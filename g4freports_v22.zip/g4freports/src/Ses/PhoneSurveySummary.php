<?php

namespace GlpiPlugin\G4freports\Ses;

/** Telephone survey evidence is disclosed separately from the GLPI-only INS12. */
final class PhoneSurveySummary
{
    public static function build(array $calls, bool $available, string $followup = ''): array
    {
        $unique = [];
        foreach ($calls as $call) {
            // Repository selects one latest non-null response per uniqueid; a call
            // can appear in more than one queue and must not inflate this count.
            $id = (string)$call['id'];
            if (array_key_exists($id, $unique)) continue;
            $raw = array_key_exists('satisfaction_raw', $call)
                ? $call['satisfaction_raw'] : ($call['satisfaction'] ?? null);
            $unique[$id] = $raw;
        }
        $responses = $valid = 0;
        if ($available) {
            foreach ($unique as $raw) {
                if ($raw === null) continue;
                $responses++;
                if (is_numeric($raw) && in_array((float)$raw, [1.0, 2.0, 3.0, 4.0, 5.0], true)) $valid++;
            }
        }
        $status = !$available ? 'Fonte de pesquisa telefônica indisponível'
            : ($responses > 0 ? 'Respostas telefônicas identificadas; fora do INS12'
                : 'Nenhuma resposta telefônica vinculada às ligações consideradas');
        $explanation = 'O INS12 desta extração usa exclusivamente as pesquisas de chamados do GLPI. '
            . 'A consulta de telefonia também busca pesquisas, mas essas respostas não participam do numerador nem do denominador do INS12. '
            . 'A contagem apresentada cobre somente os identificadores únicos das ligações do período e filas selecionados, após excluir números de teste; não é o total geral de pesquisas da central. '
            . 'Para cada identificador é selecionada a resposta não nula mais recente disponível na extração, inclusive se registrada depois do mês. '
            . 'A nota original e a nota convertida pela regra existente (6 menos a nota, na faixa de 1 a 5) ficam separadas na base de ligações. '
            . 'Valores inteiros de 1 a 5 são identificados para conferência; essa classificação não valida a escala contratual nem autoriza somar pesquisas de fontes distintas.';
        if (!$available) {
            $explanation .= ' A fonte de pesquisas não pôde ser consultada; quantidades de respostas são indisponíveis, não zero.';
        }
        return [
            'available' => $available,
            'unique_calls' => count($unique),
            'responses' => $available ? $responses : null,
            'valid_responses' => $available ? $valid : null,
            'invalid_responses' => $available ? $responses - $valid : null,
            'without_response' => $available ? count($unique) - $responses : null,
            'status' => $status,
            'explanation' => $explanation,
            'actions' => self::actions($available, $followup),
        ];
    }

    public static function actions(bool $available, string $followup): string
    {
        $text = 'Providência nesta versão: demonstrar a disponibilidade da fonte, as respostas vinculadas e os valores originais separadamente, mantendo explícita a composição do INS12. ';
        if (!$available) $text .= 'Próximo passo técnico: verificar acesso e estrutura da tabela tab_pesquisa na conexão de telefonia. ';
        $text .= 'Para uma futura inclusão no INS12, é necessário definir e validar a escala, o critério de satisfação, a população e o tratamento conjunto das duas fontes. Nenhuma validação gerencial é presumida pelo plugin.';
        return $text . (trim($followup) !== '' ? "\nAcompanhamento informado: " . trim($followup)
            : "\nAcompanhamento gerencial: não informado nesta extração.");
    }
}
