<?php

require_once dirname(__DIR__) . '/inc/bootstrap.php';

use GlpiPlugin\G4freports\Config;
use GlpiPlugin\G4freports\Security;
use GlpiPlugin\G4freports\Ses\Settings;

if (class_exists('Session')) {
    Session::checkLoginUser();
}
$cfg = Config::merged();
if (!Security::canUse($cfg)) {
    if (class_exists('Html')) { Html::displayRightError(); }
    http_response_code(403);
    exit;
}
$canConfigure = Security::canConfigure();
$initial = Settings::normalizeInput(['month' => date('Y-m', strtotime('first day of last month'))], $cfg);
$testNumbers = Settings::testNumbers($cfg['ses_test_numbers_json'] ?? '[]');
$root = rtrim((string)($GLOBALS['CFG_GLPI']['root_doc'] ?? ''), '/');
$front = $root . '/plugins/g4freports/front/';
$configUrl = $root . '/front/config.form.php';
$csrf = (class_exists('Session') && method_exists('Session', 'getNewCSRFToken')) ? Session::getNewCSRFToken() : '';
if (empty($_SESSION['g4freports_ses_nonce'])) {
    $_SESSION['g4freports_ses_nonce'] = bin2hex(random_bytes(24));
}
$nonce = (string)$_SESSION['g4freports_ses_nonce'];
$h = static function ($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); };
$field = static function (string $name) use ($initial, $h): string {
    $value = $initial[$name] ?? '';
    return $h(is_array($value) ? implode(', ', $value) : $value);
};
$configured = [];
foreach (['ses' => 'GLPI / MariaDB', 'callcenter' => 'Telefonia / MySQL'] as $source => $label) {
    $prefix = $source . '_db_';
    $ready = (int)($cfg[$prefix . 'enabled'] ?? 0) === 1;
    foreach (['host', 'name', 'user'] as $part) { $ready = $ready && trim((string)($cfg[$prefix . $part] ?? '')) !== ''; }
    $configured[$source] = ['label' => $label, 'ready' => $ready];
}
if (class_exists('Html')) { Html::header('Relatório mensal SES — G4F', $_SERVER['PHP_SELF'], 'tools', 'PluginG4freportsMenu'); }
?>
<style><?php readfile(dirname(__DIR__) . '/assets/css/ses.css'); ?></style>
<div class="g4fr-ses" id="g4fr-ses">
  <header class="g4fr-ses-header">
    <div><span class="g4fr-ses-eyebrow">G4F · CENTRAL DE SERVIÇOS</span><h1>Relatório mensal SES</h1><p>Indicadores de serviço, chamados e telefonia no mesmo relatório.</p></div>
    <nav aria-label="Áreas do plugin"><a class="btn btn-outline-secondary" href="<?php echo $h($front . 'report.php'); ?>">Relatórios por profissional</a><?php if ($canConfigure): ?> <a class="btn btn-outline-secondary" href="<?php echo $h($configUrl); ?>">Configurar conexões</a><?php endif; ?></nav>
  </header>
  <div class="g4fr-ses-connections" aria-label="Configuração das fontes">
    <?php foreach ($configured as $connection): ?><span class="g4fr-ses-source <?php echo $connection['ready'] ? 'configured' : 'missing'; ?>"><?php echo $h($connection['label']); ?>: <strong><?php echo $connection['ready'] ? 'configurada' : 'configuração pendente'; ?></strong></span><?php endforeach; ?>
    <span class="g4fr-ses-help">As fontes são consultadas ao gerar o relatório. O teste de acesso fica na configuração.</span>
  </div>
  <?php if (!$configured['ses']['ready'] || !$configured['callcenter']['ready']): ?><p class="g4fr-ses-notice">Configure e habilite as duas conexões em <strong>Configurar → Geral → Relatórios G4F</strong> antes de gerar. Esta área usa as conexões de banco dedicadas ao relatório SES.</p><?php endif; ?>
  <noscript><p class="g4fr-ses-notice error">Ative o JavaScript para gerar o relatório e administrar os números de teste.</p></noscript>

  <form id="g4fr-ses-form">
    <section class="g4fr-ses-card">
      <h2>1. Período e abrangência</h2>
      <div class="g4fr-ses-grid">
        <div class="g4fr-ses-field"><label for="ses-month">Mês de referência</label><input class="form-control" id="ses-month" name="month" type="month" value="<?php echo $field('month'); ?>" required><small>Chamados pela data de solução. Ligações pela entrada na fila.</small></div>
        <div class="g4fr-ses-field"><label for="ses-entity">ID da entidade GLPI</label><input class="form-control" id="ses-entity" name="entity_id" type="number" min="0" step="1" value="<?php echo $field('entity_id'); ?>" required><small>Somente a entidade informada; não soma subentidades.</small></div>
        <div class="g4fr-ses-field"><label for="ses-groups">IDs dos grupos atribuídos</label><input class="form-control" id="ses-groups" name="group_ids" value="<?php echo $field('group_ids'); ?>" placeholder="Opcional — deixe vazio para todos"><small>Filtra a população inteira do relatório pela atribuição atual. Para definir N1 no INS6, use o campo Grupos N1 nos critérios abaixo.</small></div>
        <div class="g4fr-ses-field"><label for="ses-queue">Identificador da fila de telefonia</label><input class="form-control" id="ses-queue" name="queue_filter" maxlength="100" value="<?php echo $field('queue_filter'); ?>" required><small>Inclui filas cujo nome contém este texto, como ssdf.</small></div>
      </div>
      <p class="g4fr-ses-method">O mês inclui do primeiro dia às 00:00 até o início do mês seguinte, sem incluir esse instante. Chamados criados antes do mês entram se foram solucionados nele. Esse critério constará nos arquivos exportados.</p>
      <details class="g4fr-ses-details">
        <summary>Critérios dos indicadores</summary>
        <div class="g4fr-ses-detail-body">
          <p class="g4fr-ses-help">A associação inicial reproduz os códigos do painel fornecido. O prazo é o registrado no chamado; ausência de prazo fica identificada separadamente.</p>
          <div class="g4fr-ses-field"><label for="ses-priority-map">Associação dos indicadores INS1 a INS4</label><select class="form-select" id="ses-priority-map" name="priority_preset"><option value="panel">Painel atual · INS1 Baixa, INS2 Média, INS3 Alta, INS4 Muito alta</option><option value="contract">Ordem do contrato · INS1 Muito alta, INS2 Alta, INS3 Média, INS4 Baixa</option></select><small id="ses-priority-description">Códigos GLPI: INS1 = 2; INS2 = 3; INS3 = 4; INS4 = 5. Esta associação será informada no relatório.</small></div>
          <div class="g4fr-ses-grid">
            <div class="g4fr-ses-field g4fr-ses-full"><label for="ses-n1-categories">IDs das categorias elegíveis N1</label><textarea class="form-control" id="ses-n1-categories" name="n1_categories" rows="3"><?php echo $field('n1_categories'); ?></textarea><small>Lista inicial das consultas fornecidas, incluindo Instalação de Navegador (162), Outro problema com o computador (149) e Criar nova pasta em servidor ou rede (176). Separe os IDs por vírgula; os nomes da base serão conferidos na extração.</small></div>
            <div class="g4fr-ses-field"><label for="ses-n1-groups">IDs dos grupos N1</label><input class="form-control" id="ses-n1-groups" name="n1_group_ids" value="<?php echo $field('n1_group_ids'); ?>"><small>Seleção inicial: 55. Os nomes serão consultados na conexão GLPI do relatório e exibidos na prévia. Este campo classifica o INS6 sem restringir a população dos demais indicadores.</small></div>
            <div class="g4fr-ses-field"><label for="ses-n3-groups">IDs dos grupos N3 a excluir de INS3, INS4 e INS6</label><input class="form-control" id="ses-n3-groups" name="n3_group_ids" value="<?php echo $field('n3_group_ids'); ?>" required><small>Qualquer vínculo atual a um destes grupos exclui o chamado das duas parcelas desses três indicadores, mesmo junto com N1. A base detalhada e os demais indicadores mantêm os chamados. Os nomes serão conferidos na base do relatório.</small></div>
            <div class="g4fr-ses-field"><label for="ses-ins6">INS6 · Critério de enquadramento N1</label><select class="form-select" id="ses-ins6" name="ins6_mode" aria-describedby="ses-ins6-help"><option value="assigned_n1" selected>Categoria elegível, grupo N1 atual e sem grupo N3</option></select><small id="ses-ins6-help">O denominador usa as categorias selecionadas sem vínculo N3; o numerador exige também um grupo N1. Chamados apenas em N2 ou sem grupo não contam como N1. A atribuição atual não comprova qual grupo solucionou o chamado na data da solução.</small></div>
            <div class="g4fr-ses-field"><label for="ses-kb">INS11 · Base de conhecimento</label><select class="form-select" id="ses-kb" name="kb_mode"><option value="validated_links" <?php echo ($initial['kb_mode'] ?? '') === 'validated_links' ? 'selected' : ''; ?>>Artigo vinculado ao chamado e validado</option><option value="category_proxy" <?php echo ($initial['kb_mode'] ?? '') === 'category_proxy' ? 'selected' : ''; ?>>Categoria com base de conhecimento — provisório</option></select><small>A aproximação por categoria será identificada como provisória.</small></div>
            <div class="g4fr-ses-field g4fr-ses-full"><label for="ses-kb-ids">IDs dos artigos previamente validados</label><input class="form-control" id="ses-kb-ids" name="validated_kb_ids" value="<?php echo $field('validated_kb_ids'); ?>" placeholder="IDs de artigos separados por vírgula"><small>Use IDs de artigos, não de categorias de chamados ou da base de conhecimento. A existência no catálogo não comprova aprovação. Sem a lista, o modo por artigos fica pendente; o modo provisório por categoria não usa esta lista.</small></div>
          </div>
        </div>
      </details>
    </section>

    <section class="g4fr-ses-card">
      <h2>2. Complementos e textos do relatório</h2>
      <div class="g4fr-ses-field"><label for="ses-title">Título</label><input class="form-control" id="ses-title" name="report_title" maxlength="180" value="<?php echo $field('report_title'); ?>" data-manual="1"></div>
      <details class="g4fr-ses-details"><summary>Informações manuais · INS5 e INS10</summary><div class="g4fr-ses-detail-body g4fr-ses-grid">
        <div class="g4fr-ses-field g4fr-ses-full"><label for="ses-incomplete">INS5 · IDs dos chamados com execução incompleta</label><input class="form-control" id="ses-incomplete" name="incomplete_ticket_ids" value="<?php echo $field('incomplete_ticket_ids'); ?>" placeholder="Opcional — IDs separados por vírgula"><small>Somados aos chamados reabertos, sem contar o mesmo chamado duas vezes. Somente chamados do período e escopo.</small></div>
        <div class="g4fr-ses-field g4fr-ses-full"><p class="g4fr-ses-help">INS10: informe a composição da equipe e as substituições no período de três meses encerrado no mês de referência. Campos vazios deixam o indicador pendente.</p></div>
        <div class="g4fr-ses-field"><label for="ses-staff">Total de profissionais da equipe</label><input class="form-control" id="ses-staff" name="staff_total" type="number" min="0" step="1" value="<?php echo $field('staff_total'); ?>"></div>
        <div class="g4fr-ses-field"><label for="ses-replacements">Substituições nos três meses</label><input class="form-control" id="ses-replacements" name="staff_replacements" type="number" min="0" step="1" value="<?php echo $field('staff_replacements'); ?>"></div>
        <div class="g4fr-ses-field"><label for="ses-excluded">Reduções determinadas pelo contratante</label><input class="form-control" id="ses-excluded" name="staff_excluded" type="number" min="0" step="1" value="<?php echo $field('staff_excluded'); ?>"><small>Quantidade a desconsiderar das substituições informadas.</small></div>
      </div></details>
      <details class="g4fr-ses-details"><summary>Análise gerencial, ações e observações</summary><div class="g4fr-ses-detail-body g4fr-ses-grid">
        <div class="g4fr-ses-field g4fr-ses-full"><label for="ses-summary">Análise gerencial</label><textarea class="form-control" id="ses-summary" name="executive_summary" rows="4" maxlength="12000" data-manual="1"><?php echo $field('executive_summary'); ?></textarea></div>
        <div class="g4fr-ses-field"><label for="ses-actions">Ações corretivas e acompanhamento</label><textarea class="form-control" id="ses-actions" name="actions" rows="4" maxlength="12000" data-manual="1"><?php echo $field('actions'); ?></textarea></div>
        <div class="g4fr-ses-field"><label for="ses-notes">Observações e justificativas</label><textarea class="form-control" id="ses-notes" name="notes" rows="4" maxlength="12000" data-manual="1"><?php echo $field('notes'); ?></textarea></div>
        <div class="g4fr-ses-field g4fr-ses-full"><label for="ses-phone-actions">INS12 · Acompanhamento das pesquisas de telefonia</label><textarea class="form-control" id="ses-phone-actions" name="phone_survey_actions" rows="3" maxlength="12000" data-manual="1"><?php echo $field('phone_survey_actions'); ?></textarea><small>Informe providências, responsáveis e prazos efetivamente acordados. O relatório mostra automaticamente a disponibilidade e as respostas vinculadas, explicando por que não integram o INS12. Este texto não altera a fórmula.</small></div>
      </div></details>
    </section>
  </form>

  <section class="g4fr-ses-card">
    <details class="g4fr-ses-details g4fr-ses-details-first"><summary>3. Números de teste excluídos da telefonia <span id="ses-test-count"></span></summary>
      <div class="g4fr-ses-detail-body">
        <p class="g4fr-ses-help">A lista salva exclui o número de origem de todos os indicadores e detalhes de telefonia. Espaços, parênteses e pontuação são removidos; os dígitos devem corresponder exatamente ao número registrado na fila. Não são excluídas automaticamente ligações curtas.</p>
        <?php if ($canConfigure): ?><form id="g4fr-ses-tests-form" method="post" action="<?php echo $h($configUrl); ?>">
          <input type="hidden" name="config_class" value="GlpiPlugin\G4freports\Config">
          <input type="hidden" name="config_context" value="plugin:g4freports">
          <input type="hidden" name="_glpi_csrf_token" value="<?php echo $h($csrf); ?>">
          <input type="hidden" name="ses_test_numbers_json" id="ses-test-json" value="<?php echo $h(json_encode($testNumbers, JSON_UNESCAPED_UNICODE)); ?>">
        <?php endif; ?>
        <div class="g4fr-ses-table-wrap"><table class="g4fr-ses-table" id="ses-tests-table"><thead><tr><th scope="col">Número de origem</th><th scope="col">Identificação / motivo</th><th scope="col">Excluir</th><?php if ($canConfigure): ?><th scope="col">Ação</th><?php endif; ?></tr></thead><tbody id="ses-tests-body"></tbody></table></div>
        <p id="ses-tests-empty" class="g4fr-ses-help" hidden>Nenhum número cadastrado. Todas as origens serão consideradas.</p>
        <?php if ($canConfigure): ?><div class="g4fr-ses-actions"><button type="button" class="btn btn-outline-secondary" id="ses-add-test">Adicionar número</button><button type="submit" class="btn btn-primary" name="update" value="1" id="ses-save-tests">Salvar números de teste</button></div><p class="g4fr-ses-help" id="ses-tests-state">Salve a lista antes de gerar o relatório. Alterações na lista exigem gerar novamente para atualizar os indicadores.</p></form><?php else: ?><p class="g4fr-ses-help">A lista é administrada pelos usuários com permissão de configuração.</p><?php endif; ?>
      </div>
    </details>
  </section>

  <div class="g4fr-ses-action-bar">
    <div class="g4fr-ses-actions"><button type="submit" form="g4fr-ses-form" class="btn btn-primary" id="ses-generate">Gerar relatório mensal</button><button type="button" class="btn btn-outline-secondary" id="ses-save-manual" disabled>Atualizar textos</button><button type="button" class="btn btn-success" id="ses-export-docx" disabled>Exportar Word</button><button type="button" class="btn btn-success" id="ses-export-xlsx" disabled>Exportar Excel</button></div>
    <span id="ses-draft-state" class="g4fr-ses-help">Gere o relatório para revisar os indicadores e exportar.</span>
  </div>
  <div id="ses-status" role="status" aria-live="polite" hidden></div>
  <section id="ses-preview" hidden aria-label="Prévia do relatório">
    <div class="g4fr-ses-card"><div class="g4fr-ses-preview-heading"><h2 id="ses-preview-title">Prévia do relatório</h2><span id="ses-generated-at" class="g4fr-ses-help"></span></div><div id="ses-totals" class="g4fr-ses-totals"></div><div id="ses-selections"></div><div id="ses-warnings"></div></div>
    <div class="g4fr-ses-card"><h2>Níveis de serviço</h2><div id="ses-metrics" class="g4fr-ses-metrics"></div><div id="ses-phone-survey"></div><details class="g4fr-ses-details"><summary>Regras aplicadas e observações</summary><div id="ses-rule-notes" class="g4fr-ses-detail-body"></div></details></div>
    <div class="g4fr-ses-card"><h2>Dados que sustentam os indicadores</h2><p class="g4fr-ses-help">A prévia é paginada. O Excel inclui todos os registros do relatório gerado.</p><div id="ses-source-tabs" class="g4fr-ses-actions" role="group" aria-label="Selecionar tabela"><button type="button" class="btn btn-outline-secondary active" data-source="tickets" aria-pressed="true">Chamados</button><button type="button" class="btn btn-outline-secondary" data-source="calls" aria-pressed="false">Ligações consideradas</button><button type="button" class="btn btn-outline-secondary" data-source="excluded_calls" aria-pressed="false">Testes excluídos</button></div><div id="ses-source-table" class="g4fr-ses-table-wrap"></div><div class="g4fr-ses-pager"><button type="button" id="ses-page-prev" class="btn btn-outline-secondary btn-sm">Anterior</button><span id="ses-page-info"></span><button type="button" id="ses-page-next" class="btn btn-outline-secondary btn-sm">Próxima</button></div></div>
  </section>
</div>
<script>
window.G4FREPORTS_SES = <?php echo json_encode([
    'api_url' => $front . 'ses_api.php', 'export_url' => $front . 'ses_export.php',
    'nonce' => $nonce, 'can_configure' => $canConfigure, 'test_numbers' => $testNumbers,
    'connections_ready' => $configured['ses']['ready'] && $configured['callcenter']['ready'],
], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE); ?>;
</script>
<script><?php readfile(dirname(__DIR__) . '/assets/js/ses.js'); ?></script>
<?php if (class_exists('Html')) { Html::footer(); } ?>
