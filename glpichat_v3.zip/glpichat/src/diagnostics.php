<?php

declare(strict_types=1);

use Symfony\Component\HttpFoundation\Response;

/**
 * Create or accept an opaque request trace ID. Only a deliberately narrow
 * character set is accepted from the browser so the value is safe in headers
 * and one-line logs.
 */
function glpichat_diagnostic_trace_id(?string $candidate = null): string
{
    $candidate = trim((string) $candidate);
    if (preg_match('/\A[a-zA-Z0-9_-]{8,64}\z/', $candidate) === 1) {
        return $candidate;
    }

    try {
        return bin2hex(random_bytes(8));
    } catch (\Throwable $e) {
        return substr(hash('sha256', uniqid('glpichat', true)), 0, 16);
    }
}

function glpichat_diagnostic_started_at(): int
{
    return hrtime(true);
}

function glpichat_diagnostic_elapsed_ms(int $started_at): float
{
    return max(0.0, round((hrtime(true) - $started_at) / 1_000_000, 3));
}

/**
 * Emit a closed-schema, privacy-safe JSON record to files/_log/glpichat.log.
 * Logging is best-effort and can never break a Chat request.
 *
 * @param array<string, mixed> $metrics
 * @param null|callable(string):void $sink Test-only sink override.
 */
function glpichat_diagnostic_log(
    string $operation,
    string $phase,
    string $trace_id,
    int $started_at,
    array $metrics = [],
    ?callable $sink = null
): void {
    $allowed_operations = [
        'widget_channels',
        'widget_history',
        'widget_mark_read',
        'widget_poll',
    ];
    $allowed_phases = [
        'start',
        'authorized',
        'session_released',
        'participant_ready',
        'messages_ready',
        'events_ready',
        'complete',
        'runtime_error',
    ];
    if (!in_array($operation, $allowed_operations, true)) {
        $operation = 'unknown';
    }
    if (!in_array($phase, $allowed_phases, true)) {
        $phase = 'runtime_error';
    }

    $record = [
        'build' => defined('PLUGIN_GLPICHAT_BUILD') ? (string) PLUGIN_GLPICHAT_BUILD : 'unknown',
        'trace' => glpichat_diagnostic_trace_id($trace_id),
        'operation' => $operation,
        'phase' => $phase,
        'elapsed_ms' => glpichat_diagnostic_elapsed_ms($started_at),
    ];

    $integer_fields = [
        'messages',
        'events',
        'channels',
        'requested_channels',
        'returned_channels',
        'channel_errors',
        'http_status',
        'peak_memory_bytes',
    ];
    foreach ($integer_fields as $field) {
        if (array_key_exists($field, $metrics)) {
            $record[$field] = max(0, (int) $metrics[$field]);
        }
    }

    if (array_key_exists('session_released', $metrics)) {
        $record['session_released'] = (bool) $metrics['session_released'];
    }

    if (array_key_exists('outcome', $metrics)) {
        $outcome = (string) $metrics['outcome'];
        $record['outcome'] = in_array($outcome, ['ok', 'rejected', 'runtime_error'], true)
            ? $outcome
            : 'runtime_error';
    }

    if (array_key_exists('exception_class', $metrics)) {
        $exception_class = (string) $metrics['exception_class'];
        $record['exception_class'] = preg_match('/\A[a-zA-Z0-9_\\\\]{1,160}\z/', $exception_class) === 1
            ? $exception_class
            : 'Throwable';
    }

    if (array_key_exists('exception_code', $metrics)) {
        $exception_code = substr((string) $metrics['exception_code'], 0, 32);
        $record['exception_code'] = preg_match('/\A[a-zA-Z0-9_.-]{0,32}\z/', $exception_code) === 1
            ? $exception_code
            : '';
    }

    $record['peak_memory_bytes'] = max(
        (int) ($record['peak_memory_bytes'] ?? 0),
        memory_get_peak_usage(true)
    );

    try {
        $line = json_encode($record, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES) . PHP_EOL;
        if ($sink !== null) {
            $sink($line);
            return;
        }
        \Toolbox::logInFile('glpichat', $line, true);
    } catch (\Throwable $e) {
        // Diagnostics must never alter endpoint behavior.
    }
}

function glpichat_diagnostic_response(
    Response $response,
    string $trace_id,
    int $started_at
): Response {
    $response->headers->set('X-Glpichat-Trace-Id', glpichat_diagnostic_trace_id($trace_id));
    $response->headers->set(
        'Server-Timing',
        sprintf('glpichat;dur=%.3f', glpichat_diagnostic_elapsed_ms($started_at))
    );

    return $response;
}
