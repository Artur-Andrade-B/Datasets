/**
 * Widget HTTP Module
 * Handles serialized fetch requests, CSRF synchronization and privacy-safe
 * request diagnostics.
 */

let csrfToken = "";
let requestCounter = 0;

export class HttpRequestError extends Error {
  constructor(message, details = {}) {
    super(message);
    this.name = "HttpRequestError";
    this.requestId = String(details.requestId || "");
    this.status = Number(details.status || 0);
    this.kind = String(details.kind || "request_failed");
  }
}

export const setCsrfToken = (token) => {
  csrfToken = token;
};

export const getCsrfToken = () => csrfToken;

const createRequestId = () => {
  requestCounter = (requestCounter + 1) % 0x1000000;

  try {
    const bytes = new Uint8Array(8);
    globalThis.crypto.getRandomValues(bytes);
    return Array.from(bytes, (value) => value.toString(16).padStart(2, "0")).join("");
  } catch (_error) {
    const timePart = Date.now().toString(16).slice(-10).padStart(10, "0");
    const counterPart = requestCounter.toString(16).padStart(6, "0");
    return `${timePart}${counterPart}`;
  }
};

const elapsedMs = (startedAt) => Math.max(0, Math.round(performance.now() - startedAt));

const normalizeRequestId = (candidate, fallback) => {
  const value = String(candidate || "");
  return /^[a-zA-Z0-9_-]{8,64}$/.test(value) ? value : fallback;
};

let activeRequestPromise = Promise.resolve();

/**
 * Perform a serialized JSON fetch request.
 *
 * Client-only options are removed before native fetch():
 * - requestLabel: privacy-safe operation name used in Console diagnostics.
 * - slowAfterMs/onSlow: soft warning only; an active fetch is never aborted.
 * - maxQueueWaitMs: expires a request only while it is still waiting to be
 *   dispatched, so stale work cannot start after a long queue blockage.
 */
export const fetchJson = (url, options = {}) => {
  const {
    requestLabel = "request",
    slowAfterMs = 0,
    onSlow = null,
    maxQueueWaitMs = 0,
    ...nativeOptions
  } = options || {};

  const requestId = createRequestId();
  const queuedAt = performance.now();
  const safeLabel = String(requestLabel || "request").slice(0, 64);
  let dispatched = false;
  let settled = false;
  let queueExpired = false;
  let slowTimer = null;
  let queueTimer = null;

  console.info(`[GLPI Chat][${requestId}] queued`, {
    operation: safeLabel,
  });

  if (Number(slowAfterMs) > 0) {
    slowTimer = window.setTimeout(() => {
      if (settled) {
        return;
      }

      const diagnostic = {
        requestId,
        operation: safeLabel,
        elapsedMs: elapsedMs(queuedAt),
        phase: dispatched ? "active" : "queued",
      };
      console.warn(`[GLPI Chat][${requestId}] slow`, diagnostic);
      if (typeof onSlow === "function") {
        try {
          onSlow(diagnostic);
        } catch (_callbackError) {
          console.error(`[GLPI Chat][${requestId}] slow callback failed`, {
            operation: safeLabel,
            kind: "callback_error",
          });
        }
      }
    }, Number(slowAfterMs));
  }

  const queueExpiryPromise = Number(maxQueueWaitMs) > 0
    ? new Promise((_, reject) => {
        queueTimer = window.setTimeout(() => {
          if (settled || dispatched) {
            return;
          }
          queueExpired = true;
          reject(new HttpRequestError(
            "Request expired before it reached the server.",
            { requestId, kind: "queue_expired" }
          ));
        }, Number(maxQueueWaitMs));
      })
    : null;

  const executionPromise = activeRequestPromise.then(async () => {
    if (queueExpired) {
      throw new HttpRequestError(
        "Request expired before it reached the server.",
        { requestId, kind: "queue_expired" }
      );
    }

    dispatched = true;
    if (queueTimer !== null) {
      window.clearTimeout(queueTimer);
      queueTimer = null;
    }

    const requestOptions = {
      credentials: "same-origin",
      ...nativeOptions,
    };
    const headers = new Headers(requestOptions.headers || {});
    headers.set("X-Requested-With", "XMLHttpRequest");
    headers.set("Accept", "application/json");
    headers.set("X-Glpichat-Trace-Id", requestId);
    if (csrfToken) {
      headers.set("X-Glpi-Csrf-Token", csrfToken);
    }
    requestOptions.headers = headers;

    if (requestOptions.body instanceof FormData) {
      if (requestOptions.body.has("_glpi_csrf_token") && csrfToken) {
        requestOptions.body.set("_glpi_csrf_token", csrfToken);
      }
    }

    console.info(`[GLPI Chat][${requestId}] start`, {
      operation: safeLabel,
      queueMs: elapsedMs(queuedAt),
    });

    let response;
    try {
      response = await fetch(url, requestOptions);
    } catch (_error) {
      throw new HttpRequestError(
        "Network request failed.",
        { requestId, kind: "network_error" }
      );
    }

    const serverTraceId = normalizeRequestId(
      response.headers.get("X-Glpichat-Trace-Id"),
      requestId
    );
    const responseText = await response.text();
    let data = {};
    if (responseText !== "") {
      try {
        data = JSON.parse(responseText);
      } catch (_error) {
        throw new HttpRequestError(
          `Unexpected response format (${response.status}).`,
          {
            requestId: serverTraceId,
            status: response.status,
            kind: "invalid_json",
          }
        );
      }
    }

    if (!response.ok) {
      const errorMsg =
        (typeof data.message === "string" && data.message !== "")
          ? data.message
          : (typeof data.error === "string" && data.error !== "")
            ? data.error
            : "Request failed.";
      throw new HttpRequestError(errorMsg, {
        requestId: normalizeRequestId(data._glpichat_trace_id, serverTraceId),
        status: response.status,
        kind: "http_error",
      });
    }

    if (data._glpi_csrf_token) {
      csrfToken = data._glpi_csrf_token;
    }

    console.info(`[GLPI Chat][${serverTraceId}] complete`, {
      operation: safeLabel,
      status: response.status,
      elapsedMs: elapsedMs(queuedAt),
    });
    return data;
  });

  activeRequestPromise = executionPromise.catch(() => {});
  const callerPromise = queueExpiryPromise
    ? Promise.race([executionPromise, queueExpiryPromise])
    : executionPromise;

  return callerPromise.catch((error) => {
    const normalizedError = error instanceof HttpRequestError
      ? error
      : new HttpRequestError("Request failed.", {
          requestId,
          kind: "request_failed",
        });
    console.error(`[GLPI Chat][${normalizedError.requestId || requestId}] failed`, {
      operation: safeLabel,
      status: normalizedError.status,
      kind: normalizedError.kind,
      elapsedMs: elapsedMs(queuedAt),
    });
    throw normalizedError;
  }).finally(() => {
    settled = true;
    if (slowTimer !== null) {
      window.clearTimeout(slowTimer);
    }
    if (queueTimer !== null) {
      window.clearTimeout(queueTimer);
    }
  });
};

export const postForm = (url, formData, requestOptions = {}) => fetchJson(url, {
  method: "POST",
  body: formData,
  credentials: "same-origin",
  ...requestOptions,
});
