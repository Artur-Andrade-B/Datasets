<?php

declare(strict_types=1);

namespace Glpi\DBAL {
    final class QueryFunction
    {
        public static function max(string $field, string $alias): string
        {
            return sprintf('MAX(%s) AS %s', $field, $alias);
        }
    }
}

namespace {
    if (!defined('READ')) {
        define('READ', 1);
    }

    final class CommonITILActor
    {
        public const REQUESTER = 1;
        public const ASSIGN = 2;
        public const OBSERVER = 3;
    }

    final class CommonITILObject
    {
        public const SOLVED = 5;
        public const CLOSED = 6;
    }

    final class Session
    {
        /** @var array<string, bool> */
        public static array $rights = [];

        /** @var array<string, int> */
        public static array $right_checks = [];

        public static function haveRight(string $right, int $level): bool
        {
            if ($level !== READ) {
                throw new RuntimeException('Unexpected right level in channel discovery test.');
            }

            self::$right_checks[$right] = (self::$right_checks[$right] ?? 0) + 1;

            return self::$rights[$right] ?? false;
        }
    }

    final class ChannelDiscoveryTicket
    {
        public int $can_calls = 0;

        public function __construct(
            public readonly int $id,
            private readonly bool $readable
        ) {
        }

        public function can(int $id, int $right): bool
        {
            if ($id !== $this->id || $right !== READ) {
                throw new RuntimeException('Unexpected Ticket::can arguments.');
            }

            $this->can_calls++;

            return $this->readable;
        }
    }

    final class ChannelDiscoveryResult implements \IteratorAggregate
    {
        /** @param list<array<string, mixed>> $rows */
        public function __construct(private readonly array $rows)
        {
        }

        public function getIterator(): \Traversable
        {
            return new \ArrayIterator($this->rows);
        }

        /** @return array<string, mixed>|false */
        public function current(): array|false
        {
            return $this->rows[0] ?? false;
        }
    }

    final class ChannelDiscoveryDb
    {
        /**
         * @param list<array{tickets_id:int}> $user_links
         * @param list<array{tickets_id:int}> $group_links
         * @param list<array{id:int,status:int}> $ticket_rows
         * @param list<array{id:int,tickets_id:int,room_type:string}> $room_rows
         * @param list<array{rooms_id:int,last_id:int}> $message_rows
         * @param list<array<string, mixed>> $participant_rows
         * @param list<array{participants_id:int,last_read_messages_id:int}> $readstate_rows
         * @param array<int, int> $unread_by_room
         */
        public function __construct(
            private readonly array $user_links,
            private readonly array $group_links,
            private readonly array $ticket_rows,
            private readonly array $room_rows,
            private readonly array $message_rows = [],
            private readonly array $participant_rows = [],
            private readonly array $readstate_rows = [],
            private readonly array $unread_by_room = []
        ) {
        }

        /** @param array<string, mixed> $query */
        public function request(array $query): ChannelDiscoveryResult
        {
            $table = (string) ($query['FROM'] ?? '');

            if ($table === 'glpi_tickets_users') {
                return new ChannelDiscoveryResult($this->user_links);
            }
            if ($table === 'glpi_groups_tickets') {
                return new ChannelDiscoveryResult($this->group_links);
            }
            if ($table === 'glpi_tickets') {
                return new ChannelDiscoveryResult($this->ticket_rows);
            }
            if ($table === 'glpi_plugin_glpichat_rooms') {
                return new ChannelDiscoveryResult($this->room_rows);
            }
            if ($table === 'glpi_plugin_glpichat_participants') {
                return new ChannelDiscoveryResult($this->participant_rows);
            }
            if ($table === 'glpi_plugin_glpichat_readstates') {
                return new ChannelDiscoveryResult($this->readstate_rows);
            }
            if ($table === 'glpi_plugin_glpichat_messages' && isset($query['COUNT'])) {
                $rooms_id = (int) ($query['WHERE']['rooms_id'] ?? 0);
                return new ChannelDiscoveryResult([['cpt' => $this->unread_by_room[$rooms_id] ?? 0]]);
            }
            if ($table === 'glpi_plugin_glpichat_messages') {
                return new ChannelDiscoveryResult($this->message_rows);
            }

            throw new RuntimeException('Unexpected table in channel discovery test: ' . $table);
        }
    }

    /** @var array<int, ChannelDiscoveryTicket> */
    $channel_discovery_tickets = [];

    /** @var array<string, int> */
    $channel_discovery_room_ids = [];

    /** @var list<string> */
    $channel_discovery_room_creations = [];

    function glpichat_ticket_or_fail(int $tickets_id): ChannelDiscoveryTicket
    {
        global $channel_discovery_tickets;

        if (!isset($channel_discovery_tickets[$tickets_id])) {
            throw new RuntimeException('Missing ticket fixture #' . $tickets_id);
        }

        return $channel_discovery_tickets[$tickets_id];
    }

    function glpichat_room_id(int $tickets_id, string $room_type): int
    {
        global $channel_discovery_room_ids, $channel_discovery_room_creations;

        $key = $tickets_id . ':' . $room_type;
        $channel_discovery_room_creations[] = $key;

        if (!isset($channel_discovery_room_ids[$key])) {
            $channel_discovery_room_ids[$key] = ($tickets_id * 100) + ($room_type === 'internal' ? 2 : 1);
        }

        return $channel_discovery_room_ids[$key];
    }

    require_once dirname(__DIR__, 3) . '/src/domain/domain.php';
    require_once dirname(__DIR__, 3) . '/src/domain/access.php';
    require_once dirname(__DIR__, 3) . '/src/domain/readstate.php';
    require_once dirname(__DIR__, 3) . '/src/views/channel_view.php';
    require_once dirname(__DIR__, 3) . '/src/db/readstate_db.php';

    /** @return never */
    function channelDiscoveryFail(string $message): void
    {
        fwrite(STDERR, "[FAIL] {$message}\n");
        exit(1);
    }

    function channelDiscoveryAssert(bool $condition, string $message): void
    {
        if (!$condition) {
            channelDiscoveryFail($message);
        }

        fwrite(STDOUT, "[PASS] {$message}\n");
    }

    /** @param mixed $expected @param mixed $actual */
    function channelDiscoveryAssertSame(mixed $expected, mixed $actual, string $message): void
    {
        if ($expected !== $actual) {
            channelDiscoveryFail(
                $message
                . ' expected=' . var_export($expected, true)
                . ' actual=' . var_export($actual, true)
            );
        }

        fwrite(STDOUT, "[PASS] {$message}\n");
    }

    // Mixed focus/user/group candidates, including a duplicate and one ticket
    // denied by GLPI. Both room types are enabled to prove that room iteration
    // does not repeat Ticket::can().
    $_SESSION['glpigroups'] = [70];
    Session::$rights = [
        'plugin_glpichat_public' => true,
        'plugin_glpichat_internal' => true,
    ];
    Session::$right_checks = [];

    $channel_discovery_tickets = [
        10 => new ChannelDiscoveryTicket(10, true),
        20 => new ChannelDiscoveryTicket(20, false),
        30 => new ChannelDiscoveryTicket(30, true),
        40 => new ChannelDiscoveryTicket(40, true),
    ];
    $channel_discovery_room_ids = ['40:internal' => 4002];
    $channel_discovery_room_creations = [];

    $GLOBALS['DB'] = new ChannelDiscoveryDb(
        [['tickets_id' => 10], ['tickets_id' => 20]],
        [['tickets_id' => 20], ['tickets_id' => 30]],
        [
            ['id' => 10, 'status' => 1],
            ['id' => 20, 'status' => 2],
            ['id' => 30, 'status' => 3],
            ['id' => 40, 'status' => 4],
        ],
        [
            ['id' => 101, 'tickets_id' => 10, 'room_type' => GLPICHAT_ROOM_PUBLIC],
            ['id' => 102, 'tickets_id' => 10, 'room_type' => GLPICHAT_ROOM_INTERNAL],
            ['id' => 201, 'tickets_id' => 20, 'room_type' => GLPICHAT_ROOM_PUBLIC],
            ['id' => 202, 'tickets_id' => 20, 'room_type' => GLPICHAT_ROOM_INTERNAL],
            ['id' => 301, 'tickets_id' => 30, 'room_type' => GLPICHAT_ROOM_PUBLIC],
            ['id' => 302, 'tickets_id' => 30, 'room_type' => GLPICHAT_ROOM_INTERNAL],
            ['id' => 401, 'tickets_id' => 40, 'room_type' => GLPICHAT_ROOM_PUBLIC],
        ],
        [
            ['rooms_id' => 101, 'last_id' => 1001],
            ['rooms_id' => 302, 'last_id' => 3002],
            ['rooms_id' => 401, 'last_id' => 4001],
        ],
        [
            [
                'id' => 9101,
                'rooms_id' => 101,
                'participant_type' => GLPICHAT_ACTOR_USER,
                'users_id' => 7,
                'left_at' => null,
            ],
            [
                'id' => 9302,
                'rooms_id' => 302,
                'participant_type' => GLPICHAT_ACTOR_USER,
                'users_id' => 7,
                'left_at' => '2026-08-23 10:00:00',
            ],
            [
                'id' => 9401,
                'rooms_id' => 401,
                'participant_type' => GLPICHAT_ACTOR_USER,
                'users_id' => 7,
                'left_at' => null,
            ],
        ],
        [
            ['participants_id' => 9101, 'last_read_messages_id' => 900],
            ['participants_id' => 9302, 'last_read_messages_id' => 2900],
            ['participants_id' => 9401, 'last_read_messages_id' => 3900],
        ],
        [101 => 1, 302 => 2, 401 => 4]
    );

    $channels = glpichat_list_user_channels(7, 40);

    $expected = [
        [
            'rooms_id' => 401,
            'tickets_id' => 40,
            'room_type' => GLPICHAT_ROOM_PUBLIC,
            'participants_id' => 9401,
            'unread_count' => 4,
            'last_message_id' => 4001,
            'ticket_status' => 4,
        ],
        [
            'rooms_id' => 4002,
            'tickets_id' => 40,
            'room_type' => GLPICHAT_ROOM_INTERNAL,
            'participants_id' => 0,
            'unread_count' => 0,
            'last_message_id' => 0,
            'ticket_status' => 4,
        ],
        [
            'rooms_id' => 301,
            'tickets_id' => 30,
            'room_type' => GLPICHAT_ROOM_PUBLIC,
            'participants_id' => 0,
            'unread_count' => 0,
            'last_message_id' => 0,
            'ticket_status' => 3,
        ],
        [
            'rooms_id' => 302,
            'tickets_id' => 30,
            'room_type' => GLPICHAT_ROOM_INTERNAL,
            'participants_id' => 0,
            'unread_count' => 2,
            'last_message_id' => 3002,
            'ticket_status' => 3,
        ],
        [
            'rooms_id' => 101,
            'tickets_id' => 10,
            'room_type' => GLPICHAT_ROOM_PUBLIC,
            'participants_id' => 9101,
            'unread_count' => 1,
            'last_message_id' => 1001,
            'ticket_status' => 1,
        ],
        [
            'rooms_id' => 102,
            'tickets_id' => 10,
            'room_type' => GLPICHAT_ROOM_INTERNAL,
            'participants_id' => 0,
            'unread_count' => 0,
            'last_message_id' => 0,
            'ticket_status' => 1,
        ],
    ];

    channelDiscoveryAssertSame($expected, $channels, 'Channel output, order, rooms, unread state and status remain unchanged');
    channelDiscoveryAssertSame(['40:internal'], $channel_discovery_room_creations, 'Missing allowed room still uses existing room creation path');
    channelDiscoveryAssertSame(1, Session::$right_checks['plugin_glpichat_public'] ?? 0, 'Public read right is snapshotted once');
    channelDiscoveryAssertSame(1, Session::$right_checks['plugin_glpichat_internal'] ?? 0, 'Internal read right is snapshotted once');

    foreach ($channel_discovery_tickets as $tickets_id => $ticket) {
        channelDiscoveryAssertSame(1, $ticket->can_calls, 'Ticket #' . $tickets_id . ' receives one Ticket::can decision');
    }

    channelDiscoveryAssert(
        !in_array(20, array_column($channels, 'tickets_id'), true),
        'Ticket denied by GLPI remains absent from channel output'
    );

    // Preserve the historical 80-output cap and descending candidate order.
    $_SESSION['glpigroups'] = [];
    Session::$rights = [
        'plugin_glpichat_public' => true,
        'plugin_glpichat_internal' => false,
    ];
    Session::$right_checks = [];
    $channel_discovery_tickets = [];
    $user_links = [];
    $ticket_rows = [];
    for ($id = 1; $id <= 85; $id++) {
        $channel_discovery_tickets[$id] = new ChannelDiscoveryTicket($id, true);
        $user_links[] = ['tickets_id' => $id];
        $ticket_rows[] = ['id' => $id, 'status' => 1];
    }
    $channel_discovery_room_ids = [];
    $channel_discovery_room_creations = [];
    $GLOBALS['DB'] = new ChannelDiscoveryDb($user_links, [], $ticket_rows, []);

    $capped_channels = glpichat_list_user_channels(7, 0);

    channelDiscoveryAssertSame(80, count($capped_channels), 'Channel discovery preserves the 80-output cap');
    channelDiscoveryAssertSame(85, $capped_channels[0]['tickets_id'] ?? 0, 'Candidate order remains descending at the first result');
    channelDiscoveryAssertSame(6, $capped_channels[79]['tickets_id'] ?? 0, 'Candidate order remains descending at the cap boundary');
    channelDiscoveryAssertSame(1, Session::$right_checks['plugin_glpichat_public'] ?? 0, 'Capped discovery snapshots public right once');
    channelDiscoveryAssertSame(1, Session::$right_checks['plugin_glpichat_internal'] ?? 0, 'Capped discovery snapshots internal right once');

    for ($id = 6; $id <= 85; $id++) {
        channelDiscoveryAssertSame(1, $channel_discovery_tickets[$id]->can_calls, 'Evaluated ticket #' . $id . ' is authorized once');
    }
    for ($id = 1; $id <= 5; $id++) {
        channelDiscoveryAssertSame(0, $channel_discovery_tickets[$id]->can_calls, 'Ticket #' . $id . ' remains beyond the unchanged cap');
    }

    // Keep the baseline stale-link behavior explicit. Candidate discovery has
    // historically surfaced glpichat_ticket_or_fail() failures instead of
    // silently converting a nonexistent linked ticket into an empty channel.
    Session::$rights = [
        'plugin_glpichat_public' => true,
        'plugin_glpichat_internal' => true,
    ];
    Session::$right_checks = [];
    $channel_discovery_tickets = [];
    $channel_discovery_room_ids = [];
    $channel_discovery_room_creations = [];
    $GLOBALS['DB'] = new ChannelDiscoveryDb(
        [['tickets_id' => 999]],
        [],
        [],
        []
    );

    try {
        glpichat_list_user_channels(7, 0);
        channelDiscoveryFail('Stale linked ticket must retain the baseline failure behavior');
    } catch (RuntimeException $error) {
        channelDiscoveryAssertSame(
            'Missing ticket fixture #999',
            $error->getMessage(),
            'Stale/nonexistent candidate still follows glpichat_ticket_or_fail behavior'
        );
    }

    fwrite(STDOUT, "[PASS] Channel discovery authorization unit tests completed\n");
}
