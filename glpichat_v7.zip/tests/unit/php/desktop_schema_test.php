<?php

declare(strict_types=1);

// Standalone fixture suite; no GLPI bootstrap, database, vendor or credentials.
require_once dirname(__DIR__, 3) . '/src/desktop/schema.php';

function desktop_schema_assert(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

function desktop_schema_fixture(): array
{
    $metadata = ['tables' => [], 'columns' => [], 'indexes' => []];
    $definitions = glpichat_desktop_schema_definitions();
    $definitions['glpi_plugin_glpichat_messages'] = [
        'columns' => [],
        'indexes' => ['desktop_followup_id' => ['columns' => ['itilfollowups_id'], 'unique' => false]],
    ];
    foreach ($definitions as $table => $definition) {
        $metadata['tables'][] = ['TABLE_NAME' => $table, 'ENGINE' => 'InnoDB'];
        foreach ($definition['columns'] as $name => $column) {
            $type = str_replace(' ascii_bin', '', $column['type']);
            // MariaDB integer display widths must normalize correctly.
            $type = preg_replace('/\bint\b/', 'int(10)', $type);
            $type = preg_replace('/\bbigint\b/', 'bigint(20)', $type);
            $metadata['columns'][] = [
                'TABLE_NAME' => $table, 'COLUMN_NAME' => $name,
                'COLUMN_TYPE' => $type,
                'COLUMN_DEFAULT' => str_starts_with($column['extra'], 'DEFAULT ') ? substr($column['extra'], 8) : null,
                'IS_NULLABLE' => $column['nullable'] ? 'YES' : 'NO',
                'COLLATION_NAME' => str_contains($column['type'], 'ascii_bin') ? 'ascii_bin' : null,
                'EXTRA' => $name === 'id' ? 'auto_increment' : '',
            ];
        }
        foreach ($definition['indexes'] as $name => $index) {
            foreach ($index['columns'] as $position => $column) {
                $metadata['indexes'][] = [
                    'TABLE_NAME' => $table, 'INDEX_NAME' => $name,
                    'NON_UNIQUE' => $index['unique'] ? 0 : 1,
                    'SEQ_IN_INDEX' => $position + 1, 'COLUMN_NAME' => $column,
                    'SUB_PART' => null,
                ];
            }
        }
    }
    return $metadata;
}

$config = ['desktop_schema_version' => '1', 'desktop_idempotency_key' => str_repeat('a', 64), 'desktop_enabled' => '0'];
$read_config = static function (string $key) use (&$config): mixed { return $config[$key] ?? null; };
$metadata = desktop_schema_fixture();
$read_metadata = static function () use (&$metadata): array { return $metadata; };
desktop_schema_assert(glpichat_desktop_schema_health(true, $read_metadata, $read_config)['healthy'], 'Complete metadata must pass.');

foreach (['tables', 'columns', 'indexes'] as $kind) {
    $broken = $metadata;
    array_shift($broken[$kind]);
    $health = glpichat_desktop_schema_health(true, static fn (): array => $broken, $read_config);
    desktop_schema_assert(!$health['healthy'], 'Missing ' . $kind . ' must fail closed.');
}
foreach (['engine', 'collation', 'default', 'unique', 'prefix', 'order'] as $case) {
    $broken = $metadata;
    if ($case === 'engine') {
        $broken['tables'][0]['ENGINE'] = 'MyISAM';
    } elseif ($case === 'collation') {
        $broken['columns'][1]['COLLATION_NAME'] = 'ascii_general_ci';
    } elseif ($case === 'default') {
        foreach ($broken['columns'] as &$column) {
            if ($column['COLUMN_NAME'] === 'status') { $column['COLUMN_DEFAULT'] = null; }
        }
        unset($column);
    } else {
        foreach ($broken['indexes'] as &$index) {
            if ($index['INDEX_NAME'] === 'desktop_send_uuid') {
                if ($case === 'unique') { $index['NON_UNIQUE'] = 1; }
                if ($case === 'prefix') { $index['SUB_PART'] = 4; }
                if ($case === 'order') { $index['SEQ_IN_INDEX'] = 3 - $index['SEQ_IN_INDEX']; }
            }
        }
        unset($index);
    }
    desktop_schema_assert(!glpichat_desktop_schema_health(true, static fn (): array => $broken, $read_config)['healthy'], 'Incompatible ' . $case . ' must fail.');
}
foreach ([null, false, true, '', '0', '01', '2', 1.0, 'garbage'] as $bad_marker) {
    $config['desktop_schema_version'] = $bad_marker;
    desktop_schema_assert(!glpichat_desktop_schema_health(true, $read_metadata, $read_config)['healthy'], 'Unsupported marker must fail.');
}
$config['desktop_schema_version'] = '1';
$opaque = glpichat_desktop_schema_health(true, static function (): array { throw new RuntimeException('sensitive server detail'); }, $read_config);
desktop_schema_assert($opaque['issues'] === ['schema_metadata:unavailable'], 'Inspection errors must be opaque.');
desktop_schema_assert(glpichat_desktop_schema_version_to_store('99') === '99', 'Future marker must not downgrade.');

// Simulate interrupted/new install and repeat. DDL changes only the fixture's
// table/index presence; deployed column/index semantics are checked separately.
$present = ['glpi_plugin_glpichat_messages' => true];
$created_sql = [];
$index_present = false;
$config = ['desktop_enabled' => '0'];
$writes = [];
$exists = static function (string $table) use (&$present): bool { return isset($present[$table]); };
$execute = static function (string $sql) use (&$present, &$created_sql, &$index_present): void {
    $created_sql[] = $sql;
    if (preg_match('/\ACREATE TABLE `([^`]+)`/', $sql, $match) === 1) {
        $present[$match[1]] = true;
    } elseif (str_starts_with($sql, 'ALTER TABLE `glpi_plugin_glpichat_messages` ADD KEY `desktop_followup_id`')) {
        $index_present = true;
    } else {
        throw new RuntimeException('Unexpected mutation in installer.');
    }
};
$install_metadata = static function () use (&$present, &$index_present): array {
    $fixture = desktop_schema_fixture();
    foreach (['tables', 'columns', 'indexes'] as $kind) {
        $fixture[$kind] = array_values(array_filter($fixture[$kind], static function (array $row) use (&$present, &$index_present): bool {
            return isset($present[$row['TABLE_NAME']])
                && (($row['INDEX_NAME'] ?? '') !== 'desktop_followup_id' || $index_present);
        }));
    }
    return $fixture;
};
$write_config = static function (array $values) use (&$config, &$writes): void {
    $writes[] = $values;
    $config = array_replace($config, $values);
};
glpichat_desktop_schema_install($exists, $execute, $install_metadata, $read_config, $write_config);
desktop_schema_assert(count($created_sql) === 4, 'First install creates three tables and one supporting index.');
desktop_schema_assert($config['desktop_enabled'] === '0', 'Desktop starts disabled.');
desktop_schema_assert(preg_match('/\A[a-f0-9]{64}\z/', $config['desktop_idempotency_key']) === 1, 'Install creates HMAC key.');
desktop_schema_assert(end($writes) === ['desktop_schema_version' => '1'], 'Schema marker is final write.');
$key_before = $config['desktop_idempotency_key'];
$config['desktop_enabled'] = '1';
glpichat_desktop_schema_install($exists, $execute, $install_metadata, $read_config, $write_config);
desktop_schema_assert(count($created_sql) === 4, 'Repeat install must not repeat DDL.');
desktop_schema_assert($config['desktop_enabled'] === '1' && $config['desktop_idempotency_key'] === $key_before, 'Repeat preserves explicit opt-in and HMAC key.');
$config['desktop_schema_version'] = '5';
glpichat_desktop_schema_install($exists, $execute, $install_metadata, $read_config, $write_config);
desktop_schema_assert($config['desktop_schema_version'] === '5', 'Old package preserves future marker.');

unset($config['desktop_schema_version']);
$bad_readback = static function () use ($install_metadata): array {
    $value = $install_metadata();
    $value['columns'] = [];
    return $value;
};
$rejected = false;
try {
    glpichat_desktop_schema_install($exists, $execute, $bad_readback, $read_config, $write_config);
} catch (RuntimeException $e) {
    $rejected = true;
}
desktop_schema_assert($rejected && !isset($config['desktop_schema_version']), 'Failed structural readback cannot mark installation complete.');

$config['desktop_idempotency_key'] = 'invalid-existing-key';
$writes_before = count($writes);
$rejected = false;
try {
    glpichat_desktop_schema_install($exists, $execute, $install_metadata, $read_config, $write_config);
} catch (RuntimeException $e) {
    $rejected = true;
}
desktop_schema_assert($rejected && $config['desktop_idempotency_key'] === 'invalid-existing-key'
    && count($writes) === $writes_before, 'Invalid existing HMAC key must not be rotated or hidden.');

// Exercise the production metadata reader with a DB that has no write method.
$DB = new class {
    public array $queries = [];
    public function query(string $sql): object {
        $this->queries[] = $sql;
        desktop_schema_assert(str_starts_with($sql, 'SELECT '), 'Health must use SELECT only.');
        return (object) [];
    }
    public function fetchAssoc(object $result): false { return false; }
};
glpichat_desktop_schema_metadata();
desktop_schema_assert(count($DB->queries) === 3, 'Metadata inspection is three bounded read-only queries.');
echo "[PASS] Desktop schema lifecycle, repeat, fail-closed shapes, monotonic marker and no runtime DDL\n";
