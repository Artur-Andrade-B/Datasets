<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpichat\Domain;

use InvalidArgumentException;

/**
 * Immutable, request-local authorization facts for one authenticated GLPI actor.
 *
 * This value object deliberately contains no names, credentials, tokens, session
 * objects, tickets, or other mutable framework state. It can therefore be reused
 * by future transports without coupling their authorization rules to PHP sessions.
 */
final readonly class ActorContext
{
    /** @var list<int> */
    public array $entityIds;

    /** @var list<int> */
    public array $groupIds;

    /**
     * @param list<int> $entityIds
     * @param list<int> $groupIds
     */
    public function __construct(
        public int $userId,
        public int $profileId,
        public int $entityId,
        public bool $isRecursive,
        array $entityIds,
        array $groupIds,
        public bool $canReadPublic,
        public bool $canCreatePublic
    ) {
        if ($userId <= 0) {
            throw new InvalidArgumentException('Actor user id must be positive.');
        }
        if ($profileId <= 0) {
            throw new InvalidArgumentException('Actor profile id must be positive.');
        }
        if ($entityId < 0) {
            throw new InvalidArgumentException('Actor entity id cannot be negative.');
        }

        $normalizedEntityIds = self::normalizeIds($entityIds, true, 'entity');
        if (!in_array($entityId, $normalizedEntityIds, true)) {
            $normalizedEntityIds[] = $entityId;
            sort($normalizedEntityIds, SORT_NUMERIC);
        }

        $this->entityIds = $normalizedEntityIds;
        $this->groupIds = self::normalizeIds($groupIds, false, 'group');
    }

    /**
     * @param list<int> $ids
     * @return list<int>
     */
    private static function normalizeIds(array $ids, bool $allowZero, string $label): array
    {
        $normalized = [];
        foreach ($ids as $id) {
            if (!is_int($id) || ($allowZero ? $id < 0 : $id <= 0)) {
                throw new InvalidArgumentException(sprintf(
                    'Actor %s ids must be %s integers.',
                    $label,
                    $allowZero ? 'non-negative' : 'positive'
                ));
            }
            $normalized[$id] = $id;
        }

        $normalized = array_values($normalized);
        sort($normalized, SORT_NUMERIC);

        return $normalized;
    }
}
