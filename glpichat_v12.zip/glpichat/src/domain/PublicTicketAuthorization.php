<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpichat\Domain;

/**
 * Pure public-room policy. GLPI remains authoritative for the ticket-level
 * decision supplied by the caller; this service only composes immutable facts.
 */
final class PublicTicketAuthorization
{
    public static function canRead(ActorContext $actor, bool $ticketCanRead): bool
    {
        return $ticketCanRead && $actor->canReadPublic;
    }

    public static function canSend(
        ActorContext $actor,
        bool $ticketCanRead,
        bool $ticketTerminal
    ): bool {
        return self::canRead($actor, $ticketCanRead)
            && $actor->canCreatePublic
            && !$ticketTerminal;
    }
}
