<?php

declare(strict_types=1);

use GlpiPlugin\Glpichat\Domain\ActorContext;

/**
 * Strict parser for the hidden public-authorization shadow flag. Only an exact
 * integer/string 1 enables observation; every malformed value fails closed.
 */
function glpichat_public_authorization_shadow_value_enabled(mixed $value): bool
{
    return $value === 1 || $value === '1';
}

function glpichat_public_authorization_shadow_enabled(): bool
{
    static $resolved = false;
    static $enabled = false;

    if ($resolved) {
        return $enabled;
    }
    $resolved = true;

    try {
        $enabled = glpichat_public_authorization_shadow_value_enabled(
            Config::getConfigurationValue('plugin:glpichat', 'public_authorization_shadow_enabled')
        );
    } catch (Throwable $error) {
        $enabled = false;
    }

    return $enabled;
}

/**
 * Capture the authenticated browser's request-local GLPI scope without keeping
 * a reference to Session, Ticket, or any mutable framework object.
 */
function glpichat_capture_browser_actor_context(
    bool $canReadPublic,
    bool $canCreatePublic
): ActorContext {
    $profile = $_SESSION['glpiactiveprofile'] ?? [];
    $profileId = is_array($profile)
        ? (glpichat_normalize_session_id($profile['id'] ?? null, false) ?? 0)
        : 0;
    $entityId = glpichat_normalize_session_id(
        $_SESSION['glpiactive_entity'] ?? null,
        true
    ) ?? -1;
    $isRecursive = glpichat_normalize_session_bool(
        $_SESSION['glpiactive_entity_recursive'] ?? null
    );
    if ($isRecursive === null) {
        throw new InvalidArgumentException('Actor recursive-entity state is missing or malformed.');
    }

    $rawEntityIds = $_SESSION['glpiactiveentities'] ?? [];
    $entityIds = glpichat_normalize_session_ids($rawEntityIds, true);
    $rawGroupIds = $_SESSION['glpigroups'] ?? [];
    $groupIds = glpichat_normalize_session_ids($rawGroupIds, false);

    return new ActorContext(
        glpichat_current_user_id(),
        $profileId,
        $entityId,
        $isRecursive,
        $entityIds,
        $groupIds,
        $canReadPublic,
        $canCreatePublic
    );
}

function glpichat_normalize_session_bool(mixed $rawValue): ?bool
{
    return match ($rawValue) {
        false, 0, '0' => false,
        true, 1, '1' => true,
        default => null,
    };
}

function glpichat_normalize_session_id(mixed $rawId, bool $allowZero): ?int
{
    if (is_int($rawId)) {
        $id = $rawId;
    } elseif (is_string($rawId) && preg_match('/\A(?:0|[1-9][0-9]*)\z/', $rawId) === 1) {
        $candidate = filter_var($rawId, FILTER_VALIDATE_INT, [
            'options' => ['min_range' => 0],
        ]);
        if (!is_int($candidate)) {
            return null;
        }
        $id = $candidate;
    } else {
        return null;
    }

    if ($allowZero ? $id < 0 : $id <= 0) {
        return null;
    }

    return $id;
}

/**
 * @return list<int>
 */
function glpichat_normalize_session_ids(mixed $rawIds, bool $allowZero): array
{
    if (!is_array($rawIds)) {
        return [];
    }

    $normalized = [];
    foreach ($rawIds as $rawId) {
        $id = glpichat_normalize_session_id($rawId, $allowZero);
        if ($id === null) {
            continue;
        }
        $normalized[$id] = $id;
    }

    $normalized = array_values($normalized);
    sort($normalized, SORT_NUMERIC);

    return $normalized;
}
