<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpichat\Domain;

use Throwable;

/**
 * Best-effort parity observer. It intentionally returns no authorization value,
 * making it impossible for a shadow decision to replace the current decision.
 */
final class AuthorizationShadow
{
    public const PUBLIC_READ = 'public_read';
    public const PUBLIC_SEND = 'public_send';

    /**
     * @param callable():bool $evaluateShadow
     * @param null|callable(array<string, bool|string>):void $observer
     */
    public static function observe(
        bool $enabled,
        string $decision,
        bool $currentAllowed,
        callable $evaluateShadow,
        ?callable $observer = null
    ): void {
        if (!$enabled || !in_array($decision, [self::PUBLIC_READ, self::PUBLIC_SEND], true)) {
            return;
        }

        try {
            $shadowAllowed = (bool) $evaluateShadow();
        } catch (Throwable $error) {
            self::notify($observer, [
                'decision' => $decision,
                'outcome' => 'error',
                'current_allowed' => $currentAllowed,
                'exception_class' => $error::class,
            ]);
            return;
        }

        if ($shadowAllowed === $currentAllowed) {
            return;
        }

        self::notify($observer, [
            'decision' => $decision,
            'outcome' => 'mismatch',
            'current_allowed' => $currentAllowed,
            'shadow_allowed' => $shadowAllowed,
        ]);
    }

    /**
     * @param null|callable(array<string, bool|string>):void $observer
     * @param array<string, bool|string> $observation
     */
    private static function notify(?callable $observer, array $observation): void
    {
        if ($observer === null) {
            return;
        }

        try {
            $observer($observation);
        } catch (Throwable $error) {
            // Shadow diagnostics can never alter the current authorization path.
        }
    }
}
