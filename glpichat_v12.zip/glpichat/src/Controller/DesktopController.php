<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpichat\Controller;

use Glpi\Controller\AbstractController;
use Glpi\Http\Firewall;
use Glpi\Security\Attribute\SecurityStrategy;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

require_once dirname(__DIR__) . '/functions.php';
require_once dirname(__DIR__) . '/desktop/common.php';
require_once dirname(__DIR__) . '/desktop/auth.php';
require_once dirname(__DIR__) . '/desktop/conversations.php';

/** Explicit pilot adapter; it never consumes or fabricates a GLPI user session. */
final class DesktopController extends AbstractController
{
    #[Route('/Desktop/V1/{operation}', name: 'glpichat_desktop_v1', requirements: ['operation' => '.+'], methods: ['GET', 'POST'])]
    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]
    public function dispatch(Request $request, string $operation): Response
    {
        \glpichat_desktop_reset_request_context();
        $status = 200;
        $stage = 'request';
        try {
            \glpichat_desktop_request_guard($request);
            $method = $request->getRealMethod();
            $stage = 'request_body';
            $data = $method === 'POST' ? \glpichat_desktop_json_body($request) : [];
            if ($method === 'POST' && $operation === 'Enroll') {
                $stage = 'managed_enroll';
                $result = \glpichat_desktop_enroll($data);
            } elseif ($method === 'POST' && $operation === 'Renew') {
                $stage = 'managed_renew';
                $result = \glpichat_desktop_renew($data);
            } elseif ($method === 'POST' && $operation === 'Pairings') {
                $stage = 'pair_start';
                $result = \glpichat_desktop_pair_start($data, $request->getClientIp() ?? 'unknown', $request);
                $status = 201;
            } elseif (preg_match('~\APairings/([a-f0-9]{32})(/Exchange)?\z~D', $operation, $match) === 1) {
                $stage = 'pair_credentials';
                $secret = (string) $request->headers->get('X-GLPIChat-Pairing-Secret', '');
                if (preg_match('/\A[a-f0-9]{64}\z/D', $secret) !== 1) {
                    \glpichat_desktop_fail('invalid_pairing', 'Vínculo inválido ou expirado.', 401);
                }
                if ($method === 'GET' && empty($match[2])) {
                    $stage = 'pair_status';
                    $result = \glpichat_desktop_pair_status($match[1], $secret);
                } elseif ($method === 'POST' && ($match[2] ?? '') === '/Exchange') {
                    $stage = 'pair_exchange';
                    $result = \glpichat_desktop_pair_exchange($match[1], $secret, \glpichat_desktop_string($data, 'token', 64));
                } else {
                    \glpichat_desktop_fail('not_found', 'Operação indisponível.', 404);
                }
            } else {
                $stage = 'authenticate';
                $actor = \glpichat_desktop_authenticate(\glpichat_desktop_bearer($request));
                if ($method === 'GET' && $operation === 'Me') {
                    $stage = 'identity';
                    $result = \glpichat_desktop_identity($actor);
                } elseif ($method === 'POST' && $operation === 'Revoke') {
                    $stage = 'revoke';
                    \glpichat_desktop_revoke($actor);
                    $result = ['ok' => true];
                } elseif ($method === 'GET' && $operation === 'Conversations') {
                    $stage = 'conversations';
                    $result = \glpichat_desktop_conversations($actor, max(0, $request->query->getInt('before')), $this->limit($request, 30));
                } elseif (preg_match('~\AConversations/([1-9][0-9]{0,9})/(Messages|Read)\z~D', $operation, $match) === 1) {
                    $ticket = (int) $match[1];
                    if ($match[2] === 'Messages' && $method === 'GET') {
                        $stage = 'history';
                        $result = \glpichat_desktop_history($actor, $ticket, max(0, $request->query->getInt('before')), $this->limit($request, 50));
                    } elseif ($match[2] === 'Messages' && $method === 'POST') {
                        $stage = 'send';
                        $result = \glpichat_desktop_send($actor, $ticket, \glpichat_desktop_string($data, 'client_message_id', 36), \glpichat_desktop_string($data, 'content', 16000));
                    } elseif ($match[2] === 'Read' && $method === 'POST') {
                        $ids = $data['message_ids'] ?? null;
                        if (!is_array($ids) || !array_is_list($ids) || count($ids) > 50) {
                            \glpichat_desktop_fail('invalid_request', 'Lista de mensagens inválida.', 400);
                        }
                        $stage = 'read';
                        \glpichat_desktop_read($actor, $ticket, $ids);
                        $result = ['ok' => true];
                    } else {
                        \glpichat_desktop_fail('not_found', 'Operação indisponível.', 404);
                    }
                } else {
                    \glpichat_desktop_fail('not_found', 'Operação indisponível.', 404);
                }
            }
        } catch (\GlpichatDesktopException $e) {
            $status = $e->httpStatus;
            $result = ['error' => ['code' => $e->errorCode, 'message' => $e->getMessage()]];
        } catch (\Symfony\Component\HttpFoundation\Exception\RequestExceptionInterface $e) {
            $status = 400;
            $result = ['error' => ['code' => 'invalid_request', 'message' => 'Parâmetros de solicitação inválidos.']];
        } catch (\Throwable $e) {
            $reference = \glpichat_desktop_log_failure($stage, $e);
            $status = 503;
            $result = ['error' => ['code' => 'temporarily_unavailable', 'message' => 'Serviço indisponível. Referência para o administrador: ' . $reference . '.', 'reference' => $reference]];
        }
        $response = new JsonResponse($result, $status);
        $response->headers->set('Cache-Control', 'no-store, private');
        $response->headers->set('Pragma', 'no-cache');
        $response->headers->set('X-Content-Type-Options', 'nosniff');
        $response->headers->set('Referrer-Policy', 'no-referrer');
        $response->headers->set('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'");
        if ($status === 401) {
            $response->headers->set('WWW-Authenticate', 'Bearer realm="GLPIChat Desktop"');
        }
        if ($status === 429 || $status === 503) {
            $response->headers->set('Retry-After', '15');
        }
        return $response;
    }

    private function limit(Request $request, int $maximum): int
    {
        $value = $request->query->getInt('limit', $maximum);
        return max(1, min($maximum, $value));
    }
}
