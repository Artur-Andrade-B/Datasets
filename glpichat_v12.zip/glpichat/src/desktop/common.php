<?php

declare(strict_types=1);

use Symfony\Component\HttpFoundation\Request;

/** Desktop1 is an explicitly enabled, requester-only pilot adapter. */
final class GlpichatDesktopException extends RuntimeException
{
    public function __construct(public readonly string $errorCode, string $message, public readonly int $httpStatus)
    {
        parent::__construct($message, $httpStatus);
    }
}

function glpichat_desktop_fail(string $code, string $message, int $status): never
{
    throw new GlpichatDesktopException($code, $message, $status);
}

function glpichat_desktop_now(): string
{
    return gmdate('Y-m-d H:i:s');
}

/** One configuration snapshot per HTTP request, never a cross-request cache. */
function glpichat_desktop_reset_request_context(): void
{
    unset($GLOBALS['glpichat_desktop_request_config']);
}

function glpichat_desktop_config(string $key): mixed
{
    if (!isset($GLOBALS['glpichat_desktop_request_config'])) {
        $GLOBALS['glpichat_desktop_request_config'] = Config::getConfigurationValues('plugin:glpichat');
    }
    return $GLOBALS['glpichat_desktop_request_config'][$key] ?? null;
}

function glpichat_desktop_enabled(): bool
{
    return (string) glpichat_desktop_config('desktop_enabled') === '1';
}

/**
 * Compatibility link for older clients only. It is not an activation or API
 * prerequisite. Current clients construct the approval link from their own
 * configured GLPI root and pairing ID, independent of backend transport.
 */
function glpichat_desktop_base_url(?Request $request = null): string
{
    global $CFG_GLPI;
    $request ??= Request::createFromGlobals();
    try {
        $origin = $request->getSchemeAndHttpHost();
        // Core computes root_doc from Request::getBasePath() during web boot.
        $path = rtrim((string) ($CFG_GLPI['root_doc'] ?? $request->getBasePath()), '/');
    } catch (\Symfony\Component\HttpFoundation\Exception\RequestExceptionInterface $error) {
        glpichat_desktop_fail('invalid_request', 'Não foi possível identificar o endereço do GLPI.', 400);
    }
    if (($path !== '' && (!str_starts_with($path, '/') || str_starts_with($path, '//')))
        || preg_match('/[\x00-\x20\x7f\\\\?#]/', $path)
        || preg_match('~(?:^|/)\.{1,2}(?:/|$)~', rawurldecode($path))) {
        glpichat_desktop_fail('invalid_request', 'Não foi possível identificar o caminho do GLPI.', 400);
    }
    $url = $origin . $path;
    $parts = parse_url($url);
    if (!is_array($parts) || !in_array($parts['scheme'] ?? '', ['http', 'https'], true)
        || empty($parts['host']) || isset($parts['user']) || isset($parts['pass'])
        || isset($parts['query']) || isset($parts['fragment']) || preg_match('/[\x00-\x20\x7f\\\\]/', $url)) {
        glpichat_desktop_fail('invalid_request', 'Não foi possível identificar o endereço do GLPI.', 400);
    }
    return $url;
}

/** Full structural readback belongs to install/update, not every page/poll. */
function glpichat_desktop_schema_ready(): bool
{
    return in_array((string) glpichat_desktop_config('desktop_schema_version'), ['1', '2'], true)
        && preg_match('/\A[a-f0-9]{64}\z/D', (string) glpichat_desktop_config('desktop_idempotency_key')) === 1;
}

function glpichat_desktop_require_schema(): void
{
    if (!glpichat_desktop_schema_ready()) {
        glpichat_desktop_fail('schema_unavailable', 'Conclua a atualização do plugin antes de usar o aplicativo.', 503);
    }
}

function glpichat_desktop_request_guard(Request $request): void
{
    if (!glpichat_desktop_enabled()) {
        glpichat_desktop_fail('unavailable', 'Aplicativo de desktop indisponível.', 404);
    }
    // A cookie or Origin header neither grants access nor invalidates a bearer.
    // No browser session or CORS permission is used for these API operations.
    glpichat_desktop_require_schema();
}

/** Useful server diagnostics without logging request data or exception text. */
function glpichat_desktop_log_failure(string $stage, Throwable $error): string
{
    $reference = bin2hex(random_bytes(6));
    error_log(sprintf(
        'glpichat desktop [%s] stage=%s exception=%s location=%s:%d code=%s',
        $reference,
        preg_replace('/[^A-Za-z0-9_\/.-]/', '_', $stage),
        get_class($error),
        basename($error->getFile()),
        $error->getLine(),
        preg_replace('/[^A-Za-z0-9_-]/', '_', (string) $error->getCode())
    ));
    return $reference;
}

function glpichat_desktop_json_body(Request $request): array
{
    $type = strtolower(trim(explode(';', (string) $request->headers->get('Content-Type', ''))[0]));
    if ($type !== 'application/json') {
        glpichat_desktop_fail('json_required', 'Envie uma solicitação JSON.', 415);
    }
    $advertised = (int) $request->headers->get('Content-Length', '0');
    if ($advertised > 32768) {
        glpichat_desktop_fail('request_too_large', 'Solicitação muito grande.', 413);
    }
    $stream = $request->getContent(true);
    $raw = is_resource($stream) ? stream_get_contents($stream, 32769) : false;
    if (!is_string($raw) || strlen($raw) > 32768) {
        glpichat_desktop_fail('request_too_large', 'Solicitação muito grande.', 413);
    }
    try {
        $object = json_decode($raw, false, 16, JSON_THROW_ON_ERROR);
    } catch (JsonException $e) {
        glpichat_desktop_fail('invalid_json', 'JSON inválido.', 400);
    }
    if (!$object instanceof stdClass) {
        glpichat_desktop_fail('invalid_json', 'O corpo deve ser um objeto JSON.', 400);
    }
    return json_decode($raw, true, 16, JSON_THROW_ON_ERROR);
}

function glpichat_desktop_string(array $input, string $key, int $maxBytes = 4000): string
{
    if (!isset($input[$key]) || !is_string($input[$key]) || strlen($input[$key]) > $maxBytes) {
        glpichat_desktop_fail('invalid_request', 'Parâmetro inválido: ' . $key . '.', 400);
    }
    return $input[$key];
}

function glpichat_desktop_bearer(Request $request): string
{
    $value = (string) $request->headers->get('Authorization', '');
    if (preg_match('/\ABearer ([a-f0-9]{64})\z/D', $value, $matches) !== 1) {
        glpichat_desktop_fail('invalid_credential', 'Conecte sua conta novamente.', 401);
    }
    return $matches[1];
}

function glpichat_desktop_quote(string $value): string
{
    global $DB;
    return "'" . $DB->escape($value) . "'";
}

/** Database exceptions are converted to a non-sensitive error by controller. */
function glpichat_desktop_db_rows(string $sql): array
{
    global $DB;
    $result = $DB->doQuery($sql);
    if ($result === false || $result === true) {
        throw new RuntimeException('Desktop select failed.');
    }
    $rows = [];
    while ($row = $DB->fetchAssoc($result)) {
        $rows[] = $row;
    }
    if (method_exists($result, 'free')) {
        $result->free();
    }
    return $rows;
}

/**
 * Own one GLPI transaction boundary using its public API only.
 * GLPI11 returns void and handles nested boundaries with savepoints. Releasing
 * a savepoint does not commit its caller's transaction. Callers that perform
 * post-commit side effects must own the outer boundary, as the desktop HTTP
 * entrypoints do; this helper never commits or rolls back a caller's boundary.
 */
function glpichat_desktop_transaction(callable $action): mixed
{
    global $DB;
    $DB->beginTransaction();
    try {
        $result = $action();
        $DB->commit();
        return $result;
    } catch (Throwable $error) {
        try {
            $DB->rollBack();
        } catch (Throwable $rollbackError) {
            error_log('glpichat desktop: rollback failed; request terminated.');
        }
        throw $error;
    }
}
