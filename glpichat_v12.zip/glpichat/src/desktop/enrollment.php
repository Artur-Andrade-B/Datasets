<?php

declare(strict_types=1);

/** Administrator-issued, one-use enrollment; no client-provided actor is trusted. */
const GLPICHAT_DESKTOP_GRANTS_TABLE = 'glpi_plugin_glpichat_desktopgrants';
const GLPICHAT_DESKTOP_REGISTRATIONS_TABLE = 'glpi_plugin_glpichat_desktopregistrations';

function glpichat_desktop_managed_schema(): bool
{
    return function_exists('glpichat_desktop_config')
        && (string) glpichat_desktop_config('desktop_schema_version') === '2';
}

function glpichat_desktop_require_managed_schema(): void
{
    glpichat_desktop_require_schema();
    if (!glpichat_desktop_managed_schema()) {
        glpichat_desktop_fail('schema_unavailable', 'Conclua a atualização para habilitar a conexão automática.', 503);
    }
}

/** A SID/computer match constrains delivery; possession of the grant is the proof. */
function glpichat_desktop_delivery_identity(string $sid, string $computer): array
{
    $computer = strtoupper(trim($computer));
    if (preg_match('/^S-1-5-21-(?:[0-9]{1,10}-){3}[0-9]{1,10}$/D', $sid) !== 1
        || preg_match('/^[A-Z0-9][A-Z0-9_-]{0,62}$/D', $computer) !== 1) {
        glpichat_desktop_fail('invalid_enrollment', 'Identificação de provisionamento inválida.', 400);
    }
    foreach (array_slice(explode('-', $sid), 4) as $component) {
        if ((float) $component > 4294967295) {
            glpichat_desktop_fail('invalid_enrollment', 'Identificação de provisionamento inválida.', 400);
        }
    }
    return [$sid, $computer];
}

function glpichat_desktop_enrollment_string(array $input, string $key, int $limit): string
{
    if (!isset($input[$key]) || !is_string($input[$key]) || strlen($input[$key]) > $limit) {
        glpichat_desktop_fail('invalid_enrollment', 'Dados de provisionamento inválidos.', 400);
    }
    return $input[$key];
}

/** Administrative service only. The CLI verifies its operator and AD mapping. */
function glpichat_desktop_grant_issue(array $input, int $ttlSeconds = 604800): array
{
    glpichat_desktop_require_managed_schema();
    foreach (['users_id', 'profiles_id', 'entities_id'] as $key) {
        if (!isset($input[$key]) || !is_int($input[$key])) {
            glpichat_desktop_fail('invalid_enrollment', 'Contexto GLPI inválido.', 400);
        }
    }
    if ($ttlSeconds < 60 || $ttlSeconds > 30 * 86400) {
        glpichat_desktop_fail('invalid_enrollment', 'A validade deve ser entre um minuto e trinta dias.', 400);
    }
    [$sid, $computer] = glpichat_desktop_delivery_identity(
        glpichat_desktop_enrollment_string($input, 'windows_sid', 184),
        glpichat_desktop_enrollment_string($input, 'computer_name', 63));
    return glpichat_desktop_transaction(static function () use ($input, $ttlSeconds, $sid, $computer): array {
        $facts = glpichat_desktop_auth_user($input['users_id'], $input['profiles_id'], $input['entities_id'], true);
        if (array_key_exists('expected_identity', $input)) {
            $expected = $input['expected_identity'];
            if (!is_array($expected)) {
                glpichat_desktop_fail('invalid_enrollment', 'Referência de identidade inválida.', 400);
            }
            foreach (['auths_id', 'sync_anchor', 'user_incarnation', 'auth_source_fingerprint'] as $field) {
                if (!isset($expected[$field]) || $expected[$field] !== $facts[$field]) {
                    glpichat_desktop_fail('enrollment_identity_changed', 'A conta mudou durante o provisionamento. Verifique novamente o vínculo AD.', 409);
                }
            }
        }
        $id = bin2hex(random_bytes(16));
        $secret = bin2hex(random_bytes(32));
        $now = glpichat_desktop_now();
        $expires = gmdate('Y-m-d H:i:s', glpichat_desktop_auth_timestamp($now) + $ttlSeconds);
        global $DB;
        if (!$DB->insert(GLPICHAT_DESKTOP_GRANTS_TABLE, [
            'grant_id' => $id, 'secret_hash' => glpichat_desktop_auth_hash('enrollment-grant', $secret),
            'status' => 'issued', 'users_id' => $facts['user_id'], 'profiles_id' => $facts['profile_id'],
            'entities_id' => $facts['entity_id'], 'auths_id' => $facts['auths_id'],
            'sync_anchor' => $facts['sync_anchor'], 'user_incarnation' => $facts['user_incarnation'],
            'auth_source_fingerprint' => $facts['auth_source_fingerprint'], 'windows_sid' => $sid,
            'computer_name' => $computer, 'created_at' => $now, 'expires_at' => $expires,
        ])) {
            glpichat_desktop_fail('storage_unavailable', 'Não foi possível emitir o provisionamento.', 503);
        }
        return ['grant_id' => $id, 'grant_secret' => $secret, 'windows_sid' => $sid, 'computer_name' => $computer,
            'expires_at' => gmdate('Y-m-d\TH:i:s\Z', glpichat_desktop_auth_timestamp($expires)),
            'user' => ['id' => $facts['user_id'], 'subject_id' => glpichat_desktop_subject_id($facts)],
            'profile_id' => $facts['profile_id'], 'entity_id' => $facts['entity_id']];
    });
}

/** Administrative revocation also leaves consumed grants unusable for replay. */
function glpichat_desktop_grant_revoke(string $grantId): void
{
    glpichat_desktop_require_managed_schema();
    if (!glpichat_desktop_auth_hex($grantId, 32)) {
        glpichat_desktop_fail('invalid_enrollment', 'Identificação de provisionamento inválida.', 400);
    }
    glpichat_desktop_transaction(static function () use ($grantId): void {
        $where = ' WHERE grant_id=' . glpichat_desktop_quote($grantId) . ' LIMIT 1';
        $registration = glpichat_desktop_auth_one('SELECT * FROM ' . GLPICHAT_DESKTOP_REGISTRATIONS_TABLE . $where);
        if ($registration) {
            [$device, $registration, $grant] = glpichat_desktop_managed_lock($grantId);
        } else {
            $grant = glpichat_desktop_auth_one('SELECT * FROM ' . GLPICHAT_DESKTOP_GRANTS_TABLE . $where . ' FOR UPDATE');
            // An enrollment that committed while waiting for the grant must be
            // retried in the standard device-first order; never revoke half of it.
            if ($grant && $grant['status'] === 'consumed') {
                glpichat_desktop_fail('enrollment_busy', 'Tente novamente para revogar a instalação recém-registrada.', 503);
            }
        }
        if (!$grant) {
            glpichat_desktop_fail('enrollment_unavailable', 'Provisionamento não encontrado.', 404);
        }
        global $DB;
        $values = ['status' => 'revoked', 'revoked_at' => glpichat_desktop_now()];
        if ((!empty($device) && !$DB->update(GLPICHAT_DESKTOP_DEVICES_TABLE, $values, ['id' => (int) $device['id']]))
            || !$DB->update(GLPICHAT_DESKTOP_GRANTS_TABLE, $values, ['grant_id' => $grantId])) {
            glpichat_desktop_fail('storage_unavailable', 'Não foi possível revogar o provisionamento.', 503);
        }
    });
}

/** One indexed extra lookup; no queries against new tables before schema2. */
function glpichat_desktop_registration_metadata(int $deviceId): array
{
    if ($deviceId < 1 || !glpichat_desktop_managed_schema()) {
        return [];
    }
    return glpichat_desktop_auth_one('SELECT r.*,g.status AS grant_status,g.windows_sid,g.computer_name FROM '
        . GLPICHAT_DESKTOP_REGISTRATIONS_TABLE . ' r LEFT JOIN ' . GLPICHAT_DESKTOP_GRANTS_TABLE
        . ' g ON g.grant_id=r.grant_id WHERE r.devices_id=' . $deviceId . ' LIMIT 1');
}

function glpichat_desktop_managed_device_active(array $device, array $registration): void
{
    if (($device['status'] ?? '') !== 'completed' || !empty($device['revoked_at'])
        || ($registration['grant_status'] ?? '') !== 'consumed') {
        glpichat_desktop_fail('device_revoked', 'Esta instalação foi revogada. Solicite novo provisionamento ao suporte.', 403);
    }
}

function glpichat_desktop_managed_facts(array $binding, bool $lock): array
{
    try {
        $facts = glpichat_desktop_auth_user((int) $binding['users_id'], (int) $binding['profiles_id'], (int) $binding['entities_id'], $lock);
    } catch (GlpichatDesktopException $error) {
        if ($error->errorCode !== 'credential_invalid') {
            throw $error;
        }
        glpichat_desktop_fail('authorization_denied', 'A conta ou seu contexto GLPI não está autorizado. Contate o suporte.', 403);
    }
    if (!glpichat_desktop_auth_binding_matches($binding, $facts)) {
        glpichat_desktop_fail('authorization_denied', 'A identidade da conta mudou. Solicite novo provisionamento ao suporte.', 403);
    }
    return $facts;
}

/** Lock order for existing registrations: device, registration, grant, authority. */
function glpichat_desktop_managed_lock(string $grantId): array
{
    $where = ' WHERE grant_id=' . glpichat_desktop_quote($grantId) . ' LIMIT 1';
    $registration = glpichat_desktop_auth_one('SELECT * FROM ' . GLPICHAT_DESKTOP_REGISTRATIONS_TABLE . $where);
    if (!$registration) {
        glpichat_desktop_fail('enrollment_unavailable', 'Provisionamento indisponível.', 401);
    }
    $device = glpichat_desktop_auth_one('SELECT * FROM ' . GLPICHAT_DESKTOP_DEVICES_TABLE
        . ' WHERE id=' . (int) $registration['devices_id'] . ' LIMIT 1 FOR UPDATE');
    $registration = glpichat_desktop_auth_one('SELECT * FROM ' . GLPICHAT_DESKTOP_REGISTRATIONS_TABLE . $where . ' FOR UPDATE');
    $grant = glpichat_desktop_auth_one('SELECT * FROM ' . GLPICHAT_DESKTOP_GRANTS_TABLE . $where . ' FOR UPDATE');
    if (!$device || !$registration || !$grant || (int) $registration['devices_id'] !== (int) $device['id']) {
        glpichat_desktop_fail('enrollment_unavailable', 'Provisionamento indisponível.', 401);
    }
    $registration += ['grant_status' => $grant['status'], 'windows_sid' => $grant['windows_sid'], 'computer_name' => $grant['computer_name']];
    return [$device, $registration, $grant];
}

function glpichat_desktop_managed_input(array $input, bool $enroll): array
{
    $values = [];
    foreach (['grant_id' => 32, 'device_id' => 36, 'refresh_secret' => 64, 'access_token' => 64]
        + ($enroll ? ['grant_secret' => 64, 'windows_sid' => 184, 'computer_name' => 63] : []) as $key => $limit) {
        $values[$key] = glpichat_desktop_enrollment_string($input, $key, $limit);
    }
    if (!glpichat_desktop_auth_hex($values['grant_id'], 32)
        || preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/D', $values['device_id']) !== 1
        || !glpichat_desktop_auth_hex($values['refresh_secret']) || !glpichat_desktop_auth_hex($values['access_token'])
        || hash_equals($values['refresh_secret'], $values['access_token'])
        || ($enroll && (!glpichat_desktop_auth_hex($values['grant_secret'])
            || hash_equals($values['grant_secret'], $values['refresh_secret']) || hash_equals($values['grant_secret'], $values['access_token'])))) {
        glpichat_desktop_fail('invalid_enrollment', 'Dados de provisionamento inválidos.', 400);
    }
    if ($enroll) {
        [$values['windows_sid'], $values['computer_name']] = glpichat_desktop_delivery_identity($values['windows_sid'], $values['computer_name']);
    }
    return $values;
}

function glpichat_desktop_enroll(array $input): array
{
    glpichat_desktop_auth_available();
    glpichat_desktop_require_managed_schema();
    $input = glpichat_desktop_managed_input($input, true);
    return glpichat_desktop_transaction(static function () use ($input): array {
        $where = ' WHERE grant_id=' . glpichat_desktop_quote($input['grant_id']) . ' LIMIT 1';
        $grant = glpichat_desktop_auth_one('SELECT * FROM ' . GLPICHAT_DESKTOP_GRANTS_TABLE . $where);
        $secretHash = glpichat_desktop_auth_hash('enrollment-grant', $input['grant_secret']);
        if (!$grant || !hash_equals((string) $grant['secret_hash'], $secretHash)
            || !hash_equals((string) $grant['windows_sid'], $input['windows_sid'])
            || !hash_equals((string) $grant['computer_name'], $input['computer_name'])) {
            glpichat_desktop_fail('enrollment_unavailable', 'Provisionamento indisponível para esta conta ou computador.', 401);
        }
        $tokenHash = glpichat_desktop_auth_hash('bearer', $input['access_token']);
        $refreshHash = glpichat_desktop_auth_hash('managed-refresh', $input['refresh_secret']);
        if ($grant['status'] === 'consumed') {
            [$device, $registration, $grant] = glpichat_desktop_managed_lock($input['grant_id']);
            glpichat_desktop_managed_device_active($device, $registration);
            if (!hash_equals((string) $device['device_id'], $input['device_id'])
                || !hash_equals((string) $registration['enrollment_access_hash'], $tokenHash)
                || !hash_equals((string) $registration['refresh_secret_hash'], $refreshHash)) {
                glpichat_desktop_fail('enrollment_unavailable', 'O provisionamento já foi utilizado.', 401);
            }
            if (!hash_equals((string) $device['token_hash'], $tokenHash)) {
                glpichat_desktop_fail('enrollment_consumed', 'A instalação já renovou sua credencial. Retome a renovação.', 409);
            }
            if ($registration['refresh_expires_at'] <= glpichat_desktop_now()) {
                glpichat_desktop_fail('refresh_expired', 'O provisionamento precisa ser renovado pelo suporte.', 401);
            }
            $facts = glpichat_desktop_managed_facts($device, true);
            return glpichat_desktop_identity(glpichat_desktop_auth_actor($device, $facts) + ['managed_registration' => $registration]);
        }
        $grant = glpichat_desktop_auth_one('SELECT * FROM ' . GLPICHAT_DESKTOP_GRANTS_TABLE . $where . ' FOR UPDATE');
        if ($grant['status'] === 'revoked' || !empty($grant['revoked_at'])) {
            glpichat_desktop_fail('device_revoked', 'Este provisionamento foi revogado. Contate o suporte.', 403);
        }
        if ($grant['status'] !== 'issued') {
            glpichat_desktop_fail('enrollment_busy', 'Aguarde alguns segundos para retomar a conexão automática.', 503);
        }
        $now = glpichat_desktop_now();
        if ($grant['expires_at'] <= $now) {
            glpichat_desktop_fail('grant_expired', 'O provisionamento expirou. Solicite a atualização ao suporte.', 410);
        }
        $facts = glpichat_desktop_managed_facts($grant, true);
        $device = [
            'pairing_id' => bin2hex(random_bytes(16)), 'poll_secret_hash' => glpichat_desktop_auth_hash('poll-secret', bin2hex(random_bytes(32))),
            'token_hash' => $tokenHash, 'device_id' => $input['device_id'], 'device_name' => $grant['computer_name'],
            'windows_login' => $facts['login'], 'request_ip_hash' => glpichat_desktop_auth_hash('pairing-ip', 'managed'),
            'user_code' => '', 'status' => 'completed', 'created_at' => $now, 'pairing_expires_at' => $now, 'approved_at' => $now,
            'token_expires_at' => gmdate('Y-m-d H:i:s', glpichat_desktop_auth_timestamp($now) + 90 * 86400), 'revoked_at' => null,
        ];
        foreach (['users_id', 'profiles_id', 'entities_id', 'auths_id', 'sync_anchor', 'user_incarnation', 'auth_source_fingerprint'] as $field) {
            $device[$field] = $grant[$field];
        }
        global $DB;
        if (!$DB->insert(GLPICHAT_DESKTOP_DEVICES_TABLE, $device)) {
            glpichat_desktop_fail('storage_unavailable', 'Não foi possível registrar a instalação.', 503);
        }
        $device['id'] = (int) $DB->insertId();
        $registration = [
            'devices_id' => $device['id'], 'grant_id' => $grant['grant_id'], 'refresh_secret_hash' => $refreshHash,
            'refresh_expires_at' => gmdate('Y-m-d H:i:s', glpichat_desktop_auth_timestamp($now) + 365 * 86400),
            'enrollment_access_hash' => $tokenHash, 'created_at' => $now,
        ];
        if (!$DB->insert(GLPICHAT_DESKTOP_REGISTRATIONS_TABLE, $registration)
            || !$DB->update(GLPICHAT_DESKTOP_GRANTS_TABLE, ['status' => 'consumed', 'consumed_at' => $now],
                ['id' => (int) $grant['id'], 'status' => 'issued']) || $DB->affectedRows() !== 1) {
            glpichat_desktop_fail('storage_unavailable', 'Não foi possível concluir o registro.', 503);
        }
        $registration += ['grant_status' => 'consumed', 'windows_sid' => $grant['windows_sid'], 'computer_name' => $grant['computer_name']];
        return glpichat_desktop_identity(glpichat_desktop_auth_actor($device, $facts) + ['managed_registration' => $registration]);
    });
}

function glpichat_desktop_renew(array $input): array
{
    glpichat_desktop_auth_available();
    glpichat_desktop_require_managed_schema();
    $input = glpichat_desktop_managed_input($input, false);
    return glpichat_desktop_transaction(static function () use ($input): array {
        [$device, $registration] = glpichat_desktop_managed_lock($input['grant_id']);
        if (!hash_equals((string) $device['device_id'], $input['device_id'])
            || !hash_equals((string) $registration['refresh_secret_hash'], glpichat_desktop_auth_hash('managed-refresh', $input['refresh_secret']))) {
            glpichat_desktop_fail('refresh_invalid', 'A autorização de renovação não é válida.', 401);
        }
        glpichat_desktop_managed_device_active($device, $registration);
        $now = glpichat_desktop_now();
        if ($registration['refresh_expires_at'] <= $now) {
            glpichat_desktop_fail('refresh_expired', 'O prazo de recuperação expirou. Solicite novo provisionamento ao suporte.', 401);
        }
        $facts = glpichat_desktop_managed_facts($device, true);
        $tokenHash = glpichat_desktop_auth_hash('bearer', $input['access_token']);
        if (!hash_equals((string) $device['token_hash'], $tokenHash)) {
            $device['token_hash'] = $tokenHash;
            $device['token_expires_at'] = gmdate('Y-m-d H:i:s', glpichat_desktop_auth_timestamp($now) + 90 * 86400);
            $registration['refresh_expires_at'] = gmdate('Y-m-d H:i:s', glpichat_desktop_auth_timestamp($now) + 365 * 86400);
            global $DB;
            if (!$DB->update(GLPICHAT_DESKTOP_DEVICES_TABLE,
                ['token_hash' => $tokenHash, 'token_expires_at' => $device['token_expires_at']], ['id' => (int) $device['id']])
                || !$DB->update(GLPICHAT_DESKTOP_REGISTRATIONS_TABLE,
                    ['refresh_expires_at' => $registration['refresh_expires_at'], 'rotated_at' => $now], ['devices_id' => (int) $device['id']])) {
                glpichat_desktop_fail('storage_unavailable', 'Não foi possível renovar a autorização.', 503);
            }
        }
        return glpichat_desktop_identity(glpichat_desktop_auth_actor($device, $facts) + ['managed_registration' => $registration]);
    });
}
