<?php

declare(strict_types=1);

/**
 * Return the structural contract inherited by the 1.0.6 foundation.
 *
 * This deliberately describes only objects that already belong to the working
 * 1.0.5 schema. It is an inspection manifest, not a migration definition, and
 * must never be used to create or repair objects during an ordinary request.
 *
 * @return array{
 *     tables:list<string>,
 *     columns:array<string, list<string>>,
 *     indexes:array<string, array<string, array{columns:list<string>, unique:bool}>>
 * }
 */
function glpichat_foundation_schema_contract(): array
{
    return [
        'tables' => [
            'glpi_plugin_glpichat_rooms',
            'glpi_plugin_glpichat_participants',
            'glpi_plugin_glpichat_messages',
            'glpi_plugin_glpichat_events',
            'glpi_plugin_glpichat_invites',
            'glpi_plugin_glpichat_readstates',
            'glpi_plugin_glpichat_auditlogs',
        ],
        'columns' => [
            'glpi_plugin_glpichat_participants' => [
                'last_activity',
                'last_seen',
                'is_typing_until',
                'last_send_at',
            ],
        ],
        'indexes' => [
            'glpi_plugin_glpichat_rooms' => [
                'unicity' => [
                    'columns' => ['tickets_id', 'room_type'],
                    'unique' => true,
                ],
            ],
            'glpi_plugin_glpichat_participants' => [
                'participants_room_user' => [
                    'columns' => ['users_id', 'rooms_id'],
                    'unique' => false,
                ],
                'participants_session' => [
                    'columns' => ['session_token_hash'],
                    'unique' => false,
                ],
                'idx_rooms_typing' => [
                    'columns' => ['rooms_id', 'left_at', 'is_typing_until'],
                    'unique' => false,
                ],
                'idx_expire_inactive' => [
                    'columns' => ['left_at', 'participant_type', 'last_activity'],
                    'unique' => false,
                ],
            ],
            'glpi_plugin_glpichat_messages' => [
                'messages_room_id' => [
                    'columns' => ['rooms_id', 'id'],
                    'unique' => false,
                ],
                'messages_ticket_id' => [
                    'columns' => ['tickets_id', 'id'],
                    'unique' => false,
                ],
                'messages_participant_id' => [
                    'columns' => ['participants_id', 'id'],
                    'unique' => false,
                ],
                'idx_messages_document' => [
                    'columns' => ['documents_id'],
                    'unique' => false,
                ],
            ],
            'glpi_plugin_glpichat_events' => [
                'events_room_id' => [
                    'columns' => ['rooms_id', 'id'],
                    'unique' => false,
                ],
                'events_ticket_id' => [
                    'columns' => ['tickets_id', 'id'],
                    'unique' => false,
                ],
                'idx_events_date' => [
                    'columns' => ['date_creation'],
                    'unique' => false,
                ],
                'idx_events_room_date' => [
                    'columns' => ['rooms_id', 'date_creation'],
                    'unique' => false,
                ],
            ],
            'glpi_plugin_glpichat_invites' => [
                'token_hash' => [
                    'columns' => ['token_hash'],
                    'unique' => true,
                ],
                'invites_expires_at' => [
                    'columns' => ['expires_at'],
                    'unique' => false,
                ],
                'idx_invites_ticket' => [
                    'columns' => ['tickets_id'],
                    'unique' => false,
                ],
            ],
            'glpi_plugin_glpichat_readstates' => [
                'room_participant' => [
                    'columns' => ['rooms_id', 'participants_id'],
                    'unique' => true,
                ],
                'readstates_participant_room' => [
                    'columns' => ['participants_id', 'rooms_id'],
                    'unique' => false,
                ],
            ],
            'glpi_plugin_glpichat_auditlogs' => [
                'audit_ticket_date' => [
                    'columns' => ['tickets_id', 'date_creation'],
                    'unique' => false,
                ],
            ],
        ],
    ];
}

/**
 * Read one deployed index shape without exposing row or environment data.
 *
 * @return array{columns:list<string>, unique:bool}|null
 */
function glpichat_foundation_live_index_shape(string $table, string $index): ?array
{
    global $DB;

    $result = $DB->doQuery(sprintf('SHOW INDEX FROM %s', $DB::quoteName($table)));
    if (!$result) {
        throw new RuntimeException('Unable to inspect the GLPI Chat schema.');
    }

    $columns = [];
    $non_unique = null;
    while ($row = $DB->fetchAssoc($result)) {
        if (($row['Key_name'] ?? null) !== $index) {
            continue;
        }

        $raw_sequence = $row['Seq_in_index'] ?? null;
        if (is_int($raw_sequence)) {
            $sequence = $raw_sequence;
        } elseif (is_string($raw_sequence) && preg_match('/\A[1-9][0-9]*\z/', $raw_sequence) === 1) {
            $sequence = (int) $raw_sequence;
        } else {
            return null;
        }

        $column = $row['Column_name'] ?? null;
        if ($sequence <= 0 || !is_string($column) || $column === '' || isset($columns[$sequence])) {
            return null;
        }

        $row_non_unique = match ($row['Non_unique'] ?? null) {
            0, '0' => 0,
            1, '1' => 1,
            default => null,
        };
        if ($row_non_unique === null || ($non_unique !== null && $non_unique !== $row_non_unique)) {
            return null;
        }

        $non_unique = $row_non_unique;
        $columns[$sequence] = $column;
    }

    if ($columns === [] || $non_unique === null) {
        return null;
    }

    ksort($columns, SORT_NUMERIC);
    if (array_keys($columns) !== range(1, count($columns))) {
        return null;
    }

    return [
        'columns' => array_values($columns),
        'unique' => $non_unique === 0,
    ];
}

function glpichat_foundation_expected_schema_version(): int
{
    if (!defined('GLPICHAT_FOUNDATION_SCHEMA_VERSION')) {
        throw new LogicException('GLPICHAT_FOUNDATION_SCHEMA_VERSION must be defined before schema health inspection.');
    }

    $expected_version = (int) constant('GLPICHAT_FOUNDATION_SCHEMA_VERSION');
    if ($expected_version < 1) {
        throw new LogicException('GLPICHAT_FOUNDATION_SCHEMA_VERSION must be a positive integer.');
    }

    return $expected_version;
}

/**
 * Normalize the persisted foundation marker without accepting PHP truthiness.
 *
 * A positive integer marks a schema that has completed foundation adoption.
 * A future positive marker remains compatible with this additive foundation so
 * an older package can inspect it without overwriting or rejecting it. Missing,
 * zero, malformed, negative, boolean, floating-point and compound values are
 * deliberately not compatible.
 *
 * @return array{compatible:bool, state:string, version:int|null}
 */
function glpichat_foundation_marker_status(mixed $raw_marker): array
{
    $expected_version = glpichat_foundation_expected_schema_version();

    if ($raw_marker === null || $raw_marker === false || $raw_marker === '') {
        return [
            'compatible' => false,
            'state' => 'missing',
            'version' => null,
        ];
    }

    $normalized = null;
    if (is_int($raw_marker) && $raw_marker >= 0) {
        $normalized = $raw_marker;
    } elseif (
        is_string($raw_marker)
        && preg_match('/\A(?:0|[1-9][0-9]*)\z/', $raw_marker) === 1
    ) {
        $candidate = filter_var(
            $raw_marker,
            FILTER_VALIDATE_INT,
            ['options' => ['min_range' => 0]]
        );
        if (is_int($candidate)) {
            $normalized = $candidate;
        }
    }

    if ($normalized === null) {
        return [
            'compatible' => false,
            'state' => 'invalid',
            'version' => null,
        ];
    }

    if ($normalized === 0) {
        return [
            'compatible' => false,
            'state' => 'outdated',
            'version' => 0,
        ];
    }

    $state = 'current';
    if ($normalized < $expected_version) {
        $state = 'previous';
    } elseif ($normalized > $expected_version) {
        $state = 'future';
    }

    return [
        'compatible' => true,
        'state' => $state,
        'version' => $normalized,
    ];
}

/**
 * Inspect the 1.0.6 foundation schema without mutating the database or config.
 *
 * Every dependency can be injected so the contract can be verified without a
 * GLPI database. In GLPI, omitted callbacks use the normal read-only schema and
 * Config APIs. Missing child objects are not queried when their table is absent.
 * A Config read failure is reduced to an opaque `unreadable` marker state; no
 * exception message or environment detail is returned.
 *
 * @param null|callable(string):bool $table_exists
 * @param null|callable(string, string):bool $field_exists
 * @param null|callable(string, string):(array{columns:list<string>, unique:bool}|null) $index_shape
 * @param null|callable(string):mixed $config_value
 * @return array{
 *     healthy:bool,
 *     structural_healthy:bool,
 *     structural_state:string,
 *     marker_compatible:bool,
 *     marker_state:string,
 *     marker_version:int|null,
 *     expected_marker_version:int,
 *     missing_tables:list<string>,
 *     missing_columns:list<string>,
 *     missing_indexes:list<string>,
 *     mismatched_indexes:list<string>,
 *     elapsed_ms:float
 * }
 */
function glpichat_foundation_schema_health(
    ?callable $table_exists = null,
    ?callable $field_exists = null,
    ?callable $index_shape = null,
    ?callable $config_value = null
): array {
    $started_at = hrtime(true);

    $table_exists ??= static function (string $table): bool {
        global $DB;
        return (bool) $DB->tableExists($table);
    };
    $field_exists ??= static function (string $table, string $field): bool {
        global $DB;
        return (bool) $DB->fieldExists($table, $field);
    };
    $index_shape ??= static fn (string $table, string $index): ?array =>
        glpichat_foundation_live_index_shape($table, $index);
    $config_value ??= static fn (string $key): mixed => Config::getConfigurationValue('plugin:glpichat', $key);

    $contract = glpichat_foundation_schema_contract();
    $missing_tables = [];
    $missing_columns = [];
    $missing_indexes = [];
    $mismatched_indexes = [];
    $present_tables = [];

    $structural_readable = true;
    try {
        foreach ($contract['tables'] as $table) {
            $present_tables[$table] = $table_exists($table);
            if (!$present_tables[$table]) {
                $missing_tables[] = $table;
            }
        }

        foreach ($contract['columns'] as $table => $columns) {
            if (!($present_tables[$table] ?? false)) {
                continue;
            }
            foreach ($columns as $column) {
                if (!$field_exists($table, $column)) {
                    $missing_columns[] = $table . '.' . $column;
                }
            }
        }

        foreach ($contract['indexes'] as $table => $indexes) {
            if (!($present_tables[$table] ?? false)) {
                continue;
            }
            foreach ($indexes as $index => $expected_shape) {
                $actual_shape = $index_shape($table, $index);
                if ($actual_shape === null) {
                    $missing_indexes[] = $table . '.' . $index;
                    continue;
                }
                if ($actual_shape !== $expected_shape) {
                    $mismatched_indexes[] = $table . '.' . $index;
                }
            }
        }
    } catch (Throwable $e) {
        $structural_readable = false;
        $missing_tables = [];
        $missing_columns = [];
        $missing_indexes = [];
        $mismatched_indexes = [];
    }

    // Validate the code-owned constant before invoking the injected Config
    // reader, so a LogicException raised by that reader is handled like every
    // other opaque Config failure rather than escaping with private detail.
    $expected_marker_version = glpichat_foundation_expected_schema_version();
    try {
        $raw_marker = $config_value('foundation_schema_version');
        $marker = glpichat_foundation_marker_status($raw_marker);
    } catch (Throwable $e) {
        $marker = [
            'compatible' => false,
            'state' => 'unreadable',
            'version' => null,
        ];
    }

    $structural_healthy = $structural_readable
        && $missing_tables === []
        && $missing_columns === []
        && $missing_indexes === []
        && $mismatched_indexes === [];
    $structural_state = !$structural_readable
        ? 'unreadable'
        : ($structural_healthy ? 'healthy' : 'incomplete');
    $marker_compatible = (bool) $marker['compatible'];

    return [
        'healthy' => $structural_healthy && $marker_compatible,
        'structural_healthy' => $structural_healthy,
        'structural_state' => $structural_state,
        'marker_compatible' => $marker_compatible,
        'marker_state' => (string) $marker['state'],
        'marker_version' => is_int($marker['version']) ? $marker['version'] : null,
        'expected_marker_version' => $expected_marker_version,
        'missing_tables' => $missing_tables,
        'missing_columns' => $missing_columns,
        'missing_indexes' => $missing_indexes,
        'mismatched_indexes' => $mismatched_indexes,
        'elapsed_ms' => max(0.0, round((hrtime(true) - $started_at) / 1_000_000, 3)),
    ];
}

/**
 * Refuse to commit the foundation marker when deployed structural
 * postconditions are incomplete or could not be inspected.
 *
 * @param array<string, mixed> $health
 */
function glpichat_foundation_assert_structural_postconditions(array $health): void
{
    if (($health['structural_healthy'] ?? false) !== true) {
        throw new RuntimeException('GLPI Chat foundation structural postconditions failed.');
    }
}
