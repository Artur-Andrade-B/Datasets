<?php

declare(strict_types=1);

require dirname(__DIR__, 2) . '/bootstrap/unit.php';
require_once dirname(__DIR__, 3) . '/src/domain/ActorContext.php';

if (!function_exists('glpichat_current_user_id')) {
    function glpichat_current_user_id(): int
    {
        return (int) ($GLOBALS['glpichat_test_current_user_id'] ?? 0);
    }
}

require_once dirname(__DIR__, 3) . '/src/domain/browser_actor.php';

$enabled_values = [1, '1'];
foreach ($enabled_values as $enabled_value) {
    glpichat_unit_assert_same(
        true,
        glpichat_public_authorization_shadow_value_enabled($enabled_value),
        'Only the exact integer/string value 1 enables shadow observation'
    );
}

$disabled_values = [null, '', 0, '0', false, true, 2, '2', -1, '-1', '01', 'true', [], new stdClass()];
foreach ($disabled_values as $disabled_value) {
    glpichat_unit_assert_same(
        false,
        glpichat_public_authorization_shadow_value_enabled($disabled_value),
        'Malformed or non-canonical shadow flag fails closed'
    );
}
glpichat_unit_pass('Public authorization shadow flag uses strict fail-closed parsing');

glpichat_unit_assert_same_array([], glpichat_normalize_session_ids(null, true), 'Non-array entity session state normalizes to empty');
glpichat_unit_assert_same_array(
    [0, 2, 7],
    glpichat_normalize_session_ids(['7', 2, '2', 0, '0', -1, 'bad', 3.5], true),
    'Entity session ids accept canonical numeric strings, keep zero, deduplicate and sort'
);
glpichat_unit_assert_same_array(
    [2, 7],
    glpichat_normalize_session_ids(['7', 2, '2', 0, '0', -1, 'bad', 3.5], false),
    'Group session ids exclude zero/non-positive/junk values, deduplicate and sort'
);
glpichat_unit_pass('Browser session id normalization is bounded and deterministic');

foreach ([true, 6.0, '06', '+6', ' 6', '6junk', str_repeat('9', 40), [], new stdClass()] as $malformed_id) {
    glpichat_unit_assert_same(
        null,
        glpichat_normalize_session_id($malformed_id, false),
        'Session scalar IDs reject implicit casts and non-canonical encodings'
    );
}
foreach ([false, 0, '0'] as $false_value) {
    glpichat_unit_assert_same(false, glpichat_normalize_session_bool($false_value), 'Canonical false session value is accepted');
}
foreach ([true, 1, '1'] as $true_value) {
    glpichat_unit_assert_same(true, glpichat_normalize_session_bool($true_value), 'Canonical true session value is accepted');
}
foreach ([null, '', 'false', 'true', 2, '2', 0.0, 1.0, [], new stdClass()] as $malformed_bool) {
    glpichat_unit_assert_same(
        null,
        glpichat_normalize_session_bool($malformed_bool),
        'Recursive session state rejects truthy casts and malformed encodings'
    );
}
glpichat_unit_pass('Browser actor scalar capture is strict and fail-closed');

$GLOBALS['glpichat_test_current_user_id'] = 42;
$_SESSION = [
    'glpiactiveprofile' => ['id' => '6', 'name' => 'must-not-be-captured'],
    'glpiactive_entity' => '7',
    'glpiactive_entity_recursive' => 1,
    'glpiactiveentities' => ['7', 2, 2, '0', 'junk'],
    'glpigroups' => ['9', 3, 9, 0, 'junk'],
    'glpiname' => 'private-user-name',
    'glpicsrftokens' => ['secret-token'],
];

$actor = glpichat_capture_browser_actor_context(true, false);
glpichat_unit_assert_same(42, $actor->userId, 'Browser capture stores only the numeric GLPI user id');
glpichat_unit_assert_same(6, $actor->profileId, 'Browser capture stores the active numeric profile id');
glpichat_unit_assert_same(7, $actor->entityId, 'Browser capture stores the active entity id');
glpichat_unit_assert_same(true, $actor->isRecursive, 'Browser capture stores the recursive-scope flag');
glpichat_unit_assert_same_array([0, 2, 7], $actor->entityIds, 'Browser capture snapshots normalized accessible entities');
glpichat_unit_assert_same_array([3, 9], $actor->groupIds, 'Browser capture snapshots normalized groups');
glpichat_unit_assert_same(true, $actor->canReadPublic, 'Browser capture receives the already-computed public READ fact');
glpichat_unit_assert_same(false, $actor->canCreatePublic, 'Browser capture receives the already-computed public CREATE fact');

$_SESSION['glpiactiveprofile']['id'] = 99;
$_SESSION['glpiactive_entity'] = 88;
$_SESSION['glpiactiveentities'][] = 88;
$_SESSION['glpigroups'][] = 77;
$GLOBALS['glpichat_test_current_user_id'] = 101;

glpichat_unit_assert_same(42, $actor->userId, 'Captured actor is isolated from later user-session mutation');
glpichat_unit_assert_same(6, $actor->profileId, 'Captured actor is isolated from later profile mutation');
glpichat_unit_assert_same(7, $actor->entityId, 'Captured actor is isolated from later active-entity mutation');
glpichat_unit_assert_same_array([0, 2, 7], $actor->entityIds, 'Captured actor is isolated from later entity-list mutation');
glpichat_unit_assert_same_array([3, 9], $actor->groupIds, 'Captured actor is isolated from later group-list mutation');
glpichat_unit_pass('Browser actor capture is an immutable request-local snapshot');

$serialized_actor = json_encode($actor, JSON_THROW_ON_ERROR);
foreach (['private-user-name', 'secret-token', 'glpiname', 'glpicsrftokens'] as $forbidden) {
    if (str_contains($serialized_actor, $forbidden)) {
        glpichat_unit_fail('ActorContext captured forbidden mutable/secret session state: ' . $forbidden);
    }
}
glpichat_unit_pass('Browser capture excludes names, tokens and mutable Session objects');

$GLOBALS['glpichat_test_current_user_id'] = 42;
$_SESSION = [
    'glpiactiveprofile' => [],
    'glpiactive_entity' => 0,
    'glpiactive_entity_recursive' => false,
    'glpiactiveentities' => [0],
    'glpigroups' => [],
];
try {
    glpichat_capture_browser_actor_context(true, true);
    glpichat_unit_fail('Browser capture without a valid active profile must fail closed.');
} catch (InvalidArgumentException $error) {
    glpichat_unit_pass('Browser capture without a valid active profile fails closed');
}

$expect_capture_failure = static function (array $session, string $message): void {
    $_SESSION = $session + [
        'glpiactiveprofile' => ['id' => 6],
        'glpiactive_entity' => 0,
        'glpiactive_entity_recursive' => false,
        'glpiactiveentities' => [0],
        'glpigroups' => [],
    ];

    try {
        glpichat_capture_browser_actor_context(true, true);
        glpichat_unit_fail($message);
    } catch (InvalidArgumentException $error) {
        // Expected: malformed authorization scope must never be coerced.
    }
};

foreach (['6junk', true, 6.0, '06', str_repeat('9', 40)] as $bad_profile_id) {
    $expect_capture_failure(
        ['glpiactiveprofile' => ['id' => $bad_profile_id]],
        'Browser capture must reject malformed profile IDs.'
    );
}
foreach (['7junk', true, 7.0, '07', str_repeat('9', 40)] as $bad_entity_id) {
    $expect_capture_failure(
        ['glpiactive_entity' => $bad_entity_id],
        'Browser capture must reject malformed active-entity IDs.'
    );
}
foreach (['false', 'true', 0.0, 1.0, 2, '2'] as $bad_recursive_value) {
    $expect_capture_failure(
        ['glpiactive_entity_recursive' => $bad_recursive_value],
        'Browser capture must reject malformed recursive-entity state.'
    );
}
glpichat_unit_pass('Malformed browser authorization scope cannot be coerced into an actor');

$expect_capture_failure(
    ['glpiactive_entity_recursive' => null],
    'Browser capture must reject missing recursive-entity state.'
);
$expect_capture_failure(
    ['glpiactive_entity' => null],
    'Browser capture must reject missing active-entity state.'
);
$GLOBALS['glpichat_test_current_user_id'] = 0;
$expect_capture_failure([], 'Browser capture must reject an unauthenticated/missing user id.');
glpichat_unit_pass('Missing authenticated browser scope fails closed');

fwrite(STDOUT, "[PASS] Browser ActorContext unit tests completed\n");
