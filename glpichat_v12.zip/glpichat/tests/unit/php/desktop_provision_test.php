<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/desktop/provision.php';
final class GlpichatDesktopException extends RuntimeException {
    public function __construct(public string $errorCode) { parent::__construct($errorCode); }
}
$assertions = 0;
function provision_assert(bool $ok, string $message): void {
    global $assertions; ++$assertions;
    if (!$ok) { throw new RuntimeException($message); }
}
function provision_reject(callable $action, string $message): void {
    try { $action(); } catch (RuntimeException $e) { provision_assert(true, $message); return; }
    provision_assert(false, $message);
}
function glpichat_desktop_quote(string $s): string { return "'" . str_replace("'", "''", $s) . "'"; }
function glpichat_desktop_auth_hash(string $purpose, string $value): string { return hash('sha256', "glpichat-desktop-v1\0" . $purpose . "\0" . $value); }
require_once dirname(__DIR__, 3) . '/src/desktop/enrollment.php';
function glpichat_desktop_fail(string $code, string $message, int $status): never { throw new GlpichatDesktopException($code); }
$guid = '00112233-4455-6677-8899-aabbccddeeff';
$user = ['id' => 7, 'profiles_id' => 4, 'entities_id' => 1, 'sync_field' => $guid, 'date_creation' => '2020-01-01 00:00:00', 'authtype' => 3];
$userRows = [$user]; $profileRows = []; $allowed = ['4:1']; $queries = [];
function glpichat_desktop_db_rows(string $sql): array {
    global $userRows, $profileRows, $queries;
    $queries[] = $sql;
    if (str_starts_with($sql, 'SELECT * FROM glpi_users WHERE auths_id=3 AND name=')) { return $userRows; }
    if ($sql === 'SELECT profiles_id,entities_id,is_recursive FROM glpi_profiles_users WHERE users_id=7') { return $profileRows; }
    throw new LogicException('Unexpected query in provisioning fixture.');
}
function glpichat_desktop_auth_user(int $user, int $profile, int $entity): array {
    global $allowed;
    if ($user !== 7 || !in_array($profile . ':' . $entity, $allowed, true)) { throw new GlpichatDesktopException('credential_invalid'); }
    return ['user_id' => $user, 'profile_id' => $profile, 'entity_id' => $entity];
}
$source = ['id' => 3, 'sync_field' => 'objectGUID', 'date_creation' => '2019-01-01 00:00:00'];
$row = ['login' => '0012345', 'object_guid' => strtoupper($guid), 'windows_sid' => 'S-1-5-21-1-2-3-1001', 'computer_name' => 'PC-ONE', 'profiles_id' => '', 'entities_id' => ''];
provision_assert(glpichat_desktop_provision_user($row, $source)['id'] === 7, 'Canonical GUID comparison resolves a replicated account.');
provision_assert(str_contains($queries[0], "name='0012345'"), 'Login leading zeros are retained.');
provision_reject(fn() => glpichat_desktop_provision_user(array_replace($row, ['object_guid' => '11112233-4455-6677-8899-aabbccddeeff']), $source), 'Recycled login with another AD object is refused.');
$userRows = [$user, $user];
provision_reject(fn() => glpichat_desktop_provision_user($row, $source), 'Ambiguous matching GLPI users are refused.');
$userRows = [];
provision_reject(fn() => glpichat_desktop_provision_user($row, $source), 'Missing account is not auto-created.');
$userRows = [array_replace($user, ['sync_field' => 'anchor-X'])];
provision_assert(glpichat_desktop_provision_user($row + ['sync_value' => 'anchor-X'], ['id' => 3, 'sync_field' => 'customAnchor'])['id'] === 7, 'Existing configured directory synchronization attribute is supported.');
provision_reject(fn() => glpichat_desktop_provision_user($row + ['sync_value' => 'anchor-x'], ['id' => 3, 'sync_field' => 'customAnchor']), 'Configured synchronization anchor comparison preserves exact bytes.');
$userRows = [$user];
$_SESSION = ['glpiactive_entity' => 0, 'glpiactiveprofile' => ['id' => 99]];
$facts = glpichat_desktop_provision_context($user, null, null);
provision_assert($facts['profile_id'] === 4 && $facts['entity_id'] === 1, 'Default context comes from account settings, ignoring browser context.');
$allowed = ['4:1', '5:2'];
provision_assert(glpichat_desktop_provision_context($user, 5, 2)['entity_id'] === 2, 'Explicit authorized admin context overrides native defaults.');
provision_reject(fn() => glpichat_desktop_provision_context($user, 5, 0), 'Explicit unauthorized root entity is not substituted.');
$noDefault = array_replace($user, ['profiles_id' => 0]);
$profileRows = [['profiles_id' => 4, 'entities_id' => 1], ['profiles_id' => 5, 'entities_id' => 2]];
provision_reject(fn() => glpichat_desktop_provision_context($noDefault, null, null), 'Ambiguous contexts require an admin assignment.');
$profileRows = [$profileRows[0]];
provision_assert(glpichat_desktop_provision_context($noDefault, null, null)['profile_id'] === 4, 'Sole eligible context needs no explicit override.');
provision_assert(glpichat_desktop_provision_number('0', 'entity', true) === 0, 'Root entity zero is a valid explicit entity.');
foreach (['-1', '1.5', '2147483648', '00'] as $bad) { provision_reject(fn() => glpichat_desktop_provision_number($bad, 'id', true), 'Malformed IDs are refused.'); }
provision_reject(fn() => glpichat_desktop_provision_number('0', 'profile', false), 'Profile zero is invalid.');
provision_assert(glpichat_desktop_provision_assignments([$row], $source, null, null)[0]['entities_id'] === 1, 'Assignment binds expected account/context.');
$bound = glpichat_desktop_provision_assignments([$row], $source, null, null)[0]['expected_identity'];
provision_assert($bound['sync_anchor'] === glpichat_desktop_auth_hash('directory-anchor', $guid) && $bound['auths_id'] === 3,
    'Prevalidated AD identity is retained through issuance, not replaced with just a numeric user ID.');
provision_assert(glpichat_desktop_provision_assignments([array_replace($row, ['computer_name' => 'PC_ONE'])], $source, null, null)[0]['computer_name'] === 'PC_ONE', 'Windows underscore names use shared delivery validator.');
provision_reject(fn() => glpichat_desktop_provision_assignments([$row, $row], $source, null, null), 'Duplicate delivery destination cannot overwrite a grant.');
foreach (['../PC', 'PC/ONE', 'PC.ONE', '..'] as $computer) {
    provision_reject(fn() => glpichat_desktop_provision_assignments([array_replace($row, ['computer_name' => $computer])], $source, null, null), 'Path and domain-suffix computer names are refused.');
}
provision_reject(fn() => glpichat_desktop_provision_assignments([array_replace($row, ['windows_sid' => 'S-1-5-18'])], $source, null, null), 'SYSTEM is never provisioned as the chat user.');
$csv = tempnam(sys_get_temp_dir(), 'glpichat-provision-');
try {
    file_put_contents($csv, "\xEF\xBB\xBFlogin,object_guid,windows_sid,computer_name\r\n\"0012345\",$guid,S-1-5-21-1-2-3-1001,PC-ONE\r\n");
    $parsed = glpichat_desktop_provision_csv($csv);
    provision_assert(count($parsed) === 1 && $parsed[0]['login'] === '0012345', 'BOM/quoted CSV from Windows retains textual login.');
    file_put_contents($csv, "login,login,object_guid,windows_sid,computer_name\n");
    provision_reject(fn() => glpichat_desktop_provision_csv($csv), 'Duplicate column labels cannot replace identity data.');
    file_put_contents($csv, "login,object_guid,windows_sid,computer_name\nuser,missing\n");
    provision_reject(fn() => glpichat_desktop_provision_csv($csv), 'Incomplete CSV row fails before provisioning.');
} finally { unlink($csv); }
echo "PASS desktop provisioning: $assertions assertions; mapping/context/CSV fixtures, no directory or live GLPI database.\n";
