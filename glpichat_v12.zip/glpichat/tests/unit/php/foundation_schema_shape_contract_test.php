<?php

declare(strict_types=1);

/**
 * Exact inherited schema fingerprint for the invisible foundation release.
 * This complements the read-only health probe (which checks live presence) by
 * preventing a same-named table/index with silently changed source shape.
 */

require dirname(__DIR__, 2) . '/bootstrap/unit.php';
require_once dirname(__DIR__, 3) . '/src/db/setup_helpers.php';
require_once dirname(__DIR__, 3) . '/src/db/schema_health.php';

$plugin_root = dirname(__DIR__, 3);
$schema_queries = glpichat_schema_queries();

$expected_columns = [
    'glpi_plugin_glpichat_rooms' => [
        'id', 'tickets_id', 'room_type', 'date_creation', 'date_mod',
    ],
    'glpi_plugin_glpichat_participants' => [
        'id', 'rooms_id', 'users_id', 'guest_name', 'guest_email',
        'participant_type', 'session_token_hash', 'joined_at', 'left_at',
        'last_activity', 'last_seen', 'is_typing_until', 'last_send_at',
    ],
    'glpi_plugin_glpichat_messages' => [
        'id', 'rooms_id', 'tickets_id', 'participant_type', 'users_id',
        'participants_id', 'message_type', 'content', 'documents_id',
        'itilfollowups_id', 'date_creation',
    ],
    'glpi_plugin_glpichat_events' => [
        'id', 'rooms_id', 'tickets_id', 'event_type', 'actor_type', 'users_id',
        'participants_id', 'payload_json', 'date_creation',
    ],
    'glpi_plugin_glpichat_invites' => [
        'id', 'rooms_id', 'tickets_id', 'token_hash', 'created_by',
        'guest_name', 'guest_email', 'expires_at', 'accepted_at', 'revoked_at',
        'participants_id', 'date_creation',
    ],
    'glpi_plugin_glpichat_readstates' => [
        'id', 'rooms_id', 'participants_id', 'last_read_messages_id', 'date_mod',
    ],
    'glpi_plugin_glpichat_auditlogs' => [
        'id', 'rooms_id', 'tickets_id', 'action', 'actor_type', 'users_id',
        'participants_id', 'payload_json', 'date_creation',
    ],
];

glpichat_unit_assert_same_array(
    array_keys($expected_columns),
    array_keys($schema_queries),
    'Foundation defines exactly the seven inherited tables in stable order'
);

$actual_indexes = [];
foreach ($schema_queries as $table => $query) {
    preg_match_all('/^\s*`([a-z0-9_]+)`\s+[A-Z]/mi', $query, $column_matches);
    glpichat_unit_assert_same_array(
        $expected_columns[$table],
        $column_matches[1] ?? [],
        'Inherited column order and membership remain exact for ' . $table
    );

    preg_match('/PRIMARY\s+KEY\s*\(([^)]+)\)/i', $query, $primary_match);
    preg_match_all('/`([^`]+)`/', (string) ($primary_match[1] ?? ''), $primary_columns);
    glpichat_unit_assert_same_array(['id'], $primary_columns[1] ?? [], 'Primary key remains id for ' . $table);

    preg_match_all(
        '/UNIQUE\s+KEY\s+`([^`]+)`\s*\(([^)]+)\)/i',
        $query,
        $unique_matches,
        PREG_SET_ORDER
    );
    foreach ($unique_matches as $match) {
        preg_match_all('/`([^`]+)`/', (string) $match[2], $index_columns);
        $actual_indexes[$table . '.' . $match[1]] = [
            'columns' => $index_columns[1] ?? [],
            'unique' => true,
        ];
    }
}
glpichat_unit_pass('All inherited table columns and primary keys retain their exact shape');

$setup_source = file_get_contents($plugin_root . '/src/db/setup_helpers.php');
if (!is_string($setup_source)) {
    glpichat_unit_fail('Unable to read setup_helpers.php for index fingerprinting.');
}
preg_match_all(
    "~\\x24migration->addKey\\(\\s*'([^']+)'\\s*,\\s*(\\[[^\\]]+\\]|'[^']+')\\s*,\\s*'([^']+)'\\s*\\);~s",
    $setup_source,
    $add_key_matches,
    PREG_SET_ORDER
);
glpichat_unit_assert_same(16, count($add_key_matches), 'Exactly sixteen inherited Migration index declarations remain');
foreach ($add_key_matches as $match) {
    preg_match_all("/'([^']+)'/", (string) $match[2], $index_columns);
    $actual_indexes[$match[1] . '.' . $match[3]] = [
        'columns' => $index_columns[1] ?? [],
        'unique' => false,
    ];
}
ksort($actual_indexes, SORT_STRING);

$expected_indexes = [
    'glpi_plugin_glpichat_auditlogs.audit_ticket_date' => [['tickets_id', 'date_creation'], false],
    'glpi_plugin_glpichat_events.events_room_id' => [['rooms_id', 'id'], false],
    'glpi_plugin_glpichat_events.events_ticket_id' => [['tickets_id', 'id'], false],
    'glpi_plugin_glpichat_events.idx_events_date' => [['date_creation'], false],
    'glpi_plugin_glpichat_events.idx_events_room_date' => [['rooms_id', 'date_creation'], false],
    'glpi_plugin_glpichat_invites.idx_invites_ticket' => [['tickets_id'], false],
    'glpi_plugin_glpichat_invites.invites_expires_at' => [['expires_at'], false],
    'glpi_plugin_glpichat_invites.token_hash' => [['token_hash'], true],
    'glpi_plugin_glpichat_messages.idx_messages_document' => [['documents_id'], false],
    'glpi_plugin_glpichat_messages.messages_participant_id' => [['participants_id', 'id'], false],
    'glpi_plugin_glpichat_messages.messages_room_id' => [['rooms_id', 'id'], false],
    'glpi_plugin_glpichat_messages.messages_ticket_id' => [['tickets_id', 'id'], false],
    'glpi_plugin_glpichat_participants.idx_expire_inactive' => [['left_at', 'participant_type', 'last_activity'], false],
    'glpi_plugin_glpichat_participants.idx_rooms_typing' => [['rooms_id', 'left_at', 'is_typing_until'], false],
    'glpi_plugin_glpichat_participants.participants_room_user' => [['users_id', 'rooms_id'], false],
    'glpi_plugin_glpichat_participants.participants_session' => [['session_token_hash'], false],
    'glpi_plugin_glpichat_readstates.readstates_participant_room' => [['participants_id', 'rooms_id'], false],
    'glpi_plugin_glpichat_readstates.room_participant' => [['rooms_id', 'participants_id'], true],
    'glpi_plugin_glpichat_rooms.unicity' => [['tickets_id', 'room_type'], true],
];
$normalized_expected_indexes = [];
foreach ($expected_indexes as $qualified_name => [$columns, $unique]) {
    $normalized_expected_indexes[$qualified_name] = [
        'columns' => $columns,
        'unique' => $unique,
    ];
}
ksort($normalized_expected_indexes, SORT_STRING);
glpichat_unit_assert_same_array(
    $normalized_expected_indexes,
    $actual_indexes,
    'All nineteen inherited indexes retain exact ordered columns and uniqueness'
);

$health_index_shapes = [];
foreach (glpichat_foundation_schema_contract()['indexes'] as $table => $indexes) {
    foreach ($indexes as $index => $shape) {
        $health_index_shapes[$table . '.' . $index] = $shape;
    }
}
ksort($health_index_shapes, SORT_STRING);
glpichat_unit_assert_same_array(
    $normalized_expected_indexes,
    $health_index_shapes,
    'Read-only health manifest contains every inherited index shape fingerprint'
);
glpichat_unit_pass('Index names, ordered columns and uniqueness are fully fingerprinted');

$hook_source = file_get_contents($plugin_root . '/hook.php');
if (!is_string($hook_source)) {
    glpichat_unit_fail('Unable to read hook.php for lifecycle-only schema assertions.');
}
preg_match_all(
    "/addField\\(\\s*'([^']+)'\\s*,\\s*'([^']+)'/",
    $hook_source,
    $field_matches,
    PREG_SET_ORDER
);
$actual_compatibility_fields = array_map(
    static fn(array $match): string => $match[1] . '.' . $match[2],
    $field_matches
);
glpichat_unit_assert_same_array(
    [
        'glpi_plugin_glpichat_participants.last_activity',
        'glpi_plugin_glpichat_participants.last_seen',
        'glpi_plugin_glpichat_participants.is_typing_until',
        'glpi_plugin_glpichat_participants.last_send_at',
    ],
    $actual_compatibility_fields,
    'Lifecycle queues only the four inherited participant compatibility fields'
);

$setup = file_get_contents($plugin_root . '/setup.php');
if (!is_string($setup)) {
    glpichat_unit_fail('Unable to read setup.php for runtime schema boundary.');
}
$init_start = strpos($setup, 'function plugin_init_glpichat(): void');
$version_start = strpos($setup, 'function plugin_version_glpichat(): array');
$init_body = ($init_start !== false && $version_start !== false && $version_start > $init_start)
    ? substr($setup, $init_start, $version_start - $init_start)
    : '';
foreach (['CREATE TABLE', 'ALTER TABLE', 'addField(', 'addKey(', 'executeMigration', 'glpichat_schema_queries('] as $ddl_token) {
    glpichat_unit_assert_true(
        !str_contains($init_body, $ddl_token),
        'plugin_init performs no schema/lifecycle work: ' . $ddl_token
    );
}
glpichat_unit_assert_true(
    str_contains($setup_source, 'function glpichat_ensure_runtime_schema'),
    'Dormant production helper remains available for callable-surface compatibility'
);
glpichat_unit_assert_true(
    !str_contains($init_body, 'glpichat_ensure_runtime_schema'),
    'Dormant compatibility helper remains unwired from ordinary initialization'
);
glpichat_unit_pass('Schema work is confined to normal install/update lifecycle');

fwrite(STDOUT, "[PASS] Foundation schema-shape contract completed\n");
