<?php

declare(strict_types=1);

require dirname(__DIR__, 2) . '/bootstrap/unit.php';
require_once dirname(__DIR__, 3) . '/src/domain/AuthorizationShadow.php';

use GlpiPlugin\Glpichat\Domain\AuthorizationShadow;

$reflection = new ReflectionClass(AuthorizationShadow::class);
glpichat_unit_assert_true($reflection->isFinal(), 'AuthorizationShadow is final');
$observe_method = $reflection->getMethod('observe');
glpichat_unit_assert_same('void', (string) $observe_method->getReturnType(), 'Shadow observation cannot return an authorization decision');

$evaluation_calls = 0;
$observer_calls = 0;
AuthorizationShadow::observe(
    false,
    AuthorizationShadow::PUBLIC_READ,
    true,
    static function () use (&$evaluation_calls): bool {
        $evaluation_calls++;
        return false;
    },
    static function (array $observation) use (&$observer_calls): void {
        $observer_calls++;
    }
);
glpichat_unit_assert_same(0, $evaluation_calls, 'Disabled shadow does not evaluate candidate authorization');
glpichat_unit_assert_same(0, $observer_calls, 'Disabled shadow does not call diagnostics');
glpichat_unit_pass('Default-off shadow has zero evaluator and observer work');

foreach (['internal_read', 'internal_send', 'guest_read', 'read', ''] as $invalid_decision) {
    AuthorizationShadow::observe(
        true,
        $invalid_decision,
        true,
        static function () use (&$evaluation_calls): bool {
            $evaluation_calls++;
            return false;
        },
        static function (array $observation) use (&$observer_calls): void {
            $observer_calls++;
        }
    );
}
glpichat_unit_assert_same(0, $evaluation_calls, 'Non-public decision names cannot execute the shadow evaluator');
glpichat_unit_assert_same(0, $observer_calls, 'Non-public decision names cannot emit observations');
glpichat_unit_pass('Shadow is scoped to explicit public read/send decisions only');

foreach ([false, true] as $matching_value) {
    $match_observations = [];
    AuthorizationShadow::observe(
        true,
        AuthorizationShadow::PUBLIC_READ,
        $matching_value,
        static fn(): bool => $matching_value,
        static function (array $observation) use (&$match_observations): void {
            $match_observations[] = $observation;
        }
    );
    glpichat_unit_assert_same_array([], $match_observations, 'Matching shadow decision emits no synchronous diagnostic');
}
glpichat_unit_pass('Matching decisions create no routine log volume');

$mismatch_cases = [
    [true, false],
    [false, true],
];
foreach ($mismatch_cases as [$current_allowed, $shadow_allowed]) {
    $observations = [];
    AuthorizationShadow::observe(
        true,
        AuthorizationShadow::PUBLIC_SEND,
        $current_allowed,
        static fn(): bool => $shadow_allowed,
        static function (array $observation) use (&$observations): void {
            $observations[] = $observation;
        }
    );

    glpichat_unit_assert_same(1, count($observations), 'Mismatch emits exactly one bounded observation');
    glpichat_unit_assert_same_array(
        [
            'decision' => AuthorizationShadow::PUBLIC_SEND,
            'outcome' => 'mismatch',
            'current_allowed' => $current_allowed,
            'shadow_allowed' => $shadow_allowed,
        ],
        $observations[0],
        'Mismatch observation uses the closed non-identifying schema'
    );
}
glpichat_unit_pass('Both mismatch directions preserve the current authorization decision');

$error_observations = [];
AuthorizationShadow::observe(
    true,
    AuthorizationShadow::PUBLIC_READ,
    true,
    static function (): bool {
        throw new RuntimeException('private-user-99123 ticket-88123 secret-content');
    },
    static function (array $observation) use (&$error_observations): void {
        $error_observations[] = $observation;
    }
);
glpichat_unit_assert_same(1, count($error_observations), 'Evaluator failure emits one bounded error observation');
glpichat_unit_assert_same_array(
    [
        'decision' => AuthorizationShadow::PUBLIC_READ,
        'outcome' => 'error',
        'current_allowed' => true,
        'exception_class' => RuntimeException::class,
    ],
    $error_observations[0],
    'Evaluator failure exposes only exception class and decision booleans'
);
$serialized_error = json_encode($error_observations[0], JSON_THROW_ON_ERROR);
foreach (['99123', '88123', 'private-user', 'secret-content', 'user_id', 'profile_id', 'entity_id', 'group_id', 'ticket_id', 'room_id'] as $forbidden) {
    if (str_contains($serialized_error, $forbidden)) {
        glpichat_unit_fail('Shadow error observation leaked forbidden identity/context: ' . $forbidden);
    }
}
glpichat_unit_pass('Evaluator exceptions cannot leak raw identity, context or content');

AuthorizationShadow::observe(
    true,
    AuthorizationShadow::PUBLIC_SEND,
    false,
    static fn(): bool => true,
    static function (array $observation): void {
        throw new RuntimeException('simulated observer failure');
    }
);
glpichat_unit_pass('Observer failure cannot alter or interrupt current authorization');

$fresh_evaluations = [];
foreach ([true, false] as $fresh_value) {
    AuthorizationShadow::observe(
        true,
        AuthorizationShadow::PUBLIC_READ,
        !$fresh_value,
        static function () use (&$fresh_evaluations, $fresh_value): bool {
            $fresh_evaluations[] = $fresh_value;
            return $fresh_value;
        }
    );
}
glpichat_unit_assert_same_array([true, false], $fresh_evaluations, 'Each enabled call evaluates fresh request-local facts');
glpichat_unit_pass('Shadow has no positive cross-request authorization cache');

fwrite(STDOUT, "[PASS] AuthorizationShadow unit tests completed\n");
