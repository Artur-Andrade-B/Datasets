<?php

declare(strict_types=1);

require dirname(__DIR__, 2) . '/bootstrap/unit.php';
require_once dirname(__DIR__, 3) . '/src/db/setup_helpers.php';

$normalized_cases = [
    [0, 0],
    ['0', 0],
    [1, 1],
    ['1', 1],
    [2, 2],
    ['2', 2],
    [null, null],
    ['', null],
    [false, null],
    [true, null],
    [-1, null],
    ['-1', null],
    ['01', null],
    [1.0, null],
    [str_repeat('9', 40), null],
];
foreach ($normalized_cases as [$raw, $expected]) {
    glpichat_unit_assert_same(
        $expected,
        glpichat_foundation_normalize_version($raw),
        'Foundation marker normalization accepts only canonical bounded integers'
    );
}
glpichat_unit_pass('Foundation marker normalization is strict and overflow-safe');

foreach ([null, '', 0, '0', false, true, -1, '01', 1.0] as $pre_adoption_marker) {
    glpichat_unit_assert_same(
        '0',
        glpichat_foundation_shadow_config_value($pre_adoption_marker, '1'),
        'First foundation adoption forces a stale shadow opt-in off'
    );
}
foreach ([1, '1', 2, '2'] as $adopted_marker) {
    glpichat_unit_assert_same(
        '1',
        glpichat_foundation_shadow_config_value($adopted_marker, '1'),
        'Repeated lifecycle preserves an exact shadow opt-in'
    );
    foreach ([null, '', 0, '0', false, true, 2, '2', -1, '01'] as $disabled_value) {
        glpichat_unit_assert_same(
            '0',
            glpichat_foundation_shadow_config_value($adopted_marker, $disabled_value),
            'Repeated lifecycle normalizes every malformed shadow value off'
        );
    }
}
glpichat_unit_pass('Foundation shadow lifecycle is first-adoption-off and strictly idempotent');

foreach ([null, '', 0, '0', false, true, -1, '01', 1.0] as $old_marker) {
    glpichat_unit_assert_same(
        GLPICHAT_FOUNDATION_SCHEMA_VERSION,
        glpichat_foundation_version_to_store($old_marker),
        'Missing, old or malformed marker advances to the current foundation version'
    );
}
foreach ([1, '1', 2, '2'] as $current_or_future_marker) {
    glpichat_unit_assert_same(
        (string) $current_or_future_marker,
        glpichat_foundation_version_to_store($current_or_future_marker),
        'Current/future canonical marker is never decreased'
    );
}
glpichat_unit_pass('Foundation version recording is monotonic');

$hook_source = file_get_contents(dirname(__DIR__, 3) . '/hook.php');
if (!is_string($hook_source)) {
    glpichat_unit_fail('Unable to inspect the foundation lifecycle marker gate.');
}
$health_position = strpos($hook_source, 'glpichat_foundation_schema_health(');
$assert_position = strpos($hook_source, 'glpichat_foundation_assert_structural_postconditions(');
$marker_position = strpos(
    $hook_source,
    "'foundation_schema_version' => glpichat_foundation_version_to_store("
);
glpichat_unit_assert_true(
    $health_position !== false
        && $assert_position !== false
        && $marker_position !== false
        && $health_position < $assert_position
        && $assert_position < $marker_position,
    'Lifecycle reads structural postconditions and fails closed before committing the marker'
);
glpichat_unit_pass('Foundation marker commit is ordered after its structural health gate');

fwrite(STDOUT, "[PASS] Foundation lifecycle value tests completed\n");
