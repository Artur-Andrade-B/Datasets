<?php

declare(strict_types=1);

// Standalone focused behavior tests; run with PHP 8.2+ without a GLPI instance.
// SQL execution/lifecycle is covered by the separately required GLPI smoke test.
define('READ', 1);
define('CREATE', 4);
class Auth { public const LDAP = 3; public const CAS = 5; public const X509 = 6; public const EXTERNAL = 4; }
class Ticket { public const READMY = 1; public const READALL = 1024; }
class ITILFollowup { public const SEEPUBLIC = 1; public const ADDMY = 4; public const ADDALLITEM = 4096; }
class DesktopAuthTestError extends RuntimeException
{
    public function __construct(public string $errorCode, int $status) { parent::__construct($errorCode, $status); }
}
function glpichat_desktop_fail(string $code, string $message, int $status): never { throw new DesktopAuthTestError($code, $status); }
function glpichat_desktop_now(): string { return '2026-09-21 12:00:00'; }
function glpichat_desktop_enabled(): bool { return true; }
function glpichat_desktop_require_schema(): void {}
function glpichat_desktop_base_url(): string {
    if (!empty($GLOBALS['fixture']['url_unavailable'])) { throw new RuntimeException('No public URL context'); }
    return 'https://glpi.example.test';
}
function glpichat_desktop_quote(string $value): string { return "'" . str_replace("'", "''", $value) . "'"; }
function glpichat_desktop_transaction(callable $callback): mixed { return $callback(); }

$fixture = [];
$queries = [];
function desktop_auth_fixture(): void
{
    global $fixture, $queries, $DB;
    $fixture = [
        'user' => ['id' => 10, 'auths_id' => 2, 'authtype' => Auth::CAS, 'sync_field' => "\x01\x02object-guid",
            'date_creation' => '2025-01-01 10:00:00', 'is_active' => 1, 'is_deleted' => 0,
            'name' => 'artur', 'firstname' => 'Artur', 'realname' => 'Example', 'begin_date' => null, 'end_date' => null],
        'source' => ['id' => 2, 'is_active' => 1, 'date_creation' => '2020-01-01 00:00:00',
            'host' => 'ad.example.test', 'basedn' => 'DC=example,DC=test', 'sync_field' => 'objectGUID'],
        'grant' => ['id' => 19, 'entities_id' => 0], 'recursive_grant' => [],
        'profile' => ['id' => 3], 'entity' => ['id' => 0, 'entities_id' => 0], 'ancestors' => [],
        'rights' => [['name' => 'plugin_glpichat_public', 'rights' => READ | CREATE],
            ['name' => 'ticket', 'rights' => Ticket::READMY],
            ['name' => 'followup', 'rights' => ITILFollowup::SEEPUBLIC | ITILFollowup::ADDMY]],
        'device' => [], 'pair_counts' => ['ip' => 0, 'device' => 0, 'active' => 0], 'url_unavailable' => false,
    ];
    $queries = [];
    $DB = new class {
        public int $updates = 0;
        public int $inserts = 0;
        public function doQuery(string $sql): bool {
            global $queries;
            $queries[] = $sql;
            return true;
        }
        public function insert(string $table, array $values): bool {
            global $fixture;
            $fixture['device'] = $values + ['id' => 7, 'users_id' => 0, 'profiles_id' => 0,
                'entities_id' => 0, 'auths_id' => 0, 'token_hash' => null, 'revoked_at' => null];
            $this->inserts++;
            return true;
        }
        public function update(string $table, array $values, array $where): bool
        {
            global $fixture;
            foreach ($where as $key => $value) {
                if (($fixture['device'][$key] ?? null) !== $value) { return false; }
            }
            $fixture['device'] = array_replace($fixture['device'], $values);
            $this->updates++;
            return true;
        }
        public function affectedRows(): int { return 1; }
    };
}
function glpichat_desktop_db_rows(string $sql): array
{
    global $fixture, $queries;
    $queries[] = $sql;
    if (str_contains($sql, 'GET_LOCK(')) { return [['acquired' => 1]]; }
    if (str_contains($sql, 'RELEASE_LOCK(')) { return [['released' => 1]]; }
    if (str_contains($sql, 'SELECT COUNT(*)')) {
        $kind = str_contains($sql, 'device_id=') ? 'device' : (str_contains($sql, 'request_ip_hash=') ? 'ip' : 'active');
        return [['n' => $fixture['pair_counts'][$kind]]];
    }
    if (str_contains($sql, 'FROM glpi_profiles_users ')) {
        if (str_contains($sql, 'is_recursive=1')) {
            $grant = $fixture['recursive_grant'];
            preg_match('/entities_id IN \(([0-9,]+)\)/', $sql, $match);
            return $grant && !empty($grant['is_recursive']) && in_array((int) $grant['entities_id'], array_map('intval', explode(',', $match[1] ?? '')), true) ? [$grant] : [];
        }
        $grant = $fixture['grant'];
        preg_match('/AND entities_id=(\d+)/', $sql, $match);
        return $grant && (int) $grant['entities_id'] === (int) ($match[1] ?? -1) ? [$grant] : [];
    }
    if (str_contains($sql, 'FROM glpi_entities ')) {
        preg_match('/WHERE id=(\d+)/', $sql, $match);
        $id = (int) ($match[1] ?? -1);
        $entity = (int) ($fixture['entity']['id'] ?? -1) === $id ? $fixture['entity'] : ($fixture['ancestors'][$id] ?? []);
        return $entity ? [$entity] : [];
    }
    $mapping = [
        'glpi_plugin_glpichat_desktopdevices' => 'device', 'glpi_profiles_users' => 'grant',
        'glpi_profilerights' => 'rights', 'glpi_authldaps' => 'source',
        'glpi_profiles' => 'profile', 'glpi_entities' => 'entity', 'glpi_users' => 'user',
    ];
    foreach ($mapping as $table => $key) {
        if (str_contains($sql, 'FROM ' . $table . ' ')) {
            return $key === 'rights' ? $fixture[$key] : ($fixture[$key] ? [$fixture[$key]] : []);
        }
    }
    throw new RuntimeException('Unexpected test SQL: ' . $sql);
}

require_once dirname(__DIR__, 3) . '/src/desktop/auth.php';
$assertions = 0;
function desktop_assert(bool $condition, string $message): void
{
    global $assertions;
    if (!$condition) { throw new RuntimeException('FAIL: ' . $message); }
    $assertions++;
}
function desktop_throws(callable $callback, string $code, string $message): void
{
    try { $callback(); } catch (DesktopAuthTestError $e) {
        desktop_assert($e->errorCode === $code, $message . ' (actual ' . $e->errorCode . ')');
        return;
    }
    throw new RuntimeException('FAIL: expected rejection ' . $message);
}

desktop_assert(glpichat_desktop_auth_hash('bearer', str_repeat('a', 64)) !== glpichat_desktop_auth_hash('poll-secret', str_repeat('a', 64)), 'Hash purposes separated');

desktop_auth_fixture();
$facts = glpichat_desktop_auth_user(10, 3, 0, true);
desktop_assert($facts['can_read'] && $facts['can_create'], 'CAS+LDAP requester is eligible without Session impersonation');
desktop_assert(count(array_filter($queries, static fn(string $q): bool => str_ends_with($q, 'FOR UPDATE'))) === 6, 'Mutation revalidation locks all current authority reads');
desktop_assert(strlen($facts['sync_anchor']) === 64, 'Binary directory anchor fingerprinted without text coercion');

foreach (['disabled', 'deleted', 'local', 'future', 'expired', 'source', 'missing_source', 'grant', 'public', 'native_read', 'native_ticket'] as $scenario) {
    desktop_auth_fixture();
    switch ($scenario) {
        case 'disabled': $fixture['user']['is_active'] = 0; break;
        case 'deleted': $fixture['user']['is_deleted'] = 1; break;
        case 'local': $fixture['user']['authtype'] = 1; break;
        case 'future': $fixture['user']['begin_date'] = '2026-09-22 00:00:00'; break;
        case 'expired': $fixture['user']['end_date'] = '2026-09-20 00:00:00'; break;
        case 'source': $fixture['source']['sync_field'] = ''; break;
        case 'missing_source': $fixture['source'] = []; break;
        case 'grant': $fixture['grant'] = []; break;
        case 'public': $fixture['rights'][0]['rights'] = 0; break;
        case 'native_read': $fixture['rights'][2]['rights'] = ITILFollowup::ADDMY; break;
        case 'native_ticket': $fixture['rights'][1]['rights'] = 0; break;
    }
    desktop_throws(static fn() => glpichat_desktop_auth_user(10, 3, 0), 'credential_invalid', $scenario . ' current authority denied');
}
desktop_auth_fixture();
$fixture['rights'][2]['rights'] = ITILFollowup::SEEPUBLIC;
desktop_assert(glpichat_desktop_auth_user(10, 3, 0)['can_create'] === false, 'Public read alone never grants send');
$fixture['rights'][2]['rights'] |= ITILFollowup::ADDALLITEM;
desktop_assert(glpichat_desktop_auth_user(10, 3, 0)['can_create'] === true, 'Native ADDALLITEM accepted for direct requester sends');
$fixture['rights'][1]['rights'] = Ticket::READALL;
desktop_assert(glpichat_desktop_auth_user(10, 3, 0)['can_read'], 'Native READALL satisfies read authority without widening direct-requester conversation selection');
foreach ([Auth::X509, Auth::EXTERNAL] as $externalType) {
    desktop_auth_fixture();
    $fixture['user']['authtype'] = $externalType;
    desktop_assert(glpichat_desktop_auth_user(10, 3, 0)['can_read'], 'Core-supported external authentication with LDAP source is eligible');
}
desktop_auth_fixture();
$fixture['source']['sync_field'] = 'entryUUID';
desktop_assert(glpichat_desktop_auth_user(10, 3, 0)['can_read'], 'Use the configured LDAP synchronization attribute rather than literal ObjectGUID');

desktop_auth_fixture();
$fixture['grant'] = [];
$fixture['entity'] = ['id' => 9, 'entities_id' => 4];
$fixture['ancestors'] = [4 => ['id' => 4, 'entities_id' => 0], 0 => ['id' => 0, 'entities_id' => 0]];
$fixture['recursive_grant'] = ['id' => 23, 'entities_id' => 4, 'is_recursive' => 1];
desktop_assert(glpichat_desktop_auth_user(10, 3, 9, true)['entity_id'] === 9, 'Recursive ancestor grant authorizes the selected child without changing its bound entity');
desktop_assert(count(array_filter($queries, static fn(string $q): bool => str_contains($q, 'FROM glpi_entities') && str_ends_with($q, 'FOR UPDATE'))) === 3, 'Mutation locks selected entity and actual parent chain');
$fixture['recursive_grant']['is_recursive'] = 0;
desktop_throws(static fn() => glpichat_desktop_auth_user(10, 3, 9), 'credential_invalid', 'Nonrecursive parent grant cannot authorize child');
$fixture['recursive_grant'] = ['id' => 23, 'entities_id' => 5, 'is_recursive' => 1];
desktop_throws(static fn() => glpichat_desktop_auth_user(10, 3, 9), 'credential_invalid', 'Unrelated recursive entity cannot authorize child');
$fixture['recursive_grant']['entities_id'] = 4;
$fixture['ancestors'][4]['entities_id'] = 9;
desktop_throws(static fn() => glpichat_desktop_auth_user(10, 3, 9), 'credential_invalid', 'Cyclic hierarchy cannot invent recursive authority');

desktop_auth_fixture();
$facts = glpichat_desktop_auth_user(10, 3, 0);
$row = ['auths_id' => 2, 'users_id' => 10, 'profiles_id' => 3, 'entities_id' => 0,
    'sync_anchor' => $facts['sync_anchor'], 'user_incarnation' => $facts['user_incarnation'],
    'auth_source_fingerprint' => $facts['auth_source_fingerprint'], 'windows_login' => 'DOMAIN\\artur'];
desktop_assert(glpichat_desktop_auth_binding_matches($row, $facts), 'Exact binding accepted');
foreach (['auths_id', 'sync_anchor', 'user_incarnation', 'auth_source_fingerprint'] as $field) {
    $changed = $row;
    $changed[$field] = $field === 'auths_id' ? 4 : 'different';
    desktop_assert(!glpichat_desktop_auth_binding_matches($changed, $facts), 'Changed ' . $field . ' invalidates binding');
}
$renamed = $facts;
$renamed['login'] = 'artur.renamed';
desktop_assert(glpichat_desktop_auth_binding_matches($row, $renamed), 'Directory login rename preserves the same anchored binding');
$subject = glpichat_desktop_subject_id($facts);
desktop_assert((bool) preg_match('/^[a-f0-9]{64}$/D', $subject), 'Principal subject is opaque lowercase64hex');
desktop_assert((bool) preg_match('/^v2:[a-f0-9]{61}$/D', $facts['auth_source_fingerprint']), 'Versioned binding fits the existing64-character column without ambiguity');
$reapproved = $renamed + ['device_db_id' => 999, 'device_id' => 'new-device'];
$reapproved['profile_id'] = 77;
$reapproved['entity_id'] = 42;
$reapproved['can_create'] = false;
desktop_assert(glpichat_desktop_subject_id($reapproved) === $subject, 'Rename, device reapproval, profile/entity or rights change preserves principal subject');
foreach (['user_id', 'sync_anchor', 'user_incarnation', 'auth_source_fingerprint'] as $field) {
    $otherPrincipal = $facts;
    $otherPrincipal[$field] = $field === 'user_id' ? 11 : str_repeat('d', 64);
    desktop_assert(glpichat_desktop_subject_id($otherPrincipal) !== $subject, 'Principal subject changes for replacement ' . $field);
}
$missingAnchor = $facts;
unset($missingAnchor['user_incarnation']);
desktop_throws(static fn() => glpichat_desktop_subject_id($missingAnchor), 'credential_invalid', 'Missing incarnation cannot fall back to numeric user id');
$fixture['user']['authtype'] = Auth::LDAP;
desktop_assert(!glpichat_desktop_auth_binding_matches($row, glpichat_desktop_auth_user(10, 3, 0)), 'CAS→LDAP auth-type change invalidates old credential despite unchanged GUID');

desktop_auth_fixture();
$facts = glpichat_desktop_auth_user(10, 3, 0);
$stableRow = $row;
$legacyRow = $row;
$legacyRow['auth_source_fingerprint'] = $facts['legacy_auth_source_fingerprint'];
$legacyRow['approved_at'] = '2026-09-20 12:00:00';
$legacySubject = glpichat_desktop_subject_id(array_replace($facts, ['auth_source_fingerprint' => $legacyRow['auth_source_fingerprint']]));
$fixture['source']['host'] = 'new-ad.example.test';
$fixture['source']['port'] = '636';
$fixture['source']['basedn'] = 'OU=People,DC=example,DC=test';
$fixture['source']['condition'] = '(objectClass=person)';
$changedOperationalFacts = glpichat_desktop_auth_user(10, 3, 0);
desktop_assert(glpichat_desktop_auth_binding_matches($stableRow, $changedOperationalFacts), 'Operational LDAP changes retain new credential identity');
desktop_assert(glpichat_desktop_subject_id($changedOperationalFacts) === $subject, 'Operational LDAP changes retain v2 draft subject');
desktop_assert(glpichat_desktop_auth_binding_matches($legacyRow, $changedOperationalFacts), 'Legacy credential survives operational changes with matching GUID/user/source incarnation evidence');
$legacyDevice = $legacyRow + ['id' => 7, 'device_id' => 'legacy-device', 'status' => 'completed',
    'token_expires_at' => '2026-12-01 00:00:00', 'revoked_at' => null];
desktop_assert(glpichat_desktop_subject_id(glpichat_desktop_auth_from_row($legacyDevice)) === $legacySubject, 'Legacy credential retains its exact original subject and drafts');
desktop_assert(glpichat_desktop_subject_id($changedOperationalFacts) !== $legacySubject, 'New approval never blindly reattaches a legacy subject');
unset($fixture['source']['date_creation']);
desktop_assert(!glpichat_desktop_auth_binding_matches($legacyRow, glpichat_desktop_auth_user(10, 3, 0)), 'Ambiguous legacy source incarnation requires reapproval after operational change');
$fixture['source']['date_creation'] = '2026-09-21 00:00:00';
$recreatedSourceFacts = glpichat_desktop_auth_user(10, 3, 0);
desktop_assert(!glpichat_desktop_auth_binding_matches($legacyRow, $recreatedSourceFacts), 'Recreated source cannot reuse legacy approval');
desktop_assert(!glpichat_desktop_auth_binding_matches($stableRow, $recreatedSourceFacts), 'Recreated source cannot be misclassified as legacy to reuse v2 approval');
$fixture['source']['date_creation'] = '2020-01-01 00:00:00';
$fixture['source']['sync_field'] = 'entryUUID';
desktop_assert(!glpichat_desktop_auth_binding_matches($legacyRow, glpichat_desktop_auth_user(10, 3, 0)), 'Changing anchor semantics requires legacy reapproval');
$fixture['source']['sync_field'] = 'objectGUID';
$fixture['user']['sync_field'] = 'replacement-directory-account';
desktop_assert(!glpichat_desktop_auth_binding_matches($legacyRow, glpichat_desktop_auth_user(10, 3, 0)), 'Operational compatibility never bypasses replaced directory anchor');
$fixture['user']['sync_field'] = "\x01\x02object-guid";
$fixture['user']['date_creation'] = '2026-09-21 11:00:00';
desktop_assert(!glpichat_desktop_auth_binding_matches($legacyRow, glpichat_desktop_auth_user(10, 3, 0)), 'Reused numeric user ID cannot inherit old approval');

desktop_auth_fixture();
foreach ([[], 42, true, new stdClass()] as $bad) {
    desktop_throws(static fn() => glpichat_desktop_pair_start(['device_id' => $bad], '127.0.0.1'), 'invalid_pairing', 'Non-string JSON never reaches casts/SQL');
}

desktop_auth_fixture();
$facts = glpichat_desktop_auth_user(10, 3, 0);
$fixture['device'] = $row + ['id' => 7, 'pairing_id' => str_repeat('a', 32), 'device_id' => '11111111-2222-3333-4444-555555555555',
    'poll_secret_hash' => glpichat_desktop_auth_hash('poll-secret', str_repeat('b', 64)),
    'token_hash' => null, 'status' => 'approved', 'revoked_at' => null,
    'pairing_expires_at' => '2026-09-21 12:10:00', 'token_expires_at' => null];
$queries = [];
$response1 = glpichat_desktop_pair_exchange(str_repeat('a', 32), str_repeat('b', 64), str_repeat('c', 64));
desktop_assert(count(array_filter($queries, static fn(string $q): bool => str_contains($q, 'FROM glpi_users '))) === 1, 'Exchange reads already-locked account authority only once');
$response2 = glpichat_desktop_pair_exchange(str_repeat('a', 32), str_repeat('b', 64), str_repeat('c', 64));
desktop_assert($response1 === $response2 && $DB->updates === 1, 'Lost-response retry reuses exactly one consumed device/token');
desktop_assert($response1['user']['subject_id'] === glpichat_desktop_subject_id($facts), 'Exchange identity exposes the current principal subject');
desktop_assert($fixture['device']['token_hash'] !== str_repeat('c', 64), 'Only bearer hash stored');
desktop_assert(str_ends_with($response1['device']['expires_at'], 'Z'), 'Token expiry explicitly UTC');
desktop_throws(static fn() => glpichat_desktop_pair_exchange(str_repeat('a', 32), str_repeat('b', 64), str_repeat('d', 64)), 'pairing_consumed', 'Different token cannot replace consumed credential');
desktop_throws(static fn() => glpichat_desktop_pair_status(str_repeat('a', 32), str_repeat('e', 64)), 'pairing_unavailable', 'Wrong poll secret cannot reveal approval');
$fixture['device']['status'] = 'revoked';
desktop_throws(static fn() => glpichat_desktop_auth_from_row($fixture['device']), 'credential_invalid', 'Revoke denies current credential immediately');

$pairInput = ['device_id' => '11111111-2222-4333-8444-555555555555', 'device_name' => 'Office workstation',
    'windows_login' => 'Different Windows display hint', 'poll_secret' => str_repeat('b', 64)];
desktop_auth_fixture();
$fixture['url_unavailable'] = true;
$fixture['pair_counts']['ip'] = 200;
$pairing = glpichat_desktop_pair_start($pairInput, '192.0.2.10');
desktop_assert($DB->inserts === 1, 'Shared IP does not impose the former20-enrollment office limit');
desktop_assert($pairing['verification_path'] === 'plugins/glpichat/front/desktop.php?pairing=' . $pairing['pairing_id'], 'Relative approval link is always available without canonical URL detection');
desktop_assert(!isset($pairing['verification_uri']), 'Failed optional absolute URL does not block pairing');
desktop_assert((bool) array_filter($queries, static fn(string $q): bool => str_contains($q, 'AND device_id=') && str_contains($q, 'WHERE request_ip_hash=') && str_contains($q, 'created_at>=')), 'Per-installation retry limit stays within the existing IP/time index');
glpichat_desktop_pair_approve($pairing['pairing_id'], 10, 3, 0);
desktop_assert($fixture['device']['users_id'] === 10 && $fixture['device']['status'] === 'approved', 'Browser user, not differing Windows login hint, establishes approval identity');
foreach (['device' => 10, 'ip' => 1000, 'active' => 1000] as $kind => $count) {
    desktop_auth_fixture();
    $fixture['pair_counts'][$kind] = $count;
    desktop_throws(static fn() => glpichat_desktop_pair_start($pairInput, '192.0.2.10'), 'pairing_rate_limited', $kind . ' admission remains bounded');
    desktop_assert($DB->inserts === 0 && (bool) array_filter($queries, static fn(string $q): bool => str_contains($q, 'RELEASE_LOCK(')), 'Rejected admission performs no insert and releases its lock');
}

echo 'PASS desktop auth: ' . $assertions . " assertions\n";
