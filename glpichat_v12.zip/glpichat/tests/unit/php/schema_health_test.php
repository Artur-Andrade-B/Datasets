<?php

declare(strict_types=1);

require dirname(__DIR__, 2) . '/bootstrap/unit.php';

if (!defined('GLPICHAT_FOUNDATION_SCHEMA_VERSION')) {
    define('GLPICHAT_FOUNDATION_SCHEMA_VERSION', 1);
}

require_once dirname(__DIR__, 3) . '/src/db/schema_health.php';

$contract = glpichat_foundation_schema_contract();
glpichat_unit_assert_same(7, count($contract['tables']), 'Foundation health fixes the seven inherited plugin tables');
glpichat_unit_assert_same(
    4,
    count($contract['columns']['glpi_plugin_glpichat_participants'] ?? []),
    'Foundation health checks the four participant compatibility fields'
);
$index_count = array_sum(array_map('count', $contract['indexes']));
glpichat_unit_assert_same(19, $index_count, 'Foundation health checks all nineteen inherited named indexes');
glpichat_unit_pass('Foundation schema inspection contract is complete');

$present_tables = array_fill_keys($contract['tables'], true);
$present_columns = [];
foreach ($contract['columns'] as $table => $columns) {
    foreach ($columns as $column) {
        $present_columns[$table . '.' . $column] = true;
    }
}
$present_indexes = [];
foreach ($contract['indexes'] as $table => $indexes) {
    foreach ($indexes as $index => $shape) {
        $present_indexes[$table . '.' . $index] = $shape;
    }
}

$inspect = static function (
    array $tables,
    array $columns,
    array $indexes,
    mixed $marker
): array {
    return glpichat_foundation_schema_health(
        static fn (string $table): bool => $tables[$table] ?? false,
        static fn (string $table, string $column): bool => $columns[$table . '.' . $column] ?? false,
        static fn (string $table, string $index): ?array => $indexes[$table . '.' . $index] ?? null,
        static fn (string $key): mixed => $key === 'foundation_schema_version' ? $marker : null
    );
};

$healthy = $inspect($present_tables, $present_columns, $present_indexes, '1');
glpichat_unit_assert_true($healthy['healthy'], 'Complete structure with current marker is healthy');
glpichat_unit_assert_true($healthy['structural_healthy'], 'Complete structure is structurally healthy');
glpichat_unit_assert_same('healthy', $healthy['structural_state'], 'Healthy structure has an explicit state');
glpichat_unit_assert_true($healthy['marker_compatible'], 'Current positive marker is compatible');
glpichat_unit_assert_same('current', $healthy['marker_state'], 'Current marker has an explicit state');
glpichat_unit_assert_same(1, $healthy['marker_version'], 'Current marker version is normalized');
glpichat_unit_assert_same(1, $healthy['expected_marker_version'], 'Expected marker version comes from the lifecycle constant');
glpichat_unit_assert_same_array([], $healthy['missing_tables'], 'Healthy structure reports no missing tables');
glpichat_unit_assert_same_array([], $healthy['missing_columns'], 'Healthy structure reports no missing columns');
glpichat_unit_assert_same_array([], $healthy['missing_indexes'], 'Healthy structure reports no missing indexes');
glpichat_unit_assert_same_array([], $healthy['mismatched_indexes'], 'Healthy structure reports no mismatched indexes');
glpichat_unit_assert_true(is_float($healthy['elapsed_ms']) && $healthy['elapsed_ms'] >= 0.0, 'Health reports a non-negative elapsed time');
glpichat_unit_pass('Healthy foundation snapshot is reported without mutation');

$without_rooms = $present_tables;
unset($without_rooms['glpi_plugin_glpichat_rooms']);
$child_calls_for_missing_table = 0;
$missing_table = glpichat_foundation_schema_health(
    static fn (string $table): bool => $without_rooms[$table] ?? false,
    static function (string $table, string $column) use ($present_columns, &$child_calls_for_missing_table): bool {
        if ($table === 'glpi_plugin_glpichat_rooms') {
            $child_calls_for_missing_table++;
        }
        return $present_columns[$table . '.' . $column] ?? false;
    },
    static function (string $table, string $index) use ($present_indexes, &$child_calls_for_missing_table): ?array {
        if ($table === 'glpi_plugin_glpichat_rooms') {
            $child_calls_for_missing_table++;
        }
        return $present_indexes[$table . '.' . $index] ?? null;
    },
    static fn (string $key): string => '1'
);
glpichat_unit_assert_same_array(
    ['glpi_plugin_glpichat_rooms'],
    $missing_table['missing_tables'],
    'Missing table is reported once in deterministic contract order'
);
glpichat_unit_assert_same(0, $child_calls_for_missing_table, 'Missing tables suppress redundant child-object probes');
glpichat_unit_assert_true(!$missing_table['structural_healthy'], 'Missing table makes structure unhealthy');
glpichat_unit_assert_same('incomplete', $missing_table['structural_state'], 'Missing table marks structure incomplete');
glpichat_unit_assert_true(!$missing_table['healthy'], 'Missing table makes the combined foundation unhealthy');
glpichat_unit_pass('Missing table inspection is bounded and explicit');

$without_column = $present_columns;
unset($without_column['glpi_plugin_glpichat_participants.last_send_at']);
$without_index = $present_indexes;
unset($without_index['glpi_plugin_glpichat_events.idx_events_room_date']);
$missing_children = $inspect($present_tables, $without_column, $without_index, 1);
glpichat_unit_assert_same_array(
    ['glpi_plugin_glpichat_participants.last_send_at'],
    $missing_children['missing_columns'],
    'Missing compatibility column is identified without inspecting data rows'
);
glpichat_unit_assert_same_array(
    ['glpi_plugin_glpichat_events.idx_events_room_date'],
    $missing_children['missing_indexes'],
    'Missing named index is identified without inspecting data rows'
);
glpichat_unit_assert_true(!$missing_children['structural_healthy'], 'Missing child objects make structure unhealthy');
glpichat_unit_assert_true($missing_children['marker_compatible'], 'Structural failure remains distinct from marker compatibility');
glpichat_unit_pass('Column and index failures remain separate from the marker');

$wrong_shape_indexes = $present_indexes;
$wrong_shape_indexes['glpi_plugin_glpichat_participants.participants_room_user'] = [
    'columns' => ['rooms_id', 'users_id'],
    'unique' => false,
];
$wrong_shape_indexes['glpi_plugin_glpichat_rooms.unicity'] = [
    'columns' => ['tickets_id', 'room_type'],
    'unique' => false,
];
$mismatched = $inspect($present_tables, $present_columns, $wrong_shape_indexes, '1');
glpichat_unit_assert_same_array(
    [
        'glpi_plugin_glpichat_rooms.unicity',
        'glpi_plugin_glpichat_participants.participants_room_user',
    ],
    $mismatched['mismatched_indexes'],
    'Live health rejects wrong uniqueness and wrong ordered columns under an inherited index name'
);
glpichat_unit_assert_true(!$mismatched['structural_healthy'], 'Wrong deployed index shapes are unhealthy');
glpichat_unit_pass('Index health validates deployed order and uniqueness, not only names');

$marker_cases = [
    [null, 'missing', false, null],
    ['', 'missing', false, null],
    [false, 'missing', false, null],
    [0, 'outdated', false, 0],
    ['0', 'outdated', false, 0],
    ['invalid', 'invalid', false, null],
    ['-1', 'invalid', false, null],
    ['01', 'invalid', false, null],
    [true, 'invalid', false, null],
    [1.0, 'invalid', false, null],
    [1, 'current', true, 1],
    ['1', 'current', true, 1],
    [2, 'future', true, 2],
    ['2', 'future', true, 2],
];

foreach ($marker_cases as [$raw, $expected_state, $expected_compatible, $expected_version]) {
    $status = glpichat_foundation_marker_status($raw);
    glpichat_unit_assert_same($expected_state, $status['state'], 'Marker state is normalized strictly');
    glpichat_unit_assert_same($expected_compatible, $status['compatible'], 'Marker compatibility requires a positive integer');
    glpichat_unit_assert_same($expected_version, $status['version'], 'Marker version never relies on truthiness');
}
glpichat_unit_pass('Missing, malformed, current and future markers have closed states');

$unreadable = glpichat_foundation_schema_health(
    static fn (string $table): bool => $present_tables[$table] ?? false,
    static fn (string $table, string $column): bool => $present_columns[$table . '.' . $column] ?? false,
    static fn (string $table, string $index): bool => $present_indexes[$table . '.' . $index] ?? false,
    static function (string $key): mixed {
        throw new RuntimeException('private database detail must not escape');
    }
);
glpichat_unit_assert_same('unreadable', $unreadable['marker_state'], 'Config failure is reduced to a closed marker state');
glpichat_unit_assert_true(!$unreadable['marker_compatible'], 'Unreadable marker is incompatible');
glpichat_unit_assert_true(!$unreadable['healthy'], 'Unreadable marker keeps the combined health fail-closed');
glpichat_unit_pass('Marker read failures do not expose exception details');

$unreadable_structure = glpichat_foundation_schema_health(
    static function (string $table): bool {
        throw new RuntimeException('private database detail must not escape');
    },
    static fn (string $table, string $column): bool => true,
    static fn (string $table, string $index): ?array => null,
    static fn (string $key): string => '1'
);
glpichat_unit_assert_same('unreadable', $unreadable_structure['structural_state'], 'Schema reader failure has a closed state');
glpichat_unit_assert_true(!$unreadable_structure['structural_healthy'], 'Unreadable structure fails closed');
glpichat_unit_assert_true(!$unreadable_structure['healthy'], 'Unreadable structure keeps combined health unhealthy');
glpichat_unit_assert_same_array([], $unreadable_structure['missing_tables'], 'Partial schema details are not returned after a reader failure');
glpichat_unit_pass('Schema reader failures return bounded health rather than exception details');

glpichat_foundation_assert_structural_postconditions($healthy);
$postcondition_rejected = false;
try {
    glpichat_foundation_assert_structural_postconditions($mismatched);
} catch (RuntimeException $error) {
    $postcondition_rejected = true;
    glpichat_unit_assert_same(
        'GLPI Chat foundation structural postconditions failed.',
        $error->getMessage(),
        'Postcondition failure is stable and discloses no database detail'
    );
}
glpichat_unit_assert_true($postcondition_rejected, 'Unhealthy structure blocks the marker gate');
glpichat_unit_pass('Foundation marker postcondition gate fails closed');

$source = file_get_contents(dirname(__DIR__, 3) . '/src/db/schema_health.php');
if (!is_string($source)) {
    glpichat_unit_fail('Unable to inspect schema health source.');
}
foreach (['ALTER TABLE', 'CREATE TABLE', 'DROP TABLE', 'executeMigration', 'setConfigurationValues', '->insert(', '->update(', '->delete('] as $mutation_token) {
    if (stripos($source, $mutation_token) !== false) {
        glpichat_unit_fail('Schema health must remain read-only; found mutation token: ' . $mutation_token);
    }
}
glpichat_unit_pass('Schema health source contains no database or Config mutation primitive');

fwrite(STDOUT, "[PASS] Foundation schema health unit tests completed\n");
