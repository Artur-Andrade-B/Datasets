<?php

declare(strict_types=1);

require dirname(__DIR__, 2) . '/bootstrap/unit.php';

$plugin_root = dirname(__DIR__, 3);
$shadow = file_get_contents($plugin_root . '/tests/qualification/foundation_shadow.php');
$health = file_get_contents($plugin_root . '/tests/qualification/foundation_health.php');
$runbook = file_get_contents($plugin_root . '/docs/releases/1.0.6-foundation1.md');
if (!is_string($shadow) || !is_string($health) || !is_string($runbook)) {
    glpichat_unit_fail('Unable to read foundation CLI qualification contract files.');
}

foreach ([$shadow, $health] as $cli_source) {
    glpichat_unit_assert_true(
        str_contains($cli_source, "PHP_SAPI !== 'cli'") && str_contains($cli_source, 'http_response_code(404)'),
        'Foundation qualification helpers refuse HTTP execution'
    );
    foreach (['$DB', 'doQuery(', 'ALTER TABLE', 'CREATE TABLE', 'DROP TABLE'] as $forbidden) {
        glpichat_unit_assert_true(
            !str_contains($cli_source, $forbidden),
            'Foundation qualification helper contains no raw database/DDL primitive: ' . $forbidden
        );
    }
}

foreach (['status', 'enable', 'disable'] as $action) {
    glpichat_unit_assert_true(str_contains($shadow, "'{$action}'"), 'Shadow CLI supports the bounded action: ' . $action);
    glpichat_unit_assert_true(
        str_contains($runbook, 'foundation_shadow.php ' . $action),
        'Runbook contains the shadow CLI command: ' . $action
    );
}
glpichat_unit_assert_true(
    str_contains($shadow, 'foundation_schema_version')
        && str_contains($shadow, 'Config::setConfigurationValues')
        && str_contains($shadow, 'Config::getConfigurationValue'),
    'Shadow CLI gates on the foundation marker and uses GLPI Config with read-back'
);
glpichat_unit_assert_true(
    str_contains($health, 'glpichat_foundation_schema_health()')
        && !str_contains($health, 'Config::setConfigurationValues'),
    'Health CLI invokes only the read-only foundation snapshot'
);
glpichat_unit_assert_true(
    str_contains($runbook, 'foundation_health.php'),
    'Runbook contains the read-only health command'
);

glpichat_unit_pass('Foundation CLI helpers are guarded, bounded, documented and GLPI-bootstrapped');
fwrite(STDOUT, "[PASS] Foundation CLI contract completed\n");
