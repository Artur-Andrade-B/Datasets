<?php

declare(strict_types=1);

require dirname(__DIR__, 2) . '/bootstrap/unit.php';

$plugin_root = dirname(__DIR__, 3);
$controller = file_get_contents($plugin_root . '/src/Controller/WidgetController.php');
$functions = file_get_contents($plugin_root . '/src/functions.php');
$readstate = file_get_contents($plugin_root . '/src/db/readstate_db.php');

if (!is_string($controller) || !is_string($functions) || !is_string($readstate)) {
    glpichat_unit_fail('Unable to read perf2 hydration source contracts.');
}

if (str_contains($controller, 'glpichat_expire_inactive_user_participants')) {
    glpichat_unit_fail('Widget controller must not run installation-wide participant expiration.');
}
glpichat_unit_pass('Interactive Widget Poll contains no installation-wide participant expiration');

$history_start = strpos($controller, 'public function history(Request $request): Response');
$history_end = strpos($controller, "#[Route('/Widget/MarkRead'", $history_start);
$history = substr($controller, $history_start, $history_end - $history_start);

$acl_position = strpos($history, 'glpichat_widget_readable_room_or_fail');
$participant_position = strpos($history, 'glpichat_participant_id_for_user($rooms_id, $users_id, false)');
$release_position = strpos($history, 'glpichat_release_session_lock');
$messages_position = strpos($history, 'glpichat_messages_before');
$events_position = strpos($history, "glpichat_events(\$rooms_id, '')");

foreach ([$acl_position, $participant_position, $release_position, $messages_position, $events_position] as $position) {
    if ($position === false) {
        glpichat_unit_fail('History hydration safety step is missing.');
    }
}
if (!($acl_position < $release_position && $release_position < $participant_position && $participant_position < $messages_position && $messages_position < $events_position)) {
    glpichat_unit_fail('History must authorize, release session, preserve participant semantics, then load messages/events.');
}
glpichat_unit_pass('History releases the session immediately after complete room authorization');

if (substr_count($history, 'glpichat_participant_id_for_user') !== 1) {
    glpichat_unit_fail('History must invoke participant preparation exactly once after releasing the session lock.');
}
glpichat_unit_pass('History preserves open-as-join after session release');

$participant_helper_start = strpos($functions, 'function glpichat_participant_id_for_user(');
$active_helper_start = strpos($functions, 'function glpichat_active_participant_id_for_user(', $participant_helper_start);
$disconnect_helper_start = strpos($functions, 'function glpichat_disconnect_user_participant(', $active_helper_start);
$expire_helper_start = strpos($functions, 'function glpichat_expire_inactive_user_participants(', $disconnect_helper_start);
if (
    $participant_helper_start === false
    || $active_helper_start === false
    || $disconnect_helper_start === false
    || $expire_helper_start === false
) {
    glpichat_unit_fail('Participant lifecycle helpers cannot be isolated.');
}
$participant_helper = substr($functions, $participant_helper_start, $active_helper_start - $participant_helper_start);
$active_helper = substr($functions, $active_helper_start, $disconnect_helper_start - $active_helper_start);
$disconnect_helper = substr($functions, $disconnect_helper_start, $expire_helper_start - $disconnect_helper_start);
if (
    substr_count($participant_helper, "'ORDER' => ['id ASC']") !== 2
    || !str_contains($participant_helper, '$inserted_participants_id !== $participants_id')
    || substr_count($active_helper, "'ORDER' => ['id ASC']") !== 1
    || substr_count($disconnect_helper, "'ORDER' => ['id ASC']") !== 1
) {
    glpichat_unit_fail('Active participant lookups must select the canonical row and retire a later concurrent duplicate.');
}
glpichat_unit_pass('Participant source enforces earliest-row race convergence');

if (
    !str_contains($readstate, "(int) \$row['id'] < (int) \$active_participant_by_room[\$rid]['id']")
    || !str_contains($readstate, '$unread_participant = $active_participant ?? $latest_participant;')
    || str_contains($readstate, 'glpichat_unread_where_for_participant($latest_participant, $last_read)')
) {
    glpichat_unit_fail('Channel unread state must prefer the deterministic canonical active participant.');
}
glpichat_unit_pass('Channel unread state cannot be pinned to a retired concurrent participant');

$mark_db_start = strpos($readstate, 'function glpichat_mark_read(');
$mark_db_end = strpos($readstate, 'function glpichat_unread_count(', $mark_db_start);
$mark_db = substr($readstate, $mark_db_start, $mark_db_end - $mark_db_start);
if (
    !str_contains($mark_db, 'new QueryExpression(sprintf(')
    || !str_contains($mark_db, 'GREATEST(`last_read_messages_id`, %d)')
    || !str_contains($mark_db, 'catch (\Throwable $insert_error)')
    || !str_contains($mark_db, "'SELECT' => ['last_read_messages_id']")
    || str_contains($mark_db, 'glpichat_readstate_update_payload(')
) {
    glpichat_unit_fail('MarkRead persistence must atomically advance and read back the cursor after insert races.');
}
glpichat_unit_pass('Concurrent MarkRead requests cannot move the persisted cursor backwards');

$room_helper_start = strpos($functions, 'function glpichat_room_id(');
$room_helper_end = strpos($functions, 'function glpichat_ticket_or_fail(', $room_helper_start);
$room_helper = substr($functions, $room_helper_start, $room_helper_end - $room_helper_start);
$room_insert = strpos($room_helper, "\$DB->insert('glpi_plugin_glpichat_rooms'");
$room_reselect = strrpos($room_helper, "'FROM' => 'glpi_plugin_glpichat_rooms'");
if (
    $room_insert === false
    || $room_reselect === false
    || $room_insert >= $room_reselect
    || !str_contains($room_helper, 'catch (\Throwable $insert_error)')
    || str_contains($room_helper, '$DB->insertId()')
) {
    glpichat_unit_fail('Room creation must reselect the canonical unique row after a concurrent insert.');
}
glpichat_unit_pass('Concurrent room creation cannot return a stale insert identifier');

if (!str_contains($history, "'messages' => \$messages") || !str_contains($history, "'events'   => \$events")) {
    glpichat_unit_fail('History response message/event keys changed.');
}
glpichat_unit_pass('History retains the baseline message/event payload keys');

$mark_read_start = strpos($controller, 'public function markRead(Request $request): Response');
$mark_read_end = strpos($controller, "#[Route('/Widget/Config'", $mark_read_start);
$mark_read = substr($controller, $mark_read_start, $mark_read_end - $mark_read_start);
$mark_acl = strpos($mark_read, 'glpichat_widget_readable_room_or_fail');
$mark_csrf = strpos($mark_read, 'Session::getNewCSRFToken');
$mark_participant = strpos($mark_read, 'glpichat_participant_id_for_user($rooms_id, $users_id, false)');
$mark_release = strpos($mark_read, 'glpichat_release_session_lock');
$mark_persist = strpos($mark_read, 'glpichat_mark_read($rooms_id');
if ($mark_acl === false || $mark_csrf === false || $mark_participant === false || $mark_release === false || $mark_persist === false) {
    glpichat_unit_fail('MarkRead diagnostic/session boundary is incomplete.');
}
if (!($mark_acl < $mark_csrf && $mark_csrf < $mark_release && $mark_release < $mark_participant && $mark_participant < $mark_persist)) {
    glpichat_unit_fail('MarkRead must authorize/renew CSRF, release, then prepare the participant and persist read state.');
}
glpichat_unit_pass('MarkRead releases the session before participant and read-state database work');

if (!str_contains($controller, "array_slice(\$submitted_channels, 0, \$max_channels)")) {
    glpichat_unit_fail('Poll must hard-bound raw submitted channels before per-channel work.');
}
glpichat_unit_pass('Poll bounds raw input before per-channel authorization and queries');

$poll_start = strpos($controller, 'public function poll(Request $request): Response');
$poll_end = strpos($controller, "#[Route('/Widget/History'", $poll_start);
$poll = substr($controller, $poll_start, $poll_end - $poll_start);
$poll_slice = strpos($poll, 'array_slice($submitted_channels, 0, $max_channels)');
$poll_acl = strpos($poll, 'glpichat_assert_can_read_room');
$poll_authorized = strpos($poll, '$authorized_channels[] = [');
$poll_csrf = strpos($poll, 'Session::getNewCSRFToken');
$poll_release = strpos($poll, '$session_released = glpichat_release_session_lock');
$poll_messages = strpos($poll, 'glpichat_messages($rooms_id, $after_id)');
if (
    $poll_slice === false
    || $poll_acl === false
    || $poll_authorized === false
    || $poll_csrf === false
    || $poll_release === false
    || $poll_messages === false
) {
    glpichat_unit_fail('Poll authorization/session boundary is incomplete.');
}
if (
    !($poll_slice < $poll_acl
        && $poll_acl < $poll_authorized
        && $poll_authorized < $poll_csrf
        && $poll_csrf < $poll_release
        && $poll_release < $poll_messages)
    || substr_count($poll, 'glpichat_assert_can_read_room') !== 1
) {
    glpichat_unit_fail('Poll must authorize under the session lock and release before channel hydration.');
}
glpichat_unit_pass('Poll releases the session before message/event/read-state hydration');

$channels_start = strpos($controller, 'public function channels(Request $request): Response');
$channels_end = strpos($controller, "#[Route('/Widget/Poll'", $channels_start);
$channels_method = substr($controller, $channels_start, $channels_end - $channels_start);
$channels_csrf = strpos($channels_method, 'Session::getNewCSRFToken');
$channels_release = strpos($channels_method, '$session_released = glpichat_release_session_lock');
$channels_discovery = strpos($channels_method, 'glpichat_list_user_channels');
if ($channels_csrf === false || $channels_release === false || $channels_discovery === false) {
    glpichat_unit_fail('Channels session boundary is incomplete.');
}
if (!($channels_csrf < $channels_release && $channels_release < $channels_discovery)) {
    glpichat_unit_fail('Channels must snapshot CSRF and release before discovery.');
}
glpichat_unit_pass('Channels discovery cannot retain the same-user PHP session lock');

if (!str_contains($functions, 'bool $raise_presence_notification = true')) {
    glpichat_unit_fail('Participant helper must preserve legacy notification behavior by default.');
}
if (!str_contains($functions, 'if ($tickets_id > 0 && $raise_presence_notification)')) {
    glpichat_unit_fail('Presence notification must be explicitly guarded.');
}
glpichat_unit_pass('Interactive read paths can suppress synchronous presence notifications');

if (!str_contains($functions, 'function glpichat_release_session_lock(): bool')) {
    glpichat_unit_fail('Session release helper is missing.');
}
glpichat_unit_pass('Session release helper is present');

fwrite(STDOUT, "[PASS] perf2 hydration contract tests completed\n");
