<?php

declare(strict_types=1);

// Standalone fixture suite; no GLPI bootstrap, database, vendor or credentials.
require_once dirname(__DIR__, 3) . '/src/desktop/schema.php';

$assertions = 0;
function desktop_schema_assert(bool $condition, string $message): void
{
    ++$GLOBALS['assertions'];
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

function desktop_schema_fixture(): array
{
    $metadata = ['tables' => [], 'columns' => [], 'indexes' => []];
    $definitions = glpichat_desktop_schema_definitions();
    $definitions['glpi_plugin_glpichat_messages'] = [
        'columns' => [],
        'indexes' => ['desktop_followup_id' => ['columns' => ['itilfollowups_id'], 'unique' => false]],
    ];
    foreach ($definitions as $table => $definition) {
        $metadata['tables'][] = ['TABLE_NAME' => $table, 'ENGINE' => 'InnoDB'];
        foreach ($definition['columns'] as $name => $column) {
            $type = str_replace(' ascii_bin', '', $column['type']);
            // MariaDB integer display widths must normalize correctly.
            $type = preg_replace('/\bint\b/', 'int(10)', $type);
            $type = preg_replace('/\bbigint\b/', 'bigint(20)', $type);
            $metadata['columns'][] = [
                'TABLE_NAME' => $table, 'COLUMN_NAME' => $name,
                'COLUMN_TYPE' => $type,
                'COLUMN_DEFAULT' => str_starts_with($column['extra'], 'DEFAULT ') ? substr($column['extra'], 8) : null,
                'IS_NULLABLE' => $column['nullable'] ? 'YES' : 'NO',
                'COLLATION_NAME' => str_contains($column['type'], 'ascii_bin') ? 'ascii_bin' : null,
                'EXTRA' => $name === 'id' ? 'auto_increment' : '',
            ];
        }
        foreach ($definition['indexes'] as $name => $index) {
            foreach ($index['columns'] as $position => $column) {
                $metadata['indexes'][] = [
                    'TABLE_NAME' => $table, 'INDEX_NAME' => $name,
                    'NON_UNIQUE' => $index['unique'] ? 0 : 1,
                    'SEQ_IN_INDEX' => $position + 1, 'COLUMN_NAME' => $column,
                    'SUB_PART' => null,
                ];
            }
        }
    }
    return $metadata;
}

$config = ['desktop_schema_version' => '2', 'desktop_idempotency_key' => str_repeat('a', 64), 'desktop_enabled' => '0'];
$read_config = static function (string $key) use (&$config): mixed { return $config[$key] ?? null; };
$metadata = desktop_schema_fixture();
$read_metadata = static function () use (&$metadata): array { return $metadata; };
desktop_schema_assert(glpichat_desktop_schema_health(true, $read_metadata, $read_config)['healthy'], 'Complete metadata must pass.');

foreach (['tables', 'columns', 'indexes'] as $kind) {
    $broken = $metadata;
    array_shift($broken[$kind]);
    $health = glpichat_desktop_schema_health(true, static fn (): array => $broken, $read_config);
    desktop_schema_assert(!$health['healthy'], 'Missing ' . $kind . ' must fail closed.');
}
foreach (['engine', 'collation', 'default', 'unique', 'prefix', 'order'] as $case) {
    $broken = $metadata;
    if ($case === 'engine') {
        $broken['tables'][0]['ENGINE'] = 'MyISAM';
    } elseif ($case === 'collation') {
        $broken['columns'][1]['COLLATION_NAME'] = 'ascii_general_ci';
    } elseif ($case === 'default') {
        foreach ($broken['columns'] as &$column) {
            if ($column['COLUMN_NAME'] === 'status') { $column['COLUMN_DEFAULT'] = null; }
        }
        unset($column);
    } else {
        foreach ($broken['indexes'] as &$index) {
            if ($index['INDEX_NAME'] === 'desktop_send_uuid') {
                if ($case === 'unique') { $index['NON_UNIQUE'] = 1; }
                if ($case === 'prefix') { $index['SUB_PART'] = 4; }
                if ($case === 'order') { $index['SEQ_IN_INDEX'] = 3 - $index['SEQ_IN_INDEX']; }
            }
        }
        unset($index);
    }
    desktop_schema_assert(!glpichat_desktop_schema_health(true, static fn (): array => $broken, $read_config)['healthy'], 'Incompatible ' . $case . ' must fail.');
}
foreach ([null, false, true, '', '0', '01', '1', '3', 2.0, 'garbage'] as $bad_marker) {
    $config['desktop_schema_version'] = $bad_marker;
    desktop_schema_assert(!glpichat_desktop_schema_health(true, $read_metadata, $read_config)['healthy'], 'Unsupported marker must fail.');
}
$config['desktop_schema_version'] = '2';
$opaque = glpichat_desktop_schema_health(true, static function (): array { throw new RuntimeException('sensitive server detail'); }, $read_config);
desktop_schema_assert($opaque['issues'] === ['schema_metadata:unavailable'], 'Inspection errors must be opaque.');
desktop_schema_assert(glpichat_desktop_schema_version_to_store('99') === '99', 'Future marker must not downgrade.');

// Simulate interrupted/new install and repeat. DDL changes only the fixture's
// table/index presence; deployed column/index semantics are checked separately.
$present = ['glpi_plugin_glpichat_messages' => true];
$created_sql = [];
$index_present = false;
$config = ['desktop_enabled' => '0'];
$writes = [];
$exists = static function (string $table) use (&$present): bool { return isset($present[$table]); };
$execute = static function (string $sql) use (&$present, &$created_sql, &$index_present): void {
    $created_sql[] = $sql;
    if (preg_match('/\ACREATE TABLE `([^`]+)`/', $sql, $match) === 1) {
        $present[$match[1]] = true;
    } elseif (str_starts_with($sql, 'ALTER TABLE `glpi_plugin_glpichat_messages` ADD KEY `desktop_followup_id`')) {
        $index_present = true;
    } else {
        throw new RuntimeException('Unexpected mutation in installer.');
    }
};
$install_metadata = static function () use (&$present, &$index_present): array {
    $fixture = desktop_schema_fixture();
    foreach (['tables', 'columns', 'indexes'] as $kind) {
        $fixture[$kind] = array_values(array_filter($fixture[$kind], static function (array $row) use (&$present, &$index_present): bool {
            return isset($present[$row['TABLE_NAME']])
                && (($row['INDEX_NAME'] ?? '') !== 'desktop_followup_id' || $index_present);
        }));
    }
    return $fixture;
};
$write_config = static function (array $values) use (&$config, &$writes): void {
    $writes[] = $values;
    $config = array_replace($config, $values);
};
glpichat_desktop_schema_install($exists, $execute, $install_metadata, $read_config, $write_config);
desktop_schema_assert(count($created_sql) === 6, 'First install creates five tables and one supporting index.');
desktop_schema_assert($config['desktop_enabled'] === '0', 'Desktop starts disabled.');
desktop_schema_assert(preg_match('/\A[a-f0-9]{64}\z/', $config['desktop_idempotency_key']) === 1, 'Install creates HMAC key.');
desktop_schema_assert(end($writes) === ['desktop_schema_version' => '2'], 'Schema marker is final write.');
$key_before = $config['desktop_idempotency_key'];
$config['desktop_enabled'] = '1';
glpichat_desktop_schema_install($exists, $execute, $install_metadata, $read_config, $write_config);
desktop_schema_assert(count($created_sql) === 6, 'Repeat install must not repeat DDL.');
desktop_schema_assert($config['desktop_enabled'] === '1' && $config['desktop_idempotency_key'] === $key_before, 'Repeat preserves explicit opt-in and HMAC key.');
$config['desktop_schema_version'] = '5';
glpichat_desktop_schema_install($exists, $execute, $install_metadata, $read_config, $write_config);
desktop_schema_assert($config['desktop_schema_version'] === '5', 'Old package preserves future marker.');

unset($config['desktop_schema_version']);
$bad_readback = static function () use ($install_metadata): array {
    $value = $install_metadata();
    $value['columns'] = [];
    return $value;
};
$rejected = false;
try {
    glpichat_desktop_schema_install($exists, $execute, $bad_readback, $read_config, $write_config);
} catch (RuntimeException $e) {
    $rejected = true;
}
desktop_schema_assert($rejected && !isset($config['desktop_schema_version']), 'Failed structural readback cannot mark installation complete.');

$config['desktop_idempotency_key'] = 'invalid-existing-key';
$writes_before = count($writes);
$rejected = false;
try {
    glpichat_desktop_schema_install($exists, $execute, $install_metadata, $read_config, $write_config);
} catch (RuntimeException $e) {
    $rejected = true;
}
desktop_schema_assert($rejected && $config['desktop_idempotency_key'] === 'invalid-existing-key'
    && count($writes) === $writes_before, 'Invalid existing HMAC key must not be rotated or hidden.');

// Exercise the default production DB paths. GLPI 11 deliberately rejects
// DBmysql::query(); this guard must not be replaced with a permissive fake.
class DesktopSchemaGlpiDbFixture
{
    public array $queries = [];
    public array $ddl = [];
    public array $present = ['glpi_plugin_glpichat_messages' => true];
    public bool $index_present = false;
    public bool $allow_ddl = false;
    public int $fail_metadata_reads = 0;
    public int $forbidden_query_calls = 0;
    public ?string $fail_create = null;
    public array $credential_rows = [];
    public array $send_rows = [];
    public array $read_rows = [];

    public function query(string $sql): never {
        $this->forbidden_query_calls++;
        throw new Exception('Executing direct queries is not allowed!');
    }

    public function tableExists(string $table): bool {
        return isset($this->present[$table]);
    }

    public function doQuery(string $sql): object|bool {
        $this->queries[] = $sql;
        if (str_starts_with($sql, 'SELECT ')) {
            desktop_schema_assert(preg_match('/ FROM information_schema\.(TABLES|COLUMNS|STATISTICS) WHERE /', $sql, $match) === 1,
                'Metadata reads must target the expected information_schema views.');
            desktop_schema_assert(str_contains($sql, 'TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('),
                'Metadata reads must be bounded to the current database and fixed plugin tables.');
            if ($this->fail_metadata_reads > 0) {
                $this->fail_metadata_reads--;
                throw new RuntimeException('Simulated metadata failure after table creation.');
            }
            $kind = ['TABLES' => 'tables', 'COLUMNS' => 'columns', 'STATISTICS' => 'indexes'][$match[1]];
            $rows = array_values(array_filter(desktop_schema_fixture()[$kind], function (array $row): bool {
                return isset($this->present[$row['TABLE_NAME']])
                    && (($row['INDEX_NAME'] ?? '') !== 'desktop_followup_id' || $this->index_present);
            }));
            return (object) ['rows' => $rows, 'offset' => 0];
        }

        desktop_schema_assert($this->allow_ddl, 'Metadata and health checks must not issue DDL.');
        if (preg_match('/\ACREATE TABLE `([^`]+)`/', $sql, $match) === 1) {
            if ($this->fail_create === $match[1]) { throw new RuntimeException('Simulated new-table creation failure.'); }
            desktop_schema_assert(in_array($match[1], glpichat_desktop_schema_tables(), true), 'Only owned desktop tables may be created.');
            desktop_schema_assert(!isset($this->present[$match[1]]), 'Retry must preserve tables already created.');
            $this->present[$match[1]] = true;
        } elseif ($sql === 'ALTER TABLE `glpi_plugin_glpichat_messages` ADD KEY `desktop_followup_id` (`itilfollowups_id`)') {
            desktop_schema_assert(!$this->index_present, 'Retry must preserve the supporting index.');
            $this->index_present = true;
        } else {
            throw new RuntimeException('Unexpected mutation in default installer path.');
        }
        $this->ddl[] = $sql;
        return true;
    }

    public function fetchAssoc(object $result): array|false {
        return $result->rows[$result->offset++] ?? false;
    }
}

$DB = new DesktopSchemaGlpiDbFixture();
foreach (glpichat_desktop_schema_tables() as $table) {
    $DB->present[$table] = true;
}
$DB->index_present = true;
glpichat_desktop_schema_metadata();
desktop_schema_assert(count($DB->queries) === 3, 'Metadata inspection is three bounded read-only queries.');
$config = ['desktop_schema_version' => '2', 'desktop_idempotency_key' => str_repeat('b', 64)];
desktop_schema_assert(glpichat_desktop_schema_health(config_value: $read_config)['healthy'],
    'Default metadata reader must pass using GLPI doQuery and real result iteration.');
desktop_schema_assert(count($DB->queries) === 6 && $DB->ddl === [] && $DB->forbidden_query_calls === 0,
    'Metadata and health must remain read-only and never use forbidden query().');

// DDL can survive an interrupted update. Exercise install with its default
// tableExists/doQuery/metadata paths, then retry against the same partial state.
$DB = new DesktopSchemaGlpiDbFixture();
$DB->allow_ddl = true;
$DB->fail_metadata_reads = 1;
$config = ['desktop_enabled' => '0'];
$writes = [];
$interrupted = false;
try {
    glpichat_desktop_schema_install(config_value: $read_config, config_write: $write_config);
} catch (RuntimeException $e) {
    $interrupted = $e->getMessage() === 'Simulated metadata failure after table creation.';
}
desktop_schema_assert($interrupted && count($DB->ddl) === 5 && count($DB->present) === 6 && !$DB->index_present,
    'Interrupted install retains the five created tables before the supporting index is added.');
desktop_schema_assert($writes === [] && !isset($config['desktop_schema_version'], $config['desktop_idempotency_key']),
    'Metadata failure before readback must not write configuration or completion marker.');

glpichat_desktop_schema_install(config_value: $read_config, config_write: $write_config);
desktop_schema_assert(count($DB->ddl) === 6 && $DB->index_present,
    'Retry adds only the missing supporting index and preserves existing tables.');
desktop_schema_assert($config['desktop_enabled'] === '0'
    && preg_match('/\A[a-f0-9]{64}\z/', $config['desktop_idempotency_key']) === 1
    && end($writes) === ['desktop_schema_version' => '2'],
    'Successful retry retains disabled default, creates HMAC key and writes completion marker last.');
$key_before = $config['desktop_idempotency_key'];
$config['desktop_enabled'] = '1';
$DB->allow_ddl = false;
glpichat_desktop_schema_install(config_value: $read_config, config_write: $write_config);
desktop_schema_assert(count($DB->ddl) === 6 && $DB->forbidden_query_calls === 0
    && $config['desktop_enabled'] === '1' && $config['desktop_idempotency_key'] === $key_before,
    'Repeat install uses the supported GLPI API, performs no DDL and preserves opt-in and HMAC key.');
// Upgrade a real schema1 layout by adding only managed-enrollment tables.
// Existing credential and idempotency rows are opaque fixture data: any DML or
// recreation would fail the DB boundary above, not silently rewrite the rows.
$legacyTables = ['glpi_plugin_glpichat_desktopdevices', 'glpi_plugin_glpichat_desktopsends', 'glpi_plugin_glpichat_desktopreads'];
foreach ([false, true] as $interruptUpgrade) {
    $DB = new DesktopSchemaGlpiDbFixture();
    foreach ($legacyTables as $table) { $DB->present[$table] = true; }
    $DB->index_present = true;
    $DB->allow_ddl = true;
    $DB->credential_rows = [['id' => 17, 'status' => 'completed', 'token_hash' => str_repeat('e', 64), 'users_id' => 41]];
    $DB->send_rows = [['users_id' => 41, 'client_message_id' => '28d7ca95-03c8-4b95-baea-f3a0a92f8361', 'itilfollowups_id' => 78]];
    $DB->read_rows = [['users_id' => 41, 'itilfollowups_id' => 78]];
    $beforeRows = [$DB->credential_rows, $DB->send_rows, $DB->read_rows];
    $config = ['desktop_enabled' => '1', 'desktop_schema_version' => '1', 'desktop_idempotency_key' => str_repeat('f', 64)];
    $writes = [];
    if ($interruptUpgrade) {
        $DB->fail_create = 'glpi_plugin_glpichat_desktopregistrations';
        $interrupted = false;
        try { glpichat_desktop_schema_install(config_value: $read_config, config_write: $write_config); }
        catch (RuntimeException $error) { $interrupted = $error->getMessage() === 'Simulated new-table creation failure.'; }
        desktop_schema_assert($interrupted && count($DB->ddl) === 1 && isset($DB->present['glpi_plugin_glpichat_desktopgrants']), 'Interrupted upgrade retains its first new table for retry');
        desktop_schema_assert($writes === [] && $config['desktop_schema_version'] === '1', 'Failed upgrade leaves schema1 marker and existing settings intact');
        desktop_schema_assert([$DB->credential_rows, $DB->send_rows, $DB->read_rows] === $beforeRows, 'Failed migration preserves credentials, send receipts and read state');
        $DB->fail_create = null;
    }
    glpichat_desktop_schema_install(config_value: $read_config, config_write: $write_config);
    desktop_schema_assert(count($DB->ddl) === 2 && str_starts_with($DB->ddl[0], 'CREATE TABLE `glpi_plugin_glpichat_desktopgrants`') && str_starts_with($DB->ddl[1], 'CREATE TABLE `glpi_plugin_glpichat_desktopregistrations`'), 'Upgrade creates exactly the two managed tables without touching legacy tables/index');
    desktop_schema_assert($config['desktop_schema_version'] === '2' && end($writes) === ['desktop_schema_version' => '2'], 'Schema2 marker is committed only after complete migration readback');
    desktop_schema_assert($config['desktop_idempotency_key'] === str_repeat('f', 64) && $config['desktop_enabled'] === '1', 'Managed migration preserves existing key and opt-in');
    desktop_schema_assert([$DB->credential_rows, $DB->send_rows, $DB->read_rows] === $beforeRows, 'Successful migration preserves established devices and retry/read data');
    $DB->allow_ddl = false;
    glpichat_desktop_schema_install(config_value: $read_config, config_write: $write_config);
    desktop_schema_assert(count($DB->ddl) === 2 && $DB->forbidden_query_calls === 0, 'Repeated upgrade performs no further DDL or forbidden DB query');
}
echo "[PASS] Desktop schema: $assertions assertions; fresh/repeated/interrupted schema2 installs, schema1 migration preserving credentials and idempotency, GLPI DB API and fail-closed shapes.\n";
