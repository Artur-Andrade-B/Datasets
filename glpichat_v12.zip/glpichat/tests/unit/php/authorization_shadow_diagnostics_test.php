<?php

declare(strict_types=1);

require dirname(__DIR__, 2) . '/bootstrap/unit.php';
require_once dirname(__DIR__, 3) . '/src/diagnostics.php';

$mismatch_lines = [];
glpichat_authorization_shadow_log(
    [
        'decision' => 'public_send',
        'outcome' => 'mismatch',
        'current_allowed' => true,
        'shadow_allowed' => false,
        'users_id' => 99123,
        'profiles_id' => 88123,
        'entities_id' => 77123,
        'groups_id' => [66123],
        'tickets_id' => 55123,
        'rooms_id' => 44123,
        'user_name' => 'private-shadow-user',
        'message_content' => 'private-shadow-message',
        'token' => 'private-shadow-token',
        'url' => 'https://private.invalid/ticket/55123',
        'exception_message' => 'private-shadow-exception',
    ],
    static function (string $line) use (&$mismatch_lines): void {
        $mismatch_lines[] = $line;
    }
);

glpichat_unit_assert_same(1, count($mismatch_lines), 'One mismatch emits exactly one JSON line');
$mismatch = json_decode($mismatch_lines[0], true, 512, JSON_THROW_ON_ERROR);
$mismatch_keys = array_keys($mismatch);
sort($mismatch_keys, SORT_STRING);
glpichat_unit_assert_same_array(
    ['build', 'current_allowed', 'decision', 'operation', 'outcome', 'shadow_allowed'],
    $mismatch_keys,
    'Mismatch log has an exact closed field set'
);
glpichat_unit_assert_same('authorization_shadow', $mismatch['operation'], 'Mismatch uses the dedicated operation');
glpichat_unit_assert_same('public_send', $mismatch['decision'], 'Mismatch retains only an allowlisted public decision');
glpichat_unit_assert_same('mismatch', $mismatch['outcome'], 'Mismatch retains the bounded outcome');
glpichat_unit_assert_same(true, $mismatch['current_allowed'], 'Mismatch records the current Boolean decision');
glpichat_unit_assert_same(false, $mismatch['shadow_allowed'], 'Mismatch records the shadow Boolean decision');

$serialized = $mismatch_lines[0];
foreach ([
    '99123',
    '88123',
    '77123',
    '66123',
    '55123',
    '44123',
    'private-shadow-user',
    'private-shadow-message',
    'private-shadow-token',
    'private.invalid',
    'private-shadow-exception',
    'users_id',
    'profiles_id',
    'entities_id',
    'groups_id',
    'tickets_id',
    'rooms_id',
] as $forbidden) {
    if (str_contains($serialized, $forbidden)) {
        glpichat_unit_fail('Shadow diagnostic leaked forbidden context: ' . $forbidden);
    }
}
glpichat_unit_pass('Mismatch logger strips identity, authorization context, content, URL and secrets');

$error_lines = [];
glpichat_authorization_shadow_log(
    [
        'decision' => 'public_read',
        'outcome' => 'error',
        'current_allowed' => false,
        'exception_class' => RuntimeException::class,
        'exception_message' => 'raw private exception message',
        'tickets_id' => 123456,
    ],
    static function (string $line) use (&$error_lines): void {
        $error_lines[] = $line;
    }
);
glpichat_unit_assert_same(1, count($error_lines), 'One observer error emits exactly one JSON line');
$error = json_decode($error_lines[0], true, 512, JSON_THROW_ON_ERROR);
$error_keys = array_keys($error);
sort($error_keys, SORT_STRING);
glpichat_unit_assert_same_array(
    ['build', 'current_allowed', 'decision', 'exception_class', 'operation', 'outcome'],
    $error_keys,
    'Error log has an exact closed field set'
);
glpichat_unit_assert_same(RuntimeException::class, $error['exception_class'], 'Error log keeps only a safe exception class');
if (str_contains($error_lines[0], 'raw private') || str_contains($error_lines[0], '123456')) {
    glpichat_unit_fail('Shadow error diagnostic leaked exception text or a ticket id.');
}
glpichat_unit_pass('Error logger omits raw exception text and identifiers');

$invalid_class_lines = [];
glpichat_authorization_shadow_log(
    [
        'decision' => 'public_read',
        'outcome' => 'error',
        'current_allowed' => true,
        'exception_class' => "Bad Class\nprivate-value",
    ],
    static function (string $line) use (&$invalid_class_lines): void {
        $invalid_class_lines[] = $line;
    }
);
$invalid_class_record = json_decode($invalid_class_lines[0], true, 512, JSON_THROW_ON_ERROR);
glpichat_unit_assert_same('Throwable', $invalid_class_record['exception_class'], 'Unsafe exception class is replaced');

$ignored_lines = [];
foreach ([
    ['decision' => 'internal_read', 'outcome' => 'mismatch'],
    ['decision' => 'guest_read', 'outcome' => 'mismatch'],
    ['decision' => 'public_read', 'outcome' => 'ok'],
    ['decision' => '', 'outcome' => 'error'],
] as $invalid_observation) {
    glpichat_authorization_shadow_log(
        $invalid_observation,
        static function (string $line) use (&$ignored_lines): void {
            $ignored_lines[] = $line;
        }
    );
}
glpichat_unit_assert_same_array([], $ignored_lines, 'Non-public and non-error/mismatch observations are discarded');
glpichat_unit_pass('Logger cannot become an internal/Guest or routine-match telemetry channel');

glpichat_authorization_shadow_log(
    [
        'decision' => 'public_send',
        'outcome' => 'mismatch',
        'current_allowed' => false,
        'shadow_allowed' => true,
    ],
    static function (string $line): void {
        throw new RuntimeException('simulated filesystem failure');
    }
);
glpichat_unit_pass('Shadow log sink failure is swallowed');

fwrite(STDOUT, "[PASS] Authorization shadow diagnostics unit tests completed\n");
