<?php

declare(strict_types=1);

require dirname(__DIR__, 2) . '/bootstrap/unit.php';
require_once dirname(__DIR__, 3) . '/src/domain/ActorContext.php';

use GlpiPlugin\Glpichat\Domain\ActorContext;

/** @param callable():void $operation */
function actorContextExpectInvalid(callable $operation, string $message): void
{
    try {
        $operation();
    } catch (InvalidArgumentException $error) {
        glpichat_unit_pass($message);
        return;
    }

    glpichat_unit_fail($message);
}

$reflection = new ReflectionClass(ActorContext::class);
glpichat_unit_assert_true($reflection->isFinal(), 'ActorContext is final');
glpichat_unit_assert_true($reflection->isReadOnly(), 'ActorContext is a PHP readonly class');

$property_names = array_map(
    static fn(ReflectionProperty $property): string => $property->getName(),
    $reflection->getProperties()
);
sort($property_names, SORT_STRING);
$expected_property_names = [
    'canCreatePublic',
    'canReadPublic',
    'entityId',
    'entityIds',
    'groupIds',
    'isRecursive',
    'profileId',
    'userId',
];
sort($expected_property_names, SORT_STRING);
glpichat_unit_assert_same_array(
    $expected_property_names,
    $property_names,
    'ActorContext has only the closed request-local fact set'
);
glpichat_unit_pass('ActorContext cannot grow identity, credential, ticket or message state unnoticed');

$source_entities = [4, 2, 4, 0];
$source_groups = [9, 2, 9];
$actor = new ActorContext(17, 6, 7, true, $source_entities, $source_groups, true, false);

glpichat_unit_assert_same(17, $actor->userId, 'ActorContext preserves the GLPI user id');
glpichat_unit_assert_same(6, $actor->profileId, 'ActorContext preserves the active profile id');
glpichat_unit_assert_same(7, $actor->entityId, 'ActorContext preserves the active entity id');
glpichat_unit_assert_same(true, $actor->isRecursive, 'ActorContext preserves recursive scope');
glpichat_unit_assert_same(true, $actor->canReadPublic, 'ActorContext preserves public READ fact');
glpichat_unit_assert_same(false, $actor->canCreatePublic, 'ActorContext preserves public CREATE fact');
glpichat_unit_assert_same_array([0, 2, 4, 7], $actor->entityIds, 'Entity ids are unique, sorted and include the active entity');
glpichat_unit_assert_same_array([2, 9], $actor->groupIds, 'Group ids are positive, unique and sorted');
glpichat_unit_pass('ActorContext normalizes immutable entity and group snapshots');

$source_entities[] = 99;
$source_groups[] = 88;
glpichat_unit_assert_same_array([0, 2, 4, 7], $actor->entityIds, 'Mutating constructor entity input cannot alter ActorContext');
glpichat_unit_assert_same_array([2, 9], $actor->groupIds, 'Mutating constructor group input cannot alter ActorContext');

try {
    $actor->userId = 123;
    glpichat_unit_fail('Readonly ActorContext must reject property mutation.');
} catch (Error $error) {
    glpichat_unit_pass('Readonly ActorContext rejects property mutation');
}

try {
    $actor->groupIds[] = 123;
    glpichat_unit_fail('Readonly ActorContext must reject array-element mutation.');
} catch (Error $error) {
    glpichat_unit_pass('Readonly ActorContext rejects nested array mutation');
}

$root_actor = new ActorContext(1, 1, 0, false, [], [], false, false);
glpichat_unit_assert_same_array([0], $root_actor->entityIds, 'Root entity zero is valid and added to the entity snapshot');
glpichat_unit_assert_same_array([], $root_actor->groupIds, 'An actor may have no group membership');

actorContextExpectInvalid(
    static fn() => new ActorContext(0, 1, 0, false, [], [], false, false),
    'ActorContext rejects a non-positive user id'
);
actorContextExpectInvalid(
    static fn() => new ActorContext(1, 0, 0, false, [], [], false, false),
    'ActorContext rejects a non-positive profile id'
);
actorContextExpectInvalid(
    static fn() => new ActorContext(1, 1, -1, false, [], [], false, false),
    'ActorContext rejects a negative active entity id'
);
actorContextExpectInvalid(
    static fn() => new ActorContext(1, 1, 0, false, [0, -1], [], false, false),
    'ActorContext rejects a negative accessible entity id'
);
actorContextExpectInvalid(
    static fn() => new ActorContext(1, 1, 0, false, ['2'], [], false, false),
    'ActorContext rejects non-integer entity facts'
);
actorContextExpectInvalid(
    static fn() => new ActorContext(1, 1, 0, false, [], [0], false, false),
    'ActorContext rejects a non-positive group id'
);
actorContextExpectInvalid(
    static fn() => new ActorContext(1, 1, 0, false, [], ['2'], false, false),
    'ActorContext rejects non-integer group facts'
);

fwrite(STDOUT, "[PASS] ActorContext unit tests completed\n");
