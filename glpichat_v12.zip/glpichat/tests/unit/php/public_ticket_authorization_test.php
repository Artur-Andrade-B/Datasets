<?php

declare(strict_types=1);

require dirname(__DIR__, 2) . '/bootstrap/unit.php';
require_once dirname(__DIR__, 3) . '/src/domain/access.php';
require_once dirname(__DIR__, 3) . '/src/domain/ActorContext.php';
require_once dirname(__DIR__, 3) . '/src/domain/PublicTicketAuthorization.php';

use GlpiPlugin\Glpichat\Domain\ActorContext;
use GlpiPlugin\Glpichat\Domain\PublicTicketAuthorization;

$reflection = new ReflectionClass(PublicTicketAuthorization::class);
glpichat_unit_assert_true($reflection->isFinal(), 'PublicTicketAuthorization is final');
glpichat_unit_assert_same_array([], $reflection->getProperties(), 'PublicTicketAuthorization carries no mutable state');
foreach (['canRead', 'canSend'] as $method_name) {
    $method = $reflection->getMethod($method_name);
    glpichat_unit_assert_true($method->isStatic(), $method_name . ' is a stateless static policy method');
    glpichat_unit_assert_same('bool', (string) $method->getReturnType(), $method_name . ' has an explicit Boolean result');
}

$policy_source = file_get_contents(dirname(__DIR__, 3) . '/src/domain/PublicTicketAuthorization.php');
if (!is_string($policy_source)) {
    glpichat_unit_fail('Unable to read PublicTicketAuthorization source.');
}
foreach (['Session::', 'Ticket::', 'Config::', '$DB', '$_SESSION', '$_COOKIE', '$_REQUEST'] as $forbidden_dependency) {
    if (str_contains($policy_source, $forbidden_dependency)) {
        glpichat_unit_fail('Pure public policy references a framework/global dependency: ' . $forbidden_dependency);
    }
}
glpichat_unit_pass('Public policy is pure and independent of GLPI/session/database globals');

$booleans = [false, true];
$read_cases = 0;
foreach ($booleans as $ticket_can_read) {
    foreach ($booleans as $can_read_public) {
        $actor = new ActorContext(11, 3, 0, false, [0], [], $can_read_public, false);
        $legacy = glpichat_can_read_room_from_state(
            $ticket_can_read,
            GLPICHAT_ROOM_PUBLIC,
            $can_read_public,
            false
        );
        $candidate = PublicTicketAuthorization::canRead($actor, $ticket_can_read);
        $explicit_policy = $ticket_can_read && $can_read_public;
        glpichat_unit_assert_same(
            $explicit_policy,
            $candidate,
            'Public read matches its independent explicit policy formula'
        );
        glpichat_unit_assert_same(
            $legacy,
            $candidate,
            sprintf(
                'Public read parity holds (ticket=%d, public_read=%d)',
                (int) $ticket_can_read,
                (int) $can_read_public
            )
        );
        $read_cases++;
    }
}
glpichat_unit_assert_same(4, $read_cases, 'Public read truth table covers every Boolean combination');
glpichat_unit_pass('Public read policy exactly matches all four inherited public-room outcomes');

$send_cases = 0;
foreach ($booleans as $ticket_can_read) {
    foreach ($booleans as $can_read_public) {
        foreach ($booleans as $can_create_public) {
            foreach ($booleans as $terminal) {
                $actor = new ActorContext(
                    11,
                    3,
                    0,
                    false,
                    [0],
                    [],
                    $can_read_public,
                    $can_create_public
                );
                $legacy_public_read = glpichat_can_read_room_from_state(
                    $ticket_can_read,
                    GLPICHAT_ROOM_PUBLIC,
                    $can_read_public,
                    false
                );
                $legacy = glpichat_can_send_from_state(
                    $legacy_public_read,
                    false,
                    $terminal,
                    GLPICHAT_ROOM_PUBLIC,
                    $can_create_public,
                    false
                );
                $candidate = PublicTicketAuthorization::canSend($actor, $ticket_can_read, $terminal);
                $explicit_policy = $ticket_can_read
                    && $can_read_public
                    && $can_create_public
                    && !$terminal;
                glpichat_unit_assert_same(
                    $explicit_policy,
                    $candidate,
                    'Public send matches its independent explicit policy formula'
                );
                glpichat_unit_assert_same(
                    $legacy,
                    $candidate,
                    sprintf(
                        'Public send parity holds (ticket=%d, read=%d, create=%d, terminal=%d)',
                        (int) $ticket_can_read,
                        (int) $can_read_public,
                        (int) $can_create_public,
                        (int) $terminal
                    )
                );
                $send_cases++;
            }
        }
    }
}
glpichat_unit_assert_same(16, $send_cases, 'Public send truth table covers every Boolean combination');
glpichat_unit_pass('Public send policy exactly matches all sixteen inherited public-room outcomes');

$internal_only_actor = new ActorContext(11, 3, 0, false, [0], [], false, true);
glpichat_unit_assert_same(
    true,
    glpichat_can_read_ticket_from_state(true, false, true),
    'Inherited generic ticket chat access may be granted by an internal-only right'
);
glpichat_unit_assert_same(
    false,
    PublicTicketAuthorization::canRead($internal_only_actor, true),
    'Public policy never treats internal-only generic ticket access as public access'
);
glpichat_unit_pass('Public policy remains deliberately isolated from internal-room semantics');

$scope_a = new ActorContext(11, 3, 0, false, [0], [], true, true);
$scope_b = new ActorContext(99, 8, 7, true, [0, 2, 7], [4, 10], true, true);
glpichat_unit_assert_same(
    PublicTicketAuthorization::canRead($scope_a, true),
    PublicTicketAuthorization::canRead($scope_b, true),
    'Captured scope identifiers cannot independently grant or deny public read'
);
glpichat_unit_assert_same(
    PublicTicketAuthorization::canSend($scope_a, true, false),
    PublicTicketAuthorization::canSend($scope_b, true, false),
    'Captured scope identifiers cannot independently grant or deny public send'
);
glpichat_unit_pass('GLPI ticket authorization remains the supplied authoritative ticket fact');

fwrite(STDOUT, "[PASS] PublicTicketAuthorization unit tests completed\n");
