<?php

declare(strict_types=1);

/**
 * In-memory SQL-boundary fixture, NOT a MySQL or live GLPI substitute.
 * Services, hashes, validation and transaction callbacks remain production code.
 */
final class DesktopEnrollmentRows
{
    public int $offset = 0;
    public function __construct(public array $rows) {}
    public function free(): void {}
}

final class DesktopEnrollmentDB
{
    public const ANCHOR = "\x78\x56\x34\x12\x34\x12\x34\x12\x12\x34\x12\x34\x56\x78\x90\xab";
    public array $tables;
    public array $queries = [];
    public array $writes = [];
    public array $snapshots = [];
    public ?string $failInsert = null;
    public ?string $failUpdate = null;
    public ?int $failCommitDepth = null;
    private int $lastId = 0;
    private int $affected = 0;

    public function __construct()
    {
        $this->tables = [
            'glpi_users' => [['id' => 10, 'auths_id' => 2, 'authtype' => 5, 'sync_field' => self::ANCHOR,
                'date_creation' => '2025-01-01 00:00:00', 'is_active' => 1, 'is_deleted' => 0,
                'name' => 'employee', 'firstname' => 'Test', 'realname' => 'Employee', 'profiles_id' => 3, 'entities_id' => 1]],
            'glpi_authldaps' => [['id' => 2, 'date_creation' => '2020-01-01 00:00:00', 'sync_field' => 'objectGUID', 'is_active' => 1]],
            'glpi_profiles' => [['id' => 3]], 'glpi_entities' => [['id' => 1, 'entities_id' => 0], ['id' => 0, 'entities_id' => 0]],
            'glpi_profiles_users' => [['id' => 1, 'users_id' => 10, 'profiles_id' => 3, 'entities_id' => 1, 'is_recursive' => 0]],
            'glpi_profilerights' => [['profiles_id' => 3, 'name' => 'plugin_glpichat_public', 'rights' => 5],
                ['profiles_id' => 3, 'name' => 'ticket', 'rights' => 1], ['profiles_id' => 3, 'name' => 'followup', 'rights' => 5]],
            'glpi_plugin_glpichat_desktopdevices' => [], 'glpi_plugin_glpichat_desktopgrants' => [],
            'glpi_plugin_glpichat_desktopregistrations' => [],
        ];
    }
    public function escape(string $value): string { return addslashes($value); }
    public function beginTransaction(): void { $this->snapshots[] = [$this->tables, $this->lastId, $this->writes]; }
    public function commit(): void
    {
        if (!$this->snapshots) { throw new RuntimeException('No transaction'); }
        if ($this->failCommitDepth === count($this->snapshots)) {
            $this->failCommitDepth = null;
            throw new RuntimeException('Fixture rejected the database commit');
        }
        array_pop($this->snapshots);
    }
    public function rollBack(): void
    {
        if (!$this->snapshots) { throw new RuntimeException('No transaction'); }
        [$this->tables, $this->lastId, $this->writes] = array_pop($this->snapshots);
    }
    public function affectedRows(): int { return $this->affected; }
    public function insertId(): int { return $this->lastId; }
    public function insert(string $table, array $values): bool
    {
        if ($this->failInsert === $table) { $this->failInsert = null; return false; }
        if (!array_key_exists($table, $this->tables)) { throw new RuntimeException('Unknown table: ' . $table); }
        if ($table !== 'glpi_plugin_glpichat_desktopregistrations') {
            $values['id'] = $this->tables[$table] ? max(array_column($this->tables[$table], 'id')) + 1 : 1;
            $this->lastId = $values['id'];
        }
        foreach (['grant_id', 'pairing_id', 'token_hash', 'devices_id'] as $unique) {
            if (!isset($values[$unique])) { continue; }
            foreach ($this->tables[$table] as $row) {
                if (($row[$unique] ?? null) === $values[$unique]) { throw new RuntimeException('Fixture unique constraint: ' . $unique); }
            }
        }
        $this->tables[$table][] = $values;
        $this->writes[] = ['insert', $table, $values]; $this->affected = 1;
        return true;
    }
    public function update(string $table, array $values, array $where): bool
    {
        if ($this->failUpdate === $table) { $this->failUpdate = null; return false; }
        $this->affected = 0;
        foreach ($this->tables[$table] as &$row) {
            $match = true;
            foreach ($where as $field => $value) {
                if (($row[$field] ?? null) !== $value) { $match = false; break; }
            }
            if ($match) { $row = array_replace($row, $values); $this->affected++; }
        }
        unset($row);
        $this->writes[] = ['update', $table, $values, $where];
        return true;
    }
    public function doQuery(string $sql): DesktopEnrollmentRows
    {
        $this->queries[] = $sql;
        if (!preg_match('/^SELECT .+ FROM ([a-z_0-9]+)(?: |$)/D', $sql, $tableMatch)) {
            throw new RuntimeException('Unsupported fixture SQL: ' . $sql);
        }
        $table = $tableMatch[1];
        if (!array_key_exists($table, $this->tables)) { throw new RuntimeException('Unknown SQL table: ' . $table); }
        $rows = $this->tables[$table];
        if (str_contains($sql, 'SELECT r.*,g.status AS grant_status')) {
            $rows = [];
            foreach ($this->tables['glpi_plugin_glpichat_desktopregistrations'] as $registration) {
                $matched = false;
                foreach ($this->tables['glpi_plugin_glpichat_desktopgrants'] as $grant) {
                    if ($registration['grant_id'] === $grant['grant_id']) {
                        $matched = true;
                        $rows[] = $registration + ['grant_status' => $grant['status'], 'windows_sid' => $grant['windows_sid'], 'computer_name' => $grant['computer_name']];
                    }
                }
                if (!$matched && str_contains($sql, 'LEFT JOIN')) {
                    $rows[] = $registration + ['grant_status' => null, 'windows_sid' => null, 'computer_name' => null];
                }
            }
        }
        $where = explode(' WHERE ', $sql, 2)[1] ?? '';
        preg_match_all('/(?:^|\sAND\s)(?:[a-z]+\.)?([a-z_]+)=(\d+|\'(?:[^\'\\\\]|\\\\.)*\')/', $where, $conditions, PREG_SET_ORDER);
        foreach ($conditions as $condition) {
            $value = str_starts_with($condition[2], "'") ? stripslashes(substr($condition[2], 1, -1)) : (int) $condition[2];
            $rows = array_values(array_filter($rows, static fn(array $row): bool => ($row[$condition[1]] ?? null) === $value));
        }
        if (preg_match('/entities_id IN \(([0-9,]+)\)/', $where, $in)) {
            $entities = array_map('intval', explode(',', $in[1]));
            $rows = array_values(array_filter($rows, static fn(array $row): bool => in_array((int) ($row['entities_id'] ?? -1), $entities, true)));
        }
        if (str_contains($sql, ' LIMIT 1')) { $rows = array_slice($rows, 0, 1); }
        return new DesktopEnrollmentRows($rows);
    }
    public function fetchAssoc(DesktopEnrollmentRows $result): array|false { return $result->rows[$result->offset++] ?? false; }
}
