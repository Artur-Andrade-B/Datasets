<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit(1);
}

require dirname(__DIR__, 4) . '/vendor/autoload.php';

$kernel = new \Glpi\Kernel\Kernel();
$kernel->boot();

require_once dirname(__DIR__, 2) . '/src/functions.php';

$health = glpichat_foundation_schema_health();
fwrite(STDOUT, json_encode($health, JSON_THROW_ON_ERROR | JSON_PRETTY_PRINT) . PHP_EOL);

exit($health['healthy'] === true ? 0 : 5);
