<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit(1);
}

require dirname(__DIR__, 4) . '/vendor/autoload.php';

$kernel = new \Glpi\Kernel\Kernel();
$kernel->boot();

$action = strtolower((string) ($argv[1] ?? 'status'));
if (!in_array($action, ['status', 'enable', 'disable'], true)) {
    fwrite(STDERR, "Usage: php foundation_shadow.php [status|enable|disable]\n");
    exit(2);
}

$context = 'plugin:glpichat';
$flagKey = 'public_authorization_shadow_enabled';
$markerKey = 'foundation_schema_version';

if ($action === 'enable') {
    $rawMarker = Config::getConfigurationValue($context, $markerKey);
    $markerIsAdopted = (is_int($rawMarker) && $rawMarker >= 1)
        || (
            is_string($rawMarker)
            && preg_match('/\A[1-9][0-9]*\z/', $rawMarker) === 1
            && filter_var($rawMarker, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) !== false
        );
    if (!$markerIsAdopted) {
        fwrite(STDERR, "Refusing to enable shadow before foundation_schema_version >= 1.\n");
        exit(3);
    }

    Config::setConfigurationValues($context, [$flagKey => '1']);
} elseif ($action === 'disable') {
    Config::setConfigurationValues($context, [$flagKey => '0']);
}

$rawFlag = Config::getConfigurationValue($context, $flagKey);
$flag = ($rawFlag === 1 || $rawFlag === '1') ? '1' : '0';
if (($action === 'enable' && $flag !== '1') || ($action === 'disable' && $flag !== '0')) {
    fwrite(STDERR, "Shadow flag read-back did not match the requested state.\n");
    exit(4);
}

$rawMarker = Config::getConfigurationValue($context, $markerKey);
$marker = is_scalar($rawMarker) ? (string) $rawMarker : '';
fwrite(STDOUT, "foundation_schema_version={$marker}\n");
fwrite(STDOUT, "public_authorization_shadow_enabled={$flag}\n");
