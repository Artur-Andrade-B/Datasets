<?php

declare(strict_types=1);

/**
 * CLI contract regression using unchanged GLPI11.0.7 DBmysql public transaction
 * methods, private transaction state and SQL/savepoint formatting. Only the
 * low-level connection is a fixture: no DB constructor, SQL server or GLPI boot.
 * The autoloader must supply GLPI's real Safe dependency, not a replacement.
 *
 * Usage: php desktop_transaction_core_boundary.php COMMON_PATH CORE_DBMYSQL_PATH AUTOLOAD
 * Passing desktop4 common.php fails at its call to the actual private method.
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
if ($argc !== 4 || !is_file($argv[1]) || !is_file($argv[2]) || !is_file($argv[3])) {
    fwrite(STDERR, "Usage: desktop_transaction_core_boundary.php COMMON_PATH CORE_DBMYSQL_PATH AUTOLOAD\n");
    exit(2);
}
if (hash_file('sha256', $argv[2]) !== '0e964e1a943055a6df521bee2aeca6774c664375fde6f28dff309482500dffd9') {
    throw new RuntimeException('Expected unchanged GLPI11.0.7 src/DBmysql.php from the official tag.');
}
require $argv[3];
require $argv[2];
require $argv[1];
if (!function_exists('Safe\\preg_match')) {
    throw new RuntimeException('The autoloader must provide GLPI\'s Safe dependency.');
}
$_SESSION = [];
$checks = 0;
function transaction_check(bool $condition, string $message): void
{
    ++$GLOBALS['checks'];
    if (!$condition) { throw new RuntimeException($message); }
}

/** Models only driver boundaries and rollback effects, never application SQL. */
final class DesktopTransactionDriver
{
    public array $calls = [];
    public array $values = [];
    public array $committed = [];
    public array $savepoints = [];
    public bool $active = false;
    public string $failNext = '';
    public int $affected_rows = 0;
    public int $warning_count = 0;
    public int $errno = 0;
    public string $error = '';
    private array $before = [];

    private function succeeds(string $call): bool
    {
        $this->calls[] = $call;
        if ($this->failNext === $call) { $this->failNext = ''; return false; }
        return true;
    }
    public function begin_transaction(): bool
    {
        if (!$this->succeeds('begin')) { return false; }
        if ($this->active) { throw new LogicException('Core attempted a second physical begin.'); }
        $this->before = $this->values;
        $this->active = true;
        return true;
    }
    public function savepoint(string $name): bool
    {
        if (!$this->succeeds('savepoint:' . $name)) { return false; }
        if (!$this->active) { throw new LogicException('Savepoint requires a transaction.'); }
        $this->savepoints[$name] = $this->values;
        return true;
    }
    public function release_savepoint(string $name): bool
    {
        if (!$this->succeeds('release:' . $name)) { return false; }
        if (!array_key_exists($name, $this->savepoints)) { throw new LogicException('Missing savepoint.'); }
        unset($this->savepoints[$name]);
        return true;
    }
    public function query(string $sql): bool
    {
        if (preg_match('/\AROLLBACK TO `(savepoint_[0-9]+)`\z/D', $sql, $match) !== 1) {
            throw new LogicException('Unexpected driver SQL: ' . $sql);
        }
        if (!$this->succeeds('rollback-to:' . $match[1])) { return false; }
        if (!array_key_exists($match[1], $this->savepoints)) { throw new LogicException('Missing rollback savepoint.'); }
        $this->values = $this->savepoints[$match[1]];
        return true;
    }
    public function commit(): bool
    {
        if (!$this->succeeds('commit')) { return false; }
        if (!$this->active) { throw new LogicException('No physical transaction to commit.'); }
        $this->committed = $this->values;
        $this->savepoints = [];
        $this->active = false;
        return true;
    }
    public function rollback(): bool
    {
        if (!$this->succeeds('rollback')) { return false; }
        if (!$this->active) { throw new LogicException('No physical transaction to roll back.'); }
        $this->values = $this->before;
        $this->savepoints = [];
        $this->active = false;
        return true;
    }
}

final class DesktopTransactionCoreBoundary extends DBmysql
{
    public function __construct(DesktopTransactionDriver $driver)
    {
        // Do not run the real connection constructor. All other methods and
        // private fields, including the inaccessible state getter, are core.
        $this->dbh = $driver;
    }
}

transaction_check((new ReflectionMethod(DBmysql::class, 'isInTransaction'))->isPrivate(), 'Core state getter must retain its real private visibility.');
foreach (['beginTransaction', 'commit', 'rollBack', 'doQuery', 'quoteName'] as $method) {
    transaction_check((new ReflectionMethod(DesktopTransactionCoreBoundary::class, $method))->getDeclaringClass()->getName() === DBmysql::class, 'Core method must not be replaced: ' . $method);
}
$fresh = static function (): DesktopTransactionDriver {
    $driver = new DesktopTransactionDriver();
    $GLOBALS['DB'] = new DesktopTransactionCoreBoundary($driver);
    return $driver;
};

$driver = $fresh();
$result = glpichat_desktop_transaction(static function () use ($driver): string {
    $driver->values = ['followup', 'mirror', 'receipt'];
    return 'confirmed';
});
transaction_check($result === 'confirmed' && $driver->committed === ['followup', 'mirror', 'receipt'], 'Success returns only after the outermost driver commit.');
transaction_check(!$driver->active && $driver->calls === ['begin', 'commit'], 'Top-level action owns exactly one physical transaction.');

$driver = $fresh();
$original = new LogicException('mirror failure');
try {
    glpichat_desktop_transaction(static function () use ($driver, $original): never {
        $driver->values = ['followup'];
        throw $original;
    });
    throw new RuntimeException('Expected action failure.');
} catch (LogicException $error) { transaction_check($error === $original, 'Action exception is preserved.'); }
transaction_check($driver->values === [] && $driver->committed === [] && $driver->calls === ['begin', 'rollback'], 'Failed action leaves no partial rows or commit.');

$driver = $fresh();
$driver->failNext = 'begin';
$called = false;
try {
    glpichat_desktop_transaction(static function () use (&$called): void { $called = true; });
    throw new LogicException('Expected begin failure.');
} catch (RuntimeException $error) { transaction_check($error->getMessage() === 'Failed to start transaction.', 'Real core begin failure is propagated.'); }
transaction_check(!$called && $driver->calls === ['begin'], 'Failed begin invokes neither callback nor rollback.');

$driver = $fresh();
$driver->failNext = 'commit';
try {
    glpichat_desktop_transaction(static function () use ($driver): void { $driver->values = ['uncommitted']; });
    throw new LogicException('Expected commit failure.');
} catch (RuntimeException $error) { transaction_check($error->getMessage() === 'Failed to commit transaction.', 'Real core commit failure is propagated.'); }
transaction_check($driver->values === [] && !$driver->active && $driver->calls === ['begin', 'commit', 'rollback'], 'Failed commit rolls back the owned boundary.');

$driver = $fresh();
$driver->failNext = 'rollback';
try {
    glpichat_desktop_transaction(static function () use ($original): never { throw $original; });
    throw new RuntimeException('Expected original action failure.');
} catch (LogicException $error) { transaction_check($error === $original, 'Rollback failure never replaces the original action error.'); }
transaction_check($driver->calls === ['begin', 'rollback'] && $driver->active, 'Rollback failure is not reported as successful cleanup.');

// A caller-owned transaction must not be physically committed or discarded.
$driver = $fresh();
$DB->beginTransaction();
$driver->values = ['caller'];
glpichat_desktop_transaction(static function () use ($driver): void { $driver->values[] = 'nested'; });
transaction_check($driver->active && $driver->committed === [] && $driver->values === ['caller', 'nested'], 'Nested success releases a savepoint without publishing caller data.');
transaction_check($driver->calls === ['begin', 'savepoint:savepoint_0', 'release:savepoint_0'], 'Nested success follows real core savepoint naming and release.');
$DB->rollBack();
transaction_check($driver->values === [] && !$driver->active, 'Caller can still roll back all nested work.');

$driver = $fresh();
$DB->beginTransaction();
$driver->values = ['caller'];
try {
    glpichat_desktop_transaction(static function () use ($driver, $original): never { $driver->values[] = 'failed-nested'; throw $original; });
    throw new RuntimeException('Expected nested failure.');
} catch (LogicException $error) { transaction_check($error === $original, 'Nested action preserves its original error.'); }
transaction_check($driver->values === ['caller'] && $driver->active && $driver->committed === [], 'Nested failure preserves preexisting caller work.');
transaction_check($driver->calls === ['begin', 'savepoint:savepoint_0', 'rollback-to:savepoint_0'], 'Actual core rollback-to SQL reaches only the driver boundary.');
$DB->commit();
transaction_check($driver->committed === ['caller'] && !$driver->active, 'Caller can commit after nested rollback; core nesting stays balanced.');

$driver = $fresh();
$DB->beginTransaction();
$driver->values = ['caller'];
$driver->failNext = 'savepoint:savepoint_0';
$called = false;
try {
    glpichat_desktop_transaction(static function () use (&$called): void { $called = true; });
    throw new LogicException('Expected savepoint failure.');
} catch (RuntimeException $error) { transaction_check($error->getMessage() === 'Failed to start transaction.', 'Savepoint creation failure is propagated.'); }
transaction_check(!$called && $driver->active && $driver->values === ['caller'], 'Failed savepoint creation does not touch caller work.');
$DB->commit();
transaction_check($driver->committed === ['caller'], 'Failed savepoint does not advance core nesting.');

// GLPI native writers may open balanced nested boundaries inside our action.
$driver = $fresh();
glpichat_desktop_transaction(static function () use ($driver): void {
    global $DB;
    $driver->values[] = 'receipt';
    $DB->beginTransaction();
    $driver->values[] = 'native-followup';
    $DB->commit();
    $driver->values[] = 'mirror';
});
transaction_check($driver->committed === ['receipt', 'native-followup', 'mirror'], 'Balanced native nested work commits atomically with the outer action.');
transaction_check($driver->calls === ['begin', 'savepoint:savepoint_0', 'release:savepoint_0', 'commit'], 'Native inner commit cannot publish before the enclosing action ends.');

echo "PASS desktop transaction/core boundary: $checks assertions; unchanged GLPI11.0.7 methods, driver fixture only, no database execution.\n";
