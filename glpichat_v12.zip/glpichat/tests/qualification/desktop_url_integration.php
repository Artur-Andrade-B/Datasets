<?php

declare(strict_types=1);

/**
 * Request integration regression using the actual Symfony HttpFoundation
 * v6.4.35 source pinned by GLPI 11.0.7. Config/DB storage are explicit fixtures.
 * No GLPI bootstrap, session, network request, or database connection is made.
 * Usage: php desktop_url_integration.php /path/to/actual-symfony/autoload.php
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
if ($argc !== 2 || !is_file($argv[1]) || !is_readable($argv[1])) {
    fwrite(STDERR, "Usage: desktop_url_integration.php ACTUAL_SYMFONY_AUTOLOADER\n");
    exit(2);
}
require $argv[1];

use Symfony\Component\HttpFoundation\Request;

if (!class_exists(Request::class)) {
    throw new RuntimeException('Actual Symfony Request dependency is required; no fallback fixture is permitted.');
}
$requestSource = (new ReflectionClass(Request::class))->getFileName();
if (!is_string($requestSource)
    || hash_file('sha256', $requestSource) !== 'e9d530ffb9e0460245a67b497ac0e827d30f6321a0a07b62904b76f77eb82f30') {
    throw new RuntimeException('This regression requires unchanged official HttpFoundation v6.4.35 Request.php, as pinned by GLPI 11.0.7.');
}

final class Config
{
    public static array $values = [
        'desktop_enabled' => '1',
        'desktop_schema_version' => '1',
        'desktop_idempotency_key' => 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
    ];
    public static function getConfigurationValues(string $context): array
    {
        if ($context !== 'plugin:glpichat') { throw new RuntimeException('Unexpected configuration context.'); }
        return self::$values;
    }
    public static function getConfigurationValue(string $context, string $key): mixed
    {
        if ($context !== 'plugin:glpichat') {
            throw new RuntimeException('Unexpected configuration context.');
        }
        return self::$values[$key] ?? null;
    }
    public static function setConfigurationValues(string $context, array $values): never
    {
        throw new RuntimeException('Request-derived addresses must never be persisted.');
    }
}

require dirname(__DIR__, 2) . '/src/desktop/common.php';
require dirname(__DIR__, 2) . '/src/desktop/auth.php';

$assertions = 0;
function url_assert(bool $condition, string $message): void
{
    global $assertions;
    ++$assertions;
    if (!$condition) {
        throw new RuntimeException($message);
    }
}
function url_reject(callable $action, string $code, int $status, string $message): void
{
    try {
        $action();
    } catch (GlpichatDesktopException $error) {
        url_assert($error->errorCode === $code && $error->httpStatus === $status, $message);
        return;
    }
    throw new RuntimeException($message . ': expected rejection did not occur.');
}
function url_request(string $prefix = '/glpi', array $server = [], array $cookies = []): Request
{
    return new Request([], [], [], $cookies, [], array_replace([
        'REQUEST_METHOD' => 'POST',
        'REQUEST_URI' => $prefix . '/plugins/glpichat/Desktop/V1/Pairings',
        'SCRIPT_FILENAME' => '/srv/glpi/public/index.php',
        'SCRIPT_NAME' => $prefix . '/index.php',
        'PHP_SELF' => $prefix . '/index.php',
        'SERVER_NAME' => 'helpdesk.example.test',
        'HTTP_HOST' => 'helpdesk.example.test',
        'SERVER_PORT' => 443,
        'HTTPS' => 'on',
        'REMOTE_ADDR' => '198.51.100.10',
    ], $server));
}
function url_reset(): void
{
    global $CFG_GLPI;
    $CFG_GLPI = [];
    Request::setTrustedProxies([], 0);
    Request::setTrustedHosts([]);
    Config::$values['desktop_enabled'] = '1';
    Config::$values['desktop_schema_version'] = '1';
    glpichat_desktop_reset_request_context();
}

url_reset();
foreach ([null, '', 'http://old.example.test', 'https://wrong.example.test/other', 'not-a-url'] as $canonical) {
    $CFG_GLPI = $canonical === null ? [] : ['url_base' => $canonical];
    $before = $CFG_GLPI;
    $request = url_request();
    url_assert(glpichat_desktop_base_url($request) === 'https://helpdesk.example.test/glpi', 'Missing/stale/manual URL cannot override the current request.');
    glpichat_desktop_request_guard($request);
    url_assert(true, 'Enabled native HTTPS request must pass with missing or stale url_base.');
    url_assert($CFG_GLPI === $before, 'Automatic URL resolution must not alter global GLPI configuration.');
}

foreach (['', '/glpi', '/service/glpi'] as $prefix) {
    url_reset();
    $request = url_request($prefix);
    url_assert($request->getBasePath() === $prefix, 'Actual Symfony fixture must reproduce the GLPI front-controller base path.');
    url_assert(glpichat_desktop_base_url($request) === 'https://helpdesk.example.test' . $prefix, 'Automatic address must preserve the GLPI installation subpath.');
}
url_reset();
url_assert(glpichat_desktop_base_url(url_request('/glpi', ['HTTP_HOST' => 'HELPDESK.EXAMPLE.TEST:443'])) === 'https://helpdesk.example.test/glpi', 'Default HTTPS port and host case must normalize.');
url_assert(glpichat_desktop_base_url(url_request('/glpi', ['HTTP_HOST' => 'helpdesk.example.test:8443', 'SERVER_PORT' => 8443])) === 'https://helpdesk.example.test:8443/glpi', 'Nonstandard HTTPS port must be retained.');
url_assert(glpichat_desktop_base_url(url_request('', ['HTTP_HOST' => '[2001:db8::10]:8443', 'SERVER_PORT' => 8443])) === 'https://[2001:db8::10]:8443', 'IPv6 authority must remain bracketed.');
$CFG_GLPI['root_doc'] = '/glpi/';
url_assert(glpichat_desktop_base_url(url_request('')) === 'https://helpdesk.example.test/glpi', 'The root_doc already computed by GLPI is authoritative for its mount path.');
url_assert(glpichat_desktop_base_url(url_request('/glpi', ['HTTP_HOST' => 'second.example.test'])) === 'https://second.example.test/glpi', 'One request authority must not persist into the next request.');
url_assert(!array_key_exists('url_base', $CFG_GLPI), 'Resolving successive origins must not create a canonical URL setting.');

foreach (['//outside.example.test', 'https://outside.example.test', '/glpi?x=1', '/glpi#fragment', '/glpi\\other', '/glpi/../other', '/glpi/%2e%2e/other', "/glpi\nother"] as $badPath) {
    $CFG_GLPI = ['root_doc' => $badPath];
    url_reject(static fn() => glpichat_desktop_base_url(url_request()), 'invalid_request', 400, 'Unsafe root_doc must fail closed.');
}

url_reset();
$proxyHeaders = [
    'REMOTE_ADDR' => '192.0.2.20', 'HTTPS' => 'off', 'SERVER_PORT' => 80,
    'HTTP_HOST' => 'backend.internal',
    'HTTP_X_FORWARDED_PROTO' => 'https',
    'HTTP_X_FORWARDED_HOST' => 'public.example.test',
    'HTTP_X_FORWARDED_PORT' => '443',
    'HTTP_X_FORWARDED_PREFIX' => '/portal',
];
$untrusted = url_request('/glpi', $proxyHeaders);
url_assert(glpichat_desktop_base_url($untrusted) === 'http://backend.internal/glpi', 'Optional compatibility URL reflects the backend view without guessing trusted proxies.');
glpichat_desktop_request_guard($untrusted);
url_assert(true, 'HTTPS terminated upstream with backend HTTP does not block the native API.');
$forgedOnTls = url_request('/glpi', array_replace($proxyHeaders, ['HTTPS' => 'on', 'HTTP_HOST' => 'helpdesk.example.test', 'SERVER_PORT' => 443]));
url_assert(glpichat_desktop_base_url($forgedOnTls) === 'https://helpdesk.example.test/glpi', 'Untrusted forwarded host/prefix must not replace a direct HTTPS authority.');

Request::setTrustedProxies(['192.0.2.20'], Request::HEADER_X_FORWARDED_PROTO | Request::HEADER_X_FORWARDED_HOST | Request::HEADER_X_FORWARDED_PORT | Request::HEADER_X_FORWARDED_PREFIX);
$trusted = url_request('/glpi', $proxyHeaders);
url_assert(glpichat_desktop_base_url($trusted) === 'https://public.example.test/portal/glpi', 'Existing trusted proxy rules must preserve external HTTPS authority and prefix.');
glpichat_desktop_request_guard($trusted);
url_assert(true, 'Trusted proxy HTTPS request passes the production native request guard.');
Request::setTrustedProxies(['192.0.2.20'], Request::HEADER_X_FORWARDED_PROTO);
url_assert(glpichat_desktop_base_url(url_request('/glpi', $proxyHeaders)) === 'https://backend.internal/glpi', 'Untrusted forwarded header categories must remain ignored, even from an otherwise trusted proxy.');

url_reset();
Request::setTrustedHosts(['^helpdesk\\.example\\.test$']);
url_reject(static fn() => glpichat_desktop_base_url(url_request('/glpi', ['HTTP_HOST' => 'outside.example.test'])), 'invalid_request', 400, 'GLPI/Symfony trusted-host rejection must be preserved.');
Request::setTrustedHosts([]);
foreach (['bad/host', 'user@outside.example.test', 'good.example.test, outside.example.test'] as $badHost) {
    url_reject(static fn() => glpichat_desktop_base_url(url_request('/glpi', ['HTTP_HOST' => $badHost])), 'invalid_request', 400, 'Invalid authority must be rejected by actual Symfony host parsing.');
}
Request::setTrustedProxies(['192.0.2.20'], Request::HEADER_FORWARDED | Request::HEADER_X_FORWARDED_PROTO | Request::HEADER_X_FORWARDED_HOST);
$conflict = url_request('/glpi', array_replace($proxyHeaders, ['HTTP_FORWARDED' => 'proto=http;host=other.example.test']));
url_reject(static fn() => glpichat_desktop_base_url($conflict), 'invalid_request', 400, 'Conflicting trusted proxy headers must become a controlled rejection.');
glpichat_desktop_request_guard(url_request('/glpi', array_replace($proxyHeaders, ['HTTP_FORWARDED' => 'proto=http;host=other.example.test'])));
url_assert(true, 'Native request guard must not reconstruct an origin that its operation does not need.');

url_reset();
$_SERVER = url_request('/glpi')->server->all();
$_GET = $_POST = $_COOKIE = $_FILES = [];
url_assert(glpichat_desktop_base_url() === 'https://helpdesk.example.test/glpi', 'Legacy front/config calls must resolve from actual Request::createFromGlobals().');
foreach ([url_request('/glpi', ['HTTP_ORIGIN' => 'https://helpdesk.example.test']), url_request('/glpi', [], ['session' => 'fixture'])] as $extraHeaders) {
    glpichat_desktop_request_guard($extraHeaders);
    url_reject(static fn() => glpichat_desktop_bearer($extraHeaders), 'invalid_credential', 401, 'Origin and cookies neither block valid API use nor substitute for credentials.');
}
Config::$values['desktop_enabled'] = '0';
glpichat_desktop_reset_request_context();
url_reject(static fn() => glpichat_desktop_request_guard(url_request()), 'unavailable', 404, 'Automatic URL must not implicitly enable the adapter.');
Config::$values['desktop_enabled'] = '1';
Config::$values['desktop_schema_version'] = null;
glpichat_desktop_reset_request_context();
url_reject(static fn() => glpichat_desktop_request_guard(url_request()), 'schema_unavailable', 503, 'Automatic URL must not bypass the schema gate.');

// Pairing executes the actual production function; only DB storage is modeled.
final class UrlPairingDatabase
{
    public array $queries = [];
    public array $inserted = [];
    public function escape(string $value): string { return addslashes($value); }
    public function doQuery(string $sql): object|bool
    {
        $this->queries[] = $sql;
        if ($sql === "SELECT GET_LOCK('glpichat.desktop.pair.v1',0) AS acquired") {
            return (object) ['rows' => [['acquired' => '1']]];
        }
        if ($sql === "SELECT RELEASE_LOCK('glpichat.desktop.pair.v1') AS released") {
            return (object) ['rows' => [['released' => '1']]];
        }
        if (str_starts_with($sql, 'SELECT COUNT(*) AS n FROM glpi_plugin_glpichat_desktopdevices WHERE ')) {
            return (object) ['rows' => [['n' => '0']]];
        }
        if (str_starts_with($sql, "DELETE FROM glpi_plugin_glpichat_desktopdevices WHERE status IN ('pending','approved') AND pairing_expires_at<")) {
            return true;
        }
        throw new RuntimeException('Unexpected query in pairing fixture.');
    }
    public function fetchAssoc(object $result): array|null { return array_shift($result->rows); }
    public function insert(string $table, array $data): bool
    {
        url_assert($table === 'glpi_plugin_glpichat_desktopdevices', 'Pairing may insert only its device request.');
        $this->inserted[] = $data;
        return true;
    }
}
url_reset();
$CFG_GLPI = ['root_doc' => '/glpi', 'url_base' => 'https://wrong.example.test/other'];
$DB = new UrlPairingDatabase();
$input = ['device_id' => 'e51eb14b-f690-4879-8f80-39ef53ca50c1', 'device_name' => 'Fixture PC', 'windows_login' => 'EXAMPLE\\fixture', 'poll_secret' => str_repeat('b', 64)];
$pair = glpichat_desktop_pair_start($input, '198.51.100.10', url_request());
url_assert(preg_match('/\A[a-f0-9]{32}\z/', $pair['pairing_id']) === 1, 'Pairing must retain its actual random identifier contract.');
url_assert($pair['verification_path'] === 'plugins/glpichat/front/desktop.php?pairing=' . $pair['pairing_id'], 'Pairing returns an origin-independent path relative to the GLPI installation.');
url_assert(count($DB->inserted) === 1 && $DB->inserted[0]['pairing_id'] === $pair['pairing_id'], 'The approval URI must identify the actual inserted pairing request.');
$DB = new UrlPairingDatabase();

$pair = glpichat_desktop_pair_start($input, '198.51.100.10', $untrusted);
url_assert($pair['verification_path'] === 'plugins/glpichat/front/desktop.php?pairing=' . $pair['pairing_id'], 'Pairing behind HTTPS termination keeps the same host-independent approval path.');
url_assert(count($DB->inserted) === 1, 'Backend HTTP creates a real pending pairing instead of rejecting deployment layout.');
url_assert(!str_contains($pair['verification_path'], 'backend.internal') && !str_contains($pair['verification_path'], 'wrong.example.test'), 'Approval path cannot redirect to an internal or stale configured host.');

Request::setTrustedProxies([], 0);
Request::setTrustedHosts([]);
echo "PASS: $assertions assertions using unchanged Symfony HttpFoundation v6.4.35; optional compatibility URL, proxy boundaries, native guards and relative production pairing path. Configuration/DB are fixtures; no deployed GLPI, database, browser or Windows runtime qualification.\n";
