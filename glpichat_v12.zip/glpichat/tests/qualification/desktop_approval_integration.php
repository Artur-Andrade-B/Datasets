<?php

declare(strict_types=1);

/**
 * CLI boundary regression: actual plugin approval script/common, actual Symfony
 * Request, unchanged GLPI 11.0.7 CheckCsrfListener and unchanged extracted core
 * CSRF methods. Database, login session, event container and route classification
 * are explicit fixtures. This does not boot GLPI or prove deployed routing.
 * Usage: php desktop_approval_integration.php PLUGIN_ROOT SYMFONY_AUTOLOAD
 *        CORE_CHECK_CSRF_LISTENER CORE_SESSION
 */
namespace Symfony\Component\EventDispatcher {
    interface EventSubscriberInterface { public static function getSubscribedEvents(): array; }
}
namespace Symfony\Component\HttpKernel {
    final class KernelEvents { public const CONTROLLER = 'kernel.controller'; }
}
namespace Symfony\Component\HttpKernel\Event {
    final class ControllerEvent
    {
        public function __construct(private \Symfony\Component\HttpFoundation\Request $request) {}
        public function getRequest(): \Symfony\Component\HttpFoundation\Request { return $this->request; }
        public function isMainRequest(): bool { return true; }
    }
}
namespace Glpi\Http {
    final class SessionManager
    {
        // Models only the exact plugin registration; not a replacement for the
        // deployed core router or SessionManager qualification.
        public function isResourceStateless(\Symfony\Component\HttpFoundation\Request $request): bool
        {
            $path = $request->getPathInfo();
            return preg_match('#/plugins/glpichat/Desktop/V1(?:/|$)#', $path) === 1;
        }
    }
}
namespace {
    if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
    if ($argc !== 5) { fwrite(STDERR, "Usage: desktop_approval_integration.php PLUGIN_ROOT SYMFONY_AUTOLOAD CORE_CHECK_CSRF_LISTENER CORE_SESSION\n"); exit(2); }
    [$unused, $sourceRoot, $autoload, $listenerPath, $sessionPath] = $argv;
    require $autoload;
    if (hash_file('sha256', $listenerPath) !== '286dd203828520cd6f1acb6cb6c6d4c2b720f4129ace6fd2fc2ed3bf9ac81106'
        || hash_file('sha256', $sessionPath) !== '57e6ff9d5186635875cf3fb48a8a603ca24c313363e25348ef8ac224d23807c9') {
        throw new RuntimeException('This regression requires unchanged GLPI 11.0.7 CheckCsrfListener.php and Session.php.');
    }
    $checks = 0;
    function approval_check(bool $condition, string $message): void
    {
        ++$GLOBALS['checks'];
        if (!$condition) { throw new RuntimeException($message); }
    }
    function __(string $text): string { return $text; }
    final class AccessDeniedHttpException extends RuntimeException { public function setMessageToDisplay(string $text): void {} }
    final class Toolbox { public static array $logs = []; public static function logInFile(string $file, string $message): void { self::$logs[] = $file; } }
    final class Config
    {
        public static function getConfigurationValues(string $context): array
        {
            return ['desktop_enabled' => '1', 'desktop_schema_version' => '1', 'desktop_idempotency_key' => str_repeat('a', 64)];
        }
    }

    // Extract complete, unchanged methods from versioned primary core source.
    // The surrounding Session fixture provides only login state and the same
    // core token-count constant; core validation/token-consumption logic runs.
    $coreSession = file_get_contents($sessionPath);
    $methods = '';
    foreach (['getNewCSRFToken', 'cleanCSRFTokens', 'validateCSRF', 'checkCSRF'] as $method) {
        $offset = strpos($coreSession, 'public static function ' . $method . '(');
        if ($offset === false) { throw new RuntimeException('Missing actual core method ' . $method); }
        $tokens = token_get_all('<?php ' . substr($coreSession, $offset));
        array_shift($tokens);
        $text = '';
        $depth = 0;
        $opened = false;
        foreach ($tokens as $token) {
            $text .= is_array($token) ? $token[1] : $token;
            if ($token === '{') { ++$depth; $opened = true; }
            if ($token === '}' && --$depth === 0 && $opened) { break; }
        }
        if (!$opened || $depth !== 0) { throw new RuntimeException('Cannot extract core method.'); }
        $methods .= $text . "\n";
    }
    eval('final class Session { private const CSRF_MAX_TOKENS = 500; public static bool $authenticated = true; public static int $loginChecks = 0; public static function checkLoginUser(): void { ++self::$loginChecks; if (!self::$authenticated) { throw new AccessDeniedHttpException("Login required"); } } public static function getLoginUserID(): int { return self::$authenticated ? 7 : 0; } ' . $methods . '}');
    require $listenerPath;
    $listener = new \Glpi\Kernel\Listener\ControllerListener\CheckCsrfListener(new \Glpi\Http\SessionManager());
    approval_check(str_contains(file_get_contents($sourceRoot . '/setup.php'), "registerPluginStatelessPath('glpichat', '#^/Desktop/V1(?:/|$)#')"), 'Plugin stateless registration must remain restricted to native routes.');

    $temporary = sys_get_temp_dir() . '/glpichat-approval-' . bin2hex(random_bytes(8));
    $plugin = $temporary . '/plugins/glpichat';
    foreach ([$temporary . '/inc', $plugin . '/front', $plugin . '/src/desktop'] as $directory) { mkdir($directory, 0700, true); }
    copy($sourceRoot . '/front/desktop.php', $plugin . '/front/desktop.php');
    copy($sourceRoot . '/src/desktop/common.php', $plugin . '/src/desktop/common.php');
    file_put_contents($temporary . '/inc/includes.php', '<?php // Explicit core-bootstrap fixture.');
    // GLPI11 defines its root before dispatching a legacy front script.
    define('GLPI_ROOT', $temporary);
    file_put_contents($plugin . '/src/desktop/auth.php', <<<'AUTH'
<?php
const GLPICHAT_DESKTOP_DEVICES_TABLE = 'glpi_plugin_glpichat_desktopdevices';
function glpichat_desktop_auth_hex(string $value, int $length): bool { return preg_match('/\A[a-f0-9]{' . $length . '}\z/D', $value) === 1; }
function glpichat_desktop_auth_one(string $sql): array {
    if (str_starts_with($sql, 'SELECT name FROM glpi_users')) { return ['name' => 'fixture.user']; }
    return ['pairing_id' => $_GET['pairing'], 'user_code' => '12345678', 'device_name' => 'Fixture PC', 'windows_login' => 'EXAMPLE\\fixture.user', 'status' => 'pending', 'pairing_expires_at' => '2099-01-01 00:00:00', 'users_id' => 0];
}
function glpichat_desktop_pair_approve(string $pair, int $user, int $profile, int $entity): void { $GLOBALS['approvals'][] = [$pair, $user, $profile, $entity]; }
function glpichat_desktop_revoke_user_device(int $device, int $user): void { $GLOBALS['revocations'][] = [$device, $user]; }
AUTH);
    final class ApprovalDBFixture
    {
        public function escape(string $value): string { return addslashes($value); }
        public function doQuery(string $sql): object { return (object) ['rows' => []]; }
        public function fetchAssoc(object $result): mixed { return array_shift($result->rows); }
    }
    $DB = new ApprovalDBFixture();
    $CFG_GLPI = ['root_doc' => '/glpi'];
    $_SESSION = ['glpiname' => 'fixture.user', 'glpiactiveprofile' => ['id' => 4], 'glpiactive_entity' => 2];
    $cleanup = static function () use ($temporary): void {
        if (!is_dir($temporary)) { return; }
        foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($temporary, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $entry) {
            $entry->isDir() ? rmdir($entry->getPathname()) : unlink($entry->getPathname());
        }
        rmdir($temporary);
    };
    register_shutdown_function($cleanup);
    set_error_handler(static function (int $severity, string $message, string $file, int $line): bool {
        throw new ErrorException($message, 0, $severity, $file, $line);
    });
    $pair = str_repeat('a', 32);
    $run = static function (string $method, array $post = [], bool $authenticated = true, array $extraHeaders = []) use ($listener, $plugin, $pair): array {
        global $CFG_GLPI, $DB;
        $GLOBALS['approvals'] = $GLOBALS['revocations'] = [];
        Session::$authenticated = $authenticated;
        Session::$loginChecks = 0;
        if (function_exists('glpichat_desktop_reset_request_context')) { glpichat_desktop_reset_request_context(); }
        $_GET = ['pairing' => $pair];
        $_POST = $post;
        $_COOKIE = $_FILES = [];
        $_SERVER = array_replace(['REQUEST_METHOD' => $method, 'HTTPS' => 'off', 'SERVER_PORT' => 80, 'HTTP_HOST' => 'backend.internal', 'HTTP_X_FORWARDED_PROTO' => 'https', 'REQUEST_URI' => '/glpi/plugins/glpichat/front/desktop.php?pairing=' . $pair, 'SCRIPT_NAME' => '/glpi/index.php', 'SCRIPT_FILENAME' => '/srv/public/index.php', 'PHP_SELF' => '/glpi/index.php'], $extraHeaders);
        $request = \Symfony\Component\HttpFoundation\Request::createFromGlobals();
        $blocked = false;
        ob_start();
        try {
            $listener->onKernelController(new \Symfony\Component\HttpKernel\Event\ControllerEvent($request));
            include $plugin . '/front/desktop.php';
        } catch (AccessDeniedHttpException) { $blocked = true; }
        $html = ob_get_clean();
        return ['html' => $html, 'blocked' => $blocked, 'approved' => $GLOBALS['approvals'], 'revoked' => $GLOBALS['revocations']];
    };
    try {
        $page = $run('GET');
        approval_check(GLPI_ROOT === $temporary && str_starts_with($page['html'], '<!doctype html>'), 'Existing GLPI root is preserved and approval output starts with its doctype without warnings.');
        approval_check(!$page['blocked'] && str_contains($page['html'], 'Confirmar conexão deste computador'), 'Authenticated approval page renders behind HTTPS termination.');
        approval_check(str_contains($page['html'], 'name="_glpi_csrf_token"') && !str_contains($page['html'], '_desktop_csrf'), 'Approval form uses the standard GLPI CSRF token only.');
        approval_check(str_contains($page['html'], 'action="/glpi/plugins/glpichat/front/desktop.php?pairing=' . $pair), 'Form action preserves GLPI mount path without reconstructing a public origin.');
        approval_check(!isset($_SESSION['glpichat_desktop_csrf']), 'Rendering approval creates no second plugin CSRF token.');
        $valid = Session::getNewCSRFToken(true);
        $approved = $run('POST', ['desktop_action' => 'approve', 'pairing_id' => $pair, '_glpi_csrf_token' => $valid]);
        approval_check(!$approved['blocked'] && $approved['approved'] === [[$pair, 7, 4, 2]], 'Valid core token approves exact pairing without Origin, Referer or plugin token on backend HTTP.');
        approval_check(!isset($_SESSION['glpicsrftokens'][$valid]), 'Actual core validator consumes the standard form token.');
        $replay = $run('POST', ['desktop_action' => 'approve', 'pairing_id' => $pair, '_glpi_csrf_token' => $valid]);
        approval_check($replay['blocked'] && $replay['approved'] === [] && Session::$loginChecks === 0, 'Replayed core token is rejected before plugin approval executes.');
        foreach ([[], ['_glpi_csrf_token' => 'wrong']] as $token) {
            $bad = $run('POST', ['desktop_action' => 'approve', 'pairing_id' => $pair] + $token);
            approval_check($bad['blocked'] && $bad['approved'] === [] && Session::$loginChecks === 0, 'Missing/invalid core token is blocked before the plugin action.');
        }
        $mismatch = $run('POST', ['desktop_action' => 'approve', 'pairing_id' => str_repeat('b', 32), '_glpi_csrf_token' => Session::getNewCSRFToken(true)]);
        approval_check(!$mismatch['blocked'] && $mismatch['approved'] === [] && str_contains($mismatch['html'], 'class="error"'), 'A valid CSRF token cannot approve a pairing different from the displayed URL.');
        $revoked = $run('POST', ['desktop_action' => 'revoke', 'device_id' => '24', '_glpi_csrf_token' => Session::getNewCSRFToken(true)]);
        approval_check(!$revoked['blocked'] && $revoked['revoked'] === [[24, 7]], 'Revocation reaches the user-scoped service without origin guessing.');
        $loggedOut = $run('GET', [], false);
        approval_check($loggedOut['blocked'] && $loggedOut['approved'] === [], 'Normal authenticated-session requirement remains in force.');
        echo "PASS desktop approval: $checks assertions; actual front/common/Symfony/core CSRF listener and extracted CSRF methods; login/DB/router fixtures, no deployed GLPI qualification.\n";
    } finally { restore_error_handler(); $cleanup(); }
}
