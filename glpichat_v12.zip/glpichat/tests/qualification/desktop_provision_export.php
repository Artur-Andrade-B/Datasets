<?php

declare(strict_types=1);

/**
 * CLI-only integration: actual CSV mapping/export, grant issue and enrollment,
 * real temporary files; explicit fake core authority and SQL transaction layer.
 * Does not claim execution of GLPI boot, LDAP/SMB ACLs or a real MySQL commit.
 */
if (PHP_SAPI !== 'cli') { throw new RuntimeException('CLI only'); }
define('READ', 1); define('CREATE', 4);
define('GLPI_ROOT', dirname(__DIR__, 3));
class Auth { public const LDAP = 3; public const CAS = 5; public const X509 = 6; public const EXTERNAL = 4; }
class Ticket { public const READMY = 1; public const READALL = 1024; }
class ITILFollowup { public const SEEPUBLIC = 1; public const ADDMY = 4; public const ADDALLITEM = 4096; }
class Config
{
    public static function getConfigurationValues(string $context): array
    {
        return ['desktop_enabled' => '1', 'desktop_schema_version' => '2', 'desktop_idempotency_key' => str_repeat('a', 64)];
    }
}
require_once dirname(__DIR__) . '/fixtures/desktop_enrollment_db.php';
require_once dirname(__DIR__, 2) . '/src/desktop/common.php';
require_once dirname(__DIR__, 2) . '/src/desktop/auth.php';
require_once dirname(__DIR__, 2) . '/src/desktop/provision.php';

$assertions = 0;
$hostUmaskUnsupported = str_contains(php_uname(), 'Emscripten');
function export_assert(bool $condition, string $message): void
{
    global $assertions;
    if (!$condition) { throw new RuntimeException('FAIL: ' . $message); }
    ++$assertions;
}
function export_reject(callable $action, string $expectedText, string $message): void
{
    try { $action(); } catch (RuntimeException $error) {
        export_assert(str_contains($error->getMessage(), $expectedText), $message); return;
    }
    throw new RuntimeException('FAIL: missing rejection: ' . $message);
}
function export_fixture(): DesktopEnrollmentDB
{
    $database = new DesktopEnrollmentDB();
    // Canonical text form deliberately avoids stubbing GLPI's binary GUID converter.
    $database->tables['glpi_users'][0]['sync_field'] = '12345678-1234-1234-1234-1234567890ab';
    return $database;
}

$directory = sys_get_temp_dir() . '/glpichat-export-test-' . bin2hex(random_bytes(8));
if (!mkdir($directory, 0700)) { throw new RuntimeException('Cannot create temporary test directory'); }
try {
    $DB = export_fixture();
    $sid = 'S-1-5-21-111-222-333-1001';
    $csv = $directory . '/assignments.csv';
    file_put_contents($csv, "login,object_guid,windows_sid,computer_name\r\nemployee,12345678-1234-1234-1234-1234567890ab,$sid,office_pc\r\n");
    $rows = glpichat_desktop_provision_csv($csv);
    $assignments = glpichat_desktop_provision_assignments($rows, $DB->tables['glpi_authldaps'][0], null, null);
    export_assert(count($assignments) === 1 && $assignments[0]['users_id'] === 10, 'CSV anchor resolves the existing replicated account');
    export_assert($assignments[0]['profiles_id'] === 3 && $assignments[0]['entities_id'] === 1, 'Native authorized default context is assigned without browser session');
    export_assert(isset($assignments[0]['expected_identity']['sync_anchor']), 'Preflight identity is carried into locked grant issuance');

    $output = $directory . '/success';
    export_assert(!str_starts_with($output . '/', realpath(GLPI_ROOT) . '/'), 'Real export location is outside the configured GLPI root');
    $mask = umask();
    $summary = glpichat_desktop_provision_export($assignments, $output, 'https://glpi.example.test/service', 3600);
    export_assert(umask() === $mask, 'Export restores caller umask');
    $path = $output . '/' . $sid . '/OFFICE_PC.json';
    export_assert(is_file($path), 'Private export uses the Windows SID/computer path');
    export_assert((fileperms($output) & 0077) === 0 && (fileperms(dirname($path)) & 0077) === 0,
        'Both export directory levels block group and other traversal');
    if (!$hostUmaskUnsupported) {
        export_assert((fileperms($path) & 0077) === 0, 'Native file creation honors the private export umask');
    }
    $package = json_decode(file_get_contents($path), true, 32, JSON_THROW_ON_ERROR);
    export_assert($package['schema'] === 1 && $package['base_url'] === 'https://glpi.example.test/service'
        && $package['windows_sid'] === $sid && $package['computer_name'] === 'OFFICE_PC', 'Export contains the exact unattended-client delivery contract');
    export_assert($package['user_id'] === 10 && preg_match('/^[a-f0-9]{64}$/D', $package['subject_id']) === 1, 'Export binds account incarnation');
    export_assert(preg_match('/^[a-f0-9]{64}$/D', $package['secret']) === 1, 'Export carries a high-entropy bootstrap secret');
    export_assert(!str_contains(json_encode($summary, JSON_THROW_ON_ERROR), $package['secret'])
        && !isset($summary[0]['secret']) && !isset($summary[0]['grant_secret']), 'Administrative summary contains no enrollment secret');
    export_assert(count($DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE]) === 1
        && !str_contains(serialize($DB->tables), $package['secret']), 'Database commits one grant containing only the secret hash');

    $identity = glpichat_desktop_enroll(['grant_id' => $package['grant_id'], 'grant_secret' => $package['secret'],
        'windows_sid' => $package['windows_sid'], 'computer_name' => $package['computer_name'],
        'device_id' => '11111111-2222-4333-8444-555555555555', 'access_token' => str_repeat('b', 64), 'refresh_secret' => str_repeat('c', 64)]);
    export_assert($identity['user']['id'] === $package['user_id'] && $identity['user']['subject_id'] === $package['subject_id']
        && $identity['device']['auth_mode'] === 'managed', 'The exported file enrolls successfully through the real service');
    export_assert($DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE][0]['status'] === 'consumed'
        && count($DB->tables[GLPICHAT_DESKTOP_REGISTRATIONS_TABLE]) === 1, 'Enrollment consumes that exact exported grant');
    $originalHash = hash_file('sha256', $path);
    $writes = count($DB->writes);
    export_reject(static fn() => glpichat_desktop_provision_export($assignments, $output, 'https://glpi.example.test/service', 3600),
        'must be new', 'Existing output directory is refused before overwriting grants');
    export_assert(hash_file('sha256', $path) === $originalHash && count($DB->writes) === $writes, 'Rejected repeat export changes neither file nor database');

    $DB = export_fixture();
    // Reject the outer commit after the inner issuance savepoint and file write.
    $DB->failCommitDepth = 1;
    $failureOutput = $directory . '/failed';
    $failurePath = $failureOutput . '/' . $sid . '/OFFICE_PC.json';
    export_reject(static fn() => glpichat_desktop_provision_export($assignments, $failureOutput, 'https://glpi.example.test/service', 3600),
        'database commit', 'Database failure after writing the file reaches the export cleanup path');
    export_assert(!file_exists($failurePath), 'Failed export removes the file whose database transaction failed');
    export_assert(!$DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE] && !$DB->tables[GLPICHAT_DESKTOP_DEVICES_TABLE]
        && !$DB->snapshots, 'Failed export rolls back its grant and closes every transaction boundary');
    export_assert(umask() === $mask, 'Failed export also restores caller umask');
} finally {
    $items = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($directory, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($items as $item) {
        if ($item->isDir()) { rmdir($item->getPathname()); } else { unlink($item->getPathname()); }
    }
    rmdir($directory);
}
echo 'PASS desktop provisioning export: ' . $assertions . " assertions; real services/filesystem with explicit database fixture.\n";
if ($hostUmaskUnsupported) {
    echo "LIMIT: PHP WASM host filesystem does not apply PHP umask to file creation; private directory modes were verified, native file mode remains unverified.\n";
}
