<?php

declare(strict_types=1);

/**
 * Actual production controller -> common/auth/enrollment services, actual Symfony
 * Request and JsonResponse. Only the core container base/authority constants,
 * Config persistence and SQL/transaction boundary are fixtures. No service,
 * credential hash, enrollment or renewal function is replaced. This is not a
 * deployed GLPI/router/SQL test; core transactions have their own boundary suite.
 * Usage: php desktop_managed_controller_integration.php PLUGIN_ROOT AUTOLOAD
 */
namespace Glpi\Controller { abstract class AbstractController {} }
namespace {
    if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
    if ($argc !== 3) { fwrite(STDERR, "Usage: desktop_managed_controller_integration.php PLUGIN_ROOT AUTOLOAD\n"); exit(2); }
    [$unused, $plugin, $autoload] = $argv;
    require $autoload;
    define('READ', 1); define('CREATE', 4);
    class Auth { public const LDAP = 3; public const CAS = 5; public const X509 = 6; public const EXTERNAL = 4; }
    class Ticket { public const READMY = 1; public const READALL = 1024; }
    class ITILFollowup { public const SEEPUBLIC = 1; public const ADDMY = 4; public const ADDALLITEM = 4096; }
    class Config
    {
        public static array $values = ['desktop_enabled' => '1', 'desktop_schema_version' => '2', 'desktop_idempotency_key' => 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'];
        public static int $reads = 0;
        public static function getConfigurationValues(string $context): array { ++self::$reads; return self::$values; }
    }
    require $plugin . '/tests/fixtures/desktop_enrollment_db.php';
    require $plugin . '/src/Controller/DesktopController.php';
    $controller = new \GlpiPlugin\Glpichat\Controller\DesktopController();
    $assertions = 0;
    function managed_http_assert(bool $condition, string $message): void
    {
        ++$GLOBALS['assertions'];
        if (!$condition) { throw new RuntimeException($message); }
    }
    $call = static function (string $operation, string $method, mixed $data = null, ?string $token = null, array $headers = []) use ($controller): array {
        $server = array_replace(['REQUEST_METHOD' => $method, 'HTTPS' => 'off', 'SERVER_PORT' => 80,
            'HTTP_HOST' => 'backend.internal', 'HTTP_X_FORWARDED_PROTO' => 'https',
            'HTTP_ORIGIN' => 'https://another.example.test', 'CONTENT_TYPE' => 'application/json'], $headers);
        if ($token !== null) { $server['HTTP_AUTHORIZATION'] = 'Bearer ' . $token; }
        $request = new \Symfony\Component\HttpFoundation\Request([], [], [], ['GLPI_SESSION' => 'not-an-api-credential'], [], $server, is_string($data) ? $data : json_encode($data ?? new stdClass()));
        $response = $controller->dispatch($request, $operation);
        return [$response->getStatusCode(), json_decode($response->getContent(), true, 512, JSON_THROW_ON_ERROR), $response];
    };
    $fresh = static function (): array {
        global $DB;
        $DB = new DesktopEnrollmentDB();
        Config::$values['desktop_enabled'] = '1'; Config::$values['desktop_schema_version'] = '2';
        glpichat_desktop_reset_request_context();
        $grant = glpichat_desktop_grant_issue(['users_id' => 10, 'profiles_id' => 3, 'entities_id' => 1,
            'windows_sid' => 'S-1-5-21-111-222-333-1001', 'computer_name' => 'office-pc']);
        return [$grant, ['grant_id' => $grant['grant_id'], 'grant_secret' => $grant['grant_secret'],
            'device_id' => '11111111-2222-4333-8444-555555555555', 'windows_sid' => $grant['windows_sid'],
            'computer_name' => 'office-pc', 'access_token' => str_repeat('b', 64), 'refresh_secret' => str_repeat('c', 64)]];
    };
    [$grant, $input] = $fresh();
    $writesBefore = count($DB->writes);
    foreach ([['grant_secret' => str_repeat('d', 64)], ['windows_sid' => 'S-1-5-21-111-222-333-1002'], ['computer_name' => 'another-pc']] as $change) {
        [$status, $body] = $call('Enroll', 'POST', array_replace($input, $change));
        managed_http_assert($status === 401 && $body['error']['code'] === 'enrollment_unavailable', 'Wrong provisioning secret or delivery identity is denied by the real enrollment service');
        managed_http_assert(count($DB->writes) === $writesBefore && !$DB->tables[GLPICHAT_DESKTOP_DEVICES_TABLE], 'Rejected HTTP enrollment creates no device or consumed grant');
    }
    [$status, $body] = $call('Enroll', 'POST', array_replace($input, ['grant_secret' => ['bad']]));
    managed_http_assert($status === 400 && $body['error']['code'] === 'invalid_enrollment', 'Structured enrollment credential maps to an explicit client error');
    [$status, $body] = $call('Enroll', 'POST', '{broken');
    managed_http_assert($status === 400 && $body['error']['code'] === 'invalid_json', 'Malformed JSON is rejected before enrollment');
    Config::$reads = 0;
    [$status, $identity, $response] = $call('Enroll', 'POST', $input);
    managed_http_assert($status === 200 && $identity['user']['id'] === 10 && $identity['user']['subject_id'] === $grant['user']['subject_id'], 'Real enrollment dispatch returns the provisioned principal on backend HTTP');
    managed_http_assert($identity['device']['auth_mode'] === 'managed' && $identity['device']['grant_id'] === $grant['grant_id'] && $identity['device']['computer_name'] === 'OFFICE-PC', 'Serialized response preserves the complete managed identity contract');
    managed_http_assert(Config::$reads === 1, 'Guard and enrollment share one request configuration snapshot');
    managed_http_assert(count($DB->tables[GLPICHAT_DESKTOP_DEVICES_TABLE]) === 1 && count($DB->tables[GLPICHAT_DESKTOP_REGISTRATIONS_TABLE]) === 1 && !$DB->snapshots, 'HTTP enrollment commits exactly one device/registration and closes its transaction');
    managed_http_assert(!$response->headers->has('Access-Control-Allow-Origin') && str_contains($response->headers->get('Cache-Control'), 'no-store'), 'Request metadata relaxation grants no CORS access or response caching');
    foreach ([$grant['grant_secret'], $input['access_token'], $input['refresh_secret']] as $secret) {
        managed_http_assert(!str_contains($response->getContent(), $secret), 'Successful identity response never echoes provisioning or client-generated credentials');
    }
    $writesBefore = count($DB->writes);
    [$status, $replayed] = $call('Enroll', 'POST', $input);
    managed_http_assert($status === 200 && $replayed === $identity && count($DB->writes) === $writesBefore, 'A lost HTTP enrollment response is recoverable without another installation or credential mutation');
    [$status, $me] = $call('Me', 'GET', null, $input['access_token']);
    managed_http_assert($status === 200 && $me === $identity, 'The issued access credential works through actual authentication and Me dispatch');
    [$status, $missing] = $call('Me', 'GET');
    managed_http_assert($status === 401 && $missing['error']['code'] === 'invalid_credential', 'Cookie and Origin alone never authorize native account access');
    $DB->tables[GLPICHAT_DESKTOP_DEVICES_TABLE][0]['token_expires_at'] = '2020-01-01 00:00:00';
    [$status, $expired] = $call('Me', 'GET', null, $input['access_token']);
    managed_http_assert($status === 401 && $expired['error']['code'] === 'token_expired', 'Expired managed access remains distinguishable for automatic renewal');
    $renew = ['grant_id' => $input['grant_id'], 'device_id' => $input['device_id'], 'refresh_secret' => $input['refresh_secret'], 'access_token' => str_repeat('d', 64)];
    [$status, $renewed] = $call('Renew', 'POST', $renew);
    managed_http_assert($status === 200 && $renewed['user']['subject_id'] === $identity['user']['subject_id'] && $renewed['device']['id'] === $identity['device']['id'], 'Renewal after access expiry preserves installation and account identity');
    [$status, $old] = $call('Me', 'GET', null, $input['access_token']);
    managed_http_assert($status === 401, 'Renewal invalidates the old access credential');
    [$status, $new] = $call('Me', 'GET', null, $renew['access_token']);
    managed_http_assert($status === 200 && $new === $renewed, 'Renewed credential authenticates normally');
    $writesBefore = count($DB->writes);
    [$status, $replayed] = $call('Renew', 'POST', $renew);
    managed_http_assert($status === 200 && $replayed === $renewed && count($DB->writes) === $writesBefore, 'Lost renewal response replay does not extend expiry again');
    $DB->tables['glpi_users'][0]['is_active'] = 0;
    [$status, $denied] = $call('Renew', 'POST', array_replace($renew, ['access_token' => str_repeat('e', 64)]));
    managed_http_assert($status === 403 && $denied['error']['code'] === 'authorization_denied', 'Renewal still checks current account authority');
    $DB->tables['glpi_users'][0]['is_active'] = 1;
    [$status, $body] = $call('Revoke', 'POST', null, $renew['access_token']);
    managed_http_assert($status === 200 && $body['ok'], 'Authenticated revoke works through real controller and services');
    [$status, $body] = $call('Renew', 'POST', $renew);
    managed_http_assert($status === 403 && $body['error']['code'] === 'device_revoked', 'Revoked registration cannot be restored by renewal');
    [$grant, $input] = $fresh();
    $DB->failInsert = GLPICHAT_DESKTOP_REGISTRATIONS_TABLE;
    [$status, $body] = $call('Enroll', 'POST', $input);
    managed_http_assert($status === 503 && $body['error']['code'] === 'storage_unavailable', 'A registration-write failure returns a retryable enrollment failure');
    managed_http_assert(!$DB->tables[GLPICHAT_DESKTOP_DEVICES_TABLE] && !$DB->tables[GLPICHAT_DESKTOP_REGISTRATIONS_TABLE] && $DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE][0]['status'] === 'issued', 'Failed enrollment rolls back the partial device and preserves the unused grant');
    [$status] = $call('Enroll', 'POST', $input);
    managed_http_assert($status === 200, 'The identical request can retry after the storage failure');
    Config::$values['desktop_schema_version'] = '1';
    [$status, $body] = $call('Renew', 'POST', $renew);
    managed_http_assert($status === 503 && $body['error']['code'] === 'schema_unavailable', 'Schema1 chat compatibility cannot bypass managed schema2 readiness');
    Config::$values['desktop_enabled'] = '0';
    [$status, $body] = $call('Enroll', 'POST', $input);
    managed_http_assert($status === 404 && $body['error']['code'] === 'unavailable', 'Next dispatch observes disabled desktop configuration');
    echo "PASS managed controller: $assertions assertions; actual controller/common/auth/enrollment and Symfony Request/JsonResponse; SQL/config/core-container fixtures, no live GLPI/SQL execution.\n";
}
