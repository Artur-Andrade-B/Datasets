<?php

declare(strict_types=1);

/**
 * CLI-only bootstrap boundary: executes the actual copied front file until its
 * first core include. A sentinel stops before authentication/database/UI work.
 * Run each case in its own process because PHP constants cannot be undefined.
 * Usage: php desktop_front_bootstrap.php FRONT_PATH booted|direct
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
if ($argc !== 3 || !is_file($argv[1]) || !in_array($argv[2], ['booted', 'direct'], true)) {
    fwrite(STDERR, "Usage: desktop_front_bootstrap.php FRONT_PATH booted|direct\n");
    exit(2);
}
final class DesktopBootstrapReached extends RuntimeException {}
$temporary = sys_get_temp_dir() . '/glpichat-bootstrap-' . bin2hex(random_bytes(8));
$installedRoot = $temporary . '/plugin-install';
$bootedRoot = $temporary . '/existing-glpi-root';
$front = $installedRoot . '/plugins/glpichat/front/' . basename($argv[1]);
$expectedRoot = $argv[2] === 'booted' ? $bootedRoot : $installedRoot;
$cleanup = static function () use ($temporary): void {
    if (!is_dir($temporary)) { return; }
    foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($temporary, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $entry) {
        $entry->isDir() ? rmdir($entry->getPathname()) : unlink($entry->getPathname());
    }
    rmdir($temporary);
};
register_shutdown_function($cleanup);
foreach ([$installedRoot . '/inc', $bootedRoot . '/inc', dirname($front)] as $directory) { mkdir($directory, 0700, true); }
copy($argv[1], $front);
foreach ([$installedRoot, $bootedRoot] as $root) {
    file_put_contents($root . '/inc/includes.php', '<?php $GLOBALS["desktop_bootstrap_reached"] = dirname(__DIR__); throw new DesktopBootstrapReached();');
}
if ($argv[2] === 'booted') { define('GLPI_ROOT', $bootedRoot); }
set_error_handler(static function (int $severity, string $message, string $file, int $line): never {
    throw new ErrorException($message, 0, $severity, $file, $line);
});
ob_start();
try {
    try {
        include $front;
        throw new LogicException('Core include sentinel was not reached.');
    } catch (DesktopBootstrapReached) {}
    $output = ob_get_clean();
    if (GLPI_ROOT !== $expectedRoot || ($GLOBALS['desktop_bootstrap_reached'] ?? null) !== $expectedRoot || $output !== '') {
        throw new RuntimeException('Front bootstrap changed the root, included the wrong core or emitted output.');
    }
    echo 'PASS front bootstrap: ' . basename($argv[1]) . ' ' . $argv[2] . "; 3 assertions; actual front prefix, bootstrap sentinel only.\n";
} finally {
    if (ob_get_level() > 0) { ob_end_clean(); }
    restore_error_handler();
    $cleanup();
}
