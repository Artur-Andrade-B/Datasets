<?php

declare(strict_types=1);

/**
 * Actual controller + common + Symfony Request. Services/JSON response/container
 * are explicit fixtures to isolate dispatch, credentials, config refresh, status
 * mapping and response headers. This does not replace auth/conversation tests or
 * a deployed GLPI/DB qualification.
 * Usage: php desktop_controller_integration.php PLUGIN_ROOT SYMFONY_AUTOLOAD
 */
namespace Glpi\Controller { abstract class AbstractController {} }
namespace Symfony\Component\HttpFoundation {
    class Response
    {
        public HeaderBag $headers;
        public function __construct(public array $data, public int $status) { $this->headers = new HeaderBag(); }
    }
    class JsonResponse extends Response {}
}
namespace {
    if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
    if ($argc !== 3) { fwrite(STDERR, "Usage: desktop_controller_integration.php PLUGIN_ROOT SYMFONY_AUTOLOAD\n"); exit(2); }
    [$unused, $source, $autoload] = $argv;
    require $autoload;
    $checks = 0;
    function controller_check(bool $condition, string $message): void { ++$GLOBALS['checks']; if (!$condition) { throw new RuntimeException($message); } }
    final class Config
    {
        public static array $values = ['desktop_enabled' => '1', 'desktop_schema_version' => '1', 'desktop_idempotency_key' => 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'];
        public static int $reads = 0;
        public static function getConfigurationValues(string $context): array { ++self::$reads; return self::$values; }
    }
    $temp = sys_get_temp_dir() . '/glpichat-controller-' . bin2hex(random_bytes(8));
    mkdir($temp . '/src/Controller', 0700, true);
    mkdir($temp . '/src/desktop', 0700, true);
    copy($source . '/src/Controller/DesktopController.php', $temp . '/src/Controller/DesktopController.php');
    copy($source . '/src/desktop/common.php', $temp . '/src/desktop/common.php');
    file_put_contents($temp . '/src/functions.php', '<?php // Unused general helpers are outside this dispatch fixture.');
    file_put_contents($temp . '/src/desktop/auth.php', <<<'AUTH'
<?php
function glpichat_desktop_authenticate(string $token): array {
    ++$GLOBALS['authentication_calls'];
    if ($token !== str_repeat('a', 64)) { glpichat_desktop_fail('invalid_credential', 'Invalid fixture credential.', 401); }
    return ['users_id' => 7];
}
function glpichat_desktop_identity(array $actor): array { return ['user_id' => $actor['users_id']]; }
function glpichat_desktop_pair_start(array $data, string $ip, $request): array {
    ++$GLOBALS['pairing_calls']; return ['pairing_id' => str_repeat('b', 32), 'verification_path' => 'plugins/glpichat/front/desktop.php?pairing=' . str_repeat('b', 32)];
}
AUTH);
    file_put_contents($temp . '/src/desktop/conversations.php', <<<'SERVICES'
<?php
function glpichat_desktop_conversations(array $actor, int $before, int $limit): array {
    if ($GLOBALS['conversation_failure']) { throw new RuntimeException('Secret SQL and bearer fixture must not be disclosed.'); }
    return ['items' => [], 'before' => $before, 'limit' => $limit];
}
SERVICES);
    $cleanup = static function () use ($temp): void {
        if (!is_dir($temp)) { return; }
        foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($temp, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $entry) {
            $entry->isDir() ? rmdir($entry->getPathname()) : unlink($entry->getPathname());
        }
        rmdir($temp);
    };
    register_shutdown_function($cleanup);
    require $temp . '/src/Controller/DesktopController.php';
    $controller = new \GlpiPlugin\Glpichat\Controller\DesktopController();
    $GLOBALS['authentication_calls'] = $GLOBALS['pairing_calls'] = 0;
    $GLOBALS['conversation_failure'] = false;
    $request = static function (string $method = 'GET', ?string $credential = null, array $headers = [], array $query = []): \Symfony\Component\HttpFoundation\Request {
        $server = ['REQUEST_METHOD' => $method, 'HTTPS' => 'off', 'SERVER_PORT' => 80, 'HTTP_HOST' => 'backend.internal', 'HTTP_X_FORWARDED_PROTO' => 'https', 'HTTP_ORIGIN' => 'https://outside.example.test', 'HTTP_REFERER' => 'https://outside.example.test/page', 'CONTENT_TYPE' => 'application/json'];
        if ($credential !== null) { $server['HTTP_AUTHORIZATION'] = 'Bearer ' . $credential; }
        return new \Symfony\Component\HttpFoundation\Request($query, [], [], ['GLPI_SESSION' => 'irrelevant'], [], array_replace($server, $headers), '{}');
    };
    try {
        $good = $controller->dispatch($request('GET', str_repeat('a', 64)), 'Me');
        controller_check($good->status === 200 && $good->data['user_id'] === 7, 'Bearer identity succeeds on backend HTTP despite unrelated cookies/origin/referrer.');
        controller_check(Config::$reads === 1 && $GLOBALS['authentication_calls'] === 1, 'Controller reads configuration once and authenticates once.');
        controller_check(!$good->headers->has('Access-Control-Allow-Origin') && !$good->headers->has('Access-Control-Allow-Credentials'), 'Relaxing request metadata does not add CORS permission.');
        controller_check($good->headers->get('Cache-Control') === 'no-store, private', 'Credential-bearing response remains noncacheable.');
        $missing = $controller->dispatch($request(), 'Me');
        controller_check($missing->status === 401 && $missing->data['error']['code'] === 'invalid_credential', 'A GLPI cookie and Origin cannot authenticate native operations.');
        controller_check($missing->headers->has('WWW-Authenticate'), 'Missing native credentials retain bearer challenge.');
        $invalid = $controller->dispatch($request('GET', str_repeat('c', 64)), 'Me');
        controller_check($invalid->status === 401, 'Syntactically valid but unrecognized credential still rejects.');
        Config::$values['desktop_enabled'] = '0';
        $disabled = $controller->dispatch($request('GET', str_repeat('a', 64)), 'Me');
        controller_check($disabled->status === 404 && $disabled->data['error']['code'] === 'unavailable', 'Next controller request refreshes config and observes adapter disablement.');
        Config::$values['desktop_enabled'] = '1'; Config::$values['desktop_schema_version'] = '';
        $schema = $controller->dispatch($request('GET', str_repeat('a', 64)), 'Me');
        controller_check($schema->status === 503 && $schema->data['error']['code'] === 'schema_unavailable', 'Permissive admin saving does not allow runtime work on an unavailable schema.');
        Config::$values['desktop_schema_version'] = '1';
        $pair = $controller->dispatch($request('POST', null, ['HTTP_X_HTTP_METHOD_OVERRIDE' => 'DELETE']), 'Pairings');
        controller_check($pair->status === 201 && $GLOBALS['pairing_calls'] === 1, 'Dispatch follows the real POST method instead of a method-override header.');
        $badQuery = $controller->dispatch($request('GET', str_repeat('a', 64), [], ['limit' => ['unexpected']]), 'Conversations');
        controller_check($badQuery->status === 400 && $badQuery->data['error']['code'] === 'invalid_request', 'Malformed query input becomes a client error instead of generic server unavailability.');
        $GLOBALS['conversation_failure'] = true;
        $failed = $controller->dispatch($request('GET', str_repeat('a', 64)), 'Conversations');
        controller_check($failed->status === 503 && preg_match('/\A[a-f0-9]{12}\z/', $failed->data['error']['reference']) === 1, 'Unexpected service failure returns a usable diagnostic reference.');
        controller_check(!str_contains(json_encode($failed->data), 'Secret SQL') && $failed->headers->get('Retry-After') === '15', 'Failure response keeps secrets out and retains retry guidance.');
        echo "PASS desktop controller: $checks assertions; actual controller/common/Symfony Request, service/response fixtures; no deployed GLPI/DB qualification.\n";
    } finally { $cleanup(); }
}
