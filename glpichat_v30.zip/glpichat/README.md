# GLPI Chat — 1.9.8-desktop21

Plugin para GLPI 11.x / PHP 8.2+ com desktop Windows 0.9.11. Candidato de endurecimento com schema desktop **11 aditivo**, preservando subjects, credenciais, revogações, rascunhos e recuperação. Use uma versão GLPI 11.x corrigida e qualificada pela organização; compatibilidade técnica mínima não substitui manutenção de segurança.

Atualize **sem desinstalar** e conclua a migração antes do rollout Windows. Leia `docs/INSTALLATION_PT-BR.md` e `docs/releases/1.9.8-desktop21.md`. O ZIP de runtime contém somente `glpichat/`; desktop release e admin são entregues separadamente. Não distribua configuração de implantação, chaves ou credenciais nos pacotes.

Esta versão separa a sequência de publicação da telemetria de máquinas; aplica limites atômicos por usuário em mensagens/uploads e por máquina/SID na autorização automática; acrescenta prova CSRF às sessões de convidado; preserva mensagens e propostas durante esperas HTTP 429. Os limites usam janelas fixas do relógio do banco, sem promessa de janela móvel exata.

A integração automática exige usuários AD importados e autorizados no GLPI. Quem ainda aguarda sincronização continua tentando sem token manual ou limite total de tentativas. Novos usuários não precisam de login prévio no navegador quando a sincronização central está preparada. Usuários no mesmo PC e a mesma conta em PCs distintos mantêm conexões independentes; revogação explícita continua efetiva. A superfície de chat do navegador permanece desabilitada por padrão.

O ambiente pressupõe rede interna e AD administrado. Qualificação de capacidade, publisher, quarentena integral, HTTPS, assinatura Windows 1.0.0 e aceitação Kaspersky são gates posteriores; esta versão não declara sua conclusão.
