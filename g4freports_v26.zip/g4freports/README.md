# Relatórios G4F — 1.8.11

## Atualização 1.8.11

- SLA conciliado com a duração da base validada: tempo de solução positivo do GLPI; na ausência, tempo corrido desde a abertura menos espera geral quando positivo; caso contrário, tempo corrido. Clones preservam a abertura registrada. Prazos e calendários operacionais continuam na auditoria.
- INS5 desconsidera o evento de reabertura pelo mesmo solucionador integrante N1/N2/N3. Outra reabertura válida ou execução incompleta manual mantém o chamado contado. A auditoria discrimina os eventos e autores.
- INS6 aceita a categoria elegível com grupo N1 ou, quando não há grupo técnico atribuído, solucionador identificado com vínculo N1. Gráfico, cálculo e fórmulas usam o mesmo resultado.
- INS12 exibe fontes separadas, pesquisas “Não preenchida” e totais. GLPI + telefonia continua o padrão; somente GLPI permanece selecionável.
- Tabelas de ligações começam pela condição específica de INS7/8/9, com acesso à base completa. Totais visíveis não substituem o denominador do indicador.
- Legendas de gráficos circulares do Word e rótulos dos eixos corrigidos; mantidos gráficos editáveis e identidade G4F. Prioridade por nome e severidade contratual identificadas, conservando o código bruto na auditoria.
- Profissionais em ordem alfabética, busca, filtros e paginação. Duplicatas novas do mesmo vínculo são impedidas; vínculos distintos podem receber identificação própria.
- Remoções de profissionais e números de teste têm confirmação, desfazer e recuperação individual nas últimas dez versões salvas. O histórico registra o responsável e a data. O cálculo do INS10 permanece inalterado.
- Regras `ses-2026-09-23-v9`: gere novamente a competência depois da atualização.

Na conferência de junho, todos os 6.567 chamados puderam ser avaliados. INS4 reproduz **6.123 / 6.223 (98,39%)**, INS6 **4.601 / 5.381 (85,50%)** e INS11 por categoria **5.973 / 6.567**. A aplicação geral da exceção do INS5 desconsidera 13 chamados e resulta em **251 / 6.567**, diferente da exclusão manual de apenas um chamado na planilha histórica. São resultados da evidência fornecida, sem números fixos no cálculo.

Veja `VALIDACAO_1.8.11.md` para os testes, limites da validação e diferenças que dependem de decisões humanas. O histórico de versões anteriores permanece em `CHANGELOG.md`.

Plugin GLPI com dois fluxos: relatórios por profissional, obtidos pela API REST, e relatório mensal SES, obtido diretamente dos bancos GLPI/MariaDB e Asterisk/MySQL. O módulo SES gera Word editável em papel timbrado G4F e Excel a partir da mesma extração.

## Atualização

O pacote contém uma única pasta `g4freports/`.

1. Guarde uma cópia da pasta atual fora dos diretórios de plugins e mantenha o backup habitual do GLPI.
2. Substitua a pasta ativa `g4freports` pela pasta do pacote, preservando proprietário e permissões do servidor web. Evite manter outra cópia com o mesmo nome em `plugins` e `marketplace`.
3. Em **Configurar → Plugins**, execute a atualização indicada pelo GLPI e habilite o plugin. **Não desinstale para atualizar:** a desinstalação remove as configurações salvas.
4. Em **Configurar → Geral → Relatórios G4F**, confirme a identificação **Versão 1.8.11**, os campos API existentes e as duas seções de banco.
5. Em **Ferramentas → Relatórios G4F**, confirme o botão **Relatório mensal SES — Word e Excel** e gere novamente a competência desejada.

A instalação/atualização acrescenta somente configurações ausentes. Perfis e senhas existentes são preservados. Não são criadas tabelas de negócio nos bancos consultados. Composer, PHPWord e bibliotecas externas de planilhas não são necessários; o autoload e o papel timbrado já acompanham o pacote.

Se a versão ou os controles exibidos não corresponderem ao pacote, abra **Diagnóstico técnico**, ao final da configuração, ou o endereço relativo `plugins/g4freports/front/diagnostics.php`. A área administrativa informa a versão carregada, os caminhos dos arquivos e os hashes em disco, permitindo verificar qual cópia está em uso antes de alterar novamente a instalação.

## Conexões de banco

As fontes SQL do módulo SES são independentes dos perfis de API e da conexão do Metabase. Configure-as em **Configurar → Geral → Relatórios G4F**:

| Seção | Fonte |
| --- | --- |
| GLPI / MariaDB — Relatório mensal SES | Banco GLPI com chamados, prazos e evidências dos indicadores |
| Callcenter / MySQL — Telefonia | Banco Asterisk com `queue_log`; banco inicial `ipbx`, porta inicial `2210` |

Para cada fonte:

1. Preencha servidor, porta, banco e usuário; selecione **Habilitar conexão: Sim**. O auxiliar DBeaver aceita `jdbc:mysql://servidor:porta/banco` ou `jdbc:mariadb://servidor:porta/banco` e preenche apenas o endereço.
2. Informe a senha ou o nome de uma variável de ambiente disponível ao PHP do GLPI.
3. Configure TLS e os limites de tempo conforme o servidor. Em modo TLS, o certificado é verificado; o arquivo CA, quando informado, deve existir no servidor GLPI.
4. Clique em **Salvar configurações**, ao final da página, e depois em **Testar conexão** na seção correspondente.

O teste utiliza os valores salvos. A senha armazenada não reaparece no formulário: deixar em branco mantém o valor; preencher substitui; a opção de remoção apaga. As senhas usam a criptografia nativa do GLPI. Uma variável de ambiente configurada tem prioridade sobre a senha armazenada.

O PHP precisa da extensão `mysqli`, e o servidor GLPI precisa alcançar as duas fontes SQL. O acesso pelo DBeaver ou Metabase não comprova essa conectividade. Use contas com privilégios de leitura: o plugin executa consultas de leitura, mas o teste não certifica que a conta esteja impedida de escrever.

Abrir a configuração ou a tela SES não consulta as fontes SQL. A conexão ocorre ao testar ou gerar o relatório. Os relatórios por profissional continuam utilizando a API.

## Relatório mensal SES

1. Abra **Ferramentas → Relatórios G4F → Relatório mensal SES — Word e Excel**.
2. Escolha o mês, a entidade, os grupos atribuídos quando necessários e o identificador da fila. A entidade é exata, sem somar subentidades; grupos em branco abrangem todos os grupos dessa entidade. O filtro de fila procura o texto informado no nome da fila.
3. Revise **Critérios dos indicadores**, especialmente o mapeamento INS1–INS4, categorias/grupos N1, grupos N3 excluídos de INS3/INS4/INS6, artigos validados para INS11 e as fontes do INS12.
4. Complete os IDs manuais do INS5 e os textos gerenciais. Cadastre e salve os profissionais do INS10 e os números de teste antes da geração.
5. Clique em **Gerar relatório mensal**. Revise totais, indicadores, observações e as tabelas paginadas de chamados, ligações consideradas e testes excluídos.
6. Use **Exportar Word** e **Exportar Excel**. Ambos utilizam os mesmos dados e critérios preservados no rascunho.

O recorte dos chamados usa **data de solução (`solvedate`)**, inclusive chamados criados antes do mês. O intervalo começa no primeiro dia às 00:00 e termina no início do mês seguinte, sem incluir esse instante. Ligações usam a entrada na fila (`ENTERQUEUE`); eventos posteriores ao fim do mês são consultados para determinar o desfecho. O relatório usa horários locais da fonte. Para o SLA, o extrator confirma o fuso GLPI/entidade e verifica a compatibilidade da sessão SQL quando há campos `TIMESTAMP`; `DATETIME` não recebe conversão automática presumida. O fuso é necessário para a reconstrução de intervalos; um tempo de solução positivo armazenado continua utilizável sem reconstruir calendário. Esses critérios constam nos arquivos.

**Atualizar textos** altera título, análise, ações e observações sem consultar novamente as fontes. Alterar período, abrangência, critérios, o cadastro de profissionais ou a lista de testes exige gerar novamente. O rascunho é temporário, vinculado ao usuário e válido por até 24 horas; exporte os arquivos para manter o registro. Após atualizar para 1.8.11, gere novamente os rascunhos das regras anteriores (até v8) antes de atualizar textos ou exportar Word/Excel; seus dados JSON permanecem disponíveis durante a validade original. Uma nova extração reflete o estado atual dos bancos e pode diferir de um relatório antigo.

O Word contém o relatório gerencial editável com o timbre G4F e gráficos nativos. O Excel contém **18 abas**: `Painel Consolidado`, `INS1` a `INS12`, `Distribuição Temporal`, `Base de Dados`, `Base de Dados Ligações`, `Auditoria de exclusões` e `Metodologia`. Os gráficos usam os mesmos dados preservados dos indicadores; as séries do Excel apontam para células do próprio arquivo. As bases incluem todos os registros considerados na extração; a paginação da prévia não limita os dados exportados. Os indicadores apresentam suas evidências, critérios e situações de apuração. Gráficos de contagens não substituem as frações contratuais: a meta e o denominador permanecem informados. Pendência e não aplicável não viram resultado zero. A telefonia distingue abandono total, abandono até 30 segundos e abandono acima de 30 segundos usado pelo INS9.

O relatório usa pizza para tipos de chamados, roscas para composições, colunas para notas e barras horizontais para faixas de duração/espera, colunas para volumes diários (empilhadas por desfecho nas ligações) e barras para comparações de metas e prazos. Os percentuais das fatias representam a composição da população exibida; não substituem o percentual contratual. Quantidades exatas continuam disponíveis ao lado dos gráficos.

A paleta dos relatórios segue o manual G4F: marinho `#011224`, azul `#376BFF`, amarelo `#FFE554` e cinza claro `#DAE6F2`, com variantes do manual e tonalidades claras derivadas para fundos e mapas de calor. O timbre existente é preservado. Resultados, exceções e pendências continuam identificados por texto e números, além das cores.

Os gráficos nativos mantêm categorias e valores identificáveis nos dois formatos. Gere novos arquivos após atualizar: um arquivo anteriormente reparado pelo Office não recupera objetos removidos apenas com a atualização do plugin.

Os mapas de calor mostram volumes acumulados por hora e dia da semana no mês, com contagens em cada célula e intensidade relativa ao maior valor do próprio mapa. Não são médias por ocorrência do dia da semana nem avaliações de cumprimento de SLA. Chamados usam a data de solução; ligações usam a entrada na fila após excluir testes. Datas inválidas ou fora do mês não entram nas visualizações temporais e sua quantidade é informada. Os mapas são tabelas editáveis no Word e células com fórmulas e formatação condicional no Excel. As colunas temporais acrescentadas ao final das bases preservam o texto original da data e geram uma referência com precisão de segundos, evitando que o arredondamento de microssegundos transfira registros para a hora ou o mês seguinte. As colunas anteriores e as fórmulas dos indicadores são preservadas. A exportação continua sem refazer consultas; rascunhos das regras v9 podem ser reexportados durante sua validade.

## Conferência dos IDs do relatório

O grupo N1 inicial é **55**, conforme o catálogo fornecido da base GLPI do relatório. O ID **53** corresponde a **Suporte Técnico IPESS** nessa base. IDs são específicos de cada ambiente; uma seleção explícita continua sendo respeitada.

Ao gerar, o plugin consulta os nomes dos grupos selecionados, das categorias elegíveis e dos artigos informados pela mesma conexão GLPI usada nos chamados. Os IDs e nomes ficam na prévia, na metodologia do Word/Excel e no rascunho preservado. Grupos ou categorias selecionados que não existam na fonte produzem uma mensagem específica, evitando um resultado baseado em seleção inválida. Quando nenhum chamado elegível atende ao critério de grupo N1 ou ao complemento por solucionador, a observação identifica os grupos consultados e mantém o zero medido.

O campo **IDs dos grupos atribuídos** restringe toda a população; o campo **IDs dos grupos N1** classifica o numerador do INS6. Para corrigir N1, use o segundo. As 44 categorias elegíveis foram preservadas: associação atual a N1 ou grupo configurado na categoria não acrescenta automaticamente novas categorias elegíveis.

O INS11 exige **IDs de artigos** em sua lista validada. Categorias de chamados, categorias da base de conhecimento e artigos têm cadastros distintos. O plugin verifica a existência do artigo e mostra seu título, mas não infere aprovação por nome, categoria ou sinalização FAQ. Sem lista, sem acesso aos vínculos ou sem acesso ao catálogo de artigos, o modo por artigos fica pendente. A opção por categoria mede a associação entre categorias e não usa a lista de artigos; apresenta a situação normal de cumprimento da meta. Artigos inexistentes informados no modo por vínculos diretos são rejeitados com identificação dos IDs.

Na amostra de junho conferida, o critério atual com grupo 55 e complemento pelo solucionador resulta em **4.601 / 5.381 = 85,50455%** após excluir 58 chamados de categorias elegíveis com vínculo N3 no INS6; a associação por categoria resulta em **5.973 / 6.567 = 90,95477%** no INS11. Esses valores descrevem a amostra fornecida, não são números fixos do plugin e podem variar em outra extração ou escopo.

## Critérios gerais

- **INS3, INS4 e INS6:** retiram chamados com qualquer grupo N3 atualmente atribuído das duas parcelas. A atribuição simultânea a N1 não anula a exclusão. Os chamados permanecem na base completa e nos demais indicadores. A auditoria identifica os IDs excluídos por indicador; não some essas contagens como se fossem chamados distintos.
- **N3:** IDs iniciais conferidos no catálogo fornecido: `57, 58, 59, 60, 1663, 3294, 3300, 3304, 3306`. Podem ser ajustados no campo próprio e seus nomes são consultados na fonte. Essa seleção não reconstitui o histórico de escalonamento.
- **Categorias INS6:** mantidas as 44 categorias existentes, inclusive `162` (Instalação de Navegador), `149` (Outro problema com o computador) e `176` (Criar nova pasta em servidor ou rede). O nome completo consultado aparece na metodologia.
- **Percentuais e metas:** resultados do INS9 com duas casas decimais também nos rótulos percentuais do painel Excel. Metas máximas preservadas: INS5 **≤ 2,00%**, INS9 **≤ 5,00%**, INS10 **≤ 10,00%**.
- **INS12 e telefonia:** o padrão passa a incluir as pesquisas dos chamados GLPI e as pesquisas telefônicas. A opção **Somente chamados GLPI** preserva o cálculo anterior. A prévia e os dois relatórios identificam as fontes incluídas, suas contagens e o resultado agregado. O campo **INS12 · Acompanhamento das pesquisas de telefonia** permite registrar responsáveis, prazos e ações efetivamente definidos.

A consulta de pesquisas usa `tab_pesquisa.uniqueid = callid`, selecionando a resposta não nula mais recente por identificador, inclusive respostas posteriores ao mês. A contagem não duplica uma ligação que aparece em várias filas e aplica as exclusões de testes antes de contar. Abrange somente as ligações do recorte, não todas as pesquisas existentes na central. A base Excel preserva nota original, nota convertida pela regra existente, ID e data da pesquisa. Fonte indisponível resulta em quantidade indisponível, nunca em zero respostas. No modo padrão, o INS12 soma os numeradores e denominadores das duas fontes; no modo somente GLPI, as respostas telefônicas permanecem visíveis para conferência, sem participar da fração.

Os gráficos nativos, a paleta G4F e o timbre que já funcionavam são preservados. O pacote não altera tabelas ou registros nas duas fontes SQL. Após instalar, **gere novamente a competência** para aplicar as regras v9.

## INS12 — escolha das fontes

Na seção sempre visível **Como calcular os indicadores**, ao lado do seletor do INS11, use **INS12 · Fontes da pesquisa de satisfação**:

- **Chamados GLPI e pesquisas de telefonia — padrão:** `(favoráveis GLPI + favoráveis telefonia) / (válidas GLPI + válidas telefonia) × 100`.
- **Somente chamados GLPI:** `favoráveis GLPI / válidas GLPI × 100`, sem incluir a telefonia na fração.

Cada resposta válida tem o mesmo peso; não se calcula a média dos percentuais por fonte. São válidas as notas inteiras de 1 a 5. No GLPI, notas 4 e 5 são favoráveis. Na telefonia, preserva-se a conversão existente **nota considerada = 6 − nota original**; portanto notas originais **1 e 2** tornam-se **5 e 4** e são favoráveis. Notas ausentes ou inválidas ficam fora do denominador e são discriminadas na conferência. Não tornam, por si, o resultado das respostas válidas provisório.

Uma ligação que aparece em mais de uma fila contribui uma única vez. A linha com a primeira entrada nas filas selecionadas dentro do mês, com desempate pela chave ligação/fila, representa sua resposta nos detalhes e na distribuição diária. A consulta já seleciona a última resposta não nula por identificador. A apuração não tenta deduplicar uma resposta de chamado e uma resposta telefônica por pessoa: são registros de canais distintos, sem vínculo confiável entre eles.

A escolha fica preservada no rascunho e aparece na prévia, Word, Excel e metodologia. Alterar a opção exige gerar novamente. O campo de acompanhamento permite atualizar apenas o texto; não muda a escolha das fontes.

Se a telefonia for incluída e sua fonte de pesquisas estiver indisponível, o INS12 fica **pendente**, sem apresentar um resultado GLPI parcial como se fosse combinado. O modo somente GLPI continua calculável quando a fonte GLPI está disponível. Se ambas as fontes selecionadas estiverem acessíveis, mas não houver respostas válidas nem valores inválidos observados, o resultado é **N/A**, não zero nem aprovação automática.

Na amostra de junho: GLPI **619/739**, telefonia **46/46**, combinado **665/785 = 84,71%**. Em agosto: GLPI **537/629**, telefonia **29/29**, combinado **566/658 = 86,02%**. São valores das amostras fornecidas, não números fixos do plugin.

## Números de teste

Na área SES, abra **Números de teste excluídos da telefonia**. Administradores podem adicionar, editar ou remover números, informar sua identificação/motivo e ativar a exclusão. Clique em **Salvar números de teste** antes de gerar.

A correspondência usa exatamente os dígitos do número de origem após remover espaços e pontuação. Não acrescenta DDI, não compara apenas o final do número e não exclui ligações curtas automaticamente. Cadastre o número como aparece na origem registrada pela fila.

As ligações correspondentes ficam fora dos totais, INS7–INS9, médias e detalhes de telefonia considerados. A prévia permite consultar os testes excluídos, e os relatórios informam sua quantidade. A lista aplicada fica preservada com o rascunho: editar o cadastro não altera uma extração já gerada. A aba `Auditoria de exclusões` registra a lista aplicada, inclusive regras inativas, e as ligações excluídas com identificador, fila, origem e motivo. Esses registros não entram na base de ligações consideradas nem nos seus indicadores.

## Critérios aplicados

| Indicador | Comportamento desta versão |
| --- | --- |
| INS1–INS4 | Há dois mapeamentos explícitos: painel atual (`2, 3, 4, 5`) ou ordem do contrato (`5, 4, 3, 2`). A associação escolhida aparece no relatório. A meta segue a prioridade (2=8h, 3=6h, 4=4h, 5=2h), independentemente da numeração INS. A meta é comparada com a duração do relatório: `solve_delay_stat` positivo; senão, intervalo abertura–solução menos `waiting_duration` quando positivo; senão, intervalo abertura–solução. Prazos e calendários são conferências separadas na auditoria. O método é identificado por chamado. INS3 e INS4 excluem N3 de ambas as parcelas. INS4 exige vínculo técnico atual a N1 ou N2, sem limitar suas categorias às do INS6. INS1 e INS2 mantêm seu escopo. |
| Prazo ausente | Não exclui automaticamente o chamado. A apuração usa as demais evidências; somente casos sem evidência suficiente ficam pendentes, com motivo específico. O relatório mostra recorte elegível, avaliados e cobertura; somente falta de dados que impeça parte do cálculo torna o resultado parcial. Escolha de método e histórico de alterações não alteram por si sós a situação da meta. |
| INS5 | Usa chamados com pelo menos uma transição de solucionado/fechado para estado ativo não dispensada, unidos aos IDs de execução incompleta informados manualmente. Dispensa cada evento feito pelo mesmo solucionador com vínculo N1/N2/N3 na extração, sem duplicar chamados. Os IDs manuais devem pertencer ao recorte. Recusa de solução é evidência distinta. |
| INS6 | A população elegível vem das categorias N1, excluindo chamados com vínculo atual N3 de ambas as parcelas. O numerador aceita atribuição atual a N1 ou, somente quando não há grupo técnico atribuído, solucionador identificado com vínculo N1 na extração. A ausência de grupo N2 deixou de ser aceita como evidência de solução N1. A atribuição atual não comprova o grupo responsável no instante da solução; essa limitação aparece na medição. |
| INS7–INS9 | INS7 considera conversação até 600 segundos; INS8, espera até conexão de até 30 segundos; INS9, abandono sem atendimento após mais de 30 segundos. O denominador é o total recebido após excluir testes, inclusive abandonadas. TMA/TME individuais são durações; suas médias são diferentes desses percentuais. |
| INS10 | Usa somente profissionais marcados como faturados: substituições classificadas na janela de três meses / profissionais faturados ativos no último dia da competência. Saída é o último dia ativo. Cadastro vazio ou saída de profissional faturado sem classificação deixa o resultado pendente; efetivo zero resulta em N/A quando a informação está completa. Os valores mensais são descritivos, sem rateio nem reajuste histórico. |
| INS11 | O padrão exige vínculo direto do chamado a um artigo da lista previamente validada. Sem a lista ou sem acesso aos vínculos e ao catálogo de artigos, fica pendente. A opção por categoria mede a associação de categorias usada no painel e apresenta a situação normal da meta, com o método identificado. |
| INS12 | Padrão: soma respostas válidas GLPI e telefônicas, uma por ligação. Favoráveis: notas 4 e 5; na telefonia, usa 6 menos a nota original. Opção alternativa: somente GLPI. Fonte selecionada indisponível deixa a apuração pendente. A escala operacional continua 1–5, sem conversão para 0–10. |

Ausência de população elegível resulta em **não aplicável**, sem divisão por zero. Evidências indisponíveis são indicadas como pendentes ou provisórias. Justificativas e ações podem ser registradas nos campos narrativos; glosas e ajustes financeiros não são calculados automaticamente.


## Cadastros e evidências

- **INS12 visível:** as opções GLPI + telefonia (padrão) e somente GLPI aparecem ao lado do INS11, fora dos critérios avançados recolhidos.
- **INS4 N1 + N2:** usa os grupos N1 e N2 selecionados, com prevalência da exclusão N3. N2 inicial: `56, 3310, 3305`. Não exige categoria elegível N1. O filtro geral de grupos continua limitando toda a extração e pode restringir N2; para a abrangência completa, deixe-o vazio ou selecione ambos os níveis.
- **Excel por indicador:** cada aba INS contém somente os registros do seu critério, com filtros, dados utilizados e motivo. Nas abas de chamados, casos favoráveis e desfavoráveis do recorte permanecem juntos. INS7–INS9 começam pelas ligações da condição medida, mantendo link para a base recebida completa. Bases completas e auditoria contêm os registros fora do critério, inclusive ligações de teste. O link “Ver registros detalhados” vai diretamente à tabela.
- **Nomes claros:** contagens usam “Chamados não excedidos”, “Respostas favoráveis”, “Ligações recebidas consideradas” e equivalentes de cada indicador. A base de cálculo não é renomeada como “não elegíveis”, pois isso inverteria o sentido da fração.
- **Prazo, SLA e categoria distintos:** prazo vazio não impede uma classificação pela duração disponível. Um chamado pode ter SLA atribuído e nenhum prazo. A tabela exibe separadamente categoria, SLA ID/nome, prazo de origem, meta, calendário, tempo apurado e motivo de classificação.
- **Cadastros permanentes:** números de teste e profissionais são salvos nas configurações do plugin. O botão de salvar verifica a gravação. Reabrir a página ou trocar a competência reutiliza o cadastro. Somente administradores com permissão de configuração podem alterá-lo; outras configurações e credenciais são preservadas.

### Equipe e INS10

Cadastre **Foi faturado?, Nome, Perfil Profissional, Data de admissão, Data de saída e Valor mensal** na área SES. A saída é opcional e pode ser preenchida depois. Ao informar uma saída, selecione a classificação dentro da própria célula: substituição, redução determinada pela contratante, outra saída sem substituição ou pendente. Os registros podem ser editados ou removidos com confirmação; clique em **Salvar profissionais** para confirmar. Para encerrar um vínculo, preencha a data de saída, preservando sua participação nas competências anteriores.

A competência usa uma janela inclusiva do primeiro dia de dois meses antes até o último dia do mês selecionado. A equipe de referência é a ativa no último dia da competência; a data de saída é tratada como último dia ativo. Essa convenção operacional aparece nos dois relatórios. Uma data de saída isolada não prova substituição. Saídas sem classificação de profissionais faturados na janela impedem um percentual definitivo. Profissionais não faturados não entram no efetivo nem nas contagens de saída, inclusive pendências de classificação. Reduções e outras saídas são discriminadas e não contam como substituições. Os antigos três contadores manuais deixam de dirigir o resultado.

O Word identifica a marcação de faturamento na equipe e nas movimentações. O Excel apresenta os profissionais relevantes ao INS10 na aba do indicador e preserva todo o cadastro, inclusive os não faturados, na auditoria. O valor mensal é o cadastrado, sem rateio ou inferência de reajustes anteriores; a soma usa os profissionais faturados ativos no fechamento. A marcação é persistente, não um histórico mensal de faturamento; cada relatório preserva a seleção existente quando foi gerado.

Os registros ficam congelados no rascunho gerado: salvar alterações no cadastro exige gerar novamente para incorporá-las. A atualização do plugin preserva ambos os cadastros. **Não desinstale** para atualizar: a desinstalação remove as configurações do plugin.

## Organização e recuperação dos cadastros

Busca, filtros e paginação mudam somente a visualização; o salvamento mantém todas as linhas. A lista de profissionais é ordenada alfabeticamente, inclusive nos relatórios. A identificação opcional do vínculo diferencia homônimos ou vínculos realmente distintos. Novas duplicatas exatas são rejeitadas; duplicatas antigas são sinalizadas para conferência, sem exclusão automática.

“Remover” informa a entrada escolhida e permite desfazer antes de salvar. Depois de salvar, **Histórico / recuperar** apresenta as últimas dez alterações de cada cadastro, com responsável, data e quantidades alteradas. É possível recuperar uma entrada individual, conferir e salvar novamente. O histórico começa nas alterações realizadas após instalar esta versão; não recupera exclusões ocorridas antes dela. As versões mais antigas saem da lista após dez alterações posteriores.

Remover um profissional o retira de novas extrações históricas. Para manter o histórico de participação, use a data de saída e os filtros de visualização. Não use “Foi faturado?” para esconder profissionais: essa marcação controla sua participação no INS10. Relatórios já exportados e rascunhos existentes não mudam quando o cadastro é editado.

## Compatibilidade da configuração

O template de configuração corrigido na versão 1.8.1 permanece fixado no diretório do código carregado. Isso evita reutilizar o formulário antigo em cenários de cache de templates ou resolução de outra pasta. A identificação da versão é fornecida pelo código atual. O campo oculto `config_class` recebe a classe PHP diretamente, garantindo que a gravação nativa chame o tratamento das configurações.

Esses problemas foram reproduzidos/verificados localmente. A causa exata de uma instalação que ainda mostra a tela antiga depende dos arquivos efetivamente carregados; o diagnóstico foi incluído para identificá-los. Os testes locais não substituem o teste de conectividade e a conferência dos resultados no ambiente GLPI de destino.

## Relatórios por profissional — API

O fluxo anterior continua disponível pelo botão **Relatórios por profissional**, na área SES, ou pela tela principal do plugin. Configure o perfil da API, salve e use **Testar conexão padrão**. A extração mantém contextos, filtros, processamento em lotes, rascunho editável e exportação DOCX com identidade G4F.

## Contextos do relatório

O usuário pode marcar múltiplos contextos ao mesmo tempo:

- Chamados atribuídos ao agente.
- Chamados solicitados pelo agente.
- Chamados atribuídos aos grupos selecionados explicitamente.
- Tarefas de chamado feitas pelo agente.
- Acompanhamentos feitos pelo agente.
- Soluções registradas pelo agente.
- Projetos gerenciados pelo agente.
- Projetos gerenciados pelos grupos selecionados explicitamente.
- Projetos em que o agente participa.
- Tarefas de projeto do agente.
- Tarefas de projeto dos grupos selecionados explicitamente.
- Entradas narrativas manuais.

## Análises selecionáveis

As análises são calculadas a partir do rascunho já extraído, sem criar uma segunda varredura independente na API:

- Resumo por dia.
- Distribuição por status.
- Origem das atividades.
- Agente x grupos selecionados.
- Top categorias.
- Localização dos chamados.
- Tempo médio de resposta.
- Tempo de primeira resposta.
- Eventos do solicitante sem resposta técnica.
- Tabela consolidada de indicadores.

As visualizações exportadas para DOCX são tabelas/gráficos editáveis em Word, sem imagens geradas dinamicamente.
