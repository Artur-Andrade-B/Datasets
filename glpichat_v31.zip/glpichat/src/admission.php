<?php

declare(strict_types=1);

require_once __DIR__ . '/desktop/common.php';

/** Internal rollback signal, never serialized to an HTTP response. */
final class GlpichatAdmissionRejected extends RuntimeException
{
    public function __construct(public readonly array $result) { parent::__construct('Admission rejected.'); }
}

/** SQL unsigned BIGINT must fit PHP's signed integer without lossy coercion. */
function glpichat_admission_integer(mixed $value): int
{
    if (is_int($value) && $value >= 0) { return $value; }
    if (is_string($value) && preg_match('/\A(?:0|[1-9][0-9]{0,18})\z/D', $value) === 1
        && (strlen($value) < strlen((string) PHP_INT_MAX)
            || (strlen($value) === strlen((string) PHP_INT_MAX) && strcmp($value, (string) PHP_INT_MAX) <= 0))) {
        return (int) $value;
    }
    throw new RuntimeException('Invalid admission counter storage.');
}

/** Transaction-local row lock; same primary key also serializes first creation. */
function glpichat_admission_lock_bucket(string $key): array
{
    global $DB;
    if (preg_match('/\A[a-f0-9]{64}\z/D', $key) !== 1) { throw new InvalidArgumentException('Invalid admission key.'); }
    $keySql = glpichat_desktop_quote($key);
    if ($DB->doQuery('INSERT INTO glpi_plugin_glpichat_admission (bucket_key, window_start, used, expires_at) '
        . "VALUES ($keySql, 0, 0, DATE_ADD(UTC_TIMESTAMP(), INTERVAL 2 DAY)) ON DUPLICATE KEY UPDATE bucket_key=bucket_key") === false) {
        throw new RuntimeException('Admission bucket creation failed.');
    }
    $row = glpichat_desktop_db_rows('SELECT window_start, used FROM glpi_plugin_glpichat_admission '
        . "WHERE bucket_key=$keySql FOR UPDATE");
    if (count($row) !== 1) { throw new RuntimeException('Admission bucket unavailable.'); }
    return $row[0];
}

/** Acquire BEFORE ticket/receipt locks; does not consume a replay's allowance. */
function glpichat_admission_message_lock(int $userId): void
{
    if ($userId < 1) { throw new InvalidArgumentException('Invalid admission user.'); }
    glpichat_admission_lock_bucket(hash('sha256', "chat_mutation\0user:" . $userId . "\0" . '60'));
}

/**
 * Atomic, database-clock fixed-window admission. Subjects are trusted server
 * identities, never source IP addresses or raw credentials. One reused row per
 * scope/subject/window length bounds storage independently of request volume.
 * Fixed windows can admit two bursts across their boundary; these are not
 * advertised as an exact rolling-window quota.
 */
function glpichat_admission_take(array $rules): array
{
    try {
        return glpichat_desktop_transaction(static function () use ($rules): array {
            $result = glpichat_admission_take_locked($rules);
            // Roll back tentative row creation too: a throttled machine must
            // not grow storage by proposing unlimited distinct user subjects.
            if (!$result['allowed']) { throw new GlpichatAdmissionRejected($result); }
            return $result;
        });
    } catch (GlpichatAdmissionRejected $rejected) {
        return $rejected->result;
    }
}

/** Caller MUST own a transaction; rejection leaves every counter unchanged. */
function glpichat_admission_take_locked(array $rules): array
{
    global $DB;
    if (!$rules || count($rules) > 8) { throw new InvalidArgumentException('Invalid admission rule count.'); }
    $normalized = [];
    foreach ($rules as $rule) {
        if (!is_array($rule) || !is_string($rule['scope'] ?? null)
            || preg_match('/\A[a-z][a-z0-9_]{0,31}\z/D', $rule['scope']) !== 1
            || !is_string($rule['subject'] ?? null) || $rule['subject'] === '' || strlen($rule['subject']) > 512
            || !is_int($rule['limit'] ?? null) || $rule['limit'] < 1
            || !is_int($rule['window_seconds'] ?? null) || $rule['window_seconds'] < 1 || $rule['window_seconds'] > 86400) {
            throw new InvalidArgumentException('Invalid admission rule.');
        }
        $rule['cost'] ??= 1;
        if (!is_int($rule['cost']) || $rule['cost'] < 1 || $rule['cost'] > $rule['limit']) {
            throw new InvalidArgumentException('Invalid admission cost.');
        }
        $key = hash('sha256', $rule['scope'] . "\0" . $rule['subject'] . "\0" . $rule['window_seconds']);
        if (isset($normalized[$key])) { throw new InvalidArgumentException('Duplicate admission bucket.'); }
        $normalized[$key] = $rule;
    }
    ksort($normalized, SORT_STRING);
    $rows = [];
    foreach ($normalized as $key => $rule) {
        $rows[$key] = glpichat_admission_lock_bucket($key);
    }
    // Read time after acquiring all locks, so a wait across a window boundary
    // cannot debit an expired window. UNIX_TIMESTAMP is timezone independent.
    $clock = glpichat_desktop_db_rows('SELECT UNIX_TIMESTAMP() AS admission_now');
    $now = glpichat_admission_integer($clock[0]['admission_now'] ?? null);
    if ($now <= 0 || $now > PHP_INT_MAX - 172800) { throw new RuntimeException('Admission clock unavailable.'); }
    $wait = 0;
    $updates = [];
    foreach ($normalized as $key => $rule) {
        $window = $rule['window_seconds'];
        $start = intdiv($now, $window) * $window;
        $storedStart = glpichat_admission_integer($rows[$key]['window_start'] ?? null);
        $storedUsed = glpichat_admission_integer($rows[$key]['used'] ?? null);
        if ($storedStart > PHP_INT_MAX - 172800 || $storedStart % $window !== 0) {
            throw new RuntimeException('Invalid admission window storage.');
        }
        // Clock rollback must not replenish a still-future bucket.
        $used = $storedStart >= $start ? $storedUsed : 0;
        $start = max($start, $storedStart);
        if ($used < 0 || $used > $rule['limit'] || $rule['cost'] > $rule['limit'] - $used) {
            $wait = max($wait, min(86400, max(1, $start + $window - $now)));
        } else {
            $updates[$key] = [$start, $used + $rule['cost'], gmdate('Y-m-d H:i:s', $start + $window + 86400)];
        }
    }
    if ($wait > 0) { return ['allowed' => false, 'retry_after' => $wait]; }
    foreach ($updates as $key => [$start, $used, $expires]) {
        if ($DB->doQuery('UPDATE glpi_plugin_glpichat_admission SET window_start=' . $start . ', used=' . $used
            . ', expires_at=' . glpichat_desktop_quote($expires) . ' WHERE bucket_key=' . glpichat_desktop_quote($key)) === false) {
            throw new RuntimeException('Admission bucket update failed.');
        }
    }
    return ['allowed' => true, 'retry_after' => 0];
}

/** Fresh browser/desktop mutations only, AFTER authorization and receipt replay. */
function glpichat_admission_message(int $userId, ?int $attachmentBytes = null, ?int $maxFileBytes = null): void
{
    if ($userId < 1 || ($attachmentBytes !== null && ($attachmentBytes < 0 || $maxFileBytes === null || $maxFileBytes < $attachmentBytes))) {
        throw new InvalidArgumentException('Invalid message admission subject.');
    }
    // The native GLPI account ID is identical across web/device contexts. It is
    // not a device, ticket or session key, so switching those cannot refill it.
    // Rows expire after inactivity: this is a short-lived quota, not authority
    // evidence or a permanent block that could leak to a recreated identity.
    $rules = [['scope' => 'chat_mutation', 'subject' => 'user:' . $userId, 'limit' => 30, 'window_seconds' => 60]];
    if ($attachmentBytes !== null && $attachmentBytes > 0) {
        $rules[] = ['scope' => 'chat_upload_bytes', 'subject' => 'user:' . $userId,
            'limit' => max(100 * 1048576, $maxFileBytes), 'window_seconds' => 60, 'cost' => $attachmentBytes];
    }
    $result = glpichat_admission_take_locked($rules);
    if (!$result['allowed']) {
        glpichat_desktop_fail('send_throttled', 'Aguarde antes de enviar novas mensagens ou anexos.', 429,
            ['retry_after' => $result['retry_after']]);
    }
}

/** Indexed, bounded maintenance; no receipt, credential or audit data removed. */
function glpichat_admission_cleanup(int $limit = 1000): int
{
    global $DB;
    if ((string) glpichat_desktop_config('desktop_schema_version') !== '12') { return 0; }
    $limit = max(1, min(1000, $limit));
    if ($DB->doQuery('DELETE FROM glpi_plugin_glpichat_admission WHERE expires_at < UTC_TIMESTAMP() '
        . 'ORDER BY expires_at, bucket_key LIMIT ' . $limit) === false) {
        throw new RuntimeException('Admission cleanup failed.');
    }
    return (int) $DB->affectedRows();
}
