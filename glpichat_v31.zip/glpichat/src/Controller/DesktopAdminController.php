<?php

declare(strict_types=1);
namespace GlpiPlugin\Glpichat\Controller;

use Glpi\Controller\AbstractController;
use Glpi\Http\Firewall;
use Glpi\Security\Attribute\SecurityStrategy;
use Session;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

require_once dirname(__DIR__) . '/desktop/fleet.php';

/** Sessionful, READ-only monitoring. This is deliberately separate from the
 * bearer-authenticated machine Poll, which dispatches work and writes facts. */
final class DesktopAdminController extends AbstractController
{
    #[Route('/Admin/Desktop/Status', name: 'glpichat_admin_desktop_status', methods: ['GET'])]
    #[SecurityStrategy(Firewall::STRATEGY_AUTHENTICATED)]
    public function status(Request $request): Response
    {
        \glpichat_desktop_reset_request_context();
        try {
            if ($request->getRealMethod() !== 'GET') { return $this->response(['error' => ['code' => 'method_not_allowed', 'message' => 'Use uma consulta GET.']], 405); }
            if ((int) Session::getLoginUserID() < 1) { return $this->response(['error' => ['code' => 'session_expired', 'message' => 'A sessão expirou. Entre novamente no GLPI.']], 401); }
            if (!Session::haveRight('plugin_glpichat_admin', READ) || !\glpichat_management_admin_has_right((int) Session::getLoginUserID(), \glpichat_management_issuing_profile(), READ)) { return $this->response(['error' => ['code' => 'forbidden', 'message' => 'A permissão de acompanhamento foi removida.']], 403); }
            $canUpdate = Session::haveRight('plugin_glpichat_admin', UPDATE) && \glpichat_management_admin_has_right((int) Session::getLoginUserID(), \glpichat_management_issuing_profile(), UPDATE);
            $input = $request->query->all();
            if (array_diff(array_keys($input), ['ids', 'rollout_id', 'target_page', 'job_ids'])) { \glpichat_desktop_fail('invalid_request', 'Consulta inválida.', 400); }
            $ids = $input['ids'] ?? '[]';
            if (!is_string($ids) || strlen($ids) > 1400) { \glpichat_desktop_fail('invalid_request', 'Lista de computadores inválida.', 400); }
            $ids = \glpichat_management_selection_ids($ids);
            $jobIds = $input['job_ids'] ?? '[]';
            if (!is_string($jobIds) || strlen($jobIds) > 300) { \glpichat_desktop_fail('invalid_request', 'Lista de operações inválida.', 400); }
            $jobIds = \glpichat_management_selection_ids($jobIds);
            $numbers = [];
            foreach (['rollout_id' => 0, 'target_page' => 1] as $key => $default) {
                $value = $input[$key] ?? (string) $default;
                if (!is_string($value) || preg_match('/\A(?:0|[1-9][0-9]{0,9})\z/D', $value) !== 1 || (float) $value > 4294967295) { \glpichat_desktop_fail('invalid_request', 'Identificação inválida.', 400); }
                $numbers[$key] = (int) $value;
            }
            // Authorization has been captured. Do not hold the session mutex
            // during SQL. This endpoint generates no token; GLPI core idle-session
            // behavior remains subject to the deployed session policy.
            if (session_status() === PHP_SESSION_ACTIVE) { session_write_close(); }
            return $this->response(\glpichat_management_fleet_status($ids, $numbers['rollout_id'], $numbers['target_page'], $jobIds) + ['can_update' => $canUpdate]);
        } catch (\GlpichatDesktopException $error) {
            return $this->response(['error' => ['code' => $error->errorCode, 'message' => $error->getMessage()]], $error->httpStatus);
        } catch (\Throwable $error) {
            $reference = \glpichat_desktop_log_failure('desktop_admin_status', $error);
            return $this->response(['error' => ['code' => 'temporarily_unavailable', 'message' => 'A consulta falhou. Referência: ' . $reference . '.']], 503);
        }
    }

    private function response(array $body, int $status = 200): Response
    {
        return new JsonResponse($body, $status, ['Cache-Control' => 'no-store, private', 'Pragma' => 'no-cache', 'X-Content-Type-Options' => 'nosniff', 'Referrer-Policy' => 'no-referrer']);
    }
}
