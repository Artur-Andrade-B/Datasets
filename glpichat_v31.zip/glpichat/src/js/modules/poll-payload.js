// PHP counts every multipart leaf against max_input_vars (normally 1000).
// Reserve headroom and share the refresh budget across all loaded open rooms;
// per-room limits alone overflow with three tickets / six rooms.
export const POLL_FORM_INPUT_BUDGET = 900;

export function buildPollPayload(channels, openTicketIds, normalizeEventCursor) {
  const openTickets = new Set(openTicketIds.map(Number));
  const eligible = Array.from(channels).filter((channel) =>
    openTickets.has(Number(channel.tickets_id || 0)) && channel.messages_loaded === true);
  if (eligible.length === 0) return [];
  const refreshBudget = POLL_FORM_INPUT_BUDGET - 1 - eligible.length * 5;
  if (refreshBudget < 0) throw new Error('Too many open chat rooms for one poll.');
  const perRoom = Math.min(200, Math.floor(refreshBudget / eligible.length));
  return eligible.map((channel) => {
    const retainedIds = (channel.messages || [])
      .filter((message) => !message.is_optimistic && Number(message.id) > 0)
      .map((message) => Number(message.id));
    const offset = Math.max(0, Number(channel.refresh_offset || 0)) % Math.max(1, retainedIds.length);
    const count = Math.min(perRoom, retainedIds.length);
    const visibleIds = Array.from({ length: count }, (_, index) => retainedIds[(offset + index) % retainedIds.length]);
    channel.refresh_offset = (offset + count) % Math.max(1, retainedIds.length);
    return {
      visible_message_ids: visibleIds,
      tickets_id: channel.tickets_id,
      room_type: channel.room_type,
      after_id: channel.last_message_id || 0,
      after_event_id: normalizeEventCursor(channel.last_event_id),
      is_typing: Boolean(channel.isTyping || false),
    };
  });
}

export function createPollForm(payload, csrf) {
  const form = new FormData();
  form.set('_glpi_csrf_token', csrf);
  payload.forEach((item, index) => {
    form.set(`channels[${index}][tickets_id]`, String(item.tickets_id));
    form.set(`channels[${index}][room_type]`, item.room_type);
    form.set(`channels[${index}][after_id]`, String(item.after_id));
    form.set(`channels[${index}][after_event_id]`, String(item.after_event_id));
    form.set(`channels[${index}][is_typing]`, item.is_typing ? '1' : '0');
    item.visible_message_ids.forEach((id, cursor) => form.set(`channels[${index}][visible_message_ids][${cursor}]`, String(id)));
  });
  return form;
}
