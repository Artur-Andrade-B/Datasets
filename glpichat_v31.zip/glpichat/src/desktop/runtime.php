<?php

declare(strict_types=1);

function glpichat_management_runtime_version(mixed $value, bool $empty = true): bool
{
    return is_string($value) && (($empty && $value === '') || preg_match('/\A[0-9]{1,8}\.[0-9]{1,8}\.[0-9]{1,8}\z/D', $value) === 1);
}

/** Advisory telemetry is separate from installed-payload validation. Each
 * optional group is validated independently and cannot complete an assignment.
 * Older clients cannot refresh a snapshot by reporting only installed files. */
function glpichat_management_runtime_store(array $input, ?string $previous): ?string
{
    $old = is_string($previous) ? json_decode($previous, true, 8) : null;
    $snapshot = is_array($old) ? $old : [];
    $snapshot['reported'] = false;
    $snapshot['supervisor_reported'] = false;
    $snapshot['readiness_reported'] = false;
    if (is_array($snapshot['delivery'] ?? null)) { $snapshot['delivery']['reported'] = false; }
    $received = glpichat_desktop_now();
    if (array_key_exists('runtime_state', $input)) {
        $state = $input['runtime_state'];
        $version = $input['runtime_version'] ?? '';
        $counts = [];
        $valid = is_string($state) && in_array($state, ['current', 'stale', 'unknown', 'no_session'], true)
            && glpichat_management_runtime_version($version);
        foreach (['runtime_sessions', 'runtime_current_sessions', 'runtime_unmanaged_sessions'] as $key) {
            $count = $input[$key] ?? null;
            if (!is_int($count) || $count < 0 || $count > 1024) { $valid = false; $count = 0; }
            $counts[$key] = $count;
        }
        $sessions = $counts['runtime_sessions'];
        if ($counts['runtime_current_sessions'] + $counts['runtime_unmanaged_sessions'] > $sessions
            || ($state === 'no_session' && ($sessions !== 0 || $version !== ''))
            || ($state === 'current' && ($sessions === 0 || $counts['runtime_current_sessions'] !== $sessions
                || $counts['runtime_unmanaged_sessions'] !== 0 || $version === '' || $version !== ($input['current_version'] ?? '')))) { $valid = false; }
        if (!$valid) { $state = 'unknown'; $version = ''; $counts = array_fill_keys(array_keys($counts), 0); }
        $snapshot = array_replace($snapshot, ['reported' => true, 'state' => $state, 'version' => $version,
            'received_at' => $received] + $counts);
    }
    if (array_key_exists('runtime_supervisor_sessions', $input)) {
        $version = $input['runtime_supervisor_version'] ?? '';
        $versions = $input['runtime_supervisor_versions'] ?? '';
        $sessions = $input['runtime_supervisor_sessions'];
        $current = $input['runtime_supervisor_current_sessions'] ?? null;
        $valid = glpichat_management_runtime_version($version) && is_string($versions) && strlen($versions) <= 464
            && is_int($sessions) && $sessions >= 0 && $sessions <= 1024
            && is_int($current) && $current >= 0 && $current <= $sessions;
        $list = is_string($versions) && $versions !== '' ? explode(',', $versions) : [];
        if (count($list) > 16 || count(array_unique($list)) !== count($list)) { $valid = false; }
        foreach ($list as $item) { if (!glpichat_management_runtime_version($item, false)) { $valid = false; } }
        if (($sessions === 0 && ($version !== '' || $list !== [] || $current !== 0))
            || ($version !== '' && $list !== [$version]) || count($list) > (is_int($sessions) ? $sessions : 0)
            || ($current > 0 && !in_array($input['bootstrap_version'] ?? '', $list, true))
            || ($current > 0 && $current === $sessions && $list !== [$input['bootstrap_version'] ?? ''])) { $valid = false; }
        $snapshot = array_replace($snapshot, ['supervisor_reported' => $valid, 'supervisor_received_at' => $received,
            'supervisor_version' => $valid ? $version : '', 'supervisor_versions' => $valid ? $list : [],
            'supervisor_sessions' => $valid ? $sessions : 0, 'supervisor_current_sessions' => $valid ? $current : 0]);
    }
    if (array_key_exists('runtime_readiness_error', $input)
        && !(($input['runtime_readiness_error'] ?? null) === '' && !in_array($snapshot['state'] ?? '', ['current', 'no_session'], true))) {
        $error = $input['runtime_readiness_error'];
        $since = $input['runtime_readiness_since_utc'] ?? null;
        $valid = array_key_exists('runtime_state', $input) && is_string($error) && is_string($since)
            && in_array($error, ['', 'WIDGET_STARTUP_TIMEOUT', 'WIDGET_HEARTBEAT_STALE', 'WIDGET_READINESS_LOST'], true);
        if ($valid && $error === '') { $valid = $since === ''; }
        elseif ($valid) {
            $valid = preg_match('/\A[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,7})?Z\z/D', $since) === 1;
            if ($valid) {
                $date = date_parse($since);
                $stamp = strtotime($since);
                $valid = $date['error_count'] === 0 && $date['warning_count'] === 0 && $stamp !== false && $stamp <= time() + 5;
            }
        }
        $snapshot = array_replace($snapshot, ['readiness_reported' => $valid, 'readiness_received_at' => $received,
            'readiness_error' => $valid ? $error : '', 'readiness_since_utc' => $valid ? $since : '']);
        if ($valid && $error !== '' && ($snapshot['state'] ?? '') === 'current') { $snapshot['state'] = 'unknown'; }
    }
    if (array_key_exists('bootstrap_delivery_pending', $input)) {
        $expected = $input['bootstrap_expected_version'] ?? '';
        $phase = $input['bootstrap_delivery_phase'] ?? '';
        $error = $input['bootstrap_delivery_error'] ?? '';
        $retry = $input['bootstrap_retry_utc'] ?? '';
        $pending = $input['bootstrap_delivery_pending'];
        $valid = glpichat_management_runtime_version($expected)
            && is_string($phase) && preg_match('/\A[a-z][a-z0-9_]{0,63}\z/D', $phase) === 1
            && is_string($error) && preg_match('/\A[A-Za-z0-9_:.\-]{0,100}\z/D', $error) === 1
            && is_bool($pending) && is_string($retry) && ($retry === '' || preg_match('/\A[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,7})?Z\z/D', $retry) === 1);
        if ($valid && $retry !== '') {
            // Reject impossible dates as well as arbitrary timezone-relative text.
            $date = date_parse($retry);
            $valid = $date['error_count'] === 0 && $date['warning_count'] === 0;
        }
        if ($pending && $expected === '') { $valid = false; }
        if ($phase === 'current' && ($pending || ($expected !== ''
            && (!glpichat_management_runtime_version($input['bootstrap_version'] ?? null, false)
                || version_compare($input['bootstrap_version'], $expected, '<'))))) { $valid = false; }
        $snapshot['delivery'] = ['reported' => $valid, 'received_at' => $received,
            'expected_version' => $valid ? $expected : '', 'phase' => $valid ? $phase : 'unknown',
            'error' => $valid ? $error : '', 'retry_utc' => $valid ? $retry : '', 'pending' => $valid ? $pending : false];
    }
    if (!is_array($old) && !array_key_exists('runtime_state', $input)
        && !array_key_exists('runtime_supervisor_sessions', $input) && !array_key_exists('bootstrap_delivery_pending', $input)) { return null; }
    return json_encode($snapshot, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
}

function glpichat_management_runtime_recent(mixed $received, int $now): bool
{
    if (!is_string($received) || preg_match('/\A[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}\z/D', $received) !== 1) { return false; }
    $stamp = strtotime($received . ' UTC');
    return $stamp !== false && $stamp <= $now + 5 && $stamp >= $now - 300;
}

/** Bounded row-only view: no per-machine SQL, process query or remote request. */
function glpichat_management_runtime_view(array $machine, ?int $now = null): array
{
    $now ??= time();
    $snapshot = is_string($machine['runtime_json'] ?? null) ? json_decode($machine['runtime_json'], true, 8) : null;
    $view = ['state' => 'unknown', 'label' => 'Não informado por este computador', 'version' => '',
        'sessions' => 0, 'current_sessions' => 0, 'unmanaged_sessions' => 0, 'received_at' => '', 'tone' => 'secondary',
        'supervisor_reported' => false, 'supervisor_version' => '', 'supervisor_versions' => [],
        'supervisor_sessions' => 0, 'supervisor_current_sessions' => 0,
        'readiness_reported' => false, 'readiness_error' => '', 'readiness_since_utc' => ''];
    if (!is_array($snapshot)) { return $view; }
    if (($snapshot['supervisor_reported'] ?? false) === true && glpichat_management_runtime_recent($snapshot['supervisor_received_at'] ?? null, $now)) {
        foreach (['supervisor_version', 'supervisor_versions', 'supervisor_sessions', 'supervisor_current_sessions'] as $field) { $view[$field] = $snapshot[$field]; }
        $view['supervisor_reported'] = true;
    }
    $view['received_at'] = is_string($snapshot['received_at'] ?? null) ? $snapshot['received_at'] : '';
    if (!glpichat_management_runtime_recent($view['received_at'], $now)) {
        if ($view['received_at'] !== '') { $view['state'] = 'expired'; $view['label'] = 'Sem confirmação recente do Widget'; }
        return $view;
    }
    if (($snapshot['reported'] ?? false) !== true) { return $view; }
    foreach (['sessions' => 'runtime_sessions', 'current_sessions' => 'runtime_current_sessions', 'unmanaged_sessions' => 'runtime_unmanaged_sessions'] as $key => $source) {
        $view[$key] = max(0, min(1024, (int) ($snapshot[$source] ?? 0)));
    }
    $state = $snapshot['state'] ?? 'unknown';
    if ($state === 'current' && ($snapshot['version'] ?? '') !== ($machine['current_version'] ?? '')) { $state = 'stale'; }
    $labels = ['current' => 'Versão instalada em execução', 'stale' => 'Widget aguarda troca de versão',
        'unknown' => 'Execução do Widget não confirmada', 'no_session' => 'Nenhuma sessão do Widget observada'];
    if (isset($labels[$state])) { $view['state'] = $state; $view['label'] = $labels[$state]; }
    $view['version'] = is_string($snapshot['version'] ?? null) ? $snapshot['version'] : '';
    $view['tone'] = $view['state'] === 'current' ? 'success' : ($view['state'] === 'stale' ? 'warning' : 'secondary');
    if (($snapshot['readiness_reported'] ?? false) === true && glpichat_management_runtime_recent($snapshot['readiness_received_at'] ?? null, $now)) {
        $view['readiness_reported'] = true;
        $view['readiness_error'] = $snapshot['readiness_error'];
        $view['readiness_since_utc'] = $snapshot['readiness_since_utc'];
        $labels = ['WIDGET_STARTUP_TIMEOUT' => 'Widget não concluiu a inicialização',
            'WIDGET_HEARTBEAT_STALE' => 'Widget deixou de responder', 'WIDGET_READINESS_LOST' => 'Widget perdeu a confirmação de funcionamento'];
        if (isset($labels[$view['readiness_error']])) {
            $view['state'] = 'unknown'; $view['label'] = $labels[$view['readiness_error']]; $view['tone'] = 'warning';
        }
    }
    return $view;
}

function glpichat_management_bootstrap_view(array $machine, ?int $now = null): array
{
    $now ??= time();
    $snapshot = is_string($machine['runtime_json'] ?? null) ? json_decode($machine['runtime_json'], true, 8) : null;
    $delivery = is_array($snapshot) && is_array($snapshot['delivery'] ?? null) ? $snapshot['delivery'] : [];
    $view = ['reported' => false, 'pending' => false, 'expected_version' => '', 'phase' => 'unknown', 'error' => '',
        'retry_utc' => '', 'label' => 'Migração do Bootstrap não informada', 'tone' => 'secondary'];
    if (($delivery['reported'] ?? false) !== true || !glpichat_management_runtime_recent($delivery['received_at'] ?? null, $now)) { return $view; }
    foreach (['pending', 'expected_version', 'phase', 'error', 'retry_utc'] as $key) { $view[$key] = $delivery[$key]; }
    $view['reported'] = true;
    $labels = ['current' => 'Bootstrap atualizado', 'pending' => 'Migração preparada', 'upgrading' => 'Atualizando Bootstrap',
        'quiescing' => 'Salvando conversas para atualizar', 'replacing' => 'Substituindo Bootstrap',
        'opening' => 'Reabrindo sessões do Widget', 'restarting' => 'Reiniciando componentes',
        'waiting_for_signout' => 'Supervisor anterior ainda em execução', 'retry_pending' => 'Aguardando nova tentativa',
        'failed' => 'Migração interrompida', 'unsupported' => 'Migração automática indisponível', 'unknown' => 'Migração não confirmada'];
    $view['label'] = $labels[$view['phase']] ?? ('Estado da migração: ' . $view['phase']);
    $view['tone'] = $view['pending'] || $view['error'] !== '' ? 'warning' : ($view['phase'] === 'current' ? 'success' : 'secondary');
    return $view;
}

function glpichat_management_bootstrap_pending(array $machine): bool
{
    // Component versions evolve independently. Only explicit recent telemetry
    // can assert a pending migration; the Widget version cannot imply it.
    return glpichat_management_bootstrap_view($machine)['pending'];
}
