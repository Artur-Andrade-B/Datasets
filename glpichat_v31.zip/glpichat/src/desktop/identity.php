<?php

declare(strict_types=1);

/** Native GLPI TIMESTAMP values must be read as instants, not PHP-local text.
 * UNIX_TIMESTAMP(TIMESTAMP) uses the stored instant, including repeated DST hours.
 * Plugin-owned DATETIME expiry columns deliberately remain UTC and are separate.
 */
function glpichat_desktop_native_columns(bool $user): string
{
    return '*,UNIX_TIMESTAMP(date_creation) AS glpichat_created_epoch'
        . ($user ? ',UNIX_TIMESTAMP(begin_date) AS glpichat_begin_epoch,UNIX_TIMESTAMP(end_date) AS glpichat_end_epoch' : '');
}

function glpichat_desktop_native_epoch(array $row, string $column): ?int
{
    $value = $row[$column] ?? null;
    if ((!is_int($value) && !is_string($value)) || preg_match('/^[1-9][0-9]{0,10}$/D', (string) $value) !== 1) { return null; }
    return (int) $value;
}

/** Pure identity facts. Authority eligibility remains in auth_user. */
function glpichat_desktop_account_identity(array $user, array $source): array
{
    $created = glpichat_desktop_native_epoch($user, 'glpichat_created_epoch');
    $sourceCreated = glpichat_desktop_native_epoch($source, 'glpichat_created_epoch');
    if ($created === null || !array_key_exists('glpichat_created_epoch', $source)
        || ($sourceCreated === null && (string) ($source['date_creation'] ?? '') !== '')) { glpichat_desktop_auth_unavailable(); }
    // GLPI permits a NULL LDAP source creation date. Preserve that existing
    // identity with an explicit missing marker; never substitute today's date.
    $sourceInstant = $sourceCreated === null ? 'missing' : (string) $sourceCreated;
    $authType = (int) ($user['authtype'] ?? -1);
    $sourceId = (int) ($source['id'] ?? 0);
    $syncAttribute = strtolower(trim((string) ($source['sync_field'] ?? '')));
    $sourceFacts = [];
    foreach (['id', 'date_creation', 'host', 'port', 'basedn', 'login_field', 'sync_field', 'condition'] as $field) {
        $sourceFacts[$field] = (string) ($source[$field] ?? '');
    }
    return [
        'user_id' => (int) ($user['id'] ?? 0), 'auths_id' => $sourceId,
        'sync_anchor' => glpichat_desktop_auth_hash('directory-anchor', (string) ($user['sync_field'] ?? '')),
        'user_incarnation' => glpichat_desktop_auth_hash('user-incarnation-v3', (string) $created . "\0" . $authType),
        'auth_source_fingerprint' => 'v3:' . substr(glpichat_desktop_auth_hash('source-identity-v3',
            serialize([(string) $sourceId, $sourceInstant, $syncAttribute])), 0, 61),
        'legacy_user_incarnation' => glpichat_desktop_auth_hash('user-incarnation', (string) ($user['date_creation'] ?? '') . "\0" . $authType),
        'legacy_v2_source_fingerprint' => 'v2:' . substr(glpichat_desktop_auth_hash('source-identity-v2',
            serialize([(string) $sourceId, (string) ($source['date_creation'] ?? ''), $syncAttribute])), 0, 61),
        'legacy_auth_source_fingerprint' => glpichat_desktop_auth_hash('source', serialize($sourceFacts)),
        'auth_source_created_at' => $sourceCreated === null ? '' : gmdate('Y-m-d H:i:s', $sourceCreated),
        'auth_source_sync_attribute' => $syncAttribute,
    ];
}

/** Bind absolute identity to the retained subject components, detecting damage
 * to either. These proofs are computed only from server-read native authority.
 */
function glpichat_desktop_identity_proof(array $row, array $facts): string
{
    return 'v3:' . substr(glpichat_desktop_auth_hash('canonical-binding-v3', serialize([
        (int) $facts['user_id'], (int) $facts['auths_id'], (string) $facts['sync_anchor'],
        (string) $facts['user_incarnation'], (string) $facts['auth_source_fingerprint'],
        (string) ($row['user_incarnation'] ?? ''), (string) ($row['auth_source_fingerprint'] ?? ''),
    ])), 0, 61);
}

/** Preserve verified legacy subjects on renewal/reissue; new rows use v3. */
function glpichat_desktop_identity_values(array $facts, ?array $retained = null): array
{
    $values = ['sync_anchor' => $facts['sync_anchor'],
        'user_incarnation' => $retained['user_incarnation'] ?? $facts['user_incarnation'],
        'auth_source_fingerprint' => $retained['auth_source_fingerprint'] ?? $facts['auth_source_fingerprint']];
    $values['canonical_identity'] = glpichat_desktop_identity_proof($values, $facts);
    return $values;
}

function glpichat_desktop_legacy_identity_matches(array $row, array $facts): bool
{
    if (!hash_equals((string) ($row['user_incarnation'] ?? ''), (string) ($facts['legacy_user_incarnation'] ?? ''))) { return false; }
    $stored = (string) ($row['auth_source_fingerprint'] ?? '');
    if (str_starts_with($stored, 'v2:')) { return hash_equals((string) ($facts['legacy_v2_source_fingerprint'] ?? ''), $stored); }
    if (!glpichat_desktop_auth_hex($stored)) { return false; }
    if (hash_equals((string) ($facts['legacy_auth_source_fingerprint'] ?? ''), $stored)) { return true; }
    // Existing pre-v2 compatibility rule, now comparing both instants in UTC.
    $created = (string) ($facts['auth_source_created_at'] ?? '');
    $approved = (string) ($row['approved_at'] ?? '');
    return ($facts['auth_source_sync_attribute'] ?? '') === 'objectguid'
        && preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/D', $approved) === 1
        && $created !== '' && $created <= $approved;
}

/** Profile/entity are checked by the caller; this comparison never widens scope. */
function glpichat_desktop_account_matches(array $row, array $facts): bool
{
    foreach (['users_id' => 'user_id', 'auths_id' => 'auths_id'] as $stored => $current) {
        if ((int) ($row[$stored] ?? 0) < 1 || (int) $row[$stored] !== (int) ($facts[$current] ?? 0)) { return false; }
    }
    if (!glpichat_desktop_auth_hex((string) ($row['sync_anchor'] ?? ''))
        || !hash_equals((string) $row['sync_anchor'], (string) ($facts['sync_anchor'] ?? ''))) { return false; }
    $proof = (string) ($row['canonical_identity'] ?? '');
    if ($proof !== '') { return hash_equals(glpichat_desktop_identity_proof($row, $facts), $proof); }
    // Pre-migration records are accepted only by their original exact identity.
    // Never search possible historical timezones to make a mismatch pass.
    return glpichat_desktop_legacy_identity_matches($row, $facts);
}
