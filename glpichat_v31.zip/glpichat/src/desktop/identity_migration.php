<?php

declare(strict_types=1);

/** GLPI's '0' means server configuration, captured before user preferences. */
function glpichat_desktop_identity_legacy_zone(mixed $configured): DateTimeZone
{
    if (is_string($configured) && $configured !== '' && $configured !== '0') { return new DateTimeZone($configured); }
    if (defined('GLPICHAT_DESKTOP_SERVER_TIMEZONE')) { return new DateTimeZone(GLPICHAT_DESKTOP_SERVER_TIMEZONE); }
    // Standalone/CLI tooling may not call plugin boot. Use PHP configuration,
    // never the possibly user-mutated current default; PHP defaults to UTC.
    $serverTimezone = ini_get('date.timezone');
    return new DateTimeZone(is_string($serverTimezone) && $serverTimezone !== '' ? $serverTimezone : 'UTC');
}

/** Explicit install/update lifecycle only; no DDL or fleet scan on API requests.
 * Each row is committed independently, so interruption is retry-safe. Locks are
 * row -> native user -> native source; no other credential row is then acquired.
 * Unverifiable old rows stay unchanged and fail closed, never timezone-guessed.
 */
function glpichat_desktop_identity_migrate(?string $legacyTimezone = null): void
{
    require_once __DIR__ . '/common.php';
    require_once __DIR__ . '/auth.php';
    global $DB;
    if ($legacyTimezone === null && !empty($DB->use_timezones)
        && is_callable(['Config', 'getConfigurationValue'])) {
        $configured = Config::getConfigurationValue('core', 'timezone');
        $legacyTimezone = glpichat_desktop_identity_legacy_zone($configured)->getName();
    }
    $legacyZone = $legacyTimezone === null ? null : new DateTimeZone($legacyTimezone);
    foreach (['glpi_plugin_glpichat_desktopdevices', 'glpi_plugin_glpichat_desktopgrants', 'glpi_plugin_glpichat_desktopautobindings'] as $table) {
        $after = 0;
        while (true) {
            $rows = glpichat_desktop_db_rows('SELECT id FROM ' . $table . ' WHERE id>' . $after . ' ORDER BY id LIMIT 200');
            if (!$rows) { break; }
            foreach ($rows as $candidate) {
                $id = (int) $candidate['id'];
                if ($id <= $after) { throw new RuntimeException('Identity migration cursor did not advance.'); }
                $after = $id;
                glpichat_desktop_transaction(static function () use ($table, $id, $DB, $legacyZone): void {
                    $row = glpichat_desktop_auth_one('SELECT * FROM ' . $table . ' WHERE id=' . $id . ' LIMIT 1 FOR UPDATE');
                    if (!$row || (string) ($row['canonical_identity'] ?? '') !== '' || (int) ($row['users_id'] ?? 0) < 1) { return; }
                    $user = glpichat_desktop_auth_one('SELECT ' . glpichat_desktop_native_columns(true) . ' FROM glpi_users WHERE id=' . (int) $row['users_id'] . ' LIMIT 1 LOCK IN SHARE MODE');
                    if (!$user || (int) ($user['auths_id'] ?? 0) !== (int) ($row['auths_id'] ?? 0)) { return; }
                    $source = glpichat_desktop_auth_one('SELECT ' . glpichat_desktop_native_columns(false) . ' FROM glpi_authldaps WHERE id=' . (int) $row['auths_id'] . ' LIMIT 1 LOCK IN SHARE MODE');
                    if (!$source || glpichat_desktop_native_epoch($user, 'glpichat_created_epoch') === null
                        || (glpichat_desktop_native_epoch($source, 'glpichat_created_epoch') === null && (string) ($source['date_creation'] ?? '') !== '')) { return; }
                    // Every working desktop bearer is validated by the stateless
                    // API in the configured server timezone, including browser-era
                    // approvals. The install administrator's preference is unrelated.
                    // Project only that known context, never former settings.
                    if ($legacyZone !== null) {
                        $user['date_creation'] = (new DateTimeImmutable('@' . $user['glpichat_created_epoch']))->setTimezone($legacyZone)->format('Y-m-d H:i:s');
                        if ($source['glpichat_created_epoch'] !== null) {
                            $source['date_creation'] = (new DateTimeImmutable('@' . $source['glpichat_created_epoch']))->setTimezone($legacyZone)->format('Y-m-d H:i:s');
                        }
                    }
                    $facts = glpichat_desktop_account_identity($user, $source);
                    if (!glpichat_desktop_account_matches($row, $facts)) { return; }
                    if (!$DB->update($table, ['canonical_identity' => glpichat_desktop_identity_proof($row, $facts)], ['id' => $id, 'canonical_identity' => ''])
                        || $DB->affectedRows() !== 1) { throw new RuntimeException('Canonical identity migration write failed.'); }
                });
            }
        }
    }
}
