<?php

declare(strict_types=1);

require_once __DIR__ . '/flows/guest_flow.php';

/** A separate, session-bound proof; exposing it never exposes the HttpOnly cookie. */
function glpichat_guest_csrf_token(string $sessionToken): string
{
    if ($sessionToken === '') { return ''; }
    return hash_hmac('sha256', "glpichat-guest-csrf-v1\0", $sessionToken);
}

/**
 * Only same-origin AJAX may bootstrap a proof. A sibling origin is not trusted
 * merely because SameSite cookies consider it part of the same site.
 * Symfony applies its configured trusted-proxy policy to scheme and host; do
 * not trust arbitrary forwarded headers or a potentially stale url_base here.
 */
function glpichat_guest_assert_browser_request(\Symfony\Component\HttpFoundation\Request $request): void
{
    $origin = $request->headers->get('Origin');
    $fetchSite = strtolower((string) $request->headers->get('Sec-Fetch-Site', ''));
    if ($request->headers->get('X-Requested-With') !== 'XMLHttpRequest'
        || ($origin !== null && strcasecmp($origin, $request->getSchemeAndHttpHost()) !== 0)
        || !in_array($fetchSite, ['', 'same-origin'], true)) {
        throw new GlpichatGuestException('guest_origin_invalid', 'Origem da solicitação não autorizada.', 403);
    }
}

function glpichat_guest_has_csrf_proof(\Symfony\Component\HttpFoundation\Request $request, string $sessionToken): bool
{
    // Header only: a cross-origin HTML form cannot manufacture this header.
    // Never accept proof in a URL, where proxy logs and referrers may retain it.
    $proof = $request->headers->get('X-Glpi-Csrf-Token', '');
    return $sessionToken !== '' && preg_match('/\A[0-9a-f]{64}\z/D', $proof) === 1
        && hash_equals(glpichat_guest_csrf_token($sessionToken), $proof);
}

function glpichat_guest_assert_csrf(\Symfony\Component\HttpFoundation\Request $request, string $sessionToken): void
{
    glpichat_guest_assert_browser_request($request);
    if (!glpichat_guest_has_csrf_proof($request, $sessionToken)) {
        // The guest client can bootstrap through an authenticated Sync and
        // retry the SAME receipt. No mutation has taken place at this point.
        throw new GlpichatGuestException('guest_csrf_invalid', 'Atualizando a proteção da sessão. Tente novamente.', 403);
    }
}
