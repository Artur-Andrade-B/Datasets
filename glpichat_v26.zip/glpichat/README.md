# GLPI Chat — 1.9.4-desktop17

Chat contextual dos chamados do GLPI, com cliente Windows 0.9.4 e conexão automática gerenciada pela empresa.

Esta atualização entrega a correção pontual do tamanho informado à superfície gráfica do lançador Windows. O plugin GLPI mantém código de execução, permissões, matrícula e esquema 9; apenas metadados e documentação da versão são atualizados.

O candidato do lançador passou em 268 verificações nativas no Windows afetado. Isso comprova o teste isolado nessa máquina; atualização instalada, demais telas/escalas, GPO e política do Kaspersky ainda exigem qualificação. O cliente continua sem assinatura Authenticode. Windows 1.0.0 permanece reservado para a promoção assinada posterior. A falha separada de serialização do checkpoint agregado de notificações continua pendente.

Leia [a instalação](docs/INSTALLATION_PT-BR.md) e [as notas de desktop17](docs/releases/1.9.4-desktop17.md). Use o ZIP do plugin no GLPI e o ZIP Windows de release no gerenciamento de versões. Preserve estado, credenciais e pacotes anteriores; atualize sem desinstalar.
