<?php
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require dirname(__DIR__) . '/inc/autoload.php';

use GlpiPlugin\G4freports\Ses\AnnualDocxExporter;
use GlpiPlugin\G4freports\Ses\AnnualReport;
use GlpiPlugin\G4freports\Ses\OfficePackage;

$checks = 0;
function annualDocxAssert(bool $condition, string $message): void
{
    global $checks; $checks++;
    if (!$condition) throw new RuntimeException($message);
}
function annualDocxXml(string $xml): DOMXPath
{
    $dom = new DOMDocument();
    $previous = libxml_use_internal_errors(true);
    $valid = $dom->loadXML($xml);
    libxml_clear_errors(); libxml_use_internal_errors($previous);
    annualDocxAssert($valid, 'OOXML is well formed');
    $xp = new DOMXPath($dom);
    foreach (['w' => 'http://schemas.openxmlformats.org/wordprocessingml/2006/main', 'c' => 'http://schemas.openxmlformats.org/drawingml/2006/chart'] as $prefix => $uri) $xp->registerNamespace($prefix, $uri);
    return $xp;
}
$months = []; $records = [];
for ($m = 1; $m <= 12; $m++) {
    $month = sprintf('2026-%02d', $m); $months[] = $month;
    if (in_array($m, [7, 12], true)) continue;
    $metrics = [];
    for ($n = 1; $n <= 12; $n++) {
        $id = 'INS' . $n; $lower = in_array($n, [5, 9, 10], true);
        $value = [1 => 0, 2 => 100, 3 => 125, 4 => 120, 5 => 115, 6 => 110, 8 => 90, 9 => 92, 10 => 93, 11 => 94][$m];
        if ($lower) $value = $m === 1 ? 125 : 12 - $m;
        $metrics[$id] = ['id' => $id, 'label' => 'Rótulo arquivado ' . $id, 'title' => 'Título histórico ' . $id . ($m === 6 ? ' revisado' : ''),
            'status' => $m === 4 ? 'provisional' : ($m === 8 ? 'pending' : ($m === 1 ? 'unmet' : 'met')),
            'value' => $value, 'target' => $lower ? 10 : 85 + ($m % 3), 'direction' => $lower ? 'lte' : 'gte',
            'numerator' => $value, 'denominator' => $m === 1 ? 0 : 100, 'method' => 'Método histórico preservado',
            'note' => $m === 1 ? 'Nota arquivada: <texto> & =1+1' : '',
            'comparability' => ['known' => $m !== 5, 'fingerprint' => hash('sha256', $m === 6 ? 'changed-scope' : 'same-scope')]];
    }
    $records[] = ['id' => 'revision-' . $month, 'month' => $month, 'archived_at' => $month . '-28 11:00:00', 'summary' => [
        'schema_version' => 1, 'month' => $month, 'generated_at' => $month . '-28 10:00:00', 'rules_version' => 'frozen-rules-7',
        'source_identity' => ['status' => 'known', 'value' => ['glpi' => str_repeat('a', 64), 'callcenter' => str_repeat('b', 64)]],
        'scope_label' => 'Escopo congelado ' . $month, 'period' => ['start' => $month . '-01', 'end_exclusive' => $month . '-29', 'completeness' => $m === 10 ? 'provisional' : ($m === 11 ? 'unknown' : 'complete')],
        'metrics' => $metrics, 'financial' => ['available' => true, 'complete' => $m < 3,
            'gross_cents' => 100001, 'deduction_cents' => 101, 'adjustment_cents' => -10, 'net_cents' => 99890,
            'notes' => $m === 3 ? ['Apuração financeira parcial'] : []],
        'totals' => ['tickets' => 320 + $m, 'requests' => 300, 'incidents' => 20 + $m, 'calls_received' => 1000 + $m,
            'calls_answered' => 900, 'mean_talk_seconds' => 125.5, 'mean_wait_seconds' => 12.25, 'mean_talk_count' => 89, 'mean_wait_count' => 90],
        'staffing' => ['billing_professionals_total' => 12, 'note' => 'Nota mensal de equipe'],
        'manual' => ['executive_summary' => 'Análise arquivada da competência ' . $month . '.', 'actions' => "Ação registrada.\nResponsável informado no mês.", 'notes' => '=SUM(A1:A2) & <literal>', 'phone_survey_actions' => 'Providência telefônica preservada.'],
        'warnings' => ['Ressalva histórica preservada.'],
    ]];
}
$report = AnnualReport::build($records, $months); $unchanged = $report;
$writer = new AnnualDocxExporter(); $binary = $writer->toBinary($report); $parts = OfficePackage::read($binary);
annualDocxAssert($report === $unchanged, 'Exporter does not mutate archived report');
$largeFinancial = $report;
$largeFinancial['financial']['subtotal_cents']['gross'] = 9007199254740991;
annualDocxAssert(str_contains(OfficePackage::read($writer->toBinary($largeFinancial))['word/document.xml'], 'R$ 90.071.992.547.409,91'), 'Frozen cent integers remain exact without floating-point money conversion');
annualDocxAssert($writer->filename($report) === 'Relatorio_Comparativo_SES_2026-01_a_2026-12.docx', 'Filename includes selected range');
$xp = annualDocxXml($parts['word/document.xml']); $text = $xp->evaluate('string(/w:document)');
foreach (['0,00%', '100,00%', '125,00%', '+100,00 p.p.', 'Provisório', 'Pendente', 'Ausente', 'Melhora', 'Piora',
    'origem', 'Título histórico INS1 revisado', 'Rótulo arquivado INS1', 'Método histórico preservado', 'Nota arquivada: <texto> & =1+1', 'Escopo congelado 2026-01',
    'Providência telefônica preservada.', 'R$ 2.000,02', 'R$ -0,20', 'Subtotal de 2 de 12', 'Não há indicador anual agregado', 'período provisório', 'encerramento não confirmado',
    'TMA: 0:02:06 (125,50 s)', 'TME: 0:00:12 (12,25 s)', 'conversas com duração válida: 89', 'requisições: 300'] as $needle) {
    annualDocxAssert(stripos($text, $needle) !== false, 'Frozen value or caveat preserved: ' . $needle);
}
annualDocxAssert(!str_contains($text, str_repeat('a', 64)), 'Opaque source identity hashes are not exposed');
annualDocxAssert($xp->query('//w:rFonts[@w:ascii="Arial"]')->length > 0, 'G4F report font preserved');
annualDocxAssert($xp->evaluate('string(//w:pgMar/@w:top)') === '1560', 'Letterhead top margin preserved');
annualDocxAssert($xp->evaluate('string(//w:pgMar/@w:bottom)') === '1560', 'Letterhead bottom margin preserved');
annualDocxAssert($xp->query('//w:tblHeader')->length > 0, 'Long tables repeat header rows');
$original = OfficePackage::read(file_get_contents(dirname(__DIR__) . '/resources/docx/papel_timbrado_G4F.docx'));
foreach ($original as $path => $content) {
    if (preg_match('#^word/(?:header|footer|media)#', $path)) annualDocxAssert(($parts[$path] ?? '') === $content, 'Original G4F letterhead retained: ' . $path);
}
$chartCount = 0;
foreach ($parts as $path => $xml) {
    if (str_ends_with($path, '.xml') || str_ends_with($path, '.rels')) annualDocxXml($xml);
    if (!preg_match('#^word/charts/ses_chart_\d+\.xml$#', $path)) continue;
    $chartCount++; $chart = annualDocxXml($xml);
    annualDocxAssert($chart->evaluate('string(//c:barDir/@val)') === 'bar', 'Native metric chart is horizontal');
    annualDocxAssert($chart->evaluate('string(//c:catAx/c:axPos/@val)') === 'l', 'Horizontal category axis is left');
    annualDocxAssert($chart->query('//c:ser')->length === 2, 'Frozen result and target are separate series');
    annualDocxAssert($chart->query('//c:ser[1]/c:val/c:numRef/c:numCache/c:pt[@idx="6"]')->length === 0, 'Missing selected month is chart gap');
    annualDocxAssert($chart->query('//c:ser/c:cat/c:strRef/c:strCache/c:pt[c:v="2026-04 (prov.)"]')->length === 2, 'Provisional chart value explicitly marked');
    $book = OfficePackage::read($parts['word/embeddings/ses_chart_' . $chartCount . '.xlsx']);
    annualDocxAssert(isset($book['xl/worksheets/sheet1.xml']), 'Native Word chart has editable self-contained workbook');
}
annualDocxAssert($chartCount === 12, 'Twelve metric charts exported');
$chart = annualDocxXml($parts['word/charts/ses_chart_1.xml']);
annualDocxAssert($chart->evaluate('string(//c:ser[1]/c:val/c:numRef/c:numCache/c:pt[@idx="0"]/c:v)') === '0', 'Zero result remains numeric zero');
annualDocxAssert($chart->evaluate('string(//c:ser[1]/c:val/c:numRef/c:numCache/c:pt[@idx="2"]/c:v)') === '1.25', 'Value greater than 100 percent is not clipped');
annualDocxAssert($chart->query('//c:valAx/c:scaling/c:max')->length === 0, 'Word chart automatically scales beyond 100 percent');
annualDocxAssert($chart->evaluate('string(//c:ser[2]/c:val/c:numRef/c:numCache/c:pt[@idx="0"]/c:v)') === '0.86', 'Monthly archived target retained');
$gap = AnnualReport::build([$records[0], $records[2]], ['2026-01', '2026-03']);
$gapXml = OfficePackage::read($writer->toBinary($gap))['word/document.xml'];
annualDocxAssert(str_contains($gapXml, '2026-01 → 2026-03 (1 competência(s) não selecionada(s))'), 'Nonconsecutive comparison interval explicit');
$missing = OfficePackage::read($writer->toBinary(AnnualReport::build([], ['2026-01'])));
annualDocxAssert(!isset($missing['word/charts/ses_chart_1.xml']), 'All missing monthly values do not fabricate a chart');
annualDocxAssert(!str_contains($missing['word/document.xml'], 'R$ 0,00'), 'No complete financial month never displays a false zero subtotal');
$longMonths = [];
for ($y = 2025; $y <= 2026; $y++) for ($m = 1; $m <= 12; $m++) $longMonths[] = sprintf('%04d-%02d', $y, $m);
$longRecords = $records;
foreach ($records as $record) {
    $record['month'] = '2025-' . substr($record['month'], 5);
    $record['id'] = 'revision-' . $record['month'];
    $record['summary']['month'] = $record['month'];
    $longRecords[] = $record;
}
$longReport = AnnualReport::build($longRecords, $longMonths);
$longBinary = $writer->toBinary($longReport);
$long = OfficePackage::read($longBinary);
annualDocxAssert(str_contains($long['word/document.xml'], 'parte 1 de 2') && str_contains($long['word/document.xml'], 'parte 2 de 2'), '24 months split into readable 12-month tables and charts');
annualDocxAssert(count(array_filter(array_keys($long), static fn($path) => (bool)preg_match('#^word/charts/ses_chart_\d+\.xml$#', $path))) === 24, '24-month report preserves charts for both years');
foreach ([[['month' => '2026-01'], ['month' => '2026-01']], array_fill(0, 25, ['month' => '2026-01'])] as $invalid) {
    try { $writer->toBinary(['months' => $invalid]); annualDocxAssert(false, 'Invalid month selection should fail'); }
    catch (InvalidArgumentException $e) { annualDocxAssert(true, 'Duplicate or unbounded selection rejected'); }
}
if (($output = getenv('ANNUAL_DOCX_OUTPUT')) !== false && $output !== '') file_put_contents($output, $binary);
if (($output = getenv('ANNUAL_DOCX_LONG_OUTPUT')) !== false && $output !== '') file_put_contents($output, $longBinary);
echo 'annual_docx_export_test: ' . $checks . " checks passed\n";
