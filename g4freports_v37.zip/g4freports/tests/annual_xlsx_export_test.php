<?php
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }

require dirname(__DIR__) . '/inc/autoload.php';

use GlpiPlugin\G4freports\Ses\AnnualReport;
use GlpiPlugin\G4freports\Ses\AnnualXlsxExporter;
use GlpiPlugin\G4freports\Ses\OfficePackage;

$checks = 0;
function annualXlsxAssert(bool $condition, string $message): void
{
    global $checks;
    $checks++;
    if (!$condition) throw new RuntimeException($message);
}
function annualXlsxXml(string $xml): DOMXPath
{
    $dom = new DOMDocument();
    annualXlsxAssert($dom->loadXML($xml), 'Every OOXML part is valid XML');
    $xp = new DOMXPath($dom);
    $xp->registerNamespace('s', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main');
    $xp->registerNamespace('c', 'http://schemas.openxmlformats.org/drawingml/2006/chart');
    return $xp;
}
function annualXlsxCell(DOMXPath $xp, string $cell, string $child = 's:v'): string
{
    return $xp->evaluate('string(//s:c[@r="' . $cell . '"]/' . $child . ')');
}

$selected = ['2026-01', '2026-02', '2026-03', '2026-04', '2026-05', '2026-06', '2026-07', '2026-10', '2026-12'];
$records = [];
foreach (array_slice($selected, 0, 8) as $index => $month) {
    $metrics = [];
    for ($n = 1; $n <= 12; $n++) {
        $id = 'INS' . $n;
        $value = [0, 100, 125, 120, 115, 113, 110, 100][$index];
        if ($id === 'INS5') $value = [8, 5, 5, 4, 3, 2, 1, 0][$index];
        $direction = $id === 'INS5' || ($id === 'INS1' && $index === 7) ? 'lte' : 'gte';
        $metrics[$id] = ['id' => $id, 'label' => 'Título arquivado ' . $id . ' / ' . $month,
            'title' => 'Descrição histórica preservada', 'status' => $index === 3 ? 'provisional' : 'met',
            'value' => $value, 'target' => 85 + $index, 'direction' => $direction,
            'numerator' => $index * 10, 'denominator' => 0, 'method' => 'Método preservado no mês ' . $month,
            'note' => '=HYPERLINK("https://example.invalid","texto literal")',
            'comparability' => ['known' => $index !== 5, 'fingerprint' => hash('sha256', ($index < 6 ? 'source-v1' : 'source-v2') . $direction)]];
    }
    $records[] = ['id' => 'archive-' . $month, 'month' => $month, 'archived_at' => $month . '-28 10:00:00',
        'summary' => ['schema_version' => 1, 'month' => $month, 'generated_at' => $month . '-28 09:00:00',
            'period' => ['completeness' => $index === 4 ? 'provisional' : 'complete', 'complete' => $index !== 4, 'note' => $index === 4 ? 'Mês em andamento.' : 'Mês encerrado.'],
            'rules_version' => 'frozen-rules-7', 'source_identity' => ['status' => 'known', 'value' => 'frozen-source'],
            'scope_label' => 'Escopo arquivado', 'metrics' => $metrics,
            'financial' => ['available' => true, 'complete' => $index < 2, 'gross_cents' => 100001 + $index,
                'deduction_cents' => 101, 'adjustment_cents' => -10, 'net_cents' => 99890 + $index, 'notes' => ['Nota financeira preservada']],
            'manual' => ['executive_summary' => '=1+1', 'actions' => '+SUM(A1:A2)', 'notes' => '@literal', 'phone_survey_actions' => '-2+3'],
            'warnings' => ['Observação histórica'], 'totals' => ['tickets' => 11], 'staffing' => ['note' => 'Equipe registrada']]];
}
$report = AnnualReport::build($records, $selected);
$original = $report;
$exporter = new AnnualXlsxExporter();
$binary = $exporter->toBinary($report);
$parts = OfficePackage::read($binary);
annualXlsxAssert($report === $original, 'Export cannot alter frozen report input');
annualXlsxAssert($exporter->filename($report) === 'Analise_SES_2026-01_a_2026-12.xlsx', 'Filename identifies selected period');
foreach ($parts as $xml) annualXlsxXml($xml);
$workbook = annualXlsxXml($parts['xl/workbook.xml']);
annualXlsxAssert($workbook->query('//s:sheet')->length === 15, 'Summary, financial, twelve metrics and monthly notes exported');
annualXlsxAssert($workbook->evaluate('string(//s:calcPr/@fullCalcOnLoad)') === '1', 'Workbook requests formula recalculation');

$metric = annualXlsxXml($parts['xl/worksheets/sheet3.xml']);
annualXlsxAssert(annualXlsxCell($metric, 'B8') === '0', 'Actual zero is numeric zero');
annualXlsxAssert(annualXlsxCell($metric, 'B9') === '1', '100 percent is numeric 1');
annualXlsxAssert(annualXlsxCell($metric, 'B10') === '1.25', 'Results over 100 percent remain unchanged');
annualXlsxAssert(annualXlsxCell($metric, 'C8') === '0.85' && annualXlsxCell($metric, 'C9') === '0.86', 'Each month keeps its own frozen target');
annualXlsxAssert(annualXlsxCell($metric, 'F8') === '0', 'Frozen zero denominator preserved without KPI division');
annualXlsxAssert(annualXlsxCell($metric, 'G9') === '100' && str_contains(annualXlsxCell($metric, 'G9', 's:f'), '(B9-B8)*100'), 'Comparable monthly delta has formula over frozen values and contract cache');
annualXlsxAssert(str_contains(annualXlsxCell($metric, 'H9', 's:f'), 'G9>0'), 'Historical evolution uses that month direction, not latest direction');
annualXlsxAssert(annualXlsxCell($metric, 'G10') === '25', 'Difference is percentage points, not relative percent');
annualXlsxAssert(!str_contains(annualXlsxCell($metric, 'G9', 's:f'), 'ROUND'), 'Delta formulas never round away genuine small changes');
annualXlsxAssert(annualXlsxCell($metric, 'B11') === '1.2' && annualXlsxCell($metric, 'G11', 's:f') === '', 'Provisional numeric results remain visible without comparison');
annualXlsxAssert(annualXlsxCell($metric, 'G12', 's:f') === '', 'Comparison does not bridge provisional predecessor');
annualXlsxAssert(annualXlsxCell($metric, 'G13', 's:f') === '' && annualXlsxCell($metric, 'G14', 's:f') === '', 'Unknown and incompatible source cannot create comparison formulas');
annualXlsxAssert(annualXlsxCell($metric, 'G15', 's:f') === '', 'Changed direction invalidates comparison');
annualXlsxAssert(annualXlsxCell($metric, 'B16') === '' && annualXlsxCell($metric, 'G16', 's:f') === '', 'Missing selected month has blank result and no delta');
annualXlsxAssert(str_contains($metric->evaluate('string(//s:c[@r="D11"])'), 'provisória'), 'Provisional status explicit');
annualXlsxAssert(str_contains($metric->evaluate('string(//s:c[@r="D12"])'), 'mês provisório'), 'Partial monthly period remains explicit even when metric target is met');
annualXlsxAssert(str_contains($parts['xl/worksheets/sheet3.xml'], 'Título arquivado INS1 / 2026-01'), 'Historical per-month label preserved');
annualXlsxAssert(str_contains($parts['xl/worksheets/sheet3.xml'], 'Descrição histórica preservada'), 'Distinct historical title also preserved');
annualXlsxAssert(!str_contains($parts['xl/worksheets/sheet3.xml'], '<f>HYPERLINK'), 'Formula-looking notes never become formulas');

$decrease = annualXlsxXml($parts['xl/worksheets/sheet7.xml']);
annualXlsxAssert(annualXlsxCell($decrease, 'G9') === '-3' && str_contains(annualXlsxCell($decrease, 'H9', 's:f'), 'G9<0'), 'Lower-is-better metric uses decreasing improvement');
annualXlsxAssert(annualXlsxCell($decrease, 'H10') === 'Estável', 'Unchanged metric comparison cache correct');
annualXlsxAssert(annualXlsxCell($decrease, 'G15') === '-1', 'Nonconsecutive selected months may compare when contract permits');
annualXlsxAssert(str_contains($decrease->evaluate('string(//s:c[@r="I15"])'), '2 competência(s) não selecionada(s)'), 'Skipped month interval is visibly explicit');

$financial = annualXlsxXml($parts['xl/worksheets/sheet2.xml']);
annualXlsxAssert(annualXlsxCell($financial, 'C8') === '1000.01' && annualXlsxCell($financial, 'E8') === '-0.1', 'Frozen cents become numeric BRL including negative adjustments');
annualXlsxAssert(annualXlsxCell($financial, 'C17') === '2000.03', 'Subtotal cache includes only complete month amounts');
annualXlsxAssert(str_contains(annualXlsxCell($financial, 'C17', 's:f'), 'SUMIF($B$8:$B$16,"Completo",C8:C16)'), 'Subtotal is a functional sum over visible frozen values');
annualXlsxAssert(annualXlsxCell($financial, 'C10') === '1000.03', 'Incomplete financial source values remain visible');
annualXlsxAssert($financial->evaluate('string(//s:c[@r="B12"])') === 'Provisório', 'Partial monthly financial period labeled provisional');

$largeRecords = array_slice($records, 0, 2);
$largeRecords[0]['summary']['financial']['gross_cents'] = 10000000000000001;
$largeRecords[1]['summary']['financial']['gross_cents'] = 10000000000000003;
$largeRecords[0]['summary']['financial']['adjustment_cents'] = -10000000000000007;
$largeRecords[1]['summary']['financial']['adjustment_cents'] = -10000000000000009;
$largeParts = OfficePackage::read($exporter->toBinary(AnnualReport::build($largeRecords, ['2026-01', '2026-02'])));
$largeFinancial = annualXlsxXml($largeParts['xl/worksheets/sheet2.xml']);
annualXlsxAssert($largeFinancial->evaluate('string(//s:c[@r="C8"])') === 'R$ 100.000.000.000.000,01', 'Large positive cents preserve every digit as exact currency text');
annualXlsxAssert($largeFinancial->evaluate('string(//s:c[@r="E8"])') === '-R$ 100.000.000.000.000,07', 'Large negative cents preserve every digit and sign');
annualXlsxAssert($largeFinancial->evaluate('string(//s:c[@r="C10"])') === 'R$ 200.000.000.000.000,04' && annualXlsxCell($largeFinancial, 'C10', 's:f') === '', 'Large subtotal preserves archived cents without an inaccurate SUMIF');
annualXlsxAssert($largeFinancial->evaluate('string(//s:c[@r="E10"])') === '-R$ 200.000.000.000.000,16', 'Negative large subtotal remains exact');
annualXlsxAssert(annualXlsxCell($largeFinancial, 'D10', 's:f') !== '', 'Unaffected financial columns retain functional formulas');
annualXlsxAssert(str_contains($largeFinancial->evaluate('string(//s:c[@r="A6"])'), 'texto monetário exato'), 'Precision fallback is clearly disclosed');
$largeRecords[1]['summary']['financial']['gross_cents'] = -10000000000000001;
$cancelParts = OfficePackage::read($exporter->toBinary(AnnualReport::build($largeRecords, ['2026-01', '2026-02'])));
$cancelFinancial = annualXlsxXml($cancelParts['xl/worksheets/sheet2.xml']);
annualXlsxAssert($cancelFinancial->evaluate('string(//s:c[@r="C10"])') === 'R$ 0,00' && annualXlsxCell($cancelFinancial, 'C10', 's:f') === '', 'Exact small subtotal of unsafe large inputs never silently excludes text source amounts');
$notes = annualXlsxXml($parts['xl/worksheets/sheet15.xml']);
annualXlsxAssert($notes->query('//s:f')->length === 0, 'Manual notes cannot execute formulas');
annualXlsxAssert($notes->evaluate('string(//s:c[@r="C8"]/@t)') === 'inlineStr' && $notes->evaluate('string(//s:c[@r="C8"])') === '=1+1', 'Formula injection preserved as text');

$chartCount = 0;
foreach ($parts as $name => $xml) {
    if (!preg_match('#^xl/charts/chart\d+\.xml$#', $name)) continue;
    $chartCount++;
    $xp = annualXlsxXml($xml);
    annualXlsxAssert($xp->evaluate('string(//c:barDir/@val)') === 'bar', 'Every annual metric chart is horizontal');
    annualXlsxAssert($xp->evaluate('string(//c:catAx/c:axPos/@val)') === 'l', 'Category axis is left');
    annualXlsxAssert($xp->query('//c:ser')->length === 2, 'Frozen result and target series both present');
    annualXlsxAssert($xp->evaluate('string(//c:ser[1]/c:val/c:numRef/c:f)') !== '', 'Chart values reference visible monthly cells');
    annualXlsxAssert($xp->query('//c:ser[1]/c:val/c:numRef/c:numCache/c:pt[@idx="8"]')->length === 0, 'Missing chart result remains gap');
}
annualXlsxAssert($chartCount === 12, 'All twelve monthly metric charts exported');
$highChart = annualXlsxXml($parts['xl/charts/chart1.xml']);
annualXlsxAssert((float)$highChart->evaluate('string(//c:valAx/c:scaling/c:max/@val)') > 1.25, 'Chart scale supports results greater than 100 percent');

$tinyRecords = array_slice($records, 0, 2);
$tinyRecords[0]['summary']['metrics']['INS1']['value'] = 50.0;
$tinyRecords[1]['summary']['metrics']['INS1']['value'] = 50.00000000001;
$tinyReport = AnnualReport::build($tinyRecords, ['2026-01', '2026-02']);
$tinyParts = OfficePackage::read($exporter->toBinary($tinyReport));
$tinySheet = annualXlsxXml($tinyParts['xl/worksheets/sheet3.xml']);
annualXlsxAssert((float)annualXlsxCell($tinySheet, 'G9') > 0 && (float)annualXlsxCell($tinySheet, 'G9') < 0.00000000005, 'Tiny nonzero delta preserves the positive cached value');
annualXlsxAssert(!str_contains(annualXlsxCell($tinySheet, 'G9', 's:f'), 'ROUND') && str_contains(annualXlsxCell($tinySheet, 'G9', 's:f'), '(B9-B8)*100'), 'Tiny nonzero comparison uses unrounded monthly difference');
annualXlsxAssert(annualXlsxCell($tinySheet, 'H9') === 'Melhora' && str_contains(annualXlsxCell($tinySheet, 'H9', 's:f'), 'G9>0'), 'Tiny improvement keeps cached direction and formula direction consistent');

$missingReport = AnnualReport::build([], ['2026-01']);
$missingParts = OfficePackage::read($exporter->toBinary($missingReport));
$missingFinancial = annualXlsxXml($missingParts['xl/worksheets/sheet2.xml']);
annualXlsxAssert(annualXlsxCell($missingFinancial, 'C9') === '' && $missingFinancial->evaluate('string(//s:c[@r="C9"]/@t)') === 'str', 'No complete month produces unavailable subtotal, never false zero');

$longNote = str_repeat('á', 50000) . "\n=HYPERLINK(\"https://example.invalid\")";
$longNoteReport = $report;
$longNoteReport['months'][0]['summary']['manual']['executive_summary'] = $longNote;
$longNoteParts = OfficePackage::read($exporter->toBinary($longNoteReport));
$longNoteSheet = annualXlsxXml($longNoteParts['xl/worksheets/sheet15.xml']);
$restoredNote = '';
foreach ($longNoteSheet->query('//s:row[s:c[starts-with(@r,"A")]/s:is/s:t="2026-01" and s:c[starts-with(@r,"B")]/s:is/s:t[starts-with(.,"Resumo executivo")]]') as $row) {
    $restoredNote .= $longNoteSheet->evaluate('string(s:c[starts-with(@r,"C")]/s:is/s:t)', $row);
}
annualXlsxAssert($restoredNote === $longNote, '50,000-character Unicode narrative survives visible continuation rows without truncation');
foreach ($longNoteSheet->query('//s:c/s:is/s:t') as $cell) {
    annualXlsxAssert(mb_strlen($cell->textContent, 'UTF-8') <= 32767, 'Every narrative cell remains within Excel text limit');
}
annualXlsxAssert($longNoteSheet->query('//s:f')->length === 0, 'Long note continuation cells remain literal text');
annualXlsxAssert($longNoteSheet->query('//s:row[number(@ht)>409]')->length === 0, 'Long notes remain within supported Excel row height');

$longMonths = [];
for ($year = 2025; $year <= 2026; $year++) for ($month = 1; $month <= 12; $month++) $longMonths[] = sprintf('%04d-%02d', $year, $month);
$longParts = OfficePackage::read($exporter->toBinary(AnnualReport::build([], $longMonths)));
annualXlsxAssert(count(array_filter(array_keys($longParts), static fn($name) => (bool)preg_match('#^xl/charts/chart\d+\.xml$#', $name))) === 24, '24-month report splits charts into readable 12-month panels');
try {
    $exporter->toBinary(['months' => [['month' => '2026-01'], ['month' => '2026-01']], 'metrics' => []]);
    annualXlsxAssert(false, 'Duplicate selection must fail');
} catch (InvalidArgumentException $e) { annualXlsxAssert(true, 'Duplicate selection rejected'); }
try {
    $tooMany = array_fill(0, 25, ['month' => '2026-01']);
    $exporter->toBinary(['months' => $tooMany]);
    annualXlsxAssert(false, 'Unbounded selection must fail');
} catch (InvalidArgumentException $e) { annualXlsxAssert(true, 'More than 24 months rejected'); }

if (($output = getenv('ANNUAL_XLSX_OUTPUT')) !== false && $output !== '') file_put_contents($output, $binary);
echo 'annual_xlsx_export_test: ' . $checks . " checks passed\n";
