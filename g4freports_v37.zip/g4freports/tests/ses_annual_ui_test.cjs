'use strict';
// Run the actual annual controller with a small DOM and one-use CSRF server.
const assert = require('assert'), fs = require('fs'), vm = require('vm'), path = require('path');
const turn = () => new Promise(r => setImmediate(r));
class Element {
  constructor(tag) { this.tagName = tag; this.children = []; this.dataset = {}; this.events = {}; this.value = ''; this.textContent = ''; this.disabled = false; }
  appendChild(n) { n.parent = this; this.children.push(n); return n; }
  removeChild(n) { this.children.splice(this.children.indexOf(n), 1); }
  remove() { if (this.parent) this.parent.removeChild(this); }
  get firstChild() { return this.children[0]; }
  setAttribute(k,v) { this[k] = v; }
  addEventListener(k,fn) { (this.events[k] ||= []).push(fn); }
  async emit(k) { for (const fn of this.events[k] || []) await fn({ target: this, preventDefault() {} }); }
  click() { return this.emit('click'); }
  querySelectorAll(selector) { const out = [], tags = selector.split(','); const visit = n => { for (const c of n.children) { if (tags.includes(c.tagName)) out.push(c); visit(c); } }; visit(this); return out; }
}
const source = fs.readFileSync(path.join(__dirname, '../assets/js/ses_annual.js'), 'utf8');
const ids = new Map(), root = new Element('div'), requests = [], used = new Set();
ids.set('g4fr-ses-annual', root);
for (const m of source.matchAll(/el\('([^']+)'\)/g)) if (!ids.has(m[1])) { const n = new Element(m[1].includes('button') ? 'button' : 'div'); ids.set(m[1], n); root.appendChild(n); }
ids.get('annual-year').value = '2026';
const revision = 'a'.repeat(64), laterRevision = 'b'.repeat(64), records = [{ id: revision, month:'2026-06', archived_at:'2026-07-01T09:00:00-03:00', scope_label:'Entidade 1 <script>literal</script>' }];
const report = {coverage:{available:1,requested:12},warnings:['Aviso preservado'],financial:{months:[{month:'2026-06',status:'unavailable',available:false,complete:false,gross_cents:null,net_cents:null}],coverage_label:'Nenhuma competência completa',subtotal_cents:{net:null},is_partial:true},metrics:{INS5:{label:'Taxa <literal>',months:[{month:'2026-06',value:0,target:2,status:'met',comparison:{delta_pp:null,reason:'Primeiro mês'}}]}}};
let token = 0, currentToken = '', failTokens = false, exportPayload;
const response = body => ({ok:true,status:200,text:async()=>JSON.stringify(body)});
class TestURL extends URL { static createObjectURL() { return 'blob:download'; } static revokeObjectURL() {} }
const context = {window:{G4FREPORTS_ANNUAL:{api_url:'/archive',csrf_url:'/csrf',export_url:'/export',nonce:'nonce'},location:{href:'https://example.invalid/annual'}},document:{getElementById:id=>ids.get(id),createElement:tag=>new Element(tag),body:new Element('body')},Intl,Map,URL:TestURL,URLSearchParams,AbortController,setTimeout:()=>1,clearTimeout:()=>{},fetch:async(url,request={})=>{
  const u = new URL(url,'https://example.invalid'), body = Object.fromEntries(request.body || []); requests.push({u,body,request});
  assert.equal(request.credentials,'same-origin'); assert.equal(request.cache,'no-store');
  if (u.pathname === '/csrf') { if(failTokens) return {ok:false,status:403,text:async()=>'<html>expired</html>'}; currentToken = 'one-use-'+(++token); return response({ok:true,csrf_token:currentToken}); }
  if (request.method === 'POST') { assert.equal(body._glpi_csrf_token,currentToken); assert(!used.has(currentToken)); used.add(currentToken); assert.equal(body._ses_nonce,'nonce'); }
  if (u.pathname === '/export') { exportPayload = JSON.parse(body.payload); return {ok:true,status:200,headers:{get:()=> 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'},blob:async()=>({size:100})}; }
  if(body.action==='preview') return response({ok:true,report});
  assert.equal(u.searchParams.get('action'),'list'); assert.equal(u.searchParams.get('_ses_nonce'),'nonce'); return response({ok:true,revisions:records});
}};
vm.createContext(context); vm.runInContext(source,context);
const text = n => n.textContent + n.children.map(text).join(' ');
(async()=>{
  await turn(); await turn();
  assert.equal(root.querySelectorAll('input').length,12);
  assert.equal(root.querySelectorAll('select').length,12);
  assert(root.querySelectorAll('input').every(n=>n.checked),'Year includes missing months explicitly');
  assert.equal(ids.get('annual-word').disabled,true,'Export requires review');
  const june = root.querySelectorAll('select')[5]; june.value = revision; await june.emit('change');
  await ids.get('annual-preview-button').emit('click');
  assert.equal(ids.get('annual-word').disabled,false);
  assert(text(ids.get('annual-preview-body')).includes('Total líquido não apurado'));
  assert(!text(ids.get('annual-preview-body')).includes('R$'),'Unknown finances never become zero');
  assert(text(ids.get('annual-preview-body')).includes('0,00%'),'Actual metric zero remains visible');
  assert(text(ids.get('annual-preview-body')).includes('encerramento não confirmado'),'Unknown period closure is explicit');
  await ids.get('annual-word').emit('click'); await turn(); await turn();
  assert.equal(exportPayload.months.length,12); assert.equal(exportPayload.selections[0].id,revision);
  assert(!requests.some(r=>r.u.searchParams.get('action')==='generate'),'No extraction call');
  // A new archive appears after review. Export must keep the pinned ID.
  records.unshift({...records[0],id:laterRevision});
  await ids.get('annual-year-form').emit('submit'); await ids.get('annual-word').emit('click'); await turn(); await turn();
  assert.equal(exportPayload.selections[0].id,revision);
  const juneNew = root.querySelectorAll('select')[5]; juneNew.value=laterRevision; await juneNew.emit('change');
  assert(ids.get('annual-word').disabled,'Changing a revision invalidates reviewed selection');
  failTokens=true; const posts=requests.filter(r=>r.request.method==='POST').length;
  await ids.get('annual-preview-button').emit('click');
  assert.equal(requests.filter(r=>r.request.method==='POST').length,posts,'Failed CSRF refresh prevents dispatch');
  failTokens=false; report.coverage.available=0; await ids.get('annual-preview-button').emit('click');
  assert(ids.get('annual-word').disabled && ids.get('annual-excel').disabled,'All-missing preview cannot export an empty report');
  report.coverage.available=1; report.metrics.INS5.months[0].period_completeness='provisional'; await ids.get('annual-preview-button').emit('click');
  assert(text(ids.get('annual-preview-body')).includes('mês provisório'),'Open month remains explicitly provisional');
  await ids.get('annual-clear').emit('click');
  assert(ids.get('annual-preview-button').disabled); assert(root.querySelectorAll('input').every(n=>!n.checked));
  // Year navigation preserves selections, with an explicit24-month bound.
  await ids.get('annual-all').emit('click'); ids.get('annual-year').value='2025'; await ids.get('annual-year-form').emit('submit'); await ids.get('annual-all').emit('click');
  assert(text(ids.get('annual-selection-count')).startsWith('24 '));
  ids.get('annual-year').value='2024'; await ids.get('annual-year-form').emit('submit'); await ids.get('annual-all').emit('click');
  assert(text(ids.get('annual-selection-count')).startsWith('24 ')); assert(text(ids.get('annual-status')).includes('máximo 24'));
  assert(!source.includes('innerHTML'),'Stored narratives use text nodes');
  console.log('Annual UI: missing months, explicit revisions, immutable export selection, null/zero handling, CSRF, multi-year limit and no extraction passed.');
})().catch(e=>{console.error(e);process.exitCode=1;});
