<?php

// Native bootstrap keeps GLPI's CSRF checks for archive and preview POSTs.
require_once dirname(__DIR__) . '/inc/bootstrap.php';

use GlpiPlugin\G4freports\Config;
use GlpiPlugin\G4freports\Security;
use GlpiPlugin\G4freports\Ses\AnnualReport;
use GlpiPlugin\G4freports\Ses\AnnualSelection;
use GlpiPlugin\G4freports\Ses\MonthlyArchiveStore;
use GlpiPlugin\G4freports\Ses\SnapshotStore;

@ini_set('display_errors', '0');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
$owner = Security::currentUserId();
if ($owner <= 0 || !Security::canUse(Config::merged())) {
    g4fr_json_response(403, ['ok' => false, 'error' => 'Acesso negado.']);
}
$method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
if (!in_array($method, ['GET', 'POST'], true)) {
    header('Allow: GET, POST');
    g4fr_json_response(405, ['ok' => false, 'error' => 'Método não permitido.']);
}
$input = $method === 'POST' ? $_POST : $_GET;
$action = $input['action'] ?? '';
if (!is_string($action) || !in_array($action, ['list', 'archive', 'preview', 'download_snapshot'], true)) {
    g4fr_json_response(400, ['ok' => false, 'error' => 'Operação de arquivo desconhecida.']);
}
$requiredMethod = in_array($action, ['archive', 'preview'], true) ? 'POST' : 'GET';
if ($method !== $requiredMethod) {
    header('Allow: ' . $requiredMethod);
    g4fr_json_response(405, ['ok' => false, 'error' => 'Método não permitido para esta operação.']);
}
$nonce = $input['_ses_nonce'] ?? null;
$expectedNonce = $_SESSION['g4freports_ses_nonce'] ?? null;
if (!is_string($nonce) || !is_string($expectedNonce) || $expectedNonce === '' || !hash_equals($expectedNonce, $nonce)) {
    g4fr_json_response(403, ['ok' => false, 'error' => 'Sessão expirada. Recarregue a área SES.']);
}
$csrf = $method === 'POST' && class_exists('Session') && method_exists('Session', 'getNewCSRFToken') ? Session::getNewCSRFToken() : '';
$reply = static function (int $code, array $result) use ($csrf): void {
    if (is_string($csrf) && $csrf !== '') $result['csrf_token'] = $csrf;
    g4fr_json_response($code, $result);
};
if (session_status() === PHP_SESSION_ACTIVE) session_write_close();

try {
    if ($action === 'list') {
        $year = AnnualSelection::year($input['year'] ?? null);
        $reply(200, ['ok' => true, 'revisions' => MonthlyArchiveStore::listYear($owner, $year)]);
    }
    if ($action === 'archive') {
        $token = AnnualSelection::id($input['token'] ?? null);
        $revision = AnnualSelection::id($input['draft_revision'] ?? null);
        // Only the server-owned draft can be archived. Do not normalize live
        // settings or accept replacement financial/metric/narrative values.
        $snapshot = SnapshotStore::load($token, $owner);
        SnapshotStore::assertCurrentRules($snapshot);
        $record = MonthlyArchiveStore::archive($snapshot, $owner, $revision);
        $reply(200, ['ok' => true, 'record' => $record]);
    }
    if ($action === 'preview') {
        $selection = AnnualSelection::parse($input['payload'] ?? null);
        $records = AnnualSelection::records($selection, $owner);
        $reply(200, ['ok' => true, 'report' => AnnualReport::build($records, $selection['months'])]);
    }
    $id = AnnualSelection::id($input['id'] ?? null);
    $month = AnnualSelection::month($input['month'] ?? null);
    $snapshot = MonthlyArchiveStore::loadSnapshot($owner, $id, $month);
    // Raw archived evidence remains accessible even after calculation rules change.
    $binary = json_encode($snapshot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR);
    header('Content-Type: application/json; charset=UTF-8');
    header('Content-Disposition: attachment; filename="SES-arquivado-' . $month . '-' . substr($id, 0, 12) . '.json"');
    header('Content-Length: ' . strlen($binary));
    echo $binary;
} catch (InvalidArgumentException $e) {
    $reply(400, ['ok' => false, 'error' => $e->getMessage()]);
} catch (RuntimeException $e) {
    $code = in_array($e->getCode(), [404, 409, 503], true) ? $e->getCode() : 400;
    // Store messages with these codes are deliberately safe for the interface.
    $message = in_array($e->getCode(), [404, 409, 503], true)
        ? $e->getMessage() : 'O rascunho não está disponível para arquivamento. Confira a versão exibida e gere novamente se necessário.';
    $reply($code, ['ok' => false, 'error' => $message]);
} catch (Throwable $e) {
    $reply(500, ['ok' => false, 'error' => 'Não foi possível concluir a operação no arquivo de relatórios. Nenhum relatório mensal foi recalculado.']);
}
