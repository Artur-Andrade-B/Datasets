(function () {
  'use strict';
  var config = window.G4FREPORTS_ANNUAL || {}, root = document.getElementById('g4fr-ses-annual');
  if (!root || root.dataset.initialized) return;
  root.dataset.initialized = '1';
  var state = { busy: false, year: null, records: [], selected: new Map(), reviewed: null, initial: true };
  var fmt = new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  var money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
  function el(id) { return document.getElementById(id); }
  function node(tag, text) { var n = document.createElement(tag); if (text !== undefined) n.textContent = String(text); return n; }
  function clear(n) { while (n.firstChild) n.removeChild(n.firstChild); }
  function notice(text, error) { var n = el('annual-status'); n.textContent = text; n.className = 'g4fr-ses-notice' + (error ? ' error' : ''); n.hidden = false; }
  function selection() {
    var months = Array.from(state.selected.keys()).sort();
    return { months: months, selections: months.filter(function (m) { return !!state.selected.get(m); }).map(function (m) { return { month: m, id: state.selected.get(m) }; }) };
  }
  function invalidate() { state.reviewed = null; el('annual-preview').hidden = true; controls(); }
  function controls() {
    Array.prototype.forEach.call(root.querySelectorAll('input,select,button'), function (n) { n.disabled = state.busy; });
    el('annual-all').disabled = state.busy || state.year === null;
    el('annual-preview-button').disabled = state.busy || !state.selected.size;
    el('annual-word').disabled = el('annual-excel').disabled = state.busy || !state.reviewed;
    el('annual-selection-count').textContent = state.selected.size + ' competência(s) selecionada(s).';
    clear(el('annual-selection'));
    Array.from(state.selected.keys()).sort().forEach(function (month) {
      var b = node('button', month + ' · remover'); b.type = 'button'; b.className = 'btn btn-outline-secondary btn-sm'; b.disabled = state.busy;
      b.addEventListener('click', function () { state.selected.delete(month); invalidate(); renderCatalog(); });
      el('annual-selection').appendChild(b);
    });
  }
  async function json(response) {
    var result; try { result = JSON.parse(await response.text()); } catch (e) { throw new Error('O servidor não retornou uma resposta válida (HTTP ' + response.status + '). Confira a sessão do GLPI.'); }
    if (!response.ok || !result.ok) throw new Error(result.error || 'Não foi possível concluir a operação.');
    return result;
  }
  async function get(action, values) {
    var url = new URL(config.api_url, window.location.href); url.searchParams.set('action', action); url.searchParams.set('_ses_nonce', config.nonce);
    Object.keys(values || {}).forEach(function (k) { url.searchParams.set(k, values[k]); });
    var controller = new AbortController(), timer = setTimeout(function () { controller.abort(); }, 30000);
    try { return await json(await fetch(url.toString(), { credentials: 'same-origin', cache: 'no-store', signal: controller.signal })); }
    finally { clearTimeout(timer); }
  }
  var queue = Promise.resolve();
  function post(url, body, consume) {
    var operation = queue.then(async function () {
      var controller = new AbortController(), timer = setTimeout(function () { controller.abort(); }, 60000);
      try {
        var tokenUrl = new URL(config.csrf_url, window.location.href); tokenUrl.searchParams.set('action', 'get_csrf'); tokenUrl.searchParams.set('payload', JSON.stringify({ _ses_nonce: config.nonce }));
        var token = await json(await fetch(tokenUrl.toString(), { credentials: 'same-origin', cache: 'no-store', signal: controller.signal }));
        if (typeof token.csrf_token !== 'string' || !token.csrf_token) throw new Error('Não foi possível validar a sessão.');
        body.set('_glpi_csrf_token', token.csrf_token); body.set('_ses_nonce', config.nonce);
        return await consume(await fetch(url, { method: 'POST', body: body, credentials: 'same-origin', cache: 'no-store', signal: controller.signal }));
      } finally { clearTimeout(timer); }
    });
    queue = operation.catch(function () {}); return operation;
  }
  function selectedId(month) { return state.selected.has(month) ? state.selected.get(month) : ''; }
  function table(headers, rows) {
    var wrap = node('div'); wrap.className = 'g4fr-ses-table-wrap'; var t = node('table'); t.className = 'g4fr-ses-table'; var tr = node('tr'), head = node('thead'), body = node('tbody');
    headers.forEach(function (s) { tr.appendChild(node('th', s)); }); head.appendChild(tr); t.appendChild(head);
    rows.forEach(function (row) { var r = node('tr'); row.forEach(function (s) { r.appendChild(node('td', s === null || s === undefined ? '—' : s)); }); body.appendChild(r); });
    t.appendChild(body); wrap.appendChild(t); return wrap;
  }
  function renderCatalog() {
    clear(el('annual-catalog')); if (state.year === null) return;
    var t = node('table'); t.className = 'g4fr-ses-table'; var h = node('thead'), hr = node('tr'), b = node('tbody');
    ['Incluir', 'Competência', 'Versão arquivada', 'Evidência arquivada'].forEach(function (v) { hr.appendChild(node('th', v)); }); h.appendChild(hr); t.appendChild(h);
    for (var i = 1; i <= 12; i++) (function () {
      var month = state.year + '-' + String(i).padStart(2, '0'), rows = state.records.filter(function (r) { return r.month === month; });
      var r = node('tr'), c = node('td'), check = node('input'); check.type = 'checkbox'; check.checked = state.selected.has(month); check.setAttribute('aria-label', 'Incluir ' + month); c.appendChild(check); r.appendChild(c); r.appendChild(node('td', month));
      c = node('td'); var select = node('select'); select.className = 'form-select'; select.setAttribute('aria-label', 'Versão de ' + month);
      var empty = node('option', rows.length ? 'Escolha uma versão' : 'Sem mês arquivado'); empty.value = ''; select.appendChild(empty);
      rows.forEach(function (v) { var o = node('option', (v.archived_at || '') + ' · ' + (v.scope_label || v.title || 'Relatório mensal') + ' · ' + v.id.slice(0, 8)); o.value = v.id; select.appendChild(o); });
      select.value = selectedId(month); c.appendChild(select); r.appendChild(c);
      var detail = node('td'); r.appendChild(detail);
      function downloadLink() { clear(detail); if (!select.value) return; var a = node('a', 'Baixar dados JSON'); var url = new URL(config.api_url, window.location.href); url.searchParams.set('action', 'download_snapshot'); url.searchParams.set('id', select.value); url.searchParams.set('month', month); url.searchParams.set('_ses_nonce', config.nonce); a.href = url.toString(); detail.appendChild(a); }
      check.addEventListener('change', function () {
        if (check.checked) { if (state.selected.size >= 24 && !state.selected.has(month)) { check.checked = false; notice('Selecione no máximo 24 competências.', true); return; } state.selected.set(month, select.value); } else state.selected.delete(month);
        invalidate();
      });
      select.addEventListener('change', function () {
        if (select.value && !state.selected.has(month) && state.selected.size >= 24) { select.value = ''; notice('Selecione no máximo 24 competências.', true); return; }
        if (select.value) { state.selected.set(month, select.value); check.checked = true; } else if (check.checked) state.selected.set(month, '');
        downloadLink(); invalidate();
      }); downloadLink(); b.appendChild(r);
    })();
    t.appendChild(b); el('annual-catalog').appendChild(t); controls();
  }
  async function loadYear(event) {
    if (event) event.preventDefault(); if (state.busy) return;
    var year = Number(el('annual-year').value); if (!Number.isInteger(year) || year < 2000 || year > 2100) { notice('Informe um ano entre 2000 e 2100.', true); return; }
    state.busy = true; controls(); notice('Consultando as versões arquivadas…');
    try {
      var result = await get('list', { year: year }); state.year = year; state.records = result.revisions || [];
      if (state.initial) { for (var i = 1; i <= 12; i++) state.selected.set(year + '-' + String(i).padStart(2, '0'), ''); state.initial = false; }
      renderCatalog(); notice('Escolha a versão de cada mês. Competências sem versão selecionada serão identificadas como ausentes.');
    } catch (error) { notice(error.name === 'AbortError' ? 'A consulta ao arquivo demorou. Tente novamente.' : error.message, true); }
    finally { state.busy = false; controls(); }
  }
  function renderPreview(report) {
    var target = el('annual-preview-body'); clear(target);
    target.appendChild(node('p', report.coverage.available + ' de ' + report.coverage.requested + ' competências com versão selecionada.'));
    (report.warnings || []).forEach(function (s) { target.appendChild(node('p', s)); });
    var f = report.financial; target.appendChild(node('h3', 'Custos mensais')); target.appendChild(node('p', f.coverage_label));
    target.appendChild(table(['Competência', 'Bruto', 'Glosas', 'Ajustes', 'Líquido', 'Situação'], f.months.map(function (m) { return [m.month].concat(['gross_cents', 'deduction_cents', 'adjustment_cents', 'net_cents'].map(function (key) { return m[key] === null || m[key] === undefined || !m.available ? '—' : money.format(m[key] / 100); })).concat([{ missing: 'Ausente', unavailable: 'Indisponível', provisional: 'Mês provisório', incomplete: 'Incompleto', complete: 'Completo' }[m.status] || 'Incompleto']); })));
    target.appendChild(node('p', f.subtotal_cents.net === null || f.subtotal_cents.net === undefined
      ? 'Total líquido não apurado: nenhuma competência encerrada e financeiramente completa.'
      : (f.is_partial ? 'Subtotal líquido dos meses encerrados e financeiramente completos: ' : 'Total líquido: ') + money.format(f.subtotal_cents.net / 100)));
    Object.keys(report.metrics).forEach(function (id) {
      var m = report.metrics[id]; target.appendChild(node('h3', id + ' · ' + m.label));
      target.appendChild(table(['Competência', 'Resultado', 'Meta', 'Situação', 'Comparação'], m.months.map(function (r) {
        var c = r.comparison || {}, movement = { improved: 'Melhora', declined: 'Piora', unchanged: 'Sem variação', unavailable: 'Sem comparação' }[c.direction] || 'Sem comparação';
        var comparison = c.delta_pp === null || c.delta_pp === undefined ? (c.reason || movement) : movement + ': ' + (c.delta_pp > 0 ? '+' : '') + fmt.format(c.delta_pp) + ' p.p. em relação a ' + c.previous_month + (c.gap_months > 0 ? ' (intervalo entre competências selecionadas)' : '');
        var status = { met: 'Meta atingida', unmet: 'Meta não atingida', pending: 'Pendente', provisional: 'Provisório', not_applicable: 'Não aplicável', missing: 'Ausente' }[r.status] || r.status;
        if (r.status !== 'missing' && r.period_completeness !== 'complete') status += r.period_completeness === 'provisional' ? ' / mês provisório' : ' / encerramento não confirmado';
        return [r.month, r.value === null ? '—' : fmt.format(r.value) + '%', r.target === null ? '—' : fmt.format(r.target) + '%', status, comparison];
      })));
    });
    el('annual-preview').hidden = false;
  }
  async function preview() {
    if (state.busy || !state.selected.size) return;
    var payload = selection(), body = new URLSearchParams(); body.set('action', 'preview'); body.set('payload', JSON.stringify(payload)); state.busy = true; controls(); notice('Preparando a comparação dos meses selecionados…');
    try { var result = await post(config.api_url, body, json); renderPreview(result.report); state.reviewed = result.report.coverage.available > 0 ? payload : null; notice(state.reviewed ? 'Comparação preparada. Word e Excel usarão exatamente estas versões.' : 'Nenhuma versão selecionada. Escolha ao menos uma versão arquivada para exportar.'); }
    catch (error) { state.reviewed = null; notice(error.name === 'AbortError' ? 'A consulta demorou. Tente novamente.' : error.message, true); }
    finally { state.busy = false; controls(); }
  }
  async function exportFile(format) {
    if (state.busy || !state.reviewed) return;
    var body = new URLSearchParams(); body.set('format', format); body.set('payload', JSON.stringify(state.reviewed)); state.busy = true; controls(); notice('Preparando o arquivo…');
    try {
      await post(config.export_url, body, async function (response) {
        var type = response.headers.get('Content-Type') || ''; if (!response.ok || !/application\/vnd\.openxmlformats-officedocument/.test(type)) { await json(response); throw new Error('O arquivo não foi retornado.'); }
        var blob = await response.blob(); if (!blob.size) throw new Error('O arquivo retornado está vazio.');
        var url = URL.createObjectURL(blob), a = node('a'); a.href = url; a.download = 'Relatorio_SES_Meses_Selecionados.' + format; document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(url); }, 60000);
      }); notice('Arquivo preparado para download.');
    } catch (error) { notice(error.name === 'AbortError' ? 'A exportação demorou. Tente novamente com menos competências.' : error.message, true); }
    finally { state.busy = false; controls(); }
  }
  el('annual-year-form').addEventListener('submit', loadYear);
  el('annual-all').addEventListener('click', function () { if (state.busy || state.year === null) return; var months = []; for (var i = 1; i <= 12; i++) months.push(state.year + '-' + String(i).padStart(2, '0')); if (state.selected.size + months.filter(function (m) { return !state.selected.has(m); }).length > 24) { notice('Selecione no máximo 24 competências.', true); return; } months.forEach(function (m) { if (!state.selected.has(m)) state.selected.set(m, ''); }); invalidate(); renderCatalog(); });
  el('annual-clear').addEventListener('click', function () { if (state.busy) return; state.selected.clear(); invalidate(); renderCatalog(); });
  el('annual-preview-button').addEventListener('click', preview);
  el('annual-word').addEventListener('click', function () { exportFile('docx'); });
  el('annual-excel').addEventListener('click', function () { exportFile('xlsx'); });
  loadYear();
})();
