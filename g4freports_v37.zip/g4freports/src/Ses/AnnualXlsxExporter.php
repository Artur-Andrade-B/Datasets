<?php

namespace GlpiPlugin\G4freports\Ses;

/** Compact, archive-only workbook. No source queries or monthly KPI recalculation. */
final class AnnualXlsxExporter
{
    private array $sheets = [];
    private array $report = [];

    public function filename(array $report): string
    {
        $months = array_column($report['months'] ?? [], 'month');
        $first = preg_replace('/[^0-9-]/', '', (string)($months[0] ?? ''));
        $last = preg_replace('/[^0-9-]/', '', (string)($months ? end($months) : ''));
        return 'Analise_SES_' . $first . ($last !== $first ? '_a_' . $last : '') . '.xlsx';
    }

    public function toBinary(array $report): string
    {
        $months = $report['months'] ?? [];
        if (count($months) < 1 || count($months) > 24 || count($report['metrics'] ?? []) > 12 || count($report['financial']['months'] ?? []) > 24) {
            throw new \InvalidArgumentException('Selecione de 1 a 24 competências para a análise.');
        }
        $previous = '';
        foreach ($months as $month) {
            $key = (string)($month['month'] ?? '');
            if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/D', $key) || $key <= $previous) {
                throw new \InvalidArgumentException('As competências devem ser únicas e estar em ordem cronológica.');
            }
            $previous = $key;
        }
        $this->report = $report;
        $this->sheets = [$this->overview(), $this->financial()];
        foreach ($report['metrics'] ?? [] as $id => $metric) {
            if (!preg_match('/^INS([1-9]|1[0-2])$/D', (string)$id) || count($metric['months'] ?? []) > 24) {
                throw new \InvalidArgumentException('Identificador de indicador inválido.');
            }
            $this->sheets[] = $this->metric((string)$id, $metric);
        }
        $this->sheets[] = $this->notes();
        return $this->package();
    }

    private function sheet(string $name, array $widths, string $title): array
    {
        $sheet = ['name' => $name, 'widths' => $widths, 'rows' => [], 'heights' => [], 'merges' => [], 'charts' => [], 'filter' => ''];
        $titleLines = max(1, (int)ceil(mb_strlen($title, 'UTF-8') / (array_sum($widths) / 2)));
        $this->merged($sheet, 1, $title, 1, min(409, 28 * $titleLines + 10));
        $this->merged($sheet, 2, 'G4F | Contrato SES/DF 053592/2025 | ' . $this->period(), 2, 26);
        $this->merged($sheet, 3, 'Fonte: resumos mensais arquivados. Valores, metas e regras preservados na data de cada apuração.', 4, 30);
        return $sheet;
    }

    private function period(): string
    {
        $months = array_column($this->report['months'], 'month');
        return $months[0] . (count($months) > 1 ? ' a ' . end($months) : '') . ' (' . count($months) . ' competências selecionadas)';
    }

    private function overview(): array
    {
        $s = $this->sheet('Resumo', [14, 23, 24, 28, 26, 65], 'Análise histórica dos indicadores');
        $coverage = $this->report['coverage'] ?? [];
        $this->merged($s, 5, (int)($coverage['available'] ?? 0) . ' de ' . count($this->report['months']) . ' competências com resumo arquivado. Meses ausentes permanecem sem resultado.', 5, 32);
        $this->merged($s, 6, 'Não são calculados indicadores anuais nem médias de percentuais. A variação mensal é apresentada em pontos percentuais apenas quando comparável.', 4, 38);
        $this->headers($s, 7, ['Competência', 'Arquivo', 'Regras arquivadas', 'Data da apuração', 'Referência do arquivo', 'Observações']);
        $r = 8;
        foreach ($this->report['months'] as $month) {
            $summary = $month['summary'] ?? [];
            $known = ($summary['source_identity']['status'] ?? 'unknown') === 'known';
            $notes = trim((string)($summary['scope_label'] ?? '') . "\n" . $this->text($summary['warnings'] ?? []));
            if (($month['status'] ?? '') === 'available' && ($summary['period']['completeness'] ?? 'unknown') !== 'complete') {
                $notes = trim('Competência provisória ou encerramento não confirmado. ' . ($summary['period']['note'] ?? '') . "\n" . $notes);
            }
            if (($month['status'] ?? '') === 'missing') $notes = 'Resumo mensal ausente. Não substituído por zero.';
            elseif (!$known) $notes = trim('Origem arquivada não identificada; comparações podem estar indisponíveis. ' . $notes);
            foreach ($this->textChunks($notes, 60) as $part => $chunk) {
                $this->row($s, $r++, [$month['month'], $part ? 'Notas (continuação)' : (($month['status'] ?? '') === 'available' ? 'Disponível' : 'Ausente'), $part ? '' : ($summary['rules_version'] ?? ''), $part ? '' : ($summary['generated_at'] ?? ''), $part ? '' : ($month['record_id'] ?? ''), $chunk], [0, 0, 0, 0, 0, 4], max(34, $this->height($chunk, 60) - 8));
            }
        }
        $s['filter'] = 'A7:F' . ($r - 1);
        if (!empty($this->report['warnings'])) {
            $this->merged($s, $r++, 'Observações da análise', 3, 26);
            foreach ($this->report['warnings'] as $warning) {
                foreach ($this->textChunks($this->text($warning), 130) as $chunk) $this->merged($s, $r++, $chunk, 4, max(24, $this->height($chunk, 130) - 6));
            }
        }
        return $s;
    }

    private function financial(): array
    {
        $s = $this->sheet('Financeiro', [14, 22, 19, 19, 19, 19, 58], 'Valores financeiros arquivados');
        $financial = $this->report['financial'] ?? [];
        $this->merged($s, 5, (string)($financial['coverage_label'] ?? 'Cobertura financeira conforme os arquivos disponíveis.'), 5, 30);
        $this->merged($s, 6, 'Subtotal apenas das competências completas. Valores parciais continuam visíveis, mas não integram o subtotal. Valores em reais (R$).', 4, 35);
        $this->headers($s, 7, ['Competência', 'Situação financeira', 'Bruto (R$)', 'Glosa (R$)', 'Ajuste (R$)', 'Líquido (R$)', 'Observações']);
        $byMonth = [];
        foreach ($financial['months'] ?? [] as $month) $byMonth[$month['month']] = $month;
        $precisionFallback = false;
        $unsafeSubtotal = [false, false, false, false];
        $r = 8;
        foreach ($this->report['months'] as $selected) {
            $month = $byMonth[$selected['month']] ?? ['status' => 'missing'];
            $status = ['complete' => 'Completo', 'incomplete' => 'Parcial', 'provisional' => 'Provisório', 'unavailable' => 'Indisponível', 'missing' => 'Ausente'][$month['status'] ?? 'missing'] ?? 'Indisponível';
            $values = [];
            foreach (['gross_cents', 'deduction_cents', 'adjustment_cents', 'net_cents'] as $i => $key) {
                $cents = $month[$key] ?? null;
                $number = self::number($cents);
                $exactText = is_int($cents) && !self::excelSafeCents($cents);
                $values[] = $exactText ? self::exactCurrency($cents) : ($number === null ? null : $number / 100);
                if ($exactText) {
                    $precisionFallback = true;
                    $s['widths'][$i + 2] = 34;
                    if (($month['status'] ?? '') === 'complete') $unsafeSubtotal[$i] = true;
                }
            }
            $note = $this->text($month['notes'] ?? []);
            foreach ($this->textChunks($note, 53) as $part => $chunk) {
                $this->row($s, $r++, array_merge([$selected['month'], $part ? 'Notas (continuação)' : $status], $part ? [null, null, null, null] : $values, [$chunk]), [0, 0, 7, 7, 7, 7, 4], max(36, $this->height($chunk, 53)));
            }
        }
        $last = $r - 1;
        $s['filter'] = 'A7:G' . $last;
        $this->put($s, $r, 1, 'Subtotal das competências completas', 5);
        $s['merges'][] = 'A' . $r . ':B' . $r;
        foreach (['C', 'D', 'E', 'F'] as $i => $column) {
            $cents = $financial['subtotal_cents'][['gross', 'deduction', 'adjustment', 'net'][$i]] ?? null;
            $total = self::number($cents);
            if (is_int($cents) && (!self::excelSafeCents($cents) || $unsafeSubtotal[$i])) {
                // Text amounts must never be silently excluded by SUMIF; preserve the exact archived subtotal.
                $this->put($s, $r, $i + 3, self::exactCurrency($cents), 10);
                $precisionFallback = true;
                $s['widths'][$i + 2] = 34;
            } else {
                $this->put($s, $r, $i + 3, $total === null ? '' : $total / 100, 10, 'IF(COUNTIF($B$8:$B$' . $last . ',"Completo")=0,"",SUMIF($B$8:$B$' . $last . ',"Completo",' . $column . '8:' . $column . $last . '))');
            }
        }
        if ($precisionFallback) $this->merged($s, 6, 'Subtotal apenas das competências completas. Montantes acima da precisão de 15 algarismos do Excel são preservados como texto monetário exato. Subtotais afetados também são valores arquivados em texto, sem fórmula. Valores em reais (R$).', 4, 58);
        $s['heights'][$r] = 40;
        $excluded = $financial['excluded_months'] ?? [];
        if ($excluded) $this->merged($s, $r + 2, 'Fora do subtotal: ' . implode(', ', $excluded) . '.', 4, 35);
        return $s;
    }

    private function metric(string $id, array $metric): array
    {
        $s = $this->sheet($id, [15, 15, 15, 25, 14, 14, 17, 21, 49], $id . ' — ' . (string)($metric['label'] ?? $id));
        $this->merged($s, 5, 'A evolução respeita o sentido de melhoria registrado em cada competência. Mudanças de critério impedem a comparação direta.', 5, 30);
        $this->merged($s, 6, 'Resultado e meta são valores arquivados. Δ em pontos percentuais (p.p.); meses ausentes, provisórios ou incompatíveis não recebem comparação.', 4, 34);
        $this->headers($s, 7, ['Competência', 'Resultado', 'Meta', 'Situação arquivada', 'Numerador', 'Denominador', 'Δ (p.p.)', 'Evolução', 'Comparação / motivo']);
        $byMonth = [];
        foreach ($metric['months'] ?? [] as $month) $byMonth[$month['month']] = $month;
        $rowByMonth = [];
        foreach ($this->report['months'] as $index => $selected) $rowByMonth[$selected['month']] = $index + 8;
        $categories = $results = $targets = [];
        $r = 8;
        foreach ($this->report['months'] as $selected) {
            $month = $byMonth[$selected['month']] ?? ['status' => 'missing'];
            $value = self::number($month['value'] ?? null);
            $target = self::number($month['target'] ?? null);
            $comparison = $month['comparison'] ?? [];
            $previous = $comparison['previous_month'] ?? '';
            $previousRow = $rowByMonth[$previous] ?? null;
            $delta = self::number($comparison['delta_pp'] ?? null);
            $priorValue = self::number($byMonth[$previous]['value'] ?? null);
            // AnnualReport owns comparability; do not invent a comparison for a gap or incompatible archive.
            $comparable = $delta !== null && $value !== null && $priorValue !== null && $previousRow !== null && $previousRow < $r;
            $status = ($month['status'] ?? '') === 'missing' ? 'Arquivo ausente' : OfficePackage::status($month);
            if (($month['status'] ?? '') !== 'missing' && ($month['period_completeness'] ?? 'unknown') !== 'complete') {
                $status .= ($month['period_completeness'] ?? '') === 'provisional' ? ' / mês provisório' : ' / encerramento não confirmado';
            }
            $direction = ['improved' => 'Melhora', 'declined' => 'Piora', 'unchanged' => 'Estável', 'unavailable' => 'Não comparável'][$comparison['direction'] ?? 'unavailable'] ?? 'Não comparável';
            $reason = (string)($comparison['reason'] ?? 'Comparação indisponível.');
            if (!empty($comparison['interval_label'])) $reason = $comparison['interval_label'] . '. ' . $reason;
            elseif ($previous !== '') $reason = 'Referência: ' . $previous . '. ' . $reason;
            $this->row($s, $r, [$selected['month'], $value === null ? null : $value / 100, $target === null ? null : $target / 100, $status, self::number($month['numerator'] ?? null), self::number($month['denominator'] ?? null), null, $comparable ? $direction : 'Não comparável', $reason], [0, 6, 6, 0, 8, 8, 9, 0, 4], max(55, $this->height($reason, 44)));
            if ($comparable) {
                $this->put($s, $r, 7, $delta, 9, 'IF(AND(ISNUMBER(B' . $r . '),ISNUMBER(B' . $previousRow . ')),(B' . $r . '-B' . $previousRow . ')*100,"")');
                $improves = ($month['direction'] ?? $metric['direction'] ?? '') === 'lte' ? '<' : '>';
                $formula = 'IF(ISNUMBER(G' . $r . '),IF(G' . $r . '=0,"Estável",IF(G' . $r . $improves . '0,"Melhora","Piora")),"Não comparável")';
                $this->put($s, $r, 8, $direction, 0, $formula);
            }
            $categories[] = $selected['month'];
            $results[] = $value === null ? null : $value / 100;
            $targets[] = $target === null ? null : $target / 100;
            $r++;
        }
        $s['filter'] = 'A7:I' . ($r - 1);
        $this->merged($s, ++$r, 'Valores mensais e metas arquivadas. Consulte a situação de cada mês na tabela antes de interpretar as barras.', 4, 32);
        $chartTop = $r + 1;
        foreach (array_chunk($categories, 12) as $chunk => $labels) {
            $offset = $chunk * 12;
            $start = 8 + $offset;
            $end = $start + count($labels) - 1;
            $height = max(16, 7 + 2 * count($labels));
            $s['charts'][] = ['title' => $id . ' — ' . $labels[0] . ' a ' . end($labels), 'kind' => 'bar', 'unit' => 'percent',
                'categories' => $labels, 'category_ref' => "'" . $id . "'!\$A\$" . $start . ':$A$' . $end,
                'axis_category_title' => 'Competência', 'axis_value_title' => 'Percentual (%)', 'anchor' => [0, $chartTop, 9, $chartTop + $height],
                'series' => [
                    ['name' => 'Resultado arquivado', 'color' => ReportStyle::BLUE, 'values' => array_slice($results, $offset, 12), 'value_ref' => "'" . $id . "'!\$B\$" . $start . ':$B$' . $end],
                    ['name' => 'Meta arquivada', 'color' => ReportStyle::YELLOW_DARK, 'values' => array_slice($targets, $offset, 12), 'value_ref' => "'" . $id . "'!\$C\$" . $start . ':$C$' . $end],
                ]];
            $chartTop += $height + 2;
        }
        $this->merged($s, $chartTop + 1, 'Informações preservadas em cada competência', 3, 26);
        $r = $chartTop + 2;
        foreach ($this->report['months'] as $selected) {
            $source = $selected['summary']['metrics'][$id] ?? null;
            if (!is_array($source)) continue;
            $text = $selected['month'] . ' — ' . (string)($source['label'] ?? $source['title'] ?? $id);
            if (!empty($source['title']) && $source['title'] !== ($source['label'] ?? '')) $text .= "\n" . $source['title'];
            $text .= "\nSentido da melhoria: " . (($source['direction'] ?? '') === 'lte' ? 'redução do percentual.' : 'aumento do percentual.');
            foreach (['method' => 'Método', 'note' => 'Nota'] as $key => $label) {
                if (!empty($source[$key])) $text .= "\n" . $label . ': ' . $this->text($source[$key]);
            }
            foreach ($this->textChunks($text, 160) as $part => $chunk) {
                if ($part) $this->merged($s, $r++, $selected['month'] . ' (continuação)', 5, 26);
                $this->merged($s, $r++, $chunk, 4, $this->height($chunk, 160));
            }
        }
        return $s;
    }

    private function notes(): array
    {
        $s = $this->sheet('Notas mensais', [15, 28, 115], 'Contexto dos arquivos mensais');
        $this->merged($s, 5, 'Textos registrados no relatório mensal. A análise não infere causas para variações sem informação arquivada.', 4, 32);
        $this->headers($s, 7, ['Competência', 'Informação', 'Conteúdo arquivado']);
        $r = 8;
        foreach ($this->report['months'] as $month) {
            if (($month['status'] ?? '') !== 'available') {
                $this->row($s, $r++, [$month['month'], 'Arquivo ausente', 'Não há resumo mensal arquivado para esta competência.'], [0, 0, 4], 32);
                continue;
            }
            $summary = $month['summary'] ?? [];
            foreach (['executive_summary' => 'Resumo executivo', 'actions' => 'Ações', 'notes' => 'Observações', 'phone_survey_actions' => 'Ações de telefonia'] as $key => $label) {
                $text = $this->text($summary['manual'][$key] ?? '');
                $this->noteRows($s, $r, $month['month'], $label, $text !== '' ? $text : 'Não informado no arquivo mensal.');
            }
            $staffing = $this->text($summary['staffing'] ?? []);
            if ($staffing !== '') $this->noteRows($s, $r, $month['month'], 'Equipe', $staffing);
            $totals = $this->text($summary['totals'] ?? []);
            if ($totals !== '') $this->noteRows($s, $r, $month['month'], 'Totais arquivados', $totals);
            $rules = $this->text($summary['rule_notes'] ?? []);
            if ($rules !== '') $this->noteRows($s, $r, $month['month'], 'Regras arquivadas', $rules);
        }
        $s['filter'] = 'A7:C' . ($r - 1);
        return $s;
    }

    private function noteRows(array &$s, int &$row, string $month, string $label, string $text): void
    {
        foreach ($this->textChunks($text, 100) as $part => $chunk) {
            $this->row($s, $row++, [$month, $label . ($part ? ' (continuação)' : ''), $chunk], [0, 0, 4], $this->height($chunk, 100));
        }
    }

    /** Keep literal text intact while avoiding Excel's cell and row-height limits. */
    private function textChunks(string $text, int $width): array
    {
        if ($text === '') return [''];
        $chunks = []; $current = ''; $lines = 0;
        // Keep newline delimiters in the pieces so concatenating chunks restores the source exactly.
        foreach (preg_split('/(?<=\n)/u', $text, -1, PREG_SPLIT_NO_EMPTY) ?: [$text] as $line) {
            while ($line !== '') {
                $part = mb_substr($line, 0, $width, 'UTF-8');
                $line = mb_substr($line, mb_strlen($part, 'UTF-8'), null, 'UTF-8');
                if ($lines === 20) { $chunks[] = $current; $current = ''; $lines = 0; }
                $current .= $part;
                $lines++;
            }
        }
        if ($current !== '') $chunks[] = $current;
        return $chunks;
    }

    private static function number($value): ?float
    {
        return (is_int($value) || is_float($value)) && is_finite((float)$value) ? (float)$value : null;
    }

    private static function excelSafeCents(int $cents): bool
    {
        return $cents >= -999999999999999 && $cents <= 999999999999999;
    }

    private static function exactCurrency(int $cents): string
    {
        // Never convert through a float, including PHP_INT_MIN.
        $text = (string)$cents;
        $negative = isset($text[0]) && $text[0] === '-';
        $digits = str_pad($negative ? substr($text, 1) : $text, 3, '0', STR_PAD_LEFT);
        $whole = substr($digits, 0, -2);
        return ($negative ? '-' : '') . 'R$ ' . preg_replace('/\B(?=(\d{3})+(?!\d))/', '.', $whole) . ',' . substr($digits, -2);
    }

    private function text($value): string
    {
        if (!is_array($value)) return is_scalar($value) ? (string)$value : '';
        $lines = [];
        foreach ($value as $key => $item) {
            $text = $this->text($item);
            if ($text !== '') $lines[] = (is_string($key) ? $key . ': ' : '') . $text;
        }
        return implode("\n", $lines);
    }

    private function height(string $text, int $width): int
    {
        $lines = 0;
        foreach (explode("\n", $text) as $line) $lines += max(1, (int)ceil(mb_strlen($line, 'UTF-8') / $width));
        return min(409, max(30, 16 * $lines + 10));
    }

    private function put(array &$s, int $row, int $col, $value, int $style = 0, ?string $formula = null): void
    {
        $s['rows'][$row][$col] = ['value' => $value, 'style' => $style, 'formula' => $formula];
    }

    private function row(array &$s, int $row, array $values, array $styles, int $height): void
    {
        foreach ($values as $i => $value) $this->put($s, $row, $i + 1, $value, $styles[$i] ?? 0);
        $s['heights'][$row] = $height;
    }

    private function merged(array &$s, int $row, string $text, int $style, int $height): void
    {
        $this->put($s, $row, 1, $text, $style);
        $s['merges'][] = 'A' . $row . ':' . self::col(count($s['widths'])) . $row;
        $s['heights'][$row] = $height;
    }

    private function headers(array &$s, int $row, array $values): void
    {
        $this->row($s, $row, $values, array_fill(0, count($values), 3), 40);
    }

    private static function col(int $col): string
    {
        $value = '';
        while ($col > 0) { $col--; $value = chr(65 + $col % 26) . $value; $col = intdiv($col, 26); }
        return $value;
    }

    private function worksheet(array $s): string
    {
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0" showGridLines="0"><pane ySplit="7" topLeftCell="A8" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="20"/><cols>';
        foreach ($s['widths'] as $index => $width) $xml .= '<col min="' . ($index + 1) . '" max="' . ($index + 1) . '" width="' . $width . '" customWidth="1"/>';
        $xml .= '</cols><sheetData>';
        ksort($s['rows']);
        foreach ($s['rows'] as $row => $cells) {
            $xml .= '<row r="' . $row . '" ht="' . ($s['heights'][$row] ?? 26) . '" customHeight="1">';
            ksort($cells);
            foreach ($cells as $column => $cell) {
                $value = $cell['value'];
                $xml .= '<c r="' . self::col($column) . $row . '" s="' . $cell['style'] . '"';
                if ($cell['formula'] !== null) {
                    $numeric = self::number($value);
                    $xml .= ($numeric === null ? ' t="str"' : '') . '><f>' . OfficePackage::xml($cell['formula']) . '</f><v>' . ($numeric === null ? OfficePackage::xml($value) : sprintf('%.15g', $numeric)) . '</v></c>';
                } elseif ($value === null) $xml .= '/>';
                elseif (self::number($value) !== null) $xml .= '><v>' . sprintf('%.15g', $value) . '</v></c>';
                else $xml .= ' t="inlineStr"><is><t xml:space="preserve">' . OfficePackage::xml($value) . '</t></is></c>';
            }
            $xml .= '</row>';
        }
        $xml .= '</sheetData>';
        if ($s['filter'] !== '') $xml .= '<autoFilter ref="' . $s['filter'] . '"/>';
        if ($s['merges']) {
            $xml .= '<mergeCells count="' . count($s['merges']) . '">';
            foreach ($s['merges'] as $range) $xml .= '<mergeCell ref="' . $range . '"/>';
            $xml .= '</mergeCells>';
        }
        $xml .= '<pageMargins left="0.25" right="0.25" top="0.35" bottom="0.35" header="0.15" footer="0.15"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/>';
        if ($s['charts']) $xml .= '<drawing r:id="rIdChart"/>';
        return $xml . '</worksheet>';
    }

    private function package(): string
    {
        $ns = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/';
        $rels = '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
        $types = '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>';
        $files = ['_rels/.rels' => $rels . '<Relationship Id="rId1" Type="' . $ns . 'officeDocument" Target="xl/workbook.xml"/></Relationships>', 'xl/styles.xml' => $this->styles()];
        $workbook = '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>';
        $workbookRels = $rels . '<Relationship Id="rIdStyles" Type="' . $ns . 'styles" Target="styles.xml"/>';
        $chartNumber = 0;
        foreach ($this->sheets as $index => $s) {
            $number = $index + 1;
            $workbook .= '<sheet name="' . OfficePackage::xml($s['name']) . '" sheetId="' . $number . '" r:id="rId' . $number . '"/>';
            $workbookRels .= '<Relationship Id="rId' . $number . '" Type="' . $ns . 'worksheet" Target="worksheets/sheet' . $number . '.xml"/>';
            $files['xl/worksheets/sheet' . $number . '.xml'] = $this->worksheet($s);
            $types .= '<Override PartName="/xl/worksheets/sheet' . $number . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
            if (!$s['charts']) continue;
            $files['xl/worksheets/_rels/sheet' . $number . '.xml.rels'] = $rels . '<Relationship Id="rIdChart" Type="' . $ns . 'drawing" Target="../drawings/drawing' . $number . '.xml"/></Relationships>';
            $drawing = '<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">';
            $drawingRels = $rels;
            foreach ($s['charts'] as $chartIndex => $chart) {
                $chartNumber++;
                $id = 'rId' . ($chartIndex + 1);
                $drawing .= XlsxChart::anchor($chart, $id, $chartNumber);
                $drawingRels .= '<Relationship Id="' . $id . '" Type="' . $ns . 'chart" Target="../charts/chart' . $chartNumber . '.xml"/>';
                $files['xl/charts/chart' . $chartNumber . '.xml'] = XlsxChart::xml($chart);
                $types .= '<Override PartName="/xl/charts/chart' . $chartNumber . '.xml" ContentType="application/vnd.openxmlformats-officedocument.drawingml.chart+xml"/>';
            }
            $files['xl/drawings/drawing' . $number . '.xml'] = $drawing . '</xdr:wsDr>';
            $files['xl/drawings/_rels/drawing' . $number . '.xml.rels'] = $drawingRels . '</Relationships>';
            $types .= '<Override PartName="/xl/drawings/drawing' . $number . '.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>';
        }
        $files['xl/workbook.xml'] = $workbook . '</sheets><calcPr calcId="191029" fullCalcOnLoad="1" forceFullCalc="1"/></workbook>';
        $files['xl/_rels/workbook.xml.rels'] = $workbookRels . '</Relationships>';
        $files['[Content_Types].xml'] = $types . '</Types>';
        return OfficePackage::write($files);
    }

    private function styles(): string
    {
        $xml = '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="3"><numFmt numFmtId="164" formatCode="0.00%"/><numFmt numFmtId="165" formatCode="&quot;R$&quot; #,##0.00;[Red](&quot;R$&quot; #,##0.00)"/><numFmt numFmtId="166" formatCode="+0.00;-0.00;0.00"/></numFmts><fonts count="5">';
        foreach ([[11, ReportStyle::NAVY, false], [21, ReportStyle::WHITE, true], [11, ReportStyle::WHITE, true], [10, ReportStyle::MUTED, false], [11, ReportStyle::NAVY, true]] as $font) {
            $xml .= '<font><sz val="' . $font[0] . '"/><color rgb="FF' . $font[1] . '"/><name val="Arial"/>' . ($font[2] ? '<b/>' : '') . '</font>';
        }
        $xml .= '</fonts><fills count="6"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>';
        foreach ([ReportStyle::NAVY, ReportStyle::BLUE, ReportStyle::LIGHT_GRAY, ReportStyle::CAUTION_FILL] as $color) $xml .= '<fill><patternFill patternType="solid"><fgColor rgb="FF' . $color . '"/><bgColor indexed="64"/></patternFill></fill>';
        $xml .= '</fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left/><right/><top/><bottom style="hair"><color rgb="FF' . ReportStyle::BORDER . '"/></bottom><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="11">';
        // base, title, subtitle, header, note, subtotal label, percent, money, count, delta, subtotal money
        foreach ([[0,0,0,1],[0,1,2,0],[0,2,3,0],[0,2,2,0],[0,3,0,1],[0,4,4,1],[164,0,0,1],[165,0,0,1],[3,0,0,1],[166,0,0,1],[165,4,4,1]] as $style) {
            $xml .= '<xf numFmtId="' . $style[0] . '" fontId="' . $style[1] . '" fillId="' . $style[2] . '" borderId="' . $style[3] . '" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="' . ($style[0] ? 'right' : 'left') . '" vertical="center" wrapText="1" indent="1"/></xf>';
        }
        return $xml . '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
    }
}
