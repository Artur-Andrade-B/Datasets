<?php

namespace GlpiPlugin\G4freports\Ses;

/** Comparative report over compact, pinned monthly archives. No extraction or KPI recalculation. */
final class AnnualDocxExporter
{
    private WordChart $charts;
    private array $metricNotes = [];

    public function filename(array $report): string
    {
        $months = array_column($report['months'] ?? [], 'month');
        return 'Relatorio_Comparativo_SES_' . preg_replace('/[^0-9-]/', '', (string)($months[0] ?? ''))
            . '_a_' . preg_replace('/[^0-9-]/', '', (string)($months[count($months) - 1] ?? '')) . '.docx';
    }

    public function toBinary(array $report): string
    {
        $months = $report['months'] ?? [];
        if (!is_array($months) || count($months) < 1 || count($months) > 24 || count($report['metrics'] ?? []) > 12
            || count($report['financial']['months'] ?? []) > 24) {
            throw new \InvalidArgumentException('Selecione de 1 a 24 competências.');
        }
        $previous = '';
        foreach ($months as $month) {
            $key = (string)($month['month'] ?? '');
            if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/D', $key) || $key <= $previous) {
                throw new \InvalidArgumentException('As competências devem ser únicas e estar em ordem cronológica.');
            }
            $previous = $key;
        }
        foreach ($report['metrics'] ?? [] as $id => $metric) {
            if (!preg_match('/^INS([1-9]|1[0-2])$/D', (string)$id) || count($metric['months'] ?? []) > 24) {
                throw new \InvalidArgumentException('Indicador ou número de competências inválido.');
            }
        }
        $binary = @file_get_contents(dirname(__DIR__, 2) . '/resources/docx/papel_timbrado_G4F.docx');
        if (!is_string($binary)) throw new \RuntimeException('O papel timbrado G4F não foi encontrado no pacote do plugin.');
        $files = OfficePackage::read($binary);
        if (!isset($files['word/document.xml'], $files['word/_rels/document.xml.rels'])) {
            throw new \RuntimeException('O modelo G4F não contém os componentes necessários.');
        }
        $this->charts = new WordChart();
        $this->metricNotes = [];
        $files['word/document.xml'] = $this->document($report);
        $files['word/styles.xml'] = $this->styles();
        $files['docProps/core.xml'] = '<?xml version="1.0" encoding="UTF-8"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>Relatório comparativo SES</dc:title><dc:creator>G4F</dc:creator><dc:description>'
            . OfficePackage::xml(implode(', ', array_column($months, 'month'))) . '</dc:description></cp:coreProperties>';
        $this->charts->attach($files);
        return OfficePackage::write($files);
    }

    private function document(array $report): string
    {
        $months = $report['months'];
        $body = $this->p('G4F  |  Secretaria de Estado de Saúde do Distrito Federal', '', false, 20, 'center');
        $body .= '<w:p><w:pPr><w:spacing w:before="3000" w:after="320"/></w:pPr></w:p>';
        $body .= $this->p('Relatório Comparativo Gerencial — SES-DF', 'Title', true, 40, 'center');
        $body .= $this->p('Contrato SES/DF 053592/2025', '', true, 25, 'center');
        $body .= $this->p($months[0]['month'] . ' a ' . $months[count($months) - 1]['month'], '', false, 26, 'center');
        $body .= $this->p(count($months) . ' competências selecionadas · Revisões mensais arquivadas', '', false, 21, 'center');
        $body .= $this->page() . $this->heading('1 Objetivo e cobertura');
        $body .= $this->p('Este relatório compara os resultados das competências selecionadas e preserva os valores, as metas e os textos das revisões mensais fixadas. A evolução é expressa em pontos percentuais e considera o sentido da meta de cada indicador. Não há indicador anual agregado nem média de percentuais mensais.');
        $body .= $this->p('Uma melhora ou piora descreve a variação observada, sem atribuir causas. Resultados pendentes, provisórios, não aplicáveis ou com critérios incompatíveis permanecem identificados e não recebem uma conclusão comparativa. Uma competência ausente não representa zero.');
        $body .= $this->p('As comparações usam as competências selecionadas em sequência. Quando há meses não selecionados entre elas, o intervalo é indicado. Uma competência selecionada sem revisão interrompe a comparação.');
        $coverage = $report['coverage'] ?? [];
        $body .= $this->p('Revisões disponíveis: ' . (int)($coverage['available'] ?? 0) . ' de ' . count($months) . ' competências selecionadas.', '', true);
        $rows = [];
        foreach ($months as $row) {
            $s = $row['summary'] ?? [];
            $rows[] = [$row['month'], $row['status'] === 'available' ? (($s['period']['completeness'] ?? '') === 'complete' ? 'Arquivada · encerrada' : 'Arquivada · ' . $this->periodStatus($s['period']['completeness'] ?? 'unknown')) : 'Ausente',
                $s ? OfficePackage::date($s['generated_at'] ?? '') : '—',
                $this->number($s['totals']['tickets'] ?? null), $this->number($s['totals']['calls_received'] ?? null),
                $this->number($s['staffing']['billing_professionals_total'] ?? $s['staffing']['billed_total'] ?? null)];
        }
        $body .= $this->table(['Mês', 'Revisão', 'Extração mensal', 'Chamados', 'Ligações', 'Profissionais faturados'], $rows, [900, 1700, 2200, 1250, 1250, 2200]);
        $body .= $this->p('Volumes são apresentados por competência; não constituem um percentual anual. O escopo e as observações de cada extração constam da seção 5.', '', false, 18);
        foreach ($report['warnings'] ?? [] as $warning) $body .= $this->p((string)$warning, '', false, 18);
        $body .= $this->heading('2 Valores financeiros mensais');
        $body .= $this->financial($report['financial'] ?? []);
        $body .= $this->heading('3 Evolução dos indicadores');
        $body .= $this->p('Resultado e meta são os valores arquivados em cada mês. A coluna Δ apresenta a diferença para a competência selecionada anterior, em pontos percentuais. Nos limites máximos (≤), a redução é uma melhora; nas metas mínimas (≥), o aumento é uma melhora. A situação de atendimento à meta também é preservada da revisão mensal.');
        $body .= $this->p('A fonte vermelha identifica uma meta não atingida. O gráfico mantém os valores provisórios quando registrados; a situação e a comparabilidade devem ser lidas na tabela. Metas podem variar entre competências. Os motivos de comparação indisponível, os métodos e as ressalvas por indicador estão na seção 4.');
        foreach ($report['metrics'] ?? [] as $metric) {
            $chunks = array_chunk($metric['months'] ?? [], 12);
            foreach ($chunks as $part => $rows) {
                $body .= $this->page();
                $body .= $this->metric($metric, $rows, count($chunks) > 1 ? ' — parte ' . ($part + 1) . ' de ' . count($chunks) : '');
            }
        }
        $body .= $this->page() . $this->heading('4 Critérios e ressalvas dos indicadores');
        $body .= $this->p('As observações idênticas são agrupadas abaixo. Cada referência informa exatamente os indicadores e as competências a que o texto se aplica.', '', false, 18);
        foreach ($this->metricNotes as $text => $references) {
            $groups = [];
            foreach ($references as $id => $noteMonths) $groups[implode(', ', $noteMonths)][] = $id;
            foreach ($groups as $noteMonths => $ids) $body .= $this->p(implode(', ', $ids) . ' · ' . $noteMonths . ' · ' . $text, '', false, 18);
        }
        $body .= $this->page() . $this->heading('5 Informações e observações de cada competência');
        foreach ($months as $row) $body .= $this->monthlyNotes($row);
        $section = '<w:sectPr><w:headerReference w:type="even" r:id="rId11"/><w:headerReference w:type="default" r:id="rId12"/><w:footerReference w:type="default" r:id="rId13"/><w:headerReference w:type="first" r:id="rId14"/><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1560" w:right="1134" w:bottom="1560" w:left="1134" w:header="709" w:footer="709"/><w:cols w:space="708"/></w:sectPr>';
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart"><w:body>' . $body . $section . '</w:body></w:document>';
    }

    private function financial(array $financial): string
    {
        $rows = [];
        foreach ($financial['months'] ?? [] as $row) {
            $rows[] = [$row['month'], ['complete' => 'Completo', 'provisional' => 'Provisório', 'incomplete' => 'Incompleto', 'unavailable' => 'Indisponível', 'missing' => 'Ausente'][$row['status'] ?? ''] ?? 'Indisponível',
                $this->money($row['gross_cents'] ?? null), $this->money($row['deduction_cents'] ?? null), $this->money($row['adjustment_cents'] ?? null), $this->money($row['net_cents'] ?? null)];
        }
        $subtotal = $financial['subtotal_cents'] ?? [];
        $body = $this->table(['Mês', 'Situação', 'Base faturada', 'Glosas', 'Ajustes', 'Valor líquido'], $rows, [900, 1400, 1800, 1800, 1800, 1800]);
        $body .= $this->p('Subtotal dos meses completos', '', true);
        $body .= $this->table(['Base faturada', 'Glosas', 'Ajustes', 'Valor líquido'], [[
            $this->money($subtotal['gross'] ?? null), $this->money($subtotal['deduction'] ?? null),
            $this->money($subtotal['adjustment'] ?? null), $this->money($subtotal['net'] ?? null),
        ]], [2375, 2375, 2375, 2375]);
        $body .= $this->p((string)($financial['coverage_label'] ?? ''), '', false, 18);
        if (!empty($financial['excluded_months'])) $body .= $this->p('Fora do subtotal: ' . implode(', ', $financial['excluded_months']) . '. Os valores parciais, quando arquivados, continuam visíveis na tabela.', '', false, 18);
        foreach ($financial['months'] ?? [] as $row) foreach ($row['notes'] ?? [] as $note) $body .= $this->p($row['month'] . ': ' . $note, '', false, 18);
        return $body;
    }

    private function metric(array $metric, array $months, string $suffix): string
    {
        $id = (string)($metric['id'] ?? '');
        $title = (string)($metric['label'] ?? $id);
        foreach ($months as $month) if (($month['status'] ?? '') !== 'missing') { $title = (string)($month['title'] ?? $month['label'] ?? $title); break; }
        $body = $this->heading($id . ' — ' . $title . $suffix, 2);
        $rows = []; $violations = []; $categories = []; $values = []; $targets = []; $notes = [];
        foreach ($months as $month) {
            $comparison = $month['comparison'] ?? [];
            $delta = $comparison['delta_pp'] ?? null;
            $evolution = $delta === null ? 'Sem comparação' : (['improved' => 'Melhora', 'declined' => 'Piora', 'unchanged' => 'Estável'][$comparison['direction'] ?? ''] ?? 'Sem comparação');
            if ($delta !== null && !empty($comparison['previous_month'])) $evolution .= ' vs ' . $comparison['previous_month'];
            $status = $this->status($month['status'] ?? 'missing');
            if (($month['status'] ?? '') !== 'missing' && ($month['period_completeness'] ?? '') !== 'complete') {
                $status .= ($month['period_completeness'] ?? '') === 'provisional' ? ' · período provisório' : ' · encerramento não confirmado';
            }
            $rows[] = [$month['month'], $this->number($month['numerator'] ?? null) . ' / ' . $this->number($month['denominator'] ?? null),
                $this->percent($month['value'] ?? null), ($month['target'] ?? null) === null ? '—' : (($month['direction'] ?? '') === 'lte' ? '≤ ' : '≥ ') . $this->percent($month['target']),
                $status, $delta === null ? '—' : ($delta > 0 ? '+' : '') . number_format((float)$delta, 2, ',', '.') . ' p.p.', $evolution];
            $violations[] = ($month['status'] ?? '') === 'unmet';
            $category = (string)$month['month'];
            if (($month['status'] ?? '') === 'provisional') $category .= ' (prov.)';
            if (($month['status'] ?? '') === 'missing') $category .= ' (aus.)';
            if (($month['status'] ?? '') === 'pending') $category .= ' (pend.)';
            if (($month['status'] ?? '') !== 'missing' && ($month['period_completeness'] ?? '') !== 'complete') $category .= ($month['period_completeness'] ?? '') === 'provisional' ? ' (mês prov.)' : ' (enc. incerto)';
            $categories[] = $category;
            $values[] = ($month['value'] ?? null) === null ? null : $month['value'] / 100;
            $targets[] = ($month['target'] ?? null) === null ? null : $month['target'] / 100;
            if (!empty($comparison['reason'])) $notes['Comparabilidade: ' . $comparison['reason']][] = $month['month'];
            if (!empty($comparison['gap_months'])) $notes['Intervalo: ' . ($comparison['interval_label'] ?? '')][] = $month['month'];
            $frozenTitle = (string)($month['title'] ?? $month['label'] ?? $title);
            if ($frozenTitle !== $title && ($month['status'] ?? '') !== 'missing') $notes['Denominação arquivada: ' . $frozenTitle][] = $month['month'];
            $frozenLabel = (string)($month['label'] ?? $frozenTitle);
            if ($frozenLabel !== $frozenTitle && ($month['status'] ?? '') !== 'missing') $notes['Rótulo arquivado: ' . $frozenLabel][] = $month['month'];
            foreach (['method' => 'Método arquivado', 'note' => 'Observação arquivada'] as $key => $label) if (trim((string)($month[$key] ?? '')) !== '') $notes[$label . ': ' . $month[$key]][] = $month['month'];
        }
        $body .= $this->table(['Mês', 'Numerador / denominador', 'Resultado', 'Meta', 'Situação', 'Δ (p.p.)', 'Evolução'], $rows, [900, 1400, 1100, 1100, 1500, 1200, 2300], $violations);
        $hasNumbers = count(array_filter(array_merge($values, $targets), static fn($value) => $value !== null)) > 0;
        if ($hasNumbers) {
            $definition = ['kind' => 'bar', 'unit' => 'percent', 'available' => true, 'title' => $id . ' — resultados e metas mensais',
                'categories' => $categories, 'series' => [
                    ['name' => 'Resultado arquivado', 'color' => ReportStyle::BLUE, 'values' => $values],
                    ['name' => 'Meta arquivada', 'color' => ReportStyle::NAVY, 'values' => $targets]],
                'axis_category_title' => 'Competência', 'axis_value_title' => 'Percentual (%)',
                'note' => 'Valores de cada revisão mensal. Ausência não representa zero; situação e comparabilidade constam da tabela.'];
            $body .= str_replace('<w:keepNext/>', '', $this->charts->paragraph($definition, count($months) > 6 ? 6000 : 3400));
        } else $body .= $this->p('Nenhum valor percentual arquivado disponível para o gráfico.', '', false, 18);
        foreach ($notes as $text => $noteMonths) {
            $this->metricNotes[$text][$id] = array_merge($this->metricNotes[$text][$id] ?? [], $noteMonths);
        }
        return $body;
    }

    private function monthlyNotes(array $row): string
    {
        $body = $this->heading((string)$row['month'], 2);
        if (($row['status'] ?? '') !== 'available' || !is_array($row['summary'] ?? null)) return $body . $this->p('Competência sem revisão selecionada. Não foi substituída por zero nem interpolada.');
        $s = $row['summary'];
        $body .= $this->keep($this->p('Revisão: ' . (string)($row['record_id'] ?? '') . ' · Arquivamento: ' . OfficePackage::date($row['archived_at'] ?? '') . ' · Extração: ' . OfficePackage::date($s['generated_at'] ?? ''), '', false, 18));
        $body .= $this->keep($this->p('Escopo: ' . (string)($s['scope_label'] ?? 'Não registrado') . ' · Regras: ' . (string)($s['rules_version'] ?? 'Não registradas'), '', false, 18));
        $body .= $this->keep($this->p('Período: ' . (string)($s['period']['start'] ?? '') . ' até ' . (string)($s['period']['end_exclusive'] ?? '') . ' (limite final exclusivo).', '', false, 18));
        $body .= $this->p('Encerramento mensal: ' . $this->periodStatus($s['period']['completeness'] ?? 'unknown') . '. ' . (string)($s['period']['note'] ?? ''), '', false, 18);
        if (($s['source_identity']['status'] ?? 'unknown') !== 'known') $body .= $this->p('Identificação das fontes incompleta: a comparabilidade é avaliada individualmente por indicador.', '', false, 18);
        $body .= $this->operationalTotals($s['totals'] ?? []);
        foreach (['executive_summary' => 'Análise executiva', 'actions' => 'Ações e propostas de melhoria', 'notes' => 'Observações', 'phone_survey_actions' => 'Providências da pesquisa telefônica'] as $key => $label) {
            $value = trim((string)($s['manual'][$key] ?? ''));
            if ($value !== '') { $body .= $this->keep($this->p($label, '', true, 20)); $body .= $this->text($value); }
        }
        if (trim((string)($s['staffing']['note'] ?? '')) !== '') $body .= $this->p('Equipe: ' . $s['staffing']['note'], '', false, 18);
        foreach ($s['warnings'] ?? [] as $warning) $body .= $this->p('Observação da extração: ' . $warning, '', false, 18);
        return $body;
    }

    /** Display already-archived monthly counts and durations; never average or recalculate them. */
    private function operationalTotals(array $totals): string
    {
        $groups = [
            'Chamados' => ['tickets' => 'solucionados', 'requests' => 'requisições', 'incidents' => 'incidentes', 'tickets_assigned_n3' => 'atribuídos ao N3'],
            'Telefonia' => ['calls_received' => 'recebidas consideradas', 'calls_answered' => 'atendidas', 'calls_abandoned' => 'abandonadas',
                'calls_abandoned_over_30' => 'abandono após 30 s', 'calls_abandoned_up_to_30' => 'abandono até 30 s',
                'calls_abandoned_unknown_wait' => 'abandono sem espera conhecida', 'calls_excluded' => 'excluídas', 'calls_unknown' => 'situação desconhecida'],
            'SLA' => ['missing_deadline' => 'sem prazo', 'sla_evaluated' => 'avaliados', 'sla_unresolved' => 'não resolvidos na avaliação',
                'sla_scope_count' => 'população selecionada', 'sla_scope_evaluated' => 'avaliados na população', 'sla_scope_unresolved' => 'não resolvidos na população',
                'sla_recovered' => 'recuperados', 'sla_differences' => 'divergências', 'sla_provisional' => 'provisórios'],
        ];
        $body = '';
        foreach ($groups as $name => $fields) {
            $values = [];
            foreach ($fields as $key => $label) if (array_key_exists($key, $totals)) $values[] = $label . ': ' . $this->number($totals[$key]);
            if ($values) $body .= $this->p($name . ' (quantidades) · ' . implode('; ', $values) . '.', '', false, 18, 'left');
        }
        $times = [];
        foreach (['mean_talk_seconds' => 'TMA', 'mean_wait_seconds' => 'TME'] as $key => $label) if (array_key_exists($key, $totals)) {
            $times[] = $label . ': ' . OfficePackage::duration($totals[$key]) . ($totals[$key] === null ? '' : ' (' . $this->number($totals[$key]) . ' s)');
        }
        foreach (['mean_talk_count' => 'conversas com duração válida', 'mean_wait_count' => 'esperas com duração válida'] as $key => $label) if (array_key_exists($key, $totals)) $times[] = $label . ': ' . $this->number($totals[$key]);
        if ($times) $body .= $this->p('Tempos médios mensais arquivados (h:mm:ss; segundos entre parênteses) · ' . implode('; ', $times) . '.', '', false, 18, 'left');
        return $body === '' ? '' : $this->keep($this->p('Totais operacionais arquivados', '', true, 20)) . $body;
    }

    private function status(string $status): string
    {
        return ['met' => 'Atingida', 'unmet' => 'Não atingida', 'pending' => 'Pendente', 'not_applicable' => 'Não aplicável', 'provisional' => 'Provisório', 'missing' => 'Ausente'][$status] ?? 'Indisponível';
    }
    private function periodStatus(string $status): string { return ['complete' => 'encerrado', 'provisional' => 'provisório', 'unknown' => 'encerramento não confirmado'][$status] ?? 'encerramento não confirmado'; }
    private function percent($value): string { return $value === null ? '—' : number_format((float)$value, 2, ',', '.') . '%'; }
    private function number($value): string { return $value === null ? '—' : number_format((float)$value, floor((float)$value) == $value ? 0 : 2, ',', '.'); }
    private function money($cents): string
    {
        if ($cents === null) return '—';
        // Keep frozen cent integers exact, including values beyond floating-point precision.
        $digits = str_pad(ltrim((string)$cents, '-'), 3, '0', STR_PAD_LEFT);
        $whole = preg_replace('/\B(?=(\d{3})+(?!\d))/', '.', substr($digits, 0, -2));
        return 'R$ ' . ($cents < 0 ? '-' : '') . $whole . ',' . substr($digits, -2);
    }
    private function page(): string { return '<w:p><w:pPr><w:pageBreakBefore/><w:spacing w:after="0" w:before="0"/></w:pPr></w:p>'; }
    private function keep(string $paragraph): string { return str_replace('<w:pPr>', '<w:pPr><w:keepNext/>', $paragraph); }
    private function heading(string $text, int $level = 1): string { return $this->p($text, 'Heading' . $level, true, $level === 1 ? 28 : 23, 'left'); }
    private function text(string $text): string
    {
        $xml = '';
        foreach (preg_split('/\R/', $text) as $line) if (trim($line) !== '') $xml .= $this->p($line);
        return $xml;
    }
    private function p(string $text, string $style = '', bool $bold = false, int $size = 21, string $align = 'both', string $color = ReportStyle::NAVY): string
    {
        return '<w:p><w:pPr>' . ($style !== '' ? '<w:pStyle w:val="' . $style . '"/>' : '') . '<w:jc w:val="' . $align . '"/><w:widowControl/><w:spacing w:after="140" w:line="270" w:lineRule="auto"/>' . (str_starts_with($style, 'Heading') ? '<w:keepNext/>' : '') . '</w:pPr><w:r><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/>' . ($bold ? '<w:b/>' : '') . '<w:color w:val="' . $color . '"/><w:sz w:val="' . $size . '"/></w:rPr><w:t xml:space="preserve">' . OfficePackage::xml($text) . '</w:t></w:r></w:p>';
    }
    private function table(array $headers, array $rows, array $widths, array $violations = []): string
    {
        $xml = '<w:tbl><w:tblPr><w:tblW w:w="9500" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders>';
        foreach (['top', 'left', 'bottom', 'right', 'insideH', 'insideV'] as $edge) $xml .= '<w:' . $edge . ' w:val="single" w:sz="4" w:color="' . ReportStyle::BORDER . '"/>';
        $xml .= '</w:tblBorders><w:tblCellMar><w:top w:w="65" w:type="dxa"/><w:left w:w="95" w:type="dxa"/><w:bottom w:w="65" w:type="dxa"/><w:right w:w="95" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>';
        foreach ($widths as $width) $xml .= '<w:gridCol w:w="' . $width . '"/>';
        $xml .= '</w:tblGrid>';
        foreach (array_merge([$headers], $rows) as $i => $row) {
            $xml .= '<w:tr><w:trPr><w:cantSplit/>' . ($i === 0 ? '<w:tblHeader/>' : '') . '</w:trPr>';
            foreach ($row as $j => $cell) {
                $color = $i === 0 ? ReportStyle::WHITE : (!empty($violations[$i - 1]) ? '9C1C1C' : ReportStyle::NAVY);
                $paragraph = str_replace('w:after="140" w:line="270"', 'w:after="20" w:line="220"', $this->p((string)$cell, '', $i === 0, 18, 'left', $color));
                $xml .= '<w:tc><w:tcPr><w:tcW w:w="' . $widths[$j] . '" w:type="dxa"/><w:shd w:val="clear" w:fill="' . ($i === 0 ? ReportStyle::NAVY : ($i % 2 === 0 ? ReportStyle::POSITIVE_FILL : ReportStyle::WHITE)) . '"/><w:vAlign w:val="center"/></w:tcPr>' . $paragraph . '</w:tc>';
            }
            $xml .= '</w:tr>';
        }
        return $xml . '</w:tbl><w:p><w:pPr><w:spacing w:after="80"/></w:pPr></w:p>';
    }
    private function styles(): string
    {
        return '<?xml version="1.0" encoding="UTF-8"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:sz w:val="21"/><w:lang w:val="pt-BR"/></w:rPr></w:rPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style><w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:rPr><w:b/><w:color w:val="' . ReportStyle::NAVY . '"/><w:sz w:val="40"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:before="240" w:after="180"/><w:outlineLvl w:val="0"/></w:pPr><w:rPr><w:b/><w:color w:val="' . ReportStyle::NAVY . '"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:before="200" w:after="140"/><w:outlineLvl w:val="1"/></w:pPr><w:rPr><w:b/><w:color w:val="' . ReportStyle::NAVY . '"/></w:rPr></w:style></w:styles>';
    }
}
