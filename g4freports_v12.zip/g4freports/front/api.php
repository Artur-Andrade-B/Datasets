<?php
// Unified API endpoint. Accepts GET with ?action=...&payload={json} by default
// and also supports JSON/form POST. It follows the GLPIBot-style pattern:
// short-lived server-side API calls, no browser-side token exposure, and no
// /ajax dependency.

require_once dirname(__DIR__) . '/inc/bootstrap.php';

use GlpiPlugin\G4freports\Config;
use GlpiPlugin\G4freports\Security;
use GlpiPlugin\G4freports\Api\GlpiApiClient;
use GlpiPlugin\G4freports\Api\SearchOptionResolver;
use GlpiPlugin\G4freports\Builder\ReportDraftBuilder;

@ini_set('display_errors', '0');
@set_time_limit(45);

$cfg = Config::merged();
if (!Security::canUse($cfg) && !Security::canConfigure()) {
    g4fr_json_response(403, ['ok' => false, 'error' => 'Acesso negado']);
}

$action = trim((string)($_GET['action'] ?? $_POST['action'] ?? ''));
$input = g4fr_parse_request_payload();
if ($action === '') {
    $action = trim((string)($input['action'] ?? ''));
}
if ($action === '') {
    g4fr_json_response(400, ['ok' => false, 'error' => 'action_nao_informada']);
}

function g4fr_api_profile_from_input(array $input, array $cfg): ?array {
    if (isset($input['adhoc_profile']) && is_array($input['adhoc_profile']) && \GlpiPlugin\G4freports\Security::canConfigure()) {
        return \GlpiPlugin\G4freports\Config::normalizeProfile($input['adhoc_profile'], '__adhoc__');
    }
    $profileId = trim((string)($input['profile_id'] ?? '__default__'));
    return \GlpiPlugin\G4freports\Config::getAllowedProfileForCurrentUser($profileId, $cfg);
}

function g4fr_row_value(array $row, int $field): string {
    if ($field > 0 && isset($row[(string)$field])) {
        return is_scalar($row[(string)$field]) ? (string)$row[(string)$field] : json_encode($row[(string)$field], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
    if ($field > 0 && isset($row[$field])) {
        return is_scalar($row[$field]) ? (string)$row[$field] : json_encode($row[$field], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
    return '';
}

function g4fr_row_id(array $row, int $field = 2): int {
    foreach ([$field, 2, 'id'] as $key) {
        if (is_int($key) && isset($row[(string)$key]) && is_numeric($row[(string)$key])) return (int)$row[(string)$key];
        if (isset($row[$key]) && is_numeric($row[$key])) return (int)$row[$key];
    }
    return 0;
}

function g4fr_add_group_result(array &$groups, int $id, string $name, array $raw = []): void {
    if ($id <= 0) return;
    $name = trim($name) ?: ('Grupo #' . $id);
    foreach ($groups as $g) {
        if ((int)($g['id'] ?? 0) === $id) return;
    }
    $groups[] = ['id' => $id, 'name' => $name, 'raw' => $raw];
}


function g4fr_export_tmp_dir(): string {
    $base = null;
    if (defined('GLPI_TMP_DIR') && is_dir((string)GLPI_TMP_DIR)) {
        $base = rtrim((string)GLPI_TMP_DIR, '/\\');
    } elseif (defined('GLPI_ROOT') && is_dir((string)GLPI_ROOT . '/files/_tmp')) {
        $base = rtrim((string)GLPI_ROOT, '/\\') . '/files/_tmp';
    } else {
        $base = rtrim(sys_get_temp_dir(), '/\\');
    }
    $dir = $base . '/g4freports_exports';
    if (!is_dir($dir)) {
        @mkdir($dir, 0770, true);
    }
    return $dir;
}

function g4fr_export_cleanup(): void {
    $dir = g4fr_export_tmp_dir();
    $ttl = 1800;
    foreach (glob($dir . '/export_*') ?: [] as $file) {
        if (is_file($file) && (time() - (int)@filemtime($file)) > $ttl) {
            @unlink($file);
        }
    }
}

function g4fr_export_token_path(string $token, string $suffix = '.json'): string {
    if (!preg_match('/^[a-f0-9]{32}$/', $token)) {
        g4fr_json_response(400, ['ok' => false, 'error' => 'Token de exportação inválido.']);
    }
    return g4fr_export_tmp_dir() . '/export_' . $token . $suffix;
}

function g4fr_export_meta(string $token): array {
    $metaPath = g4fr_export_token_path($token, '.meta.json');
    $meta = is_file($metaPath) ? json_decode((string)@file_get_contents($metaPath), true) : null;
    if (!is_array($meta)) {
        g4fr_json_response(404, ['ok' => false, 'error' => 'Rascunho temporário de exportação não encontrado ou expirado.']);
    }
    $uid = g4fr_get_current_uid_glpi();
    if ((int)($meta['uid'] ?? 0) !== $uid) {
        g4fr_json_response(403, ['ok' => false, 'error' => 'Token de exportação pertence a outro usuário/sessão.']);
    }
    return $meta;
}

try {
    switch ($action) {
        case 'test_connection': {
            $profile = g4fr_api_profile_from_input($input, $cfg);
            if (!$profile) {
                g4fr_json_response(400, ['ok' => false, 'error' => 'Perfil de API não encontrado.']);
            }
            $client = new GlpiApiClient($profile);
            try {
                $client->initSession();
                try {
                    $session = $client->request('GET', '/getFullSession');
                } catch (Throwable $e) {
                    $session = ['warning' => $e->getMessage()];
                }
                g4fr_json_response(200, ['ok' => true, 'base_url' => $client->getBaseUrl(), 'session' => $session]);
            } finally {
                $client->killSession();
            }
        }

        case 'test_profiles': {
            if (!Security::canConfigure()) {
                g4fr_json_response(403, ['ok' => false, 'error' => 'Acesso negado']);
            }
            $profiles = Config::profiles($cfg);
            $out = [];
            foreach ($profiles as $id => $profile) {
                $client = null;
                try {
                    $client = new GlpiApiClient($profile);
                    $client->initSession();
                    $out[] = ['id' => $id, 'name' => $profile['name'] ?? $id, 'ok' => true, 'base_url' => $client->getBaseUrl()];
                } catch (Throwable $e) {
                    $out[] = ['id' => $id, 'name' => $profile['name'] ?? $id, 'ok' => false, 'error' => $e->getMessage()];
                } finally {
                    if ($client instanceof GlpiApiClient) {
                        $client->killSession();
                    }
                }
            }
            g4fr_json_response(200, ['ok' => true, 'results' => $out]);
        }

        case 'search_users': {
            if (!Security::canUse($cfg)) {
                g4fr_json_response(403, ['ok' => false, 'error' => 'Acesso negado']);
            }
            $q = trim((string)($input['q'] ?? ''));
            if ($q === '') {
                g4fr_json_response(200, ['ok' => true, 'users' => []]);
            }
            $profile = g4fr_api_profile_from_input($input, $cfg);
            if (!$profile) {
                g4fr_json_response(400, ['ok' => false, 'error' => 'Perfil de API não encontrado.']);
            }
            $client = new GlpiApiClient($profile);
            try {
                $resolver = new SearchOptionResolver($client, json_decode((string)($cfg['field_overrides_json'] ?? '{}'), true) ?: []);
                $fields = $resolver->fields('User', ['id' => [2], 'name' => [1], 'realname' => [9], 'firstname' => [34], 'login' => [1]]);
                $nameField = $fields['name'] ?: 1;
                $display = array_values(array_filter(array_unique([$fields['id'] ?: 2, $fields['name'] ?: 1, $fields['realname'], $fields['firstname']])));
                $res = $client->search('User', [['field' => $nameField, 'searchtype' => 'contains', 'value' => $q]], $display, '0-20');
                $users = [];
                foreach (($res['data'] ?? []) as $row) {
                    if (!is_array($row)) continue;
                    $id = g4fr_row_id($row, $fields['id'] ?: 2);
                    $name = g4fr_row_value($row, $fields['name'] ?: 1);
                    $real = g4fr_row_value($row, (int)$fields['realname']);
                    $first = g4fr_row_value($row, (int)$fields['firstname']);
                    $full = trim($first . ' ' . $real);
                    if ($id > 0) {
                        $users[] = ['id' => $id, 'name' => $full !== '' ? $full : $name, 'login' => $name, 'raw' => $row];
                    }
                }
                g4fr_json_response(200, ['ok' => true, 'users' => $users]);
            } finally {
                $client->killSession();
            }
        }

        case 'search_groups': {
            if (!Security::canUse($cfg)) {
                g4fr_json_response(403, ['ok' => false, 'error' => 'Acesso negado']);
            }
            $q = trim((string)($input['q'] ?? ''));
            if ($q === '') {
                g4fr_json_response(200, ['ok' => true, 'groups' => []]);
            }
            $profile = g4fr_api_profile_from_input($input, $cfg);
            if (!$profile) {
                g4fr_json_response(400, ['ok' => false, 'error' => 'Perfil de API não encontrado.']);
            }
            $client = new GlpiApiClient($profile);
            try {
                $groups = [];
                if (preg_match('/^\d+$/', $q)) {
                    try {
                        $item = $client->getItem('Group', (int)$q, ['expand_dropdowns' => true, 'get_hateoas' => false]);
                        if (is_array($item) && (int)($item['id'] ?? 0) > 0) {
                            g4fr_add_group_result($groups, (int)$item['id'], (string)(($item['completename'] ?? '') ?: ($item['name'] ?? '')), $item);
                        }
                    } catch (Throwable $e) {
                        // Continue with searchable fields.
                    }
                }

                $resolver = new SearchOptionResolver($client, json_decode((string)($cfg['field_overrides_json'] ?? '{}'), true) ?: []);
                $idField = $resolver->fieldStrict('Group', 'id') ?: 2;
                $nameFields = $resolver->fieldsMatching('Group', [
                    '/\b(completename|complete name|nome completo|full name)\b/',
                    '/\b(group name|nome|name)\b/',
                    '/\bglpi_groups\s+(name|completename)\b/',
                    '/\b(group\.name|group\.completename)\b/'
                ], 8);
                foreach ([1, 80] as $fallback) {
                    if (!in_array($fallback, $nameFields, true)) {
                        $nameFields[] = $fallback;
                    }
                }
                $nameFields = array_values(array_unique(array_filter(array_map('intval', $nameFields))));
                $display = array_values(array_unique(array_filter(array_merge([$idField], $nameFields))));
                $searchErrors = [];
                foreach ($nameFields as $field) {
                    try {
                        $res = $client->search('Group', [['field' => $field, 'searchtype' => 'contains', 'value' => $q]], $display, '0-30');
                        foreach (($res['data'] ?? []) as $row) {
                            if (!is_array($row)) continue;
                            $id = g4fr_row_id($row, $idField);
                            if ($id <= 0) continue;
                            $label = '';
                            foreach ($nameFields as $nf) {
                                $candidate = g4fr_row_value($row, $nf);
                                if (trim($candidate) !== '') {
                                    $label = $candidate;
                                    break;
                                }
                            }
                            g4fr_add_group_result($groups, $id, $label, $row);
                        }
                    } catch (Throwable $e) {
                        $searchErrors[] = 'campo ' . $field . ': ' . $e->getMessage();
                    }
                    if (count($groups) >= 30) {
                        break;
                    }
                }

                if (empty($groups) && !empty($searchErrors)) {
                    g4fr_json_response(200, [
                        'ok' => true,
                        'groups' => [],
                        'warning' => 'Nenhum grupo encontrado por nome. A API não aceitou os campos pesquisáveis testados; use Diagnóstico > Group para mapear o campo correto.'
                    ]);
                }
                g4fr_json_response(200, ['ok' => true, 'groups' => array_values($groups)]);
            } finally {
                $client->killSession();
            }
        }


        case 'search_ticket': {
            if (!Security::canUse($cfg)) {
                g4fr_json_response(403, ['ok' => false, 'error' => 'Acesso negado']);
            }
            $ticketId = (int)($input['ticket_id'] ?? $input['id'] ?? 0);
            if ($ticketId <= 0) {
                g4fr_json_response(400, ['ok' => false, 'error' => 'Informe um número de chamado válido.']);
            }
            $profile = g4fr_api_profile_from_input($input, $cfg);
            if (!$profile) {
                g4fr_json_response(400, ['ok' => false, 'error' => 'Perfil de API não encontrado.']);
            }
            $client = new GlpiApiClient($profile);
            try {
                $item = $client->getItem('Ticket', $ticketId, ['expand_dropdowns' => true, 'get_hateoas' => false]);
                if (!is_array($item) || (int)($item['id'] ?? $ticketId) <= 0) {
                    g4fr_json_response(404, ['ok' => false, 'error' => 'Chamado não encontrado.']);
                }
                $status = (string)($item['status'] ?? '');
                $statusMap = [1 => 'Novo', 2 => 'Em atendimento (atribuído)', 3 => 'Em atendimento (planejado)', 4 => 'Pendente', 5 => 'Solucionado', 6 => 'Fechado'];
                if (is_numeric($status) && isset($statusMap[(int)$status])) {
                    $status = $statusMap[(int)$status];
                }
                $category = '';
                if (isset($item['itilcategories_id'])) {
                    if (is_array($item['itilcategories_id'])) {
                        $category = (string)(($item['itilcategories_id']['completename'] ?? '') ?: ($item['itilcategories_id']['name'] ?? ''));
                    } elseif (!is_numeric((string)$item['itilcategories_id'])) {
                        $category = (string)$item['itilcategories_id'];
                    }
                }
                g4fr_json_response(200, ['ok' => true, 'ticket' => [
                    'id' => (int)($item['id'] ?? $ticketId),
                    'title' => (string)($item['name'] ?? ('Chamado ' . $ticketId)),
                    'status' => $status,
                    'category' => $category,
                    'date' => (string)($item['date'] ?? ''),
                    'raw' => $item,
                ]]);
            } finally {
                $client->killSession();
            }
        }

        case 'search_options': {
            if (!Security::canUse($cfg)) {
                g4fr_json_response(403, ['ok' => false, 'error' => 'Acesso negado']);
            }
            $itemtype = trim((string)($input['itemtype'] ?? 'Ticket'));
            $profile = g4fr_api_profile_from_input($input, $cfg);
            if (!$profile) {
                g4fr_json_response(400, ['ok' => false, 'error' => 'Perfil de API não encontrado.']);
            }
            $client = new GlpiApiClient($profile);
            try {
                $options = $client->listSearchOptions($itemtype);
                g4fr_json_response(200, ['ok' => true, 'itemtype' => $itemtype, 'options' => $options]);
            } finally {
                $client->killSession();
            }
        }

        case 'prepare_export': {
            if (!Security::canUse($cfg)) {
                g4fr_json_response(403, ['ok' => false, 'error' => 'Acesso negado']);
            }
            g4fr_export_cleanup();
            $op = trim((string)($input['op'] ?? ''));
            $uid = g4fr_get_current_uid_glpi();
            if ($uid <= 0) {
                g4fr_json_response(403, ['ok' => false, 'error' => 'Sessão GLPI inválida para preparar exportação.']);
            }
            if ($op === 'start') {
                $token = bin2hex(random_bytes(16));
                $meta = [
                    'uid' => $uid,
                    'created_at' => time(),
                    'total_chunks' => max(1, (int)($input['total_chunks'] ?? 1)),
                    'received_chunks' => 0,
                    'bytes' => 0,
                ];
                @file_put_contents(g4fr_export_token_path($token, '.meta.json'), json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                @file_put_contents(g4fr_export_token_path($token, '.part'), '');
                g4fr_json_response(200, ['ok' => true, 'token' => $token]);
            }
            $token = trim((string)($input['token'] ?? ''));
            $meta = g4fr_export_meta($token);
            if ($op === 'chunk') {
                $chunk = (string)($input['chunk'] ?? '');
                if ($chunk === '' && (int)($input['total_chunks'] ?? 1) > 1) {
                    g4fr_json_response(400, ['ok' => false, 'error' => 'Lote de exportação vazio.']);
                }
                $partPath = g4fr_export_token_path($token, '.part');
                @file_put_contents($partPath, $chunk, FILE_APPEND | LOCK_EX);
                $meta['received_chunks'] = (int)($meta['received_chunks'] ?? 0) + 1;
                $meta['bytes'] = (int)($meta['bytes'] ?? 0) + strlen($chunk);
                @file_put_contents(g4fr_export_token_path($token, '.meta.json'), json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
                g4fr_json_response(200, ['ok' => true, 'received_chunks' => $meta['received_chunks'], 'bytes' => $meta['bytes']]);
            }
            if ($op === 'finish') {
                $partPath = g4fr_export_token_path($token, '.part');
                if (!is_file($partPath)) {
                    g4fr_json_response(404, ['ok' => false, 'error' => 'Arquivo temporário de exportação não encontrado.']);
                }
                $jsonPath = g4fr_export_token_path($token, '.json');
                @rename($partPath, $jsonPath);
                if (!is_file($jsonPath)) {
                    g4fr_json_response(500, ['ok' => false, 'error' => 'Falha ao finalizar rascunho temporário de exportação.']);
                }
                $meta['finished_at'] = time();
                @file_put_contents(g4fr_export_token_path($token, '.meta.json'), json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
                g4fr_json_response(200, ['ok' => true, 'token' => $token, 'bytes' => filesize($jsonPath)]);
            }
            g4fr_json_response(400, ['ok' => false, 'error' => 'Operação de exportação inválida.']);
        }

        case 'build_draft': {
            if (!Security::canUse($cfg)) {
                g4fr_json_response(403, ['ok' => false, 'error' => 'Acesso negado']);
            }
            $profile = g4fr_api_profile_from_input($input, $cfg);
            if (!$profile) {
                g4fr_json_response(400, ['ok' => false, 'error' => 'Perfil de API não encontrado.']);
            }
            $builder = new ReportDraftBuilder($cfg, $profile);
            try {
                $draft = $builder->build($input);
                g4fr_json_response(200, ['ok' => true, 'draft' => $draft]);
            } finally {
                if (method_exists($builder, 'close')) {
                    $builder->close();
                }
            }
        }

        default:
            g4fr_json_response(404, ['ok' => false, 'error' => 'acao_desconhecida: ' . $action]);
    }
} catch (Throwable $e) {
    $trace = g4fr_str_limit($e->getTraceAsString(), 3000);
    g4fr_json_response(500, ['ok' => false, 'error' => $e->getMessage(), 'trace' => $trace]);
}
