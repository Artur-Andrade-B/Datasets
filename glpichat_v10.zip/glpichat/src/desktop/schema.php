<?php

declare(strict_types=1);

/** Desktop pilot schema. Included only by the desktop/admin/install paths. */
function glpichat_desktop_schema_definitions(): array
{
    $column = static fn (string $type, bool $nullable = false, string $extra = ''): array => [
        'type' => $type, 'nullable' => $nullable, 'extra' => $extra,
    ];
    $index = static fn (array $columns, bool $unique = false): array => [
        'columns' => $columns, 'unique' => $unique,
    ];
    return [
        'glpi_plugin_glpichat_desktopdevices' => [
            'columns' => [
                'id' => $column('int unsigned', false, 'AUTO_INCREMENT'),
                'pairing_id' => $column('char(32) ascii_bin'),
                'poll_secret_hash' => $column('char(64) ascii_bin'),
                'token_hash' => $column('char(64) ascii_bin', true),
                'device_id' => $column('char(36) ascii_bin'),
                'device_name' => $column('varchar(100)'),
                'windows_login' => $column('varchar(200)'),
                'request_ip_hash' => $column('char(64) ascii_bin'),
                'user_code' => $column('char(9) ascii_bin'),
                'status' => $column('varchar(16)', false, "DEFAULT 'pending'"),
                'users_id' => $column('int unsigned', false, 'DEFAULT 0'),
                'profiles_id' => $column('int unsigned', false, 'DEFAULT 0'),
                'entities_id' => $column('int unsigned', false, 'DEFAULT 0'),
                'auths_id' => $column('int unsigned', false, 'DEFAULT 0'),
                'sync_anchor' => $column('char(64) ascii_bin', false, "DEFAULT ''"),
                'user_incarnation' => $column('char(64) ascii_bin', false, "DEFAULT ''"),
                'auth_source_fingerprint' => $column('char(64) ascii_bin', false, "DEFAULT ''"),
                'created_at' => $column('datetime'),
                'pairing_expires_at' => $column('datetime'),
                'approved_at' => $column('datetime', true),
                'token_expires_at' => $column('datetime', true),
                'revoked_at' => $column('datetime', true),
            ],
            'indexes' => [
                'PRIMARY' => $index(['id'], true),
                'desktop_pairing' => $index(['pairing_id'], true),
                'desktop_token' => $index(['token_hash'], true),
                'desktop_request_ip' => $index(['request_ip_hash', 'created_at']),
                'desktop_expiry' => $index(['status', 'pairing_expires_at']),
                'desktop_user_status' => $index(['users_id', 'status']),
            ],
        ],
        'glpi_plugin_glpichat_desktopsends' => [
            'columns' => [
                'id' => $column('bigint unsigned', false, 'AUTO_INCREMENT'),
                'users_id' => $column('int unsigned'),
                'client_message_id' => $column('char(36) ascii_bin'),
                'tickets_id' => $column('int unsigned'),
                'payload_hash' => $column('char(64) ascii_bin'),
                'itilfollowups_id' => $column('int unsigned', true),
                'created_at' => $column('datetime'),
            ],
            'indexes' => [
                'PRIMARY' => $index(['id'], true),
                'desktop_send_uuid' => $index(['users_id', 'client_message_id'], true),
                'desktop_send_followup' => $index(['tickets_id', 'itilfollowups_id']),
                'desktop_send_rate' => $index(['users_id', 'created_at']),
            ],
        ],
        'glpi_plugin_glpichat_desktopreads' => [
            'columns' => [
                'id' => $column('bigint unsigned', false, 'AUTO_INCREMENT'),
                'users_id' => $column('int unsigned'),
                'itilfollowups_id' => $column('int unsigned'),
                'created_at' => $column('datetime'),
            ],
            'indexes' => [
                'PRIMARY' => $index(['id'], true),
                'desktop_read_followup' => $index(['users_id', 'itilfollowups_id'], true),
            ],
        ],
    ];
}

function glpichat_desktop_schema_tables(): array
{
    return array_keys(glpichat_desktop_schema_definitions());
}

/** Metadata only: no CREATE/ALTER and no installation calls on runtime paths. */
function glpichat_desktop_schema_metadata(): array
{
    global $DB;
    $tables = array_merge(glpichat_desktop_schema_tables(), ['glpi_plugin_glpichat_messages']);
    // All identifiers are fixed in this source file, never request input.
    $in = "'" . implode("','", $tables) . "'";
    $where = "TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ($in)";
    $queries = [
        'tables' => "SELECT TABLE_NAME, ENGINE FROM information_schema.TABLES WHERE $where",
        'columns' => "SELECT TABLE_NAME, COLUMN_NAME, COLUMN_TYPE, COLUMN_DEFAULT, IS_NULLABLE, COLLATION_NAME, EXTRA FROM information_schema.COLUMNS WHERE $where",
        'indexes' => "SELECT TABLE_NAME, INDEX_NAME, NON_UNIQUE, SEQ_IN_INDEX, COLUMN_NAME, SUB_PART FROM information_schema.STATISTICS WHERE $where ORDER BY TABLE_NAME, INDEX_NAME, SEQ_IN_INDEX",
    ];
    $metadata = [];
    foreach ($queries as $kind => $sql) {
        $result = $DB->doQuery($sql);
        if ($result === false) {
            throw new RuntimeException('Desktop schema metadata unavailable.');
        }
        $metadata[$kind] = [];
        while ($row = $DB->fetchAssoc($result)) {
            $metadata[$kind][] = $row;
        }
    }
    return $metadata;
}

/** Full readback for install/admin qualification; deliberately not called on each poll. */
function glpichat_desktop_schema_health(
    bool $check_marker = true,
    ?callable $metadata_reader = null,
    ?callable $config_value = null
): array {
    $metadata_reader ??= 'glpichat_desktop_schema_metadata';
    $config_value ??= static fn (string $key): mixed => Config::getConfigurationValue('plugin:glpichat', $key);
    $issues = [];
    try {
        $metadata = $metadata_reader();
        $tables = [];
        foreach ($metadata['tables'] as $row) {
            $tables[$row['TABLE_NAME']] = strtolower((string) $row['ENGINE']);
        }
        $columns = [];
        foreach ($metadata['columns'] as $row) {
            $columns[$row['TABLE_NAME']][$row['COLUMN_NAME']] = $row;
        }
        $indexes = [];
        foreach ($metadata['indexes'] as $row) {
            $table = (string) $row['TABLE_NAME'];
            $index = (string) $row['INDEX_NAME'];
            $indexes[$table][$index]['unique'] = (int) $row['NON_UNIQUE'] === 0;
            $indexes[$table][$index]['columns'][(int) $row['SEQ_IN_INDEX']] = (string) $row['COLUMN_NAME'];
            if (($row['SUB_PART'] ?? null) !== null) {
                $indexes[$table][$index]['prefix'] = true;
            }
        }
        $definitions = glpichat_desktop_schema_definitions();
        $definitions['glpi_plugin_glpichat_messages'] = [
            'columns' => [],
            'indexes' => ['desktop_followup_id' => ['columns' => ['itilfollowups_id'], 'unique' => false]],
        ];
        foreach ($definitions as $table => $definition) {
            if (($tables[$table] ?? '') !== 'innodb') {
                $issues[] = $table . ':missing_or_nontransactional';
                continue;
            }
            foreach ($definition['columns'] as $name => $expected) {
                $actual = $columns[$table][$name] ?? null;
                if ($actual === null) {
                    $issues[] = $table . '.' . $name . ':missing';
                    continue;
                }
                // MariaDB reports integer display widths; MySQL 8 may omit them.
                $type = strtolower((string) $actual['COLUMN_TYPE']);
                $type = preg_replace('/\b(bigint|int)\([0-9]+\)/', '$1', $type);
                $expected_type = str_replace(' ascii_bin', '', $expected['type']);
                $binary_ascii = str_contains($expected['type'], ' ascii_bin');
                $default_matches = true;
                if (str_starts_with($expected['extra'], 'DEFAULT ')) {
                    // MariaDB quotes literal string defaults, MySQL may not.
                    $expected_default = trim(substr($expected['extra'], 8), "'");
                    $actual_default = $actual['COLUMN_DEFAULT'] ?? null;
                    if (is_string($actual_default) && str_starts_with($actual_default, "'") && str_ends_with($actual_default, "'")) {
                        $actual_default = substr($actual_default, 1, -1);
                    }
                    $default_matches = $actual_default !== null && (string) $actual_default === $expected_default;
                }
                if ($type !== $expected_type
                    || !$default_matches
                    || (($actual['IS_NULLABLE'] === 'YES') !== $expected['nullable'])
                    || ($binary_ascii && ($actual['COLLATION_NAME'] ?? '') !== 'ascii_bin')
                    || ($name === 'id' && !str_contains(strtolower((string) $actual['EXTRA']), 'auto_increment'))
                ) {
                    $issues[] = $table . '.' . $name . ':shape';
                }
            }
            foreach ($definition['indexes'] as $name => $expected) {
                $actual = $indexes[$table][$name] ?? null;
                if ($actual !== null) {
                    ksort($actual['columns']);
                    $actual['columns'] = array_values($actual['columns']);
                }
                if ($actual === null
                    || ($actual['prefix'] ?? false)
                    || $actual['unique'] !== $expected['unique']
                    || $actual['columns'] !== $expected['columns']
                ) {
                    $issues[] = $table . '.' . $name . ':missing_or_shape';
                }
            }
        }
        $key = $config_value('desktop_idempotency_key');
        if (!is_string($key) || preg_match('/\A[a-f0-9]{64}\z/', $key) !== 1) {
            $issues[] = 'desktop_idempotency_key:invalid';
        }
        if ($check_marker) {
            $marker = $config_value('desktop_schema_version');
            if ($marker !== '1' && $marker !== 1) {
                $issues[] = 'desktop_schema_version:unsupported';
            }
        }
    } catch (Throwable $e) {
        // Keep diagnostic location, but never log SQL, credentials or exception text.
        error_log('glpichat desktop schema: ' . get_class($e) . ' at ' . basename($e->getFile()) . ':' . $e->getLine());
        $issues[] = 'schema_metadata:unavailable';
    }
    return ['healthy' => $issues === [], 'issues' => array_values(array_unique($issues)), 'schema_version' => '1'];
}

/** Preserve a future marker when older code is accidentally installed. */
function glpichat_desktop_schema_version_to_store(mixed $raw): string
{
    if ((is_string($raw) || is_int($raw)) && preg_match('/\A[1-9][0-9]*\z/', (string) $raw) === 1) {
        return (string) $raw;
    }
    return '1';
}

/** Called solely by GLPI's explicit install/update hook. */
function glpichat_desktop_schema_install(
    ?callable $table_exists = null,
    ?callable $execute = null,
    ?callable $metadata_reader = null,
    ?callable $config_value = null,
    ?callable $config_write = null
): void {
    global $DB;
    $table_exists ??= static fn (string $table): bool => (bool) $DB->tableExists($table);
    $execute ??= static fn (string $sql): mixed => $DB->doQuery($sql);
    $metadata_reader ??= 'glpichat_desktop_schema_metadata';
    $config_value ??= static fn (string $key): mixed => Config::getConfigurationValue('plugin:glpichat', $key);
    $config_write ??= static fn (array $values): mixed => Config::setConfigurationValues('plugin:glpichat', $values);
    $previous_marker = $config_value('desktop_schema_version');
    foreach (glpichat_desktop_schema_definitions() as $table => $definition) {
        if ($table_exists($table)) {
            continue;
        }
        $parts = [];
        foreach ($definition['columns'] as $name => $column) {
            $type = str_replace(' ascii_bin', ' CHARACTER SET ascii COLLATE ascii_bin', $column['type']);
            $parts[] = '`' . $name . '` ' . $type . ($column['nullable'] ? ' NULL DEFAULT NULL' : ' NOT NULL') . ' ' . $column['extra'];
        }
        foreach ($definition['indexes'] as $name => $index) {
            $prefix = $name === 'PRIMARY' ? 'PRIMARY KEY' : ($index['unique'] ? 'UNIQUE KEY ' : 'KEY ') . '`' . $name . '`';
            $parts[] = $prefix . ' (`' . implode('`,`', $index['columns']) . '`)';
        }
        $execute('CREATE TABLE `' . $table . '` (' . implode(', ', $parts) . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC');
    }

    // Native public history excludes attachment mirrors by followup ID.
    // Add only the missing index; incompatible existing shapes fail readback.
    $metadata = $metadata_reader();
    $has_followup_index = false;
    foreach ($metadata['indexes'] as $row) {
        if ($row['TABLE_NAME'] === 'glpi_plugin_glpichat_messages' && $row['INDEX_NAME'] === 'desktop_followup_id') {
            $has_followup_index = true;
        }
    }
    if (!$has_followup_index) {
        $execute('ALTER TABLE `glpi_plugin_glpichat_messages` ADD KEY `desktop_followup_id` (`itilfollowups_id`)');
    }

    $key = $config_value('desktop_idempotency_key');
    if ($key === null || $key === false || $key === '') {
        $key = bin2hex(random_bytes(32));
    }
    if (!is_string($key) || preg_match('/\A[a-f0-9]{64}\z/', $key) !== 1) {
        throw new RuntimeException('Desktop idempotency key is invalid; existing key was not replaced.');
    }
    $config_write([
        'desktop_enabled' => (string) $config_value('desktop_enabled') === '1' ? '1' : '0',
        'desktop_idempotency_key' => $key,
    ]);
    $health = glpichat_desktop_schema_health(false, $metadata_reader, $config_value);
    if (!$health['healthy']) {
        throw new RuntimeException('GLPI Chat desktop schema: ' . implode(', ', $health['issues']));
    }
    // This marker is the last write and is never downgraded by an old package.
    $config_write(['desktop_schema_version' => glpichat_desktop_schema_version_to_store($previous_marker)]);
}
