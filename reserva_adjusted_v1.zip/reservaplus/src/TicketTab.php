<?php

declare(strict_types=1);

namespace GlpiPlugin\Reservaplus;

use CommonGLPI;

final class TicketTab extends CommonGLPI
{
    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0): string
    {
        if (!$item instanceof \Ticket || !Schema::ready() || !Access::right('read') || !$item->can((int) $item->getID(), READ)) {
            return '';
        }
        return __('Reserva Plus', 'reservaplus');
    }

    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0): bool
    {
        if (!$item instanceof \Ticket || !Schema::ready() || !Access::right('read') || !$item->can((int) $item->getID(), READ)) {
            return false;
        }
        self::show($item);
        return true;
    }

    private static function show(\Ticket $ticket): void
    {
        BookingView::css();
        echo '<div class="rp-workflow"><section class="rp-panel"><h2>' . BookingView::e(__('Reservas vinculadas a este chamado', 'reservaplus')) . '</h2>';
        try {
            $rows = BookingService::search(['tickets_id' => (int) $ticket->getID()], 26, 0);
            BookingView::renderList(array_slice($rows, 0, 25), [], true);
            if (count($rows) > 25) {
                BookingView::notice(__('Há mais reservas vinculadas. Consulte a lista de solicitações.', 'reservaplus'));
            }
            if ($rows === [] && Access::right('request') && $ticket->can((int) $ticket->getID(), UPDATE)) {
                echo '<p>' . BookingView::e(__('Complete os recursos e o período para organizar uma reserva usando este mesmo chamado.', 'reservaplus')) . '</p>';
                BookingView::link('booking.form.php', __('Organizar reserva', 'reservaplus'), ['tickets_id' => (int) $ticket->getID()], 'btn-primary');
            }
        } catch (\Throwable $error) {
            BookingView::notice(BookingView::publicError($error), true);
        }
        echo '</section></div>';
    }
}
