<?php
declare(strict_types=1);

namespace GlpiPlugin\Reservaplus;

final class TicketBridge
{
    public static function connect(array $booking, array $resources, int $existing = 0): int
    {
        global $DB;
        $ticket = new \Ticket();
        if ($existing > 0) {
            if (!$ticket->getFromDB($existing) || !$ticket->can($existing, UPDATE)
                || (int) $ticket->fields['entities_id'] !== (int) $booking['entities_id']
                || in_array((int) $ticket->fields['status'], [\CommonITILObject::SOLVED, \CommonITILObject::CLOSED], true)) {
                throw new \DomainException('Chamado indisponível para conversão em reserva.');
            }
            if (Store::find('bookings', ['tickets_id' => $existing], ['LIMIT' => 1])) {
                throw new \DomainException('Este chamado já possui uma solicitação de reserva.');
            }
            return $existing; // Preserve intentional assignment on ticket-origin intake.
        }
        $groups = array_values(array_unique(array_map(static fn($r) => (int) $r['groups_id_ticket'], $resources)));
        if (count($groups) !== 1 || $groups[0] < 1) {
            throw new \DomainException('Selecione recursos do mesmo grupo responsável; combinações entre equipes exigem solicitações separadas nesta versão.');
        }
        $group = new \Group();
        if (!$group->getFromDB($groups[0]) || empty($group->fields['is_assign'])
            || !\Session::haveAccessToEntity((int) $group->fields['entities_id'], (bool) ($group->fields['is_recursive'] ?? false))) {
            throw new \DomainException('O grupo responsável não está disponível para atribuição de chamados.');
        }
        $assignees = array_values(array_unique(array_map(static fn($r) => (int) ($r['default_assignee_users_id'] ?: $r['custodian_users_id']), $resources)));
        $assignee = count($assignees) === 1 ? $assignees[0] : 0;
        if ($assignee > 0) {
            $eligible = false;
            $user = new \User();
            if ($user->getFromDB($assignee) && !empty($user->fields['is_active']) && empty($user->fields['is_deleted'])) {
                foreach ($DB->request(['FROM' => 'glpi_profiles_users', 'WHERE' => ['users_id' => $assignee, 'entities_id' => (int) $booking['entities_id']]]) as $profileUser) {
                    foreach ($DB->request(['FROM' => 'glpi_profilerights', 'WHERE' => ['profiles_id' => (int) $profileUser['profiles_id'], 'name' => 'ticket']]) as $right) {
                        if (((int) $right['rights'] & \Ticket::OWN) !== 0) { $eligible = true; }
                    }
                }
            }
            if (!$eligible) { $assignee = 0; }
        }
        $input = [
            'name' => 'ReservaPlus #' . (int) $booking['id'],
            'content' => 'Solicitação de reserva #' . (int) $booking['id'] . '. Consulte a aba ReservaPlus para recursos, período, aprovações, termos e devolução.',
            'entities_id' => (int) $booking['entities_id'], 'type' => \Ticket::DEMAND_TYPE,
            '_users_id_requester' => (int) $booking['users_id_borrower'],
            '_groups_id_assign' => $groups[0], '_disablenotif' => true,
        ];
        if ($assignee > 0) { $input['_users_id_assign'] = $assignee; }
        if (!$ticket->can(-1, CREATE, $input)) { throw new \DomainException('Sem permissão nativa para abrir o chamado desta reserva.'); }
        $id = WorkflowHooks::native(static fn() => (int) $ticket->add($input));
        if ($id < 1 || !$ticket->getFromDB($id)) { throw new \DomainException('O GLPI não confirmou a criação do chamado.'); }
        if ((int) $ticket->fields['entities_id'] !== (int) $booking['entities_id']) {
            throw new \DomainException('Uma regra do GLPI alterou a entidade do chamado. Revise o roteamento.');
        }
        if (in_array((int) $ticket->fields['status'], [\CommonITILObject::SOLVED, \CommonITILObject::CLOSED], true)) {
            throw new \DomainException('Uma regra encerrou o chamado antes do fluxo de reserva. Revise o roteamento.');
        }
        $actualGroups = [];
        foreach ($DB->request(['FROM' => 'glpi_groups_tickets', 'WHERE' => ['tickets_id' => $id, 'type' => \CommonITILActor::ASSIGN]]) as $actor) {
            $actualGroups[] = (int) $actor['groups_id'];
        }
        if (!in_array($groups[0], $actualGroups, true)) {
            throw new \DomainException('Uma regra do GLPI alterou o grupo responsável. Revise o roteamento antes de reservar.');
        }
        // Native rules own the final assignment. Preserve and expose it; never reset in a sync loop.
        Store::event((int) $booking['id'], 'ticket_created', ['tickets_id' => $id, 'proposed_groups_id' => $groups[0], 'proposed_users_id' => $assignee, 'assigned_groups_ids' => $actualGroups]);
        return $id;
    }

    public static function requestApprovals(array $booking, array $lines, array $resources): void
    {
        foreach ($lines as $line) {
            $resource = $resources[(int) $line['resources_id']];
            $policy = Store::decode($resource['policy_json'] ?? null);
            if (empty($policy['approval_required'])) { continue; }
            $group = (int) ($resource['groups_id_approve'] ?? 0);
            if ($group < 1) { throw new \DomainException('Configure o grupo aprovador antes de publicar o recurso.'); }
            $id = WorkflowHooks::native(static function () use ($booking, $line, $group): int {
                $approval = new \TicketValidation();
                $id = (int) $approval->add([
                    'tickets_id' => (int) $booking['tickets_id'],
                    'itemtype_target' => \Group::class, 'items_id_target' => $group,
                    'comment_submission' => 'ReservaPlus #' . (int) $booking['id'] . ' / recurso #' . (int) $line['resources_id'] . '. Responda pela aba ReservaPlus.',
                    '_disablenotif' => true,
                ]);
                if ($id < 1) { throw new \DomainException('Não foi possível registrar a aprovação no GLPI.'); }
                return $id;
            });
            Store::insert('bookingapprovals', [
                'bookings_id' => (int) $booking['id'], 'lines_id' => (int) $line['id'],
                'ticketvalidations_id' => $id, 'target_itemtype' => \Group::class, 'target_id' => $group,
                'status' => 'pending', 'users_id_decider' => 0, 'date_mod' => Store::now(),
            ]);
        }
    }

    public static function decide(array $approval, bool $accepted, string $reason): void
    {
        $model = new \TicketValidation();
        $id = (int) $approval['ticketvalidations_id'];
        if (!$model->getFromDB($id) || !$model->canAnswer()) {
            throw new \DomainException('Sem permissão nativa para responder esta aprovação.');
        }
        WorkflowHooks::native(static function () use ($model, $id, $accepted, $reason): void {
            if (!$model->update(['id' => $id, 'status' => $accepted ? \CommonITILValidation::ACCEPTED : \CommonITILValidation::REFUSED,
                'comment_validation' => $reason, '_disablenotif' => true])) {
                throw new \DomainException('O GLPI recusou a decisão de aprovação.');
            }
            if (!$model->getFromDB($id) || (int) $model->fields['status'] !== ($accepted ? \CommonITILValidation::ACCEPTED : \CommonITILValidation::REFUSED)) {
                throw new \DomainException('A decisão nativa não corresponde à solicitação.');
            }
        });
        Store::update('bookingapprovals', (int) $approval['id'], [
            'status' => $accepted ? 'approved' : 'rejected', 'users_id_decider' => Access::userId(), 'date_mod' => Store::now(),
        ]);
    }

    public static function followup(array $booking, string $message, bool $private = false): void
    {
        WorkflowHooks::native(static function () use ($booking, $message, $private): void {
            $followup = new \ITILFollowup();
            if (!$followup->add(['itemtype' => \Ticket::class, 'items_id' => (int) $booking['tickets_id'],
                'content' => $message, 'is_private' => $private ? 1 : 0])) {
                throw new \DomainException('Não foi possível registrar o acompanhamento no chamado.');
            }
        });
    }

    public static function solve(array $booking): void
    {
        $ticket = new \Ticket();
        $id = (int) $booking['tickets_id'];
        if (!$ticket->getFromDB($id) || !$ticket->can($id, UPDATE)) {
            throw new \DomainException('Sem permissão para solucionar o chamado vinculado.');
        }
        WorkflowHooks::native(static function () use ($ticket, $id): void {
            if (!$ticket->update(['id' => $id, 'status' => \CommonITILObject::SOLVED, '_disablenotif' => true])) {
                throw new \DomainException('O GLPI recusou a solução do chamado; verifique sua matriz de estados e permissões.');
            }
            if (!$ticket->getFromDB($id) || !in_array((int) $ticket->fields['status'], [\CommonITILObject::SOLVED, \CommonITILObject::CLOSED], true)) {
                throw new \DomainException('O GLPI não aplicou a solução do chamado; revise regras e campos obrigatórios.');
            }
        });
    }

    public static function enqueue(int $bookingId, string $kind, array $payload, string $eventKey): void
    {
        Store::insert('bookingoutbox', [
            'bookings_id' => $bookingId, 'event_key' => hash('sha256', $eventKey), 'kind' => $kind,
            'payload_json' => Store::json($payload), 'status' => 'pending', 'attempts' => 0,
            'date_creation' => Store::now(), 'date_mod' => Store::now(),
        ]);
    }

    public static function deliverOutbox(int $bookingId = 0): int
    {
        $where = ['status' => 'pending'];
        if ($bookingId > 0) { Access::assertBooking(Store::row('bookings', $bookingId)); $where['bookings_id'] = $bookingId; }
        elseif (!\Session::isCron() && !Access::right('admin')) { throw new \DomainException('Fila restrita à ação automática ou administrador.'); }
        $done = 0;
        $touched = [];
        foreach (Store::find('bookingoutbox', $where, ['ORDER' => ['id ASC'], 'LIMIT' => 100]) as $candidate) {
            if (!empty($candidate['next_attempt_at']) && $candidate['next_attempt_at'] > Store::now()) { continue; }
            if (!\Session::isCron() && !Access::booking(Store::row('bookings', (int) $candidate['bookings_id']))) { continue; }
            $touched[(int) $candidate['bookings_id']] = true;
            try {
                Store::transaction(static function () use ($candidate, &$done): void {
                    $event = Store::lock('bookingoutbox', (int) $candidate['id']);
                    if ($event['status'] !== 'pending') { return; }
                    $booking = Store::row('bookings', (int) $event['bookings_id']);
                    $payload = Store::decode($event['payload_json']);
                    if ($event['kind'] === 'followup') {
                        self::followup($booking, (string) $payload['message'], !empty($payload['is_private']));
                    } elseif ($event['kind'] === 'approval') {
                        $approval = new \TicketValidation(); $ticket = new \Ticket();
                        if (!$approval->getFromDB((int) $payload['ticketvalidations_id']) || !$ticket->getFromDB((int) $booking['tickets_id'])) { throw new \DomainException('Vínculo nativo ausente na fila de aprovação.'); }
                        // Do not send a stale request after it was already answered/cancelled.
                        if ($booking['status'] === 'submitted' && (int) $approval->fields['status'] === \CommonITILValidation::WAITING) {
                            \NotificationEvent::raiseEvent('validation', $ticket, ['validation_id' => $approval->getID(), 'validation_status' => \CommonITILValidation::WAITING], $approval);
                        }
                    }
                    Store::update('bookingoutbox', (int) $event['id'], ['status' => 'done', 'attempts' => (int) $event['attempts'] + 1, 'last_error' => null, 'date_mod' => Store::now()]);
                    ++$done;
                });
            } catch (\Throwable $e) {
                Store::transaction(static function () use ($candidate, $e): void {
                    $event = Store::lock('bookingoutbox', (int) $candidate['id']);
                    if ($event['status'] !== 'pending') { return; }
                    $attempts = (int) $event['attempts'] + 1;
                    Store::update('bookingoutbox', (int) $event['id'], [
                        'attempts' => $attempts, 'last_error' => mb_substr($e->getMessage(), 0, 2000),
                        'next_attempt_at' => date('Y-m-d H:i:s', time() + min(3600, 60 * (2 ** min(6, $attempts)))), 'date_mod' => Store::now(),
                    ]);
                    Store::update('bookings', (int) $event['bookings_id'], ['integration_status' => 'attention', 'integration_error' => 'Acompanhamento/notificação pendente; a ação automática repetirá a entrega.']);
                });
            }
        }
        if ($bookingId > 0) { $touched[$bookingId] = true; }
        foreach (array_keys($touched) as $id) {
            if (!Store::find('bookingoutbox', ['bookings_id' => $id, 'status' => 'pending'], ['LIMIT' => 1])) {
                Store::update('bookings', $id, ['integration_status' => 'synced', 'integration_error' => null]);
            }
        }
        return $done;
    }
}
