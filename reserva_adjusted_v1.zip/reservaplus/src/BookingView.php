<?php

declare(strict_types=1);

namespace GlpiPlugin\Reservaplus;

use Html;
use Session;
use Throwable;

/** Small escaped server-rendered views. All state changes stay in services. */
final class BookingView
{
    public const PAGE_SIZE = 25;
    private static int $fieldSequence = 0;

    public static function text(mixed $value): string
    {
        return is_scalar($value) ? (string) $value : '';
    }

    public static function e(mixed $value): string
    {
        return htmlspecialchars(self::text($value), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    public static function url(string $file, array $query = []): string
    {
        global $CFG_GLPI;
        $base = rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/') . '/plugins/reservaplus/front/' . ltrim($file, '/');
        return $base . ($query === [] ? '' : '?' . http_build_query($query));
    }

    public static function ticketUrl(int $id): string
    {
        global $CFG_GLPI;
        return rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/') . '/front/ticket.form.php?id=' . $id;
    }

    public static function css(): void
    {
        global $CFG_GLPI;
        $url = rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/') . '/plugins/reservaplus/css/workflow.css';
        echo '<link rel="stylesheet" href="' . self::e($url) . '?v=' . self::e(defined('PLUGIN_RESERVAPLUS_VERSION') ? PLUGIN_RESERVAPLUS_VERSION : '0.7') . '">';
    }

    public static function header(string $title): void
    {
        Dashboard::renderHeader($title);
        self::css();
        echo '<div class="rp-workflow"><div class="rp-heading"><div><h1>' . self::e($title) . '</h1>';
        echo '<p class="rp-muted">' . self::e(__('Reservas, retirada, devolução e documentos em um só lugar.', 'reservaplus')) . '</p></div><nav class="rp-nav" aria-label="Reserva Plus">';
        self::link('booking.php', __('Solicitações', 'reservaplus'));
        self::link('workflow.calendar.php', __('Agenda', 'reservaplus'));
        if (Access::right('request')) {
            self::link('booking.form.php', __('Nova reserva', 'reservaplus'), [], 'btn-primary');
        }
        if (Access::right('manage')) {
            self::link('resource.php', __('Recursos', 'reservaplus'));
        }
        echo '</nav></div>';
    }

    public static function footer(): void
    {
        echo '</div>';
        Dashboard::renderFooter();
    }

    public static function requireReady(): void
    {
        Session::checkLoginUser();
        if (!Schema::ready()) {
            throw new \DomainException(__('A atualização do Reserva Plus precisa ser concluída pelo administrador.', 'reservaplus'));
        }
    }

    public static function link(string $file, string $label, array $query = [], string $class = 'btn-outline-secondary'): void
    {
        echo '<a class="btn ' . self::e($class) . '" href="' . self::e(self::url($file, $query)) . '">' . self::e($label) . '</a>';
    }

    /** A second, plugin-owned request binding; GLPI's kernel owns native CSRF. */
    public static function command(string $action, int $id = 0): string
    {
        $key = bin2hex(random_bytes(24));
        $commands = &$_SESSION['reservaplus_commands'];
        if (!is_array($commands)) {
            $commands = [];
        }
        foreach ($commands as $existing => $command) {
            if (($command['expires'] ?? 0) < time()) {
                unset($commands[$existing]);
            }
        }
        while (count($commands) >= 100) {
            array_shift($commands);
        }
        $commands[$key] = ['action' => $action, 'id' => $id, 'user' => Access::userId(), 'expires' => time() + 7200];
        return $key;
    }

    public static function checkCommand(string $key, string $action, int $id = 0): void
    {
        $command = $_SESSION['reservaplus_commands'][$key] ?? null;
        if (!is_array($command) || ($command['action'] ?? '') !== $action || (int) ($command['id'] ?? -1) !== $id
            || (int) ($command['user'] ?? 0) !== Access::userId() || (int) ($command['expires'] ?? 0) < time()) {
            throw new \DomainException(__('O formulário expirou. Atualize a página antes de tentar novamente.', 'reservaplus'));
        }
        // Do not consume here: retries must reach service-level idempotency.
    }

    public static function formStart(string $action, int $id = 0, int $revision = 0): void
    {
        echo '<form method="post" action="' . self::e(self::url('booking.action.php')) . '">';
        self::hidden('action', $action);
        self::hidden('id', $id);
        self::hidden('expected_revision', $revision);
        self::hidden('operation_key', self::command($action, $id));
    }

    public static function hidden(string $name, mixed $value): void
    {
        echo '<input type="hidden" name="' . self::e($name) . '" value="' . self::e($value) . '">';
    }

    public static function input(string $name, string $label, mixed $value = '', string $type = 'text', bool $required = false, string $attributes = ''): void
    {
        $id = 'rp_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $name) . '_' . ++self::$fieldSequence;
        echo '<div class="rp-field"><label for="' . self::e($id) . '">' . self::e($label) . '</label>';
        echo '<input id="' . self::e($id) . '" name="' . self::e($name) . '" type="' . self::e($type) . '" value="' . self::e($value) . '"' . ($required ? ' required' : '') . ' ' . $attributes . '></div>';
    }

    public static function textarea(string $name, string $label, string $value = '', bool $required = false): void
    {
        $id = 'rp_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $name) . '_' . ++self::$fieldSequence;
        echo '<div class="rp-field"><label for="' . self::e($id) . '">' . self::e($label) . '</label><textarea id="' . self::e($id) . '" name="' . self::e($name) . '" maxlength="10000"' . ($required ? ' required' : '') . '>' . self::e($value) . '</textarea></div>';
    }

    public static function select(string $name, string $label, array $options, string $value = ''): void
    {
        $id = 'rp_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $name) . '_' . ++self::$fieldSequence;
        echo '<div class="rp-field"><label for="' . self::e($id) . '">' . self::e($label) . '</label><select id="' . self::e($id) . '" name="' . self::e($name) . '">';
        foreach ($options as $key => $text) {
            echo '<option value="' . self::e($key) . '"' . ((string) $key === $value ? ' selected' : '') . '>' . self::e($text) . '</option>';
        }
        echo '</select></div>';
    }

    public static function submit(string $label): void
    {
        echo '<button class="btn btn-primary" type="submit">' . self::e($label) . '</button>';
    }

    public static function date(mixed $value): string
    {
        $value = self::text($value);
        if ($value === '') {
            return '-';
        }
        return $value;
    }

    public static function datetimeInput(mixed $value): string
    {
        return substr(str_replace(' ', 'T', self::text($value)), 0, 16);
    }

    public static function timezoneNote(): void
    {
        echo '<p class="rp-muted">' . self::e(sprintf(__('Horários no fuso da instalação: %s.', 'reservaplus'), date_default_timezone_get())) . '</p>';
    }

    public static function statuses(): array
    {
        return [
            'submitted' => __('Aguardando aprovação', 'reservaplus'), 'approved' => __('Aprovada', 'reservaplus'),
            'ready' => __('Conferido e liberado', 'reservaplus'), 'issued' => __('Em uso', 'reservaplus'),
            'returning' => __('Devolução em andamento', 'reservaplus'), 'completed' => __('Concluída', 'reservaplus'),
            'rejected' => __('Rejeitada', 'reservaplus'), 'cancelled' => __('Cancelada', 'reservaplus'),
            'requested' => __('Solicitado', 'reservaplus'), 'allocated' => __('Reservado', 'reservaplus'),
            'released' => __('Reserva liberada', 'reservaplus'),
            'received' => __('Recebido; aguarda conferência', 'reservaplus'), 'inspection' => __('Em conferência', 'reservaplus'),
            'inspected' => __('Conferido', 'reservaplus'), 'available' => __('Disponível', 'reservaplus'),
            'quarantine' => __('Retido para avaliação', 'reservaplus'), 'maintenance' => __('Em manutenção', 'reservaplus'),
            'lost' => __('Perda pendente de resolução', 'reservaplus'), 'partial' => __('Devolução parcial', 'reservaplus'),
            'awaiting_signatures' => __('Aguardando assinaturas', 'reservaplus'), 'prepared' => __('Pronto para assinatura', 'reservaplus'),
            'signed' => __('Assinado', 'reservaplus'), 'finalized' => __('Finalizado', 'reservaplus'),
            'complete' => __('Assinado e finalizado', 'reservaplus'),
            'partially_signed' => __('Aguardando os demais signatários', 'reservaplus'),
            'accepted' => __('Aceites registrados; finalizando documento', 'reservaplus'),
            'artifact_error' => __('Aceites registrados; documento precisa de atenção', 'reservaplus'),
            'superseded' => __('Substituído por nova versão', 'reservaplus'), 'artifact_pending' => __('Assinatura registrada; documento em processamento', 'reservaplus'),
        ];
    }

    public static function badge(string $status): void
    {
        $class = preg_replace('/[^a-z_]/', '', $status);
        echo '<span class="rp-badge rp-badge-' . self::e($class) . '">' . self::e(self::statuses()[$status] ?? $status) . '</span>';
    }

    public static function notice(string $message, bool $error = false): void
    {
        echo '<div role="' . ($error ? 'alert' : 'status') . '" class="' . ($error ? 'rp-error' : 'rp-warning') . '">' . self::e($message) . '</div>';
    }

    public static function publicError(Throwable $error): string
    {
        if ($error instanceof \DomainException || $error instanceof \InvalidArgumentException) {
            return $error->getMessage();
        }
        if (class_exists(\Toolbox::class)) {
            \Toolbox::logInFile('reservaplus', get_class($error) . ': ' . $error->getMessage() . "\n");
        }
        return __('Não foi possível concluir esta operação. Atualize a página e, se o problema continuar, informe a equipe responsável.', 'reservaplus');
    }

    public static function renderList(array $rows, array $query = [], bool $compact = false): void
    {
        if ($rows === []) {
            echo '<p class="rp-empty">' . self::e(__('Nenhuma solicitação encontrada neste filtro.', 'reservaplus')) . '</p>';
            return;
        }
        echo '<div class="rp-table-wrap"><table class="rp-table"><thead><tr>';
        foreach ([__('Solicitação', 'reservaplus'), __('Situação', 'reservaplus'), __('Período', 'reservaplus'), __('Finalidade', 'reservaplus'), __('Chamado', 'reservaplus')] as $title) {
            echo '<th scope="col">' . self::e($title) . '</th>';
        }
        echo '</tr></thead><tbody>';
        foreach ($rows as $row) {
            echo '<tr><td><a href="' . self::e(self::url('booking.php', ['id' => (int) $row['id']])) . '">#' . (int) $row['id'] . '</a></td><td>';
            self::badge((string) ($row['status'] ?? ''));
            echo '</td><td>' . self::e(self::date($row['begin'] ?? '')) . '<br>' . self::e(self::date($row['end'] ?? '')) . '</td><td>' . self::e($row['purpose'] ?? '') . '</td><td>';
            if ((int) ($row['tickets_id'] ?? 0) > 0) {
                echo '<a href="' . self::e(self::ticketUrl((int) $row['tickets_id'])) . '">#' . (int) $row['tickets_id'] . '</a>';
            } else {
                echo self::e(__('Pendente', 'reservaplus'));
            }
            echo '</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public static function pagination(string $file, array $query, int $page, bool $more): void
    {
        echo '<nav class="rp-pagination" aria-label="' . self::e(__('Paginação', 'reservaplus')) . '">';
        if ($page > 1) {
            self::link($file, __('Anterior', 'reservaplus'), array_merge($query, ['page' => $page - 1]));
        }
        echo '<span>' . self::e(sprintf(__('Página %d', 'reservaplus'), $page)) . '</span>';
        if ($more) {
            self::link($file, __('Próxima', 'reservaplus'), array_merge($query, ['page' => $page + 1]));
        }
        echo '</nav>';
    }

    public static function locator(array $resource): string
    {
        return implode(' / ', array_filter([
            (string) ($resource['_location_name'] ?? ''), (string) ($resource['building'] ?? ''),
            (string) ($resource['wing'] ?? ''), (string) ($resource['floor'] ?? ''),
            (string) ($resource['room_number'] ?? ''),
        ], static fn(string $v): bool => trim($v) !== ''));
    }

    public static function renderResource(array $resource, bool $checked = false): void
    {
        $id = (int) $resource['id'];
        echo '<label class="rp-resource"><input type="checkbox" name="resources_ids[]" value="' . $id . '"' . ($checked ? ' checked' : '') . '><h3>' . self::e($resource['name'] ?? '#' . $id) . '</h3>';
        $locator = self::locator($resource);
        if ($locator !== '') {
            echo '<p>' . self::e($locator) . '</p>';
        }
        echo '<dl>';
        foreach ([__('Código / patrimônio', 'reservaplus') => $resource['inventory_number'] ?? '', __('Setor responsável', 'reservaplus') => $resource['_sector_name'] ?? '', __('Responsável pela guarda', 'reservaplus') => $resource['_custodian_name'] ?? '', __('Equipe de atendimento', 'reservaplus') => $resource['_ticket_group_name'] ?? ''] as $label => $value) {
            if ((string) $value !== '') {
                echo '<dt>' . self::e($label) . '</dt><dd>' . self::e($value) . '</dd>';
            }
        }
        if (($resource['kind'] ?? '') === 'room') {
            echo '<dt>' . self::e(__('Capacidade', 'reservaplus')) . '</dt><dd>' . (int) ($resource['capacity'] ?? 0) . '</dd>';
            if (!empty($resource['area_m2'])) {
                echo '<dt>' . self::e(__('Área', 'reservaplus')) . '</dt><dd>' . self::e($resource['area_m2']) . ' m²</dd>';
            }
        }
        echo '</dl>';
        if (!empty($resource['features'])) {
            echo '<p class="rp-muted">' . self::e($resource['features']) . '</p>';
        }
        if (!empty($resource['_calendar_label'])) {
            echo '<p class="rp-muted">' . self::e($resource['_calendar_label']) . '</p>';
        }
        $policy = ResourceService::policy($resource);
        $signature = ['submission' => __('Assinatura na solicitação', 'reservaplus'), 'approval' => __('Assinatura após aprovação', 'reservaplus'), 'handover' => __('Assinatura antes da retirada / uso', 'reservaplus'), 'none' => __('Sem assinatura de retirada obrigatória', 'reservaplus')];
        echo '<p class="rp-muted">' . self::e(!empty($policy['approval_required']) ? __('Exige aprovação da equipe.', 'reservaplus') : __('Confirmação sujeita à disponibilidade.', 'reservaplus')) . ' ' . self::e($signature[$policy['signature_stage'] ?? 'none'] ?? '') . '.</p>';
        if (!empty($policy['return_signature_required'])) {
            echo '<p class="rp-muted">' . self::e(__('Exige termo assinado na devolução / término de uso.', 'reservaplus')) . '</p>';
        }
        echo '</label>';
    }

    private static function lineSnapshot(array $line): array
    {
        $snapshot = Store::decode($line['snapshot_json'] ?? null);
        return is_array($snapshot['resource'] ?? null) ? $snapshot['resource'] : $snapshot;
    }

    private static function lineName(array $line): string
    {
        $snapshot = self::lineSnapshot($line);
        return (string) ($snapshot['name'] ?? $line['resource_name'] ?? ('Recurso #' . (int) ($line['resources_id'] ?? 0)));
    }

    public static function renderDetail(array $booking): void
    {
        $id = (int) $booking['id'];
        echo '<section class="rp-panel"><div class="rp-heading"><h2>' . self::e(sprintf(__('Solicitação #%d', 'reservaplus'), $id)) . '</h2>';
        self::badge((string) $booking['status']);
        echo '</div><dl class="rp-meta">';
        $snapshot = Store::decode($booking['borrower_snapshot_json'] ?? null);
        $values = [
            __('Usuário responsável pelo uso', 'reservaplus') => $snapshot['name'] ?? ('#' . (int) $booking['users_id_borrower']),
            __('Matrícula informada', 'reservaplus') => $snapshot['matricula'] ?? '',
            __('Unidade informada', 'reservaplus') => $snapshot['unit'] ?? '',
            __('Início previsto', 'reservaplus') => self::date($booking['begin'] ?? ''),
            __('Devolução / término previsto', 'reservaplus') => self::date($booking['end'] ?? ''),
        ];
        foreach ($values as $label => $value) {
            if ((string) $value !== '') {
                echo '<div><dt>' . self::e($label) . '</dt><dd>' . self::e($value) . '</dd></div>';
            }
        }
        echo '</dl><p>' . nl2br(self::e($booking['purpose'] ?? '')) . '</p>';
        if ((int) ($booking['tickets_id'] ?? 0) > 0) {
            echo '<a class="btn btn-outline-primary" href="' . self::e(self::ticketUrl((int) $booking['tickets_id'])) . '">' . self::e(sprintf(__('Abrir chamado #%d', 'reservaplus'), $booking['tickets_id'])) . '</a>';
        }
        self::timezoneNote();
        if (!in_array((string) ($booking['integration_status'] ?? ''), ['', 'ok', 'synced', 'synchronized'], true)) {
            self::notice(__('Há uma atualização pendente com o chamado, calendário ou documentos. A equipe deve verificar a solicitação antes de repetir a operação.', 'reservaplus'));
        }
        if (in_array((string) $booking['status'], ['issued', 'returning'], true)) {
            echo '<p class="rp-muted">' . self::e(__('Nesta versão, o período de empréstimos já entregues não pode ser prorrogado. Registre a devolução e faça uma nova solicitação para outro período.', 'reservaplus')) . '</p>';
        }
        echo '</section><section class="rp-panel"><h2>' . self::e(__('Recursos e devolução', 'reservaplus')) . '</h2><div class="rp-table-wrap"><table class="rp-table"><thead><tr>';
        foreach ([__('Recurso', 'reservaplus'), __('Situação', 'reservaplus'), __('Retirada', 'reservaplus'), __('Recebimento', 'reservaplus'), __('Conferência', 'reservaplus')] as $label) {
            echo '<th scope="col">' . self::e($label) . '</th>';
        }
        echo '</tr></thead><tbody>';
        foreach ($booking['lines'] ?? [] as $line) {
            $resource = self::lineSnapshot($line);
            echo '<tr><td><strong>' . self::e(self::lineName($line)) . '</strong><br><span class="rp-muted">' . self::e(self::locator($resource)) . '</span>';
            self::renderAccessorySummary($line);
            echo '</td><td>';
            self::badge((string) ($line['state'] ?? 'requested'));
            echo '</td><td>' . self::e(self::date($line['issued_at'] ?? '')) . '</td><td>' . self::e(self::date($line['received_at'] ?? '')) . '</td><td>' . self::e(self::date($line['inspection_at'] ?? '')) . '</td></tr>';
        }
        echo '</tbody></table></div><p class="rp-muted">' . self::e(__('O recebimento confirma quais itens voltaram. A conferência e a liberação para novo uso são registradas separadamente.', 'reservaplus')) . '</p></section>';
        self::renderDocuments($booking);
        self::renderActions($booking);
        self::renderHistory($booking);
    }

    private static function renderAccessorySummary(array $line): void
    {
        $accessories = Store::decode($line['accessories_json'] ?? null);
        if ($accessories === []) {
            return;
        }
        echo '<ul class="rp-muted">';
        foreach ($accessories as $accessory) {
            if (!is_array($accessory)) {
                continue;
            }
            $issued = (int) ($accessory['issued'] ?? $accessory['quantity'] ?? 0);
            $received = (int) ($accessory['received'] ?? $accessory['returned'] ?? 0);
            echo '<li>' . self::e($accessory['name'] ?? '') . ': ' . self::e(sprintf(__('%1$d de %2$d devolvidos', 'reservaplus'), $received, $issued)) . '</li>';
        }
        echo '</ul>';
    }

    public static function purposeLabel(string $purpose): string
    {
        return [
            'request' => __('Termo da solicitação', 'reservaplus'), 'handover' => __('Termo de entrega', 'reservaplus'),
            'return_receipt' => __('Recebimento para conferência', 'reservaplus'),
            'return_inspection' => __('Termo de devolução e conferência', 'reservaplus'),
        ][$purpose] ?? $purpose;
    }

    private static function renderDocuments(array $booking): void
    {
        echo '<section class="rp-panel"><h2>' . self::e(__('Documentos e assinaturas', 'reservaplus')) . '</h2>';
        $documents = DocumentService::forBooking((int) $booking['id']);
        if ($documents === []) {
            echo '<p class="rp-muted">' . self::e(__('Nenhum termo preparado para esta solicitação.', 'reservaplus')) . '</p>';
        } else {
            echo '<div class="rp-table-wrap"><table class="rp-table"><thead><tr><th>' . self::e(__('Documento', 'reservaplus')) . '</th><th>' . self::e(__('Situação', 'reservaplus')) . '</th><th>' . self::e(__('Acesso', 'reservaplus')) . '</th></tr></thead><tbody>';
            foreach ($documents as $document) {
                echo '<tr><td>' . self::e(self::purposeLabel((string) $document['purpose'])) . ' <span class="rp-muted">#' . (int) $document['id'] . '</span></td><td>';
                self::badge((string) $document['status']);
                echo '</td><td>';
                self::link('agreement.php', __('Revisar / assinar', 'reservaplus'), ['id' => (int) $document['id']]);
                echo '</td></tr>';
            }
            echo '</tbody></table></div>';
        }
        $state = (string) $booking['status'];
        $purposes = [];
        if (!in_array($state, ['cancelled', 'rejected', 'completed'], true)) {
            $purposes[] = 'request';
        }
        if (in_array($state, ['approved', 'ready'], true)) {
            $purposes[] = 'handover';
        }
        foreach ($booking['lines'] ?? [] as $line) {
            if (!empty($line['received_at'])) {
                $purposes[] = 'return_receipt';
            }
            if (!empty($line['inspection_at'])) {
                $purposes[] = 'return_inspection';
            }
        }
        if ($purposes !== []) {
            echo '<details class="rp-subform"><summary>' . self::e(__('Preparar documento desta etapa', 'reservaplus')) . '</summary>';
            self::formStart('prepare_document', (int) $booking['id'], (int) $booking['revision']);
            $options = [];
            foreach (array_unique($purposes) as $purpose) {
                $options[$purpose] = self::purposeLabel($purpose);
            }
            self::select('purpose', __('Documento', 'reservaplus'), $options);
            self::submit(__('Preparar para revisão', 'reservaplus'));
            Html::closeForm();
            echo '</details>';
        }
        echo '</section>';
    }

    private static function actionLines(array $booking, string $capability, array $states = []): array
    {
        $lines = [];
        foreach ($booking['lines'] ?? [] as $line) {
            if ($states !== [] && !in_array((string) ($line['state'] ?? ''), $states, true)) {
                continue;
            }
            try {
                $resource = Store::row('resources', (int) $line['resources_id']);
                if (Access::resource($resource, $capability)) {
                    $lines[] = $line;
                }
            } catch (\RuntimeException) {
                // A broken link cannot be acted upon from this screen.
            }
        }
        return $lines;
    }

    private static function chooseLines(array $lines, bool $accessories = false): void
    {
        echo '<fieldset><legend class="fs-6">' . self::e(__('Selecione os itens desta operação', 'reservaplus')) . '</legend>';
        foreach ($lines as $line) {
            $id = (int) $line['id'];
            echo '<label class="rp-check"><input type="checkbox" name="lines_ids[]" value="' . $id . '"><span>' . self::e(self::lineName($line)) . '</span></label>';
            if ($accessories) {
                foreach (Store::decode($line['accessories_json'] ?? null) as $index => $accessory) {
                    if (!is_array($accessory) || !is_numeric($index)) {
                        continue;
                    }
                    $issued = (int) ($accessory['issued'] ?? $accessory['quantity'] ?? 0);
                    $received = (int) ($accessory['received'] ?? $accessory['returned'] ?? 0);
                    $outstanding = max(0, $issued - $received);
                    if ($outstanding > 0) {
                        self::input('accessories[' . $id . '][' . (int) $index . ']', sprintf(__('Recebidos agora: %s', 'reservaplus'), $accessory['name'] ?? ''), 0, 'number', false, 'min="0" max="' . $outstanding . '" step="1"');
                    }
                }
            }
        }
        echo '</fieldset>';
    }

    private static function actionStart(array $booking, string $action, string $label, string $description = ''): void
    {
        echo '<details class="rp-subform"><summary>' . self::e($label) . '</summary>';
        if ($description !== '') {
            echo '<p>' . self::e($description) . '</p>';
        }
        self::formStart($action, (int) $booking['id'], (int) $booking['revision']);
    }

    private static function actionEnd(string $label): void
    {
        self::submit($label);
        Html::closeForm();
        echo '</details>';
    }

    private static function renderActions(array $booking): void
    {
        $state = (string) $booking['status'];
        if (in_array($state, ['completed', 'rejected', 'cancelled'], true)) {
            return;
        }
        echo '<section class="rp-panel"><h2>' . self::e(__('Próximas ações', 'reservaplus')) . '</h2>';
        $approveLines = self::actionLines($booking, 'approve', ['requested']);
        if ($approveLines !== [] && $state === 'submitted') {
            foreach (['approve' => __('Aprovar recursos', 'reservaplus'), 'reject' => __('Rejeitar solicitação', 'reservaplus')] as $action => $label) {
                self::actionStart($booking, $action, $label);
                self::chooseLines($approveLines);
                self::textarea('reason', __('Justificativa', 'reservaplus'), '', $action === 'reject');
                self::actionEnd($label);
            }
        }
        if (in_array($state, ['approved', 'ready'], true) && Access::booking($booking, 'issue')) {
            self::actionStart($booking, 'issue', __('Registrar entrega / início de uso', 'reservaplus'), __('Confira a identidade, os recursos e os acessórios. Os termos obrigatórios devem estar aceitos antes da entrega.', 'reservaplus'));
            self::textarea('condition', __('Condição na entrega e conferência dos acessórios', 'reservaplus'), '', true);
            self::actionEnd(__('Confirmar entrega', 'reservaplus'));
        }
        $receiveLines = array_values(array_filter(self::actionLines($booking, 'receive', ['issued', 'received', 'quarantine', 'maintenance']), static fn(array $line): bool => (self::lineSnapshot($line)['kind'] ?? '') !== 'room'));
        if ($receiveLines !== [] && in_array($state, ['issued', 'returning'], true)) {
            self::actionStart($booking, 'receive', __('Receber devolução', 'reservaplus'), __('Marque apenas os itens que recebeu e informe a quantidade de cada acessório entregue agora. O recebimento não declara que a conferência foi aprovada.', 'reservaplus'));
            self::chooseLines($receiveLines, true);
            self::input('deliverer', __('Nome de quem entregou os itens', 'reservaplus'), '', 'text', true, 'maxlength="255"');
            self::textarea('note', __('Observações do recebimento', 'reservaplus'));
            self::actionEnd(__('Registrar recebimento agora', 'reservaplus'));
        }
        $inspectLines = array_values(array_filter(self::actionLines($booking, 'inspect', ['received', 'quarantine', 'maintenance', 'allocated', 'issued']), static fn(array $line): bool => in_array($line['state'], ['received', 'quarantine', 'maintenance'], true) || (self::lineSnapshot($line)['kind'] ?? '') === 'room'));
        if ($inspectLines !== [] && in_array($state, ['approved', 'issued', 'returning'], true)) {
            self::actionStart($booking, 'inspect', __('Conferir devolução / término de uso', 'reservaplus'), __('Registre a conferência dos equipamentos recebidos ou das salas após o uso. Aponte faltas, avarias e testes realizados; nenhuma verificação é aprovada automaticamente.', 'reservaplus'));
            self::chooseLines($inspectLines);
            self::select('result', __('Resultado da conferência', 'reservaplus'), ['' => __('Selecione o resultado', 'reservaplus'), 'pass' => __('Aprovado para novo uso', 'reservaplus'), 'quarantine' => __('Reter para avaliação', 'reservaplus'), 'maintenance' => __('Encaminhar para manutenção', 'reservaplus')]);
            self::textarea('findings', __('Verificações, condição e pendências', 'reservaplus'), '', true);
            self::actionEnd(__('Registrar conferência', 'reservaplus'));
        }
        $allReady = ($booking['lines'] ?? []) !== [];
        foreach ($booking['lines'] ?? [] as $line) {
            $allReady = $allReady && ($line['state'] ?? '') === 'ready' && !empty($line['inspection_at']);
        }
        if ($allReady && Access::booking($booking, 'inspect') && $state === 'returning') {
            self::actionStart($booking, 'complete', __('Concluir solicitação', 'reservaplus'), __('A conclusão exige os registros de devolução ou término de uso e os documentos obrigatórios. Encerrar não substitui os registros físicos.', 'reservaplus'));
            self::actionEnd(__('Verificar requisitos e concluir', 'reservaplus'));
        }
        if (Access::booking($booking, 'approve') && in_array($state, ['submitted', 'approved', 'ready'], true)) {
            self::actionStart($booking, 'extend', __('Alterar período antes da entrega', 'reservaplus'), __('A alteração será validada contra a disponibilidade e pode exigir novos termos. Esta ação não altera empréstimos já entregues.', 'reservaplus'));
            self::input('begin', __('Novo início', 'reservaplus'), self::datetimeInput($booking['begin'] ?? ''), 'datetime-local', true);
            self::input('end', __('Novo término', 'reservaplus'), self::datetimeInput($booking['end'] ?? ''), 'datetime-local', true);
            self::actionEnd(__('Validar e alterar período', 'reservaplus'));
        }
        if (in_array($state, ['submitted', 'approved'], true) && (Access::booking($booking, 'request') || Access::booking($booking, 'manage'))) {
            self::actionStart($booking, 'cancel', __('Cancelar antes da entrega', 'reservaplus'));
            self::textarea('reason', __('Motivo do cancelamento', 'reservaplus'), '', true);
            self::actionEnd(__('Cancelar solicitação', 'reservaplus'));
        }
        echo '</section>';
    }

    private static function renderHistory(array $booking): void
    {
        $labels = ['submitted'=>'Solicitação enviada', 'approve'=>'Aprovação registrada', 'approved'=>'Aprovação registrada', 'reject'=>'Solicitação rejeitada', 'issue'=>'Entrega confirmada', 'issued'=>'Entrega registrada', 'receive'=>'Recebimento confirmado', 'received'=>'Recebimento registrado', 'inspect'=>'Conferência confirmada', 'inspected'=>'Conferência registrada', 'complete'=>'Solicitação concluída', 'cancel'=>'Solicitação cancelada', 'extend'=>'Período alterado', 'signed'=>'Assinatura registrada'];
        echo '<section class="rp-panel"><h2>' . self::e(__('Histórico', 'reservaplus')) . '</h2><ol class="rp-timeline">';
        foreach ($booking['events'] ?? [] as $event) {
            $type = (string) ($event['type'] ?? $event['event_type'] ?? '');
            echo '<li><time>' . self::e(self::date($event['occurred_at'] ?? $event['recorded_at'] ?? '')) . '</time><strong>' . self::e(__($labels[$type] ?? 'Atualização registrada', 'reservaplus')) . '</strong></li>';
        }
        echo '</ol></section>';
    }
}
