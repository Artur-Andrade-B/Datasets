# Validation record — 0.7.0-rc1

Validation date: 2026-10-28. Tests used a disposable local installation, never the production GLPI database.

## Environment

| Component | Tested version |
| --- | --- |
| GLPI | 11.0.7 official release, real native classes and bundled dependencies |
| PHP | 8.3.6 |
| MariaDB | 10.11.14, InnoDB |
| TCPDF | 6.11.2 bundled with GLPI |
| Starting plugin | Supplied ReservaPlus 0.6.1 |

The original 49 extracted source files were compared byte-for-byte with the supplied ZIP and remain unchanged. Work and the upgrade test used separate copies.

## Automated results

| Suite | Result / scope |
| --- | --- |
| PHP syntax | All 79 packaged PHP files passed lint. |
| Standalone tests | Six test files passed with 72 checks: authorization (12), resources (8), workflow (7), documents (5), UI (3) and legacy behavior (37). |
| Upgrade preservation | Original 0.6.1 was installed first. All 40 existing profile-right rows, including explicit denials, and the original native asset, reservation item, reservation and legacy request survived upgrade. |
| Legacy live verifier | 95 checks passed using actual GLPI objects and database rows; fixtures rolled back. |
| Workflow live integration | 11 grouped scenarios passed: self-service submission, one native ticket, retry identity, group approval, calendar allocation, native mutation guards, partial return, inspection, signed completion, room closure, ticket reuse, revisions and hold handling. |
| Resource live integration | Six grouped scenarios passed: internal-only inventory identity, restricted calendar mode, policy strengthening/weakening, revision conflicts, scoped discovery, stale-session membership revocation and entity isolation. |
| Document live integration | Eight grouped scenarios passed: viewed source/exact consent, actor scope, actual native attachment, replay, tampering, material versions, multiple return/inspection signers, failed finalization recovery and historical key preservation. |
| Concurrency | Four grouped multi-process scenarios passed, covering distinct submissions, identical retry keys, competing native approvals and forced-wait private-resource approvals. Only one competing allocation committed. |
| Native automatic actions | Two grouped scenarios passed for unsigned-hold expiry and outbox delivery using native GLPI CronTask execution without a logged-in user. |

Grouped scenarios include multiple assertions and are not counts of individual browser interactions.

The final consolidated run used an unchanged production-source fingerprint and produced no new PHP error-log entries or SQL error log.

The forced-wait private-resource approval test originally reproduced two allocations under a stale REPEATABLE READ snapshot. The release fixes that failure with per-transaction READ COMMITTED plus the resource lock, and the same reproducer passes. The database connection's default isolation setting is not changed globally.

## HTTP, browser and PDF checks

- Native GLPI catalog cards rendered and opened resource-kind-specific intake. An actual Self-Service profile saw catalog/intake without staff actions or the on-behalf selector.
- Queue, detail, native ticket tab, calendar and static assets rendered through GLPI 11 HTTP routing. Mirrored assets matched.
- Missing native CSRF was rejected with HTTP 403. Valid CSRF reached the domain action and returned a 303 redirect. A successful HTTP form submission created a booking and its native ticket.
- Desktop and 390-pixel mobile layouts were inspected in a browser with no JavaScript page errors in the checked flows.
- Generated source/final Portuguese PDFs were rendered and visually inspected. Accented identities and room/location fields remained readable.
- Native final-document creation and the actual Ticket `Document_Item` association were checked in the database. Private evidence was not attached to the ticket.

Screenshots and generated fixture documents are validation intermediates, not included in the installable plugin.

## Repeating tests

Standalone checks do not require a database:

```bash
PHP_BIN=php bash tools/run-tests.sh
```

Live tests deliberately write fixtures. Provision a disposable GLPI 11.0.7 installation, install and activate this plugin, and configure an administrator and self-service fixture account. Use an exact expected database name; each test checks it before writes. A representative invocation is:

```bash
GLPI_ROOT=/path/to/disposable/glpi \
RP_TEST_DATABASE=disposable_glpi \
RP_TEST_ALLOW_WRITES=1 \
RP_TEST_NATIVE_GUARDS=1 \
RP_TEST_ADMIN=fixture_admin \
RP_TEST_EMPLOYEE=fixture_employee \
php tests/integration_workflow.php
```

The same guarded setup is used by `tests/resources_integration.php`, `tests/documents_integration.php`, `tests/integration_concurrency.php`, `tests/integration_cron.php` and `tools/verify.php`. Check each script's fixture assumptions before running. Some suites retain uniquely named fixtures for inspection; do not point them at production. The concurrency suite starts separate PHP workers.

## Limits of this evidence

This is a tested release candidate, not production certification. No production installation, deployment, database migration or external message delivery was performed. The tests do not establish compatibility with every GLPI 11 patch, PHP 8.2/8.4/8.5, MySQL, production data volume, external SMTP delivery, every native ticket rule/profile combination, SSO/MFA provider or third-party plugin combination.

The site's real permissions, ticket state matrix, notification configuration, backup/restore procedure, scheduler, private file serving and document wording still require staging acceptance. Functional release boundaries are listed in the README. Generic native API writes, disabling the plugin, direct SQL and unrelated outer transactions are not supported ways to execute this workflow.
