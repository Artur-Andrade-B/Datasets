<?php

declare(strict_types=1);

use GlpiPlugin\Reservaplus\Access;
use GlpiPlugin\Reservaplus\BookingService;
use GlpiPlugin\Reservaplus\BookingView;

include_once (defined('GLPI_ROOT') ? GLPI_ROOT . '/inc/includes.php' : __DIR__ . '/../../../inc/includes.php');

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    http_response_code(405);
    header('Allow: GET');
    echo json_encode(['error' => 'Método não permitido.'], JSON_UNESCAPED_UNICODE);
    exit;
}
try {
    BookingView::requireReady();
    Access::assertRight('read');
    $start = is_string($_GET['start'] ?? null) ? $_GET['start'] : '';
    $end = is_string($_GET['end'] ?? null) ? $_GET['end'] : '';
    $from = new DateTimeImmutable($start);
    $to = new DateTimeImmutable($end);
    if ($start === '' || $end === '' || $to <= $from || $to->getTimestamp() - $from->getTimestamp() > 93 * 86400) {
        throw new DomainException(__('Escolha um intervalo válido de até 93 dias.', 'reservaplus'));
    }
    $offset = max(0, min(1000000, (int) ($_GET['offset'] ?? 0)));
    $rows = BookingService::search(['from' => $from->format('Y-m-d H:i:s'), 'to' => $to->format('Y-m-d H:i:s')], 101, $offset);
    $more = count($rows) > 100;
    $events = [];
    foreach (array_slice($rows, 0, 100) as $row) {
        if (in_array($row['status'] ?? '', ['cancelled', 'rejected'], true)) {
            continue;
        }
        $state = (string) $row['status'];
        $events[] = [
            'id' => (int) $row['id'], 'start' => $row['begin'], 'end' => $row['end'],
            'title' => '#' . (int) $row['id'] . ' - ' . (BookingView::statuses()[$state] ?? $state),
            'status' => $state, 'url' => BookingView::url('booking.php', ['id' => (int) $row['id']]), 'editable' => false,
        ];
    }
    echo json_encode(['events' => $events, 'has_more' => $more, 'next_offset' => $more ? $offset + 100 : null, 'timezone' => date_default_timezone_get()], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
} catch (Throwable $error) {
    http_response_code($error instanceof DomainException || $error instanceof InvalidArgumentException ? 400 : 403);
    echo json_encode(['error' => BookingView::publicError($error)], JSON_UNESCAPED_UNICODE);
}
