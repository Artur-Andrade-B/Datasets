<?php

declare(strict_types=1);

use GlpiPlugin\Reservaplus\Access;
use GlpiPlugin\Reservaplus\BookingService;
use GlpiPlugin\Reservaplus\BookingView;

include_once (defined('GLPI_ROOT') ? GLPI_ROOT . '/inc/includes.php' : __DIR__ . '/../../../inc/includes.php');

$opened = false;
try {
    BookingView::requireReady();
    Access::assertRight('read');
    $id = max(0, (int) ($_GET['id'] ?? 0));
    if ($id > 0) {
        $booking = BookingService::get($id);
        BookingView::header(__('Detalhes da reserva', 'reservaplus'));
        $opened = true;
        BookingView::renderDetail($booking);
    } else {
        $page = max(1, min(100000, (int) ($_GET['page'] ?? 1)));
        $filters = [];
        $status = is_string($_GET['status'] ?? null) ? $_GET['status'] : '';
        $statusOptions = array_intersect_key(BookingView::statuses(), array_flip(['submitted', 'approved', 'issued', 'returning', 'completed', 'rejected', 'cancelled']));
        if (isset($statusOptions[$status])) {
            $filters['status'] = $status;
        }
        $rows = BookingService::search($filters, BookingView::PAGE_SIZE + 1, ($page - 1) * BookingView::PAGE_SIZE);
        $more = count($rows) > BookingView::PAGE_SIZE;
        $rows = array_slice($rows, 0, BookingView::PAGE_SIZE);
        BookingView::header(__('Solicitações de reserva', 'reservaplus'));
        $opened = true;
        echo '<section class="rp-panel"><form method="get" action="' . BookingView::e(BookingView::url('booking.php')) . '"><div class="rp-grid">';
        BookingView::select('status', __('Situação', 'reservaplus'), ['' => __('Todas as situações', 'reservaplus')] + $statusOptions, $status);
        echo '<div class="rp-actions">';
        BookingView::submit(__('Filtrar', 'reservaplus'));
        echo '</div></div></form>';
        BookingView::renderList($rows);
        BookingView::pagination('booking.php', $filters, $page, $more);
        echo '</section>';
        BookingView::timezoneNote();
    }
} catch (Throwable $error) {
    if (!$opened) {
        http_response_code(403);
        BookingView::header(__('Reserva Plus', 'reservaplus'));
    }
    BookingView::notice(BookingView::publicError($error), true);
}
BookingView::footer();
