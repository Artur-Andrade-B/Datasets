<?php

declare(strict_types=1);

use GlpiPlugin\Reservaplus\Access;
use GlpiPlugin\Reservaplus\BookingView;
use GlpiPlugin\Reservaplus\Dashboard;
use GlpiPlugin\Reservaplus\Sector;
use GlpiPlugin\Reservaplus\Store;

include_once (defined('GLPI_ROOT') ? GLPI_ROOT . '/inc/includes.php' : __DIR__ . '/../../../inc/includes.php');
Session::checkLoginUser();
Access::assertRight('admin');
$e=static fn(mixed $v): string=>htmlspecialchars((string)$v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
$base=($CFG_GLPI['root_doc'] ?? '').'/plugins/reservaplus/front/';
$id=(int)($_POST['id'] ?? $_GET['id'] ?? 0); $error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    try {
        $id=Sector::save($_POST,$id);
        Session::addMessageAfterRedirect(__('Setor salvo.','reservaplus'));
        Html::redirect($base.'sector.php?id='.$id); return;
    } catch (Throwable $ex) { $error=BookingView::publicError($ex); }
}
Dashboard::renderHeader(__('Setores responsáveis','reservaplus'));
try {
    $row=$id>0?Store::row('sectors',$id):[];
    $entity=(int)($row['entities_id'] ?? $_GET['entities_id'] ?? $_SESSION['glpiactive_entity'] ?? 0);
    if (!Access::entity($entity)) { throw new DomainException(__('Entidade indisponível.','reservaplus')); }
} catch (Throwable $ex) {
    http_response_code(403); echo '<div class="alert alert-danger">'.$e(BookingView::publicError($ex)).'</div>'; Dashboard::renderFooter(); return;
}
echo '<div class="container-fluid"><h1>'.__('Setores responsáveis','reservaplus').'</h1><p>'.__('O setor identifica a unidade organizacional. Não cria grupo, entidade nem concessão de permissão no GLPI.','reservaplus').'</p>';
if ($error!=='') { echo '<div class="alert alert-danger">'.$e($error).'</div>'; }
echo '<form method="post" action="'.$e($base.'sector.php').'" class="card card-body mb-3"><input type="hidden" name="id" value="'.$id.'"><input type="hidden" name="entities_id" value="'.$entity.'"><div class="row g-3"><div class="col-md-4"><label class="form-label" for="sector-name">'.__('Nome','reservaplus').'</label><input id="sector-name" class="form-control" name="name" maxlength="255" required value="'.$e($row['name'] ?? '').'"></div><div class="col-md-3"><label class="form-label" for="sector-code">'.__('Código','reservaplus').'</label><input id="sector-code" class="form-control" name="code" maxlength="64" required value="'.$e($row['code'] ?? '').'"></div><div class="col-md-5"><label class="form-label" for="sector-parent">'.__('Setor superior','reservaplus').'</label><select id="sector-parent" class="form-select" name="parent_id"><option value="0">'.__('Nenhum','reservaplus').'</option>';
foreach (Sector::search($entity) as $sector) {
    if ((int)$sector['id']===$id) { continue; }
    echo '<option value="'.(int)$sector['id'].'"'.((int)($row['parent_id'] ?? 0)===(int)$sector['id']?' selected':'').'>'.$e($sector['name']).'</option>';
}
echo '</select></div></div><label class="form-check my-3"><input class="form-check-input" type="checkbox" name="is_active" value="1"'.(!$row || (int)$row['is_active']?' checked':'').'><span class="form-check-label">'.__('Ativo','reservaplus').'</span></label><div><button class="btn btn-primary" type="submit">'.__('Salvar setor','reservaplus').'</button> <a class="btn btn-outline-secondary" href="'.$e($base.'sector.php').'">'.__('Novo setor','reservaplus').'</a></div>';
Html::closeForm();
echo '<div class="card"><table class="table"><thead><tr><th>'.__('Código','reservaplus').'</th><th>'.__('Nome','reservaplus').'</th><th>'.__('Ativo','reservaplus').'</th></tr></thead><tbody>';
foreach (Sector::search($entity,false) as $sector) { echo '<tr><td>'.$e($sector['code']).'</td><td><a href="'.$e($base.'sector.php?id='.(int)$sector['id']).'">'.$e($sector['name']).'</a></td><td>'.((int)$sector['is_active']?__('Sim','reservaplus'):__('Não','reservaplus')).'</td></tr>'; }
echo '</tbody></table></div><a class="btn btn-outline-secondary my-3" href="'.$e($base.'resource.php').'">'.__('Recursos','reservaplus').'</a></div>';
Dashboard::renderFooter();
