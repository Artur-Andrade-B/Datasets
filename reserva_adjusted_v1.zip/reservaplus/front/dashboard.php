<?php

declare(strict_types=1);

use GlpiPlugin\Reservaplus\Dashboard;

include_once (defined('GLPI_ROOT') ? GLPI_ROOT . '/inc/includes.php' : __DIR__ . '/../../../inc/includes.php');

Session::checkLoginUser();

if (!Dashboard::canView()) {
    Html::displayRightError();
}

Dashboard::renderHeader(__('Reserva Plus', 'reservaplus'));
Dashboard::includeAssets();
Dashboard::showDashboard();
Dashboard::renderFooter();
