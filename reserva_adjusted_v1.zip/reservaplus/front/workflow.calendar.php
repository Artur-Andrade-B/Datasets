<?php

declare(strict_types=1);

use GlpiPlugin\Reservaplus\Access;
use GlpiPlugin\Reservaplus\BookingService;
use GlpiPlugin\Reservaplus\BookingView;

include_once (defined('GLPI_ROOT') ? GLPI_ROOT . '/inc/includes.php' : __DIR__ . '/../../../inc/includes.php');

$opened = false;
try {
    BookingView::requireReady();
    Access::assertRight('read');
    $monthText = is_string($_GET['month'] ?? null) ? $_GET['month'] : date('Y-m');
    if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/D', $monthText)) {
        throw new DomainException(__('Mês inválido.', 'reservaplus'));
    }
    $month = new DateTimeImmutable($monthText . '-01 00:00:00');
    $gridStart = $month->modify('-' . $month->format('w') . ' days');
    $gridEnd = $gridStart->modify('+42 days');
    $page = max(1, min(100000, (int) ($_GET['page'] ?? 1)));
    $filters = ['from' => $gridStart->format('Y-m-d H:i:s'), 'to' => $gridEnd->format('Y-m-d H:i:s')];
    $rows = BookingService::search($filters, 101, ($page - 1) * 100);
    $more = count($rows) > 100;
    $rows = array_slice($rows, 0, 100);
    $rows = array_values(array_filter($rows, static fn(array $r): bool => !in_array($r['status'] ?? '', ['cancelled', 'rejected'], true)));
    BookingView::header(__('Agenda de reservas', 'reservaplus'));
    $opened = true;
    echo '<section class="rp-panel"><div class="rp-heading"><h2>' . BookingView::e($month->format('m/Y')) . '</h2><nav class="rp-nav">';
    BookingView::link('workflow.calendar.php', __('Mês anterior', 'reservaplus'), ['month' => $month->modify('-1 month')->format('Y-m')]);
    BookingView::link('workflow.calendar.php', __('Mês atual', 'reservaplus'));
    BookingView::link('workflow.calendar.php', __('Próximo mês', 'reservaplus'), ['month' => $month->modify('+1 month')->format('Y-m')]);
    echo '</nav></div><form method="get" class="rp-actions" action="' . BookingView::e(BookingView::url('workflow.calendar.php')) . '">';
    BookingView::input('month', __('Ir para o mês', 'reservaplus'), $monthText, 'month', true);
    BookingView::submit(__('Ir', 'reservaplus'));
    echo '</form><p class="rp-muted">' . BookingView::e(__('Esta agenda mostra as solicitações que você pode acessar. Solicitações pendentes ainda não garantem disponibilidade. Consulte o recurso e o período ao fazer uma nova reserva.', 'reservaplus')) . '</p>';
    BookingView::timezoneNote();
    if ($more || $page > 1) {
        BookingView::notice(__('Há muitas solicitações neste período. Os eventos desta página estão destacados; use a paginação para consultar os demais.', 'reservaplus'));
    }
    echo '<div class="rp-month" role="table" aria-label="' . BookingView::e(__('Reservas do mês', 'reservaplus')) . '">';
    foreach (['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'] as $weekday) {
        echo '<div class="rp-month-weekday" role="columnheader">' . BookingView::e(__($weekday, 'reservaplus')) . '</div>';
    }
    for ($i = 0; $i < 42; $i++) {
        $day = $gridStart->modify('+' . $i . ' days');
        $dayEnd = $day->modify('+1 day');
        echo '<div role="cell" class="rp-month-day' . ($day->format('m') !== $month->format('m') ? ' rp-month-other' : '') . ($day->format('Y-m-d') === date('Y-m-d') ? ' rp-month-today' : '') . '"><div class="rp-month-number">';
        if (Access::right('request')) {
            echo '<a href="' . BookingView::e(BookingView::url('booking.form.php', ['begin' => $day->format('Y-m-d') . 'T08:00', 'end' => $day->format('Y-m-d') . 'T09:00'])) . '" aria-label="' . BookingView::e(sprintf(__('Solicitar reserva em %s', 'reservaplus'), $day->format('d/m/Y'))) . '">' . $day->format('j') . '</a>';
        } else {
            echo $day->format('j');
        }
        echo '</div>';
        foreach ($rows as $row) {
            if ((string) ($row['begin'] ?? '') >= $dayEnd->format('Y-m-d H:i:s') || (string) ($row['end'] ?? '') <= $day->format('Y-m-d H:i:s')) {
                continue;
            }
            $status = (string) ($row['status'] ?? 'submitted');
            $label = '#' . (int) $row['id'] . ' ' . (BookingView::statuses()[$status] ?? $status);
            echo '<a class="rp-month-event" href="' . BookingView::e(BookingView::url('booking.php', ['id' => (int) $row['id']])) . '" title="' . BookingView::e(BookingView::date($row['begin'] ?? '') . ' - ' . BookingView::date($row['end'] ?? '')) . '">' . BookingView::e($label) . '</a>';
        }
        echo '</div>';
    }
    echo '</div>';
    BookingView::pagination('workflow.calendar.php', ['month' => $monthText], $page, $more);
    echo '</section><section class="rp-panel"><h2>' . BookingView::e(__('Lista do período', 'reservaplus')) . '</h2>';
    BookingView::renderList($rows);
    echo '</section>';
} catch (Throwable $error) {
    if (!$opened) {
        http_response_code(403);
        BookingView::header(__('Agenda de reservas', 'reservaplus'));
    }
    BookingView::notice(BookingView::publicError($error), true);
}
BookingView::footer();
