<?php

declare(strict_types=1);

use GlpiPlugin\Reservaplus\Access;
use GlpiPlugin\Reservaplus\BookingService;
use GlpiPlugin\Reservaplus\BookingView;
use GlpiPlugin\Reservaplus\ResourceService;

include_once (defined('GLPI_ROOT') ? GLPI_ROOT . '/inc/includes.php' : __DIR__ . '/../../../inc/includes.php');

$opened = false;
try {
    BookingView::requireReady();
    Access::assertRight('request');
    $kind = is_string($_GET['kind'] ?? null) ? $_GET['kind'] : '';
    if (!in_array($kind, ['', 'room', 'equipment', 'other'], true)) {
        throw new DomainException(__('Tipo de recurso inválido.', 'reservaplus'));
    }
    $query = ['kind' => $kind, 'q' => mb_substr(trim(BookingView::text($_GET['q'] ?? '')), 0, 200)];
    $page = max(1, min(100000, (int) ($_GET['page'] ?? 1)));
    $resourceId = max(0, (int) ($_GET['resources_id'] ?? 0));
    $ticketId = max(0, (int) ($_GET['tickets_id'] ?? 0));
    if ($ticketId > 0) {
        $ticket = new Ticket();
        if (!$ticket->can($ticketId, UPDATE) || !$ticket->getFromDB($ticketId) || !Access::entity((int) ($ticket->fields['entities_id'] ?? -1))) {
            throw new DomainException(__('Você não pode converter este chamado em uma reserva.', 'reservaplus'));
        }
        $query['tickets_id'] = $ticketId;
    }
    $defaults = $_SESSION['reservaplus_booking_form'] ?? [];
    unset($_SESSION['reservaplus_booking_form']);
    if (!is_array($defaults)) {
        $defaults = [];
    }
    $begin = BookingView::text($_GET['begin'] ?? $defaults['begin'] ?? '');
    $end = BookingView::text($_GET['end'] ?? $defaults['end'] ?? '');
    $query['begin'] = $begin;
    $query['end'] = $end;
    $selected = array_map('intval', is_array($defaults['resources_ids'] ?? null) ? $defaults['resources_ids'] : []);
    if ($resourceId > 0 && $selected === []) {
        $selected = [$resourceId];
        $query['resources_id'] = $resourceId;
    }
    $filters = ['publication' => 'published', 'q' => $query['q']];
    if ($kind !== '') {
        $filters['kind'] = $kind;
    }
    if ($resourceId > 0) {
        $filters['resources_id'] = $resourceId;
    }
    $rows = ResourceService::search($filters, 13, ($page - 1) * 12);
    $more = count($rows) > 12;
    $rows = array_slice($rows, 0, 12);
    BookingView::header(__('Solicitar reserva', 'reservaplus'));
    $opened = true;
    echo '<section class="rp-panel"><h2>' . BookingView::e(__('1. Encontre os recursos', 'reservaplus')) . '</h2><form method="get" action="' . BookingView::e(BookingView::url('booking.form.php')) . '"><div class="rp-grid">';
    BookingView::select('kind', __('Tipo', 'reservaplus'), ['' => __('Todos', 'reservaplus'), 'room' => __('Salas', 'reservaplus'), 'equipment' => __('Equipamentos', 'reservaplus'), 'other' => __('Outros recursos', 'reservaplus')], $kind);
    BookingView::input('q', __('Nome ou referência', 'reservaplus'), $query['q'], 'search', false, 'maxlength="200"');
    BookingView::input('begin', __('Consultar a partir de', 'reservaplus'), BookingView::datetimeInput($begin), 'datetime-local');
    BookingView::input('end', __('Consultar até', 'reservaplus'), BookingView::datetimeInput($end), 'datetime-local');
    echo '</div>';
    if ($ticketId > 0) {
        BookingView::hidden('tickets_id', $ticketId);
    }
    BookingView::submit(__('Buscar e consultar horários', 'reservaplus'));
    echo '</form>';
    BookingView::timezoneNote();
    BookingView::pagination('booking.form.php', $query, $page, $more);
    echo '</section>';
    if ($rows === []) {
        echo '<section class="rp-panel rp-empty">' . BookingView::e(__('Nenhum recurso disponível para seu perfil neste filtro. Altere a busca ou procure a equipe responsável.', 'reservaplus')) . '</section>';
    } else {
        BookingView::formStart('submit');
        BookingView::hidden('_return_kind', $kind);
        BookingView::hidden('_return_q', $query['q']);
        BookingView::hidden('_return_page', $page);
        BookingView::hidden('_return_resource', $resourceId);
        if ($ticketId > 0) {
            BookingView::hidden('tickets_id', $ticketId);
            BookingView::notice(sprintf(__('Esta solicitação utilizará o chamado #%d já existente.', 'reservaplus'), $ticketId));
        }
        echo '<section class="rp-panel"><div class="rp-grid">';
        foreach ($rows as $resource) {
            echo '<div>';
            BookingView::renderResource($resource, in_array((int) $resource['id'], $selected, true));
            if ($begin !== '' && $end !== '') {
                try {
                    $availability = BookingService::availability((int) $resource['id'], $begin, $end);
                    echo '<p class="rp-muted">' . BookingView::e(!empty($availability['available']) ? __('Horário disponível na consulta. A confirmação depende da validação da solicitação.', 'reservaplus') : __('Indisponível no período consultado. Escolha outro horário ou recurso.', 'reservaplus')) . '</p>';
                } catch (Throwable $error) {
                    echo '<p class="rp-muted">' . BookingView::e(__('Não foi possível consultar este período. Confira as datas antes de enviar.', 'reservaplus')) . '</p>';
                }
            }
            echo '</div>';
        }
        echo '</div><p class="rp-muted">' . BookingView::e(__('Selecione os recursos desta página que deseja solicitar juntos. Nenhuma reserva é criada durante a consulta.', 'reservaplus')) . '</p></section>';
        echo '<section class="rp-panel"><h2>' . BookingView::e(__('2. Informe o uso e o período', 'reservaplus')) . '</h2><div class="rp-grid">';
        BookingView::input('begin', __('Início / retirada', 'reservaplus'), BookingView::datetimeInput($begin), 'datetime-local', true);
        BookingView::input('end', __('Término / devolução', 'reservaplus'), BookingView::datetimeInput($end), 'datetime-local', true);
        BookingView::input('people_count', __('Número de participantes', 'reservaplus'), max(1, (int) ($defaults['people_count'] ?? 1)), 'number', true, 'min="1" max="100000" step="1"');
        if (Access::right('on_behalf')) {
            echo '<div class="rp-field"><label>' . BookingView::e(__('Usuário responsável pelo uso', 'reservaplus')) . '</label>';
            User::dropdown(['name' => 'users_id_borrower', 'value' => (int) ($defaults['users_id_borrower'] ?? Access::userId()), 'entity' => Access::entityIds(), 'right' => 'all', 'width' => '100%']);
            echo '</div>';
        } else {
            BookingView::hidden('users_id_borrower', Access::userId());
        }
        BookingView::input('matricula', __('Matrícula utilizada nesta solicitação', 'reservaplus'), $defaults['matricula'] ?? '', 'text', false, 'maxlength="100"');
        BookingView::input('unit', __('Unidade / setor do usuário', 'reservaplus'), $defaults['unit'] ?? '', 'text', false, 'maxlength="255"');
        echo '</div>';
        BookingView::textarea('purpose', __('Finalidade e informações necessárias', 'reservaplus'), BookingView::text($defaults['purpose'] ?? ''), true);
        echo '<p class="rp-muted">' . BookingView::e(__('A matrícula e a unidade informadas serão conferidas pela equipe. O usuário responsável pelo uso deverá assinar seus próprios termos, quando exigidos.', 'reservaplus')) . '</p>';
        BookingView::timezoneNote();
        echo '</section><section class="rp-panel"><h2>' . BookingView::e(__('3. Envie e acompanhe', 'reservaplus')) . '</h2><p>' . BookingView::e(__('A solicitação terá um chamado vinculado. Acompanhe a aprovação, os termos, a retirada e a devolução na mesma página. A consulta de disponibilidade não garante a reserva antes da confirmação.', 'reservaplus')) . '</p>';
        BookingView::submit(__('Enviar solicitação', 'reservaplus'));
        echo '</section>';
        Html::closeForm();
    }
} catch (Throwable $error) {
    if (!$opened) {
        http_response_code(403);
        BookingView::header(__('Solicitar reserva', 'reservaplus'));
    }
    BookingView::notice(BookingView::publicError($error), true);
}
BookingView::footer();
