<?php

declare(strict_types=1);

use GlpiPlugin\Reservaplus\Access;
use GlpiPlugin\Reservaplus\BookingView;
use GlpiPlugin\Reservaplus\Dashboard;
use GlpiPlugin\Reservaplus\Resource;
use GlpiPlugin\Reservaplus\ResourceService;
use GlpiPlugin\Reservaplus\Schema;
use GlpiPlugin\Reservaplus\Sector;
use GlpiPlugin\Reservaplus\Store;

include_once (defined('GLPI_ROOT') ? GLPI_ROOT . '/inc/includes.php' : __DIR__ . '/../../../inc/includes.php');
Session::checkLoginUser();
Access::assertRight('read');
$e=static fn(mixed $v): string=>htmlspecialchars((string)$v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
$base=($CFG_GLPI['root_doc'] ?? '').'/plugins/reservaplus/front/';
$id=(int)($_POST['id'] ?? $_GET['id'] ?? 0);
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    // GLPI's CheckCsrfListener validates/consumes the native form token before this controller.
    try {
        $action=(string)($_POST['action'] ?? '');
        if ($action==='save') {
            $input=$_POST;
            $input['policy_json']=[
                'approval_required'=>isset($_POST['approval_required']),
                'signature_stage'=>(string)($_POST['signature_stage'] ?? 'approval'),
                'return_signature_required'=>isset($_POST['return_signature_required']),
                'requester_groups_ids'=>(array)($_POST['requester_groups_ids'] ?? []),
                'max_duration_minutes'=>$_POST['max_duration_minutes'] ?? 43200,
                'buffer_before_minutes'=>$_POST['buffer_before_minutes'] ?? 0,
                'buffer_after_minutes'=>$_POST['buffer_after_minutes'] ?? 0,
            ];
            // Parse user-facing one-accessory-per-line format, never executable content.
            $parts=[];
            foreach (preg_split('/\R/u',(string)($_POST['accessories_text'] ?? '')) ?: [] as $line) {
                if (trim($line)==='') { continue; }
                $pair=explode('|',$line,2);
                $parts[]=['name'=>trim($pair[0]),'quantity'=>trim($pair[1] ?? '1')];
            }
            $input['accessories_json']=$parts;
            $id=ResourceService::save($input,$id);
        } elseif ($action==='link') {
            ResourceService::linkNative($id,(string)($_POST['native_itemtype'] ?? ''),(int)($_POST['native_items_id'] ?? 0));
        } elseif ($action==='export') {
            if (($_POST['confirm_export'] ?? '')!=='yes') { throw new DomainException(__('Confirme a criação explícita do ativo.','reservaplus')); }
            ResourceService::exportNative($id,(string)($_POST['export_itemtype'] ?? ''));
        } else { throw new DomainException(__('Ação inválida.','reservaplus')); }
        Session::addMessageAfterRedirect(__('Recurso atualizado.','reservaplus'));
        Html::redirect($base.'resource.form.php?id='.$id);
        return;
    } catch (Throwable $ex) { $error=BookingView::publicError($ex); }
}
Dashboard::renderHeader(__('Recurso','reservaplus'));
Dashboard::includeAssets(false);
echo '<div class="container-fluid"><div class="d-flex justify-content-between mb-3"><h1>'.__('Recurso','reservaplus').'</h1><a class="btn btn-outline-secondary" href="'.$e($base.'resource.php').'">'.__('Recursos','reservaplus').'</a></div>';
if (!Schema::ready()) { echo '<div class="alert alert-warning">'.__('Atualize a instalação do plugin.','reservaplus').'</div></div>'; Dashboard::renderFooter(); return; }
if ($error!=='') { echo '<div class="alert alert-danger" role="alert">'.$e($error).'</div>'; }
try {
    $row=$id>0?Resource::getRow($id):[];
    $entity=(int)($row['entities_id'] ?? $_POST['entities_id'] ?? $_GET['entities_id'] ?? $_SESSION['glpiactive_entity'] ?? 0);
    if (!Access::entity($entity)) { throw new DomainException(__('Entidade indisponível.','reservaplus')); }
    if ($id<1) { Access::assertRight('manage'); }
} catch (Throwable $ex) {
    http_response_code(403); echo '<div class="alert alert-danger">'.$e(BookingView::publicError($ex)).'</div></div>'; Dashboard::renderFooter(); return;
}
$editable=$id===0 || Access::resource($row,'manage');
$display=$row?ResourceService::decorate($row):[];
if ($row) {
    echo '<section class="card card-body mb-3"><h2>'.$e($row['name']).'</h2><p>'.$e(implode(' / ',array_filter([$display['_location_name'],$row['building'],$row['floor'],$row['room_number']]))).'</p><p>'.__('Setor responsável','reservaplus').': '.$e($display['_sector_name']).' &middot; '.__('Responsável pela guarda','reservaplus').': '.$e($display['_custodian_name']).'</p><p>'.__('Grupo dos chamados','reservaplus').': '.$e($display['_ticket_group_name']).'</p><p>'.$e($row['directions']).'</p><p>'.$e($row['features']).'</p><small>'.$e($display['_calendar_label']).'</small>';
    if ($row['capacity']!==null) { echo '<p>'.sprintf(__('Capacidade: %d pessoas','reservaplus'),(int)$row['capacity']).($row['area_m2']!==null?' &middot; '.$e($row['area_m2']).' m²':'').'</p>'; }
    if ((int)$row['locations_id']>0) {
        $loc=new Location();
        if ($loc->can((int)$row['locations_id'],READ)) { echo '<p><a class="btn btn-outline-secondary" href="'.$e(Location::getFormURLWithID((int)$row['locations_id'])).'">'.__('Localização / mapa GLPI','reservaplus').'</a></p>'; }
    }
    if (Access::resource($row,'request')) { echo '<p><a class="btn btn-primary" href="'.$e($base.'booking.form.php?resources_id='.(int)$row['id']).'">'.__('Solicitar reserva','reservaplus').'</a></p>'; }
    echo '</section>';
}
if (!$editable) { echo '</div>'; Dashboard::renderFooter(); return; }
$policy=ResourceService::policy($row);
$value=static fn(string $key,mixed $default='')=>$row[$key] ?? $default;
$textInput=static function(string $name,string $label,mixed $current,string $type='text',string $extra='') use ($e): void {
    echo '<div class="col-md-4"><label class="form-label" for="rp-'.$e($name).'">'.$e(__($label,'reservaplus')).'</label><input id="rp-'.$e($name).'" class="form-control" type="'.$e($type).'" name="'.$e($name).'" value="'.$e($current).'" '.$extra.'></div>';
};
$select=static function(string $name,string $label,array $options,mixed $current) use ($e): void {
    echo '<div class="col-md-4"><label class="form-label" for="rp-'.$e($name).'">'.$e(__($label,'reservaplus')).'</label><select id="rp-'.$e($name).'" class="form-select" name="'.$e($name).'">';
    foreach ($options as $k=>$v) { echo '<option value="'.$e($k).'"'.((string)$current===(string)$k?' selected':'').'>'.$e(__($v,'reservaplus')).'</option>'; }
    echo '</select></div>';
};
echo '<form method="post" action="'.$e($base.'resource.form.php').'" class="card card-body mb-3"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="'.$id.'"><input type="hidden" name="expected_revision" value="'.(int)($row['config_revision'] ?? 0).'"><input type="hidden" name="entities_id" value="'.$entity.'"><h2>'.__('Cadastro e responsabilidade','reservaplus').'</h2><p>'.__('O cadastro é interno ao plugin. Publicar não cria um ativo no inventário.','reservaplus').'</p><div class="row g-3">';
$textInput('name','Nome',$value('name'),'text','required maxlength="255"');
$select('kind','Tipo',['equipment'=>'Equipamento','room'=>'Sala','other'=>'Outro recurso'],$value('kind','equipment'));
$select('publication','Publicação',['draft'=>'Rascunho','published'=>'Publicado','unavailable'=>'Indisponível','retired'=>'Retirado de uso'],$value('publication','draft'));
$sectorOptions=[0=>'Selecione']; foreach (Sector::search($entity) as $sector) { $sectorOptions[(int)$sector['id']]=$sector['name']; }
$select('sectors_id','Setor responsável',$sectorOptions,$value('sectors_id',0));
foreach (['groups_id_ticket'=>'Grupo responsável pelos chamados','groups_id_manage'=>'Grupo gestor / operação','groups_id_approve'=>'Grupo autorizado a aprovar'] as $name=>$label) {
    echo '<div class="col-md-4"><label class="form-label">'.$e(__($label,'reservaplus')).'</label>';
    $options=['name'=>$name,'value'=>(int)$value($name,0),'entity'=>$entity,'width'=>'100%'];
    if ($name==='groups_id_ticket') { $options['condition']=['is_assign'=>1]; }
    if ($name==='groups_id_manage' && !Access::right('admin')) { $options['condition']=['id'=>Access::groups() ?: [-1]]; }
    Group::dropdown($options); echo '</div>';
}
foreach (['custodian_users_id'=>'Responsável pela guarda','default_assignee_users_id'=>'Técnico padrão (vazio: responsável pela guarda)'] as $name=>$label) {
    echo '<div class="col-md-6"><label class="form-label">'.$e(__($label,'reservaplus')).'</label>';
    User::dropdown(['name'=>$name,'value'=>(int)$value($name,0),'entity'=>$entity,'right'=>'all','width'=>'100%']); echo '</div>';
}
echo '</div><h2 class="mt-4">'.__('Identificação e localização','reservaplus').'</h2><div class="row g-3">';
foreach (['inventory_number'=>'Patrimônio / código interno','serial'=>'Número de série','manufacturer'=>'Fabricante','model'=>'Modelo','building'=>'Prédio / bloco','wing'=>'Ala','floor'=>'Andar','room_number'=>'Número da sala'] as $key=>$label) { $textInput($key,$label,$value($key)); }
echo '<div class="col-md-4"><label class="form-label">'.__('Localização GLPI (opcional)','reservaplus').'</label>'; Location::dropdown(['name'=>'locations_id','value'=>(int)$value('locations_id',0),'entity'=>$entity,'width'=>'100%']); echo '</div>';
$textInput('capacity','Capacidade máxima (pessoas)',$value('capacity'),'number','min="1" max="1000000" step="1"');
$textInput('area_m2','Área (m²)',$value('area_m2'),'number','min="0.01" step="0.01"');
$textInput('latitude','Latitude (opcional)',$value('latitude'),'number','min="-90" max="90" step="0.0000001"');
$textInput('longitude','Longitude (opcional)',$value('longitude'),'number','min="-180" max="180" step="0.0000001"');
$select('operational_state','Condição operacional',['available'=>'Disponível','inspection'=>'Em conferência','quarantine'=>'Quarentena','maintenance'=>'Manutenção'],$value('operational_state','available'));
$textInput('operational_reason','Motivo da alteração operacional (quando houver)','','text','maxlength="4000"');
echo '</div><div class="row g-3 mt-1">';
foreach (['address'=>'Endereço / campus','directions'=>'Como chegar / acessibilidade / retirada de chaves','features'=>'Instalações e recursos','comment'=>'Observações visíveis aos usuários autorizados'] as $key=>$label) {
    echo '<div class="col-md-6"><label for="rp-'.$e($key).'" class="form-label">'.$e(__($label,'reservaplus')).'</label><textarea class="form-control" id="rp-'.$e($key).'" name="'.$e($key).'" rows="3">'.$e($value($key)).'</textarea></div>';
}
$parts=ResourceService::normalizeAccessories($row['accessories_json'] ?? []);
$accessoryText=implode("\n",array_map(static fn(array $p):string=>$p['name'].' | '.$p['quantity'],$parts));
echo '<div class="col-md-12"><label class="form-label" for="rp-accessories">'.__('Acessórios: um por linha, nome | quantidade','reservaplus').'</label><textarea id="rp-accessories" class="form-control" name="accessories_text" rows="3">'.$e($accessoryText).'</textarea></div></div><h2 class="mt-4">'.__('Reserva, aprovação e documentos','reservaplus').'</h2><div class="row g-3">';
$select('signature_stage','Aceite do termo',['submission'=>'Após enviar a solicitação','approval'=>'Após aprovação','handover'=>'Na retirada','none'=>'Não exigir aceite antecipado'],$policy['signature_stage']);
echo '<div class="col-md-8 align-self-end"><small class="form-text">'.__('Somente administradores podem dispensar aprovação/assinaturas ou adiar a etapa de assinatura. O grupo gestor pode reforçar as exigências.','reservaplus').'</small></div>';
$textInput('max_duration_minutes','Duração máxima (minutos)',$policy['max_duration_minutes'],'number','min="1" max="525600"');
$textInput('buffer_before_minutes','Preparação antes (minutos)',$policy['buffer_before_minutes'],'number','min="0" max="525600"');
$textInput('buffer_after_minutes','Preparação depois (minutos)',$policy['buffer_after_minutes'],'number','min="0" max="525600"');
echo '<div class="col-md-8"><label class="form-label">'.__('Grupos que podem solicitar (vazio: todos na entidade)','reservaplus').'</label>';
Group::dropdown(['name'=>'requester_groups_ids','values'=>$policy['requester_groups_ids'],'multiple'=>true,'entity'=>$entity,'width'=>'100%']);
echo '<small class="form-text">'.__('Recursos internos restritos a grupos usam apenas o calendário protegido do ReservaPlus nesta versão.','reservaplus').'</small></div>';
foreach (['approval_required'=>'Exigir aprovação pelo grupo configurado','return_signature_required'=>'Exigir reconhecimento do relatório de devolução'] as $key=>$label) {
    echo '<div class="col-md-6"><label class="form-check"><input class="form-check-input" type="checkbox" name="'.$e($key).'" value="1"'.($policy[$key]?' checked':'').'><span class="form-check-label">'.$e(__($label,'reservaplus')).'</span></label></div>';
}
echo '</div><p class="mt-3">'.__('Responsável pela guarda, técnico do chamado e aprovadores são papéis independentes. Não inclua senhas ou códigos de acesso nas informações visíveis.','reservaplus').'</p><div><button type="submit" class="btn btn-primary">'.__('Salvar recurso','reservaplus').'</button></div>';
Html::closeForm();
if ($id>0) {
    echo '<section class="card card-body mb-3"><h2>'.__('Vínculo com inventário (opcional)','reservaplus').'</h2>';
    if (!empty($row['native_items_id'])) {
        echo '<p>'.$e($row['native_itemtype']).' #'.(int)$row['native_items_id'].'</p><p>'.__('O vínculo não altera automaticamente nomes, responsáveis ou políticas. O ativo mantém sua visibilidade nativa.','reservaplus').'</p>';
    } else {
        echo '<p>'.__('Vincule ou exporte antes da primeira reserva. Um recurso com histórico exige migração assistida para mudar sua identidade de calendário. Série, patrimônio, fabricante e modelo vazios serão preenchidos a partir do ativo quando disponíveis. Valores já informados serão preservados.','reservaplus').'</p><form method="post" action="'.$e($base.'resource.form.php').'"><input type="hidden" name="action" value="link"><input type="hidden" name="id" value="'.$id.'"><div class="row g-3">';
        $select('native_itemtype','Tipo de ativo existente',ResourceService::nativeTypes(),'');
        $textInput('native_items_id','ID do ativo existente','','number','required min="1"');
        echo '<div class="col-md-4 align-self-end"><button class="btn btn-outline-primary" type="submit">'.__('Vincular ativo existente','reservaplus').'</button></div></div>';
        Html::closeForm();
        if ($row['kind']!=='room') {
            echo '<hr><form method="post" action="'.$e($base.'resource.form.php').'"><input type="hidden" name="action" value="export"><input type="hidden" name="id" value="'.$id.'"><div class="row g-3">';
            $select('export_itemtype','Criar novo ativo GLPI',['Computer'=>'Computador','Peripheral'=>'Periférico','Monitor'=>'Monitor','Printer'=>'Impressora','Phone'=>'Telefone'],'Peripheral');
            echo '</div><p>'.__('Serão copiados nome, entidade, série, patrimônio e localização acima. Os demais campos e responsabilidades continuam independentes.','reservaplus').'</p><label class="form-check"><input class="form-check-input" type="checkbox" name="confirm_export" value="yes" required><span class="form-check-label">'.__('Quero criar um ativo no inventário GLPI com esses dados.','reservaplus').'</span></label><button class="btn btn-outline-primary mt-2" type="submit">'.__('Criar e vincular ativo','reservaplus').'</button>';
            Html::closeForm();
        }
    }
    echo '</section>';
}
echo '</div>'; Dashboard::renderFooter();
