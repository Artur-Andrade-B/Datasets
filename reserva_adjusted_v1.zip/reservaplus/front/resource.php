<?php

declare(strict_types=1);

use GlpiPlugin\Reservaplus\Access;
use GlpiPlugin\Reservaplus\Dashboard;
use GlpiPlugin\Reservaplus\Resource;
use GlpiPlugin\Reservaplus\ResourceService;
use GlpiPlugin\Reservaplus\Schema;

include_once (defined('GLPI_ROOT') ? GLPI_ROOT . '/inc/includes.php' : __DIR__ . '/../../../inc/includes.php');
Session::checkLoginUser();
Access::assertRight('read');
$e=static fn(mixed $v): string=>htmlspecialchars((string)$v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
$base=($CFG_GLPI['root_doc'] ?? '').'/plugins/reservaplus/front/';
Dashboard::renderHeader(__('Recursos','reservaplus'));
Dashboard::includeAssets(false);
echo '<div class="container-fluid"><div class="d-flex justify-content-between mb-3"><h1>'.__('Recursos','reservaplus').'</h1><div>';
if (Access::right('manage')) { echo '<a class="btn btn-primary me-2" href="'.$e($base.'resource.form.php').'">'.__('Cadastrar recurso','reservaplus').'</a>'; }
if (Access::right('admin')) { echo '<a class="btn btn-outline-secondary" href="'.$e($base.'sector.php').'">'.__('Setores','reservaplus').'</a>'; }
echo '</div></div>';
if (!Schema::ready()) {
    echo '<div class="alert alert-warning">'.__('Atualize a instalação do plugin antes de utilizar o novo fluxo.','reservaplus').'</div></div>';
    Dashboard::renderFooter(); return;
}
$filters=['q'=>trim((string)($_GET['q'] ?? '')),'kind'=>(string)($_GET['kind'] ?? '')];
$page=max(0,(int)($_GET['page'] ?? 0));
echo '<form method="get" class="card card-body mb-3"><div class="row g-2"><div class="col-md-7"><label for="rp-q" class="form-label">'.__('Buscar nome, patrimônio, sala ou prédio','reservaplus').'</label><input id="rp-q" class="form-control" name="q" value="'.$e($filters['q']).'"></div><div class="col-md-3"><label for="rp-kind" class="form-label">'.__('Tipo','reservaplus').'</label><select id="rp-kind" name="kind" class="form-select">';
foreach ([''=>'Todos','room'=>'Sala','equipment'=>'Equipamento','other'=>'Outro recurso'] as $value=>$label) {
    echo '<option value="'.$e($value).'"'.($filters['kind']===$value?' selected':'').'>'.$e(__($label,'reservaplus')).'</option>';
}
echo '</select></div><div class="col-md-2 align-self-end"><button class="btn btn-primary" type="submit">'.__('Pesquisar','reservaplus').'</button></div></div></form>';
$rows=ResourceService::search($filters,51,$page*50);
$more=count($rows)>50; $rows=array_slice($rows,0,50);
echo '<div class="card"><div class="table-responsive"><table class="table table-striped"><thead><tr><th>'.__('Recurso','reservaplus').'</th><th>'.__('Localização','reservaplus').'</th><th>'.__('Responsabilidade','reservaplus').'</th><th>'.__('Disponibilização','reservaplus').'</th></tr></thead><tbody>';
foreach ($rows as $row) {
    $locator=implode(' / ',array_filter([$row['_location_name'],$row['building'],$row['floor'],$row['room_number']]));
    echo '<tr><td><a href="'.$e($base.'resource.form.php?id='.(int)$row['id']).'">'.$e($row['name']).'</a><br><small>'.$e($row['inventory_number'] ?: ('#'.$row['id'])).'</small></td><td>'.$e($locator).($row['capacity']!==null?'<br><small>'.sprintf(__('Capacidade: %d','reservaplus'),(int)$row['capacity']).'</small>':'').'</td><td>'.$e($row['_sector_name']).'<br><small>'.$e($row['_custodian_name']).' / '.$e($row['_ticket_group_name']).'</small></td><td>'.$e($row['publication']).'<br><small>'.$e($row['_calendar_label']).'</small></td></tr>';
}
if (!$rows) { echo '<tr><td colspan="4">'.__('Nenhum recurso disponível para este filtro e suas permissões.','reservaplus').'</td></tr>'; }
echo '</tbody></table></div></div><nav class="d-flex justify-content-between my-3">';
if ($page>0) { echo '<a class="btn btn-outline-secondary" href="'.$e($base.'resource.php?'.http_build_query($filters+['page'=>$page-1])).'">'.__('Anterior','reservaplus').'</a>'; }
if ($more) { echo '<a class="btn btn-outline-secondary" href="'.$e($base.'resource.php?'.http_build_query($filters+['page'=>$page+1])).'">'.__('Próxima','reservaplus').'</a>'; }
echo '</nav></div>';
Dashboard::renderFooter();
