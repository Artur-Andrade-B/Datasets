# Changes

## 0.7.0-rc1

- Add plugin-owned resource/sector registries and separate custody, assignment, approval and organizational responsibilities.
- Add ticket-backed reservation aggregates, native group validation, service catalog offerings, scoped calendar, inventory linking and explicit equipment export.
- Add transactional allocation, optimistic revision checks, idempotent commands, native mutation guards and durable post-commit ticket integration.
- Add issue, receipt, counted accessory reconciliation, inspection, quarantine/maintenance, reinspection and documented completion.
- Add internal electronic acceptance, immutable version snapshots, original/final PDF hashes, protected evidence, integrity verification and native final-document attachments.
- Preserve legacy data and existing profile grants/denials on upgrade. Replace profile-name-based automatic grants with explicit configuration.
- Harden legacy item/entity scope, calendar privacy, independent cancellation/deletion permissions, target-user selectors and native write failure handling. Remove direct native-table write fallbacks.
- Register unsigned-hold expiry and integration retry automatic actions.
- Add standalone tests, guarded real-GLPI integration tests and release/setup documentation.
- Raise supported minimum to GLPI 11.0.7 for the verified integration surface. New workflow text is primarily Portuguese.

This candidate does not implement every longer-term item in the preceding project assessment. The README lists explicit release boundaries. No production deployment was performed.
