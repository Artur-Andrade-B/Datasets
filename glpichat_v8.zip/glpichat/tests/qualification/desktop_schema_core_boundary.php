<?php

declare(strict_types=1);

/**
 * Integration contract fixture, not a database integration test.
 *
 * Uses unmodified GLPI DBmysql::query() from an explicit local core source path.
 * Replaces only the connection/SQL-result boundary with an in-memory fixture.
 * No core constructor, database connection, SQL execution, or GLPI session runs.
 *
 * Usage: php desktop_schema_core_boundary.php SCHEMA_PATH legacy|fixed CORE_DBMYSQL_PATH
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
if ($argc !== 4 || !in_array($argv[2], ['legacy', 'fixed'], true)
    || !is_file($argv[1]) || !is_readable($argv[1])
    || !is_file($argv[3]) || !is_readable($argv[3])) {
    fwrite(STDERR, "Usage: desktop_schema_core_boundary.php SCHEMA_PATH legacy|fixed CORE_DBMYSQL_PATH\n");
    exit(2);
}
require $argv[3];
require $argv[1];

$assertions = 0;
function boundary_assert(bool $condition, string $message): void
{
    global $assertions;
    ++$assertions;
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

final class DesktopSchemaCoreBoundary extends DBmysql
{
    public array $present = ['glpi_plugin_glpichat_messages' => true];
    public bool $followupIndex = false;
    public array $ddl = [];
    public array $reads = [];
    public bool $rejectMetadata = false;

    public function __construct()
    {
        // Intentionally do not call parent: this test must never connect.
    }

    // The forbidden query() method is inherited unchanged from real GLPI.
    public function tableExists($tablename, $usecache = true)
    {
        return isset($this->present[$tablename]);
    }

    public function doQuery($query)
    {
        if (preg_match('/\ACREATE TABLE `([^`]+)`/', $query, $match) === 1) {
            boundary_assert(array_key_exists($match[1], glpichat_desktop_schema_definitions()), 'Unknown table in CREATE.');
            boundary_assert(!isset($this->present[$match[1]]), 'Attempted to recreate an existing table.');
            $this->ddl[] = $query;
            $this->present[$match[1]] = true;
            return true;
        }
        if ($query === 'ALTER TABLE `glpi_plugin_glpichat_messages` ADD KEY `desktop_followup_id` (`itilfollowups_id`)') {
            boundary_assert(!$this->followupIndex, 'Attempted to recreate an existing supporting index.');
            $this->ddl[] = $query;
            $this->followupIndex = true;
            return true;
        }
        boundary_assert(str_starts_with($query, 'SELECT '), 'Unexpected mutating SQL.');
        boundary_assert(str_contains($query, 'TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('), 'Metadata query must remain database/table bounded.');
        $kind = null;
        foreach (['TABLES' => 'tables', 'COLUMNS' => 'columns', 'STATISTICS' => 'indexes'] as $source => $destination) {
            if (str_contains($query, 'FROM information_schema.' . $source . ' WHERE ')) {
                $kind = $destination;
            }
        }
        boundary_assert($kind !== null, 'Unexpected metadata source.');
        $this->reads[] = $query;
        if ($this->rejectMetadata) {
            throw new RuntimeException('fixture metadata failure');
        }
        return (object) ['rows' => $this->metadata()[$kind], 'position' => 0];
    }

    public function fetchAssoc($result)
    {
        return $result->rows[$result->position++] ?? false;
    }

    private function metadata(): array
    {
        // Shapes are declared fixture rows; no SQL engine is being emulated.
        $result = ['tables' => [], 'columns' => [], 'indexes' => []];
        $definitions = glpichat_desktop_schema_definitions();
        $definitions['glpi_plugin_glpichat_messages'] = [
            'columns' => [],
            'indexes' => $this->followupIndex ? ['desktop_followup_id' => ['columns' => ['itilfollowups_id'], 'unique' => false]] : [],
        ];
        foreach ($definitions as $table => $definition) {
            if (!isset($this->present[$table])) {
                continue;
            }
            $result['tables'][] = ['TABLE_NAME' => $table, 'ENGINE' => 'InnoDB'];
            foreach ($definition['columns'] as $name => $column) {
                $result['columns'][] = [
                    'TABLE_NAME' => $table,
                    'COLUMN_NAME' => $name,
                    'COLUMN_TYPE' => str_replace(' ascii_bin', '', $column['type']),
                    'COLUMN_DEFAULT' => str_starts_with($column['extra'], 'DEFAULT ') ? substr($column['extra'], 8) : null,
                    'IS_NULLABLE' => $column['nullable'] ? 'YES' : 'NO',
                    'COLLATION_NAME' => str_contains($column['type'], 'ascii_bin') ? 'ascii_bin' : null,
                    'EXTRA' => $column['extra'] === 'AUTO_INCREMENT' ? 'auto_increment' : '',
                ];
            }
            foreach ($definition['indexes'] as $name => $index) {
                foreach ($index['columns'] as $position => $column) {
                    $result['indexes'][] = [
                        'TABLE_NAME' => $table, 'INDEX_NAME' => $name,
                        'NON_UNIQUE' => $index['unique'] ? 0 : 1,
                        'SEQ_IN_INDEX' => $position + 1, 'COLUMN_NAME' => $column, 'SUB_PART' => null,
                    ];
                }
            }
        }
        return $result;
    }
}

boundary_assert((new ReflectionMethod(DesktopSchemaCoreBoundary::class, 'query'))->getDeclaringClass()->getName() === DBmysql::class, 'The real core query guard must not be overridden.');
$config = [];
$writes = [];
$readConfig = static function (string $key) use (&$config): mixed { return $config[$key] ?? null; };
$writeConfig = static function (array $values) use (&$config, &$writes): void {
    $writes[] = $values;
    $config = array_replace($config, $values);
};
$DB = new DesktopSchemaCoreBoundary();

if ($argv[2] === 'legacy') {
    $caught = null;
    try {
        // Default table_exists, execute, and metadata_reader production callbacks.
        glpichat_desktop_schema_install(null, null, null, $readConfig, $writeConfig);
    } catch (Throwable $error) {
        $caught = $error;
    }
    boundary_assert($caught instanceof Exception && $caught->getMessage() === 'Executing direct queries is not allowed!', 'Legacy source must reproduce the exact real-core rejection.');
    boundary_assert(count($DB->ddl) === 3, 'Legacy failure occurs after recording three table creations.');
    boundary_assert($DB->reads === [], 'Legacy code must fail before supported metadata execution.');
    boundary_assert($writes === [], 'Legacy failure must occur before any configuration write.');
    echo "PASS legacy: supplied actual GLPI core query guard reproduced; $assertions assertions; no database connection or SQL execution.\n";
    exit(0);
}

$tables = glpichat_desktop_schema_tables();
foreach ([0, 1, 3] as $alreadyPresent) {
    $DB = new DesktopSchemaCoreBoundary();
    foreach (array_slice($tables, 0, $alreadyPresent) as $table) {
        $DB->present[$table] = true;
    }
    $existingKey = str_repeat('b', 64);
    $config = $alreadyPresent === 0 ? [] : ['desktop_enabled' => '1', 'desktop_idempotency_key' => $existingKey];
    $writes = [];
    glpichat_desktop_schema_install(null, null, null, $readConfig, $writeConfig);
    boundary_assert(count($DB->ddl) === 4 - $alreadyPresent, 'Install must create only absent tables and the absent index.');
    boundary_assert(count($DB->reads) === 6, 'Install and postconditions must use all six supported metadata queries.');
    boundary_assert(end($writes) === ['desktop_schema_version' => '1'], 'Schema marker must be the final configuration write.');
    boundary_assert(($config['desktop_schema_version'] ?? null) === '1', 'Successful readback must record completion.');
    boundary_assert(preg_match('/\A[a-f0-9]{64}\z/', (string) ($config['desktop_idempotency_key'] ?? '')) === 1, 'Fresh install must produce a valid HMAC key.');
    boundary_assert($config['desktop_enabled'] === ($alreadyPresent === 0 ? '0' : '1'), 'Existing opt-in must be preserved; a new install remains disabled.');
    if ($alreadyPresent > 0) {
        boundary_assert($config['desktop_idempotency_key'] === $existingKey, 'Partial retry must preserve the existing HMAC key.');
    }
    $ddlCount = count($DB->ddl);
    $key = $config['desktop_idempotency_key'];
    glpichat_desktop_schema_install(null, null, null, $readConfig, $writeConfig);
    boundary_assert(count($DB->ddl) === $ddlCount, 'A repeated successful install must issue no further DDL.');
    boundary_assert($config['desktop_idempotency_key'] === $key, 'A repeated successful install must preserve the HMAC key.');
    boundary_assert(glpichat_desktop_schema_health(true, null, $readConfig)['healthy'], 'The default runtime metadata reader must accept the complete fixture.');
}

$DB->rejectMetadata = true;
$writes = [];
unset($config['desktop_schema_version']);
$caught = null;
try {
    glpichat_desktop_schema_install(null, null, null, $readConfig, $writeConfig);
} catch (Throwable $error) {
    $caught = $error;
}
boundary_assert($caught instanceof RuntimeException && $caught->getMessage() === 'fixture metadata failure', 'Supported metadata failures must still stop installation.');
boundary_assert($writes === [] && !isset($config['desktop_schema_version']), 'Metadata failure cannot write completion or replace configuration.');
boundary_assert(glpichat_desktop_schema_health(true, null, $readConfig)['issues'] === ['schema_metadata:unavailable'], 'Runtime metadata failure must remain fail-closed and opaque.');
echo "PASS fixed: real-core guard retained; default metadata/install callbacks; new, partial, interrupted-after-three-tables, repeated, and metadata-failure cases; $assertions assertions; no database connection or SQL execution.\n";
