#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
export TZ=UTC

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
plugin_root="$(cd "$script_dir/../.." && pwd)"
output_arg="${1:-$(dirname "$plugin_root")/glpichat-1.1.1-desktop2.zip}"
output_dir="$(dirname "$output_arg")"
output_name="$(basename "$output_arg")"

if [[ ! -d "$output_dir" ]]; then
    printf '[FAIL] Output directory does not exist: %s\n' "$output_dir" >&2
    exit 1
fi
output_path="$(cd "$output_dir" && pwd)/$output_name"
if [[ "$output_path" == "$plugin_root" || "$output_path" == "$plugin_root/"* ]]; then
    printf '[FAIL] Output archive must be outside the plugin source tree.\n' >&2
    exit 1
fi

staging_dir="$(mktemp -d)"
cleanup() {
    rm -rf "$staging_dir"
}
trap cleanup EXIT

cp -a "$plugin_root" "$staging_dir/glpichat"
rm -rf \
    "$staging_dir/glpichat/.git" \
    "$staging_dir/glpichat/node_modules" \
    "$staging_dir/glpichat/coverage" \
    "$staging_dir/glpichat/tests/logs" \
    "$staging_dir/glpichat/tests/performance/logs"

find "$staging_dir/glpichat" -type d -exec chmod 0755 {} +
find "$staging_dir/glpichat" -type f -exec chmod 0644 {} +
find "$staging_dir/glpichat" -type f -name '*.sh' -exec chmod 0755 {} +

# ZIP stores timestamps at two-second resolution. A fixed even UTC timestamp,
# sorted entries and stripped extra fields make repeated builds byte-identical.
find "$staging_dir/glpichat" -exec touch -h -d '@1789948800' {} +

archive_tmp="$staging_dir/glpichat-1.1.1-desktop2.zip"
(
    cd "$staging_dir"
    find glpichat -print | LC_ALL=C sort | zip -X -q -9 "$archive_tmp" -@
)

entry_count="$(unzip -Z1 "$archive_tmp" | wc -l | tr -d ' ')"
if [[ "$entry_count" -le 1 ]]; then
    printf '[FAIL] Release archive is unexpectedly empty.\n' >&2
    exit 1
fi
if unzip -Z1 "$archive_tmp" | grep -Ev '^glpichat(/|$)' >/dev/null; then
    printf '[FAIL] Release archive contains an entry outside the glpichat/ root.\n' >&2
    exit 1
fi

mv -f "$archive_tmp" "$output_path"
sha256sum "$output_path"
