# Testes Automatizados do Plugin

Este diretório contém a suíte de testes do plugin organizada por camada de confiança.

## Estrutura Atual

```text
tests/
├── bootstrap/
│   └── unit.php                       # Bootstrap mínimo para testes PHP puros
├── unit/
│   ├── js/                            # Suítes Vitest e contratos de release
│   │   ├── channels_lifecycle_contract.test.js # Bootstrap/retry/estado visual perf3
│   │   ├── perf4_stale_layout_contract.test.js # Layout estável com aviso atrasado
│   │   ├── hydration_contract.test.js # Bloqueios/falhas da hidratação perf2
│   │   ├── release_bundle.test.js     # Bundle publicado reproduzível
│   │   ├── release_archive.test.js    # ZIP determinístico, root único e exclusões
│   │   ├── release_metadata.test.js   # Metadados 1.1.0-desktop1
│   │   └── ...                        # Estado, DOM, HTTP, scheduler, format/sanitize
│   └── php/                           # Contratos e testes unitários PHP
│       ├── diagnostics_privacy_test.php
│       ├── actor_context_test.php
│       ├── authorization_shadow_diagnostics_test.php
│       ├── authorization_shadow_test.php
│       ├── browser_actor_test.php
│       ├── foundation_authorization_wiring_test.php
│       ├── foundation_cli_contract_test.php
│       ├── foundation_compatibility_contract_test.php
│       ├── foundation_lifecycle_values_test.php
│       ├── foundation_schema_shape_contract_test.php
│       ├── perf2_hydration_contract_test.php
│       ├── perf3_channels_contract_test.php
│       ├── perf3_lifecycle_contract_test.php
│       ├── perf4_leave_session_contract_test.php
│       ├── public_ticket_authorization_test.php
│       ├── schema_health_test.php
│       └── ...                        # Acesso, guest, invites, eventos e readstate
├── smoke/
│   ├── http/                          # 2 testes de rotas/segurança HTTP
│   └── php/                           # 13 testes no runtime GLPI/banco real
├── lifecycle/
│   └── install_uninstall_test.php     # Instalação/update/uninstall no laboratório
├── e2e/
│   ├── python/                        # 3 fluxos browser/E2E
│   └── setup/                         # Preparação e teardown do ambiente
├── fixtures/
│   ├── blocked_upload.html
│   └── blocked_upload.php
├── helpers/
│   └── patch_animations.py
├── qualification/
│   ├── build_release.sh                # Empacotamento ZIP determinístico
│   ├── foundation_health.php           # Snapshot read-only da fundação
│   └── foundation_shadow.php           # CLI lab-only: status/enable/disable + read-back
├── performance/
│   ├── README.md
│   ├── k6/                            # 9 cenários de carga/soak
│   └── run_k6.sh
├── run_full_suite.sh
├── run_unit_php.sh
└── validate_tests.sh
```

## Pré-requisitos de Ambiente

Para rodar as camadas de integração (smoke-php, smoke-http, e2e, lifecycle) você precisa de uma instância do GLPI rodando com o plugin instalado e dois usuários configurados:

| Usuário | Senha | Perfil | Criado por |
|---------|-------|--------|------------|
| `glpi` | `glpi` | Super-Admin | GLPI (padrão de instalação) |
| `self` | `self` | Self-Service | **Você precisa criar manualmente** |

### Criando o usuário `self`

O GLPI não cria o usuário `self` automaticamente. Você precisa criá-lo antes de rodar a esteira:

**Via interface:**
1. Acesse **Administração > Usuários > Adicionar**
2. Login: `self`, Senha: `self`, Perfil padrão: `Self-Service`
3. Salve

**Via PHP CLI no container:**
```bash
docker exec glpi php - <<'PHP'
<?php
$loader = require '/var/www/glpi/vendor/autoload.php';
$kernel = new \Glpi\Kernel\Kernel();
$kernel->boot();

$profile_row = $GLOBALS['DB']->request([
    'SELECT' => ['id'], 'FROM' => 'glpi_profiles',
    'WHERE' => ['name' => 'Self-Service'], 'LIMIT' => 1,
])->current();
$profiles_id = is_array($profile_row) ? (int)$profile_row['id'] : 6;

$user = new User();
$id = (int) $user->add([
    'name' => 'self', 'password' => 'self', 'password2' => 'self',
    'is_active' => 1, 'profiles_id' => $profiles_id, '_profiles_id' => $profiles_id,
]);
echo $id > 0 ? "[PASS] self criado (id=$id)\n" : "[FAIL] nao foi possivel criar\n";
PHP
```

O usuário `self` representa o solicitante (requester) nos testes de integração e E2E. Sem ele, o `prepare_env.php` falhará ao tentar vincular um solicitante ao ticket dedicado da esteira.

---



1. **Unitário**
   - Cobre regras puras e determinísticas.
   - Não depende de banco, sessão ou kernel do GLPI.
   - Exemplos atuais: `tests/unit/php/domain_test.php`, `tests/unit/php/access_test.php`, `tests/unit/php/message_flow_test.php`, `tests/unit/php/guest_flow_test.php`, `tests/unit/php/guest_accept_test.php`, `tests/unit/php/invite_flow_test.php` e `tests/unit/php/invite_manage_flow_test.php`.
2. **Integração / Smoke PHP**
   - Valida comportamento real do plugin no runtime do GLPI.
   - Usa banco, sessão, hooks, controllers e filesystem reais.
3. **Browser / E2E**
   - Valida fluxos visíveis no frontend e no guest flow.

## Execução

### Roteador principal

Executa todas as suítes por padrão ou uma camada específica por parâmetro:

```bash
./tests/run_unit_php.sh
./tests/run_unit_php.sh unit
./tests/run_unit_php.sh unit-php
./tests/run_unit_php.sh unit-js
./tests/run_unit_php.sh smoke
./tests/run_unit_php.sh smoke-php
./tests/run_unit_php.sh smoke-http http://localhost:8080 2 public
./tests/run_unit_php.sh e2e http://localhost:8080
```

`run_full_suite.sh` inclui o teste de uninstall, que apaga as tabelas e os dados do Chat. Ele recusa execução sem opt-in explícito e deve apontar somente para um clone descartável:

```bash
GLPICHAT_ALLOW_DESTRUCTIVE_TEST=1 ./tests/run_full_suite.sh http://localhost:8080
```

A reinstalação final recompõe o schema e as configurações, mas não restaura as mensagens, participantes ou demais linhas apagadas pelo uninstall.

### Unitário PHP

Executa apenas os testes unitários PHP no container `glpi`:

```bash
./tests/run_unit_php.sh unit-php
```

### Smoke PHP existente

Exemplos de execução direta no container:

```bash
./tests/run_unit_php.sh smoke-php
```

### Smoke HTTP autenticado

```bash
./tests/run_unit_php.sh smoke-http http://localhost:8080 2 public
```

### E2E Browser

```bash
./tests/run_unit_php.sh e2e http://localhost:8080
```

### Carga / Performance

```bash
./tests/performance/run_k6.sh http://localhost:8080
```

### Qualificação foundation1

Os helpers abaixo recusam execução HTTP e devem ser usados somente por PHP CLI em um clone descartável. Consulte o runbook `docs/releases/1.0.6-foundation1.md` antes de habilitar o observador.

```bash
docker exec glpi php /var/www/glpi/plugins/glpichat/tests/qualification/foundation_health.php
docker exec glpi php /var/www/glpi/plugins/glpichat/tests/qualification/foundation_shadow.php status
```

## Diretrizes

1. **Refatoração guiada por testes**: cada extração nova deve ganhar primeiro um teste unitário ou de integração compatível com o tipo de risco.
2. **Teardown obrigatório**: qualquer teste que escreva em banco ou disco deve limpar seus artefatos.
3. **Sem downgrade artificial**: regras puras vão para a camada unitária; integrações reais continuam protegidas por smoke/integration.
4. **Comportamento externo preservado**: testes devem validar o contrato real do plugin, não o detalhe interno da implementação.
5. **Helpers não são suíte**: scripts em `tests/helpers/` apoiam manutenção local, mas não fazem parte da taxonomia de unit/smoke/e2e.


### Qualificação desktop1

O runbook atual é `docs/releases/1.1.0-desktop1.md`. Os relatórios e helpers foundation1 acima permanecem históricos ou referentes à funcionalidade herdada.

`php tests/unit/php/desktop_schema_test.php` executa as fixtures independentes de GLPI para schema/migração repetida, engines, colunas, defaults, índices, marker e ausência de DDL no diagnóstico. Os contratos de release verificam a versão 1.1.0-desktop1, preservando o inventário e os hashes herdados de browser/Guest e permitindo apenas o controller Desktop explicitamente previsto.

O teste de lifecycle com banco continua destrutivo e exige banco descartável e seu guard explícito. O teste de fixtures não substitui a execução de uma instalação real. Testes Windows pertencem ao pacote desktop separado.
