<?php

declare(strict_types=1);

// Service-level failure-injection harness, deliberately independent of a GLPI
// session. It is not a substitute for the installed-GLPI/database smoke test.
require_once dirname(__DIR__, 3) . '/src/desktop/common.php';

final class Config
{
    public static function getConfigurationValue(string $scope, string $key): string
    {
        return str_repeat('a', 64);
    }
}
final class Ticket
{
    public static bool $merged = false;
    public static function getMergedTickets(int $id): array { return self::$merged ? [99] : []; }
}
final class DesktopRows
{
    public int $position = 0;
    public function __construct(public array $rows) {}
    public function free(): void {}
}
final class DesktopFakeDB
{
    public array $receipts = [];
    public array $followups = [];
    public array $mirrors = [];
    public array $reads = [];
    public bool $active = false;
    public bool $requester = true;
    public bool $failMirror = false;
    public int $ticketStatus = 2;
    public int $lastId = 0;
    public int $notifications = 0;
    private array $backup = [];
    public function escape(string $text): string { return addslashes($text); }
    public function isInTransaction(): bool { return $this->active; }
    public function beginTransaction(): void
    {
        if ($this->active) { throw new RuntimeException('Nested transaction'); }
        $this->active = true;
        $this->backup = [$this->receipts, $this->followups, $this->mirrors, $this->reads];
    }
    public function commit(): void { $this->active = false; }
    public function rollBack(): void
    {
        [$this->receipts, $this->followups, $this->mirrors, $this->reads] = $this->backup;
        $this->active = false;
    }
    public function insert(string $table, array $row): bool
    {
        $this->lastId++;
        $row['id'] = $this->lastId;
        $this->receipts[] = $row;
        return true;
    }
    public function insertId(): int { return $this->lastId; }
    public function update(string $table, array $changes, array $where): bool
    {
        foreach ($this->receipts as &$row) {
            if ($row['id'] === $where['id']) { $row = array_replace($row, $changes); }
        }
        return true;
    }
    public function fetchAssoc(DesktopRows $rows): array|false
    {
        return $rows->rows[$rows->position++] ?? false;
    }
    public function doQuery(string $sql): DesktopRows|bool
    {
        if (str_starts_with($sql, 'INSERT INTO glpi_plugin_glpichat_desktopreads')) {
            preg_match_all('/\((\d+),(\d+),\x27/', $sql, $matches, PREG_SET_ORDER);
            foreach ($matches as $match) { $this->reads[$match[1] . ':' . $match[2]] = true; }
            return true;
        }
        if (str_contains($sql, 'FROM glpi_tickets_users')) {
            return new DesktopRows($this->requester ? [['id' => 4]] : []);
        }
        if (str_contains($sql, 'FROM glpi_tickets ')) {
            return new DesktopRows([['id' => 7, 'name' => 'Chamado', 'status' => $this->ticketStatus, 'entities_id' => 2]]);
        }
        if (str_contains($sql, 'FROM glpi_requesttypes')) { return new DesktopRows([['id' => 1]]); }
        if (str_contains($sql, 'FROM glpi_plugin_glpichat_desktopsends')) {
            if (str_contains($sql, 'COUNT(*)')) { return new DesktopRows([['n' => count($this->receipts)]]); }
            preg_match('/client_message_id = \'([^\']+)\'/', $sql, $match);
            return new DesktopRows(array_values(array_filter($this->receipts, static fn(array $r): bool => $r['client_message_id'] === ($match[1] ?? ''))));
        }
        if (str_starts_with($sql, 'SELECT id FROM glpi_plugin_glpichat_messages')) {
            return new DesktopRows($this->failMirror ? [] : array_values($this->mirrors));
        }
        if (str_contains($sql, 'FROM glpi_itilfollowups f')) {
            $rows = array_values(array_filter($this->followups, static fn(array $r): bool => $r['is_private'] === 0 && empty($r['attachment'])));
            if (preg_match('/f.id = (\d+)/', $sql, $match)) {
                $rows = array_values(array_filter($rows, static fn(array $r): bool => $r['id'] === (int) $match[1]));
            }
            if (preg_match('/f.id IN \(([0-9,]+)\)/', $sql, $match)) {
                $ids = array_map('intval', explode(',', $match[1]));
                $rows = array_values(array_filter($rows, static fn(array $r): bool => in_array($r['id'], $ids, true)));
            }
            if (preg_match('/f.id < (\d+)/', $sql, $match)) {
                $rows = array_values(array_filter($rows, static fn(array $r): bool => $r['id'] < (int) $match[1]));
            }
            if (str_contains($sql, 'ORDER BY f.id DESC')) {
                usort($rows, static fn(array $a, array $b): int => $b['id'] <=> $a['id']);
            }
            if (preg_match('/LIMIT (\d+)/', $sql, $match)) {
                $rows = array_slice($rows, 0, (int) $match[1]);
            }
            return new DesktopRows($rows);
        }
        throw new RuntimeException('Unrecognized test SQL: ' . $sql);
    }
}
final class ITILFollowup
{
    public function add(array $input): int
    {
        global $DB;
        if (!isset($input['_disablenotif']) || $input['users_id'] !== 10 || $input['is_private'] !== 0) {
            throw new RuntimeException('Unsafe native followup input');
        }
        $id = 100 + count($DB->followups);
        $DB->followups[$id] = $input + ['id' => $id, 'firstname' => 'Ana', 'realname' => 'Teste', 'author_login' => 'ana'];
        return $id;
    }
}
function glpichat_desktop_validate_actor(array $actor, bool $lock = false): array { return $actor; }
function glpichat_add_message(int $ticket, string $room, string $actorType, int $user, int $participant, string $content, int $document, int $followup, bool $notify = true): int
{
    global $DB;
    if ($notify || !$DB->active) { throw new RuntimeException('Mirror must be inside transaction without notification'); }
    if ($DB->failMirror) { throw new RuntimeException('Injected mirror failure'); }
    $id = 500 + count($DB->mirrors);
    $DB->mirrors[$id] = ['id' => $id, 'itilfollowups_id' => $followup, 'tickets_id' => $ticket, 'users_id' => $user];
    return $id;
}
function glpichat_raise_message_notification_event(...$args): void
{
    global $DB;
    if (!$DB->receipts || !$DB->receipts[0]['itilfollowups_id']) { throw new RuntimeException('Notification before durable source'); }
    $DB->notifications++;
}

require_once dirname(__DIR__, 3) . '/src/desktop/conversations.php';

function desktop_assert(bool $condition, string $label): void
{
    if (!$condition) { throw new RuntimeException($label); }
    echo '[PASS] ' . $label . "\n";
}
function desktop_expect(string $code, callable $call, string $label): void
{
    try { $call(); } catch (GlpichatDesktopException $error) {
        desktop_assert($error->errorCode === $code, $label);
        return;
    }
    throw new RuntimeException($label . ': operation unexpectedly succeeded');
}

$DB = new DesktopFakeDB();
$actor = ['user_id' => 10, 'profile_id' => 1, 'entity_id' => 2, 'can_read' => true, 'can_create' => true, 'device_db_id' => 4];
$uuid = '01234567-89ab-4cde-8fab-0123456789ab';
foreach (["linha 1\nlinha 2", "a\u{00a0}b", "a  \nb", "a\n\n\n\nb", '<script>literal &amp; text</script>', 'Olá 👋'] as $plain) {
    $canonical = glpichat_desktop_normalize_message($plain);
    $html = str_replace("\n", '<br>', htmlspecialchars($canonical, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));
    desktop_assert(glpichat_desktop_text($html) === $canonical, 'Plain text → native HTML → text is lossless: ' . json_encode($plain));
}
desktop_assert(glpichat_desktop_text('<p>Olá</p><script>secret()</script><style>.hide{}</style><p>Mundo &amp; teste</p>') === "Olá\nMundo & teste", 'Active HTML is stripped and entities decoded once');
desktop_expect('invalid_content', static fn() => glpichat_desktop_normalize_message("a\0b"), 'Control characters rejected');
desktop_expect('invalid_content', static fn() => glpichat_desktop_normalize_message(str_repeat('x', 4001)), 'Overlong message rejected');
desktop_expect('invalid_message_id', static fn() => glpichat_desktop_send($actor, 7, '../unsafe', 'x'), 'Malformed idempotency ID rejected');

$first = glpichat_desktop_send($actor, 7, $uuid, "Resposta\ncom espaços  \ne NBSP a\u{00a0}b");
$replay = glpichat_desktop_send(array_replace($actor, ['device_db_id' => 9]), 7, $uuid, "Resposta\ncom espaços  \ne NBSP a\u{00a0}b");
desktop_assert($first === $replay, 'Lost-response identical retry returns the same source message');
desktop_assert(count($DB->followups) === 1 && count($DB->mirrors) === 1 && count($DB->receipts) === 1, 'Retry creates no duplicate followup, mirror or receipt');
desktop_assert($DB->notifications === 1, 'Retry never repeats post-commit notification');
desktop_expect('idempotency_conflict', static fn() => glpichat_desktop_send($actor, 7, $uuid, 'Different'), 'Same key with different content conflicts');

$DB->followups[100]['is_private'] = 1;
desktop_expect('message_unavailable', static fn() => glpichat_desktop_send($actor, 7, $uuid, "Resposta\ncom espaços  \ne NBSP a\u{00a0}b"), 'Private source cannot be disclosed on replay');
$DB->followups[100]['is_private'] = 0;
$DB->followups[100]['content'] = 'Edited by technician';
desktop_expect('message_changed', static fn() => glpichat_desktop_send($actor, 7, $uuid, "Resposta\ncom espaços  \ne NBSP a\u{00a0}b"), 'Edited source cannot masquerade as original send confirmation');
$DB->requester = false;
desktop_expect('conversation_unavailable', static fn() => glpichat_desktop_send($actor, 7, $uuid, 'Different'), 'Current ticket authorization precedes receipt disclosure');
$DB->requester = true;

$DB->failMirror = true;
try { glpichat_desktop_send($actor, 7, '11234567-89ab-4cde-8fab-0123456789ab', 'Crash before mirror'); } catch (RuntimeException $expected) {}
desktop_assert(count($DB->followups) === 1 && count($DB->receipts) === 1, 'Failure before browser mirror rolls back source and receipt');
$DB->failMirror = false;
$DB->ticketStatus = 6;
desktop_expect('conversation_read_only', static fn() => glpichat_desktop_send($actor, 7, '21234567-89ab-4cde-8fab-0123456789ab', 'Closed'), 'Closed ticket cannot receive a new send');
$DB->ticketStatus = 2;

$DB->followups[101] = $DB->followups[100];
$DB->followups[101]['id'] = 101;
$DB->followups[101]['is_private'] = 1;
desktop_expect('message_unavailable', static fn() => glpichat_desktop_read($actor, 7, [100, 101]), 'Mixed visible/private read set is rejected atomically');
desktop_assert($DB->reads === [], 'Rejected Read marks no partial subset');
glpichat_desktop_read($actor, 7, [100]);
glpichat_desktop_read($actor, 7, [100]);
desktop_assert(array_keys($DB->reads) === ['10:100'], 'Read stores exactly the displayed ID and remains idempotent');
desktop_expect('invalid_message_ids', static fn() => glpichat_desktop_read($actor, 7, [100.5]), 'Read rejects fractional IDs');

$DB = new DesktopFakeDB();
for ($id = 1; $id <= 101; $id++) {
    $DB->followups[$id] = [
        'id' => $id, 'items_id' => 7, 'users_id' => 20, 'is_private' => 0,
        'content' => 'Message ' . $id, 'date' => '2026-09-21 12:00:00',
    ];
}
$page1 = glpichat_desktop_history($actor, 7, 0, 50);
$page2 = glpichat_desktop_history($actor, 7, $page1['next_before'], 50);
$page3 = glpichat_desktop_history($actor, 7, $page2['next_before'], 50);
desktop_assert(array_column($page1['messages'], 'id') === range(52, 101), 'Newest snapshot is bounded and ascending for render');
desktop_assert(array_column($page2['messages'], 'id') === range(2, 51) && array_column($page3['messages'], 'id') === [1], 'Backwards pages preserve all101 IDs with no50-boundary gap');
desktop_assert($page3['has_more'] === false && $page3['next_before'] === 0, 'Final page terminates explicitly');
$DB->followups[53]['is_private'] = 1;
$refreshed = glpichat_desktop_history($actor, 7, 0, 50);
desktop_assert(!in_array(53, array_column($refreshed['messages'], 'id'), true), 'Refresh re-reads current privacy instead of returning cached history');

echo "[PASS] Desktop conversation service failure-injection tests completed.\n";
