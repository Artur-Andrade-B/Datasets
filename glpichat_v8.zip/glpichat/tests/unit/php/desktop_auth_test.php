<?php

declare(strict_types=1);

// Standalone focused behavior tests; run with PHP 8.2+ without a GLPI instance.
// SQL execution/lifecycle is covered by the separately required GLPI smoke test.
define('READ', 1);
define('CREATE', 4);
class Auth { public const LDAP = 3; public const CAS = 5; }
class Ticket { public const READMY = 1; }
class ITILFollowup { public const SEEPUBLIC = 1; public const ADDMY = 4; public const ADDALLITEM = 4096; }
class DesktopAuthTestError extends RuntimeException
{
    public function __construct(public string $errorCode, int $status) { parent::__construct($errorCode, $status); }
}
function glpichat_desktop_fail(string $code, string $message, int $status): never { throw new DesktopAuthTestError($code, $status); }
function glpichat_desktop_now(): string { return '2026-09-21 12:00:00'; }
function glpichat_desktop_enabled(): bool { return true; }
function glpichat_desktop_require_schema(): void {}
function glpichat_desktop_base_url(): string { return 'https://glpi.example.test'; }
function glpichat_desktop_quote(string $value): string { return "'" . str_replace("'", "''", $value) . "'"; }
function glpichat_desktop_transaction(callable $callback): mixed { return $callback(); }

$fixture = [];
$queries = [];
function desktop_auth_fixture(): void
{
    global $fixture, $queries, $DB;
    $fixture = [
        'user' => ['id' => 10, 'auths_id' => 2, 'authtype' => Auth::CAS, 'sync_field' => "\x01\x02object-guid",
            'date_creation' => '2025-01-01 10:00:00', 'is_active' => 1, 'is_deleted' => 0,
            'name' => 'artur', 'firstname' => 'Artur', 'realname' => 'Example', 'begin_date' => null, 'end_date' => null],
        'source' => ['id' => 2, 'is_active' => 1, 'host' => 'ad.example.test', 'basedn' => 'DC=example,DC=test', 'sync_field' => 'objectGUID'],
        'grant' => ['id' => 19], 'profile' => ['id' => 3], 'entity' => ['id' => 0],
        'rights' => [['name' => 'plugin_glpichat_public', 'rights' => READ | CREATE],
            ['name' => 'ticket', 'rights' => Ticket::READMY],
            ['name' => 'followup', 'rights' => ITILFollowup::SEEPUBLIC | ITILFollowup::ADDMY]],
        'device' => [],
    ];
    $queries = [];
    $DB = new class {
        public int $updates = 0;
        public function update(string $table, array $values, array $where): bool
        {
            global $fixture;
            foreach ($where as $key => $value) {
                if (($fixture['device'][$key] ?? null) !== $value) { return false; }
            }
            $fixture['device'] = array_replace($fixture['device'], $values);
            $this->updates++;
            return true;
        }
        public function affectedRows(): int { return 1; }
    };
}
function glpichat_desktop_db_rows(string $sql): array
{
    global $fixture, $queries;
    $queries[] = $sql;
    $mapping = [
        'glpi_plugin_glpichat_desktopdevices' => 'device', 'glpi_profiles_users' => 'grant',
        'glpi_profilerights' => 'rights', 'glpi_authldaps' => 'source',
        'glpi_profiles' => 'profile', 'glpi_entities' => 'entity', 'glpi_users' => 'user',
    ];
    foreach ($mapping as $table => $key) {
        if (str_contains($sql, 'FROM ' . $table . ' ')) {
            return $key === 'rights' ? $fixture[$key] : ($fixture[$key] ? [$fixture[$key]] : []);
        }
    }
    throw new RuntimeException('Unexpected test SQL: ' . $sql);
}

require_once dirname(__DIR__, 3) . '/src/desktop/auth.php';
$assertions = 0;
function desktop_assert(bool $condition, string $message): void
{
    global $assertions;
    if (!$condition) { throw new RuntimeException('FAIL: ' . $message); }
    $assertions++;
}
function desktop_throws(callable $callback, string $code, string $message): void
{
    try { $callback(); } catch (DesktopAuthTestError $e) {
        desktop_assert($e->errorCode === $code, $message . ' (actual ' . $e->errorCode . ')');
        return;
    }
    throw new RuntimeException('FAIL: expected rejection ' . $message);
}

desktop_assert(glpichat_desktop_normalize_login('DOMAIN\\Artur') === 'artur', 'Windows domain is selector only');
desktop_assert(glpichat_desktop_normalize_login('Artur@example.test') === 'artur', 'UPN selector');
foreach (['', 'DOMAIN\\\\artur', 'artur@@domain', "artur\0admin", 'artur admin'] as $bad) {
    desktop_assert(glpichat_desktop_normalize_login($bad) === '', 'Malformed selector rejected');
}
desktop_assert(glpichat_desktop_auth_hash('bearer', str_repeat('a', 64)) !== glpichat_desktop_auth_hash('poll-secret', str_repeat('a', 64)), 'Hash purposes separated');

desktop_auth_fixture();
$facts = glpichat_desktop_auth_user(10, 3, 0, true);
desktop_assert($facts['can_read'] && $facts['can_create'], 'CAS+LDAP requester is eligible without Session impersonation');
desktop_assert(count(array_filter($queries, static fn(string $q): bool => str_ends_with($q, 'FOR UPDATE'))) === 6, 'Mutation revalidation locks all current authority reads');
desktop_assert(strlen($facts['sync_anchor']) === 64, 'Binary directory anchor fingerprinted without text coercion');

foreach (['disabled', 'deleted', 'local', 'future', 'expired', 'source', 'grant', 'public', 'native_read', 'native_ticket'] as $scenario) {
    desktop_auth_fixture();
    switch ($scenario) {
        case 'disabled': $fixture['user']['is_active'] = 0; break;
        case 'deleted': $fixture['user']['is_deleted'] = 1; break;
        case 'local': $fixture['user']['authtype'] = 1; break;
        case 'future': $fixture['user']['begin_date'] = '2026-09-22 00:00:00'; break;
        case 'expired': $fixture['user']['end_date'] = '2026-09-20 00:00:00'; break;
        case 'source': $fixture['source']['sync_field'] = 'mail'; break;
        case 'grant': $fixture['grant'] = []; break;
        case 'public': $fixture['rights'][0]['rights'] = 0; break;
        case 'native_read': $fixture['rights'][2]['rights'] = ITILFollowup::ADDMY; break;
        case 'native_ticket': $fixture['rights'][1]['rights'] = 0; break;
    }
    desktop_throws(static fn() => glpichat_desktop_auth_user(10, 3, 0), 'credential_invalid', $scenario . ' current authority denied');
}
desktop_auth_fixture();
$fixture['rights'][2]['rights'] = ITILFollowup::SEEPUBLIC;
desktop_assert(glpichat_desktop_auth_user(10, 3, 0)['can_create'] === false, 'Public read alone never grants send');
$fixture['rights'][2]['rights'] |= ITILFollowup::ADDALLITEM;
desktop_assert(glpichat_desktop_auth_user(10, 3, 0)['can_create'] === true, 'Native ADDALLITEM accepted for direct requester sends');

desktop_auth_fixture();
$facts = glpichat_desktop_auth_user(10, 3, 0);
$row = ['auths_id' => 2, 'users_id' => 10, 'profiles_id' => 3, 'entities_id' => 0,
    'sync_anchor' => $facts['sync_anchor'], 'user_incarnation' => $facts['user_incarnation'],
    'auth_source_fingerprint' => $facts['auth_source_fingerprint'], 'windows_login' => 'DOMAIN\\artur'];
desktop_assert(glpichat_desktop_auth_binding_matches($row, $facts), 'Exact binding accepted');
foreach (['auths_id', 'sync_anchor', 'user_incarnation', 'auth_source_fingerprint'] as $field) {
    $changed = $row;
    $changed[$field] = $field === 'auths_id' ? 4 : 'different';
    desktop_assert(!glpichat_desktop_auth_binding_matches($changed, $facts), 'Changed ' . $field . ' invalidates binding');
}
$renamed = $facts;
$renamed['login'] = 'artur.renamed';
desktop_assert(glpichat_desktop_auth_binding_matches($row, $renamed), 'Directory login rename preserves the same anchored binding');
$subject = glpichat_desktop_subject_id($facts);
desktop_assert((bool) preg_match('/^[a-f0-9]{64}$/D', $subject), 'Principal subject is opaque lowercase64hex');
$reapproved = $renamed + ['device_db_id' => 999, 'device_id' => 'new-device'];
$reapproved['profile_id'] = 77;
$reapproved['entity_id'] = 42;
$reapproved['can_create'] = false;
desktop_assert(glpichat_desktop_subject_id($reapproved) === $subject, 'Rename, device reapproval, profile/entity or rights change preserves principal subject');
foreach (['user_id', 'sync_anchor', 'user_incarnation', 'auth_source_fingerprint'] as $field) {
    $otherPrincipal = $facts;
    $otherPrincipal[$field] = $field === 'user_id' ? 11 : str_repeat('d', 64);
    desktop_assert(glpichat_desktop_subject_id($otherPrincipal) !== $subject, 'Principal subject changes for replacement ' . $field);
}
$missingAnchor = $facts;
unset($missingAnchor['user_incarnation']);
desktop_throws(static fn() => glpichat_desktop_subject_id($missingAnchor), 'credential_invalid', 'Missing incarnation cannot fall back to numeric user id');
$fixture['user']['authtype'] = Auth::LDAP;
desktop_assert(!glpichat_desktop_auth_binding_matches($row, glpichat_desktop_auth_user(10, 3, 0)), 'CAS→LDAP auth-type change invalidates old credential despite unchanged GUID');

desktop_auth_fixture();
foreach ([[], 42, true, new stdClass()] as $bad) {
    desktop_throws(static fn() => glpichat_desktop_pair_start(['device_id' => $bad], '127.0.0.1'), 'invalid_pairing', 'Non-string JSON never reaches casts/SQL');
}

desktop_auth_fixture();
$facts = glpichat_desktop_auth_user(10, 3, 0);
$fixture['device'] = $row + ['id' => 7, 'pairing_id' => str_repeat('a', 32), 'device_id' => '11111111-2222-3333-4444-555555555555',
    'poll_secret_hash' => glpichat_desktop_auth_hash('poll-secret', str_repeat('b', 64)),
    'token_hash' => null, 'status' => 'approved', 'revoked_at' => null,
    'pairing_expires_at' => '2026-09-21 12:10:00', 'token_expires_at' => null];
$response1 = glpichat_desktop_pair_exchange(str_repeat('a', 32), str_repeat('b', 64), str_repeat('c', 64));
$response2 = glpichat_desktop_pair_exchange(str_repeat('a', 32), str_repeat('b', 64), str_repeat('c', 64));
desktop_assert($response1 === $response2 && $DB->updates === 1, 'Lost-response retry reuses exactly one consumed device/token');
desktop_assert($response1['user']['subject_id'] === glpichat_desktop_subject_id($facts), 'Exchange identity exposes the current principal subject');
desktop_assert($fixture['device']['token_hash'] !== str_repeat('c', 64), 'Only bearer hash stored');
desktop_assert(str_ends_with($response1['device']['expires_at'], 'Z'), 'Token expiry explicitly UTC');
desktop_throws(static fn() => glpichat_desktop_pair_exchange(str_repeat('a', 32), str_repeat('b', 64), str_repeat('d', 64)), 'pairing_consumed', 'Different token cannot replace consumed credential');
desktop_throws(static fn() => glpichat_desktop_pair_status(str_repeat('a', 32), str_repeat('e', 64)), 'pairing_unavailable', 'Wrong poll secret cannot reveal approval');
$fixture['device']['status'] = 'revoked';
desktop_throws(static fn() => glpichat_desktop_auth_from_row($fixture['device']), 'credential_invalid', 'Revoke denies current credential immediately');

echo 'PASS desktop auth: ' . $assertions . " assertions\n";
