<?php

declare(strict_types=1);

namespace Symfony\Component\HttpFoundation {
    /**
     * Tiny request fixture only when Symfony is absent. It models the methods
     * used by common.php; it does NOT establish GLPI/Symfony firewall parity.
     * With Symfony autoloaded, the real Request class is used instead.
     */
    if (!class_exists(Request::class)) {
        final class DesktopCommonTestBag
        {
            private array $values;
            public function __construct(array $values = []) { $this->values = array_change_key_case($values, CASE_LOWER); }
            public function has(string $key): bool { return array_key_exists(strtolower($key), $this->values); }
            public function get(string $key, mixed $default = null): mixed { return $this->values[strtolower($key)] ?? $default; }
            public function count(): int { return count($this->values); }
        }
        final class Request
        {
            public DesktopCommonTestBag $headers;
            public DesktopCommonTestBag $cookies;
            private mixed $content;
            private bool $secure;
            public function __construct(array $query = [], array $request = [], array $attributes = [], array $cookies = [], array $files = [], array $server = [], mixed $content = null)
            {
                $headers = [];
                foreach ($server as $key => $value) {
                    if (str_starts_with($key, 'HTTP_')) { $headers[str_replace('_', '-', substr($key, 5))] = $value; }
                    elseif (in_array($key, ['CONTENT_TYPE', 'CONTENT_LENGTH'], true)) { $headers[str_replace('_', '-', $key)] = $value; }
                }
                $this->headers = new DesktopCommonTestBag($headers);
                $this->cookies = new DesktopCommonTestBag($cookies);
                $this->content = $content;
                $this->secure = ($server['HTTPS'] ?? '') === 'on';
            }
            public function isSecure(): bool { return $this->secure; }
            public function getContent(bool $asResource = false): mixed
            {
                if (is_resource($this->content)) { rewind($this->content); }
                return $this->content;
            }
        }
    }
}

namespace {
    use Symfony\Component\HttpFoundation\Request;

    final class Config
    {
        public static array $values = [];
        public static function getConfigurationValue(string $context, string $key): mixed
        {
            if ($context !== 'plugin:glpichat') { throw new RuntimeException('Unexpected config context.'); }
            return self::$values[$key] ?? null;
        }
    }

    require_once dirname(__DIR__, 3) . '/src/desktop/common.php';

    $assertions = 0;
    function desktop_common_assert(bool $result, string $message): void
    {
        global $assertions;
        if (!$result) { throw new RuntimeException('FAIL: ' . $message); }
        $assertions++;
    }
    function desktop_common_throws(callable $action, string $code, int $status, string $message): void
    {
        try { $action(); } catch (GlpichatDesktopException $error) {
            desktop_common_assert($error->errorCode === $code && $error->httpStatus === $status, $message);
            return;
        }
        throw new RuntimeException('FAIL: expected rejection: ' . $message);
    }
    function desktop_common_reset(): void
    {
        global $CFG_GLPI;
        Config::$values = ['desktop_enabled' => '1', 'desktop_schema_version' => '1', 'desktop_idempotency_key' => str_repeat('a', 64)];
        $CFG_GLPI = ['url_base' => 'https://glpi.example.test/glpi'];
    }
    /** @return array{0:Request,1:resource} */
    function desktop_common_request(string $body = '{}', array $headers = [], array $cookies = [], bool $secure = true, array $query = []): array
    {
        $server = ['HTTPS' => $secure ? 'on' : 'off', 'SERVER_PORT' => $secure ? 443 : 80,
            'HTTP_HOST' => 'glpi.example.test', 'REQUEST_METHOD' => 'POST', 'REQUEST_URI' => '/glpi/plugins/glpichat/Desktop/V1/Pairings'];
        foreach ($headers as $key => $value) {
            $name = strtoupper(str_replace('-', '_', $key));
            $server[in_array($name, ['CONTENT_TYPE', 'CONTENT_LENGTH'], true) ? $name : 'HTTP_' . $name] = $value;
        }
        $stream = fopen('php://temp', 'w+b');
        if ($stream === false) { throw new RuntimeException('Test stream unavailable.'); }
        fwrite($stream, $body);
        rewind($stream);
        return [new Request($query, [], [], $cookies, [], $server, $stream), $stream];
    }

    desktop_common_reset();
    [$native] = desktop_common_request();
    glpichat_desktop_request_guard($native);
    desktop_common_assert(true, 'Configured HTTPS native request passes');
    foreach ([null, '', '0', 'true', '01'] as $disabled) {
        Config::$values['desktop_enabled'] = $disabled;
        desktop_common_throws(static fn() => glpichat_desktop_request_guard($native), 'unavailable', 404, 'Disabled/malformed flag rejects before business work');
    }
    desktop_common_reset();
    [$plain] = desktop_common_request(secure: false);
    desktop_common_throws(static fn() => glpichat_desktop_request_guard($plain), 'https_required', 400, 'Cleartext request rejected');
    foreach ([['PHPSESSID' => 'accidental-session'], ['other_cookie' => 'value']] as $cookies) {
        [$cookieRequest] = desktop_common_request(cookies: $cookies);
        desktop_common_throws(static fn() => glpichat_desktop_request_guard($cookieRequest), 'desktop_client_required', 403, 'All browser cookies excluded from bearer API');
    }
    foreach (['https://glpi.example.test', 'https://attacker.invalid', 'null', ''] as $origin) {
        [$originRequest] = desktop_common_request(headers: ['Origin' => $origin]);
        desktop_common_throws(static fn() => glpichat_desktop_request_guard($originRequest), 'desktop_client_required', 403, 'Browser Origin presence rejected even if empty/same-origin');
    }
    [$override] = desktop_common_request(headers: ['X-HTTP-Method-Override' => 'DELETE']);
    desktop_common_throws(static fn() => glpichat_desktop_request_guard($override), 'invalid_request', 400, 'Method override rejected');

    foreach (['', '0', '2', '01'] as $version) {
        desktop_common_reset();
        Config::$values['desktop_schema_version'] = $version;
        desktop_common_throws(static fn() => glpichat_desktop_request_guard($native), 'schema_unavailable', 503, 'Missing/unsupported schema marker rejects');
    }
    foreach (['', str_repeat('a', 63), str_repeat('A', 64), str_repeat('g', 64), str_repeat('a', 64) . "\n"] as $key) {
        desktop_common_reset();
        Config::$values['desktop_idempotency_key'] = $key;
        desktop_common_throws(static fn() => glpichat_desktop_require_schema(), 'schema_unavailable', 503, 'Invalid server idempotency key rejects');
    }
    foreach (['http://glpi.example.test', 'https://name:secret@glpi.example.test', 'https://glpi.example.test?key=a',
        'https://glpi.example.test#fragment', "https://glpi.example.test/with space", 'https://glpi.example.test\\wrong'] as $url) {
        desktop_common_reset();
        $CFG_GLPI['url_base'] = $url;
        desktop_common_throws(static fn() => glpichat_desktop_request_guard($native), 'configuration_required', 503, 'Invalid configured authority rejected');
    }
    desktop_common_reset();
    $CFG_GLPI['url_base'] .= '/';
    desktop_common_assert(glpichat_desktop_base_url() === 'https://glpi.example.test/glpi', 'Configured GLPI subpath preserved and trailing slash normalized');

    [$json] = desktop_common_request('{"message":"olá","nested":{"ok":true}}', ['Content-Type' => 'application/json; charset=UTF-8']);
    $body = glpichat_desktop_json_body($json);
    desktop_common_assert($body['message'] === 'olá' && $body['nested']['ok'] === true, 'UTF8 object JSON parsed through actual helper');
    [$emptyObject] = desktop_common_request('{}', ['Content-Type' => 'APPLICATION/JSON']);
    desktop_common_assert(glpichat_desktop_json_body($emptyObject) === [], 'Empty JSON object accepted');
    foreach (['', 'text/plain', 'application/x-www-form-urlencoded', 'multipart/form-data; boundary=x'] as $contentType) {
        [$notJson] = desktop_common_request('{}', ['Content-Type' => $contentType]);
        desktop_common_throws(static fn() => glpichat_desktop_json_body($notJson), 'json_required', 415, 'Wrong media type rejected');
    }
    foreach (['', '{broken', '[]', '[{}]', 'null', 'true', '42', '"text"', "{\"x\":\"\xb1\"}", str_repeat('{"x":', 20) . 'null' . str_repeat('}', 20)] as $invalid) {
        [$invalidJson] = desktop_common_request($invalid, ['Content-Type' => 'application/json']);
        desktop_common_throws(static fn() => glpichat_desktop_json_body($invalidJson), 'invalid_json', 400, 'Malformed/nonobject/deep/invalidUTF8 JSON rejected');
    }
    [$declaredTooLarge, $unreadStream] = desktop_common_request('{}', ['Content-Type' => 'application/json', 'Content-Length' => '32769']);
    desktop_common_throws(static fn() => glpichat_desktop_json_body($declaredTooLarge), 'request_too_large', 413, 'Oversize advertised length rejected');
    desktop_common_assert(ftell($unreadStream) === 0, 'Advertised oversize rejects before consuming body');
    $exactBody = '{"x":"' . str_repeat('a', 32760) . '"}';
    desktop_common_assert(strlen($exactBody) === 32768, 'Exact-limit fixture is 32768 bytes');
    [$exact] = desktop_common_request($exactBody, ['Content-Type' => 'application/json']);
    desktop_common_assert(strlen(glpichat_desktop_json_body($exact)['x']) === 32760, 'Exact byte limit accepted without Content-Length');
    foreach ([[], ['Content-Length' => '2'], ['Content-Length' => '-1']] as $lengthHeaders) {
        [$actualTooLarge, $boundedStream] = desktop_common_request(str_repeat('x', 100000), ['Content-Type' => 'application/json'] + $lengthHeaders);
        desktop_common_throws(static fn() => glpichat_desktop_json_body($actualTooLarge), 'request_too_large', 413, 'Actual stream bound enforced despite absent/misleading length');
        desktop_common_assert(ftell($boundedStream) === 32769, 'Only limit plus one bytes consumed');
    }

    $token = str_repeat('ab', 32);
    [$bearer] = desktop_common_request(headers: ['Authorization' => 'Bearer ' . $token]);
    desktop_common_assert(glpichat_desktop_bearer($bearer) === $token, 'Exact lowercase64 bearer accepted');
    foreach (['', $token, 'bearer ' . $token, 'Bearer  ' . $token, ' Bearer ' . $token, 'Bearer ' . strtoupper($token),
        'Bearer ' . substr($token, 1), 'Bearer ' . $token . "\n", 'Bearer ' . $token . ',other'] as $value) {
        [$invalidBearer] = desktop_common_request(headers: ['Authorization' => $value]);
        desktop_common_throws(static fn() => glpichat_desktop_bearer($invalidBearer), 'invalid_credential', 401, 'Malformed bearer rejected');
    }
    [$queryOnly] = desktop_common_request(query: ['token' => $token, 'Authorization' => 'Bearer ' . $token]);
    desktop_common_throws(static fn() => glpichat_desktop_bearer($queryOnly), 'invalid_credential', 401, 'Query value cannot authenticate');
    foreach ([[], null, 7, true, new stdClass()] as $bad) {
        desktop_common_throws(static fn() => glpichat_desktop_string(['x' => $bad], 'x'), 'invalid_request', 400, 'String-field helper rejects malformed scalars without coercion');
    }

    final class DesktopCommonTransactionFixture
    {
        public bool $active = false;
        public array $calls = [];
        public ?Throwable $beginError = null;
        public ?Throwable $commitError = null;
        public ?Throwable $rollbackError = null;
        public function isInTransaction(): bool { $this->calls[] = 'state'; return $this->active; }
        public function beginTransaction(): void { $this->calls[] = 'begin'; if ($this->beginError) { throw $this->beginError; } $this->active = true; }
        public function commit(): void { $this->calls[] = 'commit'; if ($this->commitError) { throw $this->commitError; } $this->active = false; }
        public function rollBack(): void { $this->calls[] = 'rollback'; if ($this->rollbackError) { throw $this->rollbackError; } $this->active = false; }
    }
    $DB = new DesktopCommonTransactionFixture();
    $value = glpichat_desktop_transaction(static function () use ($DB): array { $DB->calls[] = 'action'; return ['accepted' => 1]; });
    desktop_common_assert($value === ['accepted' => 1] && $DB->calls === ['state', 'begin', 'action', 'commit'], 'Successful transaction returns value and commits exactly once');
    $DB = new DesktopCommonTransactionFixture();
    $DB->active = true;
    try {
        glpichat_desktop_transaction(static function () use ($DB): void { $DB->calls[] = 'unexpected-action'; });
        throw new LogicException('Nested transaction was not rejected.');
    } catch (RuntimeException $error) {
        desktop_common_assert($DB->calls === ['state'] && $DB->active, 'Nested transaction rejected without touching caller transaction');
    }
    foreach ([false, true] as $rollbackFails) {
        $DB = new DesktopCommonTransactionFixture();
        $original = new LogicException('original-action-error');
        $DB->rollbackError = $rollbackFails ? new RuntimeException('rollback-error') : null;
        try {
            glpichat_desktop_transaction(static function () use ($original): never { throw $original; });
            throw new RuntimeException('Action error disappeared.');
        } catch (Throwable $error) {
            desktop_common_assert($error === $original, 'Original action error preserved even if rollback fails');
            desktop_common_assert($DB->calls === ['state', 'begin', 'rollback'], 'Failed action rolls back and never commits');
        }
    }
    $DB = new DesktopCommonTransactionFixture();
    $commitError = new LogicException('commit-error');
    $DB->commitError = $commitError;
    try {
        glpichat_desktop_transaction(static fn(): string => 'not-committed');
        throw new RuntimeException('Commit error disappeared.');
    } catch (Throwable $error) {
        desktop_common_assert($error === $commitError && $DB->calls === ['state', 'begin', 'commit', 'rollback'], 'Commit failure attempts rollback and preserves error');
    }
    $DB = new DesktopCommonTransactionFixture();
    $beginError = new LogicException('begin-error');
    $DB->beginError = $beginError;
    try {
        glpichat_desktop_transaction(static function () use ($DB): void { $DB->calls[] = 'unexpected-action'; });
        throw new RuntimeException('Begin error disappeared.');
    } catch (Throwable $error) {
        desktop_common_assert($error === $beginError && $DB->calls === ['state', 'begin'], 'Begin failure does not execute business callback');
    }

    echo 'PASS desktop common: ' . $assertions . " assertions (standalone Request fixture unless Symfony autoloaded)\n";
}
