<?php

declare(strict_types=1);

/**
 * Browser-approved Desktop/V1 profile credentials.
 *
 * Windows account text selects the account to confirm; it is never proof of
 * identity. These are revocable profile bearer credentials, not hardware-bound
 * device keys. No browser session is fabricated for an API request.
 */

const GLPICHAT_DESKTOP_DEVICES_TABLE = 'glpi_plugin_glpichat_desktopdevices';

function glpichat_desktop_normalize_login(string $login): string
{
    $login = trim($login);
    if ($login === '' || strlen($login) > 200 || preg_match('/[\x00-\x20\x7f]/', $login)) {
        return '';
    }
    // Domain/UPN labels are display hints, not an independently verified domain.
    if (substr_count($login, '\\') > 1 || substr_count($login, '@') > 1) {
        return '';
    }
    if (str_contains($login, '\\')) {
        [$domain, $login] = explode('\\', $login, 2);
        if ($domain === '') {
            return '';
        }
    }
    if (str_contains($login, '@')) {
        [$login, $domain] = explode('@', $login, 2);
        if ($domain === '') {
            return '';
        }
    }
    if (!preg_match('/^[\p{L}\p{N}._$-]{1,128}$/uD', $login)) {
        return '';
    }
    return function_exists('mb_strtolower') ? mb_strtolower($login, 'UTF-8') : strtolower($login);
}

function glpichat_desktop_auth_hash(string $purpose, string $value): string
{
    return hash('sha256', "glpichat-desktop-v1\0" . $purpose . "\0" . $value);
}

function glpichat_desktop_auth_hex(string $value, int $length = 64): bool
{
    return (bool) preg_match('/^[a-f0-9]{' . $length . '}$/D', $value);
}

function glpichat_desktop_auth_timestamp(string $sqlDate): int
{
    return (new DateTimeImmutable($sqlDate, new DateTimeZone('UTC')))->getTimestamp();
}

function glpichat_desktop_auth_one(string $sql): array
{
    $rows = glpichat_desktop_db_rows($sql);
    return isset($rows[0]) && is_array($rows[0]) ? $rows[0] : [];
}

function glpichat_desktop_auth_sql(string $sql): void
{
    global $DB;
    if ($DB->doQuery($sql) === false) {
        glpichat_desktop_fail('storage_unavailable', 'O serviço está temporariamente indisponível.', 503);
    }
}

function glpichat_desktop_auth_available(): void
{
    if (!glpichat_desktop_enabled()) {
        glpichat_desktop_fail('desktop_disabled', 'O acesso pelo aplicativo está desativado.', 503);
    }
    glpichat_desktop_require_schema();
    glpichat_desktop_base_url(); // Refuse credential work without the configured HTTPS authority.
}

function glpichat_desktop_auth_unavailable(): never
{
    glpichat_desktop_fail('credential_invalid', 'A autorização expirou ou foi revogada. Conecte novamente.', 401);
}

/** Returns current DB facts. Exact selected entity grants only in this pilot. */
function glpichat_desktop_auth_user(int $userId, int $profileId, int $entityId, bool $forUpdate = false): array
{
    if ($userId < 1 || $profileId < 1 || $entityId < 0) {
        glpichat_desktop_auth_unavailable();
    }
    $lock = $forUpdate ? ' FOR UPDATE' : '';
    $user = glpichat_desktop_auth_one('SELECT * FROM glpi_users WHERE id=' . $userId . ' LIMIT 1' . $lock);
    $sourceId = (int) ($user['auths_id'] ?? 0);
    $sync = (string) ($user['sync_field'] ?? '');
    $created = (string) ($user['date_creation'] ?? '');
    $authType = (int) ($user['authtype'] ?? -1);
    $supportedAuthTypes = [];
    foreach (['Auth::LDAP', 'Auth::CAS'] as $constant) {
        if (defined($constant)) {
            $supportedAuthTypes[] = (int) constant($constant);
        }
    }
    // GLPI explicitly supports CAS accounts enriched by an AuthLDAP source.
    // Local authentication with leftover LDAP fields is not an eligible binding.
    $currentTime = glpichat_desktop_now();
    $begin = (string) ($user['begin_date'] ?? '');
    $end = (string) ($user['end_date'] ?? '');
    if (!$user || (int) ($user['is_active'] ?? 0) !== 1 || (int) ($user['is_deleted'] ?? 1) !== 0
        || $sourceId < 1 || $sync === '' || $created === '' || !in_array($authType, $supportedAuthTypes, true)
        || ($begin !== '' && $begin > $currentTime) || ($end !== '' && $end < $currentTime)) {
        glpichat_desktop_auth_unavailable();
    }
    $source = glpichat_desktop_auth_one('SELECT * FROM glpi_authldaps WHERE id=' . $sourceId . ' LIMIT 1' . $lock);
    if (!$source || (array_key_exists('is_active', $source) && (int) $source['is_active'] !== 1)
        || strtolower(trim((string) ($source['sync_field'] ?? ''))) !== 'objectguid') {
        glpichat_desktop_auth_unavailable();
    }
    $grant = glpichat_desktop_auth_one('SELECT id FROM glpi_profiles_users WHERE users_id=' . $userId
        . ' AND profiles_id=' . $profileId . ' AND entities_id=' . $entityId . ' LIMIT 1' . $lock);
    $profile = glpichat_desktop_auth_one('SELECT id FROM glpi_profiles WHERE id=' . $profileId . ' LIMIT 1' . $lock);
    $entity = glpichat_desktop_auth_one('SELECT id FROM glpi_entities WHERE id=' . $entityId . ' LIMIT 1' . $lock);
    // GLPI root entity is a real row (id=0). No ancestry expansion is inferred.
    if (!$grant || !$profile || !$entity) {
        glpichat_desktop_auth_unavailable();
    }
    $rights = [];
    foreach (glpichat_desktop_db_rows('SELECT name,rights FROM glpi_profilerights WHERE profiles_id=' . $profileId
        . " AND name IN ('plugin_glpichat_public','ticket','followup')" . $lock) as $right) {
        $name = (string) $right['name'];
        if (isset($rights[$name])) {
            glpichat_desktop_auth_unavailable(); // Ambiguous rights are not merged.
        }
        $rights[$name] = (int) $right['rights'];
    }
    foreach (['READ', 'CREATE', 'Ticket::READMY', 'ITILFollowup::SEEPUBLIC', 'ITILFollowup::ADDMY', 'ITILFollowup::ADDALLITEM'] as $constant) {
        if (!defined($constant)) {
            glpichat_desktop_fail('unsupported_rights', 'Esta versão do GLPI requer qualificação antes do uso do aplicativo.', 503);
        }
    }
    $read = (int) constant('READ');
    $create = (int) constant('CREATE');
    $ticketReadOwn = (int) constant('Ticket::READMY');
    $followupReadPublic = (int) constant('ITILFollowup::SEEPUBLIC');
    if (($rights['plugin_glpichat_public'] ?? 0) & $read) {
        $publicRead = true;
    } else {
        $publicRead = false;
    }
    if (!$publicRead || (($rights['ticket'] ?? 0) & $ticketReadOwn) === 0
        || (($rights['followup'] ?? 0) & $followupReadPublic) === 0) {
        glpichat_desktop_auth_unavailable();
    }
    $nativeCreateMask = 0;
    foreach (['ITILFollowup::ADDMY', 'ITILFollowup::ADDALLITEM'] as $constant) {
        if (defined($constant)) {
            $nativeCreateMask |= (int) constant($constant);
        }
    }
    $sourceFacts = [];
    foreach (['id', 'date_creation', 'host', 'port', 'basedn', 'login_field', 'sync_field', 'condition'] as $field) {
        $sourceFacts[$field] = (string) ($source[$field] ?? '');
    }
    $name = trim((string) ($user['firstname'] ?? '') . ' ' . (string) ($user['realname'] ?? ''));
    return [
        'user_id' => $userId,
        'profile_id' => $profileId,
        'entity_id' => $entityId,
        'auths_id' => $sourceId,
        // Preserve exact source bytes, including binary objectGUID storage.
        'sync_anchor' => glpichat_desktop_auth_hash('directory-anchor', $sync),
        'user_incarnation' => glpichat_desktop_auth_hash('user-incarnation', $created . "\0" . $authType),
        'auth_source_fingerprint' => glpichat_desktop_auth_hash('source', serialize($sourceFacts)),
        'name' => $name !== '' ? $name : (string) $user['name'],
        'login' => (string) $user['name'],
        'can_read' => true,
        'can_create' => (($rights['plugin_glpichat_public'] ?? 0) & $create) !== 0
            && (($rights['followup'] ?? 0) & $nativeCreateMask) !== 0,
        'followup_rights' => $rights['followup'] ?? 0,
    ];
}

/** Pure comparison shared by enrollment replay and current-binding validation. */
function glpichat_desktop_auth_binding_matches(array $row, array $facts): bool
{
    foreach (['auths_id' => 'auths_id', 'users_id' => 'user_id', 'profiles_id' => 'profile_id', 'entities_id' => 'entity_id'] as $stored => $current) {
        if (!isset($row[$stored], $facts[$current]) || (int) $row[$stored] !== (int) $facts[$current]) {
            return false;
        }
    }
    foreach (['sync_anchor', 'user_incarnation', 'auth_source_fingerprint'] as $field) {
        if (!isset($row[$field], $facts[$field]) || $row[$field] === ''
            || !hash_equals((string) $row[$field], (string) $facts[$field])) {
            return false;
        }
    }
    // A directory rename must not retarget or invalidate the immutable binding.
    // Windows login matching is checked only at explicit browser approval.
    return true;
}

function glpichat_desktop_auth_from_row(array $row, bool $forUpdate = false): array
{
    if (($row['status'] ?? '') !== 'completed' || !empty($row['revoked_at'])
        || (string) ($row['token_expires_at'] ?? '') <= glpichat_desktop_now()) {
        glpichat_desktop_auth_unavailable();
    }
    $facts = glpichat_desktop_auth_user((int) $row['users_id'], (int) $row['profiles_id'], (int) $row['entities_id'], $forUpdate);
    if (!glpichat_desktop_auth_binding_matches($row, $facts)) {
        glpichat_desktop_auth_unavailable();
    }
    return $facts + [
        'device_db_id' => (int) $row['id'],
        'device_id' => (string) $row['device_id'],
        'expires_at' => (string) $row['token_expires_at'],
    ];
}

function glpichat_desktop_validate_actor(array $actor, bool $forUpdate = false): array
{
    glpichat_desktop_auth_available();
    $id = (int) ($actor['device_db_id'] ?? 0);
    if ($id < 1) {
        glpichat_desktop_auth_unavailable();
    }
    $row = glpichat_desktop_auth_one('SELECT * FROM ' . GLPICHAT_DESKTOP_DEVICES_TABLE . ' WHERE id=' . $id
        . ' LIMIT 1' . ($forUpdate ? ' FOR UPDATE' : ''));
    $current = glpichat_desktop_auth_from_row($row, $forUpdate);
    foreach (['user_id', 'profile_id', 'entity_id', 'device_db_id'] as $key) {
        if (!isset($actor[$key]) || (int) $actor[$key] !== $current[$key]) {
            glpichat_desktop_auth_unavailable();
        }
    }
    return $current;
}

function glpichat_desktop_revalidate_actor(array $actor, bool $forUpdate = false): array
{
    return glpichat_desktop_validate_actor($actor, $forUpdate);
}

function glpichat_desktop_authenticate(string $bearer): array
{
    glpichat_desktop_auth_available();
    if (!glpichat_desktop_auth_hex($bearer)) {
        glpichat_desktop_auth_unavailable();
    }
    $hash = glpichat_desktop_auth_hash('bearer', $bearer);
    $row = glpichat_desktop_auth_one('SELECT * FROM ' . GLPICHAT_DESKTOP_DEVICES_TABLE
        . ' WHERE token_hash=' . glpichat_desktop_quote($hash) . ' LIMIT 1');
    if (!$row || !hash_equals((string) $row['token_hash'], $hash)) {
        glpichat_desktop_auth_unavailable();
    }
    return glpichat_desktop_auth_from_row($row);
}

/**
 * Client-local state belongs to this account incarnation, not a recyclable
 * numeric GLPI user id. Display names, profiles, entities and device credentials
 * are deliberately excluded so legitimate rename/reapproval retains drafts.
 */
function glpichat_desktop_subject_id(array $actor): string
{
    $userId = (int) ($actor['user_id'] ?? 0);
    if ($userId < 1) {
        glpichat_desktop_auth_unavailable();
    }
    $parts = [(string) $userId];
    foreach (['sync_anchor', 'user_incarnation', 'auth_source_fingerprint'] as $field) {
        if (!isset($actor[$field]) || !is_string($actor[$field]) || !glpichat_desktop_auth_hex($actor[$field])) {
            glpichat_desktop_auth_unavailable();
        }
        $parts[] = $actor[$field];
    }
    return glpichat_desktop_auth_hash('principal-subject', implode("\0", $parts));
}

function glpichat_desktop_identity(array $actor): array
{
    return [
        'user' => ['id' => $actor['user_id'], 'subject_id' => glpichat_desktop_subject_id($actor),
            'name' => $actor['name'], 'login' => $actor['login'],
            'profile_id' => $actor['profile_id'], 'entity_id' => $actor['entity_id']],
        'device' => ['id' => $actor['device_db_id'], 'device_id' => $actor['device_id'],
            'expires_at' => gmdate('Y-m-d\TH:i:s\Z', glpichat_desktop_auth_timestamp($actor['expires_at']))],
        'api_version' => 1,
    ];
}

function glpichat_desktop_pair_start(array $input, string $ip): array
{
    glpichat_desktop_auth_available();
    foreach (['device_id', 'device_name', 'windows_login', 'poll_secret'] as $field) {
        if (!isset($input[$field]) || !is_string($input[$field])) {
            glpichat_desktop_fail('invalid_pairing', 'Dados de conexão inválidos.', 400);
        }
    }
    $deviceId = strtolower((string) ($input['device_id'] ?? ''));
    $name = trim((string) ($input['device_name'] ?? ''));
    $login = trim((string) ($input['windows_login'] ?? ''));
    $secret = (string) ($input['poll_secret'] ?? '');
    if (!preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/D', $deviceId)
        || $name === '' || strlen($name) > 100 || preg_match('/[\x00-\x1f\x7f]/', $name)
        || glpichat_desktop_normalize_login($login) === '' || !glpichat_desktop_auth_hex($secret)) {
        glpichat_desktop_fail('invalid_pairing', 'Verifique os dados do computador e tente novamente.', 400);
    }
    // One short admission lock closes concurrent COUNT/INSERT rate-cap races.
    $lease = glpichat_desktop_auth_one("SELECT GET_LOCK('glpichat.desktop.pair.v1',0) AS acquired");
    if ((int) ($lease['acquired'] ?? 0) !== 1) {
        glpichat_desktop_fail('pairing_busy', 'Aguarde alguns segundos e tente novamente.', 429);
    }
    try {
        $table = GLPICHAT_DESKTOP_DEVICES_TABLE;
        $now = glpichat_desktop_now();
        $nowTimestamp = glpichat_desktop_auth_timestamp($now);
        $cutoff = gmdate('Y-m-d H:i:s', $nowTimestamp - 600);
        $old = gmdate('Y-m-d H:i:s', $nowTimestamp - 86400);
        // Never delete completed/revoked credentials or current replay evidence.
        glpichat_desktop_auth_sql('DELETE FROM ' . $table . " WHERE status IN ('pending','approved') AND pairing_expires_at<"
            . glpichat_desktop_quote($old) . ' ORDER BY pairing_expires_at,id LIMIT 100');
        $ipHash = glpichat_desktop_auth_hash('pairing-ip', substr($ip, 0, 64));
        $count = glpichat_desktop_auth_one('SELECT COUNT(*) AS n FROM ' . $table . ' WHERE request_ip_hash='
            . glpichat_desktop_quote($ipHash) . ' AND created_at>=' . glpichat_desktop_quote($cutoff));
        $active = glpichat_desktop_auth_one('SELECT COUNT(*) AS n FROM ' . $table
            . " WHERE status IN ('pending','approved') AND pairing_expires_at>" . glpichat_desktop_quote($now));
        if ((int) ($count['n'] ?? 0) >= 20 || (int) ($active['n'] ?? 0) >= 1000) {
            glpichat_desktop_fail('pairing_rate_limited', 'Muitas solicitações. Aguarde e tente novamente.', 429);
        }
        $id = bin2hex(random_bytes(16));
        $code = strtoupper(substr($id, 0, 4) . '-' . substr($id, 4, 4));
        $expires = gmdate('Y-m-d H:i:s', $nowTimestamp + 600);
        global $DB;
        if (!$DB->insert($table, [
            'pairing_id' => $id, 'poll_secret_hash' => glpichat_desktop_auth_hash('poll-secret', $secret),
            'device_id' => $deviceId, 'device_name' => $name, 'windows_login' => $login,
            'request_ip_hash' => $ipHash, 'user_code' => $code, 'status' => 'pending',
            'created_at' => $now, 'pairing_expires_at' => $expires,
        ])) {
            glpichat_desktop_fail('pairing_unavailable', 'Não foi possível iniciar a conexão.', 503);
        }
        return ['pairing_id' => $id, 'user_code' => $code,
            'verification_uri' => glpichat_desktop_base_url() . '/plugins/glpichat/front/desktop.php?pairing=' . $id,
            'expires_in' => 600, 'poll_interval' => 5];
    } finally {
        // Release is attempted even on failed admission; no secret is in SQL/logs.
        glpichat_desktop_auth_one("SELECT RELEASE_LOCK('glpichat.desktop.pair.v1') AS released");
    }
}

function glpichat_desktop_pair_lookup(string $id, string $secret, bool $forUpdate = false): array
{
    glpichat_desktop_auth_available();
    if (!glpichat_desktop_auth_hex($id, 32) || !glpichat_desktop_auth_hex($secret)) {
        glpichat_desktop_fail('pairing_unavailable', 'Solicitação de conexão indisponível.', 404);
    }
    $row = glpichat_desktop_auth_one('SELECT * FROM ' . GLPICHAT_DESKTOP_DEVICES_TABLE . ' WHERE pairing_id='
        . glpichat_desktop_quote($id) . ' LIMIT 1' . ($forUpdate ? ' FOR UPDATE' : ''));
    if (!$row || !hash_equals((string) $row['poll_secret_hash'], glpichat_desktop_auth_hash('poll-secret', $secret))
        || !in_array($row['status'], ['pending', 'approved', 'completed'], true) || !empty($row['revoked_at'])) {
        glpichat_desktop_fail('pairing_unavailable', 'Solicitação de conexão indisponível.', 404);
    }
    if ((string) $row['pairing_expires_at'] <= glpichat_desktop_now()) {
        glpichat_desktop_fail('pairing_expired', 'A solicitação expirou. Inicie uma nova conexão.', 410);
    }
    return $row;
}

function glpichat_desktop_pair_status(string $id, string $secret): array
{
    $row = glpichat_desktop_pair_lookup($id, $secret);
    return ['status' => $row['status'], 'expires_in' => max(0,
        glpichat_desktop_auth_timestamp($row['pairing_expires_at']) - glpichat_desktop_auth_timestamp(glpichat_desktop_now()))];
}

function glpichat_desktop_pair_exchange(string $id, string $secret, string $token): array
{
    if (!glpichat_desktop_auth_hex($token) || hash_equals($secret, $token)) {
        glpichat_desktop_fail('invalid_token', 'Credencial de conexão inválida.', 400);
    }
    return glpichat_desktop_transaction(static function () use ($id, $secret, $token): array {
        $row = glpichat_desktop_pair_lookup($id, $secret, true);
        $tokenHash = glpichat_desktop_auth_hash('bearer', $token);
        if ($row['status'] === 'pending') {
            glpichat_desktop_fail('authorization_pending', 'Confirme a conexão no GLPI.', 409);
        }
        if ($row['status'] === 'completed') {
            if (!hash_equals((string) $row['token_hash'], $tokenHash)) {
                glpichat_desktop_fail('pairing_consumed', 'A solicitação já foi utilizada.', 409);
            }
            return glpichat_desktop_identity(glpichat_desktop_auth_from_row($row, true));
        }
        $facts = glpichat_desktop_auth_user((int) $row['users_id'], (int) $row['profiles_id'], (int) $row['entities_id'], true);
        if (!glpichat_desktop_auth_binding_matches($row, $facts)) {
            glpichat_desktop_auth_unavailable();
        }
        $expires = gmdate('Y-m-d H:i:s', glpichat_desktop_auth_timestamp(glpichat_desktop_now()) + 90 * 86400);
        global $DB;
        if (!$DB->update(GLPICHAT_DESKTOP_DEVICES_TABLE, [
            'token_hash' => $tokenHash, 'status' => 'completed', 'token_expires_at' => $expires,
        ], ['id' => (int) $row['id'], 'status' => 'approved', 'revoked_at' => null]) || $DB->affectedRows() !== 1) {
            glpichat_desktop_fail('pairing_conflict', 'A solicitação mudou. Inicie uma nova conexão.', 409);
        }
        $row['status'] = 'completed';
        $row['token_hash'] = $tokenHash;
        $row['token_expires_at'] = $expires;
        return glpichat_desktop_identity(glpichat_desktop_auth_from_row($row, true));
    });
}

/** Only the sessionful approval page calls this; no client user id is accepted. */
function glpichat_desktop_pair_approve(string $pairingId, int $userId, int $profileId, int $entityId): void
{
    glpichat_desktop_auth_available();
    if (!glpichat_desktop_auth_hex($pairingId, 32)) {
        glpichat_desktop_fail('pairing_unavailable', 'Solicitação indisponível.', 404);
    }
    glpichat_desktop_transaction(static function () use ($pairingId, $userId, $profileId, $entityId): void {
        $row = glpichat_desktop_auth_one('SELECT * FROM ' . GLPICHAT_DESKTOP_DEVICES_TABLE . ' WHERE pairing_id='
            . glpichat_desktop_quote($pairingId) . ' LIMIT 1 FOR UPDATE');
        if (!$row || !in_array($row['status'], ['pending', 'approved'], true)
            || (string) $row['pairing_expires_at'] <= glpichat_desktop_now() || !empty($row['revoked_at'])) {
            glpichat_desktop_fail('pairing_unavailable', 'Solicitação indisponível ou expirada.', 404);
        }
        $facts = glpichat_desktop_auth_user($userId, $profileId, $entityId, true);
        if (glpichat_desktop_normalize_login((string) $row['windows_login']) !== glpichat_desktop_normalize_login($facts['login'])) {
            glpichat_desktop_fail('account_mismatch', 'Entre no GLPI com a mesma conta exibida pelo aplicativo.', 403);
        }
        if ($row['status'] === 'approved') {
            if (!glpichat_desktop_auth_binding_matches($row, $facts)) {
                glpichat_desktop_fail('pairing_unavailable', 'Solicitação indisponível.', 404);
            }
            return; // Identical confirmation retry does not change the actor/context.
        }
        global $DB;
        if (!$DB->update(GLPICHAT_DESKTOP_DEVICES_TABLE, [
            'status' => 'approved', 'users_id' => $userId, 'profiles_id' => $profileId, 'entities_id' => $entityId,
            'auths_id' => $facts['auths_id'], 'sync_anchor' => $facts['sync_anchor'],
            'user_incarnation' => $facts['user_incarnation'], 'auth_source_fingerprint' => $facts['auth_source_fingerprint'],
            'approved_at' => glpichat_desktop_now(),
        ], ['id' => (int) $row['id'], 'status' => 'pending']) || $DB->affectedRows() !== 1) {
            glpichat_desktop_fail('pairing_conflict', 'A solicitação mudou. Tente novamente.', 409);
        }
    });
}

function glpichat_desktop_revoke_user_device(int $deviceId, int $userId): void
{
    glpichat_desktop_require_schema();
    if ($deviceId < 1 || $userId < 1) {
        glpichat_desktop_fail('device_unavailable', 'Dispositivo indisponível.', 404);
    }
    global $DB;
    if (!$DB->update(GLPICHAT_DESKTOP_DEVICES_TABLE, ['status' => 'revoked', 'revoked_at' => glpichat_desktop_now()],
        ['id' => $deviceId, 'users_id' => $userId])) {
        glpichat_desktop_fail('storage_unavailable', 'Não foi possível revogar a conexão.', 503);
    }
}

function glpichat_desktop_revoke(array $actor): void
{
    glpichat_desktop_revoke_user_device((int) $actor['device_db_id'], (int) $actor['user_id']);
}
