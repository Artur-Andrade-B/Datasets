<?php

declare(strict_types=1);

use Symfony\Component\HttpFoundation\Request;

/** Desktop1 is an explicitly enabled, requester-only pilot adapter. */
final class GlpichatDesktopException extends RuntimeException
{
    public function __construct(public readonly string $errorCode, string $message, public readonly int $httpStatus)
    {
        parent::__construct($message, $httpStatus);
    }
}

function glpichat_desktop_fail(string $code, string $message, int $status): never
{
    throw new GlpichatDesktopException($code, $message, $status);
}

function glpichat_desktop_now(): string
{
    return gmdate('Y-m-d H:i:s');
}

function glpichat_desktop_enabled(): bool
{
    return (string) Config::getConfigurationValue('plugin:glpichat', 'desktop_enabled') === '1';
}

function glpichat_desktop_base_url(): string
{
    global $CFG_GLPI;
    $url = rtrim((string) ($CFG_GLPI['url_base'] ?? ''), '/');
    $parts = parse_url($url);
    if (!is_array($parts) || ($parts['scheme'] ?? '') !== 'https'
        || empty($parts['host']) || isset($parts['user']) || isset($parts['pass'])
        || isset($parts['query']) || isset($parts['fragment']) || preg_match('/[\x00-\x20\\\\]/', $url)) {
        glpichat_desktop_fail('configuration_required', 'Configure a URL HTTPS oficial do GLPI.', 503);
    }
    return $url;
}

/** Cheap request gate. Full structural readback runs at lifecycle/admin time. */
function glpichat_desktop_require_schema(): void
{
    $version = (string) Config::getConfigurationValue('plugin:glpichat', 'desktop_schema_version');
    $key = (string) Config::getConfigurationValue('plugin:glpichat', 'desktop_idempotency_key');
    if ($version !== '1' || preg_match('/\A[a-f0-9]{64}\z/D', $key) !== 1) {
        glpichat_desktop_fail('schema_unavailable', 'Conclua a atualização do plugin antes de usar o aplicativo.', 503);
    }
}

function glpichat_desktop_request_guard(Request $request): void
{
    if (!glpichat_desktop_enabled()) {
        glpichat_desktop_fail('unavailable', 'Aplicativo de desktop indisponível.', 404);
    }
    if (!$request->isSecure()) {
        glpichat_desktop_fail('https_required', 'A conexão exige HTTPS.', 400);
    }
    // This adapter never accepts a browser cookie as authorization. Pairing
    // approval is a separate normal GLPI page with session and CSRF checks.
    if ($request->headers->has('Origin') || $request->cookies->count() > 0) {
        glpichat_desktop_fail('desktop_client_required', 'Use o aplicativo para esta operação.', 403);
    }
    if ($request->headers->has('X-HTTP-Method-Override')) {
        glpichat_desktop_fail('invalid_request', 'Método inválido.', 400);
    }
    glpichat_desktop_base_url();
    glpichat_desktop_require_schema();
}

function glpichat_desktop_json_body(Request $request): array
{
    $type = strtolower(trim(explode(';', (string) $request->headers->get('Content-Type', ''))[0]));
    if ($type !== 'application/json') {
        glpichat_desktop_fail('json_required', 'Envie uma solicitação JSON.', 415);
    }
    $advertised = (int) $request->headers->get('Content-Length', '0');
    if ($advertised > 32768) {
        glpichat_desktop_fail('request_too_large', 'Solicitação muito grande.', 413);
    }
    $stream = $request->getContent(true);
    $raw = is_resource($stream) ? stream_get_contents($stream, 32769) : false;
    if (!is_string($raw) || strlen($raw) > 32768) {
        glpichat_desktop_fail('request_too_large', 'Solicitação muito grande.', 413);
    }
    try {
        $object = json_decode($raw, false, 16, JSON_THROW_ON_ERROR);
    } catch (JsonException $e) {
        glpichat_desktop_fail('invalid_json', 'JSON inválido.', 400);
    }
    if (!$object instanceof stdClass) {
        glpichat_desktop_fail('invalid_json', 'O corpo deve ser um objeto JSON.', 400);
    }
    return json_decode($raw, true, 16, JSON_THROW_ON_ERROR);
}

function glpichat_desktop_string(array $input, string $key, int $maxBytes = 4000): string
{
    if (!isset($input[$key]) || !is_string($input[$key]) || strlen($input[$key]) > $maxBytes) {
        glpichat_desktop_fail('invalid_request', 'Parâmetro inválido: ' . $key . '.', 400);
    }
    return $input[$key];
}

function glpichat_desktop_bearer(Request $request): string
{
    $value = (string) $request->headers->get('Authorization', '');
    if (preg_match('/\ABearer ([a-f0-9]{64})\z/D', $value, $matches) !== 1) {
        glpichat_desktop_fail('invalid_credential', 'Conecte sua conta novamente.', 401);
    }
    return $matches[1];
}

function glpichat_desktop_quote(string $value): string
{
    global $DB;
    return "'" . $DB->escape($value) . "'";
}

/** Database exceptions are converted to a non-sensitive error by controller. */
function glpichat_desktop_db_rows(string $sql): array
{
    global $DB;
    $result = $DB->doQuery($sql);
    if ($result === false || $result === true) {
        throw new RuntimeException('Desktop select failed.');
    }
    $rows = [];
    while ($row = $DB->fetchAssoc($result)) {
        $rows[] = $row;
    }
    if (method_exists($result, 'free')) {
        $result->free();
    }
    return $rows;
}

/** GLPI11 DBmysql transaction methods return void. Never nest transactions. */
function glpichat_desktop_transaction(callable $action): mixed
{
    global $DB;
    if ($DB->isInTransaction()) {
        throw new RuntimeException('Desktop operation refuses nested transaction.');
    }
    $DB->beginTransaction();
    try {
        $result = $action();
        $DB->commit();
        return $result;
    } catch (Throwable $error) {
        try {
            $DB->rollBack();
        } catch (Throwable $rollbackError) {
            error_log('glpichat desktop: rollback failed; request terminated.');
        }
        throw $error;
    }
}

