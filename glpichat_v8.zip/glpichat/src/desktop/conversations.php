<?php

declare(strict_types=1);

/**
 * Desktop text pilot. Native public ITILFollowup rows are the readable source.
 * No browser Session actor is fabricated. These functions receive a freshly
 * authenticated actor and revalidate it within every mutation transaction.
 */

function glpichat_desktop_text(string $html, int $maxCharacters = 16000): string
{
    // Bounds apply before DOM/regex processing, including malicious native HTML.
    if (strlen($html) > 262144 || preg_match('//u', $html) !== 1) {
        return 'Conteúdo disponível no GLPI.';
    }
    $html = preg_replace('~<(script|style|iframe|object|svg|math|template)\b[^>]*>.*?</\1\s*>~isu', '', $html) ?? '';
    $html = preg_replace('~<!--.*?-->~su', '', $html) ?? '';
    $html = preg_replace('~<(?:br\b[^>]*|/(?:p|div|li|tr|h[1-6]|pre|blockquote)\s*)>~iu', "\n", $html) ?? '';
    $text = html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = str_replace(["\r\n", "\r"], "\n", $text);
    $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F\x{202A}-\x{202E}\x{2066}-\x{2069}]/u', '', $text) ?? '';
    // Preserve internal whitespace exactly: submitted plain text is escaped to
    // HTML once, and idempotent replay must compare that lossless inverse.
    $text = trim($text);
    if ($text === '') {
        return 'Conteúdo disponível no GLPI.';
    }
    if (mb_strlen($text, 'UTF-8') > $maxCharacters) {
        return mb_substr($text, 0, $maxCharacters, 'UTF-8') . "\n[Continue a leitura no GLPI.]";
    }
    return $text;
}

function glpichat_desktop_normalize_message(string $content): string
{
    if (strlen($content) > 16000 || preg_match('//u', $content) !== 1) {
        glpichat_desktop_fail('invalid_content', 'A mensagem deve conter texto UTF-8 de até 4000 caracteres.', 400);
    }
    $content = str_replace(["\r\n", "\r"], "\n", $content);
    if (class_exists('Normalizer')) {
        $normalized = Normalizer::normalize($content, Normalizer::FORM_C);
        if (!is_string($normalized)) {
            glpichat_desktop_fail('invalid_content', 'Texto inválido.', 400);
        }
        $content = $normalized;
    }
    if (preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F\x{202A}-\x{202E}\x{2066}-\x{2069}]/u', $content)) {
        glpichat_desktop_fail('invalid_content', 'O texto contém caracteres de controle não permitidos.', 400);
    }
    $content = preg_replace('/^\s+|\s+$/u', '', $content) ?? '';
    if ($content === '' || mb_strlen($content, 'UTF-8') > 4000) {
        glpichat_desktop_fail('invalid_content', 'A mensagem deve conter de 1 a 4000 caracteres.', 400);
    }
    return $content;
}

/** This predicate is shared by History, unread metadata, replay and exact-ID Read. */
function glpichat_desktop_public_followup_predicate(string $alias = 'f'): string
{
    // Only a compiled alias is accepted; never a route/body value.
    if ($alias !== 'f') {
        throw new LogicException('Unsupported followup alias.');
    }
    return "f.itemtype = 'Ticket' AND f.is_private = 0 AND NOT EXISTS ("
        . 'SELECT 1 FROM glpi_plugin_glpichat_messages gm '
        . 'LEFT JOIN glpi_plugin_glpichat_rooms gr ON gr.id = gm.rooms_id '
        . 'WHERE gm.itilfollowups_id = f.id AND ('
        . 'gm.documents_id <> 0 OR gm.tickets_id <> f.items_id OR gr.id IS NULL '
        . 'OR gr.tickets_id <> f.items_id OR BINARY gr.room_type <> BINARY \'public\' '
        . "OR BINARY gm.participant_type <> BINARY 'user' "
        . "OR BINARY gm.message_type NOT IN (BINARY 'message', BINARY 'text')))";
}

function glpichat_desktop_ticket(array $actor, int $ticketId, bool $lock = false): array
{
    if ($ticketId <= 0 || (int) ($actor['user_id'] ?? 0) <= 0 || empty($actor['can_read'])) {
        glpichat_desktop_fail('conversation_unavailable', 'Conversa indisponível.', 404);
    }
    $userId = (int) $actor['user_id'];
    $entityId = (int) $actor['entity_id'];
    // Explicit locks cover the ticket and direct requester row on mutation.
    $rows = glpichat_desktop_db_rows('SELECT id, name, status, entities_id FROM glpi_tickets '
        . "WHERE id = $ticketId AND entities_id = $entityId AND is_deleted = 0 AND is_template = 0 AND status IN (1,2,3,4,5,6)"
        . ($lock ? ' FOR UPDATE' : ''));
    if (!$rows) {
        glpichat_desktop_fail('conversation_unavailable', 'Conversa indisponível.', 404);
    }
    $requesters = glpichat_desktop_db_rows('SELECT id FROM glpi_tickets_users '
        . "WHERE tickets_id = $ticketId AND users_id = $userId AND type = 1 LIMIT 1"
        . ($lock ? ' FOR UPDATE' : ''));
    if (!$requesters) {
        glpichat_desktop_fail('conversation_unavailable', 'Conversa indisponível.', 404);
    }
    return $rows[0];
}

function glpichat_desktop_ticket_output(array $actor, array $ticket): array
{
    return [
        'ticket_id' => (int) $ticket['id'],
        'title' => glpichat_desktop_text((string) $ticket['name'], 250),
        'status' => (int) $ticket['status'],
        'can_send' => !empty($actor['can_create']) && in_array((int) $ticket['status'], [1, 2, 3, 4], true),
    ];
}

function glpichat_desktop_conversations(array $actor, int $before, int $limit): array
{
    $actor = glpichat_desktop_validate_actor($actor);
    $limit = max(1, min(30, $limit));
    $userId = (int) $actor['user_id'];
    $entityId = (int) $actor['entity_id'];
    $beforeSql = $before > 0 ? ' AND t.id < ' . $before : '';
    $tickets = glpichat_desktop_db_rows('SELECT t.id, t.name, t.status, t.entities_id FROM glpi_tickets t '
        . "WHERE t.entities_id = $entityId AND t.is_deleted = 0 AND t.is_template = 0 AND t.status IN (1,2,3,4,5,6)"
        . $beforeSql . ' AND EXISTS (SELECT 1 FROM glpi_tickets_users tu '
        . "WHERE tu.tickets_id = t.id AND tu.users_id = $userId AND tu.type = 1) "
        . 'ORDER BY t.id DESC LIMIT ' . ($limit + 1));
    $hasMore = count($tickets) > $limit;
    $tickets = array_slice($tickets, 0, $limit);
    $summaryByTicket = [];
    if ($tickets) {
        $ticketIds = implode(',', array_map(static fn(array $row): int => (int) $row['id'], $tickets));
        // Aggregate metadata only, never fetch a ticket's entire body history.
        // count:sum:max is a change hint, not a cursor or cryptographic set proof.
        $unread = "(f.users_id <> $userId AND dr.id IS NULL)";
        $summaries = glpichat_desktop_db_rows('SELECT f.items_id, MAX(f.id) AS latest_message_id, '
            . "SUM(CASE WHEN $unread THEN 1 ELSE 0 END) AS unread_count, "
            . "SUM(CASE WHEN $unread THEN f.id ELSE 0 END) AS unread_sum, "
            . "MAX(CASE WHEN $unread THEN f.id ELSE 0 END) AS unread_max "
            . 'FROM glpi_itilfollowups f LEFT JOIN glpi_plugin_glpichat_desktopreads dr '
            . "ON dr.itilfollowups_id = f.id AND dr.users_id = $userId "
            . "WHERE f.items_id IN ($ticketIds) AND " . glpichat_desktop_public_followup_predicate()
            . ' GROUP BY f.items_id');
        foreach ($summaries as $summary) {
            $summaryByTicket[(int) $summary['items_id']] = $summary;
        }
    }
    $output = [];
    foreach ($tickets as $ticket) {
        $summary = $summaryByTicket[(int) $ticket['id']] ?? [];
        $count = (int) ($summary['unread_count'] ?? 0);
        $output[] = glpichat_desktop_ticket_output($actor, $ticket) + [
            'unread_count' => $count,
            'unread_revision' => $count . ':' . (string) ($summary['unread_sum'] ?? '0') . ':' . (string) ($summary['unread_max'] ?? '0'),
            'latest_message_id' => (int) ($summary['latest_message_id'] ?? 0),
        ];
    }
    return [
        'conversations' => $output,
        'next_before' => $hasMore && $tickets ? (int) $tickets[count($tickets) - 1]['id'] : 0,
        'has_more' => $hasMore,
    ];
}

function glpichat_desktop_message_output(array $actor, array $followup): array
{
    $author = trim((string) ($followup['firstname'] ?? '') . ' ' . (string) ($followup['realname'] ?? ''));
    if ($author === '') {
        $author = (string) ($followup['author_login'] ?? '');
    }
    return [
        'id' => (int) $followup['id'],
        'author_id' => (int) $followup['users_id'],
        'author_name' => $author !== '' ? glpichat_desktop_text($author, 150) : 'Usuário GLPI',
        'content' => glpichat_desktop_text((string) $followup['content']),
        'created_at' => (string) $followup['date'],
        'own' => (int) $followup['users_id'] === (int) $actor['user_id'],
    ];
}

function glpichat_desktop_followup_select(): string
{
    // Avoid transferring unbounded native HTML from the database to PHP.
    return 'SELECT f.id, f.items_id, f.users_id, f.date, '
        . "CASE WHEN OCTET_LENGTH(f.content) <= 262144 THEN f.content ELSE '' END AS content, "
        . 'u.name AS author_login, u.firstname, u.realname FROM glpi_itilfollowups f '
        . 'LEFT JOIN glpi_users u ON u.id = f.users_id ';
}

function glpichat_desktop_history(array $actor, int $ticketId, int $before, int $limit): array
{
    $actor = glpichat_desktop_validate_actor($actor);
    $ticket = glpichat_desktop_ticket($actor, $ticketId);
    $limit = max(1, min(50, $limit));
    $rows = glpichat_desktop_db_rows(glpichat_desktop_followup_select()
        . "WHERE f.items_id = $ticketId AND " . glpichat_desktop_public_followup_predicate()
        . ($before > 0 ? " AND f.id < $before" : '')
        . ' ORDER BY f.id DESC LIMIT ' . ($limit + 1));
    $hasMore = count($rows) > $limit;
    $rows = array_slice($rows, 0, $limit);
    $oldest = $rows ? (int) $rows[count($rows) - 1]['id'] : 0;
    return [
        'ticket' => glpichat_desktop_ticket_output($actor, $ticket),
        'messages' => array_map(static fn(array $row): array => glpichat_desktop_message_output($actor, $row), array_reverse($rows)),
        'next_before' => $hasMore ? $oldest : 0,
        'has_more' => $hasMore,
    ];
}

function glpichat_desktop_payload_hash(int $ticketId, string $content): string
{
    $key = (string) Config::getConfigurationValue('plugin:glpichat', 'desktop_idempotency_key');
    if (preg_match('/^[0-9a-f]{64}$/D', $key) !== 1) {
        glpichat_desktop_fail('desktop_unavailable', 'Execute a atualização do plugin antes de enviar.', 503);
    }
    return hash_hmac('sha256', "glpichat-desktop-send-v1\0" . $ticketId . "\0" . $content, hex2bin($key));
}

function glpichat_desktop_send(array $actor, int $ticketId, string $uuid, string $content): array
{
    global $DB;

    $uuid = strtolower($uuid);
    if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/D', $uuid) !== 1) {
        glpichat_desktop_fail('invalid_message_id', 'Identificador de mensagem inválido.', 400);
    }
    $content = glpichat_desktop_normalize_message($content);
    $hash = glpichat_desktop_payload_hash($ticketId, $content);
    $created = false;
    $result = glpichat_desktop_transaction(function () use ($actor, $ticketId, $uuid, $content, $hash, &$created): array {
        global $DB;
        $actor = glpichat_desktop_validate_actor($actor, true);
        $ticket = glpichat_desktop_ticket($actor, $ticketId, true);
        $userId = (int) $actor['user_id'];
        $uuidSql = glpichat_desktop_quote($uuid);
        $receipts = glpichat_desktop_db_rows('SELECT id, tickets_id, payload_hash, itilfollowups_id '
            . 'FROM glpi_plugin_glpichat_desktopsends '
            . "WHERE users_id = $userId AND client_message_id = $uuidSql FOR UPDATE");
        if ($receipts) {
            $receipt = $receipts[0];
            if ((int) $receipt['tickets_id'] !== $ticketId || !hash_equals((string) $receipt['payload_hash'], $hash)) {
                glpichat_desktop_fail('idempotency_conflict', 'Este identificador já pertence a outra mensagem.', 409);
            }
            $followupId = (int) $receipt['itilfollowups_id'];
            $rows = glpichat_desktop_db_rows(glpichat_desktop_followup_select()
                . "WHERE f.id = $followupId AND f.items_id = $ticketId AND "
                . glpichat_desktop_public_followup_predicate() . ' LIMIT 1 FOR UPDATE');
            if (!$rows || (int) $rows[0]['users_id'] !== $userId) {
                glpichat_desktop_fail('message_unavailable', 'A mensagem enviada não está mais disponível.', 409);
            }
            $currentContent = glpichat_desktop_text((string) $rows[0]['content']);
            if (!hash_equals($hash, glpichat_desktop_payload_hash($ticketId, $currentContent))) {
                glpichat_desktop_fail('message_changed', 'A mensagem já foi enviada e alterada no GLPI. Atualize a conversa.', 409);
            }
            return ['message' => glpichat_desktop_message_output($actor, $rows[0]), 'client_message_id' => $uuid];
        }
        if (empty($actor['can_create']) || !in_array((int) $ticket['status'], [1, 2, 3, 4], true)) {
            glpichat_desktop_fail('conversation_read_only', 'Esta conversa está disponível somente para leitura.', 403);
        }
        // Core addToMergedTickets can fan out a followup; this pilot never does.
        if (Ticket::getMergedTickets($ticketId) !== []) {
            glpichat_desktop_fail('conversation_merge_unsupported', 'Envie este acompanhamento pela interface do GLPI.', 409);
        }
        $now = glpichat_desktop_now();
        $recent = glpichat_desktop_db_rows('SELECT COUNT(*) AS n FROM glpi_plugin_glpichat_desktopsends '
            . "WHERE users_id = $userId AND created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 1 MINUTE)");
        if ((int) ($recent[0]['n'] ?? 0) >= 30) {
            glpichat_desktop_fail('send_throttled', 'Aguarde um minuto antes de enviar novas mensagens.', 429);
        }
        $requestTypes = glpichat_desktop_db_rows('SELECT id FROM glpi_requesttypes '
            . "WHERE BINARY name = BINARY 'GLPI Chat' AND is_active = 1 AND is_itilfollowup = 1 ORDER BY id LIMIT 2");
        if (count($requestTypes) !== 1) {
            glpichat_desktop_fail('request_type_unavailable', 'A origem GLPI Chat precisa ser configurada pelo administrador.', 503);
        }
        if (!$DB->insert('glpi_plugin_glpichat_desktopsends', [
            'users_id' => $userId, 'client_message_id' => $uuid, 'tickets_id' => $ticketId,
            'payload_hash' => $hash, 'itilfollowups_id' => null, 'created_at' => $now,
        ])) {
            throw new RuntimeException('Desktop send receipt insert failed.');
        }
        $receiptId = (int) $DB->insertId();
        $followup = new ITILFollowup();
        // Use GLPI's real followup writer, explicit actor/time, escaped plain text.
        // No user/profile/entity is installed in $_SESSION. The native add
        // notification is suppressed; the plugin notification is post-commit.
        $nativeTime = date('Y-m-d H:i:s');
        $followupId = (int) $followup->add([
            'itemtype' => Ticket::class, 'items_id' => $ticketId, 'users_id' => $userId,
            'content' => str_replace("\n", '<br>', htmlspecialchars($content, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')),
            'is_private' => 0, 'requesttypes_id' => (int) $requestTypes[0]['id'],
            'date' => $nativeTime, 'date_creation' => $nativeTime, 'date_mod' => $nativeTime,
            '_disablenotif' => true, '_no_reopen' => true,
        ]);
        if ($followupId <= 0) {
            throw new RuntimeException('Native followup insert failed.');
        }
        // A desktop device is not a browser presence participant. participants_id
        // zero is supported by the original message writer; users_id is explicit.
        $messageId = glpichat_add_message($ticketId, 'public', 'user', $userId, 0, $content, 0, $followupId, false);
        $mirror = glpichat_desktop_db_rows('SELECT id FROM glpi_plugin_glpichat_messages '
            . "WHERE id = $messageId AND itilfollowups_id = $followupId AND tickets_id = $ticketId AND users_id = $userId");
        if ($messageId <= 0 || !$mirror) {
            throw new RuntimeException('Browser message insert failed.');
        }
        if (!$DB->update('glpi_plugin_glpichat_desktopsends', ['itilfollowups_id' => $followupId], ['id' => $receiptId])) {
            throw new RuntimeException('Desktop send receipt completion failed.');
        }
        $rows = glpichat_desktop_db_rows(glpichat_desktop_followup_select()
            . "WHERE f.id = $followupId AND f.items_id = $ticketId AND "
            . glpichat_desktop_public_followup_predicate() . ' LIMIT 1');
        if (!$rows || (int) $rows[0]['users_id'] !== $userId
            || !hash_equals($hash, glpichat_desktop_payload_hash($ticketId, glpichat_desktop_text((string) $rows[0]['content'])))) {
            throw new RuntimeException('Native followup verification failed.');
        }
        $created = true;
        return ['message' => glpichat_desktop_message_output($actor, $rows[0]), 'client_message_id' => $uuid];
    });
    if ($created) {
        // Best effort once after commit. Replay never repeats this side effect.
        // Email/third-party delivery is not an exactly-once promise in this pilot.
        try {
            glpichat_desktop_transaction(function () use ($actor, $ticketId, $result, $hash, $content): void {
                $actor = glpichat_desktop_validate_actor($actor, true);
                glpichat_desktop_ticket($actor, $ticketId, true);
                $followupId = (int) $result['message']['id'];
                $rows = glpichat_desktop_db_rows(glpichat_desktop_followup_select()
                    . "WHERE f.id = $followupId AND f.items_id = $ticketId AND "
                    . glpichat_desktop_public_followup_predicate() . ' LIMIT 1 FOR UPDATE');
                if (!$rows || !hash_equals($hash, glpichat_desktop_payload_hash($ticketId, glpichat_desktop_text((string) $rows[0]['content'])))) {
                    return;
                }
                // Hold the current source row until notification queue creation
                // settles, so a privacy/content change before this phase wins.
                glpichat_raise_message_notification_event($ticketId, 'public', 'user', (int) $actor['user_id'], $content);
            });
        } catch (Throwable $ignored) {
            error_log('GLPIChat desktop: post-commit message notification failed.');
        }
    }
    return $result;
}

function glpichat_desktop_read(array $actor, int $ticketId, array $messageIds): void
{
    if (count($messageIds) > 50) {
        glpichat_desktop_fail('invalid_message_ids', 'Informe no máximo 50 mensagens.', 400);
    }
    $ids = [];
    foreach ($messageIds as $id) {
        if (!is_int($id) || $id <= 0) {
            glpichat_desktop_fail('invalid_message_ids', 'Identificador de mensagem inválido.', 400);
        }
        $ids[$id] = $id;
    }
    glpichat_desktop_transaction(function () use ($actor, $ticketId, $ids): void {
        global $DB;
        $actor = glpichat_desktop_validate_actor($actor, true);
        glpichat_desktop_ticket($actor, $ticketId, true);
        if (!$ids) {
            return;
        }
        $userId = (int) $actor['user_id'];
        $rows = glpichat_desktop_db_rows('SELECT f.id FROM glpi_itilfollowups f '
            . "WHERE f.items_id = $ticketId AND f.id IN (" . implode(',', $ids) . ') AND '
            . glpichat_desktop_public_followup_predicate() . ' FOR UPDATE');
        // A forged/private/other-ticket ID yields no write, including partial sets.
        if (count($rows) !== count($ids)) {
            glpichat_desktop_fail('message_unavailable', 'Uma mensagem não está mais disponível. Atualize a conversa.', 404);
        }
        $now = glpichat_desktop_quote(glpichat_desktop_now());
        $values = [];
        foreach ($rows as $row) {
            $values[] = '(' . $userId . ',' . (int) $row['id'] . ',' . $now . ')';
        }
        $sql = 'INSERT INTO glpi_plugin_glpichat_desktopreads (users_id,itilfollowups_id,created_at) VALUES '
            . implode(',', $values) . ' ON DUPLICATE KEY UPDATE users_id = VALUES(users_id)';
        if (!$DB->doQuery($sql)) {
            throw new RuntimeException('Desktop read-state write failed.');
        }
    });
}
