<?php

declare(strict_types=1);

require_once __DIR__ . '/common.php';
require_once __DIR__ . '/runtime.php';

const GLPICHAT_MANAGEMENT_RELEASES = 'glpi_plugin_glpichat_desktopreleases';
const GLPICHAT_MANAGEMENT_GRANTS = 'glpi_plugin_glpichat_desktopmachinegrants';
const GLPICHAT_MANAGEMENT_MACHINES = 'glpi_plugin_glpichat_desktopmachines';
const GLPICHAT_MANAGEMENT_ASSIGNMENTS = 'glpi_plugin_glpichat_desktopassignments';
const GLPICHAT_MANAGEMENT_MAX_FILE = 16777216;
const GLPICHAT_MANAGEMENT_MAX_ZIP = 34603008;

/** Machine management supports legacy schemas8/9 and current schema12. Automatic
 * user enrollment has its own stricter schema requirement. No structural scan
 * belongs on the administration page or authenticated machine polling path. */
function glpichat_management_schema_ready(): bool
{
    return in_array((string) glpichat_desktop_config('desktop_schema_version'), ['8', '9', '10', '11', '12', '13', '14', '15'], true);
}

/** Schema13 records the grant boundary independently from started acknowledgements.
 * An old pending assignment may have reached an endpoint before this upgrade. */
function glpichat_management_claims_ready(): bool
{
    return in_array((string) glpichat_desktop_config('desktop_schema_version'), ['13', '14', '15'], true);
}

function glpichat_management_assignment_authorized(array $assignment): bool
{
    return $assignment && (($assignment['execution_authority'] ?? 'legacy') !== 'queued'
        || $assignment['status'] === 'started');
}

/** Acquire first in a grant/control transaction, before targets or machines.
 * Idle heartbeat and result paths never acquire this singleton. */
function glpichat_management_dispatch_lock(): array
{
    $budget = glpichat_management_one('glpi_plugin_glpichat_desktopdispatch', 'id=1', true);
    if (!$budget || (int) $budget['active_limit'] < 1 || (int) $budget['active_limit'] > 250) {
        glpichat_desktop_fail('management_capacity_unavailable', 'Controle de distribuição indisponível.', 503);
    }
    return $budget;
}

/** The first consistent read occurs after acquiring dispatch_lock. Concurrent
 * grants cannot commit until this transaction ends. Completed results may only
 * make this conservative count larger than necessary, never oversubscribe it. */
function glpichat_management_dispatch_has_capacity(array $budget): bool
{
    if ((int) $budget['paused'] !== 0) { return false; }
    $limit = (int) $budget['active_limit'];
    return count(glpichat_desktop_db_rows('SELECT id FROM ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS
        . " WHERE status IN ('pending','started') AND execution_authority IN ('legacy','authorized') ORDER BY status,execution_authority,id LIMIT " . $limit)) < $limit;
}

/** Read-only saturation hint. A stale read may defer useful work, never grant
 * it. Every authorization still takes dispatch_lock and repeats the count.
 * No shared lock/cache row is written by thousands of waiting claimants. */
function glpichat_management_dispatch_advisory(): bool
{
    $budget = glpichat_management_one('glpi_plugin_glpichat_desktopdispatch', 'id=1');
    if (!$budget || (int) $budget['active_limit'] < 1 || (int) $budget['active_limit'] > 250) {
        glpichat_desktop_fail('management_capacity_unavailable', 'Controle de distribuição indisponível.', 503);
    }
    return glpichat_management_dispatch_has_capacity($budget);
}

function glpichat_management_validate_report(array $input, array $assignment, array $release): void
{
    if (!$assignment || !$release || !is_int($input['assignment_release_id'] ?? null)
        || !is_int($input['assignment_sequence'] ?? null)
        || !is_string($input['assignment_manifest_sha256'] ?? null)
        || !is_string($input['assignment_action'] ?? null)
        || (int) $assignment['releases_id'] !== $input['assignment_release_id']
        || (int) $release['sequence'] !== $input['assignment_sequence']
        || $assignment['action'] !== $input['assignment_action']
        || !hash_equals(hash('sha256', (string) $release['manifest_json']), $input['assignment_manifest_sha256'])) {
        glpichat_desktop_fail('assignment_identity_mismatch', 'A identidade da operação não corresponde à autorização registrada.', 409);
    }
}

function glpichat_management_require_schema(): void
{
    if (!glpichat_management_schema_ready()) {
        glpichat_desktop_fail('schema_unavailable', 'Conclua a atualização do plugin para administrar o Windows.', 503);
    }
}

/** A failed start/rollback leaves the database boundary uncertain. Callers
 * must stop instead of writing diagnostics or retrying on this connection. */
final class GlpichatManagementTransactionStateException extends RuntimeException {}

/** Retry only successfully rolled-back database lock conflicts. GLPI has no
 * public transaction-depth getter, so rollback success is tracked here instead
 * of guessing through a private or nonexistent database API. */
function glpichat_management_transaction(callable $action): mixed
{
    global $DB;
    for ($attempt = 0; ; ++$attempt) {
        try { $DB->beginTransaction(); }
        catch (Throwable $error) { throw new GlpichatManagementTransactionStateException('Management transaction could not start.', 0, $error); }
        try {
            $result = $action();
            $DB->commit();
            return $result;
        } catch (Throwable $error) {
            try { $DB->rollBack(); }
            catch (Throwable $rollbackError) {
                glpichat_desktop_log_failure('management_rollback', $rollbackError);
                throw new GlpichatManagementTransactionStateException('Management rollback failed; request terminated.', 0, $error);
            }
            $transient = ($error instanceof mysqli_sql_exception && in_array($error->getCode(), [1205, 1213], true))
                || (basename($error->getFile()) === 'DBmysql.php' && preg_match('/\A(?:MySQL query error:).*\((?:1205|1213)\) in SQL query /s', $error->getMessage()));
            if (!$transient || $attempt >= 2) { throw $error; }
            usleep(random_int(10000, 50000));
        }
    }
}

function glpichat_management_one(string $table, string $where, bool $lock = false): array
{
    $rows = glpichat_desktop_db_rows('SELECT * FROM ' . $table . ' WHERE ' . $where . ' LIMIT 1' . ($lock ? ' FOR UPDATE' : ''));
    return $rows[0] ?? [];
}

function glpichat_management_write(string $table, array $values, ?array $where = null): int
{
    global $DB;
    $ok = $where === null ? $DB->insert($table, $values) : $DB->update($table, $values, $where);
    if (!$ok) { throw new RuntimeException('Management storage failed.'); }
    return $where === null ? (int) $DB->insertId() : 0;
}

function glpichat_management_hex(array $input, string $key, int $length = 64): string
{
    $value = glpichat_desktop_string($input, $key, $length);
    if (preg_match('/\A[a-f0-9]{' . $length . '}\z/D', $value) !== 1) {
        glpichat_desktop_fail('invalid_request', 'Credencial inválida.', 400);
    }
    return $value;
}

function glpichat_management_uuid(string $value): string
{
    if (preg_match('/\A[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}\z/D', $value) !== 1) {
        glpichat_desktop_fail('invalid_request', 'Identificador de instalação inválido.', 400);
    }
    return $value;
}

function glpichat_management_hash(string $purpose, string $value): string
{
    return hash('sha256', "glpichat-management-v1\0" . $purpose . "\0" . $value);
}

function glpichat_management_text(array $input, string $key, int $maximum): string
{
    $value = glpichat_desktop_string($input, $key, $maximum);
    if (preg_match('/[\x00-\x1f\x7f]/', $value)) {
        glpichat_desktop_fail('invalid_request', 'Texto inválido.', 400);
    }
    return $value;
}

/** Core's plugin document directory is protected storage, never an artifact URL. */
function glpichat_management_storage(): string
{
    if (!defined('GLPI_PLUGIN_DOC_DIR')) { throw new RuntimeException('GLPI plugin storage unavailable.'); }
    $base = rtrim(GLPI_PLUGIN_DOC_DIR, '/\\');
    if (is_link($base)) { throw new RuntimeException('Management storage must not be a symlink.'); }
    foreach ([$base, $base . '/glpichat', $base . '/glpichat/management'] as $directory) {
        if (is_link($directory) || (!is_dir($directory) && !mkdir($directory, 0700, true))) {
            throw new RuntimeException('Management storage unavailable.');
        }
    }
    $path = $base . '/glpichat/management';
    if (!chmod($path, 0700)) { throw new RuntimeException('Management storage permissions failed.'); }
    if (defined('GLPI_ROOT')) {
        $public = realpath(GLPI_ROOT . '/public');
        $real = realpath($path);
        if ($public !== false && $real !== false && ($real === $public || str_starts_with($real, $public . DIRECTORY_SEPARATOR))) {
            throw new RuntimeException('Management storage must be outside the public document root.');
        }
    }
    return $path;
}

function glpichat_management_storage_lock(callable $action): mixed
{
    $path = glpichat_management_storage();
    $lockPath = $path . '/management.lock';
    if (is_link($lockPath)) { throw new RuntimeException('Invalid storage lock.'); }
    $lock = fopen($lockPath, 'c+b');
    if ($lock === false) { throw new RuntimeException('Storage lock unavailable.'); }
    try {
        if (!chmod($lockPath, 0600) || !flock($lock, LOCK_EX)) { throw new RuntimeException('Storage lock failed.'); }
        return $action($path);
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
}

function glpichat_management_file(string $path, string $bytes): void
{
    $handle = fopen($path, 'x+b');
    if ($handle === false) { throw new RuntimeException('Artifact write failed.'); }
    try {
        if (!chmod($path, 0600)) { throw new RuntimeException('Artifact permissions failed.'); }
        $written = 0;
        while ($written < strlen($bytes)) {
            $part = fwrite($handle, substr($bytes, $written));
            if ($part === false || $part === 0) { throw new RuntimeException('Artifact write incomplete.'); }
            $written += $part;
        }
        if (!fflush($handle) || (function_exists('fsync') && !fsync($handle))) { throw new RuntimeException('Artifact flush failed.'); }
    } finally { fclose($handle); }
}

/** Called while storage lock is held. Never silently replace a lost signing key. */
function glpichat_management_signing_key(string $storage): OpenSSLAsymmetricKey
{
    if (!extension_loaded('openssl')) { glpichat_desktop_fail('openssl_required', 'Ative a extensão OpenSSL do PHP.', 503); }
    $path = $storage . '/instance-signing.pem';
    if (is_link($path)) { throw new RuntimeException('Invalid signing key path.'); }
    if (!is_file($path)) {
        foreach ([GLPICHAT_MANAGEMENT_RELEASES, GLPICHAT_MANAGEMENT_MACHINES, GLPICHAT_MANAGEMENT_GRANTS] as $table) {
            if (glpichat_desktop_db_rows('SELECT id FROM ' . $table . ' LIMIT 1')) {
                glpichat_desktop_fail('signing_key_missing', 'Restaure a chave de assinatura protegida do backup do GLPI.', 503);
            }
        }
        $key = openssl_pkey_new(['private_key_bits' => 2048, 'private_key_type' => OPENSSL_KEYTYPE_RSA]);
        if ($key === false || !openssl_pkey_export($key, $pem)) { throw new RuntimeException('Signing key generation failed.'); }
        glpichat_management_file($path, $pem);
    }
    if (!chmod($path, 0600)) { throw new RuntimeException('Signing key permissions failed.'); }
    $pem = file_get_contents($path);
    $key = is_string($pem) ? openssl_pkey_get_private($pem) : false;
    $details = $key === false ? false : openssl_pkey_get_details($key);
    if ($key === false || $details === false || ($details['type'] ?? -1) !== OPENSSL_KEYTYPE_RSA || ($details['bits'] ?? 0) < 2048) {
        throw new RuntimeException('Invalid signing key.');
    }
    return $key;
}

function glpichat_management_public_key(OpenSSLAsymmetricKey $key): string
{
    $details = openssl_pkey_get_details($key);
    if (!is_array($details) || !isset($details['rsa']['n'], $details['rsa']['e'])) { throw new RuntimeException('Invalid RSA public key.'); }
    return '<RSAKeyValue><Modulus>' . base64_encode($details['rsa']['n']) . '</Modulus><Exponent>' . base64_encode($details['rsa']['e']) . '</Exponent></RSAKeyValue>';
}

/** Read exact bounded entries; never extract an archive into the filesystem. */
function glpichat_management_release_bytes(string $zipPath): array
{
    if (!class_exists(ZipArchive::class)) { glpichat_desktop_fail('zip_required', 'Ative a extensão ZIP do PHP.', 503); }
    if (!is_file($zipPath) || filesize($zipPath) > GLPICHAT_MANAGEMENT_MAX_ZIP) {
        glpichat_desktop_fail('release_invalid', 'Arquivo de versão inválido ou muito grande.', 400);
    }
    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::RDONLY) !== true) { glpichat_desktop_fail('release_invalid', 'ZIP inválido.', 400); }
    try {
        $allowed = ['release.json' => 16384, 'GLPIChat.Agent.exe' => GLPICHAT_MANAGEMENT_MAX_FILE, 'GLPIChat.Widget.exe' => GLPICHAT_MANAGEMENT_MAX_FILE];
        if ($zip->numFiles !== 3) { glpichat_desktop_fail('release_invalid', 'O ZIP deve conter somente o manifesto e os dois componentes.', 400); }
        $entries = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            $name = is_array($stat) ? ($stat['name'] ?? '') : '';
            if (!isset($allowed[$name]) || isset($entries[$name]) || ($stat['size'] ?? 0) < 1 || $stat['size'] > $allowed[$name] || ($stat['encryption_method'] ?? 0) !== 0) {
                glpichat_desktop_fail('release_invalid', 'Conteúdo de ZIP inválido.', 400);
            }
            if ($zip->getExternalAttributesIndex($i, $opsys, $attributes) && (($attributes >> 16) & 0170000) === 0120000) {
                glpichat_desktop_fail('release_invalid', 'Links não são permitidos no ZIP.', 400);
            }
            $bytes = $zip->getFromIndex($i, (int) $stat['size']);
            if (!is_string($bytes) || strlen($bytes) !== $stat['size']) { glpichat_desktop_fail('release_invalid', 'Entrada de ZIP incompleta.', 400); }
            $entries[$name] = $bytes;
        }
        try { $metadata = json_decode($entries['release.json'], true, 12, JSON_THROW_ON_ERROR); }
        catch (JsonException $e) { glpichat_desktop_fail('release_invalid', 'Manifesto JSON inválido.', 400); }
        if (!is_array($metadata) || ($metadata['schema'] ?? null) !== 1 || ($metadata['product'] ?? '') !== 'glpichat-desktop'
            || !is_string($metadata['version'] ?? null) || strlen($metadata['version']) > 32 || preg_match('/\A[0-9]+\.[0-9]+\.[0-9]+\z/D', $metadata['version']) !== 1
            || !is_array($metadata['files'] ?? null) || !array_is_list($metadata['files']) || count($metadata['files']) !== 2) {
            glpichat_desktop_fail('release_invalid', 'Manifesto de versão inválido.', 400);
        }
        $components = [];
        foreach (['agent' => 'GLPIChat.Agent.exe', 'widget' => 'GLPIChat.Widget.exe'] as $role => $filename) {
            $matches = array_values(array_filter($metadata['files'], static fn ($f): bool => is_array($f) && ($f['role'] ?? '') === $role));
            $f = $matches[0] ?? [];
            $bytes = $entries[$filename];
            if (count($matches) !== 1 || ($f['filename'] ?? '') !== $filename || !is_int($f['size'] ?? null) || $f['size'] !== strlen($bytes)
                || !is_string($f['sha256'] ?? null) || !hash_equals(hash('sha256', $bytes), $f['sha256']) || strlen($bytes) < 128 || substr($bytes, 0, 2) !== 'MZ') {
                glpichat_desktop_fail('release_invalid', 'Tamanho, hash ou executável inválido.', 400);
            }
            $pe = unpack('Voffset', substr($bytes, 60, 4))['offset'];
            if ($pe < 64 || $pe > strlen($bytes) - 24 || substr($bytes, $pe, 4) !== "PE\0\0") { glpichat_desktop_fail('release_invalid', 'Cabeçalho PE inválido.', 400); }
            $components[] = ['role' => $role, 'filename' => $filename, 'size' => strlen($bytes), 'sha256' => hash('sha256', $bytes)];
        }
        $compatibility = $metadata['compatibility'] ?? [
            'platform' => 'windows', 'architecture' => 'x64',
            'bootstrap_abi' => version_compare($metadata['version'], '0.4.0', '>=') ? 2 : 1,
            'state_schema_min' => 1, 'state_schema_max' => 1,
        ];
        if (!is_array($compatibility) || array_diff(array_keys($compatibility), ['platform', 'architecture', 'bootstrap_abi', 'state_schema_min', 'state_schema_max'])
            || ($compatibility['platform'] ?? '') !== 'windows' || ($compatibility['architecture'] ?? '') !== 'x64'
            || !is_int($compatibility['bootstrap_abi'] ?? null) || $compatibility['bootstrap_abi'] < 1 || $compatibility['bootstrap_abi'] > 100
            || (version_compare($metadata['version'], '0.4.0', '>=') && $compatibility['bootstrap_abi'] < 2)
            || !is_int($compatibility['state_schema_min'] ?? null) || !is_int($compatibility['state_schema_max'] ?? null)
            || $compatibility['state_schema_min'] < 1 || $compatibility['state_schema_max'] < $compatibility['state_schema_min'] || $compatibility['state_schema_max'] > 100) {
            glpichat_desktop_fail('release_invalid', 'Compatibilidade da versão inválida.', 400);
        }
        return ['version' => $metadata['version'], 'components' => $components, 'entries' => $entries, 'compatibility' => $compatibility];
    } finally { $zip->close(); }
}

/** Canonical publication identity excludes the newly assigned sequence. */
function glpichat_management_import_identity(array $release): array
{
    $identity = ['schema' => 1, 'product' => 'glpichat-desktop', 'version' => $release['version']];
    foreach (['platform', 'architecture', 'bootstrap_abi', 'state_schema_min', 'state_schema_max'] as $field) {
        $identity[$field] = $release['compatibility'][$field];
    }
    $identity['components'] = $release['components'];
    return $identity;
}

/** Only the server's published releases and clock allocate publication order.
 * Machine counters are untrusted, machine-local antirollback telemetry: they
 * must never advance (or exhaust) the sequence space for the whole fleet.
 * Accept the canonical numeric strings returned for BIGINT columns without
 * allowing PHP's integer cast to silently saturate or truncate them. */
function glpichat_management_next_release_sequence(mixed $publishedMaximum, int $serverMilliseconds): int
{
    if ((!is_int($publishedMaximum) && !is_string($publishedMaximum))
        || preg_match('/\A(?:0|[1-9][0-9]*)\z/D', (string) $publishedMaximum) !== 1
        || (string) (int) $publishedMaximum !== (string) $publishedMaximum) {
        throw new RuntimeException('Invalid published release sequence.');
    }
    $maximum = (int) $publishedMaximum;
    if ($serverMilliseconds < 1 || $serverMilliseconds >= PHP_INT_MAX || $maximum >= PHP_INT_MAX - 1) {
        throw new RuntimeException('Release sequence exhausted.');
    }
    // Check before adding: overflowing a PHP integer would produce a float.
    // A server clock adjustment never lowers a previously published highwater.
    return max($serverMilliseconds, $maximum + 1);
}

function glpichat_management_import_storage_error(): never
{
    glpichat_desktop_fail('release_storage_invalid', 'A publicação existente está incompleta ou divergente. Preserve os arquivos e consulte o administrador; a versão não foi substituída.', 409);
}

/** The storage lock is held. Never trust a directory merely because its name
 * matches a candidate. Replayed publications must retain private exact bytes. */
function glpichat_management_import_files(string $directory, array $components, ?array $entries = null): void
{
    clearstatcache(true, $directory);
    if (is_link($directory) || !is_dir($directory) || (fileperms($directory) & 0777) !== 0700) {
        glpichat_management_import_storage_error();
    }
    $expected = array_column($components, 'filename');
    $names = scandir($directory);
    if ($names === false || array_diff($names, array_merge(['.', '..'], $expected))) {
        glpichat_management_import_storage_error();
    }
    $missing = [];
    foreach ($components as $file) {
        $path = $directory . '/' . $file['filename'];
        clearstatcache(true, $path);
        if (is_link($path)) { glpichat_management_import_storage_error(); }
        if (!file_exists($path) && $entries !== null) { $missing[] = $file['filename']; continue; }
        if (!is_file($path) || (fileperms($path) & 0777) !== 0600 || filesize($path) !== $file['size']
            || !hash_equals($file['sha256'], (string) hash_file('sha256', $path))) {
            glpichat_management_import_storage_error();
        }
    }
    // Validate every existing entry before adding anything. Only a new or
    // uncommitted exact candidate may finish a partial stage; database-backed
    // publications are checked without write access and cannot self-repair.
    foreach ($missing as $filename) { glpichat_management_file($directory . '/' . $filename, $entries[$filename]); }
    if ($missing) { glpichat_management_import_files($directory, $components); }
}

/** Exact retries recover their original publication; a version never acquires
 * different bytes/compatibility, a new sequence, or an implicit assignment. */
function glpichat_management_import_existing(array $row, array $release, string $storage, OpenSSLAsymmetricKey $key): array
{
    $id = (string) ($row['id'] ?? ''); $sequence = (string) ($row['sequence'] ?? '');
    if (preg_match('/\A[1-9][0-9]*\z/D', $id) !== 1 || (string) (int) $id !== $id
        || preg_match('/\A[1-9][0-9]*\z/D', $sequence) !== 1 || (string) (int) $sequence !== $sequence
        || preg_match('/\A[a-f0-9]{32}\z/D', (string) ($row['storage_key'] ?? '')) !== 1
        || !is_string($row['manifest_json'] ?? null) || strlen($row['manifest_json']) > 16384
        || !is_string($row['signature'] ?? null) || strlen($row['signature']) > 16384) {
        glpichat_management_import_storage_error();
    }
    $signature = base64_decode($row['signature'], true);
    $public = openssl_pkey_get_details($key);
    if ($signature === false || !is_array($public)
        || openssl_verify($row['manifest_json'], $signature, $public['key'], OPENSSL_ALGO_SHA256) !== 1) {
        glpichat_management_import_storage_error();
    }
    try { $manifest = json_decode($row['manifest_json'], true, 12, JSON_THROW_ON_ERROR); }
    catch (JsonException $error) { glpichat_management_import_storage_error(); }
    $expected = glpichat_management_import_identity($release) + ['sequence' => (int) $sequence];
    if (!is_array($manifest) || count($manifest) !== count($expected)) { glpichat_management_import_storage_error(); }
    foreach ($expected as $field => $value) {
        if (!array_key_exists($field, $manifest) || $manifest[$field] !== $value) {
            glpichat_desktop_fail('release_exists', 'Esta versão já possui outra publicação. Publique uma versão nova para arquivos ou compatibilidade diferentes.', 409);
        }
    }
    if (($row['version'] ?? '') !== $release['version']) { glpichat_management_import_storage_error(); }
    glpichat_management_import_files($storage . '/' . $row['storage_key'], $release['components']);
    return ['id' => (int) $id, 'version' => $release['version'], 'sequence' => (int) $sequence];
}

/** The web caller supplies current authority validation; trusted local callers
 * retain their existing boundary. A committed exact retry creates no authority. */
function glpichat_management_import(string $zipPath, int $adminId, ?callable $beforePublish = null): array
{
    glpichat_management_require_schema();
    $release = glpichat_management_release_bytes($zipPath);
    return glpichat_management_storage_lock(static function (string $storage) use ($release, $adminId, $beforePublish): array {
        global $DB;
        $key = glpichat_management_signing_key($storage);
        $directory = ''; $createdDirectory = false; $commitAttempted = false;
        // This importer owns its transaction; filesystem cleanup cannot rely
        // on the generic helper's exception alone to establish a rollback.
        $DB->beginTransaction();
        try {
            $existing = glpichat_management_one(GLPICHAT_MANAGEMENT_RELEASES, 'version=' . glpichat_desktop_quote($release['version']));
            if ($existing) {
                $result = glpichat_management_import_existing($existing, $release, $storage, $key);
            } else {
                $maxRelease = glpichat_desktop_db_rows('SELECT sequence FROM ' . GLPICHAT_MANAGEMENT_RELEASES . ' ORDER BY sequence DESC LIMIT 1')[0]['sequence'] ?? 0;
                // The enclosing publication lock serializes this allocation
                // with the durable insert; no machine telemetry is authority.
                $sequence = glpichat_management_next_release_sequence($maxRelease, (int) floor(microtime(true) * 1000));
                $identity = glpichat_management_import_identity($release);
                $manifest = json_encode($identity + ['sequence' => $sequence], JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
                if (!openssl_sign($manifest, $signature, $key, OPENSSL_ALGO_SHA256)) { throw new RuntimeException('Manifest signing failed.'); }
                // Identical failed attempts use at most one private candidate
                // directory. It is not authority: verify every byte and path.
                $storageKey = substr(hash('sha256', json_encode($identity, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)), 0, 32);
                $directory = $storage . '/' . $storageKey;
                if (is_link($directory)) { glpichat_management_import_storage_error(); }
                if (!file_exists($directory)) {
                    if (!mkdir($directory, 0700)) { throw new RuntimeException('Release directory failed.'); }
                    $createdDirectory = true;
                }
                glpichat_management_import_files($directory, $release['components'], $release['entries']);
                // Candidate preparation alone grants no execution authority.
                // Acquire issuer locks only at publication, after signing and
                // file I/O; denial follows the existing rollback/cleanup path.
                if ($beforePublish !== null) { $beforePublish(); }
                $id = glpichat_management_write(GLPICHAT_MANAGEMENT_RELEASES, ['version' => $release['version'], 'sequence' => $sequence, 'manifest_json' => $manifest,
                    'signature' => base64_encode($signature), 'storage_key' => $storageKey, 'created_at' => glpichat_desktop_now(), 'created_by' => $adminId]);
                $result = ['id' => $id, 'version' => $release['version'], 'sequence' => $sequence];
            }
            // Even a later successful rollback cannot disprove a COMMIT whose
            // acknowledgement was lost. Keep candidate bytes in that case.
            $commitAttempted = true;
            $DB->commit();
            return $result;
        } catch (Throwable $error) {
            $rolledBack = false;
            try { $DB->rollBack(); $rolledBack = true; }
            catch (Throwable $rollbackError) { glpichat_desktop_log_failure('management_import_rollback', $rollbackError); }
            if (!$commitAttempted && $rolledBack && $createdDirectory) {
                foreach (['GLPIChat.Agent.exe', 'GLPIChat.Widget.exe'] as $name) {
                    if (is_file($directory . '/' . $name)) { unlink($directory . '/' . $name); }
                }
                if (is_dir($directory)) { rmdir($directory); }
            }
            if ($commitAttempted || !$rolledBack) {
                $reference = glpichat_desktop_log_failure('management_import_uncertain', $error);
                glpichat_desktop_fail('release_publication_uncertain', 'Não foi possível confirmar a publicação. Reimporte o mesmo ZIP para verificar o resultado. Os arquivos foram preservados. Referência: ' . $reference . '.', 503);
            }
            throw $error;
        }
    });
}

function glpichat_management_deployment(string $baseUrl, string $enrollmentRoot, int $maxUses, int $ttlDays, int $adminId, ?callable $beforeIssue = null): array
{
    glpichat_management_require_schema();
    $parts = parse_url($baseUrl);
    if (!is_array($parts) || !in_array($parts['scheme'] ?? '', ['http', 'https'], true) || empty($parts['host']) || isset($parts['user'], $parts['pass']) || isset($parts['user']) || isset($parts['query']) || isset($parts['fragment'])
        || preg_match('/[\x00-\x20\x7f\\\\]/', $baseUrl) || preg_match('~(?:^|/)\.{1,2}(?:/|$)~', rawurldecode($parts['path'] ?? '')) || strlen($baseUrl) > 2048
        || strlen($enrollmentRoot) > 1024 || preg_match('/[\x00-\x1f\x7f]/', $enrollmentRoot) || $maxUses < 1 || $maxUses > 10000 || $ttlDays < 1 || $ttlDays > 30) {
        glpichat_desktop_fail('invalid_request', 'Endereço, prazo ou limite de instalações inválido.', 400);
    }
    return glpichat_management_storage_lock(static function (string $storage) use ($baseUrl, $enrollmentRoot, $maxUses, $ttlDays, $adminId, $beforeIssue): array {
        $public = glpichat_management_public_key(glpichat_management_signing_key($storage));
        $id = bin2hex(random_bytes(16)); $secret = bin2hex(random_bytes(32));
        // Do not retain SQL locks while waiting on storage or preparing the key.
        // New authority is validated and inserted under the same short transaction.
        return glpichat_management_transaction(static function () use ($baseUrl, $enrollmentRoot, $maxUses, $ttlDays, $adminId, $beforeIssue, $public, $id, $secret): array {
            if ($beforeIssue !== null) { $beforeIssue(); }
            glpichat_management_write(GLPICHAT_MANAGEMENT_GRANTS, ['registration_id' => $id, 'secret_hash' => glpichat_management_hash('registration', $secret), 'status' => 'issued',
                'expires_at' => gmdate('Y-m-d H:i:s', time() + $ttlDays * 86400), 'max_uses' => $maxUses, 'used_count' => 0, 'created_at' => glpichat_desktop_now(), 'created_by' => $adminId]);
            return ['schema' => 1, 'product' => 'glpichat-desktop', 'base_url' => rtrim($baseUrl, '/'), 'management_public_key_xml' => $public,
                'registration_id' => $id, 'registration_secret' => $secret, 'enrollment_mode' => 'automatic', 'enrollment_root' => $enrollmentRoot];
        });
    });
}

function glpichat_management_register(array $input): array
{
    glpichat_management_require_schema();
    $grantId = glpichat_management_hex($input, 'registration_id', 32);
    $secret = glpichat_management_hex($input, 'registration_secret');
    $token = glpichat_management_hex($input, 'machine_token');
    $installation = glpichat_management_uuid(glpichat_desktop_string($input, 'installation_id', 36));
    $computer = strtoupper(glpichat_management_text($input, 'computer_name', 63));
    $bootstrap = glpichat_management_text($input, 'bootstrap_version', 32);
    if (preg_match('/\A[A-Z0-9][A-Z0-9_-]{0,62}\z/D', $computer) !== 1) { glpichat_desktop_fail('invalid_request', 'Nome de computador inválido.', 400); }
    return glpichat_desktop_transaction(static function () use ($grantId, $secret, $token, $installation, $computer, $bootstrap): array {
        // Lock the grant first: registration consumption and revocation share this order.
        $grant = glpichat_management_one(GLPICHAT_MANAGEMENT_GRANTS, 'registration_id=' . glpichat_desktop_quote($grantId), true);
        if (!$grant || !hash_equals($grant['secret_hash'], glpichat_management_hash('registration', $secret))) {
            glpichat_desktop_fail('registration_invalid', 'Registro indisponível ou revogado.', 401);
        }
        $machine = glpichat_management_one(GLPICHAT_MANAGEMENT_MACHINES, 'installation_id=' . glpichat_desktop_quote($installation), true);
        if ($machine) {
            // An administrator can recover only this already-created installation
            // after a lost reply. Both original secrets must still match; the
            // expired/revoked shared deployment grant remains closed to others.
            if ($grant['status'] !== 'issued' && (empty($machine['registration_recovery_until'])
                || $machine['registration_recovery_until'] <= glpichat_desktop_now())) {
                glpichat_desktop_fail('registration_invalid', 'Registro indisponível ou revogado.', 401);
            }
            if ($machine['status'] !== 'active' || $machine['registration_id'] !== $grantId || !hash_equals($machine['token_hash'], glpichat_management_hash('machine', $token))) {
                glpichat_desktop_fail('registration_conflict', 'Esta instalação já possui outro registro.', 409);
            }
        } else {
            if ($grant['status'] !== 'issued') { glpichat_desktop_fail('registration_invalid', 'Registro indisponível ou revogado.', 401); }
            if ($grant['expires_at'] <= glpichat_desktop_now() || (int) $grant['used_count'] >= (int) $grant['max_uses']) { glpichat_desktop_fail('registration_expired', 'Registro expirado ou limite atingido.', 410); }
            glpichat_management_write(GLPICHAT_MANAGEMENT_MACHINES, ['installation_id' => $installation, 'token_hash' => glpichat_management_hash('machine', $token), 'registration_id' => $grantId,
                'status' => 'active', 'computer_name' => $computer, 'enrollment_computer_name' => $computer, 'bootstrap_version' => $bootstrap, 'current_version' => '', 'current_sequence' => 0, 'current_slot' => '', 'health' => 'unavailable',
                'last_result' => '', 'last_error' => '', 'last_seen' => null, 'created_at' => glpichat_desktop_now()]);
            glpichat_management_write(GLPICHAT_MANAGEMENT_GRANTS, ['used_count' => (int) $grant['used_count'] + 1], ['id' => (int) $grant['id']]);
        }
        return ['ok' => true, 'installation_id' => $installation, 'poll_seconds' => 60];
    });
}

function glpichat_management_authenticate(string $token, string $installation, bool $lock = false): array
{
    glpichat_management_require_schema();
    glpichat_management_uuid($installation);
    if (preg_match('/\A[a-f0-9]{64}\z/D', $token) !== 1) { glpichat_desktop_fail('machine_invalid', 'Registro da máquina inválido.', 401); }
    $machine = glpichat_management_one(GLPICHAT_MANAGEMENT_MACHINES, 'installation_id=' . glpichat_desktop_quote($installation), $lock);
    if (!$machine || $machine['status'] !== 'active' || !hash_equals($machine['token_hash'], glpichat_management_hash('machine', $token))) {
        glpichat_desktop_fail('machine_invalid', 'Registro da máquina inválido ou revogado.', 401);
    }
    return $machine;
}

function glpichat_management_pending(int $machineId, bool $lock = false): array
{
    $rows = glpichat_desktop_db_rows('SELECT * FROM ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' WHERE machines_id=' . $machineId . " AND status IN ('pending','started') ORDER BY id DESC LIMIT 1" . ($lock ? ' FOR UPDATE' : ''));
    return $rows[0] ?? [];
}

/** Caller owns the locked authenticated machine row. Host names are mutable
 * telemetry, while installation ID and machine credential remain the identity. */
function glpichat_management_reconcile_name(array $machine, string $name): array
{
    $name = strtoupper($name);
    if (preg_match('/\A[A-Z0-9][A-Z0-9_-]{0,62}\z/D', $name) !== 1) { glpichat_desktop_fail('invalid_request', 'Nome de computador inválido.', 400); }
    if ($name !== strtoupper((string) $machine['computer_name'])) {
        $values = ['computer_name' => $name, 'previous_computer_name' => $machine['computer_name'], 'renamed_at' => glpichat_desktop_now()];
        // Preserve the first registered name for legacy enrollment revocation
        // adoption even when several authenticated renames precede first login.
        if (empty($machine['enrollment_computer_name'])) { $values['enrollment_computer_name'] = $machine['computer_name']; }
        glpichat_management_write(GLPICHAT_MANAGEMENT_MACHINES, $values, ['id' => (int) $machine['id']]);
        $machine = array_replace($machine, $values);
    }
    return $machine;
}

function glpichat_management_poll(string $token, string $installation, array $input): array
{
    $protocol = $input['management_protocol'] ?? 1;
    if (!is_int($protocol) || !in_array($protocol, [1, 2], true)) { glpichat_desktop_fail('management_protocol_unsupported', 'Protocolo de gerenciamento não suportado.', 409); }
    if ($protocol === 2 && !glpichat_management_claims_ready()) { glpichat_desktop_fail('management_protocol_unsupported', 'Atualize o servidor antes deste cliente de gerenciamento.', 503); }
    $values = [];
    foreach (['bootstrap_version' => 32, 'current_version' => 32, 'current_slot' => 1, 'health' => 16, 'result' => 80, 'error_code' => 100] as $key => $bound) {
        $values[$key] = glpichat_management_text($input, $key, $bound);
    }
    foreach (['current_sequence', 'assignment_id'] as $key) {
        if (!isset($input[$key]) || !is_int($input[$key]) || $input[$key] < 0 || $input[$key] >= PHP_INT_MAX) { glpichat_desktop_fail('invalid_request', 'Contador inválido.', 400); }
        $values[$key] = $input[$key];
    }
    if (!in_array($values['current_slot'], ['', 'a', 'b'], true) || !in_array($values['health'], ['healthy', 'damaged', 'trial', 'unavailable'], true)) { glpichat_desktop_fail('invalid_request', 'Estado inválido.', 400); }
    $computer = array_key_exists('computer_name', $input) ? glpichat_management_text($input, 'computer_name', 63) : null;
    if ($values['assignment_id'] > 0 && !in_array($values['result'], ['started', 'retrying', 'failed', 'rolled_back', 'interrupted', 'committed', 'repaired', 'current'], true)) {
        glpichat_desktop_fail('invalid_request', 'Resultado de operação inválido.', 400);
    }
    require_once __DIR__ . '/rollouts.php';
    // Authenticate and commit current telemetry/results before touching targets.
    // Keeping these transactions separate avoids machine -> target lock inversion
    // against background dispatch, and eligibility sees the current Bootstrap.
    $machineId = glpichat_management_transaction(static function () use ($token, $installation, $values, $computer, $input, $protocol): int {
        $machine = glpichat_management_authenticate($token, $installation, true);
        if ($computer !== null) { $machine = glpichat_management_reconcile_name($machine, $computer); }
        // A late report belongs to its exact installation/assignment, never to
        // a newer desired operation. Preserve superseded history too.
        $reported = $values['assignment_id'] > 0 ? glpichat_management_one(GLPICHAT_MANAGEMENT_ASSIGNMENTS, 'id=' . $values['assignment_id'] . ' AND machines_id=' . (int) $machine['id'], true) : [];
        if ($protocol === 2 && $values['assignment_id'] > 0 && !$reported) { glpichat_desktop_fail('assignment_identity_mismatch', 'Operação não encontrada para esta instalação.', 409); }
        if ($reported) {
            $reportedRelease = glpichat_management_one(GLPICHAT_MANAGEMENT_RELEASES, 'id=' . (int) $reported['releases_id']);
            if ($protocol === 2) { glpichat_management_validate_report($input, $reported, $reportedRelease); }
            if (glpichat_management_claims_ready() && !glpichat_management_assignment_authorized($reported)) { glpichat_desktop_fail('assignment_not_authorized', 'Esta operação ainda não foi autorizada.', 409); }
            $newStatus = null;
            if ($values['result'] === 'failed' && $values['error_code'] === 'MANAGEMENT_AUTHORIZATION_WITHDRAWN') {
                if ($protocol !== 2 || empty($reported['dispatch_blocked'])) { glpichat_desktop_fail('assignment_not_withdrawn', 'Esta operação não tem retirada de execução registrada.', 409); }
                $newStatus = 'withdrawn';
            }
            elseif (in_array($values['result'], ['started', 'retrying'], true)) { $newStatus = 'started'; }
            elseif (in_array($values['result'], ['failed', 'rolled_back', 'interrupted'], true)) { $newStatus = 'failed'; }
            elseif (in_array($values['result'], ['committed', 'repaired', 'current'], true) && $values['health'] === 'healthy'
                && $reportedRelease && (int) $reportedRelease['sequence'] === $values['current_sequence'] && $reportedRelease['version'] === $values['current_version']) { $newStatus = 'completed'; }
            $details = ['last_reported_at' => glpichat_desktop_now(), 'last_result' => $values['result'], 'last_error' => $values['error_code']];
            if (in_array($reported['status'], ['completed', 'failed', 'withdrawn'], true) && $newStatus !== $reported['status']) {
                // Delayed start/retry reports cannot erase a terminal outcome.
                $details = ['last_reported_at' => glpichat_desktop_now()];
            }
            if ($newStatus !== null && in_array($reported['status'], ['pending', 'started'], true)) {
                $details['status'] = $newStatus;
                if ($newStatus === 'started' && empty($reported['started_at'])) { $details['started_at'] = glpichat_desktop_now(); }
                if (in_array($newStatus, ['completed', 'failed', 'withdrawn'], true)) { $details['completed_at'] = glpichat_desktop_now(); }
            }
            glpichat_management_write(GLPICHAT_MANAGEMENT_ASSIGNMENTS, $details, ['id' => (int) $reported['id']]);
        }
        glpichat_management_write(GLPICHAT_MANAGEMENT_MACHINES, ['bootstrap_version' => $values['bootstrap_version'], 'current_version' => $values['current_version'],
            // Never lower machine-local highwater, including after rollback.
            // It constrains only this machine; it is not publication authority.
            'current_sequence' => max((int) $machine['current_sequence'], $values['current_sequence']), 'current_slot' => $values['current_slot'], 'health' => $values['health'],
            'last_result' => $values['result'], 'last_error' => $values['error_code'], 'last_seen' => glpichat_desktop_now(),
            'runtime_json' => glpichat_management_runtime_store($input, $machine['runtime_json'] ?? null)], ['id' => (int) $machine['id']]);
        return (int) $machine['id'];
    });
    $capacityDeferred = glpichat_management_poll_rollouts(['machines_id' => $machineId, 'token' => $token, 'installation' => $installation]);
    $peek = glpichat_management_pending($machineId);
    $needsGrant = glpichat_management_claims_ready() && $peek && !glpichat_management_assignment_authorized($peek);
    if ($needsGrant && !glpichat_management_dispatch_advisory()) { $needsGrant = false; $capacityDeferred = true; }
    return glpichat_management_transaction(static function () use ($token, $installation, $needsGrant, $capacityDeferred): array {
        $budget = $needsGrant ? glpichat_management_dispatch_lock() : null;
        $machine = glpichat_management_authenticate($token, $installation, true);
        $assignment = glpichat_management_pending((int) $machine['id'], true);
        if ($assignment && glpichat_management_claims_ready() && !glpichat_management_assignment_authorized($assignment)) {
            // A newly queued direct assignment must pass the same global gate.
            // If it raced the peek, wait for the next Poll instead of changing lock order.
            if (!$budget || !empty($assignment['dispatch_blocked']) || !glpichat_management_dispatch_has_capacity($budget)) {
                if ($budget && empty($assignment['dispatch_blocked'])) { $capacityDeferred = true; }
                $assignment = [];
            }
            else {
                glpichat_management_write(GLPICHAT_MANAGEMENT_ASSIGNMENTS,
                    ['execution_authority' => 'authorized', 'authorized_at' => glpichat_desktop_now()], ['id' => (int) $assignment['id']]);
            }
        }
        $release = $assignment ? glpichat_management_one(GLPICHAT_MANAGEMENT_RELEASES, 'id=' . (int) $assignment['releases_id']) : [];
        $command = $assignment && $release ? ['id' => (int) $assignment['id'], 'action' => $assignment['action'], 'release_id' => (int) $release['id'],
            'sequence' => (int) $release['sequence'], 'manifest_json' => $release['manifest_json'], 'signature' => $release['signature']] : null;
        // Withdrawal is not execution authority. A protocol2 endpoint may
        // acknowledge it only after proving this exact attempt never activated.
        // Older clients ignore it and remain conservatively unresolved.
        return ['ok' => true, 'management_protocol' => glpichat_management_claims_ready() ? 2 : 1,
            'poll_seconds' => $capacityDeferred && !$command ? random_int(60, 90) : 60,
            'poll_reason' => $capacityDeferred && !$command ? 'capacity_deferred' : '',
            'assignment' => empty($assignment['dispatch_blocked']) ? $command : null,
            'withdrawn_assignment' => glpichat_management_claims_ready() && !empty($assignment['dispatch_blocked']) ? $command : null];
    });
}

/** The same read-only prerequisites feed administrator previews and locked
 * assignment creation. Availability may change later; execution rechecks them.
 * A currently started assignment is handled separately as waiting/reuse. */
function glpichat_management_assignment_eligibility(array $machine, array $release, string $action, ?bool $knownReleaseFailed = null): string
{
    if (!in_array($action, ['update', 'repair'], true)) { return 'not_found'; }
    if (!$machine || ($machine['status'] ?? '') !== 'active' || !$release) { return 'not_found'; }
    if ((int) $release['sequence'] < (int) $machine['current_sequence']
        || ($action === 'update' && (int) $release['sequence'] === (int) $machine['current_sequence'])) { return 'sequence_conflict'; }
    $manifest = json_decode((string) $release['manifest_json'], true, 16, JSON_THROW_ON_ERROR);
    $bootstrapAbi = version_compare((string) $machine['bootstrap_version'], '0.4.0', '>=') ? 2 : 1;
    if (($manifest['bootstrap_abi'] ?? PHP_INT_MAX) > $bootstrapAbi) { return 'bootstrap_upgrade_required'; }
    if (($manifest['state_schema_min'] ?? 0) !== 1 || ($manifest['state_schema_max'] ?? 0) !== 1) { return 'state_upgrade_required'; }
    if ($action === 'update') {
        $knownReleaseFailed ??= (bool) glpichat_management_one(GLPICHAT_MANAGEMENT_ASSIGNMENTS, 'machines_id=' . (int) $machine['id']
            . ' AND releases_id=' . (int) $release['id'] . " AND status='failed'");
        if ($knownReleaseFailed) { return 'release_quarantined'; }
    }
    return '';
}

function glpichat_management_assign(int $machineId, int $releaseId, string $action, int $adminId): int
{
    return glpichat_management_transaction(static fn (): int => glpichat_management_assign_locked($machineId, $releaseId, $action, $adminId));
}

/** The caller owns the transaction. Dispatch already holds its target row and
 * must not nest a savepoint: an InnoDB deadlock rolls back the entire database
 * transaction, making a nested rollback-to-savepoint impossible in GLPI. */
function glpichat_management_assign_locked(int $machineId, int $releaseId, string $action, int $adminId): int
{
    glpichat_management_require_schema();
    if (!in_array($action, ['update', 'repair'], true)) { glpichat_desktop_fail('invalid_request', 'Ação inválida.', 400); }
    $machine = glpichat_management_one(GLPICHAT_MANAGEMENT_MACHINES, 'id=' . $machineId, true);
    $release = glpichat_management_one(GLPICHAT_MANAGEMENT_RELEASES, 'id=' . $releaseId);
    $eligibility = glpichat_management_assignment_eligibility($machine, $release, $action);
    if ($eligibility !== '') {
        $messages = ['not_found' => 'Máquina ou versão indisponível.',
            'sequence_conflict' => 'Selecione uma versão com sequência maior; para a versão atual use Reparar.',
            'bootstrap_upgrade_required' => 'Esta versão exige manutenção do bootstrap instalado. Use o procedimento administrativo da versão.',
            'state_upgrade_required' => 'Esta versão exige uma migração de dados ainda não suportada por este cliente.',
            'release_quarantined' => 'Esta atualização falhou. Publique outra versão ou solicite reparo explicitamente.'];
        glpichat_desktop_fail($eligibility, $messages[$eligibility], $eligibility === 'not_found' ? 404 : 409);
    }
    $previous = glpichat_management_pending($machineId, true);
    if ($previous && (int) $previous['releases_id'] === $releaseId && $previous['action'] === $action) { return (int) $previous['id']; }
    if ($previous && ($previous['status'] === 'started' || (glpichat_management_claims_ready() && glpichat_management_assignment_authorized($previous)))) { glpichat_desktop_fail('operation_in_progress', 'A operação atual está em andamento. A próxima ficará aguardando.', 409); }
    if ($previous) { glpichat_management_write(GLPICHAT_MANAGEMENT_ASSIGNMENTS, ['status' => 'superseded', 'completed_at' => glpichat_desktop_now()], ['id' => (int) $previous['id']]); }
    return glpichat_management_write(GLPICHAT_MANAGEMENT_ASSIGNMENTS, ['machines_id' => $machineId, 'releases_id' => $releaseId, 'action' => $action,
        'status' => 'pending', 'created_at' => glpichat_desktop_now(), 'created_by' => $adminId, 'completed_at' => null,
        'started_at' => null, 'last_reported_at' => null, 'last_result' => '', 'last_error' => '']
        + (glpichat_management_claims_ready() ? ['execution_authority' => 'queued', 'authorized_at' => null] : []));
}

function glpichat_management_revoke(string $kind, int $id, ?callable $beforeChange = null): void
{
    glpichat_management_require_schema();
    // Compatibility entry point for trusted local maintenance only. Web
    // administration supplies an explicit revision/receipt through authority.php.
    if ($kind === 'machine' && in_array((string) glpichat_desktop_config('desktop_schema_version'), ['14', '15'], true)) {
        if (PHP_SAPI !== 'cli') { glpichat_desktop_fail('administrative_context_required', 'Use a ação administrativa com revisão e justificativa.', 400); }
        require_once __DIR__ . '/authority.php';
        $machine = glpichat_management_one(GLPICHAT_MANAGEMENT_MACHINES, 'id=' . $id);
        if (!$machine) { glpichat_desktop_fail('not_found', 'Registro não encontrado.', 404); }
        glpichat_management_authority_change('machine', $id, 'suspend', (int) ($machine['admin_revision'] ?? 0), 0,
            bin2hex(random_bytes(16)), 'Suspensão por administração local confiável (CLI).', 'local', $beforeChange);
        return;
    }
    $table = match ($kind) { 'machine' => GLPICHAT_MANAGEMENT_MACHINES, 'registration' => GLPICHAT_MANAGEMENT_GRANTS, default => '' };
    if ($table === '' || $id < 1) { glpichat_desktop_fail('invalid_request', 'Registro inválido.', 400); }
    glpichat_desktop_transaction(static function () use ($table, $id, $beforeChange): void {
        $target = glpichat_management_one($table, 'id=' . $id, true);
        if (!$target) { glpichat_desktop_fail('not_found', 'Registro não encontrado.', 404); }
        if ($beforeChange !== null) { $beforeChange(); }
        if ($table === GLPICHAT_MANAGEMENT_MACHINES && $target['status'] === 'retired') {
            glpichat_desktop_fail('installation_retired', 'Esta instalação foi retirada permanentemente.', 409);
        }
        glpichat_management_write($table, ['status' => 'revoked'], ['id' => $id]);
    });
}

/** Machine must report started for its current assignment before either payload. */
function glpichat_management_artifact(string $token, string $installation, int $releaseId, string $filename): string
{
    if (!in_array($filename, ['GLPIChat.Agent.exe', 'GLPIChat.Widget.exe'], true)) { glpichat_desktop_fail('not_found', 'Arquivo indisponível.', 404); }
    return glpichat_desktop_transaction(static function () use ($token, $installation, $releaseId, $filename): string {
        $machine = glpichat_management_authenticate($token, $installation, true);
        $assignment = glpichat_management_pending((int) $machine['id'], true);
        if (!$assignment || (int) $assignment['releases_id'] !== $releaseId || $assignment['status'] !== 'started') { glpichat_desktop_fail('not_found', 'Arquivo fora da operação autorizada.', 404); }
        // An exact retained attempt can lose its download authority after
        // Begin. Distinguish withdrawal from an unrelated/missing artifact so
        // a preparing client preserves its receipt for explicit reconciliation.
        if (!empty($assignment['dispatch_blocked'])) { glpichat_desktop_fail('assignment_not_authorized', 'A execução desta operação foi retirada.', 403); }
        $release = glpichat_management_one(GLPICHAT_MANAGEMENT_RELEASES, 'id=' . $releaseId);
        if (!$release || preg_match('/\A[a-f0-9]{32}\z/D', $release['storage_key']) !== 1) { throw new RuntimeException('Release storage invalid.'); }
        $path = glpichat_management_storage() . '/' . $release['storage_key'] . '/' . $filename;
        if (is_link(dirname($path)) || is_link($path) || !is_file($path)) { throw new RuntimeException('Release artifact unavailable.'); }
        if (glpichat_management_claims_ready()) {
            require_once dirname(__DIR__) . '/admission.php';
            $mib = glpichat_admission_desktop_limit('desktop_download_mib_per_minute', glpichat_desktop_config('desktop_download_mib_per_minute'));
            $size = filesize($path);
            if ($size === false || $size < 1 || $size > GLPICHAT_MANAGEMENT_MAX_FILE) { throw new RuntimeException('Release artifact size invalid.'); }
            $admission = glpichat_admission_take_locked([
                ['scope' => 'desktop_download_bytes', 'subject' => 'fleet', 'limit' => $mib * 1048576, 'window_seconds' => 60, 'cost' => $size],
                ['scope' => 'desktop_download_requests', 'subject' => 'machine:' . (int) $machine['id'], 'limit' => 12, 'window_seconds' => 60],
            ]);
            if (!$admission['allowed']) { glpichat_desktop_fail('download_throttled', 'Aguarde a capacidade de transferência.', 429, ['retry_after' => $admission['retry_after']]); }
        }
        return $path;
    });
}
