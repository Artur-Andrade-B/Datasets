<?php

declare(strict_types=1);

const GLPICHAT_MANAGEMENT_WAITERS = 'glpi_plugin_glpichat_desktopwaiters';
const GLPICHAT_MANAGEMENT_INTEREST_SECONDS = 300;
const GLPICHAT_MANAGEMENT_INTEREST_REFRESH_SECONDS = 30;
const GLPICHAT_MANAGEMENT_HEAD_CLEANUP_LIMIT = 16;

/** Schema15 adds scheduling interest, never executable authority. */
function glpichat_management_fairness_ready(): bool
{
    return (string) glpichat_desktop_config('desktop_schema_version') === '15';
}

/** Actual authorized work, not the mutable administrative summary counter. */
function glpichat_management_campaign_active(int $rolloutId): int
{
    return count(glpichat_desktop_db_rows('SELECT a.id FROM ' . GLPICHAT_MANAGEMENT_TARGETS . ' t INNER JOIN '
        . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' a ON a.id=t.assignments_id WHERE t.rollouts_id=' . $rolloutId
        . " AND t.status='assigned' AND a.status IN ('pending','started') AND a.execution_authority IN ('legacy','authorized') LIMIT 251"));
}

/** Ticket order is durable and independent of the wall clock. UTC is only a
 * bounded recent-contact hint. A clock rollback cannot pin an offline head. */
function glpichat_management_interest_valid(array $waiter, string $now): bool
{
    if (!$waiter) { return false; }
    $contact = $waiter['last_requested_at'] ?? '';
    $expiry = $waiter['expires_at'] ?? '';
    if (!is_string($contact) || !is_string($expiry) || $contact > $now || $expiry <= $now || $expiry < $contact) { return false; }
    $timestamp = strtotime($contact . ' UTC');
    return $timestamp !== false && gmdate('Y-m-d H:i:s', $timestamp) === $contact
        && $expiry === gmdate('Y-m-d H:i:s', $timestamp + GLPICHAT_MANAGEMENT_INTEREST_SECONDS);
}

function glpichat_management_interest_fresh(array $waiter, string $now): bool
{
    return glpichat_management_interest_valid($waiter, $now)
        && $waiter['last_requested_at'] > gmdate('Y-m-d H:i:s', strtotime($now . ' UTC') - GLPICHAT_MANAGEMENT_INTEREST_REFRESH_SECONDS);
}

function glpichat_management_interest_drop(int $rolloutId, ?int $targetId = null): void
{
    global $DB;
    if ($DB->doQuery('DELETE FROM ' . GLPICHAT_MANAGEMENT_WAITERS . ' WHERE rollouts_id=' . $rolloutId
        . ($targetId === null ? '' : ' AND targets_id=' . $targetId)) === false) {
        throw new RuntimeException('Campaign interest removal failed.');
    }
}

/** Caller has authenticated a due target/current machine. Waiter is the last
 * lock: no code holding it may subsequently acquire target/machine/parent. */
function glpichat_management_interest_touch(int $rolloutId, int $targetId, string $now, bool $forceTarget = false): void
{
    global $DB;
    $values = ['targets_id' => $targetId, 'last_requested_at' => $now,
        'expires_at' => gmdate('Y-m-d H:i:s', strtotime($now . ' UTC') + GLPICHAT_MANAGEMENT_INTEREST_SECONDS)];
    // Serialize first contact through the unique rollout key without taking a
    // missing-row gap lock and then competing to convert it into an insert.
    if ($DB->doQuery('INSERT INTO ' . GLPICHAT_MANAGEMENT_WAITERS
        . ' (rollouts_id,targets_id,last_requested_at,expires_at) VALUES (' . $rolloutId . ',' . $targetId . ','
        . glpichat_desktop_quote($now) . ',' . glpichat_desktop_quote($values['expires_at'])
        . ') ON DUPLICATE KEY UPDATE rollouts_id=VALUES(rollouts_id)') === false) {
        throw new RuntimeException('Campaign interest registration failed.');
    }
    $waiter = glpichat_management_one(GLPICHAT_MANAGEMENT_WAITERS, 'rollouts_id=' . $rolloutId, true);
    // A concurrent contact may have completed while this request waited.
    $now = glpichat_desktop_now();
    $values['last_requested_at'] = $now;
    $values['expires_at'] = gmdate('Y-m-d H:i:s', strtotime($now . ' UTC') + GLPICHAT_MANAGEMENT_INTEREST_SECONDS);
    if (glpichat_management_interest_fresh($waiter, $now)
        && (!$forceTarget || (int) $waiter['targets_id'] === $targetId)) { return; }
    if ($waiter && !glpichat_management_interest_valid($waiter, $now)) {
        glpichat_management_interest_drop($rolloutId);
        $waiter = [];
    }
    if ($waiter) { glpichat_management_write(GLPICHAT_MANAGEMENT_WAITERS, $values, ['id' => $waiter['id']]); }
    else { glpichat_management_write(GLPICHAT_MANAGEMENT_WAITERS, ['rollouts_id' => $rolloutId] + $values); }
}

/** Full-capacity contacts still join the queue. A fresh row needs no mutation
 * or singleton lock. Slow registration shares dispatch serialization with
 * grants, before target -> machine -> waiter. This also orders InnoDB unique
 * and primary gap locks during expiry/reinsertion, not just logical row locks.
 * Waiting bursts recheck freshness immediately after acquiring dispatch, so
 * only one campaign contact refreshes within the coalescing interval. */
function glpichat_management_register_interest(int $targetId, array $credential): void
{
    $target = glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS, 'id=' . $targetId);
    if (!$target || !in_array($target['status'], ['queued', 'waiting'], true)) { return; }
    $now = glpichat_desktop_now();
    $rolloutId = (int) $target['rollouts_id'];
    $waiter = glpichat_management_one(GLPICHAT_MANAGEMENT_WAITERS, 'rollouts_id=' . $rolloutId);
    if (glpichat_management_interest_fresh($waiter, $now)) { return; }
    glpichat_management_transaction(static function () use ($targetId, $credential, $rolloutId): void {
        glpichat_management_dispatch_lock();
        $waiter = glpichat_management_one(GLPICHAT_MANAGEMENT_WAITERS, 'rollouts_id=' . $rolloutId);
        if (glpichat_management_interest_fresh($waiter, glpichat_desktop_now())) { return; }
        $target = glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS, 'id=' . $targetId, true);
        if (!$target) { return; }
        glpichat_management_target_authenticate($target, $credential);
        $now = glpichat_desktop_now();
        if (!in_array($target['status'], ['queued', 'waiting'], true) || $target['available_at'] > $now) { return; }
        $machine = glpichat_management_one(GLPICHAT_MANAGEMENT_MACHINES, 'id=' . (int) $target['machines_id'], true);
        if (!$machine || (int) ($machine['admin_revision'] ?? 0) !== (int) ($target['expected_admin_revision'] ?? 0)
            || glpichat_management_pending((int) $machine['id'])) { return; }
        $rollout = glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS, 'id=' . (int) $target['rollouts_id']);
        if (!$rollout || (int) $rollout['paused'] !== 0 || !in_array($rollout['status'], ['queued', 'running'], true)
            || !in_array($rollout['action'], ['update', 'repair'], true)) { return; }
        $cap = (int) $rollout['concurrency_limit'];
        if ($cap > 0 && glpichat_management_campaign_active((int) $rollout['id']) >= $cap) { return; }
        if (!glpichat_management_interest_prerequisites($rollout, $machine)) { return; }
        glpichat_management_interest_touch((int) $rollout['id'], (int) $target['id'], $now);
    });
}

/** Non-authoritative, nonlocking eligibility snapshot. Exact actor/release and
 * machine checks still run under the normal grant locks before authorization. */
function glpichat_management_interest_prerequisites(array $rollout, array $machine): bool
{
    try { glpichat_management_require_rollout_actor($rollout); }
    catch (GlpichatDesktopException $error) {
        if ($error->errorCode === 'issuer_authority_lost') { return false; }
        throw $error;
    }
    $release = glpichat_management_one(GLPICHAT_MANAGEMENT_RELEASES, 'id=' . (int) $rollout['releases_id']);
    try { return glpichat_management_assignment_eligibility($machine, $release, $rollout['action']) === ''; }
    catch (JsonException) { return false; }
}

/** Current scheduling eligibility only. This read does not issue authority,
 * lock another campaign's target, or replace the claimant's final checks. */
function glpichat_management_waiter_eligible(array $waiter, array $rollout, string $now): bool
{
    if (!$rollout || (int) $rollout['paused'] !== 0 || !in_array($rollout['status'], ['queued', 'running'], true)
        || !in_array($rollout['action'], ['update', 'repair'], true)) { return false; }
    $id = (int) $rollout['id']; $cap = (int) $rollout['concurrency_limit'];
    if ($cap > 0 && glpichat_management_campaign_active($id) >= $cap) { return false; }
    $target = glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS, 'id=' . (int) $waiter['targets_id']);
    if (!$target || (int) $target['rollouts_id'] !== $id || !in_array($target['status'], ['queued', 'waiting'], true)
        || $target['available_at'] > $now) { return false; }
    $machine = glpichat_management_one(GLPICHAT_MANAGEMENT_MACHINES, 'id=' . (int) $target['machines_id']);
    return $machine && $machine['status'] === 'active'
        && (int) $machine['admin_revision'] === (int) $target['expected_admin_revision']
        && !glpichat_management_pending((int) $machine['id'])
        && glpichat_management_interest_prerequisites($rollout, $machine);
}

/** Caller owns dispatch_lock and has recorded its qualified interest. Inspect
 * and remove at most16 unusable heads; a later request continues cleanup.
 * No fixed first250-campaign window can permanently hide a newer campaign.
 * An eligible older claimant gets the next opportunity; it may leave capacity
 * idle until its next contact or bounded interest expiry. No offline grant is
 * created. Unknown authorized work continues occupying actual capacity. */
function glpichat_management_campaign_turn(int $rolloutId, string $now): bool
{
    for ($removed = 0; $removed < GLPICHAT_MANAGEMENT_HEAD_CLEANUP_LIMIT; ++$removed) {
        // Every runtime queue mutation owns dispatch first, including the
        // coalesced full-capacity registration path. FIFO uses a current read;
        // no other queue writer can interleave unique/primary gap locks here.
        $rows = glpichat_desktop_db_rows('SELECT * FROM ' . GLPICHAT_MANAGEMENT_WAITERS . ' ORDER BY id LIMIT 1 FOR UPDATE');
        if (!$rows) { return false; }
        $waiter = $rows[0];
        $now = glpichat_desktop_now();
        $rollout = glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS, 'id=' . (int) $waiter['rollouts_id']);
        if (!glpichat_management_interest_valid($waiter, $now) || !glpichat_management_waiter_eligible($waiter, $rollout, $now)) {
            glpichat_management_interest_drop((int) $waiter['rollouts_id']);
            continue;
        }
        return (int) $waiter['rollouts_id'] === $rolloutId;
    }
    return false;
}
