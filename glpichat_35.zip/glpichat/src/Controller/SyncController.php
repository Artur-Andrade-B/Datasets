<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpichat\Controller;

use Glpi\Controller\AbstractController;
use Glpi\Http\Firewall;
use Glpi\Security\Attribute\SecurityStrategy;
use RuntimeException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

use function glpichat_assert_can_read_room;
use function glpichat_events;
use function glpichat_messages;
use function glpichat_room_id;

require_once dirname(__DIR__) . '/functions.php';

final class SyncController extends AbstractController
{
    #[Route('/Sync', name: 'glpichat_sync', methods: ['GET'])]
    #[SecurityStrategy(Firewall::STRATEGY_AUTHENTICATED)]
    public function __invoke(Request $request): Response
    {
        $tickets_id = $request->query->getInt('tickets_id');
        $room_type = $request->query->getString('room_type');
        $last_message_id = $request->query->getInt('last_message_id');
        $last_event_id = $request->query->getString('last_event_id');

        if ($tickets_id <= 0 || !in_array($room_type, ['public', 'internal'], true)) {
            throw new RuntimeException('Parâmetros de sincronização inválidos.');
        }

        glpichat_assert_can_read_room($tickets_id, $room_type);
        \glpichat_release_session_lock();
        $rooms_id = glpichat_room_id($tickets_id, $room_type);
        $visibleIds = $request->query->all('visible_message_ids');
        $reconcile = \glpichat_message_reconciliation_request($request->query->all(), $last_message_id);
        $envelope = ['rooms_id' => $rooms_id, 'events' => glpichat_events($rooms_id, $last_event_id),
            'messages' => [], 'refreshed_messages' => [], 'removed_message_ids' => [],
            'reconciliation' => \glpichat_message_reconciliation_envelope($reconcile),
            'pending_refresh_ids' => array_values(array_map('intval', array_slice($visibleIds, 0, 200))),
            'next_message_id' => $last_message_id, 'has_more' => false];
        $budget = new \GlpichatMessageBudget();
        $budget->reserve($envelope, 64);
        $page = \glpichat_message_page($rooms_id, $last_message_id, '', $budget);
        if ($reconcile !== null && $reconcile['first']) {
            $envelope['reconciliation'] = \glpichat_reconcile_messages($rooms_id, $reconcile, '', $budget);
        }
        $refresh = \glpichat_refresh_messages($rooms_id, $visibleIds, '', $budget);
        if ($reconcile !== null && !$reconcile['first']) {
            $envelope['reconciliation'] = \glpichat_reconcile_messages($rooms_id, $reconcile, '', $budget);
        }
        return new JsonResponse(array_replace($envelope, $page, $refresh));
    }
}
