import { planReconciliation } from './message-reconciliation.js';

// PHP counts every multipart leaf against max_input_vars (normally 1000).
// Reserve headroom and share the refresh budget across all loaded open rooms;
// per-room limits alone overflow with three tickets / six rooms.
export const POLL_FORM_INPUT_BUDGET = 900;

export function buildPollPayload(channels, openTicketIds, normalizeEventCursor) {
  const openTickets = new Set(openTicketIds.map(Number));
  const eligible = Array.from(channels).filter((channel) =>
    openTickets.has(Number(channel.tickets_id || 0)) && channel.messages_loaded === true);
  if (eligible.length === 0) return [];
  const refreshBudget = POLL_FORM_INPUT_BUDGET - 1 - eligible.length * 8;
  if (refreshBudget < 0) throw new Error('Too many open chat rooms for one poll.');
  const perRoom = Math.min(200, Math.floor(refreshBudget / eligible.length));
  return eligible.map((channel) => {
    const retainedIds = (channel.messages || [])
      .filter((message) => !message.is_optimistic && Number(message.id) > 0)
      .map((message) => Number(message.id));
    const offset = Math.max(0, Number(channel.refresh_offset || 0)) % Math.max(1, retainedIds.length);
    const retained = new Set(retainedIds);
    const pending = Array.from(new Set((channel.pending_refresh_ids || []).map(Number)))
      .filter((id) => retained.has(id)).slice(0, perRoom);
    const visibleIds = [...pending];
    const selected = new Set(pending);
    let scanned = 0;
    while (visibleIds.length < perRoom && scanned < retainedIds.length) {
      const id = retainedIds[(offset + scanned++) % retainedIds.length];
      if (!selected.has(id)) { visibleIds.push(id); selected.add(id); }
    }
    channel.refresh_offset = (offset + scanned) % Math.max(1, retainedIds.length);
    const floor = channel.has_older === false ? 1 : Number(channel.oldest_cursor || retainedIds.reduce((minimum, id) => Math.min(minimum, id), Infinity) || 0);
    const reconciliation = planReconciliation(channel, floor, Number(channel.last_message_id || 0));
    return {
      reconciliation,
      visible_message_ids: visibleIds,
      tickets_id: channel.tickets_id,
      room_type: channel.room_type,
      after_id: channel.last_message_id || 0,
      after_event_id: normalizeEventCursor(channel.last_event_id),
      is_typing: Boolean(channel.isTyping || false),
    };
  });
}

export function createPollForm(payload, csrf) {
  const form = new FormData();
  form.set('_glpi_csrf_token', csrf);
  payload.forEach((item, index) => {
    form.set(`channels[${index}][tickets_id]`, String(item.tickets_id));
    form.set(`channels[${index}][room_type]`, item.room_type);
    form.set(`channels[${index}][after_id]`, String(item.after_id));
    form.set(`channels[${index}][after_event_id]`, String(item.after_event_id));
    form.set(`channels[${index}][is_typing]`, item.is_typing ? '1' : '0');
    if (item.reconciliation) {
      form.set(`channels[${index}][reconcile_after]`, String(item.reconciliation.after));
      form.set(`channels[${index}][reconcile_through]`, String(item.reconciliation.through));
      form.set(`channels[${index}][reconcile_first]`, item.reconciliation.first ? '1' : '0');
    }
    item.visible_message_ids.forEach((id, cursor) => form.set(`channels[${index}][visible_message_ids][${cursor}]`, String(id)));
  });
  return form;
}
