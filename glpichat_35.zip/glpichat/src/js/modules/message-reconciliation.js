// Re-read only the consumed history interval, independently of new-message
// delivery. No private-message tombstones or permanent per-message state.
export const RECONCILE_INTERVAL_MS = 120000;
export const RECONCILE_PAGE_ROWS = 20;
const validId = (value) => Number.isSafeInteger(value) && value >= 0 && value <= 4294967295;
const clock = () => performance.now();

export function resetReconciliation(owner) { delete owner.message_reconciliation; }

export function planReconciliation(owner, floor, through, now = clock()) {
  floor = Number(floor); through = Number(through);
  if (!validId(floor) || floor < 1 || !validId(through) || through < floor || !Number.isFinite(now)) return null;
  const state = owner.message_reconciliation ||= { sweep: null, nextAt: 0, floor, lastNow: now };
  if (now < state.lastNow) state.nextAt = 0; // A recreated/injected elapsed clock cannot strand the timer.
  state.lastNow = now;
  if (floor < state.floor || (state.sweep && through < state.sweep.through)) {
    state.sweep = null; state.nextAt = 0;
  }
  state.floor = floor;
  if (!state.sweep) {
    if (now < state.nextAt) return null;
    state.sweep = { floor, after: floor - 1, through, first: true };
  }
  const sweep = state.sweep;
  return { after: sweep.after, through: sweep.through, first: sweep.first, sweep };
}

export function acceptReconciliation(owner, request, response, now = clock(), refresh = null) {
  const state = owner.message_reconciliation;
  if (!request || !response || !state || state.sweep !== request.sweep
    || request.after !== state.sweep.after || request.through !== state.sweep.through
    || response.after !== request.after || response.through !== request.through
    || !validId(response.next) || response.next < request.after || response.next > request.through
    || typeof response.complete !== 'boolean' || (response.complete ? response.next !== request.through : response.next === request.through)
    || !Array.isArray(response.messages) || response.messages.length > RECONCILE_PAGE_ROWS
    || response.messages.some((message) => !validId(Number(message?.id)) || Number(message.id) <= request.after || Number(message.id) > response.next)) return [];
  // A room may only receive body bytes on every Nth request because another
  // room consumes the shared allowance. Request-count toggling phase-locks
  // with an even room rotation; retain priority until that lane gets service.
  const refreshServed = (Array.isArray(refresh?.refreshed_messages) && refresh.refreshed_messages.length > 0)
    || (Array.isArray(refresh?.pending_refresh_ids) && refresh.pending_refresh_ids.length === 0);
  if (request.first ? response.messages.length > 0 || response.complete : refreshServed) {
    state.sweep.first = !request.first;
  }
  state.sweep.after = response.next;
  if (response.complete) { state.sweep = null; state.nextAt = now + RECONCILE_INTERVAL_MS; }
  return response.messages;
}

// Keep the first currently visible stable row at the same viewport offset when
// restored history is inserted above it. Height-difference anchoring incorrectly
// scrolls for insertions below the viewport.
export function captureTimelineAnchor(container) {
  const viewport = container.getBoundingClientRect();
  for (const node of container.querySelectorAll('[data-timeline-key]')) {
    const bounds = node.getBoundingClientRect();
    if (bounds.bottom > viewport.top && bounds.top < viewport.bottom) {
      return { key: node.dataset.timelineKey, offset: bounds.top - viewport.top, scrollTop: container.scrollTop };
    }
  }
  return { key: '', offset: 0, scrollTop: container.scrollTop };
}

export function restoreTimelineAnchor(container, anchor) {
  if (!anchor) return;
  const row = Array.from(container.querySelectorAll('[data-timeline-key]')).find((node) => node.dataset.timelineKey === anchor.key);
  if (row) container.scrollTop += row.getBoundingClientRect().top - container.getBoundingClientRect().top - anchor.offset;
  else container.scrollTop = anchor.scrollTop;
}
