> **Atualização 1.5.0:** anexos no desktop, indicador persistente de não lidas, correções da interface e revisão de consistência. Atualize o plugin e distribua o par Windows 0.5.0 pelo gerenciamento do GLPI.

# GLPI Chat

[![GitHub Repo stars](https://img.shields.io/github/stars/forq-dev/glpichat?style=social)](https://github.com/forq-dev/glpichat)

Plugin de chat contextual em tempo real para o **GLPI 11.0.7+**, vinculado diretamente a chamados.

Versão atual: **1.5.0-desktop9**. O aplicativo Windows 0.5.0 identifica automaticamente o usuário da sessão Windows por um serviço local e consulta o AD já configurado no GLPI. A instalação administrativa prepara a máquina; o usuário não precisa conectar a conta nem receber arquivo de autorização. Consulte a [nota desta versão](docs/releases/1.5.0-desktop9.md).

O **GLPI Chat** permite a comunicação ágil e integrada entre técnicos, solicitantes e convidados sem a necessidade de ferramentas externas de comunicação (como Slack ou Teams). Ele organiza a conversação em duas salas independentes por chamado: uma sala pública (`Solicitante`) e uma sala interna (`Discussão técnica`).

> ⭐ **Curtiu o GLPI Chat?** Deixe uma estrela no repositório — isso ajuda outros administradores a encontrarem o plugin e apoia o desenvolvimento contínuo.

---

## 🖼️ Visão Geral

![Visão geral do widget de chat integrado ao GLPI](public/img/screenshots/glpi-screenshots.png)

---

## 🚀 Funcionalidades Principais

* **Widget de Chat no Rodapé (UX Dinâmica)**:
  * O launcher geral fica fixo no rodapé e abre a lista de conversas ativas.
  * Cada chamado selecionado abre um chatbox individual ao lado da barra inferior.
  * Filtros rápidos por status de chamados: `Novo`, `Processando` e `Pendente`.
* **Notificações Visuais de Mensagens Pendentes**:
  * Badge numérico no ícone do widget: total de mensagens não lidas de todos os chamados.
  * Dentro de cada chamado, abas **Solicitante** e **Discussão técnica** com badges individuais de não lidas.
  * As cores dos badges acompanham o tema visual ativo do GLPI (claro/escuro) — não há cores fixas.
* **🔗 Gestão de Convidados (Invites)**:
  * Criação de **links seguros de uso único** com validade de 1 hora para convidar terceiros externos.
  * Aba "Gestão de invites" no chamado com ações de criar, reemitir, cancelar e desconectar convidados.
  * Status visual de cada convite: ativo, expirado, cancelado, aceito, em sessão, sessão encerrada.
  * O convidado acessa o chat público via link, vê contador regressivo de expiração e pode enviar mensagens e anexos.
* **Histórico e Auditoria**:
  * **Histórico**: timeline unificada com mensagens + eventos do chamado (mudanças de status, prioridade, atribuições, entrada/saída de participantes). Paginação automática ao rolar para cima.
  * **Auditoria**: aba "Auditoria do Chat" no chamado com mensagens, convites e eventos de sessão, sujeita à retenção configurável (padrão 180 dias).

---

## 📋 Requisitos Mínimos

* **GLPI**: versão `11.0.7` ou superior.
* **PHP**: versão `8.2` ou superior.
* **Banco de Dados**: MySQL ou MariaDB compatível com GLPI.

---

## ⚙️ Instalação Rápida

### 1. Clonar o repositório

Acesse a pasta de plugins do seu GLPI e clone o repositório:

```bash
cd /var/www/html/glpi/plugins
git clone https://github.com/forq-dev/glpichat.git glpichat
```

> Se preferir instalar via ZIP, extraia o conteúdo de forma que o caminho final seja `plugins/glpichat/`.

### 2. Ajustar permissões

Defina o proprietário dos arquivos para o usuário do servidor web (substitua `www-data` pelo usuário correto do seu ambiente — `apache` no CentOS/RHEL, `www-data` no Debian/Ubuntu):

```bash
chown -R www-data:www-data /var/www/html/glpi/plugins/glpichat
find /var/www/html/glpi/plugins/glpichat -type d -exec chmod 755 {} \;
find /var/www/html/glpi/plugins/glpichat -type f -exec chmod 644 {} \;
```

### 3. Ativar no GLPI

1. Acesse o painel administrativo do GLPI: **Administração > Plugins**.
2. Localize o plugin **GLPI Chat** na lista, clique em **Instalar** e depois em **Ativar**.

---

## ⚠️ Configuração Obrigatória Pós-Instalação

Após ativar o plugin, acesse **Configuração > Plugins > GLPI Chat** e preencha o campo:

**Usuário associado a mensagens de convidados externos**

Esse campo define qual usuário do GLPI será registrado como autor dos followups criados no ticket quando um convidado externo envia uma mensagem. **Sem essa configuração, o fluxo de convites não funcionará** — o convidado verá uma mensagem de erro ao tentar acessar o link do convite.

> **Recomendação:** crie um usuário dedicado (ex: `Chat Bot` ou `Suporte Externo`) e selecione-o nesse campo. Esse usuário não precisa ter acesso ao GLPI — ele serve apenas como autor técnico dos registros.

---

## 🔗 Gestão de Convidados
> 📖 [Documentação técnica completa](docs/features/invites.md)

Permite convidar terceiros externos para o chat público de um chamado via link seguro de uso único com validade de 1 hora — sem necessidade de conta no GLPI.

### Como funciona

O técnico acessa a aba **"Gestão de invites"** dentro de um chamado e cria um convite informando **nome** (obrigatório) e **email** (opcional) do convidado. O sistema gera um **link único** que deve ser enviado manualmente ao convidado por qualquer meio externo.

O convidado clica no link, vê a página do chat com o nome do chamado e um contador regressivo de expiração. Pode enviar mensagens e anexos enquanto a sessão estiver válida.

### Configuração de Permissões

**Convidar terceiros** (`plugin_glpichat_invite`) — o que cada coluna libera:
- **Read**: visualizar a aba "Gestão de invites" e os convites existentes
- **Write**: criar novos links de convite
- **Update**: reemitir links existentes e encerrar sessões ativas de convidados

**Matriz recomendada por perfil:**

| Opção | Coluna | Solicitante | Técnico | Líder Técnico | Gerente/TI |
|-------|--------|:-----------:|:-------:|:-------------:|:----------:|
| Convidar terceiros | Read | ❌ | ✅ | ✅ | ✅ |
| | Write | ❌ | ✅ | ✅ | ✅ |
| | Update | ❌ | ✅ | ✅ | ✅ |

→ [Ver documentação técnica completa](docs/features/invites.md)

---

## 🔔 Notificações Personalizadas
> 📖 [Documentação técnica completa](docs/features/notifications.md)

O plugin registra **8 eventos de notificação** e os modos nativos AJAX e email do GLPI. Os canais efetivamente habilitados e o tempo de entrega pertencem ao subsistema de notificações do GLPI; não passam pelo Poll do widget.

### Como configurar

1. Acesse **Administração > Notificações** no GLPI
2. Filtre por "GLPI CHAT" na lista de notificações
3. Edite cada notificação como desejar — modelo de email, destinatários, ativar/desativar

### Eventos disponíveis

| Evento | Disparado quando |
|--------|-----------------|
| `glpichat_public_message` | Mensagem enviada no canal Solicitante |
| `glpichat_internal_message` | Mensagem enviada no canal Discussão técnica |
| `glpichat_guest_message` | Convidado externo envia mensagem |
| `glpichat_guest_joined` | Convidado aceita o convite e entra no chat |
| `glpichat_guest_left` | Convidado sai do chat |
| `glpichat_guest_left_timeout` | Sessão do convidado expira por inatividade |
| `glpichat_user_joined` | Suportado pelo helper de entrada quando o fluxo solicita notificação; History/Poll/MarkRead do perf2 preservam presença/evento, mas não disparam esta entrega síncrona |
| `glpichat_user_left` | Usuário executa a saída explícita da sala |

→ [Ver documentação técnica completa](docs/features/notifications.md)

---

## 📜 Histórico e Auditoria do Chat
> 📖 [Documentação técnica completa](docs/features/audit.md)

O chat mantém dois registros distintos: uma **linha do tempo** no widget e uma **aba de Auditoria** no chamado. As retenções são configuráveis; os padrões são 30 dias para eventos, 365 para mensagens e 180 para auditoria.

### Linha do Tempo (Timeline)

Exibe em ordem cronológica mensagens, anexos e eventos de sistema. A abertura carrega até 50 mensagens e o recorte atual de eventos separadamente; ao rolar para cima, pagina apenas mensagens antigas em lotes de até 50.

### Aba de Auditoria

Visível para perfis com permissão `plugin_glpichat_view_audit` (Read). Exibe **Data/Hora**, **Ação**, **Ator** e **Detalhes** dos registros ainda dentro da retenção configurada (padrão 180 dias).

### Configuração de Permissões

**Ver auditoria** (`plugin_glpichat_view_audit`):
- **Read**: exibe a aba "Auditoria do Chat" no chamado

**Matriz recomendada por perfil:**

| Opção | Coluna | Solicitante | Técnico | Líder Técnico | Gerente/TI |
|-------|--------|:-----------:|:-------:|:-------------:|:----------:|
| Ver auditoria | Read | ❌ | ❌ | ✅ | ✅ |

→ [Ver documentação técnica completa](docs/features/audit.md)

---

## 🔑 Gestão de Permissões (Profile Rights)

O GLPI Chat se integra ao sistema nativo de Perfis do GLPI. A configuração é feita em **Administração > Perfis**, sob a aba **GLPI Chat**.

### Opções e colunas disponíveis

1. **Canal publico** (`plugin_glpichat_public`)
   * **Read**: habilita o widget de chat no rodapé e leitura do canal público (Solicitante)
   * **Write**: habilita o envio de mensagens e anexos no canal público

2. **Canal interno** (`plugin_glpichat_internal`)
   * **Read**: exibe a aba Discussão técnica e permite ler mensagens internas
   * **Write**: permite enviar mensagens no canal interno

3. **Convidar terceiros** (`plugin_glpichat_invite`)
   * **Read**: visualizar a aba de participantes e convites existentes
   * **Write**: criar novos links de convite
   * **Update**: reemitir ou cancelar links e encerrar sessões

4. **Ver auditoria** (`plugin_glpichat_view_audit`)
   * **Read**: exibe a aba de Auditoria no chamado

5. **Administrar plugin** (`plugin_glpichat_admin`)
   * **Read**: visualizar configurações do plugin
   * **Update / Write**: editar e salvar configurações globais

### Matriz de configuração recomendada por perfil

| Opção no Profile | Coluna | Solicitante | Técnico | Líder Técnico | Gerente/TI |
|:-----------------|:------:|:-----------:|:-------:|:-------------:|:----------:|
| Canal publico | Read | ✅ | ✅ | ✅ | ✅ |
| | Write | ✅ | ✅ | ✅ | ✅ |
| Canal interno | Read | ❌ | ✅ | ✅ | ✅ |
| | Write | ❌ | ✅ | ✅ | ✅ |
| Convidar terceiros | Read | ❌ | ✅ | ✅ | ✅ |
| | Update | ❌ | ✅ | ✅ | ✅ |
| | Write | ❌ | ✅ | ✅ | ✅ |
| Ver auditoria | Read | ❌ | ❌ | ✅ | ✅ |
| Administrar plugin | Read | ❌ | ❌ | ❌ | ✅ |
| | Update | ❌ | ❌ | ❌ | ✅ |
| | Write | ❌ | ❌ | ❌ | ✅ |

---

## 🛠️ Documentação Técnica Detalhada

Para desenvolvedores, administradores de infraestrutura e técnicos que precisam entender ou alterar o código interno do plugin, consulte os guias avançados em `docs/`:

* 📖 [**Índice de Guias Técnicos**](docs/README.md)
* 💾 [**Schema de Banco de Dados**](docs/architecture/database/schema.md)
* 🔄 [**Polling e Sincronização**](docs/architecture/flows/polling.md)
* 🎨 [**Arquitetura do Frontend e Widget**](docs/architecture/frontend/widget.md)
* 🔑 [**Sistema de Permissões (Integração GLPI)**](docs/architecture/glpi-integration/permissions.md)
* ⚙️ [**Ambiente e Configuração (pré-requisitos de deploy)**](docs/architecture/glpi-integration/environment-and-config.md)
* 🧪 [**Suíte de Testes e QA**](tests/README.md)
* 📈 [**Testes de Carga (k6) e Capacidade**](docs/architecture/performance/load-testing.md)

<br>

<p align="center">
  <sub>━━━━━━━━━━━━━━━━━━━━━━━</sub><br>
  <sub>Curtiu o plugin? Deixe uma ⭐ no repositório para ajudar outros administradores a encontrá-lo.</sub><br>
  <sub>Desenvolvido e mantido com apoio de <a href="https://www.forq.com.br/">Forq</a></sub>
</p>
