# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.1] - 2026-08-24

### Added

- Added a browser-widget kill switch and bounded channel-discovery/request-timeout settings.
- Added a bounded automatic action for expiring inactive participant presence outside normal Poll requests.
- Reserved the future desktop protocol with a constant-cost, data-free `External/V1/Chat/Capabilities` response. Functional desktop authentication and chat routes remain unavailable.

### Changed

- Browser bootstrap now creates only the launcher. It defers Channels, Config, History, invites and polling until the user explicitly opens Chat.
- Polling is completion-driven, single-flight, inactive while hidden, and stopped when no launcher or chat window is open.
- Channel discovery now applies a hard candidate budget before ticket/room hydration and never creates rooms in its metadata GET.
- The legacy authenticated `/Sync` GET no longer creates rooms and releases the session before bounded message/event reads.
- Missing rooms for a focused ticket are created only by the explicit CSRF-protected `Widget/Open` command after the user activates Chat.
- Read-only Channels and Config requests release the PHP session lock after login/CSRF context is captured; state-changing Poll and History paths retain normal session serialization.
- Participant expiry is capped per cron execution instead of scanning the installation inside every user Poll.
- Participant expiry includes legacy rows with null `last_activity`, using `joined_at` as a bounded fallback.
- Plugin initialization no longer performs runtime schema, right or notification mutations; compatibility fields remain part of the explicit install/update callback.
- Message requests no longer create a global GLPI RequestType when the managed object is missing; they use GLPI's native followup default.

### Fixed

- Fixed a cursor error that could permanently skip messages when more than 50 arrived between polls. Poll now advances only to the last returned message and advertises `has_more` until the room is drained.
- Prevented idle and hidden GLPI pages from continuously competing with native navigation for PHP session, worker, database and browser resources.
- Added bounded browser request timeouts so a failed operation cannot block the request queue indefinitely.
- Bounded the browser request queue and prioritized user actions over queued background synchronization.
- Bounded retained per-channel timelines to 500 messages and 250 events.
- Non-idempotent Send, Upload, Invite and Reissue operations are not aborted by the generic read timeout, avoiding false failure/retry duplicates after an unknown server commit.
- Prevented attachment binaries from being sent once to the text endpoint and again to the upload endpoint.
- Prevented a malformed backlog response from creating an endless zero-delay drain loop by requiring cursor progress.
- Purged cached and rendered room content when Poll reports that access to the room has been revoked.

### Limitations

- This is a laboratory qualification build (`lab1`). PHP/GLPI/MySQL integration has not been executed in the build workspace.
- The formal recovery migration framework, durable per-user read state, followup projection, external device enrollment/authentication, desktop chat API and managed widget rollout remain future release gates.

## [1.0.0] - 2026-08-03

### Added

- Enhanced launcher notification rendering with improved validation for typing indicators
- Improved chat widget interaction and performance optimization
- User selection for external followup associations in chat configuration
- User join/leave notification events and improved chat widget state handling
- Recipient filter to prevent unauthorized internal message notification delivery
- Per-participant send rate limiting to prevent abuse; guest authentication failure audit logging
- Last activity time tracking for chat participants with updated invite guard validation
- Notification flow for secure message handling with updated email templates
- Modular architecture for chat system with HTML sanitization security features
- Form submission helper and Enter-to-send functionality for improved user experience
- Audit log tab for ticket chat with refactored tab management for multiple entries
- Drag-and-drop file upload functionality and system notifications for chat events
- Dynamic launcher positioning, image lightbox, and persistent session state for the chat widget
- Overview section with a widget screenshot in the main README
- GitHub star badge and call-out in the README encouraging repository stars
- Contribution guide (`CONTRIBUTING.md`) for external contributors
- Environment variable example file (`.env.example`) covering the test suite
- GitHub issue templates — bug report and feature request — under `.github/ISSUE_TEMPLATE/`

### Changed

- Plugin now supports dynamic base URL to enable proper operation in GLPI subdirectories
- Error messages localized to Portuguese; improved internal event handling
- Standardized the project support footer across all documentation files (`README.md` and `docs/`)

### Fixed

- Improved dark theme color contrast for better readability in dark mode
- Fixed the "Create invite" button getting stuck on "Creating..." after a successful invite creation
- Fixed a guest session crash caused by an unhandled error when the session expired mid-action
- Fixed invite acceptance showing raw unstyled text instead of a proper error page when invite limits were exceeded
- Fixed invite and accept rate limits not being enforced due to an incorrect internal counter reference
- Fixed an incorrectly formatted internal event cursor used for guest activity tracking
- Corrected CSS syntax error in linear-gradient background property
- Fixed invite revocation logic enforcement
- Corrected the notification events table in `README.md` and `docs/features/notifications.md`, which listed 6 events when the code actually registers 8
- Fixed the screenshot link in `plugin.xml`, which pointed to a non-existent file
- Fixed the logo link in `plugin.xml`, which did not resolve to a valid image
- Fixed the published version's `download_url` in `plugin.xml`, which pointed to the unstable `main` branch zip instead of the fixed tag artifact
- Filled in the empty `homepage` field in `setup.php`
- Filled in the copyright notice placeholder in the `LICENSE` file

### Security

- Hardened XSS protection in URL path handling to prevent injection attacks
- Hardened guest session validation and controller access controls
- Implemented security hardening for file uploads with size validation and type checking
- Enforced CSRF token validation on all state-changing operations
- Implemented protection against Stored XSS vulnerabilities
- Restricted asset loading to prevent unauthorized resource inclusion
- Validated all file uploads to prevent malicious file handling
- Removed a hardcoded local absolute path exposing a developer's username and directory layout from a test helper script (`tests/helpers/patch_animations.py`)

[unreleased]: https://github.com/forq-dev/glpichat/compare/v1.0.1...HEAD
[1.0.1]: https://github.com/forq-dev/glpichat/compare/v1.0.0...v1.0.1
[1.0.0]: https://github.com/forq-dev/glpichat/releases/tag/v1.0.0
