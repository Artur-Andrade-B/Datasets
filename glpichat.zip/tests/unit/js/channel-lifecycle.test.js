import { describe, expect, it } from 'vitest';
import { purgeUnavailableChannelState } from '../../../src/js/modules/channel-lifecycle.js';

const createState = () => {
  const publicChannel = {
    tickets_id: 42,
    room_type: 'public',
    unread_count: 2,
    messages: [{ id: 1, content: 'must be purged' }],
    events: [{ id: 'event-1' }],
    renderedMessageIds: new Set([1]),
    messages_loaded: true,
  };
  const internalChannel = {
    tickets_id: 42,
    room_type: 'internal',
    unread_count: 3,
    messages: [{ id: 2 }],
    events: [],
  };
  return {
    channels: new Map([
      ['42:public', publicChannel],
      ['42:internal', internalChannel],
    ]),
    tickets: new Map([[42, {
      id: 42,
      channels: { public: '42:public', internal: '42:internal' },
      activeTab: 'public',
      unreadTotal: 5,
    }]]),
    openTicketIds: [42],
    manualTicketIds: new Set([42]),
    transientTicketIds: new Set(),
    closedTicketIds: new Set(),
    closedTicketTimestamps: new Map(),
    minimizedSnapshot: { launcherOpen: false, openTicketIds: [42] },
    activeTicketId: 42,
    publicChannel,
  };
};

describe('unavailable channel lifecycle', () => {
  it('purges content and selects a remaining authorized room', () => {
    const state = createState();

    const result = purgeUnavailableChannelState(state, '42:public', {
      tickets_id: 42,
      room_type: 'public',
      unavailable: true,
    });

    expect(result).toEqual({ changed: true, ticketId: 42, ticketRemoved: false });
    expect(state.channels.has('42:public')).toBe(false);
    expect(state.publicChannel.messages).toEqual([]);
    expect(state.publicChannel.events).toEqual([]);
    expect(state.publicChannel.renderedMessageIds.size).toBe(0);
    expect(state.tickets.get(42).channels).toEqual({ internal: '42:internal' });
    expect(state.tickets.get(42).activeTab).toBe('internal');
    expect(state.tickets.get(42).unreadTotal).toBe(3);
    expect(state.openTicketIds).toEqual([42]);
  });

  it('removes the ticket and every persisted open-state reference after the last room is revoked', () => {
    const state = createState();
    purgeUnavailableChannelState(state, '42:public', { unavailable: true });

    const result = purgeUnavailableChannelState(state, '42:internal', {
      tickets_id: 42,
      room_type: 'internal',
      unavailable: true,
    });

    expect(result).toEqual({ changed: true, ticketId: 42, ticketRemoved: true });
    expect(state.tickets.has(42)).toBe(false);
    expect(state.openTicketIds).toEqual([]);
    expect(state.manualTicketIds.has(42)).toBe(false);
    expect(state.minimizedSnapshot.openTicketIds).toEqual([]);
    expect(state.activeTicketId).toBe(0);
  });
});
