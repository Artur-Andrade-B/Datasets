import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  fetchJson,
  getCsrfToken,
  postForm,
  setCsrfToken,
  setRequestTimeoutMs
} from '../../../src/js/modules/http.js';

const createJsonResponse = (payload, status = 200) => new Response(
  JSON.stringify(payload),
  {
    status,
    headers: {
      'Content-Type': 'application/json',
    },
  }
);

describe('HTTP Module', () => {
  beforeEach(() => {
    setCsrfToken('');
    setRequestTimeoutMs(15000);
  });

  afterEach(() => {
    vi.restoreAllMocks();
    vi.unstubAllGlobals();
    setCsrfToken('');
    setRequestTimeoutMs(15000);
    vi.useRealTimers();
  });

  it('keeps the active CSRF token in module state', () => {
    setCsrfToken('token-123');
    expect(getCsrfToken()).toBe('token-123');
  });

  it('serializes headers, injects the CSRF token and refreshes it from the response', async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      createJsonResponse({
        ok: true,
        _glpi_csrf_token: 'token-456',
      })
    );
    vi.stubGlobal('fetch', fetchMock);

    const formData = new FormData();
    formData.set('_glpi_csrf_token', 'stale-token');
    formData.set('message', 'hello');

    setCsrfToken('token-123');

    const result = await fetchJson('/api/messages', {
      method: 'POST',
      headers: { 'X-Custom': 'value' },
      body: formData,
    });

    expect(result).toEqual({
      ok: true,
      _glpi_csrf_token: 'token-456',
    });
    expect(getCsrfToken()).toBe('token-456');
    expect(formData.get('_glpi_csrf_token')).toBe('token-123');
    expect(fetchMock).toHaveBeenCalledTimes(1);

    const [url, requestOptions] = fetchMock.mock.calls[0];
    expect(url).toBe('/api/messages');
    expect(requestOptions.method).toBe('POST');
    expect(requestOptions.credentials).toBe('same-origin');
    expect(requestOptions.headers).toBeInstanceOf(Headers);
    expect(requestOptions.headers.get('X-Requested-With')).toBe('XMLHttpRequest');
    expect(requestOptions.headers.get('Accept')).toBe('application/json');
    expect(requestOptions.headers.get('X-Custom')).toBe('value');
    expect(requestOptions.headers.get('X-Glpi-Csrf-Token')).toBe('token-123');
  });

  it('serializes requests so the second fetch waits for the first one', async () => {
    let resolveFirst;
    const fetchMock = vi.fn()
      .mockImplementationOnce(() => new Promise((resolve) => {
        resolveFirst = resolve;
      }))
      .mockResolvedValueOnce(createJsonResponse({ second: true }));
    vi.stubGlobal('fetch', fetchMock);

    const firstPromise = fetchJson('/first');
    const secondPromise = fetchJson('/second');

    await Promise.resolve();
    expect(fetchMock).toHaveBeenCalledTimes(1);

    resolveFirst(createJsonResponse({ first: true }));
    await expect(firstPromise).resolves.toEqual({ first: true });

    await Promise.resolve();
    expect(fetchMock).toHaveBeenCalledTimes(2);
    await expect(secondPromise).resolves.toEqual({ second: true });
  });

  it('runs an interactive request before already-queued background work', async () => {
    const resolvers = new Map();
    const fetchMock = vi.fn().mockImplementation((url) => new Promise((resolve) => {
      resolvers.set(url, resolve);
    }));
    vi.stubGlobal('fetch', fetchMock);

    const active = fetchJson('/background-active', { queuePriority: 'background' });
    await Promise.resolve();
    const queuedBackground = fetchJson('/background-queued', { queuePriority: 'background' });
    const interactive = fetchJson('/interactive');

    resolvers.get('/background-active')(createJsonResponse({ active: true }));
    await expect(active).resolves.toEqual({ active: true });
    await Promise.resolve();
    await Promise.resolve();

    expect(fetchMock.mock.calls.map(([url]) => url)).toEqual([
      '/background-active',
      '/interactive',
    ]);

    resolvers.get('/interactive')(createJsonResponse({ interactive: true }));
    await expect(interactive).resolves.toEqual({ interactive: true });
    await Promise.resolve();
    await Promise.resolve();

    expect(fetchMock.mock.calls.map(([url]) => url)).toEqual([
      '/background-active',
      '/interactive',
      '/background-queued',
    ]);
    resolvers.get('/background-queued')(createJsonResponse({ background: true }));
    await expect(queuedBackground).resolves.toEqual({ background: true });
  });

  it('throws a canonical parse error when the body is not JSON', async () => {
    const fetchMock = vi.fn().mockResolvedValue(new Response('plain text body', {
      status: 200,
      headers: {
        'Content-Type': 'text/plain',
      },
    }));
    vi.stubGlobal('fetch', fetchMock);

    await expect(fetchJson('/broken')).rejects.toThrow('Unexpected response format (200).');
  });

  it('prefers the GLPI message field for failed responses', async () => {
    const fetchMock = vi.fn().mockResolvedValue(createJsonResponse({
      message: 'Request rejected by GLPI',
      error: true,
    }, 400));
    vi.stubGlobal('fetch', fetchMock);

    await expect(fetchJson('/denied')).rejects.toThrow('Request rejected by GLPI');
  });

  it('forwards POST FormData through the same fetch pipeline', async () => {
    const fetchMock = vi.fn().mockResolvedValue(createJsonResponse({ saved: true }));
    vi.stubGlobal('fetch', fetchMock);

    const formData = new FormData();
    formData.set('message', 'hello');

    await expect(postForm('/api/messages', formData, { keepalive: true })).resolves.toEqual({ saved: true });
    expect(fetchMock).toHaveBeenCalledTimes(1);

    const [, requestOptions] = fetchMock.mock.calls[0];
    expect(requestOptions.method).toBe('POST');
    expect(requestOptions.keepalive).toBe(true);
    expect(requestOptions.body).toBe(formData);
    expect(requestOptions.credentials).toBe('same-origin');
  });

  it('times out a stalled request and lets the queue continue', async () => {
    vi.useFakeTimers();
    setRequestTimeoutMs(1000);

    const fetchMock = vi.fn()
      .mockImplementationOnce((_url, options) => new Promise((_resolve, reject) => {
        options.signal.addEventListener('abort', () => {
          reject(new DOMException('Aborted', 'AbortError'));
        }, { once: true });
      }))
      .mockResolvedValueOnce(createJsonResponse({ recovered: true }));
    vi.stubGlobal('fetch', fetchMock);

    const stalled = fetchJson('/stalled');
    const stalledExpectation = expect(stalled).rejects.toThrow('Request timed out.');
    await vi.advanceTimersByTimeAsync(1000);
    await stalledExpectation;

    await expect(fetchJson('/recovered')).resolves.toEqual({ recovered: true });
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });

  it('applies the timeout to queue wait time, not only network time', async () => {
    vi.useFakeTimers();
    setRequestTimeoutMs(1000);

    const fetchMock = vi.fn().mockImplementation((_url, options) => new Promise((_resolve, reject) => {
      options.signal.addEventListener('abort', () => {
        reject(new DOMException('Aborted', 'AbortError'));
      }, { once: true });
    }));
    vi.stubGlobal('fetch', fetchMock);

    const first = fetchJson('/first-stalled');
    const queued = fetchJson('/queued');
    const firstExpectation = expect(first).rejects.toThrow('Request timed out.');
    const queuedExpectation = expect(queued).rejects.toThrow('Request timed out while waiting for Chat.');

    await vi.advanceTimersByTimeAsync(1000);
    await firstExpectation;
    await queuedExpectation;
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });
});
