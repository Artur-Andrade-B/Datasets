import { describe, expect, it } from 'vitest';
import {
  buildTextPayload,
  buildUploadPayload,
} from '../../../src/js/modules/payload.js';

describe('chat request payload separation', () => {
  it('keeps binary data out of the text message payload', () => {
    const payload = buildTextPayload('hello', {
      tickets_id: 42,
      room_type: 'public',
    });

    expect(payload.get('content')).toBe('hello');
    expect(payload.get('tickets_id')).toBe('42');
    expect(payload.get('room_type')).toBe('public');
    expect(payload.has('file')).toBe(false);
  });

  it('puts exactly one file in the upload payload and no text message', () => {
    const file = new File(['evidence'], 'evidence.txt', { type: 'text/plain' });
    const payload = buildUploadPayload(file, { tickets_id: 42 });

    expect(payload.getAll('file')).toHaveLength(1);
    expect(payload.get('file')).toBeInstanceOf(File);
    expect(payload.get('file').name).toBe('evidence.txt');
    expect(payload.get('tickets_id')).toBe('42');
    expect(payload.has('content')).toBe(false);
  });

  it('rejects an empty upload placeholder', () => {
    expect(() => buildUploadPayload(new File([], 'empty.txt'))).toThrow('A non-empty File is required.');
  });
});
