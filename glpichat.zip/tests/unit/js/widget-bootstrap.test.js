import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

describe('browser widget bootstrap containment', () => {
  beforeEach(() => {
    document.body.innerHTML = '';
    window.__glpiChatWidgetBootstrapped = false;
    window.CFG_GLPI = { root_doc: '' };
  });

  afterEach(() => {
    document.body.innerHTML = '';
    delete window.__glpiChatWidgetBootstrapped;
    delete window.CFG_GLPI;
    vi.unstubAllGlobals();
    vi.useRealTimers();
  });

  it('mounts only the launcher and remains network-idle until explicit activation', async () => {
    vi.useFakeTimers();
    const fetchMock = vi.fn();
    vi.stubGlobal('fetch', fetchMock);

    await import('../../../src/js/glpichat-widget.js');
    document.dispatchEvent(new Event('DOMContentLoaded'));
    await Promise.resolve();
    await Promise.resolve();

    expect(document.querySelector('.glpichat-widget')).not.toBeNull();
    expect(document.querySelector('[data-role="launcher-panel"]').hidden).toBe(true);
    expect(fetchMock).not.toHaveBeenCalled();

    await vi.advanceTimersByTimeAsync(5 * 60 * 1000);
    expect(fetchMock).not.toHaveBeenCalled();
  });
});
