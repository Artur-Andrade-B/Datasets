#!/usr/bin/env bash

set -euo pipefail

base_url="${GLPICHAT_BASE_URL:-http://localhost:8080}"
body_file="$(mktemp)"
headers_file="$(mktemp)"
trap 'rm -f "$body_file" "$headers_file"' EXIT

status="$(curl --silent --show-error \
  --dump-header "$headers_file" \
  --output "$body_file" \
  --write-out '%{http_code}' \
  "$base_url/plugins/glpichat/External/V1/Chat/Capabilities")"

test "$status" = "200"
grep -Eq '"service"[[:space:]]*:[[:space:]]*"glpichat"' "$body_file"
grep -Eq '"external_api_version"[[:space:]]*:[[:space:]]*"0"' "$body_file"
grep -Eq '"status"[[:space:]]*:[[:space:]]*"reserved"' "$body_file"
grep -Eq '"enabled"[[:space:]]*:[[:space:]]*false' "$body_file"
grep -Eiq '^cache-control:.*no-store' "$headers_file"

if grep -Eiq 'users_id|tickets_id|rooms_id|messages|token|cookie|objectguid' "$body_file"; then
  echo "Capabilities response leaked a forbidden identity/chat field." >&2
  exit 1
fi

echo "[PASS] External V1 capabilities endpoint is bounded and disabled."
