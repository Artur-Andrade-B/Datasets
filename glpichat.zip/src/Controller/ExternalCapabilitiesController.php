<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpichat\Controller;

use Glpi\Controller\AbstractController;
use Glpi\Http\Firewall;
use Glpi\Security\Attribute\SecurityStrategy;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

/**
 * Constant-cost discovery document for future desktop clients.
 *
 * This endpoint intentionally performs no session, database, directory, user,
 * ticket or room lookup. It is not authentication and does not expose chat.
 */
final class ExternalCapabilitiesController extends AbstractController
{
    #[Route(
        '/External/V1/Chat/Capabilities',
        name: 'glpichat_external_v1_chat_capabilities',
        methods: ['GET']
    )]
    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]
    public function capabilities(Request $request): Response
    {
        $response = new JsonResponse([
            'service' => 'glpichat',
            'plugin_version' => defined('PLUGIN_GLPICHAT_VERSION')
                ? PLUGIN_GLPICHAT_VERSION
                : 'unknown',
            'build' => defined('PLUGIN_GLPICHAT_BUILD')
                ? PLUGIN_GLPICHAT_BUILD
                : 'unknown',
            'external_api_version' => '0',
            'status' => 'reserved',
            'enabled' => false,
            'authentication' => null,
            'features' => [],
        ]);
        $response->headers->set('Cache-Control', 'no-store, max-age=0');
        $response->headers->set('Pragma', 'no-cache');
        $response->headers->set('X-Content-Type-Options', 'nosniff');

        return $response;
    }
}
