/**
 * HTTP Module
 * Handles a bounded request queue and CSRF synchronization
 */

let csrfToken = "";
let defaultTimeoutMs = 15000;

/**
 * Set the active CSRF token for headers/forms
 * @param {string} token 
 */
export const setCsrfToken = (token) => {
  csrfToken = token;
};

/**
 * Get the current CSRF token
 * @returns {string}
 */
export const getCsrfToken = () => csrfToken;

export const setRequestTimeoutMs = (timeoutMs) => {
  const normalized = Number(timeoutMs);
  defaultTimeoutMs = Number.isFinite(normalized)
    ? Math.max(1000, Math.min(60000, Math.trunc(normalized)))
    : 15000;
};

const MAX_PENDING_REQUESTS = 8;
const requestQueues = {
  interactive: [],
  background: [],
};
let requestRunning = false;

const pendingRequestCount = () => requestQueues.interactive.length + requestQueues.background.length;

const removeQueuedTask = (task) => {
  for (const queue of Object.values(requestQueues)) {
    const index = queue.indexOf(task);
    if (index >= 0) {
      queue.splice(index, 1);
      return true;
    }
  }
  return false;
};

const runNextRequest = () => {
  if (requestRunning) {
    return;
  }
  const task = requestQueues.interactive.shift() || requestQueues.background.shift();
  if (!task) {
    return;
  }

  task.started = true;
  if (task.waitTimer !== null) {
    window.clearTimeout(task.waitTimer);
  }
  requestRunning = true;
  task.execute()
    .then(task.resolve, task.reject)
    .finally(() => {
      requestRunning = false;
      runNextRequest();
    });
};

const enqueueRequest = (execute, priority, deadlineAt) => new Promise((resolve, reject) => {
  if (pendingRequestCount() >= MAX_PENDING_REQUESTS) {
    if (priority === "interactive" && requestQueues.background.length > 0) {
      const dropped = requestQueues.background.pop();
      if (dropped.waitTimer !== null) {
        window.clearTimeout(dropped.waitTimer);
      }
      dropped.reject(new Error("Background Chat request was superseded."));
    } else {
      reject(new Error("Chat request queue is busy."));
      return;
    }
  }

  const task = {
    execute,
    resolve,
    reject,
    started: false,
    waitTimer: null,
  };
  if (deadlineAt !== null) {
    const waitMs = Math.max(0, deadlineAt - Date.now());
    task.waitTimer = window.setTimeout(() => {
      if (task.started || !removeQueuedTask(task)) {
        return;
      }
      reject(new Error("Request timed out while waiting for Chat."));
    }, waitMs);
  }

  requestQueues[priority].push(task);
  runNextRequest();
});

/**
 * Perform a bounded JSON fetch request.
 *
 * Background scheduling/coalescing belongs to the caller. The short queue here
 * preserves CSRF response ordering between user mutations and reads; each
 * request is bounded by a timeout, so a failed request cannot block it forever.
 * @param {string} url 
 * @param {Object} [options] 
 * @returns {Promise<Object>}
 */
export const fetchJson = async (url, options) => {
  const suppliedOptions = options || {};
  const queuePriority = suppliedOptions.queuePriority === "background"
    ? "background"
    : "interactive";
  const timeoutEnabled = suppliedOptions.timeoutMs !== false;
  const timeoutMs = Number.isFinite(Number(suppliedOptions.timeoutMs))
    ? Math.max(1000, Math.min(60000, Math.trunc(Number(suppliedOptions.timeoutMs))))
    : defaultTimeoutMs;
  const deadlineAt = timeoutEnabled ? Date.now() + timeoutMs : null;
  return enqueueRequest(async () => {
  const remainingMs = deadlineAt === null ? null : deadlineAt - Date.now();
  if (remainingMs !== null && remainingMs <= 0) {
    throw new Error("Request timed out while waiting for Chat.");
  }
  const callerSignal = suppliedOptions.signal;
  const controller = new AbortController();
  const abortFromCaller = () => controller.abort(callerSignal?.reason);
  if (callerSignal) {
    if (callerSignal.aborted) {
      abortFromCaller();
    } else {
      callerSignal.addEventListener("abort", abortFromCaller, { once: true });
    }
  }
  const timeoutId = remainingMs === null
    ? null
    : window.setTimeout(() => controller.abort(), remainingMs);

  try {
    const requestOptions = {
      credentials: "same-origin",
      ...suppliedOptions,
      signal: controller.signal,
    };
    delete requestOptions.timeoutMs;
    delete requestOptions.queuePriority;
    const headers = new Headers(requestOptions.headers || {});
    headers.set("X-Requested-With", "XMLHttpRequest");
    headers.set("Accept", "application/json");
    if (csrfToken) {
      headers.set("X-Glpi-Csrf-Token", csrfToken);
    }
    requestOptions.headers = headers;

    if (requestOptions.body instanceof FormData) {
      if (requestOptions.body.has("_glpi_csrf_token") && csrfToken) {
        requestOptions.body.set("_glpi_csrf_token", csrfToken);
      }
    }
    const response = await fetch(url, requestOptions);
    const responseText = await response.text();
    let data = {};
    if (responseText !== "") {
      try {
        data = JSON.parse(responseText);
      } catch (error) {
        throw new Error(`Unexpected response format (${response.status}).`);
      }
    }
    if (!response.ok) {
      // GLPI's ErrorController returns {error: true, message: "...", title: "..."}
      // for 403/400/500 responses to JSON requests. Prefer the human-readable
      // 'message' field over 'error', which may be a boolean rather than a string.
      const errorMsg =
        (typeof data.message === "string" && data.message !== "")
          ? data.message
          : (typeof data.error === "string" && data.error !== "")
            ? data.error
            : "Request failed.";
      throw new Error(errorMsg);
    }
    if (data._glpi_csrf_token) {
      csrfToken = data._glpi_csrf_token;
    }
    return data;
  } catch (error) {
    if (timeoutEnabled && controller.signal.aborted && !callerSignal?.aborted) {
      throw new Error("Request timed out.");
    }
    throw error;
  } finally {
    if (timeoutId !== null) {
      window.clearTimeout(timeoutId);
    }
    if (callerSignal) {
      callerSignal.removeEventListener("abort", abortFromCaller);
    }
  }
  }, queuePriority, deadlineAt);
};

/**
 * Perform a bounded POST request with FormData
 * @param {string} url 
 * @param {FormData} formData 
 * @param {Object} [requestOptions] 
 * @returns {Promise<Object>}
 */
export const postForm = async (url, formData, requestOptions = {}) => fetchJson(url, {
  method: "POST",
  body: formData,
  credentials: "same-origin",
  ...requestOptions,
});
