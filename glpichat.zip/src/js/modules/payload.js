/**
 * Build scalar-only text and file-only upload payloads. Keeping the payloads
 * separate prevents an attachment binary from being transferred twice.
 */
export const buildTextPayload = (content, fields = {}) => {
  const data = new FormData();
  data.set("content", String(content));
  for (const [key, value] of Object.entries(fields)) {
    data.set(key, String(value));
  }
  return data;
};

export const buildUploadPayload = (file, fields = {}) => {
  if (!(file instanceof File) || file.size <= 0) {
    throw new TypeError("A non-empty File is required.");
  }
  const data = new FormData();
  data.set("file", file, file.name);
  for (const [key, value] of Object.entries(fields)) {
    data.set(key, String(value));
  }
  return data;
};
