/**
 * Remove a channel after the server reports that it is no longer available.
 *
 * This function intentionally contains no DOM work so the destructive state
 * transition can be regression-tested independently from the widget shell.
 * Keeping a stale channel would leave already-rendered messages visible after
 * a ticket/profile authorization change.
 *
 * @param {Object} state Widget state container
 * @param {string} key Canonical "ticket:room_type" channel key
 * @param {Object} payload Poll tombstone returned by the server
 * @returns {{changed: boolean, ticketId: number, ticketRemoved: boolean}}
 */
export const purgeUnavailableChannelState = (state, key, payload = {}) => {
  const channel = state?.channels instanceof Map ? state.channels.get(key) : null;
  if (!channel) {
    return { changed: false, ticketId: 0, ticketRemoved: false };
  }

  const ticketId = Number(channel.tickets_id || payload.tickets_id || 0);
  const roomType = String(channel.room_type || payload.room_type || "");

  // Clear the mutable collections before dropping the map entry. This also
  // removes content from any short-lived references held by render callbacks.
  if (Array.isArray(channel.messages)) {
    channel.messages.length = 0;
  }
  if (Array.isArray(channel.events)) {
    channel.events.length = 0;
  }
  if (channel.renderedMessageIds instanceof Set) {
    channel.renderedMessageIds.clear();
  }
  channel.messages_loaded = false;
  state.channels.delete(key);

  const ticket = state.tickets instanceof Map ? state.tickets.get(ticketId) : null;
  if (!ticket) {
    return { changed: true, ticketId, ticketRemoved: true };
  }

  if (ticket.channels && typeof ticket.channels === "object") {
    for (const [candidateType, candidateKey] of Object.entries(ticket.channels)) {
      if (candidateKey === key || !state.channels.has(candidateKey)) {
        delete ticket.channels[candidateType];
      }
    }
    if (roomType !== "" && ticket.channels[roomType] === key) {
      delete ticket.channels[roomType];
    }
  }

  const remainingRoomTypes = Object.entries(ticket.channels || {})
    .filter(([, candidateKey]) => state.channels.has(candidateKey))
    .map(([candidateType]) => candidateType);

  if (remainingRoomTypes.length === 0) {
    state.tickets.delete(ticketId);
    state.openTicketIds = (state.openTicketIds || []).filter((id) => Number(id) !== ticketId);
    state.manualTicketIds?.delete(ticketId);
    state.transientTicketIds?.delete(ticketId);
    state.closedTicketIds?.delete(ticketId);
    state.closedTicketTimestamps?.delete(ticketId);
    if (Number(state.activeTicketId || 0) === ticketId) {
      state.activeTicketId = 0;
    }
    if (state.minimizedSnapshot && Array.isArray(state.minimizedSnapshot.openTicketIds)) {
      state.minimizedSnapshot.openTicketIds = state.minimizedSnapshot.openTicketIds
        .filter((id) => Number(id) !== ticketId);
    }
    return { changed: true, ticketId, ticketRemoved: true };
  }

  if (!remainingRoomTypes.includes(ticket.activeTab)) {
    ticket.activeTab = remainingRoomTypes[0];
  }
  ticket.unreadTotal = remainingRoomTypes.reduce((total, candidateType) => {
    const candidateKey = ticket.channels[candidateType];
    return total + Number(state.channels.get(candidateKey)?.unread_count || 0);
  }, 0);

  return { changed: true, ticketId, ticketRemoved: false };
};
