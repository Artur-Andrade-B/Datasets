/**
 * DOM Module
 * Extracted from glpichat.js for DOM manipulation utilities
 */

import { SAFE_BOTTOM_MARGIN_PX } from './constants.js';

/**
 * Check if an element is visible based on CSS properties
 * @param {HTMLElement} element - Element to check
 * @returns {boolean} True if element is visible
 */
export const isVisibleElement = (element) => {
  if (!element) {
    return false;
  }
  let current = element;
  while (current && current !== document.documentElement) {
    const style = window.getComputedStyle(current);
    if (style.display === "none" || style.visibility === "hidden") {
      return false;
    }
    if (Number(style.opacity || "1") === 0) {
      return false;
    }
    current = current.parentElement;
  }
  return true;
};

const collectObstructionElements = () => Array.from(
  document.body?.querySelectorAll("header, footer, nav, .navbar, .fixed-top, .fixed-bottom, .sticky-top") || []
);

const measureObstructions = (obstructionElements) => {
  const viewportHeight = window.innerHeight || 0;
  const viewportWidth = window.innerWidth || 0;
  let bottom = 0;
  let top = 0;

  for (const element of obstructionElements) {
    if (!(element instanceof HTMLElement) || !element.isConnected) {
      continue;
    }
    if (element.classList.contains("glpichat-widget") || element.closest(".glpichat-widget")) {
      continue;
    }
    const style = window.getComputedStyle(element);
    if (style.position !== "fixed" && style.position !== "sticky") {
      continue;
    }
    if (!isVisibleElement(element)) {
      continue;
    }
    const rect = element.getBoundingClientRect();
    if (rect.height <= 0 || rect.width <= 0) {
      continue;
    }
    if (rect.height > rect.width) {
      continue;
    }
    if (rect.width < Math.min(220, viewportWidth * 0.2)) {
      continue;
    }

    if (rect.bottom >= viewportHeight - 2 && rect.left <= viewportWidth * 0.8) {
      bottom = Math.max(bottom, Math.max(0, viewportHeight - rect.top));
    }
    if (rect.top <= 2) {
      top = Math.max(top, Math.max(0, rect.bottom));
    }
  }

  return { bottom, top };
};

/**
 * Detect obstruction at bottom of viewport
 * @returns {number} Height of obstruction in pixels
 */
export const detectBottomObstruction = () => measureObstructions(collectObstructionElements()).bottom;

/**
 * Detect obstruction at top of viewport
 * @returns {number} Height of obstruction in pixels
 */
export const detectTopObstruction = () => measureObstructions(collectObstructionElements()).top;

/**
 * Update CSS variables for safe widget positioning
 * @returns {void}
 */
export const updateSafeBottom = () => {
  const measured = measureObstructions(collectObstructionElements());
  const safeBottom = `${Math.max(0, measured.bottom) + SAFE_BOTTOM_MARGIN_PX}px`;
  const safeTop = `${Math.max(0, measured.top) + SAFE_BOTTOM_MARGIN_PX}px`;
  const style = document.documentElement.style;
  if (style.getPropertyValue("--glpichat-safe-bottom") !== safeBottom) {
    style.setProperty("--glpichat-safe-bottom", safeBottom);
  }
  if (style.getPropertyValue("--glpichat-safe-top") !== safeTop) {
    style.setProperty("--glpichat-safe-top", safeTop);
  }
};

/**
 * Submit a form programmatically
 * @param {HTMLFormElement} form - Form element to submit
 */
export const submitForm = (form) => {
  if (typeof form.requestSubmit === "function") {
    form.requestSubmit();
  } else {
    form.dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }));
  }
};

/**
 * Generate channel key from ticket ID and room type
 * @param {number} ticketsId - Ticket ID
 * @param {string} roomType - Room type ("public" or "internal")
 * @returns {string} Channel key in format "ticketsId:roomType"
 */
export const channelKey = (ticketsId, roomType) => `${ticketsId}:${roomType}`;

/**
 * Check if widget position is on the left side
 * @param {string} widgetPosition - Current widget position
 * @returns {boolean} True if position is left-based
 */
export const isLeftPosition = (widgetPosition) => 
  widgetPosition === "bottom-left" || widgetPosition === "top-left";
