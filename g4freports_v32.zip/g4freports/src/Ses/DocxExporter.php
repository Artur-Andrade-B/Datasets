<?php

namespace GlpiPlugin\G4freports\Ses;

/** SES managerial report built from the same frozen dataset as the workbook. */
final class DocxExporter
{
    private const VIOLATION_FILL = 'FCE8E6';
    private const VIOLATION_TEXT = '9C1C1C';

    private WordChart $charts;

    public function filename(array $snapshot): string
    {
        return 'Relatorio_Mensal_SES_' . preg_replace('/[^0-9-]/', '', $snapshot['period']['month'] ?? '') . '.docx';
    }

    public function toBinary(array $snapshot): string
    {
        $path = dirname(__DIR__, 2) . '/resources/docx/papel_timbrado_G4F.docx';
        $binary = @file_get_contents($path);
        if (!is_string($binary)) {
            throw new \RuntimeException('O papel timbrado G4F não foi encontrado no pacote do plugin.');
        }
        $files = OfficePackage::read($binary);
        if (!isset($files['word/document.xml'], $files['word/_rels/document.xml.rels'])) {
            throw new \RuntimeException('O modelo G4F não contém os componentes necessários.');
        }
        $this->charts = new WordChart();
        $files['word/document.xml'] = $this->document($snapshot);
        $this->charts->attach($files);
        $files['word/styles.xml'] = $this->styles();
        $files['docProps/core.xml'] = '<?xml version="1.0" encoding="UTF-8"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>Relatório mensal SES</dc:title><dc:creator>G4F</dc:creator><dc:description>' . OfficePackage::xml(($snapshot['period']['month'] ?? '') . ' | ' . ($snapshot['rules_version'] ?? '')) . '</dc:description></cp:coreProperties>';
        return OfficePackage::write($files);
    }

    private function document(array $s): string
    {
        $period = $s['period'];
        $totals = $s['totals'];
        $input = $s['input'] ?? [];
        $manual = $s['manual'] ?? [];
        $figures = ChartData::build($s);
        $heatmaps = HeatmapData::build($s);
        $title = trim((string)($input['report_title'] ?? '')) ?: 'Relatório técnico de execução mensal';
        $body = $this->p('G4F  |  Secretaria de Estado de Saúde do Distrito Federal', '', false, 20, 'center');
        $body .= '<w:p><w:pPr><w:spacing w:before="3000" w:after="320"/></w:pPr></w:p>';
        $body .= $this->p($title, 'Title', true, 40, 'center');
        $body .= $this->p('Contrato SES/DF 053592/2025', '', true, 25, 'center');
        $body .= $this->p((string)($period['label'] ?? $period['month']), '', false, 26, 'center');
        $body .= $this->p('Chamados por data de solução e telefonia por entrada na fila', '', false, 21, 'center');
        $body .= $this->p('Extração: ' . OfficePackage::date($s['generated_at'] ?? ''), '', false, 18, 'center');
        $body .= $this->page();
        $body .= $this->heading('1 Apresentação e objetivo');
        $body .= $this->p('Este relatório apresenta a execução mensal dos serviços de atendimento de TIC e os indicadores operacionais do Contrato SES/DF 053592/2025. As medições utilizam os registros do GLPI, os eventos de telefonia do Asterisk e as informações gerenciais complementadas para o período.');
        $body .= $this->p('Os chamados são selecionados pela data de solução, entre ' . OfficePackage::date($period['start']) . ' e ' . OfficePackage::date($period['end_exclusive']) . ' (limite final exclusivo). Chamados abertos antes do mês integram a apuração quando solucionados no período. As ligações são selecionadas pela entrada na fila.');
        $body .= $this->heading('2 Resumo de chamados');
        $body .= $this->table(['Descrição', 'Quantidade'], [
            ['Total de chamados solucionados', OfficePackage::number($totals['tickets'] ?? 0)],
            ['Requisições', OfficePackage::number($totals['requests'] ?? 0)],
            ['Incidentes', OfficePackage::number($totals['incidents'] ?? 0)],
            ['Chamados com prazo não preenchido no GLPI', OfficePackage::number($totals['missing_deadline'] ?? 0)],
        ], [7100, 2400]);
        $body .= $this->p('O prazo de solução não preenchido no GLPI não exclui o chamado. A conformidade compara o tempo de solução apurado com o limite do SLA aplicável. O tempo positivo de solução registrado pelo GLPI tem precedência; quando não existe, utiliza-se o intervalo entre abertura e solução, descontada a espera geral quando o saldo é positivo. Nos demais casos utiliza-se o intervalo integral. Chamados clonados mantêm a data de abertura registrada no próprio chamado. A planilha apresenta o tempo, o limite e o método aplicados a cada registro.');
        $body .= $this->figure($figures['tickets_types'], 3000);
        $body .= $this->page();
        $body .= $this->heading('3 Resumo de telefonia');
        $body .= $this->table(['Descrição', 'Apuração'], [
            ['Ligações recebidas após exclusões de teste', OfficePackage::number($totals['calls_received'] ?? 0)],
            ['Ligações atendidas', OfficePackage::number($totals['calls_answered'] ?? 0)],
            ['Ligações abandonadas no total', OfficePackage::number($totals['calls_abandoned'] ?? 0)],
            ['Abandonos após mais de 30 segundos (INS9)', OfficePackage::number($totals['calls_abandoned_over_30'] ?? null)],
            ['Ligações de teste excluídas', OfficePackage::number($totals['calls_excluded'] ?? 0)],
            ['Duração média das conversas atendidas', OfficePackage::duration($totals['mean_talk_seconds'] ?? null)],
            ['Espera média antes da conexão ao agente', OfficePackage::duration($totals['mean_wait_seconds'] ?? null)],
        ], [7100, 2400]);
        $body .= $this->p('Os tempos individuais representam durações reais: TMA corresponde à conversa e TME à espera na fila antes da conexão. As médias acima são calculadas sobre as ligações com tempos válidos. INS7 e INS8 representam a proporção de ligações atendidas dentro dos limites definidos sobre o total de ligações recebidas após exclusões de teste.');
        $body .= $this->p('O total de abandonos inclui esperas de até 30 segundos; o INS9 considera somente os abandonos após mais de 30 segundos. Por isso, pode haver ligações abandonadas e resultado de 0,00% no INS9.');
        $body .= $this->figure($figures['calls_daily'], 3200);
        if (trim((string)($manual['executive_summary'] ?? '')) !== '') {
            $body .= $this->heading('Análise executiva');
            $body .= $this->text($manual['executive_summary']);
        }
        $body .= $this->page();
        $body .= $this->heading('4 Indicadores do contrato');
        $body .= $this->p('Os resultados abaixo seguem as definições operacionais e as opções de cálculo registradas nesta extração. A situação compara o resultado apurado com a meta. O método selecionado e as observações de auditoria são informados separadamente; eventuais informações necessárias ausentes são identificadas no indicador correspondente.');
        $body .= $this->metricsSummary($s);
        $body .= $this->p('As identificações INS1 a INS4 e sua associação à prioridade do GLPI são declaradas nas medições a seguir. Severidade contratual e código de prioridade GLPI são escalas diferentes: severidades 1, 2, 3 e 4 correspondem, respectivamente, às prioridades Muito alta (5), Alta (4), Média (3) e Baixa (2). O tempo de solução é comparado com o limite correspondente ao SLA aplicável. Os prazos registrados e o histórico permanecem como evidências de auditoria; um prazo vazio, isoladamente, não impede a medição.');
        $body .= $this->page();
        $body .= $this->heading('Resultados e metas dos indicadores');
        $body .= $this->p('As barras comparam resultados percentuais e metas, separados pelo sentido da regra. Quando faltam dados necessários, a limitação é indicada na medição. Indicadores pendentes ou não aplicáveis aparecem na tabela anterior e não são representados como resultado zero.');
        $body .= $this->figure($this->overview($s['metrics'], 'gte'), 4600);
        $body .= $this->figure($this->overview($s['metrics'], 'lte'), 2400);
        $body .= $this->page();
        $body .= $this->heading('5 Medição dos indicadores');
        foreach ($s['metrics'] as $index => $m) {
            $figure = $figures[$m['id']];
            // SLA audit notes can be substantial even for an unavailable
            // metric. Start each indicator cleanly instead of placing the next
            // heading below an N/A block and separating it from its chart.
            if ($index > 0) {
                $body .= $this->page();
            }
            $body .= $this->heading($m['id'] . ' ' . MetricEvidence::title($m['id'], $s['input']['priority_map'][$m['id']] ?? null), 2);
            $labels = MetricEvidence::labels($m['id']);
            $body .= $this->table(['Medição', 'Valor'], [
                [$labels['numerator'], OfficePackage::number($m['numerator'])],
                [$labels['denominator'], OfficePackage::number($m['denominator'])],
                ['Resultado', $m['value'] === null ? ($m['status'] === 'not_applicable' ? 'N/A' : 'Pendente') : OfficePackage::percent($m['value'])],
                ['Meta', ($m['direction'] === 'lte' ? '≤ ' : '≥ ') . OfficePackage::percent($m['target'])],
                ['Situação', OfficePackage::status($m)],
            ], [7100, 2400], 18);
            if ($m['id'] === 'INS12') {
                $body .= $this->ins12Sources($m, $input);
            }
            $body .= $this->p('Critério de cálculo: ' . $m['method']);
            if (!empty($m['note'])) {
                $body .= $this->p('Observação: ' . $m['note']);
            }
            if (in_array($m['id'], ['INS1', 'INS2', 'INS3', 'INS4'], true)) {
                $body .= $this->p('Chamados avaliados: ' . OfficePackage::number($m['denominator'])
                    . (!empty($m['unresolved_count']) ? '; chamados do recorte ainda não apurados por falta de evidência: ' . OfficePackage::number($m['unresolved_count']) : '')
                    . '. A tabela detalhada da planilha registra os prazos, o limite, o calendário, os tempos utilizados, o método e as observações de auditoria.', '', false, 19);
            }
            // INS4's method and note already state its scope and excluded count.
            if (array_key_exists('excluded_count', $m) && $m['id'] !== 'INS4') {
                $body .= $this->p('Exclusões N3 deste indicador: ' . OfficePackage::number($m['excluded_count']) . '. Detalhamento na aba Auditoria de exclusões da planilha.', '', true, 19);
            }
            if ($m['id'] === 'INS12') {
                $body .= $this->page();
                $body .= $this->surveyDistributions($s);
                $body .= $this->page();
                $body .= $this->heading('INS12 — Respostas válidas por fonte', 2);
            }
            // The calculation and audit notes immediately above already explain
            // the metric. Repeating the chart's long note creates orphan pages.
            $body .= $this->figure($figure, 3500, false);
            if ($m['id'] === 'INS12' && isset($s['phone_survey'])) {
                $body .= $this->heading('Pesquisa telefônica — conferência da participação', 2);
                $body .= $this->phoneSurvey($s['phone_survey'], (string)($input['phone_survey_actions'] ?? ''));
            }
        }
        $body .= $this->page();
        $body .= $this->heading('6 Distribuição temporal da operação');
        $body .= $this->p('A evolução diária mostra o volume de chamados solucionados. Os mapas de calor totalizam o volume do mês por hora e dia da semana, com os horários locais registrados na origem. Não representam médias por dia da semana nem o cumprimento dos níveis de serviço.');
        $body .= $this->figure($figures['tickets_daily'], 4400);
        foreach ($heatmaps as $heatmap) {
            $body .= $this->page();
            $body .= $this->heading($heatmap['title'], 2);
            $body .= $this->heatmap($heatmap);
        }
        $body .= $this->page();
        $body .= $this->heading('7 Ajustes e regularizações do faturamento');
        $body .= $this->p('Os percentuais operacionais deste relatório constituem a evidência da medição. Ajustes financeiros, justificativas e valores de faturamento dependem da base financeira e da validação contratual correspondente; não são calculados automaticamente a partir dos indicadores.');
        $body .= $this->heading('8 Propostas de melhoria e ações corretivas');
        $body .= $this->text(trim((string)($manual['actions'] ?? '')) ?: 'Não foram registradas ações gerenciais complementares nesta extração.');
        $body .= $this->page();
        $body .= $this->heading('9 Equipe e rotatividade de profissionais');
        $body .= $this->staffRegister($s['staff_register'] ?? []);
        $body .= $this->heading('10 Observações e encerramento');
        $body .= $this->text(trim((string)($manual['notes'] ?? '')) ?: 'Não foram registradas observações complementares.');
        $body .= $this->page();
        $body .= $this->heading('11 Metodologia e evidências');
        $body .= $this->table(['Parâmetro', 'Valor'], [
            ['Competência', $period['label'] ?? $period['month']],
            ['Extração', OfficePackage::date($s['generated_at'] ?? '')],
            ['Versão das regras', $s['rules_version'] ?? ''],
            ['Base temporal dos chamados', 'Data de solução'],
            ['Base temporal das ligações', 'Entrada na fila'],
            ['Entidade GLPI', (string)($input['entity_id'] ?? '')],
            ['Grupos técnicos selecionados', OfficePackage::selectionLabels($s, 'groups', $input['group_ids'] ?? [], 'Todos os grupos do escopo da entidade')],
            ['Grupos N1 para INS6', OfficePackage::selectionLabels($s, 'groups', $input['n1_group_ids'] ?? [], 'Não informado')],
            ['Grupos N1 e N2 para INS4', OfficePackage::selectionLabels($s, 'groups', array_values(array_unique(array_merge($input['n1_group_ids'] ?? [], $input['n2_group_ids'] ?? []))), 'Não informado')],
            ['Grupos N3 excluídos de INS3, INS4 e INS6', OfficePackage::selectionLabels($s, 'groups', $input['n3_group_ids'] ?? [], 'Nenhum informado')],
            ['Categorias elegíveis N1 (IDs)', implode(', ', $input['n1_categories'] ?? [])],
            ['Critério INS11', OfficePackage::kbCriterion($s)],
            ['Fontes do INS12', $this->ins12ModeLabel($input)],
            ['Artigos validados informados (IDs)', !empty($input['validated_kb_ids']) ? implode(', ', $input['validated_kb_ids']) : 'Nenhum informado'],
            ['Filtro de fila', (string)($input['queue_filter'] ?? '')],
            ['Referência de horário', (string)($input['timezone'] ?? 'America/Sao_Paulo')],
            ['Chamadas de teste excluídas', OfficePackage::number($totals['calls_excluded'] ?? 0)],
        ], [3600, 5900]);
        $body .= $this->heading('Calendários usados na apuração', 2);
        $body .= $this->table(['Referência', 'Configuração preservada'], MetricEvidence::calendarReferenceRows($s), [2600, 6900], 18);
        $body .= $this->p('Os segmentos efetivos acima prevalecem sobre o texto do nome do calendário. A quantidade de feriados/exceções refere-se ao catálogo vinculado, não somente à competência. Alterações posteriores nos calendários do GLPI não modificam esta extração.', '', false, 18);
        $exclusions = [];
        foreach ($s['metric_exclusions'] ?? [] as $id => $exclusion) {
            $exclusions[] = [$id, OfficePackage::number($exclusion['count'] ?? 0), 'Vínculo técnico atual a um dos grupos N3 selecionados'];
        }
        if ($exclusions) {
            $totalExclusions = array_sum(array_map(static function (array $row): int { return (int)($row['count'] ?? 0); }, $s['metric_exclusions'] ?? []));
            $exclusions[] = ['Total geral', OfficePackage::number($totalExclusions), 'Exclusões por indicador; um chamado pode participar de mais de um indicador'];
            $body .= $this->table(['Indicador', 'Excluídos por N3', 'Critério'], $exclusions, [1100, 1800, 6600], 18);
            $body .= $this->p('A exclusão N3 é específica de INS3, INS4 e INS6 e considera os grupos atualmente atribuídos. Um chamado com N1 e N3 é excluído desses indicadores. Os registros permanecem na base geral e nos demais indicadores quando atendem aos respectivos critérios; a atribuição atual não comprova o histórico de atendimento.');
        }
        $body .= $this->heading('Reaberturas administrativas e atendimento N1 sem grupo', 2);
        $ins5Audit = MetricEvidence::ins5AuditTable($s);
        $ins6Audit = MetricEvidence::ins6AuditTable($s);
        $body .= $this->table(['Regra de apuração', 'Quantidade de registros'], [
            ['INS5 — eventos de reabertura pelo mesmo solucionador N1/N2/N3 desconsiderados', OfficePackage::number(count($ins5Audit['rows']))],
            ['INS6 — chamados elegíveis sem grupo incluídos pelo solucionador N1', OfficePackage::number(count($ins6Audit['rows']))],
        ], [7300, 2200], 18);
        $body .= $this->p('No INS5, a exceção alcança o evento administrativo: outra reabertura válida ou execução incompleta informada pode manter o chamado no indicador. No INS6, a identificação do solucionador N1 complementa o critério apenas para chamado de categoria elegível sem grupo atribuído. A autoria registrada da solução é distinta da associação do profissional aos grupos, verificada na extração. As seções próprias da auditoria na planilha identificam chamados, atores, datas e a regra aplicada.', '', false, 18);
        foreach ($s['rule_notes'] ?? [] as $note) {
            $body .= $this->p($note);
        }
        if (!empty($s['warnings'])) {
            $body .= $this->heading('Limitações da apuração', 2);
            foreach ($s['warnings'] as $warning) {
                $body .= $this->p($warning);
            }
        }
        $body .= $this->p('A planilha reúne o painel, os registros do recorte de cada INS, as bases completas e a distribuição temporal. Nos indicadores telefônicos, a visualização inicial destaca a condição medida; a base completa permanece acessível e determina o total oficial do cálculo. A auditoria preserva as exclusões N3, as reaberturas administrativas, os chamados incluídos pelo solucionador N1, os números de teste, as ligações excluídas e o cadastro completo de profissionais com sua marcação de faturamento. Foram excluídas ' . OfficePackage::number($totals['calls_excluded'] ?? 0) . ' ligações de teste das contagens, percentuais e médias de telefonia.');
        if (!empty($s['selection_catalog'])) {
            $body .= $this->heading('Categorias e artigos selecionados', 2);
            $body .= $this->p('IDs e nomes consultados na base GLPI do relatório e preservados na extração. A lista de categorias define a elegibilidade N1 do INS6. Chamados atribuídos a N3 ficam fora dessa apuração. Entre os demais elegíveis, contam como solucionados no N1 aqueles com grupo N1 atribuído ou, na ausência de qualquer grupo, com solução registrada por profissional identificado no N1. Os vínculos de grupo refletem a extração; não comprovam, isoladamente, a composição histórica da equipe.');
            $categories = OfficePackage::selectionRows($s, 'categories', $input['n1_categories'] ?? []);
            $categories[] = ['Total geral (registros)', OfficePackage::number(count($categories))];
            $body .= $this->table(['ID da categoria de chamado', 'Categoria elegível N1'], $categories, [1700, 7800]);
            if (!empty($input['validated_kb_ids'])) {
                $body .= $this->heading('Artigos previamente validados informados', 2);
                $body .= $this->p('Estes são IDs de artigos. A seleção representa a lista de validação informada para o relatório; a existência do artigo no catálogo não comprova sua aprovação nem seu vínculo a um chamado.');
                if (($input['kb_mode'] ?? '') === 'category_proxy') {
                    $body .= $this->p('A lista de artigos não participa da apuração nesta extração, que usa o critério de associação por categoria.');
                }
                $articles = OfficePackage::selectionRows($s, 'articles', $input['validated_kb_ids']);
                $articles[] = ['Total geral (registros)', OfficePackage::number(count($articles))];
                $body .= $this->table(['ID do artigo', 'Título do artigo'], $articles, [1700, 7800]);
            }
        }
        $body .= $this->heading('12 Aprovação');
        $body .= $this->p('Responsável pela elaboração: ____________________________________');
        $body .= $this->p('Responsável pela validação: _____________________________________');
        $body .= $this->p('Data: ____/____/________');
        $section = '<w:sectPr><w:headerReference w:type="even" r:id="rId11"/><w:headerReference w:type="default" r:id="rId12"/><w:footerReference w:type="default" r:id="rId13"/><w:headerReference w:type="first" r:id="rId14"/><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1560" w:right="1134" w:bottom="1560" w:left="1134" w:header="709" w:footer="709"/><w:cols w:space="708"/></w:sectPr>';
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart"><w:body>' . $body . $section . '</w:body></w:document>';
    }

    private function staffRegister(array $staff): string
    {
        $xml = $this->p('A equipe abaixo corresponde ao cadastro de profissionais salvo no plugin e preservado nesta extração. Esses dados são informados pela gestão do contrato; não são extraídos dos chamados do GLPI. Profissionais sem a marcação Não Faturar compõem os totais e as movimentações do INS10 conforme as datas do vínculo. Alterações posteriores no cadastro não modificam este relatório.');
        if (empty($staff['configured'])) {
            return $xml . $this->p('Não há profissionais cadastrados nesta extração. O INS10 permanece pendente até o preenchimento do cadastro.', '', true, 20);
        }
        $xml .= $this->p('Janela de movimentações do INS10: ' . OfficePackage::date($staff['window_start'] ?? '') . ' a ' . OfficePackage::date($staff['window_end'] ?? '') . '. Referência para o quadro ativo: ' . OfficePackage::date($staff['month_end'] ?? '') . '.');
        $xml .= $this->table(['Informação de pessoal', 'Apuração'], [
            ['Profissionais ativos no último dia do mês', OfficePackage::number($staff['active_total'] ?? null)],
            ['Saídas consideradas no INS10 na janela de três meses', OfficePackage::number($staff['departures_total'] ?? null)],
            ['Motivo informado: redução determinada pela contratante', OfficePackage::number($staff['reductions'] ?? null)],
            ['Motivo informado: outra saída', OfficePackage::number($staff['other_departures'] ?? null)],
            ['Motivo não informado (saídas já incluídas no total)', OfficePackage::number($staff['unclassified_departures'] ?? null)],
            ['Profissionais não faturados no cadastro, fora do INS10', OfficePackage::number($staff['unbilled_total'] ?? 0)],
            ['Valor mensal dos profissionais faturados ativos no fim do mês', $this->staffAmount($staff['monthly_value_total'] ?? 0)],
            ['Total de dias faturados na competência (soma por profissional)', OfficePackage::number($staff['billed_days_total'] ?? 0)],
            ['Valor faturado na competência (proporcional aos dias)', $this->staffAmount($staff['billed_value_total'] ?? 0)],
        ], [7300, 2200], 19);
        $xml .= $this->p('Critério de cálculo: ' . ($staff['method'] ?? 'Saídas elegíveis na janela de três meses ÷ profissionais ativos no fim do mês × 100.'));
        if (!empty($staff['note'])) {
            $xml .= $this->p((string)$staff['note']);
        }
        $relevant = $excluded = $departures = [];
        foreach ($staff['rows'] ?? [] as $row) {
            if (StaffRegister::isNotBilled($row)) {
                $excluded[] = $row;
                continue;
            }
            if (!empty($row['relevant_month']) || !empty($row['departure_in_window'])) {
                $relevant[] = $row;
            }
            if (!empty($row['departure_in_window'])) {
                $departures[] = [
                    (string)($row['name'] ?? ''),
                    OfficePackage::date($row['departure_date'] ?? ''),
                    StaffRegister::departureReasonLabel($row['departure_reason'] ?? null),
                    !empty($row['counted_departure'] ?? $row['counted_replacement'] ?? false) ? 'Sim' : 'Não',
                ];
            }
        }
        $xml .= $this->heading('Profissionais da competência e saídas recentes', 2);
        $xml .= $this->p('Os dois quadros a seguir apresentam os mesmos profissionais: aqueles com vínculo em algum dia da competência e aqueles com saída na janela de três meses do INS10. Vínculos futuros e saídas anteriores a essa janela permanecem salvos no cadastro, mas não integram esta relação. Profissionais desconsiderados são apresentados separadamente ao final.', '', false, 18);
        $xml .= $this->staffIdentityTable($relevant);
        $xml .= $this->heading('Faturamento dos profissionais da competência e saídas recentes', 2);
        $xml .= $this->p('Primeiro dia Faturado e Último dia Faturado delimitam a interseção entre o vínculo e a competência, incluindo ambas as datas. Dias Faturado é a quantidade de dias desse intervalo. Valor Faturado = Valor mensal ÷ dias corridos da competência × Dias Faturado, com arredondamento em centavos por profissional. Saídas anteriores à competência têm zero dias e zero valor faturado, mesmo quando participam do INS10.', '', false, 18);
        $xml .= $this->staffBillingTable($relevant);
        $xml .= $this->p('Status é descritivo: Ativo indica ausência de data de saída; Inativo indica que existe uma data de saída no cadastro, inclusive futura em relação à competência. Esse status não impede o faturamento de meses anteriores nem altera o INS10. O indicador continua utilizando a equipe ativa no fechamento e as saídas na janela de três meses; os dias e valores proporcionais não modificam suas contagens.', '', false, 18);
        if ($departures) {
            $xml .= $this->heading('Saídas na janela de três meses', 2);
            $xml .= $this->p('Esta relação inclui somente profissionais sem a marcação Não Faturar com saída no mês ou nos dois meses anteriores. Todas essas saídas entram no INS10. O motivo é opcional e serve apenas à análise; informá-lo ou alterá-lo não muda a contagem.');
            $departures[] = ['Total geral (registros)', OfficePackage::number(count($departures)), '', ''];
            $xml .= $this->table(['Nome', 'Data de saída', 'Motivo (opcional)', 'Saída considerada no INS10'], $departures, [3550, 1200, 2950, 1800], 18);
        }
        $xml .= $this->heading('Profissionais desconsiderados (Não Faturado)', 2);
        $xml .= $this->p('Esta relação mantém todos os profissionais com Não Faturar marcado no cadastro, inclusive vínculos fora da competência. Sim em Profissional desconsiderado? (Não Faturado) exclui o profissional da equipe, das saídas, dos dias faturados e dos valores faturados. O Valor mensal cadastrado permanece visível para conferência.', '', false, 18);
        if ($excluded) {
            $xml .= $this->staffIdentityTable($excluded);
            $xml .= $this->heading('Valores dos profissionais desconsiderados', 2);
            $xml .= $this->staffBillingTable($excluded);
        } else {
            $xml .= $this->p('Não há profissionais desconsiderados no cadastro desta extração.');
        }
        return $xml;
    }

    /** Paired portrait tables preserve the G4F letterhead and readable columns. */
    private function staffIdentityTable(array $staffRows): string
    {
        if (!$staffRows) {
            return $this->p('Não há profissionais neste recorte.');
        }
        $rows = [];
        foreach ($staffRows as $row) {
            $rows[] = [
                (string)($row['name'] ?? ''),
                (string)($row['profile'] ?? ''),
                OfficePackage::date($row['admission_date'] ?? ''),
                empty($row['departure_date']) ? '—' : OfficePackage::date($row['departure_date']),
                empty($row['departure_date']) ? 'Ativo' : 'Inativo',
                StaffRegister::isNotBilled($row) ? 'Sim' : 'Não',
            ];
        }
        $rows[] = ['Total geral (registros)', OfficePackage::number(count($staffRows)), '', '', '', ''];
        return $this->table(['Nome', 'Perfil Profissional', 'Data de admissão', 'Data de saída', 'Status', 'Profissional desconsiderado? (Não Faturado)'], $rows, [2100, 2200, 1200, 1200, 950, 1850], 18);
    }

    private function staffBillingTable(array $staffRows): string
    {
        if (!$staffRows) {
            return $this->p('Não há faturamento neste recorte.');
        }
        $rows = [];
        $days = $monthlyCents = $billedCents = 0;
        foreach ($staffRows as $row) {
            $rows[] = [
                (string)($row['name'] ?? ''),
                empty($row['billing_first_day']) ? '—' : OfficePackage::date($row['billing_first_day']),
                empty($row['billing_last_day']) ? '—' : OfficePackage::date($row['billing_last_day']),
                OfficePackage::number($row['billed_days'] ?? 0),
                $this->staffAmount($row['monthly_value'] ?? null),
                $this->staffAmount($row['billed_value'] ?? 0),
            ];
            $days += (int)($row['billed_days'] ?? 0);
            $monthlyCents += (int)round((float)($row['monthly_value'] ?? 0) * 100);
            $billedCents += (int)round((float)($row['billed_value'] ?? 0) * 100);
        }
        $rows[] = ['Total geral (' . count($staffRows) . ' profissionais)', '', '', OfficePackage::number($days), $this->staffAmount($monthlyCents / 100), $this->staffAmount($billedCents / 100)];
        $xml = $this->table(['Nome', 'Primeiro dia Faturado', 'Último dia Faturado', 'Dias Faturado', 'Valor mensal', 'Valor Faturado'], $rows, [2750, 1250, 1250, 1100, 1550, 1600], 18);
        return $xml . $this->p('O total de Valor mensal soma os valores cadastrados das pessoas desta tabela, inclusive saídas recentes. O total de Valor Faturado corresponde somente à competência e considera dias proporcionais e exclusões. A soma de dias corresponde a dias por profissional.', '', false, 18);
    }

    private function staffAmount($value): string
    {
        return $value === null || $value === '' ? 'Não informado' : 'R$ ' . number_format((float)$value, 2, ',', '.');
    }

    private function ins12ModeLabel(array $input): string
    {
        return ($input['ins12_mode'] ?? 'glpi_and_phone') === 'glpi_and_phone'
            ? 'GLPI e pesquisa telefônica' : 'Somente GLPI; pesquisa telefônica não incluída';
    }

    private function ins12Sources(array $metric, array $input): string
    {
        $xml = $this->p('Fontes desta apuração: ' . $this->ins12ModeLabel($input), '', true, 19);
        $rows = [];
        foreach (['tickets' => 'Pesquisa GLPI', 'phone' => 'Pesquisa telefônica'] as $key => $label) {
            $counts = $metric['source_counts'][$key] ?? [];
            $available = !empty($counts['available']);
            $included = $key === 'tickets' || !empty($counts['included']);
            $rows[] = [$label, $included ? ($available ? 'Incluída' : 'Incluída / indisponível') : 'Não incluída',
                $available ? OfficePackage::number($counts['numerator'] ?? 0) : 'Não disponível',
                $available ? OfficePackage::number($counts['denominator'] ?? 0) : 'Não disponível'];
        }
        $rows[] = ['Total oficial do INS12', OfficePackage::status($metric),
            $metric['numerator'] === null ? 'Pendente' : OfficePackage::number($metric['numerator']),
            $metric['denominator'] === null ? 'Pendente' : OfficePackage::number($metric['denominator'])];
        $xml .= $this->table(['Fonte', 'Participação', 'Satisfeito / muito satisfeito (4 ou 5)', 'Pesquisas respondidas (1 a 5)'], $rows, [2600, 2500, 2300, 2100], 18);
        return $xml . $this->p('O total soma respostas favoráveis e válidas das fontes incluídas, sem calcular a média entre percentuais. Se uma fonte incluída estiver indisponível, a apuração fica pendente; os dados conhecidos permanecem visíveis para conferência.', '', false, 19);
    }

    private function surveyDistributions(array $snapshot): string
    {
        $xml = $this->heading('INS12 — Pesquisa de satisfação dos chamados GLPI', 2);
        $tickets = ChartData::ticketSurveyDistribution($snapshot);
        $xml .= $this->surveyDistributionTable($tickets, 'Pesquisa de satisfação — GLPI');
        $xml .= $this->p($tickets['available']
            ? 'Conferência de todos os chamados solucionados na competência. Não preenchida identifica pesquisa sem nota; não é nota zero nem resposta desfavorável. Somente respostas válidas de 1 a 5 participam do percentual, sendo favoráveis as notas 4 e 5.'
            : 'A fonte de pesquisas GLPI não estava disponível. O total representa os chamados do recorte, sem determinar o preenchimento de suas pesquisas.', '', false, 18);

        $xml .= $this->heading('INS12 — Pesquisa de satisfação da telefonia', 2);
        $phone = ChartData::phoneSurveyDistribution($snapshot);
        $xml .= $this->surveyDistributionTable($phone, 'Pesquisa de satisfação — Telefonia');
        $included = ($snapshot['input']['ins12_mode'] ?? 'glpi_and_phone') === 'glpi_and_phone';
        $xml .= $this->p(($included ? 'Telefonia incluída nesta apuração. ' : 'Quadro de conferência: telefonia não incluída no percentual selecionado. ')
            . ($phone['available']
                ? 'Cada ligação distinta após exclusões de teste aparece uma vez, com a nota considerada na mesma escala de satisfação do GLPI. Não preenchida e nota inválida não entram no percentual.'
                : 'A fonte telefônica não estava disponível; a ausência de dados não é interpretada como ausência de respostas.')
            . ' Os totais GLPI e telefonia representam universos distintos; não são um total de pessoas.', '', false, 18);
        return $xml;
    }

    private function surveyDistributionTable(array $distribution, string $label): string
    {
        $rows = array_map(static function (array $row): array {
            return [$row[0], OfficePackage::number($row[1])];
        }, $distribution['rows']);
        $rows[] = ['Total geral', OfficePackage::number($distribution['total'])];
        return $this->table([$label, 'Quantidade'], $rows, [7300, 2200], 18);
    }

    private function phoneSurvey(array $survey, string $followup = ''): string
    {
        $available = !empty($survey['available']);
        $value = static function (string $key) use ($survey, $available): string {
            return $available ? OfficePackage::number($survey[$key] ?? 0) : 'Não disponível';
        };
        $xml = $this->p((string)($survey['status'] ?? 'A participação da pesquisa telefônica segue a opção registrada nesta extração.'));
        $xml .= $this->p('Escopo deste diagnóstico: ligações do período após exclusões de teste, deduplicadas pelo ID da ligação. Não representa todas as pesquisas existentes na central telefônica.');
        $xml .= $this->table(['Evidência da pesquisa telefônica', 'Quantidade'], [
            ['Ligações distintas consideradas', OfficePackage::number($survey['unique_calls'] ?? 0)],
            ['Respostas registradas e vinculadas', $value('responses')],
            ['Respostas com nota inteira de 1 a 5', $value('valid_responses')],
            ['Respostas favoráveis (nota considerada 4 ou 5)', $value('favorable_responses')],
            ['Respostas fora da faixa inteira de 1 a 5', $value('invalid_responses')],
            ['Ligações sem resposta vinculada', $value('without_response')],
        ], [7300, 2200], 19);
        $xml .= $this->p(PhoneSurveySummary::scoreRuleText() . ' Notas consideradas 4 e 5 são favoráveis. Respostas ausentes ou fora da escala não participam do percentual. A participação da fonte segue a seleção identificada no resultado do INS12.', '', false, 19);
        if (!empty($survey['resolution']['explanation'])) {
            $xml .= $this->p((string)$survey['resolution']['explanation'], '', false, 19);
        }
        if (trim($followup) !== '') {
            $xml .= $this->heading('Providências e encaminhamentos informados', 2);
            $xml .= $this->text($followup);
        }
        return $xml;
    }

    private function figure(array $definition, int $height, bool $showNote = true): string
    {
        if (empty($definition['available'])) {
            return $this->p('Gráfico não apresentado: ' . ($definition['note'] ?? 'medição pendente ou não aplicável.'), '', false, 20);
        }
        $hasCountTable = ($definition['unit'] ?? '') === 'count' && count($definition['series'] ?? []) === 1
            && count($definition['categories'] ?? []) <= 8 && ($definition['id'] ?? '') !== 'INS10';
        if ($hasCountTable && in_array($definition['kind'] ?? '', ['bar', 'column'], true)) {
            $height = min($height, 2800);
        }
        $xml = $this->charts->paragraph($definition, $height);
        if ($hasCountTable) {
            $xml .= $this->compositionTable($definition);
        }
        return $xml . ($showNote ? $this->p((string)($definition['note'] ?? ''), '', false, 19) : '');
    }


    private function compositionTable(array $definition): string
    {
        $values = $definition['series'][0]['values'];
        $total = array_sum($values);
        $rows = [];
        foreach ($definition['categories'] as $index => $category) {
            $rows[] = [$category, OfficePackage::number($values[$index]), $total > 0 ? OfficePackage::percent($values[$index] * 100 / $total) : 'N/A'];
        }
        $rows[] = ['Total geral', OfficePackage::number($total), $total > 0 ? OfficePackage::percent(100) : 'N/A'];
        $heading = in_array($definition['id'] ?? '', ['INS1', 'INS2', 'INS3', 'INS4'], true) ? 'Conformidade' : 'Composição';
        $xml = $this->table([$heading, 'Quantidade', 'Participação'], $rows, [5900, 1700, 1900], 18);
        // A narrow, colored left border links each exact-count row to its slice without relying on color alone.
        $index = -1;
        return preg_replace_callback('/<w:tr>.*?<\/w:tr>/s', static function (array $match) use (&$index, $definition): string {
            $index++;
            $row = $match[0];
            // Keep the small composition table together, including its total.
            // The final row deliberately ends the keep-with-next chain.
            if ($index <= count($definition['categories'])) {
                $row = str_replace('<w:pPr>', '<w:pPr><w:keepNext/>', $row);
            }
            $color = $definition['point_colors'][$index - 1] ?? '';
            if ($index === 0 || $index > count($definition['categories']) || !preg_match('/^[0-9A-Fa-f]{6}$/', $color)) {
                return $row;
            }
            return preg_replace('/(<w:tcPr><w:tcW\b[^>]*\/>)/', '$1<w:tcBorders><w:left w:val="single" w:sz="28" w:color="' . $color . '"/></w:tcBorders>', $row, 1);
        }, $xml);
    }

    private function heatmap(array $definition): string
    {
        if (empty($definition['available'])) {
            return $this->p('Mapa de calor não apresentado: ' . $definition['note'], '', false, 20);
        }
        $maximum = max(1, (int)$definition['maximum']);
        $xml = $this->p('Volume representado: ' . OfficePackage::number($definition['total']) . ' | Registros fora da matriz: ' . OfficePackage::number($definition['omitted']), '', false, 20);
        $xml .= '<w:tbl><w:tblPr><w:tblW w:w="9500" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders>';
        foreach (['top', 'left', 'bottom', 'right', 'insideH', 'insideV'] as $edge) {
            $xml .= '<w:' . $edge . ' w:val="single" w:sz="4" w:color="' . ReportStyle::BORDER . '"/>';
        }
        $xml .= '</w:tblBorders><w:tblCellMar><w:top w:w="65" w:type="dxa"/><w:left w:w="60" w:type="dxa"/><w:bottom w:w="65" w:type="dxa"/><w:right w:w="60" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid><w:gridCol w:w="1100"/>' . str_repeat('<w:gridCol w:w="1200"/>', 7) . '</w:tblGrid>';
        $rows = array_merge([array_merge(['Hora'], $definition['column_labels'])], array_map(static function ($label, $values) { return array_merge([$label], $values); }, $definition['row_labels'], $definition['values']));
        $totals = ['Total geral'];
        foreach ($definition['column_labels'] as $weekday => $label) $totals[] = array_sum(array_column($definition['values'], $weekday));
        $rows[] = $totals;
        foreach ($rows as $rowIndex => $row) {
            $xml .= '<w:tr><w:trPr><w:cantSplit/>' . ($rowIndex === 0 ? '<w:tblHeader/>' : '') . '</w:trPr>';
            foreach ($row as $columnIndex => $value) {
                $heading = $rowIndex === 0 || $columnIndex === 0 || $rowIndex === count($rows) - 1;
                $ratio = $heading ? 0 : (int)$value / $maximum;
                $fill = $heading ? ReportStyle::NAVY : ReportStyle::heatmapColor($ratio);
                $color = $heading ? ReportStyle::WHITE : ReportStyle::NAVY;
                $text = $heading ? (string)$value : OfficePackage::number((int)$value);
                $paragraph = str_replace('w:after="140" w:line="270"', 'w:after="0" w:line="210"', $this->p($text, '', $heading, 19, 'center', $color));
                $xml .= '<w:tc><w:tcPr><w:tcW w:w="' . ($columnIndex === 0 ? '1100' : '1200') . '" w:type="dxa"/><w:shd w:val="clear" w:fill="' . $fill . '"/><w:vAlign w:val="center"/></w:tcPr>' . $paragraph . '</w:tc>';
            }
            $xml .= '</w:tr>';
        }
        $xml .= '</w:tbl>' . $this->p('Escala própria deste mapa: 0 (branco) → ' . OfficePackage::number($maximum) . ' (azul). Células mais escuras representam maior volume; os valores exatos permanecem visíveis.', '', false, 18);
        return $xml . $this->p($definition['note'], '', false, 19);
    }

    private function overview(array $metrics, string $direction): array
    {
        $categories = [];
        $values = [];
        $targets = [];
        foreach ($metrics as $metric) {
            if (($metric['direction'] ?? '') !== $direction || $metric['value'] === null) {
                continue;
            }
            $categories[] = $metric['id'];
            $values[] = $metric['value'] / 100;
            $targets[] = $metric['target'] / 100;
        }
        return [
            'id' => 'overview_' . $direction,
            'title' => $direction === 'gte' ? 'Indicadores com meta mínima' : 'Indicadores com limite máximo',
            'categories' => $categories,
            'series' => [
                ['name' => 'Resultado', 'values' => $values, 'color' => ReportStyle::BLUE],
                ['name' => $direction === 'gte' ? 'Meta mínima' : 'Limite máximo', 'values' => $targets, 'color' => ReportStyle::NAVY],
            ],
            'kind' => 'bar', 'stacked' => false, 'unit' => 'percent', 'available' => count($categories) > 0,
            'note' => $direction === 'gte'
                ? 'Regra: resultado maior ou igual à meta. O método e eventuais informações necessárias ausentes estão descritos na medição de cada indicador.'
                : 'Regra: resultado menor ou igual ao limite. Valores menores são favoráveis; zero é um resultado válido quando há população para apuração.',
        ];
    }

    private function text(string $text): string
    {
        $xml = '';
        foreach (preg_split('/\r\n|\r|\n/', $text) as $line) {
            if (trim($line) !== '') {
                $xml .= $this->p($line);
            }
        }
        return $xml;
    }

    private function heading(string $text, int $level = 1): string
    {
        return $this->p($text, 'Heading' . $level, true, $level === 1 ? 28 : 23);
    }

    private function p(string $text, string $style = '', bool $bold = false, int $size = 21, string $align = 'left', string $color = ReportStyle::NAVY): string
    {
        return '<w:p><w:pPr>' . ($style !== '' ? '<w:pStyle w:val="' . $style . '"/>' : '') . '<w:jc w:val="' . $align . '"/><w:widowControl/><w:spacing w:after="140" w:line="270" w:lineRule="auto"/>' . ($style === 'Heading1' || $style === 'Heading2' ? '<w:keepNext/>' : '') . '</w:pPr><w:r><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/>' . ($bold ? '<w:b/>' : '') . '<w:color w:val="' . ($style !== '' ? ReportStyle::NAVY : $color) . '"/><w:sz w:val="' . $size . '"/></w:rPr><w:t xml:space="preserve">' . OfficePackage::xml($text) . '</w:t></w:r></w:p>';
    }

    private function page(): string
    {
        return '<w:p><w:pPr><w:pageBreakBefore/><w:spacing w:after="0" w:before="0"/></w:pPr></w:p>';
    }

    /** Color only confirmed target violations, using the calculated status. */
    private function metricsSummary(array $snapshot): string
    {
        $rows = [];
        $violatedRows = [];
        foreach ($snapshot['metrics'] as $metric) {
            $rows[] = [$metric['id'], MetricEvidence::title($metric['id'], $snapshot['input']['priority_map'][$metric['id']] ?? null), ($metric['direction'] === 'lte' ? '≤ ' : '≥ ') . OfficePackage::percent($metric['target']), $metric['value'] === null ? ($metric['status'] === 'not_applicable' ? 'N/A' : 'Pendente') : OfficePackage::percent($metric['value']), OfficePackage::status($metric)];
            $violatedRows[] = ($metric['status'] ?? '') === 'unmet';
        }
        return $this->table(['INS', 'Indicador', 'Meta', 'Resultado', 'Situação'], $rows, [850, 4050, 1150, 1250, 2200], 18, $violatedRows);
    }

    private function table(array $headers, array $rows, array $widths, int $size = 20, array $violatedRows = []): string
    {
        $xml = '<w:tbl><w:tblPr><w:tblW w:w="9500" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders>';
        foreach (['top', 'left', 'bottom', 'right', 'insideH', 'insideV'] as $edge) {
            $xml .= '<w:' . $edge . ' w:val="single" w:sz="4" w:color="' . ReportStyle::BORDER . '"/>';
        }
        $xml .= '</w:tblBorders><w:tblCellMar><w:top w:w="85" w:type="dxa"/><w:left w:w="95" w:type="dxa"/><w:bottom w:w="85" w:type="dxa"/><w:right w:w="95" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>';
        foreach ($widths as $width) {
            $xml .= '<w:gridCol w:w="' . $width . '"/>';
        }
        $xml .= '</w:tblGrid>';
        foreach (array_merge([$headers], $rows) as $i => $row) {
            $xml .= '<w:tr><w:trPr><w:cantSplit/>' . ($i === 0 ? '<w:tblHeader/>' : '') . '</w:trPr>';
            $violated = $i > 0 && ($violatedRows[$i - 1] ?? false);
            foreach ($row as $j => $cell) {
                $total = $i > 0 && strpos((string)($row[0] ?? ''), 'Total ') === 0;
                $fill = $i === 0 ? ReportStyle::NAVY : ($violated ? self::VIOLATION_FILL : ($total || $i % 2 === 0 ? ReportStyle::POSITIVE_FILL : ReportStyle::WHITE));
                $color = $i === 0 ? ReportStyle::WHITE : ($violated ? self::VIOLATION_TEXT : ReportStyle::NAVY);
                $bold = $i === 0 || $total || ($violated && $j === count($row) - 1);
                $cellParagraph = str_replace('w:after="140" w:line="270"', 'w:after="20" w:line="240"', $this->p((string)$cell, '', $bold, $size, 'left', $color));
                $xml .= '<w:tc><w:tcPr><w:tcW w:w="' . $widths[$j] . '" w:type="dxa"/><w:shd w:val="clear" w:fill="' . $fill . '"/><w:vAlign w:val="center"/></w:tcPr>' . $cellParagraph . '</w:tc>';
            }
            $xml .= '</w:tr>';
        }
        return $xml . '</w:tbl><w:p><w:pPr><w:spacing w:after="80"/></w:pPr></w:p>';
    }

    private function styles(): string
    {
        return '<?xml version="1.0" encoding="UTF-8"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:sz w:val="21"/><w:lang w:val="pt-BR"/></w:rPr></w:rPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style><w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:rPr><w:b/><w:color w:val="' . ReportStyle::NAVY . '"/><w:sz w:val="40"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:before="240" w:after="180"/><w:outlineLvl w:val="0"/></w:pPr><w:rPr><w:b/><w:color w:val="' . ReportStyle::NAVY . '"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:before="200" w:after="140"/><w:outlineLvl w:val="1"/></w:pPr><w:rPr><w:b/><w:color w:val="' . ReportStyle::NAVY . '"/></w:rPr></w:style></w:styles>';
    }
}
