<?php

namespace GlpiPlugin\G4freports\Ses;

/** Saved contract roster and an auditable, date-based INS10 working calculation. */
final class StaffRegister
{
    public const CONFIG_KEY = 'ses_staff_register_json';
    private const MAX_ROWS = 500;
    private const MAX_BYTES = 60000;

    public static function fromSettings(array $settings): array
    {
        return self::rows($settings[self::CONFIG_KEY] ?? '[]');
    }

    /**
     * A checked mark excludes the employment from INS10. The legacy field was
     * misleadingly named "billed", but stored that same original checkbox mark.
     * Never invert it on loading, saving, restoring history or generating reports.
     */
    public static function isNotBilled(array $row): bool
    {
        $value = array_key_exists('not_billed', $row) ? $row['not_billed']
            : (array_key_exists('billed', $row) ? $row['billed'] : false);
        if (!in_array($value, [true, false, 1, 0, '1', '0'], true)) {
            throw new \InvalidArgumentException('Informe a opção Não Faturar do profissional.');
        }
        return in_array($value, [true, 1, '1'], true);
    }

    /** Normalize a complete register before saving; never infer an exit's reason. */
    public static function rows($raw): array
    {
        if (is_string($raw)) {
            if (strlen($raw) > self::MAX_BYTES || substr(ltrim($raw), 0, 1) !== '[') {
                throw new \InvalidArgumentException('O cadastro de profissionais deve ser uma lista JSON de até 60.000 bytes.');
            }
            $raw = json_decode($raw, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new \InvalidArgumentException('O cadastro de profissionais contém JSON inválido.');
            }
        }
        if (!is_array($raw) || ($raw && array_keys($raw) !== range(0, count($raw) - 1)) || count($raw) > self::MAX_ROWS) {
            throw new \InvalidArgumentException('Informe uma lista com até 500 profissionais.');
        }
        $result = [];
        $seen = [];
        foreach ($raw as $index => $row) {
            if (!is_array($row)) throw new \InvalidArgumentException('Cadastro de profissionais: linha inválida.');
            $label = 'Profissional ' . ($index + 1);
            $id = self::text($row['id'] ?? '', $label . ': identificador', 64, false);
            if ($id === '') $id = bin2hex(random_bytes(16));
            if (!preg_match('/\A[A-Za-z0-9_-]{1,64}\z/D', $id) || isset($seen[$id])) {
                throw new \InvalidArgumentException($label . ': identificador inválido ou duplicado.');
            }
            $admission = self::date($row['admission_date'] ?? '', $label . ': data de admissão');
            $departure = self::date($row['departure_date'] ?? null, $label . ': data de saída', true);
            if ($departure !== null && $departure < $admission) {
                throw new \InvalidArgumentException($label . ': a data de saída não pode ser anterior à admissão.');
            }
            $reason = $row['departure_reason'] ?? 'pending';
            if ($reason === '' || $reason === null) $reason = 'pending';
            if (!is_string($reason) || !in_array($reason, ['pending', 'replacement', 'contractor_reduction', 'other'], true)) {
                throw new \InvalidArgumentException($label . ': motivo de saída inválido.');
            }
            $notBilled = self::isNotBilled($row);
            $seen[$id] = true;
            $result[] = [
                'id' => $id,
                'not_billed' => $notBilled,
                'name' => self::text($row['name'] ?? '', $label . ': nome', 240),
                'profile' => self::text($row['profile'] ?? '', $label . ': perfil profissional', 300),
                // Optional local reference distinguishes legitimate homonyms or separate contracts.
                'record_reference' => self::text($row['record_reference'] ?? '', $label . ': identificação do vínculo', 120, false),
                'admission_date' => $admission,
                'departure_date' => $departure,
                'monthly_value' => self::money($row['monthly_value'] ?? '', $label . ': valor mensal'),
                // Keep the optional analytical detail even when the departure date is absent.
                'departure_reason' => $reason,
            ];
            // Do not inflate every legacy row when no distinction is needed.
            if ($result[count($result) - 1]['record_reference'] === '') {
                unset($result[count($result) - 1]['record_reference']);
            }
        }
        if (strlen(self::json($result)) > self::MAX_BYTES) {
            throw new \InvalidArgumentException('O cadastro de profissionais excede o limite de armazenamento de 60.000 bytes.');
        }
        return self::sortRows($result);
    }

    /** Sorting affects presentation only: departed professionals remain in the register. */
    public static function sortRows(array $rows): array
    {
        $collator = class_exists('Collator') ? new \Collator('pt_BR') : null;
        usort($rows, static function (array $a, array $b) use ($collator): int {
            $cmp = $collator ? $collator->compare($a['name'], $b['name'])
                : strcmp(self::identityText($a['name']), self::identityText($b['name']));
            return $cmp ?: strcmp($a['admission_date'] . $a['id'], $b['admission_date'] . $b['id']);
        });
        return $rows;
    }

    private static function identityText(string $text): string
    {
        $text = strtr($text, array_combine(
            preg_split('//u', 'ÁÀÂÃÄÅÉÈÊËÍÌÎÏÓÒÔÕÖÚÙÛÜÇÑáàâãäåéèêëíìîïóòôõöúùûüçñ', -1, PREG_SPLIT_NO_EMPTY),
            str_split('AAAAAAEEEEIIIIOOOOOUUUUCNaaaaaaeeeeiiiiooooouuuucn')
        ));
        return strtolower(trim(preg_replace('/\s+/u', ' ', $text)));
    }

    private static function duplicateKey(array $row): string
    {
        return implode('|', [self::identityText($row['name']), $row['admission_date'],
            self::identityText($row['profile']), self::identityText($row['record_reference'] ?? '')]);
    }

    /** Existing duplicates remain visible for review; never silently drop a saved row. */
    public static function duplicateWarnings(array $rows): array
    {
        $groups = [];
        foreach ($rows as $row) $groups[self::duplicateKey($row)][] = $row;
        $warnings = [];
        foreach ($groups as $group) if (count($group) > 1) {
            $warnings[] = ['name' => $group[0]['name'], 'admission_date' => $group[0]['admission_date'],
                'ids' => array_column($group, 'id'), 'count' => count($group)];
        }
        return $warnings;
    }

    /** Reject new duplicate employments, allowing unchanged legacy duplicates to be reviewed. */
    public static function validateDuplicates(array $rows, array $currentRows = []): void
    {
        $prior = [];
        foreach ($currentRows as $row) $prior[self::duplicateKey($row)][$row['id']] = true;
        $groups = [];
        foreach ($rows as $row) $groups[self::duplicateKey($row)][] = $row;
        foreach ($groups as $key => $group) {
            if (count($group) < 2) continue;
            foreach ($group as $row) if (!isset($prior[$key][$row['id']])) {
                throw new \InvalidArgumentException('Vínculo duplicado: ' . $row['name'] . ' (admissão ' . $row['admission_date']
                    . '). Confira a entrada existente. Para homônimos ou vínculos realmente distintos, preencha uma identificação do vínculo diferente.');
            }
        }
    }

    public static function json(array $rows): string
    {
        return json_encode($rows, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    }

    /** Used by the form to avoid silently overwriting another administrator's edits. */
    public static function revision(array $rows): string
    {
        return hash('sha256', self::json($rows));
    }

    /** Optional analytical description; legacy pending means no reason supplied. */
    public static function departureReasonLabel($reason): string
    {
        $labels = ['replacement' => 'Substituição',
            'contractor_reduction' => 'Redução determinada pela contratante',
            'other' => 'Outra saída sem substituição'];
        return is_string($reason) ? ($labels[$reason] ?? 'Motivo não informado') : 'Motivo não informado';
    }

    /**
     * Derived monthly billing; never persisted or used to change INS10 headcount.
     * Also accepts incomplete form rows for the standalone register export.
     */
    public static function billingForMonth(array $row, string $month): array
    {
        $departure = $row['departure_date'] ?? null;
        $result = ['billing_first_day' => null, 'billing_last_day' => null,
            'billed_days' => null, 'billed_value' => null, 'billing_month_days' => null,
            'status' => $departure === null || trim((string)$departure) === '' ? 'Ativo' : 'Inativo'];
        if (!preg_match('/\A(20\d{2}|2100)-(0[1-9]|1[0-2])\z/D', $month)) return $result;
        $zone = new \DateTimeZone('UTC');
        $monthStart = new \DateTimeImmutable($month . '-01', $zone);
        $monthEnd = $monthStart->modify('last day of this month');
        $monthDays = (int)$monthEnd->format('j');
        $result['billing_month_days'] = $monthDays;
        // Exclusion is explicit; preserve the user's mark and nominal salary.
        if (self::isNotBilled($row)) {
            $result['billed_days'] = 0;
            $result['billed_value'] = '0.00';
            return $result;
        }
        try {
            $admission = self::date($row['admission_date'] ?? '', 'Data de admissão');
            $departure = self::date($departure, 'Data de saída', true);
            if ($departure !== null && $departure < $admission) return $result;
        } catch (\InvalidArgumentException $e) {
            return $result;
        }
        $first = max($monthStart->format('Y-m-d'), $admission);
        $last = min($monthEnd->format('Y-m-d'), $departure ?? $monthEnd->format('Y-m-d'));
        if ($first > $last) {
            $result['billed_days'] = 0;
            $result['billed_value'] = '0.00';
            return $result;
        }
        $days = (int)(new \DateTimeImmutable($first, $zone))->diff(new \DateTimeImmutable($last, $zone))->days + 1;
        $result['billing_first_day'] = $first;
        $result['billing_last_day'] = $last;
        $result['billed_days'] = $days;
        try {
            $monthly = self::money($row['monthly_value'] ?? '', 'Valor mensal');
        } catch (\InvalidArgumentException $e) {
            return $result;
        }
        $monthlyCents = (int)str_replace('.', '', $monthly);
        // Divide only at the end: no premature rounding of the daily rate.
        $billedCents = intdiv($monthlyCents * $days * 2 + $monthDays, $monthDays * 2);
        $result['billed_value'] = number_format($billedCents / 100, 2, '.', '');
        return $result;
    }

    /**
     * Departure is the last active day. The denominator is month-end headcount.
     * Every included departure in the three-month window counts by its date.
     * Its optional reason is an analytical subdivision and never gates INS10.
     */
    public static function summarize(array $rows, string $month): array
    {
        if (!preg_match('/\A(20\d{2}|2100)-(0[1-9]|1[0-2])\z/D', $month)) {
            throw new \InvalidArgumentException('Mês inválido para apuração do cadastro de profissionais.');
        }
        $rows = self::rows($rows);
        $first = new \DateTimeImmutable($month . '-01', new \DateTimeZone('America/Sao_Paulo'));
        $monthStart = $first->format('Y-m-d');
        $monthEnd = $first->modify('last day of this month')->format('Y-m-d');
        $windowStart = $first->modify('-2 months')->format('Y-m-d');
        $active = $departures = $classifiedReplacements = $reductions = $other = $unclassified = $monthlyValueCents = $billedTotal = 0;
        $billedDaysTotal = $billedValueCents = $billingProfessionals = 0;
        $annotated = [];
        $activeIds = $departureIds = $classifiedReplacementIds = $reductionIds = $unclassifiedIds = $unbilledIds = [];
        foreach ($rows as $row) {
            $row = array_replace($row, self::billingForMonth($row, $month));
            $billedDaysTotal += $row['billed_days'];
            $billedValueCents += (int)str_replace('.', '', $row['billed_value']);
            if ($row['billed_days'] > 0) $billingProfessionals++;
            $departure = $row['departure_date'];
            $included = !$row['not_billed'];
            if ($included) $billedTotal++;
            else $unbilledIds[] = $row['id'];
            $atMonthEnd = $included && $row['admission_date'] <= $monthEnd && ($departure === null || $departure >= $monthEnd);
            $inMonth = $included && $row['admission_date'] <= $monthEnd && ($departure === null || $departure >= $monthStart);
            $inWindow = $included && $departure !== null && $departure >= $windowStart && $departure <= $monthEnd;
            if ($atMonthEnd) {
                $active++;
                $activeIds[] = $row['id'];
                $monthlyValueCents += (int)str_replace('.', '', $row['monthly_value']);
            }
            if ($inWindow) {
                $departures++;
                $departureIds[] = $row['id'];
                if ($row['departure_reason'] === 'replacement') { $classifiedReplacements++; $classifiedReplacementIds[] = $row['id']; }
                elseif ($row['departure_reason'] === 'contractor_reduction') { $reductions++; $reductionIds[] = $row['id']; }
                elseif ($row['departure_reason'] === 'other') $other++;
                else { $unclassified++; $unclassifiedIds[] = $row['id']; }
            }
            $row['relevant_month'] = $inMonth;
            $row['departure_in_window'] = $inWindow;
            $row['active_at_month_end'] = $atMonthEnd;
            $row['counted_departure'] = $inWindow;
            // Compatibility alias for existing exports: all date-eligible exits.
            $row['counted_replacement'] = $inWindow;
            $row['classification_label'] = $departure === null ? 'Sem saída registrada' : self::departureReasonLabel($row['departure_reason']);
            $row['reason'] = $row['not_billed'] ? 'Não Faturar marcado: não compõe a equipe, as saídas nem o valor mensal do INS10.' : ($inWindow ? 'Saída registrada dentro da janela de três meses; contabilizada pela data, independentemente do motivo.'
                : ($atMonthEnd ? 'Incluído e ativo no último dia do mês; compõe a equipe de referência.' : 'Fora da equipe de referência e da janela de saídas.'));
            $annotated[] = $row;
        }
        $configured = count($rows) > 0;
        $note = 'Convenção operacional: equipe de referência incluída e ativa no último dia do mês; a data de saída é o último dia ativo. '
            . 'A janela de saídas vai de ' . $windowStart . ' a ' . $monthEnd . '. '
            . 'Profissionais com “Não Faturar” marcado permanecem no cadastro, mas não entram na equipe, nas saídas ou no valor mensal do INS10. Desmarcado significa inclusão conforme as datas do vínculo. '
            . 'Todas as saídas incluídas na janela contam pela data. O motivo da saída é opcional e apenas descritivo; não altera a contagem nem impede o cálculo. '
            . 'O valor mensal é o valor cadastrado; sua soma de referência usa os profissionais incluídos e ativos no fechamento. '
            . 'O valor faturado é proporcional aos dias corridos do vínculo dentro da competência, incluindo admissão e saída: valor mensal × dias faturados ÷ dias do mês, com arredondamento final por profissional. '
            . 'Não Faturar zera os dias e o valor faturado, preservando o valor mensal cadastrado. O status Ativo/Inativo indica apenas ausência/presença de data de saída; não altera os cálculos de meses anteriores. Não há encargos nem reajustes históricos automáticos.';
        if (!$configured) $note .= ' Cadastro de profissionais não preenchido: cadastre os profissionais e suas datas para calcular o indicador.';
        if ($configured && $active === 0) $note .= ' Não há profissionais incluídos e ativos no fechamento; o percentual não se aplica por ausência de equipe de referência.';
        return [
            'rows' => $annotated, 'month' => $month, 'window_start' => $windowStart, 'window_end' => $monthEnd,
            'month_end' => $monthEnd, 'configured' => $configured, 'complete' => $configured,
            'active_total' => $active, 'departures_total' => $departures,
            // Compatibility aliases retain the metric's count; explicit reasons have their own subdivision.
            'replacements' => $departures, 'classified_replacements' => $classifiedReplacements, 'reductions' => $reductions,
            'billed_total' => $billedTotal, 'unbilled_total' => count($unbilledIds),
            'other_departures' => $other, 'unclassified_departures' => $unclassified,
            'pending_departures' => 0,
            'numerator' => $configured ? $departures : null, 'denominator' => $configured ? $active : null,
            'value' => $configured && $active > 0 ? $departures * 100 / $active : null,
            'monthly_value_total' => number_format($monthlyValueCents / 100, 2, '.', ''),
            'billed_days_total' => $billedDaysTotal,
            'billed_value_total' => number_format($billedValueCents / 100, 2, '.', ''),
            'billing_professionals_total' => $billingProfessionals,
            'billing_month_days' => (int)$first->format('t'),
            'active_ids' => $activeIds, 'departure_ids' => $departureIds, 'replacement_ids' => $departureIds,
            'classified_replacement_ids' => $classifiedReplacementIds,
            'reduction_ids' => $reductionIds, 'unclassified_ids' => $unclassifiedIds, 'pending_ids' => [],
            'unbilled_ids' => $unbilledIds,
            'method' => 'Saídas de profissionais incluídos nos três meses até o fechamento ÷ profissionais incluídos e ativos no último dia do mês × 100. O motivo da saída é apenas descritivo.',
            'note' => $note,
        ];
    }

    private static function text($value, string $label, int $limit, bool $required = true): string
    {
        if (!is_string($value)) throw new \InvalidArgumentException($label . ': informe um texto válido.');
        $value = trim($value);
        if (($required && $value === '') || strlen($value) > $limit || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', $value) || !preg_match('//u', $value)) {
            throw new \InvalidArgumentException($label . ': texto vazio, inválido ou acima do limite de ' . $limit . ' bytes.');
        }
        return $value;
    }

    private static function date($value, string $label, bool $optional = false): ?string
    {
        if ($optional && ($value === null || $value === '')) return null;
        if (!is_string($value) || !preg_match('/\A(19\d{2}|20\d{2}|2100)-(\d{2})-(\d{2})\z/D', $value, $match)
            || !checkdate((int)$match[2], (int)$match[3], (int)$match[1])) {
            throw new \InvalidArgumentException($label . ': informe uma data válida no formato AAAA-MM-DD, entre 1900 e 2100.');
        }
        return $value;
    }

    private static function money($value, string $label): string
    {
        if (!is_string($value) && !is_int($value)) throw new \InvalidArgumentException($label . ': informe um valor em reais com até duas casas decimais.');
        $value = trim((string)$value);
        $value = preg_replace('/\AR\$\s*/u', '', $value);
        if (strpos($value, ',') !== false) {
            if (!preg_match('/\A(?:\d+|\d{1,3}(?:\.\d{3})+),\d{1,2}\z/D', $value)) {
                throw new \InvalidArgumentException($label . ': formato monetário inválido.');
            }
            $value = str_replace(['.', ','], ['', '.'], $value);
        }
        if (!preg_match('/\A\d{1,8}(?:\.\d{1,2})?\z/D', $value)) {
            throw new \InvalidArgumentException($label . ': informe de R$ 0,00 a R$ 99.999.999,99, com até duas casas decimais.');
        }
        $parts = explode('.', $value, 2);
        return (string)(int)$parts[0] . '.' . str_pad($parts[1] ?? '', 2, '0');
    }
}
