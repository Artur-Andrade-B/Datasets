<?php
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }

/** Word roster cohort, inclusive billing dates and separate exclusion evidence. */
require dirname(__DIR__) . '/inc/autoload.php';

use GlpiPlugin\G4freports\Ses\DocxExporter;
use GlpiPlugin\G4freports\Ses\StaffRegister;

$assertions = 0;
function wordBillingVerify(bool $condition, string $message): void
{
    global $assertions;
    $assertions++;
    if (!$condition) throw new RuntimeException($message);
}

$rows = [];
foreach ([
    ['A Integral', '2026-01-01', '', false],
    ['B Admission', '2026-06-16', '', false],
    ['C Departure', '2026-01-01', '2026-06-02', false],
    ['D Recent exit', '2026-01-01', '2026-04-01', false],
    ['E Old exit', '2026-01-01', '2026-03-31', false],
    ['F Future hire', '2026-07-01', '', false],
    ['G Future exit', '2026-01-01', '2026-08-31', false],
    ['H Excluded old', '2026-01-01', '2026-03-31', true],
    ['I Excluded active', '2026-01-01', '', true],
] as $index => [$name, $admission, $departure, $excluded]) {
    $rows[] = ['id' => 'case-' . $index, 'name' => $name, 'profile' => 'Técnico de suporte',
        'admission_date' => $admission, 'departure_date' => $departure, 'not_billed' => $excluded,
        'monthly_value' => '30.00'];
}
$staff = StaffRegister::summarize($rows, '2026-06');
$original = $staff;
$method = new ReflectionMethod(DocxExporter::class, 'staffRegister');
$xml = $method->invoke(new DocxExporter(), $staff);
$doc = new DOMDocument();
wordBillingVerify($doc->loadXML('<root xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' . $xml . '</root>'), 'Staff section is valid XML');
$xpath = new DOMXPath($doc);
$xpath->registerNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
$tables = $xpath->query('//w:tbl');
wordBillingVerify($tables->length === 6, 'Summary, paired relevant tables, departures and paired exclusions are present');
$identity = $xpath->query('./w:tr', $tables->item(1));
$billing = $xpath->query('./w:tr', $tables->item(2));
$expected = [
    ['A Integral', 'Ativo', '01/06/2026', '30/06/2026', '30', 'R$ 30,00'],
    ['B Admission', 'Ativo', '16/06/2026', '30/06/2026', '15', 'R$ 15,00'],
    ['C Departure', 'Inativo', '01/06/2026', '02/06/2026', '2', 'R$ 2,00'],
    ['D Recent exit', 'Inativo', '—', '—', '0', 'R$ 0,00'],
    ['G Future exit', 'Inativo', '01/06/2026', '30/06/2026', '30', 'R$ 30,00'],
];
wordBillingVerify($identity->length === 7 && $billing->length === 7, 'Both tables contain five relevant people and a total');
foreach ($expected as $index => [$name, $status, $first, $last, $days, $amount]) {
    $cells = $xpath->query('./w:tc', $identity->item($index + 1));
    wordBillingVerify($cells->item(0)->textContent === $name && $cells->item(4)->textContent === $status
        && $cells->item(5)->textContent === 'Não', 'Correct identity, descriptive status and preserved exclusion flag: ' . $name);
    $values = $xpath->query('./w:tc', $billing->item($index + 1));
    wordBillingVerify($values->item(0)->textContent === $name && $values->item(1)->textContent === $first
        && $values->item(2)->textContent === $last && $values->item(3)->textContent === $days
        && $values->item(4)->textContent === 'R$ 30,00' && $values->item(5)->textContent === $amount,
        'Inclusive billing dates, unmodified monthly value and prorated billed value: ' . $name);
}
$totalCells = $xpath->query('./w:tc', $billing->item(6));
wordBillingVerify($totalCells->item(3)->textContent === '77' && $totalCells->item(4)->textContent === 'R$ 150,00'
    && $totalCells->item(5)->textContent === 'R$ 77,00', 'Month values total the same filtered rows; monthly and billed amounts are distinct');
wordBillingVerify(!str_contains($xml, 'E Old exit') && !str_contains($xml, 'F Future hire'), 'Old departures and future hires do not pollute the report');
$excluded = $xpath->query('./w:tr', $tables->item(4));
$excludedBilling = $xpath->query('./w:tr', $tables->item(5));
wordBillingVerify($excluded->length === 4 && $excludedBilling->length === 4, 'All exclusions, including old ones, remain in separate tables');
foreach (['H Excluded old', 'I Excluded active'] as $index => $name) {
    $cells = $xpath->query('./w:tc', $excluded->item($index + 1));
    $values = $xpath->query('./w:tc', $excludedBilling->item($index + 1));
    wordBillingVerify($cells->item(0)->textContent === $name && $cells->item(5)->textContent === 'Sim'
        && $values->item(3)->textContent === '0' && $values->item(4)->textContent === 'R$ 30,00'
        && $values->item(5)->textContent === 'R$ 0,00', 'Excluded staff keep monthly value and have no billable contribution: ' . $name);
}
wordBillingVerify($staff === $original && count($staff['rows']) === 9, 'Word projection never mutates the saved history or metric');
wordBillingVerify($staff['numerator'] === 2 && $staff['denominator'] === 3, 'Original INS10 date-based counts remain unchanged');
foreach ($tables as $table) {
    $width = 0;
    foreach ($xpath->query('./w:tblGrid/w:gridCol', $table) as $column) $width += (int)$column->getAttributeNS('http://schemas.openxmlformats.org/wordprocessingml/2006/main', 'w');
    wordBillingVerify($width === 9500, 'Every staff table fits the original portrait G4F content width');
    wordBillingVerify($xpath->query('./w:tr[1]/w:trPr/w:tblHeader', $table)->length === 1, 'Each long table repeats its header across pages');
}
wordBillingVerify(!str_contains($xml, 'sem cálculo proporcional'), 'Obsolete no-proration report wording is removed');
echo "Word staff billing: {$assertions} assertions passed.\n";
