<?php
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require dirname(__DIR__) . '/inc/autoload.php';
use GlpiPlugin\G4freports\Ses\StaffRegister;

$checks = 0;
function billingCheck(bool $ok, string $message): void {
    global $checks;
    $checks++;
    if (!$ok) throw new RuntimeException($message);
}
$cases = json_decode(file_get_contents(__DIR__ . '/fixtures/staff_billing_cases.json'), true, 512, JSON_THROW_ON_ERROR);
foreach ($cases as $case) {
    $before = $case['row'];
    $result = StaffRegister::billingForMonth($case['row'], $case['month']);
    foreach ($case['expected'] as $field => $expected) {
        billingCheck($result[$field] === $expected, $case['label'] . ': ' . $field . ' = ' . var_export($result[$field], true));
    }
    billingCheck($before === $case['row'], 'Never mutate entered values');
}
$rows = [
    ['id'=>'older','name'=>'Older active','profile'=>'Técnico','admission_date'=>'2025-01-01','departure_date'=>'','monthly_value'=>30],
    ['id'=>'june','name'=>'June departure','profile'=>'Técnico','admission_date'=>'2026-01-01','departure_date'=>'2026-06-02','monthly_value'=>30],
    ['id'=>'may','name'=>'May departure','profile'=>'Técnico','admission_date'=>'2026-01-01','departure_date'=>'2026-05-02','monthly_value'=>30],
    ['id'=>'march','name'=>'March departure','profile'=>'Técnico','admission_date'=>'2026-01-01','departure_date'=>'2026-03-02','monthly_value'=>30],
    ['id'=>'excluded','name'=>'Excluded','profile'=>'Técnico','admission_date'=>'2026-01-01','departure_date'=>'2026-06-02','monthly_value'=>30,'billed'=>true],
];
$saved = StaffRegister::rows($rows);
$june = StaffRegister::summarize($saved, '2026-06');
billingCheck([$june['numerator'],$june['denominator'],$june['value']] === [2,1,200], 'INS10 keeps the existing departure/headcount equation');
billingCheck($june['billed_days_total'] === 32 && $june['billed_value_total'] === '32.00', 'Sum each included professional once, including June departure');
billingCheck($june['monthly_value_total'] === '30.00', 'Nominal month-end salary total remains separate');
billingCheck($june['billing_professionals_total'] === 2, 'Two professionals overlap selected month');
billingCheck(StaffRegister::rows($june['rows']) === $saved, 'Derived fields do not pollute saved register or invert flags');
$feb = StaffRegister::summarize($saved, '2026-02');
billingCheck($feb['active_total'] === 4 && $feb['departures_total'] === 0, 'Future departures preserve historical headcount');
billingCheck($feb['billed_days_total'] === 112 && $feb['billed_value_total'] === '120.00', 'All historical active staff bill full February');
$again = StaffRegister::summarize($saved, '2026-06');
billingCheck($again === $june, 'Switching months does not retain derived state');
echo "Staff billing checks passed: {$checks} assertions.\n";
