<?php
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }

/** Synthetic INS10 presentation checks; no customer records or connection required. */
require dirname(__DIR__) . '/inc/autoload.php';

use GlpiPlugin\G4freports\Ses\DocxExporter;
use GlpiPlugin\G4freports\Ses\MetricEvidence;
use GlpiPlugin\G4freports\Ses\XlsxExporter;

function billingPresentationVerify(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

$rows = [];
foreach ([['A', true], ['B', false], ['C', null]] as [$name, $billed]) {
    $row = [
        'name' => $name,
        'profile' => 'Técnico',
        'admission_date' => '2026-01-01',
        'departure_date' => '',
        'monthly_value' => 100,
        'active_at_month_end' => $billed !== false,
    ];
    if ($billed !== null) {
        $row['billed'] = $billed;
    }
    $rows[] = $row;
}
$staff = ['configured' => true, 'rows' => $rows, 'active_total' => 2, 'monthly_value_total' => 200];
$snapshot = ['period' => ['month' => '2026-06'], 'metrics' => [], 'tickets' => [], 'staff_register' => $staff];
$originalSnapshot = $snapshot;

$table = MetricEvidence::staffRegisterTable($snapshot);
billingPresentationVerify($table['headers'][10] === 'Não foi faturado?', 'Staff evidence uses the negative label');
billingPresentationVerify(array_column($table['rows'], 10) === ['Não', 'Sim', 'Não'],
    'True, false and missing legacy billed flags retain their eligibility while inverting the display');

$wordMethod = new ReflectionMethod(DocxExporter::class, 'staffRegister');
$xml = $wordMethod->invoke(new DocxExporter(), $staff);
$document = new DOMDocument();
billingPresentationVerify($document->loadXML('<root xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' . $xml . '</root>'),
    'Word staff section is well-formed XML');
$xpath = new DOMXPath($document);
$xpath->registerNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
$tables = $xpath->query('//w:tbl');
billingPresentationVerify($tables->length === 2, 'Word contains staff summary and full register');
$staffRows = $xpath->query('./w:tr', $tables->item(1));
billingPresentationVerify($staffRows->length === 6, 'Word keeps three records and both totals');
foreach ([0 => 'Não foi faturado?', 1 => 'Não', 2 => 'Sim', 3 => 'Não', 4 => '', 5 => 'Não'] as $index => $expected) {
    $cells = $xpath->query('./w:tc', $staffRows->item($index));
    billingPresentationVerify($cells->length === 6, 'Word staff row has six columns');
    billingPresentationVerify($cells->item(5)->textContent === $expected, 'Word negative billing flag at row ' . $index);
}

$excel = new XlsxExporter();
$snapshotProperty = new ReflectionProperty(XlsxExporter::class, 'snapshot');
$snapshotProperty->setValue($excel, $snapshot);
$auditMethod = new ReflectionMethod(XlsxExporter::class, 'exclusionAudit');
$sheet = $auditMethod->invoke($excel);
$checkedFormulas = [];
foreach ($sheet['rows'] as $cells) {
    foreach ($cells as $cell) {
        $formula = $cell['formula'] ?? '';
        if (preg_match('/^(COUNTIFS|SUMIFS)\(/', $formula, $match) && str_contains($formula, '$K$')) {
            billingPresentationVerify(str_ends_with($formula, ',"Não")'), 'Excel negative billing criteria retain included records');
            billingPresentationVerify($cell['value'] === ($match[1] === 'COUNTIFS' ? 2 : 200.0),
                'Excel audit formula cache retains the included headcount or amount');
            $checkedFormulas[] = $match[1];
        }
    }
}
sort($checkedFormulas);
billingPresentationVerify($checkedFormulas === ['COUNTIFS', 'SUMIFS'], 'Headcount and amount formulas were both checked');

$foundStaffTable = false;
foreach ($sheet['tables'] as $excelTable) {
    if ($excelTable['name'] !== 'Cadastro_profissionais') {
        continue;
    }
    billingPresentationVerify(count($excelTable['headers']) === 13, 'All staff audit headers are retained');
    billingPresentationVerify(preg_match('/^A\d+:M\d+$/', $excelTable['ref']) === 1,
        'Staff audit table and filter range span all thirteen columns');
    $foundStaffTable = true;
}
billingPresentationVerify($foundStaffTable, 'Excel staff audit table was generated');
billingPresentationVerify($snapshot === $originalSnapshot, 'Export presentation does not mutate persisted billing semantics');

echo "Billing presentation checks passed: legacy flags, Word details/totals, Excel formula criteria and thirteen-column staff table.\n";
