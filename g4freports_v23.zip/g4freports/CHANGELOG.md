# 1.8.7 — cadastros permanentes e rastreabilidade dos indicadores

- Seletores INS11/INS12 visíveis lado a lado; INS12 mantém GLPI + telefonia por padrão.
- INS4 com vínculo atual N1 ou N2, sem filtro de categoria N1, excluindo N3; catálogo confere os grupos N2.
- Tabelas filtráveis de registros e motivos em cada aba INS do Excel, preservando os gráficos nativos e a identidade G4F.
- Separação explícita entre ausência de prazo de solução, ausência de SLA e ausência de categoria; rótulos de contagens específicos por indicador.
- Gravação direta e confirmada dos números de teste nas configurações, com proteção contra sobrescrita de uma versão já alterada em outra sessão.
- Cadastro persistente de profissionais com datas, perfil, valor mensal e classificação de saída; INS10 e seus gráficos/evidências calculados a partir do cadastro salvo.
- Word com quadro mensal de profissionais e movimentações dos três meses; regras v5 exigem nova geração do mês.

# Histórico de alterações — Relatórios G4F

## 1.8.6

- Nova seleção das fontes do INS12. Padrão: chamados GLPI e pesquisas de telefonia. Alternativa: somente GLPI, preservando a apuração da 1.8.5.
- Resultado combinado usa soma das respostas favoráveis dividida pela soma das válidas, com o mesmo peso por resposta; não faz média dos percentuais. Telefonia mantém conversão 6 menos a nota original; notas consideradas 4 e 5 são favoráveis.
- Uma resposta telefônica por identificador de ligação, mesmo em várias filas; números de teste continuam excluídos. Linha representativa e nota usada no INS12 registradas nas evidências. Respostas ausentes/inválidas não entram no denominador.
- Prévia, Word e Excel informam a escolha, a composição por fonte e o total. Fórmulas, distribuição diária e gráfico de notas incorporam as duas bases conforme a seleção. Fonte incluída indisponível deixa o resultado pendente.
- Regras `ses-2026-07-31-v4`: nova extração obrigatória para rascunhos anteriores. A escolha das fontes não pode ser alterada pela atualização de textos.
- Preservados INS1–INS11, exclusões N3, data de solução, telefonia INS7–INS9, conexões, identidade visual e estrutura nativa dos gráficos.

## 1.8.5

- Aplicado checklist do cliente: exclusão de vínculo técnico atual N3 somente em INS3, INS4 e INS6, tanto no numerador como no denominador, com precedência sobre vínculo N1 simultâneo. Base completa e demais indicadores preservados.
- Grupos N3 configuráveis, com nomes conferidos na fonte; exclusões e elegibilidade efetiva INS6 documentadas na prévia, Word e Excel. Fórmulas e gráficos usam a população após exclusões.
- Confirmadas as categorias INS6 162, 149 e 176 já presentes na lista inicial. Mantidas as 44 categorias e as metas máximas INS5 ≤2%, INS9 ≤5% e INS10 ≤10%.
- Rótulos percentuais de comparação no Excel passam a duas casas decimais, alinhados às tabelas e ao Word, sem alterar a estrutura OOXML dos gráficos corrigida na 1.8.4.
- Evidência de pesquisa telefônica apresentada separadamente do INS12, com contagem por identificador único, disponibilidade da fonte, nota original, nota convertida, ID e data da resposta. Incluído acompanhamento gerencial editável; pesquisas telefônicas não são incorporadas automaticamente à fórmula GLPI.
- Regras `ses-2026-07-31-v3`: rascunhos anteriores exigem nova extração. Mantidos fontes, credenciais, recorte por solução, exclusões de testes, identidade visual e relatórios por profissional via API.

## 1.8.4

- Corrigidos os rótulos personalizados dos gráficos Word e Excel conforme o contexto de série e as restrições do Microsoft Office. Roscas não emitem posição explícita; opções de percentual e bolha são limitadas aos tipos compatíveis. Preservados dados, referências, paleta G4F, barras, pizzas, roscas e mapas.
- Grupo N1 inicial corrigido de 53 para 55. Seleções explícitas, lista de 44 categorias, população por solução e critérios de atribuição atual permanecem preservados.
- IDs e nomes dos grupos, categorias elegíveis e artigos informados são consultados na fonte GLPI do relatório, preservados no rascunho e apresentados na prévia e nos dois formatos de exportação.
- Seleções inexistentes produzem erros específicos. Falta de acesso ao catálogo de artigos mantém o INS11 por vínculos validados pendente. A lista exige IDs de artigos e não presume aprovação por associação a uma categoria.
- Teste de conexão GLPI inclui os campos dos catálogos usados na conferência de IDs. Fontes, credenciais, consultas mensais de chamados/telefonia, exclusões e relatórios profissionais pela API são preservados.
- Rascunhos v2 existentes podem ser reexportados com a estrutura de gráficos corrigida, mantendo sua apuração original. Para aplicar o N1 corrigido e registrar os nomes, gere novamente o mês.

## 1.8.3

- Corrigida a estrutura OOXML dos rótulos individuais de pizzas e roscas no Excel: a opção de excluir um rótulo não é combinada com suas opções de exibição. A estrutura anterior era rejeitada pelo esquema e correspondia às quatro partes de desenho removidas na mensagem de reparo apresentada.
- Volumes diários voltaram a colunas: ligações empilhadas por desfecho e chamados por data de solução. Mantidos pizzas, roscas e mapas de calor quando adequados.
- Aplicada a paleta do manual G4F aos gráficos, tabelas e mapas dos relatórios SES: marinho, azul, amarelo e cinza claro, com variantes oficiais e tons claros derivados. Mantido o papel timbrado existente.
- Preservadas as consultas, regras, bases, fórmulas dos indicadores, normalização temporal, exclusões, configurações e fluxo anterior por API. Rascunhos válidos 1.8.1/1.8.2 podem ser reexportados.

## 1.8.2

- Gráficos escolhidos conforme a informação: pizza para tipos de chamados; roscas para composições selecionadas; colunas para duração, espera e notas de satisfação; linhas para volumes diários. Comparações de metas e contagens de prazo mantêm barras.
- Acrescentados mapas de calor por hora e dia da semana, para chamados solucionados e ligações recebidas, com valores, totais e escala de intensidade próprios. O horário é o registrado na extração; ligações de teste permanecem excluídas.
- Nova aba `Distribuição Temporal` no Excel, totalizando 18 abas, com fórmulas baseadas nas datas da própria planilha e formatação condicional. O Word apresenta os mapas como tabelas editáveis.
- Percentuais de composição são identificados separadamente das frações contratuais. Fatias pequenas e quantidades zero continuam documentadas nas evidências; pendência/N/A não vira resultado zero.
- Atualização restrita à apresentação: preservados consultas, seleção por solução/entrada na fila, regras dos indicadores, exclusões, configuração e fluxo por API. Rascunhos válidos da versão 1.8.1 podem ser exportados com as novas visualizações.

## 1.8.1

- Corrigido INS6: exige categoria elegível e atribuição atual a grupo N1; removido o critério que tratava ausência de N2 como solução N1. O relatório explicita que vínculo atual não identifica automaticamente o solucionador histórico.
- Acrescentados gráficos nativos editáveis ao Word e gráficos por indicador ao Excel, derivados da mesma extração. Metas mínimas e máximas ficam distintas; pendente/N/A não é mostrado como zero.
- Adicionada a aba `Auditoria de exclusões`, com regras aplicadas e ligações excluídas. Contagens oficiais continuam usando apenas ligações consideradas.
- Telefonia distingue abandono total e abandono após mais de 30 segundos, além das durações médias e percentuais por limite.
- Corrigido contraste do botão de geração e seus estados.
- Versão de regras alterada para `ses-2026-07-31-v2`; rascunhos anteriores exigem nova geração para exportar com os critérios e gráficos atualizados.
- Preservadas as consultas SQL e as demais regras dos indicadores, as conexões e o fluxo anterior por API.

## 1.8.0

### Relatório mensal SES

- Nova área acessível pela tela principal do plugin, com geração mensal a partir das conexões GLPI/MariaDB e Asterisk/MySQL.
- Seleção de chamados por data de solução e de ligações por entrada na fila; critérios e data da extração informados nos arquivos.
- Word editável com timbre G4F e Excel com 16 abas, gerados a partir do mesmo rascunho de dados e regras. Exportação não refaz consultas.
- Prévia de indicadores e tabelas paginadas; bases Excel completas para o recorte gerado.
- Cadastro administrativo de números de teste com motivo e situação. Exclusão exata pelo número de origem normalizado aplicada a todas as métricas e detalhes considerados de telefonia.
- INS1–INS4 com mapeamentos explícitos do painel ou da ordem do contrato; uso do prazo registrado no GLPI e identificação de chamados sem prazo.
- INS5 com reaberturas registradas e complemento manual de execução incompleta; INS6 com categorias elegíveis e critério de grupo visível.
- INS11 padrão por vínculo direto a artigo previamente validado, com opção provisória de aproximação por categoria.
- Dados manuais de pessoal para INS10, textos gerenciais editáveis e situações pendente/provisório/não aplicável quando necessárias.
- Rascunhos temporários vinculados ao usuário, com validade de 24 horas; atualização de textos preserva a extração.

### Configuração e diagnóstico

- Template versionado fixado ao diretório do código carregado e identificação visível da versão 1.8.0.
- Corrigido o valor do campo oculto `config_class`, evitando separadores duplicados que impediam a resolução do tratamento nativo de configuração.
- Diagnóstico administrativo com versão, origem dos arquivos, hashes em disco, candidatos de diretório e informações de OPcache, sem exibir credenciais ou consultar as fontes dos relatórios.
- Mantidos os campos e testes independentes das duas conexões SQL, a criptografia nativa das senhas e a gravação pelo formulário de configuração do GLPI.
- Atualização preserva configurações existentes. Desinstalação não faz parte do procedimento de atualização.

A renderização do formulário completo, com cache de produção e namespace antigo, foi verificada localmente. A causa do formulário antigo no ambiente de destino não foi afirmada como conclusivamente identificada; o diagnóstico permite conferir o código efetivamente carregado.

### Fluxo existente

- Preservados os relatórios por profissional, seus perfis de API, contextos, análises, processamento em lotes e exportação DOCX.
- Sem dependência de PHPWord ou de biblioteca externa de planilhas e sem criação de tabelas de negócio nas fontes consultadas.

## 1.7.0 — histórico

- Configuração e teste independentes de GLPI/MariaDB e Callcenter/MySQL, com preenchimento de endereço JDBC, TLS e limites de tempo.
- Criptografia nativa, manutenção de senha ao deixar o campo vazio e exclusão explícita.
- Diagnóstico de conexão e acesso às tabelas/colunas usadas pelos relatórios.
- A versão 1.7.0 continha somente as conexões; o módulo SES e suas exportações foram acrescentados na 1.8.0.

## Histórico anterior

## Alterações v0.9.0

- Corrigido ciclo de geração/exportação para evitar erro de autorização ao gerar um rascunho, exportar e depois alterar parâmetros sem recarregar a página.
- Exportação DOCX agora ocorre em iframe oculto, sem navegar a página principal.
- Sessões da API GLPI são finalizadas em `finally` nos endpoints de teste, busca e geração.
- Busca de grupos por nome usa descoberta de search options e tenta múltiplos campos seguros de nome/completename.
- ID e nome do agente são somente leitura e preenchidos pela busca.
- Adicionada área de análises selecionáveis junto dos contextos.
- Adicionadas análises de tempo de resposta com cálculo requester -> primeira ação técnica posterior.
- Adicionada análise de localização com fallback: localização do chamado, localização do solicitante e `Local não informado`.
- DOCX recebeu tabelas/gráficos editáveis para análises.
- Modelos operacional, gerencial, técnico/projeto e anexo ficaram mais diferenciados.

## Alterações v0.9.1

- Ajuste visual das análises exportadas em DOCX.
- Gráficos nativos do Word/LibreOffice para linha, pizza, rosca, barras horizontais e colunas.
- Mapa de calor editável em tabela Word para volumetria por dia da semana.
- Análises distribuídas ao longo do documento conforme o modelo selecionado, em vez de ficarem concentradas em um único bloco no início.
- Prévia web com visualizações variadas: linha em SVG, donut/pizza por CSS, heatmap em grade e barras apenas quando fizer sentido.
- Mapa de calor derivado da análise de volume diário.
- Mantida a lógica API-first, extração em lotes, sem /ajax, sem dependências externas e sem bibliotecas de gráficos.


## Alterações v1.0.1

- Adicionado Contexto de dados com filtro por múltiplos títulos de chamados.
- Busca de chamado por ID para usar o título como referência de filtro.
- Filtro por título aplica em conjunto com agente/grupos/contextos selecionados, sem substituir o escopo.
- Modo gerencial por grupos selecionados, omitindo detalhamento individual e consolidando indicadores por agente.
- Exportação DOCX preserva papel timbrado G4F e distribui análises/tabelas conforme o modelo selecionado.


## Alterações v1.0.1

- Corrigida a lógica de filtro por título para que ela não use categoria/referência como substituto do título real do chamado.
- Entradas derivadas de chamados agora carregam `ticket_id` e `ticket_title` separadamente, evitando que o filtro pareça renomear itens encontrados.
- O filtro por título passa a ser aplicado após os contextos de agente/grupo/período, em composição com eles, e não como substituição do escopo.
- Em modo `somente detalhamento`, os indicadores e gráficos continuam usando o escopo completo, mas `detail_entries` retorna apenas os chamados cujo título real corresponde aos títulos selecionados.
- Em modo `global`, os fatos, entradas, indicadores e gráficos passam a considerar apenas os chamados cujo título real corresponde aos títulos selecionados.


## Alterações v1.1.1

- Resumo gerencial por agente agora prioriza nome e sobrenome do usuário GLPI em vez do login/ID.
- Login/ID foi mantido como referência secundária em coluna própria na prévia e no DOCX.
- Resolução de nomes usa cache e fallback seguro para não reintroduzir timeouts.

## Alterações v1.1.0

- Corrigida a paginação de contextos por grupo: cada grupo selecionado agora é processado como alvo independente, evitando `ERROR_RANGE_EXCEED_TOTAL` e evitando que um grupo grande bloqueie a leitura dos demais.
- Contextos por grupo passam a usar chaves internas por grupo, mantendo rótulo agregado na interface e permitindo totais por escopo mais confiáveis.
- Chamados de usuário/grupo agora são pesquisados por múltiplas bases de data em lotes separados: atualização, abertura, solução e fechamento, reduzindo casos de chamados presentes no GLPI mas ausentes no relatório.
- `ERROR_RANGE_EXCEED_TOTAL` é tratado como fim de paginação daquele alvo, não como erro de relatório.
- Modo gerencial passa a montar resumo por agente com fallback por técnico atribuído quando eventos de tarefa/acompanhamento/solução não estão disponíveis ou estão parciais.
- Eventos técnicos em modo gerencial consideram ações não solicitantes com autoria detectável, evitando resumo zerado quando a API não expõe vínculo de grupo no subitem.
- O preset Gerencial agora prioriza grupos selecionados e não contextos centrados no agente solicitante.
- O resumo executivo e as validações do modo gerencial usam chamados/fatos carregados, não a lista de entradas detalhadas que é omitida por design.


## Alterações v1.2.0

- Adicionado critério temporal explícito para chamados: criados no período com ação do agente, atualizados no período, solucionados/fechados no período e solucionados/fechados pelo agente.
- Removido o uso invisível de todos os campos de data ao mesmo tempo; os lotes agora usam apenas os critérios temporais selecionados na interface.
- Critérios “pelo agente” passam a exigir autoria detectável via tarefas, acompanhamentos ou soluções expostas pela API.
- Melhorada a cobertura da extração com painel de fontes, totais da API, linhas lidas, únicos adicionados, duplicados e limitações da API.
- Corrigida extração de IDs de pais em subitens quando a API retorna rótulos como “Chamado 123456” em vez de número puro.
- Restaurados métodos de última atividade de chamados/projetos que haviam sido removidos acidentalmente em um ajuste anterior.
- Leitura de subitens ganhou modo de verificação paginado e controlado por orçamento para evitar perdas silenciosas sem reintroduzir 504.
- A distribuição de origem em modo gerencial prioriza grupos selecionados sobre contexto de solicitante quando o chamado foi descoberto por múltiplas fontes.

## Alterações v1.4.0

- Corrige a chamada/runtime de `mergeTicketSearchRows` garantindo que o pacote contenha a implementação usada pelo fluxo temporal.
- Normaliza fontes de chamados com escopo temporal para as chaves-base (`tickets_assigned_user`, `tickets_requested_by_user`, `tickets_assigned_groups`) para evitar que chamados encontrados sejam tratados depois como fora do contexto.
- Mantém chaves detalhadas por grupo/data para cobertura, mas recalcula a fonte primária após mesclagem de lotes, priorizando grupos selecionados em relatórios gerenciais.
- Adiciona limitação compacta de cobertura quando buscas diretas de subitens falham, sem exportar erro técnico bruto no DOCX.
- Atualiza a versão em `setup.php` e `inc/common.php` para remover ambiguidade de pacotes v1.2.0.


### Correção v1.4.0

- O pipeline de tickets agora é canônico: linhas brutas da API e descobertas por múltiplos contextos são mescladas por ID de chamado antes de gerar o detalhamento editável.
- O relatório normal renderiza um único bloco por chamado, evitando duplicidade quando o mesmo ticket é encontrado por agente, grupo e critério temporal.
- A data exibida no detalhamento passa a seguir o critério temporal selecionado sempre que possível; em relatórios de criação no período, a data de abertura do chamado é priorizada em vez da última solução/comentário.
- Entradas cujo detalhamento cairia fora do período são omitidas do corpo normal e contabilizadas na cobertura como detalhes fora do período.
- Métricas e gráficos passam a usar os fatos finais/canônicos em vez de entradas parciais de lote.
