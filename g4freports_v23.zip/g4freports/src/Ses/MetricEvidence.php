<?php

namespace GlpiPlugin\G4freports\Ses;

/** Human-readable evidence from the frozen calculation, never a second query. */
final class MetricEvidence
{
    public static function labels(string $id): array
    {
        $labels = [
            'INS1' => ['Chamados no prazo', 'Chamados com prazo válido'],
            'INS2' => ['Chamados no prazo', 'Chamados com prazo válido'],
            'INS3' => ['Chamados no prazo', 'Chamados com prazo válido'],
            'INS4' => ['Chamados N1/N2 no prazo', 'Chamados N1/N2 com prazo válido'],
            'INS5' => ['Reabertos ou incompletos', 'Chamados solucionados'],
            'INS6' => ['Elegíveis com grupo N1', 'Chamados de categorias elegíveis'],
            'INS7' => ['Concluídas em até 600 s', 'Ligações recebidas consideradas'],
            'INS8' => ['Conectadas em até 30 s', 'Ligações recebidas consideradas'],
            'INS9' => ['Abandonadas após 30 s', 'Ligações recebidas consideradas'],
            'INS10' => ['Substituições consideradas', 'Profissionais ativos ao fim do mês'],
            'INS11' => ['Chamados com vínculo considerado', 'Chamados solucionados'],
            'INS12' => ['Respostas favoráveis (4 ou 5)', 'Respostas válidas (1 a 5)'],
        ];
        $pair = $labels[$id] ?? ['Quantidade apurada', 'Base de cálculo'];
        return ['numerator' => $pair[0], 'denominator' => $pair[1]];
    }

    public static function table(array $snapshot, string $id): array
    {
        $metrics = array_column($snapshot['metrics'] ?? [], null, 'id');
        $metric = $metrics[$id] ?? [];
        if ($id === 'INS10') return self::staff($snapshot);
        if ($id === 'INS12') return self::surveys($snapshot, $metric);
        if (in_array($id, ['INS7', 'INS8', 'INS9'], true)) return self::calls($snapshot, $metric, $id);
        return self::tickets($snapshot, $metric, $id);
    }

    private static function sets(array $metric): array
    {
        return [array_fill_keys(array_map('strval', $metric['evidence_ids'] ?? []), true),
            array_fill_keys(array_map('strval', $metric['denominator_ids'] ?? []), true)];
    }

    private static function tickets(array $s, array $m, string $id): array
    {
        [$num, $den] = self::sets($m);
        $input = $s['input'];
        $labels = self::labels($id);
        $headers = ['ID do chamado', 'Título', 'Categoria ID', 'Categoria de chamado', 'Grupos IDs', 'Grupos técnicos',
            'Abertura', 'Solução', 'Prioridade GLPI', 'SLA ID', 'SLA aplicado', 'SLA atribuído', 'Prazo para solução', 'Classificação do prazo'];
        $extra = [];
        if ($id === 'INS5') $extra = ['Reabertura registrada', 'Execução incompleta informada', 'Solução recusada'];
        if ($id === 'INS6') $extra = ['Categoria elegível N1', 'Vínculo atual N1', 'Vínculo atual N2', 'Vínculo atual N3'];
        if ($id === 'INS11') $extra = ['Artigos diretamente vinculados IDs', 'Artigos validados encontrados IDs', 'Categoria BC ID', 'Critério de vínculo aplicado'];
        $headers = array_merge($headers, $extra, ['Elegível à base de cálculo', $labels['numerator'], 'Motivo / classificação']);
        $rows = [];
        foreach ($s['tickets'] ?? [] as $t) {
            $key = (string)$t['id'];
            $eligible = isset($den[$key]);
            $counts = isset($num[$key]);
            $noDeadline = ($t['within_sla'] ?? null) === null;
            $sla = (int)($t['sla_id'] ?? 0);
            $values = [$key, $t['title'] ?? '', (int)($t['category_id'] ?? 0), self::category($t),
                implode(', ', $t['group_ids'] ?? []), $t['groups'] ?? '', $t['opened_at'] ?? '', $t['solved_at'] ?? '',
                $t['priority'] ?? '', $sla, $t['sla_name'] ?? '', $sla > 0 ? 'Sim' : 'Não',
                $t['deadline'] ?? '', $noDeadline ? 'Sem prazo para solução' : (!empty($t['within_sla']) ? 'No prazo' : 'Fora do prazo')];
            $reason = '';
            if (in_array($id, ['INS1', 'INS2', 'INS3', 'INS4'], true)) {
                if ((int)$t['priority'] !== (int)$input['priority_map'][$id]) $reason = 'Prioridade fora do recorte deste indicador';
                elseif (in_array($id, ['INS3', 'INS4'], true) && !empty($t['assigned_n3'])) $reason = 'Excluído: vínculo atual a N3';
                elseif ($id === 'INS4' && empty($t['ins4_scope'])) $reason = 'Excluído: sem vínculo atual aos grupos N1 ou N2 selecionados';
                elseif ($noDeadline) $reason = 'Sem prazo para solução: não é possível avaliar cumprimento; fora da fração';
                else $reason = $counts ? 'Solução até o prazo registrado' : 'Solução após o prazo registrado';
            } elseif ($id === 'INS5') {
                array_push($values, self::yes(!empty($t['reopened'])), self::yes(!empty($t['incomplete_execution'])), self::yes(!empty($t['refused_solution'])));
                $reason = $m['numerator'] === null ? 'Evidência de reabertura indisponível' : ($counts ? 'Reabertura ou execução incompleta; contado uma vez' : 'Sem reabertura nem execução incompleta informada');
            } elseif ($id === 'INS6') {
                array_push($values, self::yes(!empty($t['n1_eligible'])), self::yes(!empty($t['assigned_n1'])), self::yes(!empty($t['assigned_n2'])), self::yes(!empty($t['assigned_n3'])));
                if (empty($t['n1_eligible'])) $reason = 'Categoria fora da lista elegível N1';
                elseif (!empty($t['assigned_n3'])) $reason = 'Excluído: vínculo atual a N3';
                else $reason = $counts ? 'Categoria elegível e vínculo atual N1' : 'Categoria elegível; sem vínculo atual N1';
            } elseif ($id === 'INS11') {
                $valid = array_values(array_intersect($t['kb_ids'] ?? [], $input['validated_kb_ids'] ?? []));
                $proxy = ($input['kb_mode'] ?? '') === 'category_proxy';
                array_push($values, implode(', ', $t['kb_ids'] ?? []), implode(', ', $valid), $t['kb_category_id'] ?? 0,
                    $proxy ? 'Vínculo da categoria (proxy)' : 'Artigo diretamente vinculado e validado');
                $reason = $m['numerator'] === null ? 'Apuração pendente: vínculo/catálogo/lista validada indisponível' : ($counts ? ($proxy ? 'Categoria com vínculo BC; não comprova artigo' : 'Pelo menos um artigo vinculado consta da lista validada') : ($proxy ? 'Categoria sem vínculo BC' : 'Nenhum artigo diretamente vinculado consta da lista validada'));
            }
            array_push($values, self::yes($eligible), $m['numerator'] === null ? 'Pendente' : self::yes($counts), $reason);
            $rows[] = $values;
        }
        return ['headers' => $headers, 'rows' => $rows];
    }

    private static function calls(array $s, array $m, string $id): array
    {
        [$num, $den] = self::sets($m);
        $headers = ['ID da ligação', 'Fila', 'Número de origem', 'Entrada na fila', 'Conexão ao agente', 'Conclusão', 'Abandono',
            'Desfecho', 'Conversa (s)', 'Espera até conexão (s)', 'Espera até abandono (s)', 'Número de teste',
            'Elegível à base de cálculo', self::labels($id)['numerator'], 'Motivo / classificação'];
        $rows = [];
        foreach (array_merge($s['calls'] ?? [], $s['excluded_calls'] ?? []) as $c) {
            $key = self::callKey($c);
            $test = isset($c['excluded_reason']);
            $yes = isset($num[$key]);
            $reason = $test ? 'Excluída: número de teste salvo — ' . $c['excluded_reason'] : '';
            if (!$test) {
                if ($yes) $reason = $id === 'INS7' ? 'Concluída com conversa até 600 s' : ($id === 'INS8' ? 'Conectada com espera até 30 s' : 'Abandonada sem atendimento após mais de 30 s');
                elseif ($id === 'INS7') $reason = empty($c['completed_at']) ? 'Sem evento de conclusão; permanece na base recebida' : (self::secondsValid($c['talk_seconds'] ?? null) ? 'Conversa acima de 600 s' : 'Duração de conversa ausente/inválida');
                elseif ($id === 'INS8') $reason = empty($c['connected_at']) ? 'Sem conexão ao agente; permanece na base recebida' : (self::secondsValid($c['wait_seconds'] ?? null) ? 'Espera até conexão acima de 30 s' : 'Espera até conexão ausente/inválida');
                else $reason = ($c['type'] ?? '') === 'Atendida' ? 'Atendida; não é abandono' : (($c['type'] ?? '') === 'Abandonada' ? (self::secondsValid($c['abandon_wait_seconds'] ?? null) ? 'Abandono até 30 s; não atende ao limite estrito > 30 s' : 'Abandono sem espera válida') : 'Sem atendimento nem abandono identificado');
            }
            $rows[] = [(string)$c['id'], $c['queue'] ?? '', (string)($c['caller'] ?? ''), $c['entered_at'] ?? '', $c['connected_at'] ?? '', $c['completed_at'] ?? '', $c['abandoned_at'] ?? '',
                $c['type'] ?? '', $c['talk_seconds'] ?? '', $c['wait_seconds'] ?? '', $c['abandon_wait_seconds'] ?? '',
                self::yes($test), self::yes(isset($den[$key])), self::yes($yes), $reason];
        }
        return ['headers' => $headers, 'rows' => $rows];
    }

    private static function surveys(array $s, array $m): array
    {
        [$num, $den] = self::sets($m);
        $headers = ['Fonte da pesquisa', 'ID do chamado / ligação', 'Título / fila', 'Categoria ID', 'Categoria de chamado', 'Grupos técnicos',
            'Data do recorte', 'Nota original', 'Nota considerada (1–5)', 'Resposta única da ligação', 'Fonte selecionada',
            'Resposta válida considerada', 'Resposta favorável considerada', 'Motivo / classificação'];
        $rows = [];
        foreach ($s['tickets'] ?? [] as $t) {
            $key = (string)$t['id'];
            $rating = $t['satisfaction'] ?? null;
            $available = !empty($m['source_counts']['tickets']['available']);
            $reason = !$available ? 'Fonte de pesquisas GLPI indisponível' : ($rating === null || $rating === '' ? 'Sem resposta à pesquisa' : (empty($t['satisfaction_valid']) ? 'Nota fora da escala inteira 1–5' : (isset($num[$key]) ? 'Resposta favorável (4 ou 5)' : 'Resposta válida não favorável (1, 2 ou 3)')));
            $rows[] = ['GLPI', $key, $t['title'] ?? '', $t['category_id'] ?? 0, self::category($t), $t['groups'] ?? '', $t['solved_at'] ?? '',
                $rating ?? '', !empty($t['satisfaction_valid']) ? $rating : '', 'Não se aplica', 'Sim', self::yes(isset($den[$key])), self::yes(isset($num[$key])), $reason];
        }
        $selected = ($s['input']['ins12_mode'] ?? '') === 'glpi_and_phone';
        $available = !empty($m['source_counts']['phone']['available']);
        foreach (array_merge($s['calls'] ?? [], $s['excluded_calls'] ?? []) as $c) {
            $key = self::callKey($c);
            $test = isset($c['excluded_reason']);
            $rating = $c['ins12_score'] ?? PhoneSurveySummary::normalizedRating($c);
            $raw = array_key_exists('satisfaction_raw', $c) ? $c['satisfaction_raw'] : null;
            $hasObserved = ($raw !== null && $raw !== '') || (isset($c['satisfaction']) && $c['satisfaction'] !== '');
            if ($test) $reason = 'Excluída: número de teste salvo — ' . $c['excluded_reason'];
            elseif (!$selected) $reason = 'Telefonia desmarcada para o INS12 nesta extração';
            elseif (!$available) $reason = 'Fonte de pesquisas telefônicas indisponível';
            elseif (empty($c['ins12_representative'])) $reason = 'Outra fila da mesma ligação; resposta contada uma única vez';
            elseif ($rating === null) $reason = $hasObserved ? 'Nota ausente/inválida na escala original inteira 1–5' : 'Sem resposta à pesquisa';
            else $reason = isset($num[$key]) ? 'Resposta favorável após normalização (6 − nota original)' : 'Resposta válida não favorável após normalização';
            $rows[] = ['Telefonia', (string)$c['id'], $c['queue'] ?? '', '', '', '', $c['entered_at'] ?? '', $raw ?? '', $rating ?? '',
                self::yes(!empty($c['ins12_representative'])), self::yes($selected), self::yes(isset($den[$key])), self::yes(isset($num[$key])), $reason];
        }
        return ['headers' => $headers, 'rows' => $rows];
    }

    private static function staff(array $s): array
    {
        $headers = ['Nome', 'Perfil Profissional', 'Data de admissão', 'Data de saída', 'Valor mensal (R$)', 'Classificação da saída',
            'Ativo ao fim do mês', 'Saída na janela de três meses', 'Substituição considerada', 'Motivo / classificação'];
        $rows = [];
        foreach ($s['staff_register']['rows'] ?? [] as $r) {
            $rows[] = [$r['name'], $r['profile'], $r['admission_date'], $r['departure_date'] ?? '', (float)$r['monthly_value'],
                $r['classification_label'] ?? '', self::yes(!empty($r['active_at_month_end'])), self::yes(!empty($r['departure_in_window'])),
                self::yes(!empty($r['counted_replacement'])), $r['reason'] ?? ''];
        }
        return ['headers' => $headers, 'rows' => $rows];
    }

    private static function category(array $t): string
    {
        if ((int)($t['category_id'] ?? 0) <= 0) return 'Sem categoria de chamado';
        return trim((string)($t['category'] ?? '')) !== '' ? $t['category'] : 'Categoria ID ' . $t['category_id'] . ' — nome indisponível';
    }

    private static function callKey(array $c): string { return (string)($c['call_key'] ?? ($c['id'] . '|' . $c['queue'])); }
    private static function yes(bool $value): string { return $value ? 'Sim' : 'Não'; }
    private static function secondsValid($value): bool { return is_numeric($value) && is_finite((float)$value) && (float)$value >= 0; }
}
