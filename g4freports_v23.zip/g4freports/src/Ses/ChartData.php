<?php

namespace GlpiPlugin\G4freports\Ses;

/** Chart definitions derived only from the preserved, calculated extraction. */
class ChartData
{
    public static function build(array $snapshot): array
    {
        $tickets = $snapshot['tickets'] ?? [];
        $calls = $snapshot['calls'] ?? [];
        $input = $snapshot['input'] ?? [];
        $metrics = array_column($snapshot['metrics'] ?? [], null, 'id');
        $result = [];
        foreach (['INS1', 'INS2', 'INS3', 'INS4'] as $id) {
            $counts = [0, 0, 0];
            $priority = (int)($input['priority_map'][$id] ?? 0);
            $cohortIds = array_key_exists('cohort_ids', $metrics[$id] ?? [])
                ? array_fill_keys(array_map('intval', $metrics[$id]['cohort_ids']), true) : null;
            foreach ($tickets as $ticket) {
                if ($cohortIds !== null ? !isset($cohortIds[(int)$ticket['id']])
                    : ((int)($ticket['priority'] ?? 0) !== $priority
                        || (in_array($id, ['INS3', 'INS4'], true) && !empty($ticket['assigned_n3']))
                        || ($id === 'INS4' && empty($ticket['ins4_scope'])))) {
                    continue;
                }
                $flag = $ticket['within_sla'] ?? null;
                $counts[$flag === null ? 2 : ($flag ? 0 : 1)]++;
            }
            $result[$id] = self::counts($id, $id . ' — Prazo de solução',
                ['No prazo', 'Fora do prazo', 'Sem prazo para solução'], $counts, array_sum($counts) > 0,
                'Quantidades de chamados da prioridade GLPI ' . $priority . '. '
                . ($id === 'INS4' ? 'Inclui os grupos N1 e N2 selecionados, com exclusão de vínculos a N3. ' : '')
                . 'Sem prazo para solução indica ausência de data limite válida no chamado, mesmo quando existe um SLA associado; não indica ausência de categoria. '
                . 'Esses chamados aparecem separadamente e ficam fora do percentual. Ter prazo válido permite a comparação mesmo sem SLA associado. '
                . self::denominatorNote($metrics[$id] ?? []) . self::exclusionNote($metrics[$id] ?? []));
        }

        $m = $metrics['INS5'] ?? [];
        $available = self::metricAvailable($m);
        $num = (int)($m['numerator'] ?? 0);
        $den = (int)($m['denominator'] ?? 0);
        $result['INS5'] = self::counts('INS5', 'INS5 — Reabertura e execução incompleta',
            ['Reabertos ou incompletos', 'Demais chamados'], [$num, max(0, $den - $num)], $available,
            'Quantidades, com união das duas evidências sem duplicidade. ' . self::denominatorNote($m)
            . (!$available ? ' Apuração indisponível ou sem população; ausência de evidência não é zero.' : ''));

        $counts = [0, 0, 0];
        $n1Groups = array_map('intval', $input['n1_group_ids'] ?? []);
        foreach ($tickets as $ticket) {
            if (empty($ticket['ins6_eligible'])) {
                continue;
            }
            $groups = array_values(array_filter(array_map('intval', $ticket['group_ids'] ?? []), function ($id) { return $id > 0; }));
            $counts[count(array_intersect($groups, $n1Groups)) ? 0 : (count($groups) ? 1 : 2)]++;
        }
        $currentRule = ($input['ins6_mode'] ?? '') === 'assigned_n1';
        $result['INS6'] = self::counts('INS6', 'INS6 — Atribuição atual dos elegíveis N1',
            ['Com grupo N1', 'Somente outros grupos', 'Sem grupo'], $counts, $currentRule && array_sum($counts) > 0,
            'Quantidades de chamados de categorias elegíveis, após excluir os atribuídos a N3. Vínculo atual a N1 não comprova o grupo que historicamente realizou a solução. '
            . self::denominatorNote($metrics['INS6'] ?? []) . self::exclusionNote($metrics['INS6'] ?? [])
            . (!$currentRule ? ' Extração anterior ao novo critério: gere novamente os dados.' : ''));

        $talk = [0, 0, 0];
        $wait = [0, 0, 0];
        $abandon = [0, 0, 0, 0];
        foreach ($calls as $call) {
            $seconds = self::seconds($call['talk_seconds'] ?? null);
            $talk[!empty($call['ins7']) ? 0 : (self::hasDate($call['completed_at'] ?? null) && $seconds !== null && $seconds > 600 ? 1 : 2)]++;
            $seconds = self::seconds($call['wait_seconds'] ?? null);
            $wait[!empty($call['ins8']) ? 0 : (self::hasDate($call['connected_at'] ?? null) && $seconds !== null && $seconds > 30 ? 1 : 2)]++;
            $seconds = self::seconds($call['abandon_wait_seconds'] ?? null);
            $type = $call['type'] ?? '';
            $abandon[!empty($call['ins9']) ? 0 : ($type === 'Abandonada' && $seconds !== null && $seconds <= 30 ? 1 : ($type === 'Atendida' ? 2 : 3))]++;
        }
        $result['INS7'] = self::counts('INS7', 'INS7 — Duração das ligações',
            ['Concluídas até 600 s', 'Concluídas acima de 600 s', 'Demais ligações'], $talk, count($calls) > 0,
            'Quantidades; duração é tempo de conversação. Demais ligações incluem abandonos, atendimento sem conclusão e duração inválida. '
            . self::denominatorNote($metrics['INS7'] ?? []) . ' Todas as ligações consideradas permanecem na base de cálculo.');
        $result['INS8'] = self::counts('INS8', 'INS8 — Espera até conectar ao agente',
            ['Conectadas até 30 s', 'Conectadas acima de 30 s', 'Demais ligações'], $wait, count($calls) > 0,
            'Quantidades; espera é tempo na fila antes do CONNECT. Demais ligações incluem abandonos, ausência de conexão e espera inválida. '
            . self::denominatorNote($metrics['INS8'] ?? []) . ' Todas as ligações consideradas permanecem na base de cálculo.');
        $result['INS9'] = self::counts('INS9', 'INS9 — Abandono total e limite de 30 s',
            ['Abandono acima de 30 s', 'Abandono até 30 s', 'Atendidas', 'Demais ligações'], $abandon, count($calls) > 0,
            'Quantidades; somente abandono estritamente acima de 30 segundos conta como abandono no INS9. Demais ligações incluem abandono sem espera válida e desfecho desconhecido. '
            . self::denominatorNote($metrics['INS9'] ?? []));

        $m = $metrics['INS10'] ?? [];
        $staff = $snapshot['staff_register'] ?? [];
        $staffCounts = array_map(function ($key) use ($staff) { return (int)($staff[$key] ?? 0); },
            ['active_total', 'replacements', 'reductions', 'other_departures', 'pending_departures']);
        $result['INS10'] = self::counts('INS10', 'INS10 — Equipe e movimentações',
            ['Efetivo no fim do mês', 'Substituições no trimestre', 'Saídas por redução de quadro', 'Outras saídas', 'Saídas a confirmar'],
            $staffCounts, !empty($staff['configured']),
            'Quantidades do cadastro de profissionais. O efetivo corresponde ao último dia do mês; as saídas correspondem à janela de três meses de '
            . ($staff['window_start'] ?? 'data não informada') . ' a ' . ($staff['window_end'] ?? 'data não informada') . '. '
            . 'As barras mostram medidas diferentes e não formam partes de um mesmo total. Somente substituições confirmadas integram o cálculo da rotatividade. '
            . (!self::metricAvailable($m) ? 'O percentual oficial ainda não está disponível; o gráfico apresenta apenas as quantidades cadastradas, quando existentes.'
                : 'O percentual oficial é apresentado na tabela do indicador.'));

        $m = $metrics['INS11'] ?? [];
        $num = (int)($m['numerator'] ?? 0);
        $den = (int)($m['denominator'] ?? 0);
        $proxy = ($input['kb_mode'] ?? '') === 'category_proxy';
        $result['INS11'] = self::counts('INS11', 'INS11 — Evidência de base de conhecimento',
            [$proxy ? 'Categoria com vínculo BC' : 'Com artigo validado', 'Demais chamados'], [$num, max(0, $den - $num)], self::metricAvailable($m),
            'Quantidades. ' . ($proxy ? 'PROXY PROVISÓRIO: vínculo da categoria à categoria de conhecimento não comprova artigo validado no chamado. '
                : 'Conta chamados com vínculo direto a artigo da lista validada. ')
            . self::denominatorNote($m) . (!self::metricAvailable($m) ? ' Evidência pendente ou sem população; não representada como zero.' : ''));

        $ratings = [0, 0, 0, 0, 0];
        $m = $metrics['INS12'] ?? [];
        $ratingEvidence = array_fill_keys(array_map('strval', $m['denominator_ids'] ?? []), true);
        foreach ($tickets as $ticket) {
            $rating = $ticket['satisfaction'] ?? null;
            if (isset($ratingEvidence[(string)$ticket['id']]) && is_numeric($rating) && in_array((float)$rating, [1.0, 2.0, 3.0, 4.0, 5.0], true)) {
                $ratings[(int)$rating - 1]++;
            }
        }
        foreach ($calls as $call) {
            $key = (string)($call['call_key'] ?? ($call['id'] . '|' . $call['queue']));
            $rating = $call['ins12_score'] ?? null;
            if (isset($ratingEvidence[$key]) && is_numeric($rating) && in_array((float)$rating, [1.0, 2.0, 3.0, 4.0, 5.0], true)) {
                $ratings[(int)$rating - 1]++;
            }
        }
        $includePhone = ($input['ins12_mode'] ?? 'glpi_and_phone') === 'glpi_and_phone';
        $result['INS12'] = self::counts('INS12', 'INS12 — Distribuição das avaliações',
            ['Nota 1', 'Nota 2', 'Nota 3', 'Nota 4', 'Nota 5'], $ratings, self::metricAvailable($m),
            ($includePhone
                ? 'Respostas válidas do GLPI e da telefonia, somadas por resposta; cada ligação é contada uma vez. A nota telefônica é normalizada por 6 − nota original. '
                : 'Somente respostas válidas do GLPI; a pesquisa telefônica está excluída por opção desta extração. ')
            . 'Escala apresentada: 1–5; notas 4 e 5 são favoráveis. ' . self::denominatorNote($m)
            . (!self::metricAvailable($m) ? ' Fontes incompletas ou ausência de respostas válidas: não há distribuição oficial a apresentar.' : ''));

        $types = [0, 0, 0];
        foreach ($tickets as $ticket) {
            $type = (int)($ticket['type'] ?? 0);
            $types[$type === 2 ? 0 : ($type === 1 ? 1 : 2)]++;
        }
        $categories = ['Requisições', 'Incidentes'];
        if ($types[2] > 0) {
            $categories[] = 'Outros tipos';
        } else {
            array_pop($types);
        }
        $result['tickets_types'] = self::counts('tickets_types', 'Chamados solucionados por tipo', $categories, $types, count($tickets) > 0,
            'Quantidades de chamados selecionados pela data de solução, inclusive os abertos antes do mês.');
        $result['calls_daily'] = self::dailyCalls($snapshot, $calls);
        $result['tickets_daily'] = self::dailyTickets($snapshot, $tickets);
        foreach (['INS5', 'INS6', 'INS9', 'INS11'] as $id) {
            $result[$id]['kind'] = 'doughnut';
            $result[$id]['note'] .= ' Percentuais das fatias representam a composição destas contagens; o percentual oficial do indicador é informado na tabela.';
        }
        foreach (['INS7', 'INS8', 'INS12'] as $id) {
            $result[$id]['kind'] = 'column';
        }
        $result['tickets_types']['kind'] = 'pie';
        $result['tickets_types']['note'] .= ' Percentuais das fatias representam a participação de cada tipo no total de chamados.';
        foreach (['INS1', 'INS2', 'INS3', 'INS4', 'INS7', 'INS8'] as $id) {
            $result[$id]['point_colors'] = [ReportStyle::BLUE, ReportStyle::YELLOW, ReportStyle::LIGHT_GRAY];
        }
        $result['INS5']['point_colors'] = [ReportStyle::YELLOW, ReportStyle::BLUE];
        $result['INS6']['point_colors'] = [ReportStyle::BLUE, ReportStyle::YELLOW, ReportStyle::LIGHT_GRAY];
        $result['INS9']['point_colors'] = [ReportStyle::YELLOW, ReportStyle::YELLOW_DARK, ReportStyle::BLUE, ReportStyle::LIGHT_GRAY];
        $result['INS10']['point_colors'] = [ReportStyle::BLUE, ReportStyle::YELLOW, ReportStyle::LIGHT_GRAY, ReportStyle::BLUE_DARK, ReportStyle::YELLOW_DARK];
        $result['INS11']['point_colors'] = [ReportStyle::BLUE, ReportStyle::YELLOW];
        $result['INS12']['point_colors'] = [ReportStyle::YELLOW_DARK, ReportStyle::YELLOW, ReportStyle::LIGHT_GRAY, ReportStyle::BLUE, ReportStyle::BLUE_DARK];
        $result['tickets_types']['point_colors'] = array_slice([ReportStyle::BLUE, ReportStyle::YELLOW, ReportStyle::LIGHT_GRAY], 0, count($categories));
        return $result;
    }

    private static function counts(string $id, string $title, array $categories, array $values, bool $available, string $note): array
    {
        return ['id' => $id, 'title' => $title, 'categories' => $categories,
            'series' => [['name' => 'Quantidade', 'values' => $available ? $values : array_fill(0, count($categories), null), 'color' => ReportStyle::BLUE]],
            'kind' => 'bar', 'stacked' => false, 'unit' => 'count', 'available' => $available, 'note' => $note];
    }

    private static function dailyCalls(array $snapshot, array $calls): array
    {
        $month = $snapshot['period']['month'] ?? '';
        $days = [];
        $series = [
            ['name' => 'Atendidas', 'values' => [], 'color' => ReportStyle::BLUE],
            ['name' => 'Abandonadas', 'values' => [], 'color' => ReportStyle::YELLOW],
            ['name' => 'Sem desfecho', 'values' => [], 'color' => ReportStyle::LIGHT_GRAY],
        ];
        $validMonth = is_string($month) && preg_match('/^(20\d{2}|2100)-(0[1-9]|1[0-2])$/D', $month);
        if ($validMonth) {
            $first = new \DateTimeImmutable($month . '-01', new \DateTimeZone('America/Sao_Paulo'));
            $numberOfDays = (int)$first->format('t');
            for ($day = 1; $day <= $numberOfDays; $day++) {
                $days[] = sprintf('%02d', $day);
            }
            foreach ($series as &$row) {
                $row['values'] = array_fill(0, $numberOfDays, 0);
            }
            unset($row);
            foreach ($calls as $call) {
                $entry = (string)($call['entered_at'] ?? '');
                if (substr($entry, 0, 7) !== $month || !self::hasDate($entry)) {
                    continue;
                }
                $day = (int)substr($entry, 8, 2);
                $type = $call['type'] ?? '';
                $series[$type === 'Atendida' ? 0 : ($type === 'Abandonada' ? 1 : 2)]['values'][$day - 1]++;
            }
        }
        $available = $validMonth && count($calls) > 0;
        if (!$available) {
            foreach ($series as &$row) {
                $row['values'] = array_fill(0, count($days), null);
            }
            unset($row);
        }
        return ['id' => 'calls_daily', 'title' => 'Ligações recebidas por dia', 'categories' => $days, 'series' => $series,
            'kind' => 'column', 'stacked' => true, 'unit' => 'count', 'available' => (bool)$available,
            'note' => 'Quantidades por dia de entrada na fila, após exclusões de números de teste; inclui dias sem chamadas. Desfechos posteriores ao fim do mês permanecem associados ao dia de entrada.'];
    }

    private static function dailyTickets(array $snapshot, array $tickets): array
    {
        $month = $snapshot['period']['month'] ?? '';
        $numberOfDays = HeatmapData::daysInMonth($month);
        $days = [];
        for ($day = 1; $day <= $numberOfDays; $day++) {
            $days[] = sprintf('%02d', $day);
        }
        $values = array_fill(0, $numberOfDays, 0);
        $total = 0;
        $omitted = 0;
        foreach ($tickets as $ticket) {
            $parts = HeatmapData::timestampParts($ticket['solved_at'] ?? null, $month);
            if ($parts === null) {
                $omitted++;
                continue;
            }
            $values[$parts['day'] - 1]++;
            $total++;
        }
        $available = $total > 0;
        return ['id' => 'tickets_daily', 'title' => 'Chamados solucionados por dia', 'categories' => $days,
            'series' => [['name' => 'Solucionados', 'values' => $available ? $values : array_fill(0, $numberOfDays, null), 'color' => ReportStyle::BLUE]],
            'kind' => 'column', 'stacked' => false, 'unit' => 'count', 'available' => $available,
            'note' => 'Quantidades por data de solução dos chamados da extração, inclusive os abertos antes do mês; inclui dias sem soluções. '
                . 'Horário local registrado (America/Sao_Paulo), sem nova conversão de fuso. Registros representados: ' . $total
                . '. Omitidos deste gráfico por data de solução ausente, inválida ou fora do mês: ' . $omitted . '.'
                . (!$available ? ' Sem datas válidas no mês para representar; ausência de dados não é zero.' : '')];
    }

    private static function metricAvailable(array $metric): bool
    {
        return isset($metric['value']) && is_numeric($metric['value']) && ($metric['denominator'] ?? 0) > 0
            && !in_array($metric['status'] ?? '', ['pending', 'not_applicable'], true);
    }

    private static function denominatorNote(array $metric): string
    {
        return array_key_exists('denominator', $metric) && $metric['denominator'] !== null
            ? 'Registros considerados no cálculo: ' . (int)$metric['denominator'] . '.'
            : 'Quantidade de registros para o cálculo ainda não disponível.';
    }

    private static function exclusionNote(array $metric): string
    {
        return array_key_exists('excluded_count', $metric)
            ? ' Excluídos deste indicador por atribuição a N3: ' . (int)$metric['excluded_count'] . '.' : '';
    }

    private static function seconds($value)
    {
        return (is_int($value) || is_float($value) || is_string($value)) && is_numeric($value)
            && is_finite((float)$value) && (float)$value >= 0 ? (float)$value : null;
    }

    private static function hasDate($value): bool
    {
        if (!is_string($value) || $value === '' || strpos($value, '0000-00-00') === 0) {
            return false;
        }
        try {
            new \DateTimeImmutable($value, new \DateTimeZone('America/Sao_Paulo'));
            $errors = \DateTimeImmutable::getLastErrors();
            return !is_array($errors) || (!$errors['warning_count'] && !$errors['error_count']);
        } catch (\Exception $e) {
            return false;
        }
    }
}
