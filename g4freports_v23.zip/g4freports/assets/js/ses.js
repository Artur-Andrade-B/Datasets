(function () {
  'use strict';
  var config = window.G4FREPORTS_SES || {};
  var root = document.getElementById('g4fr-ses');
  if (!root || root.dataset.initialized) return;
  root.dataset.initialized = '1';
  var form = document.getElementById('g4fr-ses-form');
  var state = { snapshot: null, token: '', busy: false, dataDirty: false, manualDirty: false, testsDirty: false, staffDirty: false, source: 'tickets', page: 0 };
  var testNumbers = (config.test_numbers || []).map(function (row) { return { number: String(row.number || ''), label: String(row.label || ''), active: row.active === true || row.active === 1 || row.active === '1' }; });
  var staffRows = (config.staff_rows || []).map(function (row) { return Object.assign({}, row); });
  var pageSize = 25;
  var statusNames = { met: 'Meta atendida', unmet: 'Fora da meta', not_applicable: 'Não aplicável', pending: 'Pendente', provisional: 'Provisório' };
  var numberFormat = new Intl.NumberFormat('pt-BR');
  var percentFormat = new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  function el(id) { return document.getElementById(id); }
  function node(tag, className, text) { var element = document.createElement(tag); if (className) element.className = className; if (text !== undefined) element.textContent = String(text); return element; }
  function clear(element) { while (element.firstChild) element.removeChild(element.firstChild); }
  function number(value) { return value === null || value === undefined || value === '' ? '—' : numberFormat.format(Number(value)); }
  function seconds(value) { if (value === null || value === undefined || value === '') return '—'; var n = Math.max(0, Math.round(Number(value))); return String(Math.floor(n / 3600)).padStart(2, '0') + ':' + String(Math.floor((n % 3600) / 60)).padStart(2, '0') + ':' + String(n % 60).padStart(2, '0'); }
  function bool(value) { return value === null || value === undefined ? '—' : (value ? 'Sim' : 'Não'); }
  function status(message, kind, loading) { var target = el('ses-status'); clear(target); target.className = 'g4fr-ses-notice' + (kind ? ' ' + kind : ''); if (loading) target.appendChild(node('span', 'g4fr-ses-loading')); target.appendChild(document.createTextNode(message)); target.hidden = false; }
  function updateControls() {
    var ready = !!state.snapshot && !!state.token && !state.busy && !state.dataDirty && !state.manualDirty && !state.testsDirty && !state.staffDirty;
    el('ses-generate').disabled = state.busy || !config.connections_ready || state.testsDirty || state.staffDirty;
    el('ses-generate').textContent = state.busy ? 'Aguarde…' : 'Gerar relatório mensal';
    el('ses-export-docx').disabled = !ready;
    el('ses-export-xlsx').disabled = !ready;
    el('ses-save-manual').disabled = !state.snapshot || !state.manualDirty || state.dataDirty || state.busy || state.testsDirty || state.staffDirty;
    Array.prototype.forEach.call(form.querySelectorAll('input,select,textarea'), function (input) { input.disabled = state.busy; });
    ['g4fr-ses-tests-form', 'g4fr-ses-staff-form'].forEach(function (id) { var registerForm = el(id); if (registerForm) Array.prototype.forEach.call(registerForm.querySelectorAll('input:not([type="hidden"]),select,button'), function (input) { input.disabled = state.busy; }); });
    var message = 'Gere o relatório para revisar os indicadores e exportar.';
    if (!config.connections_ready) message = 'As duas conexões de banco devem estar configuradas e habilitadas.';
    else if (state.testsDirty || state.staffDirty) message = 'Salve as alterações nos cadastros de números de teste e profissionais antes de gerar ou exportar.';
    else if (state.dataDirty && state.snapshot) message = 'Os critérios mudaram. Gere novamente para atualizar os indicadores.';
    else if (state.manualDirty && state.snapshot) message = 'Atualize os textos para incluí-los nos arquivos exportados.';
    else if (ready) message = 'Word e Excel usarão os mesmos dados e critérios desta prévia.';
    if (state.busy) message = 'Processando o relatório. Aguarde o término desta operação.';
    el('ses-draft-state').textContent = message;
  }
  function ids(name) {
    var raw = String(form.elements[name].value || '').trim();
    if (!raw) return [];
    if (!/^[\d\s,;]+$/.test(raw)) throw new Error('Informe somente IDs numéricos separados por vírgula em "' + (form.elements[name].labels[0].textContent || name) + '".');
    var result = [];
    raw.split(/[\s,;]+/).filter(Boolean).forEach(function (part) { var id = Number(part); if (!Number.isSafeInteger(id) || id < 1) throw new Error('Os IDs devem ser números inteiros maiores que zero.'); if (result.indexOf(id) < 0) result.push(id); });
    return result;
  }
  function manualInput() { var input = {}; ['report_title', 'executive_summary', 'actions', 'notes', 'phone_survey_actions'].forEach(function (name) { input[name] = String(form.elements[name].value || '').trim(); var max = name === 'report_title' ? 180 : 20000; if (new TextEncoder().encode(input[name]).length > max) throw new Error('Reduza o texto de "' + form.elements[name].labels[0].textContent + '" para caber no limite do relatório.'); }); return input; }
  function collectInput() {
    var input = manualInput();
    input.month = form.elements.month.value;
    input.entity_id = Number(form.elements.entity_id.value);
    input.queue_filter = form.elements.queue_filter.value.trim();
    if (new TextEncoder().encode(input.queue_filter).length > 100) throw new Error('Reduza o identificador da fila de telefonia.');
    input.priority_map = form.elements.priority_preset.value === 'contract' ? { INS1: 5, INS2: 4, INS3: 3, INS4: 2 } : { INS1: 2, INS2: 3, INS3: 4, INS4: 5 };
    ['group_ids', 'n1_categories', 'n1_group_ids', 'n2_group_ids', 'n3_group_ids', 'validated_kb_ids', 'incomplete_ticket_ids'].forEach(function (name) { input[name] = ids(name); });
    input.ins6_mode = 'assigned_n1';
    input.ins12_mode = form.elements.ins12_mode.value;
    input.kb_mode = form.elements.kb_mode.value;
    return input;
  }
  async function request(action, payload) {
    var serialized = JSON.stringify(payload);
    if (encodeURIComponent(JSON.stringify(Object.assign({}, payload, { _ses_nonce: config.nonce }))).length > 1800) {
      var bytes = new TextEncoder().encode(serialized);
      if (bytes.length > 128000) throw new Error('Os critérios e textos excedem o limite de 128 KB do relatório. Reduza os textos e tente novamente.');
      var totalChunks = Math.ceil(bytes.length / 1024);
      var upload = await sendRequest('input_start', { size_bytes: bytes.length, total_chunks: totalChunks });
      if (!upload.upload_token) throw new Error('Não foi possível preparar o envio dos textos.');
      for (var index = 0; index < totalChunks; index++) {
        var part = bytes.subarray(index * 1024, (index + 1) * 1024);
        var binary = ''; for (var byte = 0; byte < part.length; byte++) binary += String.fromCharCode(part[byte]);
        await sendRequest('input_chunk', { upload_token: upload.upload_token, index: index, data: btoa(binary) });
      }
      var staged = await sendRequest('input_finish', { upload_token: upload.upload_token });
      if (!staged.input_token) throw new Error('O envio dos textos não foi concluído.');
      return sendRequest(action, { input_token: staged.input_token });
    }
    return sendRequest(action, payload);
  }
  async function sendRequest(action, payload) {
    var url = new URL(config.api_url, window.location.href);
    var requestPayload = Object.assign({}, payload, { _ses_nonce: config.nonce });
    url.searchParams.set('action', action);
    url.searchParams.set('payload', JSON.stringify(requestPayload));
    var controller = new AbortController();
    var timer = setTimeout(function () { controller.abort(); }, 90000);
    try {
      var response = await fetch(url.toString(), { method: 'GET', credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' }, signal: controller.signal });
      var text = await response.text();
      var result;
      try { result = JSON.parse(text); } catch (error) { throw new Error(response.status === 414 ? 'O texto excedeu o limite aceito pelo servidor. Reduza os textos e tente novamente.' : 'O servidor não retornou o resultado do relatório (HTTP ' + response.status + '). Verifique a sessão do GLPI e tente novamente.'); }
      if (!response.ok || !result.ok) throw new Error(typeof result.error === 'string' ? result.error : (result.message || 'Não foi possível concluir a operação.'));
      return result;
    } catch (error) {
      if (error.name === 'AbortError') throw new Error('O servidor não concluiu o relatório em 90 segundos. Verifique o acesso e os tempos de consulta das duas conexões.');
      throw error;
    } finally { clearTimeout(timer); }
  }
  function acceptSnapshot(result) {
    if (!result.snapshot || !result.token) throw new Error('O servidor retornou um rascunho incompleto. Gere novamente antes de exportar.');
    state.snapshot = result.snapshot; state.token = result.token; state.dataDirty = false; state.manualDirty = false; state.page = 0;
    renderSnapshot();
  }
  form.addEventListener('submit', async function (event) {
    event.preventDefault();
    if (state.busy || state.testsDirty || state.staffDirty || !form.reportValidity()) return;
    if (!config.connections_ready) { status('Configure e habilite as conexões GLPI e telefonia antes de gerar.', 'error'); return; }
    var input;
    try { input = collectInput(); } catch (error) { status(error.message, 'error'); return; }
    state.busy = true; updateControls();
    status('Consultando os chamados e as ligações do mês e calculando os indicadores…', '', true);
    try { acceptSnapshot(await request('generate', input)); status('Relatório gerado. Revise os indicadores e exporte os arquivos.', 'success'); }
    catch (error) { status(error.message || 'Não foi possível gerar o relatório.', 'error'); }
    finally { state.busy = false; updateControls(); }
  });
  form.addEventListener('input', function (event) { if (event.target.dataset.manual) state.manualDirty = true; else state.dataDirty = true; updateControls(); });
  form.addEventListener('change', function (event) {
    if (event.target.dataset.manual) state.manualDirty = true; else state.dataDirty = true;
    if (event.target.name === 'priority_preset') el('ses-priority-description').textContent = event.target.value === 'contract' ? 'Códigos GLPI: INS1 = 5; INS2 = 4; INS3 = 3; INS4 = 2. O prazo continua sendo o registrado no chamado.' : 'Códigos GLPI: INS1 = 2; INS2 = 3; INS3 = 4; INS4 = 5. Esta associação será informada no relatório.';
    updateControls();
  });
  el('ses-save-manual').addEventListener('click', async function () {
    if (state.busy || !state.snapshot || state.dataDirty || state.testsDirty || state.staffDirty) return;
    var input;
    try { input = manualInput(); } catch (error) { status(error.message, 'error'); return; }
    input.token = state.token;
    state.busy = true; updateControls(); status('Atualizando os textos no rascunho…', '', true);
    try { acceptSnapshot(await request('update_manual', input)); status('Textos atualizados. Os dois arquivos usarão esta versão do relatório.', 'success'); }
    catch (error) { status(error.message, 'error'); }
    finally { state.busy = false; updateControls(); }
  });

  async function exportReport(format) {
    if (!state.snapshot || !state.token || state.busy || state.dataDirty || state.manualDirty || state.testsDirty || state.staffDirty) return;
    state.busy = true; updateControls(); status('Preparando o arquivo ' + (format === 'docx' ? 'Word' : 'Excel') + '…', '', true);
    try {
      var url = new URL(config.export_url, window.location.href); url.searchParams.set('token', state.token); url.searchParams.set('format', format); url.searchParams.set('_ses_nonce', config.nonce);
      var response = await fetch(url.toString(), { method: 'GET', credentials: 'same-origin', cache: 'no-store' });
      var contentType = response.headers.get('Content-Type') || '';
      if (!response.ok || /json|text\/html/i.test(contentType)) { var failure = await response.text(); try { var parsed = JSON.parse(failure); throw new Error(parsed.error || parsed.message || 'Não foi possível exportar.'); } catch (error) { if (error.name !== 'SyntaxError') throw error; throw new Error('O servidor não concluiu a exportação (HTTP ' + response.status + '). Gere novamente se a sessão expirou.'); } }
      var blob = await response.blob();
      if (!blob.size) throw new Error('O arquivo retornado está vazio.');
      var objectUrl = URL.createObjectURL(blob); var link = node('a'); link.href = objectUrl; link.download = 'Relatorio_Mensal_SES_' + String(state.snapshot.period.month || '').replace(/[^\d-]/g, '') + '.' + format; document.body.appendChild(link); link.click(); link.remove(); setTimeout(function () { URL.revokeObjectURL(objectUrl); }, 60000);
      status('Arquivo ' + (format === 'docx' ? 'Word' : 'Excel') + ' preparado para download.', 'success');
    } catch (error) { status(error.message || 'Não foi possível exportar o relatório.', 'error'); }
    finally { state.busy = false; updateControls(); }
  }
  el('ses-export-docx').addEventListener('click', function () { exportReport('docx'); });
  el('ses-export-xlsx').addEventListener('click', function () { exportReport('xlsx'); });

  function renderSelections(snapshot) {
    var target = el('ses-selections');
    if (!target) return;
    clear(target);
    var input = snapshot.input || {}, catalog = snapshot.selection_catalog || {};
    function name(kind, id) { return String(((catalog[kind] || {})[id] || {}).name || 'Nome não registrado nesta extração'); }
    function labels(kind, ids, empty) { return ids.length ? ids.map(function (id) { return id + ' — ' + name(kind, id); }).join('; ') : empty; }
    target.appendChild(node('p', 'g4fr-ses-method', 'Grupos N1 usados no INS6: ' + labels('groups', input.n1_group_ids || [], 'Não informado')));
    target.appendChild(node('p', 'g4fr-ses-method', 'INS4 · N1 e N2: ' + labels('groups', (input.n1_group_ids || []).concat(input.n2_group_ids || []), 'Não informado') + '. Sem vínculo N3; não exige categoria elegível N1.'));
    target.appendChild(node('p', 'g4fr-ses-method', 'Grupos N3 excluídos de INS3, INS4 e INS6: ' + labels('groups', input.n3_group_ids || [], 'Não informado')));
    target.appendChild(node('p', 'g4fr-ses-method', 'Fontes INS12: ' + (input.ins12_mode === 'glpi_only' ? 'Somente chamados GLPI' : 'Chamados GLPI e pesquisas de telefonia')));
    target.appendChild(node('p', 'g4fr-ses-help', 'INS11: ' + (input.kb_mode === 'category_proxy' ? 'Associação por categoria — apuração provisória. A lista de artigos não participa deste modo.' : 'Vínculo direto a artigo previamente validado. Sem a lista validada, a apuração fica pendente.')));
    var details = node('details', 'g4fr-ses-details');
    details.appendChild(node('summary', '', 'IDs e nomes usados nesta extração'));
    var wrap = node('div', 'g4fr-ses-table-wrap'), table = node('table', 'g4fr-ses-table');
    var head = node('thead'), header = node('tr');
    ['Seleção', 'ID', 'Nome na base GLPI do relatório'].forEach(function (label) { var th = node('th', '', label); th.scope = 'col'; header.appendChild(th); });
    head.appendChild(header); table.appendChild(head);
    var body = node('tbody');
    [['groups', 'group_ids', 'Filtro geral de grupos'], ['groups', 'n1_group_ids', 'Grupo N1'], ['groups', 'n2_group_ids', 'Grupo N2 · INS4'], ['groups', 'n3_group_ids', 'Grupo N3 excluído de INS3/4/6'], ['categories', 'n1_categories', 'Categoria elegível N1'], ['articles', 'validated_kb_ids', 'Artigo validado informado']].forEach(function (selection) {
      (input[selection[1]] || []).forEach(function (id) {
        var row = node('tr');
        [selection[2], id, name(selection[0], id)].forEach(function (value) { row.appendChild(node('td', '', value)); });
        body.appendChild(row);
      });
    });
    table.appendChild(body); wrap.appendChild(table); details.appendChild(wrap); target.appendChild(details);
  }

  function renderSnapshot() {
    var snapshot = state.snapshot;
    el('ses-preview').hidden = false;
    el('ses-preview-title').textContent = 'Prévia · ' + ((snapshot.period || {}).label || (snapshot.period || {}).month || 'Relatório mensal');
    el('ses-generated-at').textContent = 'Extraído em ' + String(snapshot.generated_at || '').replace('T', ' ') + ' · ' + String(snapshot.rules_version || '');
    var totals = el('ses-totals'); clear(totals);
    var countItems = [['tickets', 'Chamados solucionados'], ['requests', 'Requisições'], ['incidents', 'Incidentes'], ['calls_received', 'Ligações consideradas'], ['calls_answered', 'Ligações atendidas'], ['calls_abandoned', 'Ligações abandonadas · total']];
    [['calls_abandoned_over_30', 'Abandonadas após 30 s · INS9'], ['calls_abandoned_up_to_30', 'Abandonadas em até 30 s'], ['calls_abandoned_unknown_wait', 'Abandonadas sem espera válida']].forEach(function (item) {
      if (Object.prototype.hasOwnProperty.call(snapshot.totals || {}, item[0])) countItems.push(item);
    });
    countItems.push(['calls_excluded', 'Ligações de teste excluídas'], ['missing_deadline', 'Chamados sem prazo registrado']);
    countItems.forEach(function (item) { var tile = node('div', 'g4fr-ses-total'); tile.appendChild(node('strong', '', number((snapshot.totals || {})[item[0]]))); tile.appendChild(node('span', '', item[1])); totals.appendChild(tile); });
    [['mean_talk_seconds', 'Duração média das atendidas'], ['mean_wait_seconds', 'Espera média antes de atender']].forEach(function (item) { var tile = node('div', 'g4fr-ses-total'); tile.appendChild(node('strong', '', seconds((snapshot.totals || {})[item[0]]))); tile.appendChild(node('span', '', item[1])); totals.appendChild(tile); });
    renderSelections(snapshot);
    var warnings = el('ses-warnings'); clear(warnings);
    (snapshot.warnings || []).forEach(function (warning) { warnings.appendChild(node('p', 'g4fr-ses-notice', warning)); });
    var metrics = el('ses-metrics'); clear(metrics);
    (snapshot.metrics || []).forEach(function (metric) {
      var safeStatus = Object.prototype.hasOwnProperty.call(statusNames, metric.status) ? metric.status : 'pending';
      var card = node('article', 'g4fr-ses-metric ' + safeStatus);
      var top = node('div', 'g4fr-ses-metric-top'); top.appendChild(node('strong', '', metric.id)); top.appendChild(node('span', 'g4fr-ses-badge', statusNames[safeStatus])); card.appendChild(top);
      card.appendChild(node('h3', '', metric.label));
      card.appendChild(node('div', 'g4fr-ses-metric-value', metric.value === null || metric.value === undefined ? '—' : percentFormat.format(metric.value) + '%'));
      card.appendChild(node('span', 'g4fr-ses-help', 'Meta: ' + (metric.direction === 'lte' ? '≤ ' : '≥ ') + number(metric.target) + '%'));
      var metricLabels = (config.metric_labels || {})[metric.id] || {};
      card.appendChild(node('span', 'g4fr-ses-help', (metric.numerator_label || metricLabels.numerator || 'Registros que atendem ao critério') + ': ' + number(metric.numerator)));
      card.appendChild(node('span', 'g4fr-ses-help', (metric.denominator_label || metricLabels.denominator || 'Registros avaliados') + ': ' + number(metric.denominator)));
      if (metric.id === 'INS12' && metric.source_counts) {
        [['tickets', 'GLPI'], ['phone', 'Telefonia']].forEach(function (item) {
          var source = metric.source_counts[item[0]];
          card.appendChild(node('p', 'g4fr-ses-help', item[1] + ': ' + (source.available ? number(source.numerator) + ' favoráveis / ' + number(source.denominator) + ' válidas' : 'Fonte indisponível') + (source.included ? ' · Incluída' : ' · Excluída por seleção')));
        });
      }
      var details = node('details'); details.appendChild(node('summary', '', 'Como foi calculado')); details.appendChild(node('p', '', metric.method || '')); if (metric.note) details.appendChild(node('p', '', metric.note)); card.appendChild(details); metrics.appendChild(card);
    });
    var phone = el('ses-phone-survey'); clear(phone);
    if (snapshot.phone_survey) {
      var survey = snapshot.phone_survey;
      phone.appendChild(node('h3', '', 'INS12 · Pesquisas de telefonia'));
      phone.appendChild(node('p', 'g4fr-ses-method', survey.status));
      phone.appendChild(node('p', '', 'Ligações únicas consideradas: ' + number(survey.unique_calls) + ' · Respostas vinculadas: ' + number(survey.responses) + ' · Notas válidas (1–5): ' + number(survey.valid_responses) + ' · Favoráveis (4–5 convertidas): ' + number(survey.favorable_responses) + ' · Fora da faixa: ' + number(survey.invalid_responses) + ' · Sem resposta: ' + number(survey.without_response)));
      var phoneDetails = node('details', 'g4fr-ses-details');
      phoneDetails.appendChild(node('summary', '', 'Participação no INS12 e acompanhamento'));
      phoneDetails.appendChild(node('p', '', survey.explanation));
      String(survey.actions || '').split('\n').forEach(function (line) { phoneDetails.appendChild(node('p', '', line)); });
      phone.appendChild(phoneDetails);
    }
    var notes = el('ses-rule-notes'); clear(notes);
    (snapshot.rule_notes || []).forEach(function (note) { notes.appendChild(node('div', 'g4fr-ses-rule', note)); });
    renderTable();
  }
  var ticketColumns = [
    ['ID', function (r) { return r.id; }], ['Título', function (r) { return r.title; }], ['Categoria', function (r) { return r.category; }], ['Grupos', function (r) { return r.groups; }], ['Solução', function (r) { return r.solved_at; }], ['Prioridade', function (r) { return r.priority; }], ['Prazo registrado', function (r) { return r.deadline; }], ['No prazo', function (r) { return bool(r.within_sla); }], ['Tempo de solução', function (r) { return seconds(r.solve_seconds); }], ['Reaberto', function (r) { return bool(r.reopened); }], ['Categoria elegível N1', function (r) { return bool(r.n1_eligible); }], ['Vínculo N3', function (r) { return bool(r.assigned_n3); }], ['Elegível INS6 após exclusões', function (r) { return bool(r.ins6_eligible); }], ['Artigo validado', function (r) { return bool(r.kb_validated); }]
  ];
  var callColumns = [
    ['ID da ligação', function (r) { return r.id; }], ['Entrada na fila', function (r) { return r.entered_at; }], ['Origem', function (r) { return r.caller; }], ['Fila', function (r) { return r.queue; }], ['Tipo', function (r) { return r.type; }], ['Tempo de atendimento', function (r) { return seconds(r.talk_seconds); }], ['Espera antes de atender', function (r) { return seconds(r.wait_seconds); }], ['Espera até abandonar', function (r) { return seconds(r.abandon_wait_seconds); }], ['Encerramento', function (r) { return r.termination; }], ['Pesquisa: nota original', function (r) { return r.satisfaction_raw; }], ['Pesquisa: nota convertida', function (r) { return r.satisfaction; }], ['Data da pesquisa', function (r) { return r.survey_at; }], ['Nota para INS12', function (r) { return r.ins12_score; }], ['Resposta incluída no INS12', function (r) { return bool(r.ins12_eligible); }]
  ];
  function renderTable() {
    if (!state.snapshot) return;
    var rows = state.snapshot[state.source] || [];
    var maxPage = Math.max(0, Math.ceil(rows.length / pageSize) - 1); state.page = Math.min(maxPage, Math.max(0, state.page));
    var columns = state.source === 'tickets' ? ticketColumns : callColumns;
    var container = el('ses-source-table'); clear(container);
    if (!rows.length) container.appendChild(node('p', 'g4fr-ses-help', 'Nenhum registro nesta tabela.'));
    else {
      var table = node('table', 'g4fr-ses-table'); var head = node('thead'); var headRow = node('tr'); columns.forEach(function (column) { var cell = node('th', '', column[0]); cell.scope = 'col'; headRow.appendChild(cell); }); head.appendChild(headRow); table.appendChild(head);
      var body = node('tbody'); rows.slice(state.page * pageSize, (state.page + 1) * pageSize).forEach(function (row) { var tr = node('tr'); columns.forEach(function (column) { var value = column[1](row); tr.appendChild(node('td', '', value === null || value === undefined || value === '' ? '—' : value)); }); body.appendChild(tr); }); table.appendChild(body); container.appendChild(table);
    }
    el('ses-page-info').textContent = rows.length ? number(state.page * pageSize + 1) + '–' + number(Math.min((state.page + 1) * pageSize, rows.length)) + ' de ' + number(rows.length) : '0 registros';
    el('ses-page-prev').disabled = state.page === 0; el('ses-page-next').disabled = state.page >= maxPage;
  }
  el('ses-page-prev').addEventListener('click', function () { state.page--; renderTable(); });
  el('ses-page-next').addEventListener('click', function () { state.page++; renderTable(); });
  el('ses-source-tabs').addEventListener('click', function (event) { var button = event.target.closest('[data-source]'); if (!button) return; state.source = button.dataset.source; state.page = 0; Array.prototype.forEach.call(el('ses-source-tabs').querySelectorAll('[data-source]'), function (item) { item.classList.toggle('active', item === button); item.setAttribute('aria-pressed', item === button ? 'true' : 'false'); }); renderTable(); });

  function testsChanged() { state.testsDirty = true; var label = el('ses-tests-state'); if (label) label.textContent = 'Há alterações não salvas. Salve a lista antes de gerar ou exportar.'; updateControls(); }
  function renderTests() {
    var body = el('ses-tests-body'); clear(body);
    testNumbers.forEach(function (row, index) {
      var tr = node('tr'); var numberCell = node('td'); var labelCell = node('td'); var activeCell = node('td');
      if (config.can_configure) {
        var numberInput = node('input', 'form-control'); numberInput.type = 'text'; numberInput.inputMode = 'tel'; numberInput.maxLength = 40; numberInput.value = row.number; numberInput.setAttribute('aria-label', 'Número de origem ' + (index + 1)); numberInput.addEventListener('input', function () { row.number = numberInput.value; testsChanged(); }); numberCell.appendChild(numberInput);
        var labelInput = node('input', 'form-control'); labelInput.type = 'text'; labelInput.maxLength = 200; labelInput.value = row.label; labelInput.setAttribute('aria-label', 'Identificação do número ' + (index + 1)); labelInput.addEventListener('input', function () { row.label = labelInput.value; testsChanged(); }); labelCell.appendChild(labelInput);
        var checkbox = node('input'); checkbox.type = 'checkbox'; checkbox.checked = row.active; checkbox.setAttribute('aria-label', 'Excluir o número ' + (index + 1)); checkbox.addEventListener('change', function () { row.active = checkbox.checked; testsChanged(); }); activeCell.appendChild(checkbox);
        tr.appendChild(numberCell); tr.appendChild(labelCell); tr.appendChild(activeCell);
        var actionCell = node('td'); var remove = node('button', 'btn btn-outline-danger btn-sm', 'Remover'); remove.type = 'button'; remove.addEventListener('click', function () { testNumbers.splice(index, 1); testsChanged(); renderTests(); }); actionCell.appendChild(remove); tr.appendChild(actionCell);
      } else { numberCell.textContent = row.number; labelCell.textContent = row.label || '—'; activeCell.textContent = row.active ? 'Sim' : 'Não'; tr.appendChild(numberCell); tr.appendChild(labelCell); tr.appendChild(activeCell); }
      body.appendChild(tr);
    });
    el('ses-tests-empty').hidden = testNumbers.length > 0;
    el('ses-test-count').textContent = '· ' + number(testNumbers.length) + ' cadastrado(s)';
  }
  async function saveRegister(kind, rows, revision) {
    var controller = new AbortController();
    var timer = setTimeout(function () { controller.abort(); }, 30000);
    var body = new URLSearchParams();
    body.set('action', kind === 'staff' ? 'save_staff' : 'save_tests');
    body.set('_ses_nonce', config.nonce);
    body.set('_glpi_csrf_token', config.csrf_token || '');
    body.set('revision', revision || '');
    body.set('rows', JSON.stringify(rows));
    try {
      var response = await fetch(config.registers_url, { method: 'POST', body: body, credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' }, signal: controller.signal });
      var text = await response.text(), result;
      try { result = JSON.parse(text); } catch (error) { throw new Error('O GLPI não confirmou o salvamento (HTTP ' + response.status + '). Suas alterações continuam nesta tela. Verifique a sessão e tente novamente.'); }
      if (result.csrf_token) config.csrf_token = result.csrf_token;
      if (!response.ok || !result.ok) throw new Error(result.error || 'Não foi possível salvar o cadastro.');
      if (!Array.isArray(result.rows) || !result.revision) throw new Error('A confirmação do cadastro está incompleta. Tente salvar novamente.');
      return result;
    } catch (error) {
      if (error.name === 'AbortError') throw new Error('O servidor não confirmou o salvamento em 30 segundos. Recarregue esta página para conferir se a lista foi salva antes de tentar novamente.');
      throw error;
    } finally { clearTimeout(timer); }
  }
  if (config.can_configure && el('g4fr-ses-tests-form')) {
    el('ses-add-test').addEventListener('click', function () { if (testNumbers.length >= 500) { status('O cadastro aceita até 500 números.', 'error'); return; } testNumbers.push({ number: '', label: '', active: true }); testsChanged(); renderTests(); var last = el('ses-tests-body').lastElementChild; if (last) last.querySelector('input').focus(); });
    el('g4fr-ses-tests-form').addEventListener('submit', async function (event) {
      event.preventDefault();
      if (state.busy) return;
      var normalized;
      try {
        var seen = {}; normalized = testNumbers.map(function (row) { if (/[^0-9+().\-\s]/.test(row.number)) throw new Error('Use somente dígitos e formatação de telefone no número de origem.'); var digits = row.number.replace(/\D/g, ''); if (!digits || digits.length > 32) throw new Error('Preencha o número de todas as linhas com até 32 dígitos ou remova as linhas vazias.'); if (seen[digits]) throw new Error('O número ' + digits + ' está repetido na lista.'); if (new TextEncoder().encode(row.label.trim()).length > 240) throw new Error('Reduza a identificação do número ' + digits + '.'); seen[digits] = true; return { number: digits, label: row.label.trim(), active: !!row.active }; });
      } catch (error) { status(error.message, 'error'); el('ses-status').scrollIntoView({ block: 'nearest' }); return; }
      state.busy = true; updateControls(); status('Salvando os números de teste no cadastro permanente…', '', true);
      try {
        var saved = await saveRegister('tests', normalized, config.test_revision);
        testNumbers = saved.rows; config.test_revision = saved.revision;
        state.testsDirty = false; state.dataDirty = true; renderTests();
        el('ses-tests-state').textContent = 'Lista salva no plugin. Ela será carregada ao reabrir esta página e aplicada aos próximos relatórios, de qualquer mês.';
        status('Números de teste salvos e conferidos. Gere novamente para aplicar a lista ao relatório.', 'success');
      } catch (error) { state.testsDirty = true; status(error.message || 'Não foi possível salvar os números de teste.', 'error'); }
      finally { state.busy = false; updateControls(); }
    });
  }
  function staffChanged() { state.staffDirty = true; var label = el('ses-staff-state'); if (label) label.textContent = 'Há alterações não salvas na equipe. Salve o cadastro antes de gerar ou exportar.'; updateControls(); }
  function renderStaff() {
    var body = el('ses-staff-body'); clear(body);
    var reasons = { pending: 'Classificação pendente', replacement: 'Substituição', contractor_reduction: 'Redução determinada pelo contratante', other: 'Outra saída · não é substituição' };
    staffRows.forEach(function (row, index) {
      var tr = node('tr');
      if (!config.can_configure) {
        [row.name, row.profile, row.admission_date, (row.departure_date || '—') + (row.departure_date ? ' · ' + (reasons[row.departure_reason] || reasons.pending) : ''), row.monthly_value === null || row.monthly_value === undefined ? '—' : 'R$ ' + percentFormat.format(Number(row.monthly_value))].forEach(function (value) { tr.appendChild(node('td', '', value)); });
      } else {
        function field(key, type, label, required, max) {
          var td = node('td'), input = node('input', 'form-control'); input.type = type; input.value = row[key] || ''; input.required = !!required; if (max) input.maxLength = max;
          input.setAttribute('aria-label', label + ' · profissional ' + (index + 1));
          if (type === 'date') { input.min = '1900-01-01'; input.max = '2100-12-31'; }
          if (key === 'monthly_value') { input.inputMode = 'decimal'; input.placeholder = '0,00'; }
          input.addEventListener('input', function () { row[key] = input.value; staffChanged(); });
          td.appendChild(input); tr.appendChild(td); return { cell: td, input: input };
        }
        field('name', 'text', 'Nome', true, 180);
        field('profile', 'text', 'Perfil profissional', true, 240);
        field('admission_date', 'date', 'Data de admissão', true);
        var departure = field('departure_date', 'date', 'Data de saída', false);
        var reasonWrap = node('div', 'g4fr-ses-departure-reason'); reasonWrap.hidden = !row.departure_date;
        var reasonLabel = node('label', '', 'Classificação da saída'); var reason = node('select', 'form-select');
        reason.id = 'ses-staff-reason-' + index; reasonLabel.htmlFor = reason.id;
        Object.keys(reasons).forEach(function (key) { var option = node('option', '', reasons[key]); option.value = key; reason.appendChild(option); });
        reason.value = row.departure_reason || 'pending';
        reason.addEventListener('change', function () { row.departure_reason = reason.value; staffChanged(); });
        reasonWrap.appendChild(reasonLabel); reasonWrap.appendChild(reason); reasonWrap.appendChild(node('small', 'g4fr-ses-help', 'Uma saída não comprova substituição. Classifique o motivo para concluir o INS10.'));
        departure.cell.appendChild(reasonWrap);
        departure.input.addEventListener('input', function () { reasonWrap.hidden = !departure.input.value; if (!departure.input.value) { row.departure_reason = 'pending'; reason.value = 'pending'; } });
        field('monthly_value', 'text', 'Valor mensal em reais', true, 24);
        var action = node('td'), remove = node('button', 'btn btn-outline-danger btn-sm', 'Remover'); remove.type = 'button';
        remove.addEventListener('click', function () { staffRows.splice(index, 1); staffChanged(); renderStaff(); }); action.appendChild(remove); tr.appendChild(action);
      }
      body.appendChild(tr);
    });
    el('ses-staff-empty').hidden = staffRows.length > 0;
    if (el('ses-staff-count')) el('ses-staff-count').textContent = number(staffRows.length) + ' profissional(is) cadastrado(s)';
  }
  if (config.can_configure && el('g4fr-ses-staff-form')) {
    el('ses-add-staff').addEventListener('click', function () { if (staffRows.length >= 500) { status('O cadastro aceita até 500 profissionais.', 'error'); return; } staffRows.push({ id: '', name: '', profile: '', admission_date: '', departure_date: '', monthly_value: '', departure_reason: 'pending' }); staffChanged(); renderStaff(); var last = el('ses-staff-body').lastElementChild; if (last) last.querySelector('input').focus(); });
    el('g4fr-ses-staff-form').addEventListener('submit', async function (event) {
      event.preventDefault();
      if (state.busy || !this.reportValidity()) return;
      state.busy = true; updateControls(); status('Salvando os profissionais no cadastro permanente…', '', true);
      try {
        var saved = await saveRegister('staff', staffRows, config.staff_revision);
        staffRows = saved.rows; config.staff_revision = saved.revision;
        state.staffDirty = false; state.dataDirty = true; renderStaff();
        el('ses-staff-state').textContent = 'Profissionais salvos no plugin. O cadastro será carregado automaticamente nos próximos relatórios. Gere novamente para atualizar o INS10.';
        status('Profissionais salvos e conferidos. Gere novamente para calcular o INS10 com este cadastro.', 'success');
      } catch (error) { state.staffDirty = true; status(error.message || 'Não foi possível salvar os profissionais.', 'error'); }
      finally { state.busy = false; updateControls(); }
    });
  }
  window.addEventListener('beforeunload', function (event) { if (state.testsDirty || state.staffDirty) { event.preventDefault(); event.returnValue = ''; } });
  renderTests(); renderStaff(); updateControls();
})();
