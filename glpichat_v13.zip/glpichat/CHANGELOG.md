# Desktop6 release — 1.3.0 (2026-09-25)

- Add GLPI Desktop Windows release import, deployment export, machine status and update/repair requests.
- Serve immutable Agent/Widget releases signed by the GLPI instance and authenticated with separate machine credentials.
- Upgrade desktop schema to 3 while preserving existing chat, enrollment, send and read data.
- Keep renewable user connections visible for revocation after access-token expiry.
- Windows 0.3.0 adds complete-package validation, managed polling, explicit missing-file repair and durable recovery/handoff fixes. See the complete desktop package for scripts and qualification limits.

# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.2.0-desktop5] - 2026-09-25

- Automatic Windows logon enrollment and renewal through administrator-provisioned AD user/computer grants; no end-user browser pairing.
- Public GLPI transaction API and guarded front-page bootstrap fix the reported runtime error and constant warnings.
- Schema 2 adds grant/registration tables while preserving existing desktop and chat data.
- Windows 0.2.0 adds deployment scripts and local A/B updates through the existing updater.
- See [release notes](docs/releases/1.2.0-desktop5.md) for scope and qualification limits.

## [1.1.2-desktop3] - 2026-09-21

### Fixed

- Desktop links and readiness now derive the GLPI base URL from the current HTTPS request origin and GLPI installation path, using GLPI trusted-proxy handling. An unset or different global `url_base` no longer blocks desktop access.
- Desktop configuration no longer asks administrators to change the global GLPI URL. No global configuration value is written by this correction.

### Preserved

- Desktop client 0.1.0 and Windows source/tools are unchanged; the Windows installer still takes the target server URL through `-BaseUrl`.
- No database objects, schema markers, credentials or conversation data change relative to 1.1.1-desktop2. HTTPS and the existing browser/guest behavior remain required or preserved as applicable.

## [1.1.1-desktop2] - 2026-09-21

### Fixed

- Corrected the desktop schema metadata adapter to use `DBmysql::doQuery()`. GLPI 11 rejects `query()` with `Executing direct queries is not allowed!`, which aborted the 1.1.0-desktop1 install/update after table creation.
- Strengthened the migration fixture to enforce the real GLPI database API boundary and cover retry after partially created desktop tables.

### Preserved

- Desktop client 0.1.0, browser assets/routes, account pairing and conversation behavior are unchanged. No additional schema objects or runtime dependencies were introduced by this correction.
- Existing chat data, partially created desktop tables, keys and credentials are retained; retry the normal update without uninstalling or dropping tables.

## [1.0.6] - 2026-09-02

### Added

- Added an immutable, request-local actor context and a pure public-ticket authorization policy as the first reusable foundation for a future desktop adapter.
- Added a hidden `public_authorization_shadow_enabled` flag, disabled by default, for non-authoritative comparison of the new public policy with the established browser decision.
- Added foundation schema marker `1` and a read-only schema-health snapshot. Neither mechanism performs schema repair during normal requests.
- Added focused contracts for actor-context normalization, public-policy parity, fail-open shadow observation, lifecycle idempotency, and the absence of new routes or schema objects.

### Changed

- Advanced release identity to build `foundation1` while retaining `1.0.5-perf4` as the byte-verified active-production baseline.
- Restricted the new authorization work to public user rooms. Guest and internal-room paths remain outside the new service and flag.

### Security

- Shadow comparison is observational only: the established browser result remains authoritative, and comparison or diagnostic failures cannot grant, deny, or interrupt access.
- Actor context contains normalized GLPI authorization state only; it does not contain cookies, CSRF/session identifiers, message content, CAS/LDAP aliases, ObjectGUID values, or desktop credentials.
- Shadow diagnostics use a closed, privacy-safe schema and do not record user, ticket, room, profile, entity, group, token, URL, or payload identifiers.

### Preserved

- No External API, route, UI asset, browser/Guest protocol, table, index, cron task, runtime dependency, message transaction, read-state model, projection, enrollment, or Windows-client behavior is added in this release.
- Existing Send, Upload, Poll, History, MarkRead, Leave, Guest, invite, notification, internal-room, and protected-Document behavior remains inherited from `1.0.5-perf4`.

## [1.0.5] - 2026-08-26

### Added

- Added correlated, privacy-safe Leave phase diagnostics and response timing so a slow disconnect can be distinguished from browser queue delay.
- Added focused contracts for Leave session-lock ordering, isolated request behavior, queued-versus-active discovery states, room-local History failure, and the launcher's optional progress/warning rows.

### Changed

- Released the PHP session after Leave authentication, CSRF, room authorization, and response-token capture but before participant, event, and synchronous notification work.
- Moved explicit Leave onto a per-room-coalesced detached lane: it waits for the shared tail captured at close time, then runs without becoming the predecessor of later widget work; same-room reopening remains visibly guarded until the real Leave result.
- Split local queue-delay signals from active server/network-delay signals and bounded every deferred Channels admission while leaving already dispatched discovery work alive.
- Localized a failed History state to its own room; healthy rooms and background metadata/polling are no longer stopped by an unrelated room failure.
- Replaced the launcher's brittle two-row grid with a column layout in which warnings and filters keep their natural size and only the ticket list consumes remaining space.

### Fixed

- Prevented synchronous Leave notifications from retaining the user's PHP session lock and convoying native GLPI navigation such as Service Catalog.
- Prevented a locally queued Channels refresh from being reported as a remote refresh failure before it had produced a Network request.
- Prevented retry/manual refresh controls from creating unbounded stale discovery work behind another widget operation.
- Prevented the delayed-refresh warning from stretching status filters into large empty columns and corrupting the conversation list layout.

## [1.0.4] - 2026-08-26

### Added

- Added explicit Channels discovery states for loading, slow processing, retry cooldown, terminal failure, delayed metadata, and successful readiness, including a launcher animation and a separate visible History loading label.
- Added bounded, privacy-safe Channels phase/count diagnostics and correlated Config diagnostics with `Server-Timing`, while suppressing phase-level logging for normal periodic metadata.

### Changed

- Sequenced Config after successful Channels bootstrap and gated Poll, metadata, invite refresh, and widget timers until runtime readiness.
- Replaced Channels coalescing with exact single-flight admission and added one visibility-aware exponential retry timer for network and 502/503/504 failures.
- Limited ordinary Channels candidates to deterministic direct/group relationships for active ticket statuses, bounded the merged candidate set before authorization, and enriched only the capped `Ticket::can(READ)`-authorized result.
- Preserved an explicitly focused solved/closed ticket independently of ordinary active-ticket discovery and enforced the 80-channel limit inside room selection.

### Fixed

- Classified non-JSON gateway 502/503/504 responses by HTTP status instead of reporting them as `invalid_json`.
- Prevented a pre-ready metadata timer from queuing a second Channels scan behind slow startup work.
- Preserved already loaded conversations after a metadata failure and no longer rendered an in-progress discovery as an empty conversation list.
- Prevented duplicate authenticated bundle execution from mounting a second widget runtime, listeners, or timer set.

## [1.0.3] - 2026-08-26

### Added

- Added privacy-safe request correlation in the browser console and `files/_log/glpichat.log`, with phased History diagnostics, trace response headers, and `Server-Timing`.
- Added an explicit History failure panel with a correlation reference and manual retry action.

### Changed

- Preserved each channel's canonical browser object during metadata refresh so an in-flight History result cannot be written into detached state.
- Serialized duplicate History clicks per channel, expired only stale requests that have not reached the server, and paused Poll/metadata work while hydration is active or an open room remains failed.
- Released History, Poll, and MarkRead after their endpoint-specific authorization/CSRF work and before expensive hydration/read-state work; released Channels after login/user/CSRF snapshot and before discovery against the retained request-local rights/entity snapshot.
- Made concurrent participant selection deterministic and made unread calculation prefer the canonical active row, preventing a retired race loser from pinning unread badges.
- Made room creation converge on the unique canonical row and made MarkRead advance its cursor atomically across concurrent tabs.
- Removed installation-wide participant expiration from interactive Poll requests and suppressed synchronous join notifications when participant creation is incidental to History, Poll, or MarkRead.

### Fixed

- Removed the silent History-to-Poll fallback and the empty-Poll-to-Channels fallback that could hide the failed operation and amplify work.
- Kept the composer disabled until the selected room has loaded successfully.

## [1.0.2] - 2026-08-24

### Added

- Added an administrator-controlled, fail-closed browser-surface switch for staged laboratory qualification. Disabling it prevents browser CSS/JavaScript injection while preserving mandatory authorization and notification hooks.

### Changed

- Restricted schema, index, rights, notification, RequestType, and cron reconciliation to the GLPI plugin install/update lifecycle; normal page requests no longer attempt runtime repair.
- Ordered participant compatibility fields before dependent index migration and made repeated install/update execution safe.
- Reused one GLPI ticket authorization decision per Channels candidate for both room types while preserving the existing candidate set, ordering, room creation, unread calculation, response shape, and 80-row cap.
- Coalesced overlapping Channels and Poll work in the browser and removed the duplicate idle Channels trigger when no ticket chat is open.

### Fixed

- Added the missing `last_send_at` compatibility migration for databases upgraded from an older schema.
- Removed the stale `ExpireParticipants` automatic-action registration left by the rejected `1.0.1-lab1` candidate without dropping or rewriting chat data.
- Avoided the per-Document Chat database lookup for profiles that already hold internal-chat read permission; profiles without that permission retain the original confidentiality lookup and denial behavior.

## [1.0.0] - 2026-08-03

### Added

- Enhanced launcher notification rendering with improved validation for typing indicators
- Improved chat widget interaction and performance optimization
- User selection for external followup associations in chat configuration
- User join/leave notification events and improved chat widget state handling
- Recipient filter to prevent unauthorized internal message notification delivery
- Per-participant send rate limiting to prevent abuse; guest authentication failure audit logging
- Last activity time tracking for chat participants with updated invite guard validation
- Notification flow for secure message handling with updated email templates
- Modular architecture for chat system with HTML sanitization security features
- Form submission helper and Enter-to-send functionality for improved user experience
- Audit log tab for ticket chat with refactored tab management for multiple entries
- Drag-and-drop file upload functionality and system notifications for chat events
- Dynamic launcher positioning, image lightbox, and persistent session state for the chat widget
- Overview section with a widget screenshot in the main README
- GitHub star badge and call-out in the README encouraging repository stars
- Contribution guide (`CONTRIBUTING.md`) for external contributors
- Environment variable example file (`.env.example`) covering the test suite
- GitHub issue templates — bug report and feature request — under `.github/ISSUE_TEMPLATE/`

### Changed

- Plugin now supports dynamic base URL to enable proper operation in GLPI subdirectories
- Error messages localized to Portuguese; improved internal event handling
- Standardized the project support footer across all documentation files (`README.md` and `docs/`)

### Fixed

- Improved dark theme color contrast for better readability in dark mode
- Fixed the "Create invite" button getting stuck on "Creating..." after a successful invite creation
- Fixed a guest session crash caused by an unhandled error when the session expired mid-action
- Fixed invite acceptance showing raw unstyled text instead of a proper error page when invite limits were exceeded
- Fixed invite and accept rate limits not being enforced due to an incorrect internal counter reference
- Fixed an incorrectly formatted internal event cursor used for guest activity tracking
- Corrected CSS syntax error in linear-gradient background property
- Fixed invite revocation logic enforcement
- Corrected the notification events table in `README.md` and `docs/features/notifications.md`, which listed 6 events when the code actually registers 8
- Fixed the screenshot link in `plugin.xml`, which pointed to a non-existent file
- Fixed the logo link in `plugin.xml`, which did not resolve to a valid image
- Fixed the published version's `download_url` in `plugin.xml`, which pointed to the unstable `main` branch zip instead of the fixed tag artifact
- Filled in the empty `homepage` field in `setup.php`
- Filled in the copyright notice placeholder in the `LICENSE` file

### Security

- Hardened XSS protection in URL path handling to prevent injection attacks
- Hardened guest session validation and controller access controls
- Implemented security hardening for file uploads with size validation and type checking
- Enforced CSRF token validation on all state-changing operations
- Implemented protection against Stored XSS vulnerabilities
- Restricted asset loading to prevent unauthorized resource inclusion
- Validated all file uploads to prevent malicious file handling
- Removed a hardcoded local absolute path exposing a developer's username and directory layout from a test helper script (`tests/helpers/patch_animations.py`)

[unreleased]: https://github.com/forq-dev/glpichat/compare/v1.0.6...HEAD
[1.0.6]: https://github.com/forq-dev/glpichat/compare/v1.0.5...v1.0.6
[1.0.5]: https://github.com/forq-dev/glpichat/compare/v1.0.4...v1.0.5
[1.0.4]: https://github.com/forq-dev/glpichat/compare/v1.0.3...v1.0.4
[1.0.3]: https://github.com/forq-dev/glpichat/compare/v1.0.2...v1.0.3
[1.0.2]: https://github.com/forq-dev/glpichat/compare/v1.0.0...v1.0.2
[1.0.0]: https://github.com/forq-dev/glpichat/releases/tag/v1.0.0
