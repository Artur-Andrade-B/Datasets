<?php

declare(strict_types=1);

// Actual common/auth/enrollment services, fake core authority and SQL boundary.
define('READ', 1); define('CREATE', 4);
class Auth { public const LDAP = 3; public const CAS = 5; public const X509 = 6; public const EXTERNAL = 4; }
class Ticket { public const READMY = 1; public const READALL = 1024; }
class ITILFollowup { public const SEEPUBLIC = 1; public const ADDMY = 4; public const ADDALLITEM = 4096; }
class Config {
    public static array $values = ['desktop_enabled' => '1', 'desktop_schema_version' => '2', 'desktop_idempotency_key' => 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'];
    public static function getConfigurationValues(string $context): array { return self::$values; }
}
require_once dirname(__DIR__, 2) . '/fixtures/desktop_enrollment_db.php';
require_once dirname(__DIR__, 3) . '/src/desktop/common.php';
require_once dirname(__DIR__, 3) . '/src/desktop/auth.php';

$assertions = 0;
function managed_assert(bool $condition, string $message): void
{
    global $assertions;
    if (!$condition) { throw new RuntimeException('FAIL: ' . $message); }
    ++$assertions;
}
function managed_throws(callable $action, string $code, string $message): void
{
    try { $action(); } catch (GlpichatDesktopException $error) {
        managed_assert($error->errorCode === $code, $message . ' (got ' . $error->errorCode . ')'); return;
    }
    throw new RuntimeException('FAIL missing error: ' . $message);
}
function managed_fixture(): array
{
    global $DB;
    $DB = new DesktopEnrollmentDB(); glpichat_desktop_reset_request_context();
    $grant = glpichat_desktop_grant_issue(['users_id' => 10, 'profiles_id' => 3, 'entities_id' => 1,
        'windows_sid' => 'S-1-5-21-111-222-333-1001', 'computer_name' => 'office-pc']);
    $request = ['grant_id' => $grant['grant_id'], 'grant_secret' => $grant['grant_secret'],
        'device_id' => '11111111-2222-4333-8444-555555555555', 'windows_sid' => $grant['windows_sid'],
        'computer_name' => 'office-pc', 'access_token' => str_repeat('b', 64), 'refresh_secret' => str_repeat('c', 64)];
    return [$grant, $request];
}

Config::$values['desktop_schema_version'] = '3'; glpichat_desktop_reset_request_context();
managed_assert(glpichat_desktop_managed_schema(), 'Existing managed enrollment remains supported under schema3');
Config::$values['desktop_schema_version'] = '2'; glpichat_desktop_reset_request_context();
[$grant, $request] = managed_fixture();
managed_assert(glpichat_desktop_delivery_identity($request['windows_sid'], 'pc_2')[1] === 'PC_2', 'Computer delivery names include valid underscore consistently with deployment scripts');
$preflight = glpichat_desktop_auth_user(10, 3, 1);
$assignment = ['users_id' => 10, 'profiles_id' => 3, 'entities_id' => 1, 'windows_sid' => $request['windows_sid'],
    'computer_name' => 'OTHER-PC', 'expected_identity' => $preflight];
$DB->tables['glpi_users'][0]['sync_field'] = 'replacement-after-csv-check';
$count = count($DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE]);
managed_throws(static fn() => glpichat_desktop_grant_issue($assignment), 'enrollment_identity_changed', 'CSV-preflight identity replacement rejected under issuance lock');
managed_assert(count($DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE]) === $count, 'Changed preflight binding inserts no grant');
$DB->tables['glpi_users'][0]['sync_field'] = DesktopEnrollmentDB::ANCHOR;
managed_assert(preg_match('/^[a-f0-9]{32}$/D', $grant['grant_id']) === 1, 'Opaque grant identifier');
managed_assert($grant['user']['id'] === 10 && $grant['entity_id'] === 1 && $grant['computer_name'] === 'OFFICE-PC', 'Authority and delivery metadata server assigned');
managed_assert(!str_contains(serialize($DB->tables), $grant['grant_secret']), 'Plain grant secret never stored server-side');
foreach (['grant_secret' => str_repeat('d', 64), 'windows_sid' => 'S-1-5-21-111-222-333-1002', 'computer_name' => 'other-pc'] as $field => $value) {
    managed_throws(static fn() => glpichat_desktop_enroll(array_replace($request, [$field => $value])), 'enrollment_unavailable', 'Wrong ' . $field . ' cannot enroll');
}
foreach ([[], new stdClass(), 10, null] as $bad) {
    managed_throws(static fn() => glpichat_desktop_enroll(array_replace($request, ['grant_secret' => $bad])), 'invalid_enrollment', 'Structured/nonstring field rejected without coercion');
}
$identity = glpichat_desktop_enroll($request);
managed_assert($identity['user']['id'] === 10 && $identity['user']['subject_id'] === $grant['user']['subject_id'], 'Enrollment returns provisioned principal');
managed_assert($identity['device']['auth_mode'] === 'managed' && $identity['device']['grant_id'] === $grant['grant_id']
    && $identity['device']['windows_sid'] === $grant['windows_sid'], 'Managed provenance returned');
managed_assert(count($DB->tables[GLPICHAT_DESKTOP_DEVICES_TABLE]) === 1 && count($DB->tables[GLPICHAT_DESKTOP_REGISTRATIONS_TABLE]) === 1, 'Exactly one installation is created');
managed_assert(!str_contains(serialize($DB->tables), $request['access_token']) && !str_contains(serialize($DB->tables), $request['refresh_secret']), 'Access and refresh secrets only hashed on server');
$writes = count($DB->writes);
$DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE][0]['expires_at'] = '2020-01-01 00:00:00';
managed_assert(glpichat_desktop_enroll($request) === $identity && count($DB->writes) === $writes, 'Identical lost-response replay survives spent grant expiry without mutation');
managed_throws(static fn() => glpichat_desktop_enroll(array_replace($request, ['device_id' => '21111111-2222-4333-8444-555555555555'])), 'enrollment_unavailable', 'Consumed grant cannot enroll another installation');
managed_throws(static fn() => glpichat_desktop_enroll(array_replace($request, ['refresh_secret' => str_repeat('d', 64)])), 'enrollment_unavailable', 'Consumed grant cannot replace refresh authority');
managed_assert(glpichat_desktop_identity(glpichat_desktop_authenticate($request['access_token'])) === $identity, '/Me preserves managed provenance and subject');
$savedGrant = $DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE];
$DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE] = [];
managed_throws(static fn() => glpichat_desktop_authenticate($request['access_token']), 'device_revoked', 'Missing authoritative grant cannot downgrade a managed credential into legacy access');
$DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE] = $savedGrant;

$renew = ['grant_id' => $request['grant_id'], 'device_id' => $request['device_id'], 'refresh_secret' => $request['refresh_secret'], 'access_token' => str_repeat('d', 64)];
$DB->tables[GLPICHAT_DESKTOP_DEVICES_TABLE][0]['token_expires_at'] = '2020-01-01 00:00:00';
managed_throws(static fn() => glpichat_desktop_authenticate($request['access_token']), 'token_expired', 'Expired access has a specific recoverable error');
$expiredReplay = glpichat_desktop_enroll($request);
managed_assert($expiredReplay['device']['expires_at'] === '2020-01-01T00:00:00Z', 'Delayed exchange replay retains original expiry; client must finish with fresh renewal');
$renewed = glpichat_desktop_renew($renew);
managed_assert($renewed['user']['subject_id'] === $identity['user']['subject_id'] && $renewed['device']['id'] === $identity['device']['id'], 'Renewal after expired access retains same registration and principal');
managed_throws(static fn() => glpichat_desktop_authenticate($request['access_token']), 'credential_invalid', 'Rotated access is no longer accepted');
managed_throws(static fn() => glpichat_desktop_enroll($request), 'enrollment_consumed', 'Old enrollment replay cannot reactivate initial access after renewal');
$DB->tables[GLPICHAT_DESKTOP_DEVICES_TABLE][0]['token_expires_at'] = '2099-01-01 00:00:00';
$DB->tables[GLPICHAT_DESKTOP_REGISTRATIONS_TABLE][0]['refresh_expires_at'] = '2099-02-01 00:00:00';
$writes = count($DB->writes);
$repeat = glpichat_desktop_renew($renew);
managed_assert($repeat['device']['expires_at'] === '2099-01-01T00:00:00Z' && $repeat['device']['refresh_expires_at'] === '2099-02-01T00:00:00Z'
    && count($DB->writes) === $writes, 'Identical renewal replay changes neither expiry nor storage');
managed_throws(static fn() => glpichat_desktop_renew(array_replace($renew, ['refresh_secret' => str_repeat('e', 64)])), 'refresh_invalid', 'Wrong refresh secret cannot renew');
$DB->tables['glpi_users'][0]['is_active'] = 0;
managed_throws(static fn() => glpichat_desktop_renew($renew), 'authorization_denied', 'Renewal rechecks current account authority');
$DB->tables['glpi_users'][0]['is_active'] = 1;
$DB->tables['glpi_profiles_users'] = [];
managed_throws(static fn() => glpichat_desktop_renew($renew), 'authorization_denied', 'Removed profile/entity assignment blocks renewal');
$DB->tables['glpi_profiles_users'] = [['id' => 1, 'users_id' => 10, 'profiles_id' => 3, 'entities_id' => 1, 'is_recursive' => 0]];
$DB->tables['glpi_users'][0]['sync_field'] = 'replacement';
managed_throws(static fn() => glpichat_desktop_renew($renew), 'authorization_denied', 'Replacement account anchor cannot inherit refresh');
$DB->tables['glpi_users'][0]['sync_field'] = DesktopEnrollmentDB::ANCHOR;
$DB->tables[GLPICHAT_DESKTOP_REGISTRATIONS_TABLE][0]['refresh_expires_at'] = '2020-01-01 00:00:00';
managed_throws(static fn() => glpichat_desktop_renew($renew), 'refresh_expired', 'Expired recovery window requires administrator reprovision');

[$grant, $request] = managed_fixture();
$DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE][0]['expires_at'] = '2020-01-01 00:00:00';
managed_throws(static fn() => glpichat_desktop_enroll($request), 'grant_expired', 'Unused expired grant cannot enroll');
[$grant, $request] = managed_fixture();
glpichat_desktop_grant_revoke($grant['grant_id']);
managed_throws(static fn() => glpichat_desktop_enroll($request), 'device_revoked', 'Administrative unused-grant revocation persists');
[$grant, $request] = managed_fixture();
$identity = glpichat_desktop_enroll($request);
glpichat_desktop_grant_revoke($grant['grant_id']);
managed_throws(static fn() => glpichat_desktop_authenticate($request['access_token']), 'device_revoked', 'Admin revoke blocks access');
managed_throws(static fn() => glpichat_desktop_enroll($request), 'device_revoked', 'Admin revoke blocks spent-grant replay');
managed_throws(static fn() => glpichat_desktop_renew(array_replace($request, ['access_token' => str_repeat('e', 64)])), 'device_revoked', 'Admin revoke blocks refresh');

[$grant, $request] = managed_fixture();
$identity = glpichat_desktop_enroll($request);
glpichat_desktop_revoke_user_device($identity['device']['id'], 10);
managed_assert($DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE][0]['status'] === 'revoked', 'Own-device revoke also revokes the consumed grant');
managed_throws(static fn() => glpichat_desktop_renew($request), 'device_revoked', 'Own-device revoke blocks refresh');
foreach ([GLPICHAT_DESKTOP_DEVICES_TABLE, GLPICHAT_DESKTOP_REGISTRATIONS_TABLE] as $table) {
    [$grant, $request] = managed_fixture(); $DB->failInsert = $table;
    managed_throws(static fn() => glpichat_desktop_enroll($request), 'storage_unavailable', 'Partial enrollment fails atomically');
    managed_assert(!$DB->tables[GLPICHAT_DESKTOP_DEVICES_TABLE] && !$DB->tables[GLPICHAT_DESKTOP_REGISTRATIONS_TABLE]
        && $DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE][0]['status'] === 'issued', 'Transaction restores all unconsumed enrollment state');
}
[$grant, $request] = managed_fixture(); glpichat_desktop_enroll($request);
$before = $DB->tables; $DB->failUpdate = GLPICHAT_DESKTOP_REGISTRATIONS_TABLE;
managed_throws(static fn() => glpichat_desktop_renew(array_replace($request, ['access_token' => str_repeat('e', 64)])), 'storage_unavailable', 'Partial renewal fails atomically');
managed_assert($DB->tables === $before, 'Failed refresh metadata write does not rotate access alone');
[$grant, $request] = managed_fixture(); $identity = glpichat_desktop_enroll($request);
$before = $DB->tables; $DB->failUpdate = GLPICHAT_DESKTOP_GRANTS_TABLE;
managed_throws(static fn() => glpichat_desktop_revoke_user_device($identity['device']['id'], 10), 'storage_unavailable', 'Failed paired revocation is atomic');
managed_assert($DB->tables === $before, 'Failed grant revocation does not leave only half of registration revoked');
Config::$values['desktop_schema_version'] = '1'; glpichat_desktop_reset_request_context();
managed_throws(static fn() => glpichat_desktop_enroll($request), 'schema_unavailable', 'Enrollment requires completed schema2');
managed_assert(glpichat_desktop_schema_ready(), 'Legacy chat readiness remains compatible with schema1');
echo 'PASS desktop enrollment: ' . $assertions . " assertions\n";
