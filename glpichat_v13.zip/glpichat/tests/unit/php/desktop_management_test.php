<?php

declare(strict_types=1);
if (PHP_SAPI !== 'cli') { exit(1); }
require_once dirname(__DIR__, 2) . '/fixtures/desktop_management_db.php';
final class Config
{
    public static array $values = ['desktop_schema_version' => '3', 'desktop_enabled' => '0'];
    public static function getConfigurationValues(string $context): array { return self::$values; }
}
$temp = sys_get_temp_dir() . '/glpichat-management-' . bin2hex(random_bytes(8));
mkdir($temp, 0700);
define('GLPI_PLUGIN_DOC_DIR', $temp . '/private');
require_once dirname(__DIR__, 3) . '/src/desktop/management.php';
$DB = new DesktopManagementDB(); $count = 0;
function verify(bool $condition, string $message): void { global $count; if (!$condition) { throw new RuntimeException($message); } $count++; }
function failure(callable $action, string $code): void {
    try { $action(); } catch (GlpichatDesktopException $e) { verify($e->errorCode === $code, 'Expected ' . $code . ', got ' . $e->errorCode); return; }
    throw new RuntimeException('Expected error ' . $code);
}
function archive(string $path, string $version = '0.3.0', ?callable $alter = null): string {
    $bytes = 'MZ' . str_repeat("\0", 58) . pack('V', 64) . "PE\0\0" . str_repeat("\0", 140);
    $entries = ['GLPIChat.Agent.exe' => $bytes . 'agent', 'GLPIChat.Widget.exe' => $bytes . 'widget'];
    $files = [];
    foreach (['agent' => 'GLPIChat.Agent.exe', 'widget' => 'GLPIChat.Widget.exe'] as $role => $name) { $files[] = ['role' => $role, 'filename' => $name, 'size' => strlen($entries[$name]), 'sha256' => hash('sha256', $entries[$name])]; }
    $entries['release.json'] = json_encode(['schema' => 1, 'product' => 'glpichat-desktop', 'version' => $version, 'files' => $files], JSON_THROW_ON_ERROR);
    if ($alter) { $entries = $alter($entries); }
    $zip = new ZipArchive(); $zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE);
    foreach ($entries as $name => $content) { $zip->addFromString($name, $content); } $zip->close(); return $path;
}
function cleanup(string $path): void { if (is_dir($path) && !is_link($path)) { foreach (scandir($path) as $name) { if ($name !== '.' && $name !== '..') { cleanup($path . '/' . $name); } } rmdir($path); } elseif (file_exists($path) || is_link($path)) { unlink($path); } }
try {
    verify(extension_loaded('openssl') && class_exists(ZipArchive::class), 'Actual OpenSSL and ZipArchive required.');
    $zip = archive($temp . '/release.zip');
    $release = glpichat_management_import($zip, 1);
    verify($release['id'] === 1 && $release['sequence'] > 1000000000000, 'Imported monotonic release');
    $stored = $DB->tables[GLPICHAT_MANAGEMENT_RELEASES][0];
    $key = openssl_pkey_get_private(file_get_contents(glpichat_management_storage() . '/instance-signing.pem'));
    $public = openssl_pkey_get_details($key)['key'];
    verify(openssl_verify($stored['manifest_json'], base64_decode($stored['signature']), $public, OPENSSL_ALGO_SHA256) === 1, 'Real RSA2048 signature verifies');
    verify(openssl_verify($stored['manifest_json'] . ' ', base64_decode($stored['signature']), $public, OPENSSL_ALGO_SHA256) === 0, 'Tampered manifest rejected');
    verify((fileperms(glpichat_management_storage() . '/instance-signing.pem') & 0777) === 0600, 'Private key0600');
    verify((fileperms(glpichat_management_storage()) & 0777) === 0700, 'Private storage0700');
    $manifest = json_decode($stored['manifest_json'], true, 16, JSON_THROW_ON_ERROR);
    verify($manifest['bootstrap_abi'] === 1 && $manifest['state_schema_min'] === 1 && count($manifest['components']) === 2, 'Native updater manifest');
    failure(fn() => glpichat_management_import($zip, 1), 'release_exists');
    verify(count($DB->tables[GLPICHAT_MANAGEMENT_RELEASES]) === 1, 'Duplicate leaves release unchanged');
    foreach ([
        fn(array $e): array => $e + ['../evil.exe' => 'payload'],
        fn(array $e): array => array_replace($e, ['GLPIChat.Agent.exe' => 'MZbad']),
        fn(array $e): array => array_replace($e, ['release.json' => '{}']),
        fn(array $e): array => array_replace($e, ['release.json' => '[]']),
        fn(array $e): array => array_replace($e, ['release.json' => '{broken']),
    ] as $i => $mutate) { failure(fn() => glpichat_management_import(archive($temp . '/bad' . $i . '.zip', '0.3.1', $mutate), 1), 'release_invalid'); }
    $linkZip = archive($temp . '/symlink.zip', '0.3.1');
    $linkArchive = new ZipArchive(); $linkArchive->open($linkZip);
    $linkArchive->setExternalAttributesName('GLPIChat.Widget.exe', ZipArchive::OPSYS_UNIX, 0120777 << 16); $linkArchive->close();
    failure(fn() => glpichat_management_import($linkZip, 1), 'release_invalid');
    $oversized = archive($temp . '/oversized.zip', '0.3.1', static fn(array $e): array => array_replace($e, ['GLPIChat.Widget.exe' => str_repeat('x', GLPICHAT_MANAGEMENT_MAX_FILE + 1)]));
    failure(fn() => glpichat_management_import($oversized, 1), 'release_invalid');
    $deployment = glpichat_management_deployment('http://glpi.lab:8080/glpi', 'C:\\Protected', 1, 7, 1);
    verify($deployment['base_url'] === 'http://glpi.lab:8080/glpi' && str_contains($deployment['management_public_key_xml'], '<Modulus>'), 'HTTP lab deployment preserves root/port and public key');
    verify(!str_contains($deployment['management_public_key_xml'], '<D>'), 'Deployment key public only');
    $grant = $DB->tables[GLPICHAT_MANAGEMENT_GRANTS][0];
    verify($grant['secret_hash'] !== $deployment['registration_secret'] && strlen($grant['secret_hash']) === 64, 'Registration stores hash only');
    failure(fn() => glpichat_management_deployment('http://user:pass@host', '', 1, 7, 1), 'invalid_request');
    failure(fn() => glpichat_management_deployment('http://host/../glpi', '', 1, 7, 1), 'invalid_request');
    $token = str_repeat('a', 64); $installation = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';
    $request = ['registration_id' => $deployment['registration_id'], 'registration_secret' => $deployment['registration_secret'], 'machine_token' => $token,
        'installation_id' => $installation, 'computer_name' => 'HOST_1', 'bootstrap_version' => '0.3.0'];
    verify(glpichat_management_register($request)['ok'] === true, 'Registers with desktop chat disabled');
    verify($DB->tables[GLPICHAT_MANAGEMENT_GRANTS][0]['used_count'] === 1, 'Consumes one use');
    verify($DB->tables[GLPICHAT_MANAGEMENT_MACHINES][0]['token_hash'] !== $token, 'Machine token hashed');
    $DB->tables[GLPICHAT_MANAGEMENT_GRANTS][0]['expires_at'] = '2000-01-01 00:00:00';
    verify(glpichat_management_register($request)['ok'] === true && $DB->tables[GLPICHAT_MANAGEMENT_GRANTS][0]['used_count'] === 1, 'Expired consumed grant identical retry');
    failure(fn() => glpichat_management_register(array_replace($request, ['machine_token' => str_repeat('b', 64)])), 'registration_conflict');
    failure(fn() => glpichat_management_register(array_replace($request, ['installation_id' => 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'])), 'registration_expired');
    failure(fn() => glpichat_management_register(array_replace($request, ['computer_name' => []])), 'invalid_request');
    failure(fn() => glpichat_management_authenticate(str_repeat('c', 64), $installation), 'machine_invalid');
    $poll = ['bootstrap_version' => '0.3.0', 'current_version' => '0.2.0', 'current_sequence' => 1, 'current_slot' => 'a', 'health' => 'healthy', 'result' => '', 'error_code' => '', 'assignment_id' => 0];
    verify(glpichat_management_poll($token, $installation, $poll)['assignment'] === null, 'No implicit update');
    $assignment = glpichat_management_assign(1, 1, 'update', 1);
    verify(glpichat_management_poll($token, $installation, $poll)['assignment']['id'] === $assignment, 'Assignment returned');
    failure(fn() => glpichat_management_artifact($token, $installation, 1, 'GLPIChat.Widget.exe'), 'not_found');
    $started = array_replace($poll, ['assignment_id' => $assignment, 'result' => 'started']);
    verify(glpichat_management_poll($token, $installation, $started)['assignment']['id'] === $assignment, 'Started retains assignment');
    $path = glpichat_management_artifact($token, $installation, 1, 'GLPIChat.Widget.exe');
    verify(hash_file('sha256', $path) === $manifest['components'][1]['sha256'], 'Authenticated artifact exact bytes');
    failure(fn() => glpichat_management_artifact($token, $installation, 2, 'GLPIChat.Widget.exe'), 'not_found');
    failure(fn() => glpichat_management_artifact($token, $installation, 1, '../instance-signing.pem'), 'not_found');
    $wrong = array_replace($started, ['result' => 'committed']);
    verify(glpichat_management_poll($token, $installation, $wrong)['assignment'] !== null, 'Wrong installed version cannot complete');
    $failed = array_replace($started, ['result' => 'failed', 'error_code' => 'candidate_probe_failed']);
    verify(glpichat_management_poll($token, $installation, $failed)['assignment'] === null, 'Failure stops automatic retry');
    failure(fn() => glpichat_management_assign(1, 1, 'update', 1), 'release_quarantined');
    $repair = glpichat_management_assign(1, 1, 'repair', 1);
    verify($repair > $assignment, 'Explicit repair creates new authorization');
    $done = array_replace($poll, ['assignment_id' => $repair, 'result' => 'repaired', 'current_version' => '0.3.0', 'current_sequence' => $release['sequence']]);
    verify(glpichat_management_poll($token, $installation, $done)['assignment'] === null && $DB->tables[GLPICHAT_MANAGEMENT_ASSIGNMENTS][1]['status'] === 'completed', 'Exact healthy target acknowledged complete');
    failure(fn() => glpichat_management_assign(1, 1, 'update', 1), 'sequence_conflict');
    $next = glpichat_management_import(archive($temp . '/next.zip', '0.3.1'), 1);
    verify($next['sequence'] > $release['sequence'], 'Subsequent release monotonic');
    $nextAssignment = glpichat_management_assign(1, 2, 'update', 1);
    verify(glpichat_management_poll($token, $installation, $done)['assignment']['id'] === $nextAssignment, 'Old acknowledgement cannot complete new operation');
    $before = $DB->tables;
    $DB->failUpdate = GLPICHAT_MANAGEMENT_MACHINES;
    try { glpichat_management_poll($token, $installation, array_replace($done, ['assignment_id' => $nextAssignment, 'result' => 'failed'])); throw new LogicException('Expected storage failure'); }
    catch (RuntimeException $e) { verify($DB->tables === $before, 'Poll status and telemetry roll back together'); }
    $beforeDirectories = glob(glpichat_management_storage() . '/*');
    $DB->failInsert = GLPICHAT_MANAGEMENT_RELEASES;
    try { glpichat_management_import(archive($temp . '/dbfail.zip', '0.3.2'), 1); throw new LogicException('Expected storage failure'); }
    catch (RuntimeException $e) { verify(glob(glpichat_management_storage() . '/*') === $beforeDirectories, 'Failed import removes staged artifacts'); }
    glpichat_management_revoke('registration', 1);
    failure(fn() => glpichat_management_register($request), 'registration_invalid');
    verify(glpichat_management_authenticate($token, $installation)['id'] === 1, 'Grant revocation does not silently revoke established machines');
    glpichat_management_revoke('machine', 1);
    failure(fn() => glpichat_management_poll($token, $installation, $poll), 'machine_invalid');
    failure(fn() => glpichat_management_artifact($token, $installation, 2, 'GLPIChat.Widget.exe'), 'machine_invalid');
    $keyPath = glpichat_management_storage() . '/instance-signing.pem';
    rename($keyPath, $keyPath . '.backup');
    failure(fn() => glpichat_management_deployment('https://glpi.lab/glpi', '', 1, 7, 1), 'signing_key_missing');
    verify(!file_exists($keyPath), 'Missing pinned key is never silently replaced');
    rename($keyPath . '.backup', $keyPath);
    Config::$values['desktop_schema_version'] = '2'; glpichat_desktop_reset_request_context();
    failure(fn() => glpichat_management_register($request), 'schema_unavailable');
    echo 'PASS desktop_management_test: ' . $count . " assertions; actual native ZIP/OpenSSL/filesystem, fixture SQL boundary.\n";
} finally { cleanup($temp); }
