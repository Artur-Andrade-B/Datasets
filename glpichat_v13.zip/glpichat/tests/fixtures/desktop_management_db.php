<?php
/** SQL-boundary fixture only; actual archive, filesystem and cryptography are used by tests. */
final class DesktopManagementRows
{
    public int $offset = 0;
    public function __construct(public array $rows) {}
    public function free(): void {}
}
final class DesktopManagementDB
{
    public array $tables = [];
    public array $queries = [];
    public array $snapshots = [];
    public ?string $failInsert = null;
    public ?string $failUpdate = null;
    private int $lastId = 0;
    public function __construct()
    {
        foreach (['desktopreleases', 'desktopmachinegrants', 'desktopmachines', 'desktopassignments'] as $name) { $this->tables['glpi_plugin_glpichat_' . $name] = []; }
    }
    public function beginTransaction(): void { $this->snapshots[] = $this->tables; }
    public function commit(): void { array_pop($this->snapshots); }
    public function rollBack(): void { $this->tables = array_pop($this->snapshots); }
    public function escape(string $value): string { return addslashes($value); }
    public function insertId(): int { return $this->lastId; }
    public function insert(string $table, array $values): bool
    {
        if ($this->failInsert === $table) { $this->failInsert = null; return false; }
        if (!isset($this->tables[$table])) { throw new RuntimeException('Unknown fixture table.'); }
        $values['id'] = $this->tables[$table] ? max(array_column($this->tables[$table], 'id')) + 1 : 1;
        foreach (['version', 'sequence', 'storage_key', 'installation_id', 'token_hash'] as $key) {
            if (!isset($values[$key])) { continue; }
            foreach ($this->tables[$table] as $row) { if (($row[$key] ?? null) === $values[$key]) { throw new RuntimeException('Fixture unique conflict.'); } }
        }
        if ($table === 'glpi_plugin_glpichat_desktopmachinegrants') {
            foreach ($this->tables[$table] as $row) { if ($row['registration_id'] === $values['registration_id']) { throw new RuntimeException('Fixture registration conflict.'); } }
        }
        $this->lastId = $values['id']; $this->tables[$table][] = $values; return true;
    }
    public function update(string $table, array $values, array $where): bool
    {
        if ($this->failUpdate === $table) { $this->failUpdate = null; return false; }
        foreach ($this->tables[$table] as &$row) {
            $match = true;
            foreach ($where as $key => $value) { if ((string) ($row[$key] ?? '') !== (string) $value) { $match = false; break; } }
            if ($match) { $row = array_replace($row, $values); }
        }
        unset($row); return true;
    }
    public function doQuery(string $sql): DesktopManagementRows
    {
        $this->queries[] = $sql;
        if (preg_match('/\ASELECT (.+) FROM ([a-z_0-9]+)(?: |$)/D', $sql, $m) !== 1 || !isset($this->tables[$m[2]])) { throw new RuntimeException('Unsupported fixture SELECT: ' . $sql); }
        $rows = $this->tables[$m[2]];
        $where = explode(' WHERE ', $sql, 2)[1] ?? '';
        preg_match_all('/(?:\A| AND )([a-z_]+)=(\d+|\'(?:[^\'\\\\]|\\\\.)*\')/', $where, $clauses, PREG_SET_ORDER);
        foreach ($clauses as $clause) {
            $value = str_starts_with($clause[2], "'") ? stripslashes(substr($clause[2], 1, -1)) : (int) $clause[2];
            $rows = array_values(array_filter($rows, static fn(array $row): bool => (string) ($row[$clause[1]] ?? '') === (string) $value));
        }
        if (preg_match('/status IN \(([^)]+)\)/', $where, $in)) {
            $states = array_map(static fn(string $v): string => trim($v, " '"), explode(',', $in[1]));
            $rows = array_values(array_filter($rows, static fn(array $row): bool => in_array($row['status'], $states, true)));
        }
        if (preg_match('/ ORDER BY ([a-z_]+) DESC/', $sql, $order)) { usort($rows, static fn(array $a, array $b): int => $b[$order[1]] <=> $a[$order[1]]); }
        if (preg_match('/ LIMIT ([0-9]+)/', $sql, $limit)) { $rows = array_slice($rows, 0, (int) $limit[1]); }
        if ($m[1] !== '*') { $keys = array_fill_keys(explode(',', $m[1]), true); $rows = array_map(static fn(array $row): array => array_intersect_key($row, $keys), $rows); }
        return new DesktopManagementRows($rows);
    }
    public function fetchAssoc(DesktopManagementRows $rows): array|false { return $rows->rows[$rows->offset++] ?? false; }
}
