<?php

declare(strict_types=1);

/**
 * Integration contract fixture, not a database integration test.
 *
 * Uses unmodified GLPI DBmysql::query() from an explicit local core source path.
 * Replaces only the connection/SQL-result boundary with an in-memory fixture.
 * No core constructor, database connection, SQL execution, or GLPI session runs.
 *
 * Usage: php desktop_schema_core_boundary.php SCHEMA_PATH legacy|fixed CORE_DBMYSQL_PATH
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
if ($argc !== 4 || !in_array($argv[2], ['legacy', 'fixed'], true)
    || !is_file($argv[1]) || !is_readable($argv[1])
    || !is_file($argv[3]) || !is_readable($argv[3])) {
    fwrite(STDERR, "Usage: desktop_schema_core_boundary.php SCHEMA_PATH legacy|fixed CORE_DBMYSQL_PATH\n");
    exit(2);
}
require $argv[3];
require $argv[1];

$assertions = 0;
function boundary_assert(bool $condition, string $message): void
{
    global $assertions;
    ++$assertions;
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

final class DesktopSchemaCoreBoundary extends DBmysql
{
    public array $present = ['glpi_plugin_glpichat_messages' => true];
    public bool $followupIndex = false;
    public array $ddl = [];
    public array $reads = [];
    public bool $rejectMetadata = false;
    public ?string $rejectCreate = null;
    public array $credentialRows = [];
    public array $sendRows = [];
    public array $readRows = [];

    public function __construct()
    {
        // Intentionally do not call parent: this test must never connect.
    }

    // The forbidden query() method is inherited unchanged from real GLPI.
    public function tableExists($tablename, $usecache = true)
    {
        return isset($this->present[$tablename]);
    }

    public function doQuery($query)
    {
        if (preg_match('/\ACREATE TABLE `([^`]+)`/', $query, $match) === 1) {
            if ($this->rejectCreate === $match[1]) { throw new RuntimeException('fixture CREATE interruption'); }
            boundary_assert(array_key_exists($match[1], glpichat_desktop_schema_definitions()), 'Unknown table in CREATE.');
            boundary_assert(!isset($this->present[$match[1]]), 'Attempted to recreate an existing table.');
            $this->ddl[] = $query;
            $this->present[$match[1]] = true;
            return true;
        }
        if ($query === 'ALTER TABLE `glpi_plugin_glpichat_messages` ADD KEY `desktop_followup_id` (`itilfollowups_id`)') {
            boundary_assert(!$this->followupIndex, 'Attempted to recreate an existing supporting index.');
            $this->ddl[] = $query;
            $this->followupIndex = true;
            return true;
        }
        boundary_assert(str_starts_with($query, 'SELECT '), 'Unexpected mutating SQL.');
        boundary_assert(str_contains($query, 'TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('), 'Metadata query must remain database/table bounded.');
        $kind = null;
        foreach (['TABLES' => 'tables', 'COLUMNS' => 'columns', 'STATISTICS' => 'indexes'] as $source => $destination) {
            if (str_contains($query, 'FROM information_schema.' . $source . ' WHERE ')) {
                $kind = $destination;
            }
        }
        boundary_assert($kind !== null, 'Unexpected metadata source.');
        $this->reads[] = $query;
        if ($this->rejectMetadata) {
            throw new RuntimeException('fixture metadata failure');
        }
        return (object) ['rows' => $this->metadata()[$kind], 'position' => 0];
    }

    public function fetchAssoc($result)
    {
        return $result->rows[$result->position++] ?? false;
    }

    private function metadata(): array
    {
        // Shapes are declared fixture rows; no SQL engine is being emulated.
        $result = ['tables' => [], 'columns' => [], 'indexes' => []];
        $definitions = glpichat_desktop_schema_definitions();
        $definitions['glpi_plugin_glpichat_messages'] = [
            'columns' => [],
            'indexes' => $this->followupIndex ? ['desktop_followup_id' => ['columns' => ['itilfollowups_id'], 'unique' => false]] : [],
        ];
        foreach ($definitions as $table => $definition) {
            if (!isset($this->present[$table])) {
                continue;
            }
            $result['tables'][] = ['TABLE_NAME' => $table, 'ENGINE' => 'InnoDB'];
            foreach ($definition['columns'] as $name => $column) {
                $result['columns'][] = [
                    'TABLE_NAME' => $table,
                    'COLUMN_NAME' => $name,
                    'COLUMN_TYPE' => str_replace(' ascii_bin', '', $column['type']),
                    'COLUMN_DEFAULT' => str_starts_with($column['extra'], 'DEFAULT ') ? substr($column['extra'], 8) : null,
                    'IS_NULLABLE' => $column['nullable'] ? 'YES' : 'NO',
                    'COLLATION_NAME' => str_contains($column['type'], 'ascii_bin') ? 'ascii_bin' : null,
                    'EXTRA' => $column['extra'] === 'AUTO_INCREMENT' ? 'auto_increment' : '',
                ];
            }
            foreach ($definition['indexes'] as $name => $index) {
                foreach ($index['columns'] as $position => $column) {
                    $result['indexes'][] = [
                        'TABLE_NAME' => $table, 'INDEX_NAME' => $name,
                        'NON_UNIQUE' => $index['unique'] ? 0 : 1,
                        'SEQ_IN_INDEX' => $position + 1, 'COLUMN_NAME' => $column, 'SUB_PART' => null,
                    ];
                }
            }
        }
        return $result;
    }
}

boundary_assert((new ReflectionMethod(DesktopSchemaCoreBoundary::class, 'query'))->getDeclaringClass()->getName() === DBmysql::class, 'The real core query guard must not be overridden.');
$config = [];
$writes = [];
$readConfig = static function (string $key) use (&$config): mixed { return $config[$key] ?? null; };
$writeConfig = static function (array $values) use (&$config, &$writes): void {
    $writes[] = $values;
    $config = array_replace($config, $values);
};
$DB = new DesktopSchemaCoreBoundary();

if ($argv[2] === 'legacy') {
    $caught = null;
    try {
        // Default table_exists, execute, and metadata_reader production callbacks.
        glpichat_desktop_schema_install(null, null, null, $readConfig, $writeConfig);
    } catch (Throwable $error) {
        $caught = $error;
    }
    boundary_assert($caught instanceof Exception && $caught->getMessage() === 'Executing direct queries is not allowed!', 'Legacy source must reproduce the exact real-core rejection.');
    boundary_assert(count($DB->ddl) === count(glpichat_desktop_schema_tables()), 'Legacy failure occurs after recording the supplied schema table creations.');
    boundary_assert($DB->reads === [], 'Legacy code must fail before supported metadata execution.');
    boundary_assert($writes === [], 'Legacy failure must occur before any configuration write.');
    echo "PASS legacy: supplied actual GLPI core query guard reproduced; $assertions assertions; no database connection or SQL execution.\n";
    exit(0);
}

$tables = glpichat_desktop_schema_tables();
$legacyTables = ['glpi_plugin_glpichat_desktopdevices', 'glpi_plugin_glpichat_desktopsends', 'glpi_plugin_glpichat_desktopreads'];
$scenarios = [
    'fresh' => [[], false, false],
    'partial new install' => [['glpi_plugin_glpichat_desktopgrants'], false, false],
    'existing schema1' => [$legacyTables, true, true],
    'interrupted schema1 upgrade' => [array_merge($legacyTables, ['glpi_plugin_glpichat_desktopgrants']), true, true],
    'existing schema2' => [array_slice($tables, 0, 5), true, false],
    'completed schema3' => [$tables, true, false],
];
foreach ($scenarios as $label => [$present, $hasIndex, $schema1]) {
    $DB = new DesktopSchemaCoreBoundary();
    foreach ($present as $table) { $DB->present[$table] = true; }
    $DB->followupIndex = $hasIndex;
    $DB->credentialRows = [['id' => 22, 'users_id' => 57, 'status' => 'completed', 'token_hash' => str_repeat('c', 64)]];
    $DB->sendRows = [['users_id' => 57, 'client_message_id' => 'eae2073f-8984-4559-ad99-1bf734832b08', 'itilfollowups_id' => 24]];
    $DB->readRows = [['users_id' => 57, 'itilfollowups_id' => 24]];
    $rowsBefore = [$DB->credentialRows, $DB->sendRows, $DB->readRows];
    $existingKey = str_repeat('b', 64);
    $config = $label === 'fresh' ? [] : ['desktop_enabled' => '1', 'desktop_idempotency_key' => $existingKey, 'desktop_schema_version' => $schema1 ? '1' : ($label === 'completed schema3' ? '3' : '2')];
    $writes = [];
    glpichat_desktop_schema_install(null, null, null, $readConfig, $writeConfig);
    $missing = array_values(array_diff($tables, $present));
    boundary_assert(count($DB->ddl) === count($missing) + ($hasIndex ? 0 : 1), $label . ': install creates only missing tables/index');
    foreach ($missing as $position => $table) {
        boundary_assert(str_starts_with($DB->ddl[$position], 'CREATE TABLE `' . $table . '`'), $label . ': migration does not recreate another table');
    }
    boundary_assert(count($DB->reads) === 6, $label . ': pre/postcondition metadata uses supported DB API');
    boundary_assert(end($writes) === ['desktop_schema_version' => '3'], $label . ': schema3 marker is last');
    boundary_assert($config['desktop_schema_version'] === '3', $label . ': complete readback records schema3');
    boundary_assert(preg_match('/\A[a-f0-9]{64}\z/', (string) ($config['desktop_idempotency_key'] ?? '')) === 1, $label . ': HMAC key stays valid');
    boundary_assert($config['desktop_enabled'] === ($label === 'fresh' ? '0' : '1'), $label . ': existing opt-in is retained');
    if ($label !== 'fresh') { boundary_assert($config['desktop_idempotency_key'] === $existingKey, $label . ': existing HMAC key is retained'); }
    boundary_assert([$DB->credentialRows, $DB->sendRows, $DB->readRows] === $rowsBefore, $label . ': credentials, send receipts and read state are untouched');
    $ddlCount = count($DB->ddl);
    $key = $config['desktop_idempotency_key'];
    glpichat_desktop_schema_install(null, null, null, $readConfig, $writeConfig);
    boundary_assert(count($DB->ddl) === $ddlCount, $label . ': repeated install issues no further DDL');
    boundary_assert($config['desktop_idempotency_key'] === $key, $label . ': repeated install retains key');
    boundary_assert(glpichat_desktop_schema_health(true, null, $readConfig)['healthy'], $label . ': complete result passes readback');
}

// Simulate a failure between the two new table creations during schema1 upgrade.
$DB = new DesktopSchemaCoreBoundary();
foreach ($legacyTables as $table) { $DB->present[$table] = true; }
$DB->followupIndex = true;
$DB->credentialRows = [['id' => 29, 'token_hash' => str_repeat('e', 64), 'status' => 'completed']];
$credentialBefore = $DB->credentialRows;
$DB->rejectCreate = 'glpi_plugin_glpichat_desktopregistrations';
$config = ['desktop_enabled' => '1', 'desktop_schema_version' => '1', 'desktop_idempotency_key' => str_repeat('f', 64)];
$writes = [];
$caught = null;
try { glpichat_desktop_schema_install(null, null, null, $readConfig, $writeConfig); }
catch (Throwable $error) { $caught = $error; }
boundary_assert($caught instanceof RuntimeException && $caught->getMessage() === 'fixture CREATE interruption', 'Actual default installer surfaces interrupted CREATE');
boundary_assert(count($DB->ddl) === 1 && isset($DB->present['glpi_plugin_glpichat_desktopgrants']), 'First new table remains available for retry');
boundary_assert($writes === [] && $config['desktop_schema_version'] === '1' && $DB->credentialRows === $credentialBefore, 'Interrupted upgrade preserves old completion marker and device credentials');
$DB->rejectCreate = null;
glpichat_desktop_schema_install(null, null, null, $readConfig, $writeConfig);
boundary_assert(count($DB->ddl) === 6 && $config['desktop_schema_version'] === '3' && $config['desktop_idempotency_key'] === str_repeat('f', 64), 'Retry creates only remaining table then completes without key rotation');
boundary_assert($DB->credentialRows === $credentialBefore, 'Retry preserves established credentials');

$DB->rejectMetadata = true;
$writes = [];
unset($config['desktop_schema_version']);
$caught = null;
try {
    glpichat_desktop_schema_install(null, null, null, $readConfig, $writeConfig);
} catch (Throwable $error) {
    $caught = $error;
}
boundary_assert($caught instanceof RuntimeException && $caught->getMessage() === 'fixture metadata failure', 'Supported metadata failures must still stop installation.');
boundary_assert($writes === [] && !isset($config['desktop_schema_version']), 'Metadata failure cannot write completion or replace configuration.');
boundary_assert(glpichat_desktop_schema_health(true, null, $readConfig)['issues'] === ['schema_metadata:unavailable'], 'Runtime metadata failure must remain fail-closed and opaque.');
echo "PASS fixed: real-core guard retained; default metadata/install callbacks; fresh, partial, schema1/schema2-to3 migration, interrupted upgrade, repeated and metadata-failure cases; $assertions assertions; no database connection or SQL execution.\n";
