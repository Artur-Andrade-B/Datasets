<?php
declare(strict_types=1);
/** Actual front/common/core CSRF logic; login/rights/router/management services are fixtures. */
namespace Symfony\Component\EventDispatcher { interface EventSubscriberInterface { public static function getSubscribedEvents(): array; } }
namespace Symfony\Component\HttpKernel { final class KernelEvents { public const CONTROLLER = 'kernel.controller'; } }
namespace Symfony\Component\HttpKernel\Exception { class AccessDeniedHttpException extends \RuntimeException { public function setMessageToDisplay(string $text): void {} } }
namespace Symfony\Component\HttpKernel\Event {
    final class ControllerEvent {
        public function __construct(private \Symfony\Component\HttpFoundation\Request $request) {}
        public function getRequest(): \Symfony\Component\HttpFoundation\Request { return $this->request; }
        public function isMainRequest(): bool { return true; }
    }
}
namespace Glpi\Http {
    final class SessionManager {
        public function isResourceStateless(\Symfony\Component\HttpFoundation\Request $request): bool {
            $path = $request->getPathInfo();
            $relative = substr($path, strpos($path, '/plugins/glpichat') + strlen('/plugins/glpichat'));
            return preg_match($GLOBALS['management_stateless_pattern'], $relative) === 1;
        }
    }
}
namespace {
    if (PHP_SAPI !== 'cli' || $argc < 5) { fwrite(STDERR, "Usage: desktop_management_front.php PLUGIN_ROOT AUTOLOAD CORE_CSRF_LISTENER CORE_SESSION [export]\n"); exit(2); }
    [$unused, $source, $autoload, $listenerPath, $sessionPath] = $argv;
    $worker = ($argv[5] ?? '') === 'export';
    require $autoload;
    if (hash_file('sha256', $listenerPath) !== '286dd203828520cd6f1acb6cb6c6d4c2b720f4129ace6fd2fc2ed3bf9ac81106'
        || hash_file('sha256', $sessionPath) !== '57e6ff9d5186635875cf3fb48a8a603ca24c313363e25348ef8ac224d23807c9') { throw new \RuntimeException('Unchanged GLPI11.0.7 core sources required.'); }
    class_alias(\Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException::class, 'AccessDeniedHttpException');
    define('READ', 1); define('UPDATE', 2);
    function __(string $text): string { return $text; }
    final class Toolbox { public static function logInFile(string $file, string $text): void {} }
    final class Config {
        public static string $schema = '3';
        public static function getConfigurationValues(string $context): array { return ['desktop_schema_version' => self::$schema, 'desktop_enabled' => '0', 'desktop_idempotency_key' => str_repeat('a', 64)]; }
    }
    final class Html {
        public static function header(string $title, string $self, string $category, string $item): void { echo '<!doctype html><html><body>'; }
        public static function footer(): void { echo '</body></html>'; }
    }
    $core = file_get_contents($sessionPath); $methods = '';
    foreach (['getNewCSRFToken', 'cleanCSRFTokens', 'validateCSRF', 'checkCSRF'] as $method) {
        $offset = strpos($core, 'public static function ' . $method . '(');
        if ($offset === false) { throw new \RuntimeException('Missing core method'); }
        $tokens = token_get_all('<?php ' . substr($core, $offset)); array_shift($tokens); $text = ''; $depth = 0; $opened = false;
        foreach ($tokens as $token) {
            $text .= is_array($token) ? $token[1] : $token;
            if ($token === '{') { ++$depth; $opened = true; }
            if ($token === '}' && --$depth === 0 && $opened) { break; }
        }
        if (!$opened || $depth !== 0) { throw new \RuntimeException('Core extraction failed'); }
        $methods .= $text . "\n";
    }
    eval('final class Session {
        private const CSRF_MAX_TOKENS = 500; public static bool $authenticated = true; public static bool $read = true; public static bool $write = true; public static array $rightsChecks = [];
        public static function haveRight(string $right, int $mask): bool { return self::$authenticated && $right === "plugin_glpichat_admin" && ($mask === READ ? self::$read : self::$write); }
        public static function checkRight(string $right, int $mask): void { self::$rightsChecks[] = [$right, $mask]; if (!self::haveRight($right, $mask)) { throw new AccessDeniedHttpException("Denied"); } }
        public static function getLoginUserID(): int { return self::$authenticated ? 7 : 0; }
    ' . $methods . '}');
    preg_match_all("/registerPluginStatelessPath\('glpichat', '([^']+)'\)/", file_get_contents($source . '/setup.php'), $patterns);
    $selected = array_values(array_filter($patterns[1], static fn(string $p): bool => str_contains($p, 'Management')));
    if (count($selected) !== 1) { throw new \RuntimeException('Expected one explicit machine API stateless pattern'); }
    $GLOBALS['management_stateless_pattern'] = $selected[0];
    require $listenerPath;
    $routes = new \Glpi\Http\SessionManager();
    $listener = new \Glpi\Kernel\Listener\ControllerListener\CheckCsrfListener($routes);
    $temporary = sys_get_temp_dir() . '/glpichat-management-front-' . bin2hex(random_bytes(8));
    $plugin = $temporary . '/plugins/glpichat';
    foreach ([$temporary . '/inc', $plugin . '/front', $plugin . '/src/desktop'] as $directory) { mkdir($directory, 0700, true); }
    define('GLPI_ROOT', $temporary);
    copy($source . '/front/desktop-management.php', $plugin . '/front/desktop-management.php');
    copy($source . '/src/desktop/common.php', $plugin . '/src/desktop/common.php');
    file_put_contents($temporary . '/inc/includes.php', '<?php // Core include fixture.');
    file_put_contents($plugin . '/src/desktop/management.php', <<<'FIXTURE'
<?php
require_once __DIR__ . '/common.php';
const GLPICHAT_MANAGEMENT_RELEASES = 'fixture_releases';
const GLPICHAT_MANAGEMENT_MACHINES = 'fixture_machines';
const GLPICHAT_MANAGEMENT_GRANTS = 'fixture_grants';
const GLPICHAT_MANAGEMENT_ASSIGNMENTS = 'fixture_assignments';
function glpichat_management_require_schema(): void { if (glpichat_desktop_config('desktop_schema_version') !== '3') { glpichat_desktop_fail('schema_unavailable', 'Schema pending', 503); } }
function glpichat_management_assign(int $machine, int $release, string $operation, int $admin): int {
    if ($machine === 999) { throw new RuntimeException('Controlled write failure'); }
    $GLOBALS['management_writes'][] = ['assign', $machine, $release, $operation, $admin]; return 5;
}
function glpichat_management_revoke(string $kind, int $id): void { $GLOBALS['management_writes'][] = ['revoke', $kind, $id]; }
function glpichat_management_deployment(string $url, string $root, int $uses, int $days, int $admin): array {
    $GLOBALS['management_writes'][] = ['export', $url, $root, $uses, $days, $admin];
    return ['schema' => 1, 'product' => 'glpichat-desktop', 'base_url' => $url, 'registration_secret' => 'EXPORT_ONLY_TEST_SECRET'];
}
FIXTURE);
    final class ManagementFrontDB {
        public array $snapshots = [];
        public function beginTransaction(): void { $this->snapshots[] = $GLOBALS['management_writes']; }
        public function commit(): void { array_pop($this->snapshots); }
        public function rollback(): void { $GLOBALS['management_writes'] = array_pop($this->snapshots); }
        public function doQuery(string $sql): object {
            $rows = [];
            if (str_contains($sql, 'fixture_releases')) { $rows = [['id' => 11, 'version' => '0.3.0', 'sequence' => 500]]; }
            elseif (str_contains($sql, 'fixture_machines')) { $rows = [['id' => 1, 'status' => 'active', 'computer_name' => '<script>fixture</script>', 'installation_id' => 'test-installation', 'current_version' => '0.2.0', 'bootstrap_version' => '0.3.0', 'last_seen' => null, 'health' => 'damaged', 'last_result' => 'failed', 'last_error' => 'missing_widget', 'token_hash' => 'HIDDEN_MACHINE_HASH']]; }
            elseif (str_contains($sql, 'fixture_grants')) { $rows = [['id' => 2, 'registration_id' => str_repeat('a', 32), 'expires_at' => '2099-01-01', 'used_count' => 1, 'max_uses' => 100, 'status' => 'issued', 'secret_hash' => 'HIDDEN_GRANT_HASH']]; }
            return (object)['rows' => $rows];
        }
        public function fetchAssoc(object $result): mixed { return array_shift($result->rows); }
    }
    $DB = new ManagementFrontDB(); $CFG_GLPI = ['root_doc' => '/glpi']; $_SESSION = ['glpiname' => 'fixture.admin'];
    $cleanup = static function () use ($temporary): void {
        if (!is_dir($temporary)) { return; }
        foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($temporary, \FilesystemIterator::SKIP_DOTS), \RecursiveIteratorIterator::CHILD_FIRST) as $entry) { $entry->isDir() ? rmdir($entry->getPathname()) : unlink($entry->getPathname()); }
        rmdir($temporary);
    };
    register_shutdown_function($cleanup);
    set_error_handler(static function(int $severity, string $message, string $file, int $line): bool { throw new \ErrorException($message, 0, $severity, $file, $line); });
    $run = static function(string $method, array $post = [], bool $read = true, bool $write = true, bool $login = true) use ($listener, $plugin): array {
        global $DB, $CFG_GLPI;
        Session::$authenticated = $login; Session::$read = $read; Session::$write = $write; Session::$rightsChecks = [];
        $GLOBALS['management_writes'] = []; $_GET = $_COOKIE = $_FILES = []; $_POST = $post;
        $_SERVER = ['REQUEST_METHOD' => $method, 'HTTPS' => 'off', 'SERVER_PORT' => 80, 'HTTP_HOST' => 'backend.internal', 'HTTP_X_FORWARDED_PROTO' => 'https', 'REQUEST_URI' => '/glpi/plugins/glpichat/front/desktop-management.php', 'SCRIPT_NAME' => '/glpi/index.php', 'SCRIPT_FILENAME' => '/srv/public/index.php', 'PHP_SELF' => '/glpi/index.php'];
        $request = \Symfony\Component\HttpFoundation\Request::createFromGlobals(); $blocked = false;
        ob_start();
        try { $listener->onKernelController(new \Symfony\Component\HttpKernel\Event\ControllerEvent($request)); include $plugin . '/front/desktop-management.php'; }
        catch (\Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException) { $blocked = true; }
        return ['html' => ob_get_clean(), 'blocked' => $blocked, 'writes' => $GLOBALS['management_writes'], 'rights' => Session::$rightsChecks];
    };
    if ($worker) {
        $exportToken = Session::getNewCSRFToken(true);
        register_shutdown_function(static function() use ($exportToken): void {
            $body = ob_get_level() > 0 ? ob_get_clean() : '';
            echo json_encode(['body' => $body, 'writes' => $GLOBALS['management_writes'], 'token_consumed' => !isset($_SESSION['glpicsrftokens'][$exportToken])], JSON_THROW_ON_ERROR);
        });
        $run('POST', ['action' => 'export', 'base_url' => 'http://lab.example/glpi', 'enrollment_root' => 'C:\\enrollment', 'max_uses' => '10', 'ttl_days' => '7', '_glpi_csrf_token' => $exportToken]);
        throw new \RuntimeException('Export did not terminate before HTML rendering');
    }
    $checks = 0;
    $check = static function(bool $condition, string $message) use (&$checks): void { ++$checks; if (!$condition) { throw new \RuntimeException($message); } };
    try {
        foreach (['/Desktop/V1/Me' => true, '/Management/V1/Poll' => true, '/front/desktop-management.php' => false, '/Management/V10/Poll' => false] as $path => $stateless) {
            $check($routes->isResourceStateless(\Symfony\Component\HttpFoundation\Request::create('/glpi/plugins/glpichat' . $path)) === $stateless, 'Production registration pattern isolates native API: ' . $path);
        }
        $page = $run('GET');
        $check(!$page['blocked'] && str_starts_with($page['html'], '<!doctype html>'), 'Existing GLPI root and authenticated management rendering work on backend HTTP');
        $check(str_contains($page['html'], 'name="_glpi_csrf_token"'), 'Writable forms carry standard core token');
        $check(!str_contains($page['html'], '<script>fixture') && str_contains($page['html'], '&lt;script&gt;fixture'), 'Machine-controlled names are HTML escaped');
        $check(!str_contains($page['html'], 'HIDDEN_') && !str_contains($page['html'], 'EXPORT_ONLY_TEST_SECRET'), 'Ordinary list does not expose credential fields or export secrets');
        $check(str_contains($page['html'], 'http://backend.internal/glpi'), 'HTTP lab root is a usable administrator-editable deployment default');
        $readonly = $run('GET', [], true, false);
        $check(!$readonly['blocked'] && !str_contains($readonly['html'], '<form') && str_contains($readonly['html'], 'Computadores'), 'Read-only administrators can inspect status without mutation forms');
        foreach ([[false, false, true], [true, true, false]] as [$read, $write, $login]) {
            $denied = $run('GET', [], $read, $write, $login);
            $check($denied['blocked'] && $denied['writes'] === [] && $denied['html'] === '', 'Missing read right or login blocks page before rendering');
        }
        $post = ['action' => 'assign', 'machine_ids' => ['2', '1', '2'], 'release_id' => '11', 'operation' => 'repair'];
        foreach ([[], ['_glpi_csrf_token' => 'wrong']] as $token) {
            $denied = $run('POST', $post + $token);
            $check($denied['blocked'] && $denied['writes'] === [] && $denied['rights'] === [], 'Missing or invalid core token is rejected before plugin rights/action');
        }
        $token = Session::getNewCSRFToken(true); $accepted = $run('POST', $post + ['_glpi_csrf_token' => $token]);
        $check(!$accepted['blocked'] && $accepted['writes'] === [['assign', 1, 11, 'repair', 7], ['assign', 2, 11, 'repair', 7]], 'Valid core token reaches sorted unique administrator-scoped assignments');
        $check(!isset($_SESSION['glpicsrftokens'][$token]), 'Core token is consumed once; plugin does not validate it a second time');
        $replay = $run('POST', $post + ['_glpi_csrf_token' => $token]);
        $check($replay['blocked'] && $replay['writes'] === [], 'Consumed token cannot replay an assignment');
        $denied = $run('POST', $post + ['_glpi_csrf_token' => Session::getNewCSRFToken(true)], true, false);
        $check($denied['blocked'] && $denied['writes'] === [], 'Read right does not authorize POST mutations');
        $failed = $run('POST', array_replace($post, ['machine_ids' => ['1', '999'], '_glpi_csrf_token' => Session::getNewCSRFToken(true)]));
        $check(!$failed['blocked'] && $failed['writes'] === [] && !$DB->snapshots, 'Bulk assignment wraps all services in one rollback boundary');
        $revoked = $run('POST', ['action' => 'revoke_machine', 'id' => '12', '_glpi_csrf_token' => Session::getNewCSRFToken(true)]);
        $check($revoked['writes'] === [['revoke', 'machine', 12]], 'Valid core token reaches machine revocation');
        Config::$schema = '2'; $old = $run('POST', $post + ['_glpi_csrf_token' => Session::getNewCSRFToken(true)]); Config::$schema = '3';
        $check($old['writes'] === [] && str_contains($old['html'], 'gestão de plugins'), 'Schema2 cannot mutate management state');
        $command = [PHP_BINARY, '-c', php_ini_loaded_file(), __FILE__, $source, $autoload, $listenerPath, $sessionPath, 'export'];
        $child = proc_open($command, [1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
        if (!is_resource($child)) { throw new \RuntimeException('Cannot start isolated export case'); }
        $stdout = stream_get_contents($pipes[1]); $stderr = stream_get_contents($pipes[2]); fclose($pipes[1]); fclose($pipes[2]); $exit = proc_close($child);
        $check($exit === 0 && $stderr === '', 'Isolated actual export branch exits cleanly: ' . $stderr);
        $export = json_decode($stdout, true, 512, JSON_THROW_ON_ERROR); $body = json_decode($export['body'], true, 512, JSON_THROW_ON_ERROR);
        $check($export['token_consumed'] && $body['registration_secret'] === 'EXPORT_ONLY_TEST_SECRET' && !str_contains($export['body'], '<html>'), 'POST export emits only JSON after core token consumption');
        $check($export['writes'] === [['export', 'http://lab.example/glpi', 'C:\\enrollment', 10, 7, 7]], 'Export passes explicit HTTP root and bounds to administrator service');
        echo "PASS management front: $checks assertions; actual front/common/GLPI11 CSRF logic/Symfony Request, explicit rights/router/service/SQL fixtures; no deployed GLPI HTTP execution.\n";
    } finally { restore_error_handler(); $cleanup(); }
}
