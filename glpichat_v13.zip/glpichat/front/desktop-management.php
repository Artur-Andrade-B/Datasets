<?php

declare(strict_types=1);

// Sessionful GLPI11 legacy page: core CheckCsrfListener validates and consumes
// every POST token before execution. Never register this front path stateless.
if (!defined('GLPI_ROOT')) { define('GLPI_ROOT', dirname(__DIR__, 3)); }
include GLPI_ROOT . '/inc/includes.php';
require_once dirname(__DIR__) . '/src/desktop/management.php';
Session::checkRight('plugin_glpichat_admin', READ);
glpichat_desktop_reset_request_context();
header('Cache-Control: no-store, private');
header('Referrer-Policy: no-referrer');
header('X-Content-Type-Options: nosniff');
$escape = static fn (mixed $value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$text = static fn (array $input, string $key): string => isset($input[$key]) && is_string($input[$key]) ? $input[$key] : '';
$integer = static function (array $input, string $key): int {
    $value = $input[$key] ?? '';
    if (!is_string($value) || preg_match('/\A[0-9]{1,10}\z/D', $value) !== 1) { glpichat_desktop_fail('invalid_request', 'Número inválido.', 400); }
    return (int) $value;
};
$error = ''; $message = '';
try {
    glpichat_management_require_schema();
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        Session::checkRight('plugin_glpichat_admin', UPDATE);
        $adminId = (int) Session::getLoginUserID();
        if ($adminId < 1) { throw new RuntimeException('Administrator required.'); }
        $action = $text($_POST, 'action');
        if ($action === 'import') {
            $file = $_FILES['release'] ?? [];
            if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_string($file['tmp_name'] ?? null) || !is_uploaded_file($file['tmp_name'])) {
                glpichat_desktop_fail('upload_failed', 'Selecione o ZIP da versão. Verifique os limites de upload do PHP se necessário.', 400);
            }
            $release = glpichat_management_import($file['tmp_name'], $adminId);
            $message = 'Versão ' . $release['version'] . ' importada. Selecione os computadores para atualizar.';
        } elseif ($action === 'export') {
            $deployment = glpichat_management_deployment($text($_POST, 'base_url'), $text($_POST, 'enrollment_root'), $integer($_POST, 'max_uses'), $integer($_POST, 'ttl_days'), $adminId);
            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename="deployment.json"');
            echo json_encode($deployment, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
            exit;
        } elseif ($action === 'assign') {
            $machines = $_POST['machine_ids'] ?? [];
            if (!is_array($machines) || !array_is_list($machines) || !$machines || count($machines) > 200) { glpichat_desktop_fail('invalid_request', 'Selecione até 200 computadores.', 400); }
            $ids = [];
            foreach ($machines as $id) { $ids[] = $integer(['id' => $id], 'id'); }
            $ids = array_values(array_unique($ids)); sort($ids, SORT_NUMERIC);
            $releaseId = $integer($_POST, 'release_id'); $operation = $text($_POST, 'operation');
            glpichat_desktop_transaction(static function () use ($ids, $releaseId, $operation, $adminId): void {
                foreach ($ids as $id) { glpichat_management_assign($id, $releaseId, $operation, $adminId); }
            });
            $message = 'Solicitação registrada. Os computadores conectados verificam atualizações a cada minuto.';
        } elseif ($action === 'revoke_machine' || $action === 'revoke_registration') {
            glpichat_management_revoke($action === 'revoke_machine' ? 'machine' : 'registration', $integer($_POST, 'id'));
            $message = $action === 'revoke_machine' ? 'Gerenciamento desta máquina revogado.' : 'Novos registros e tentativas de registro com este arquivo foram revogados. As máquinas já registradas permanecem gerenciadas.';
        } else { glpichat_desktop_fail('invalid_request', 'Ação inválida.', 400); }
    }
} catch (GlpichatDesktopException $e) {
    $error = $e->getMessage();
} catch (\Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException $e) {
    throw $e;
} catch (Throwable $e) {
    $reference = glpichat_desktop_log_failure('management_admin', $e);
    $error = 'Não foi possível concluir a operação. Referência para os logs: ' . $reference . '.';
}

Html::header('GLPI Chat — Desktop Windows', $_SERVER['PHP_SELF'], 'config', 'plugins');
echo '<div class="container-fluid"><h1>Desktop Windows</h1>';
echo '<p>Importe uma versão do aplicativo, solicite atualizações ou reparos e acompanhe o resultado informado por cada computador.</p>';
if ($error !== '') { echo '<div class="alert alert-danger">' . $escape($error) . '</div>'; }
if ($message !== '') { echo '<div class="alert alert-success">' . $escape($message) . '</div>'; }
if ((string) glpichat_desktop_config('desktop_schema_version') !== '3') {
    echo '<p>Conclua a atualização do plugin pela gestão de plugins do GLPI.</p></div>'; Html::footer(); return;
}
$canUpdate = Session::haveRight('plugin_glpichat_admin', UPDATE);
$csrf = static function () use ($escape): string { return '<input type="hidden" name="_glpi_csrf_token" value="' . $escape(Session::getNewCSRFToken()) . '">'; };
try {
    $releases = glpichat_desktop_db_rows('SELECT * FROM ' . GLPICHAT_MANAGEMENT_RELEASES . ' ORDER BY sequence DESC LIMIT 200');
    $machines = glpichat_desktop_db_rows('SELECT * FROM ' . GLPICHAT_MANAGEMENT_MACHINES . ' ORDER BY id DESC LIMIT 200');
    $grants = glpichat_desktop_db_rows('SELECT id,registration_id,status,expires_at,max_uses,used_count,created_at FROM ' . GLPICHAT_MANAGEMENT_GRANTS . ' ORDER BY id DESC LIMIT 50');
    $assignments = glpichat_desktop_db_rows('SELECT * FROM ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' ORDER BY id DESC LIMIT 1000');
} catch (Throwable $e) {
    $reference = glpichat_desktop_log_failure('management_admin_list', $e);
    echo '<div class="alert alert-danger">Não foi possível consultar o gerenciamento. Referência: ' . $escape($reference) . '.</div></div>'; Html::footer(); return;
}
$latest = [];
foreach ($assignments as $assignment) { $latest[(int) $assignment['machines_id']] ??= $assignment; }
$versions = [];
foreach ($releases as $release) { $versions[(int) $release['id']] = $release['version']; }
if ($canUpdate) {
    echo '<div class="row"><section class="col-lg-6"><h2>Importar versão</h2><form method="post" enctype="multipart/form-data">' . $csrf();
    echo '<input type="hidden" name="action" value="import"><label for="desktop-release">ZIP de versão desktop</label><input class="form-control" id="desktop-release" type="file" name="release" accept=".zip" required>';
    echo '<p class="form-text">Use o ZIP de versão com release.json, Agent e Widget. A importação valida os arquivos e autoriza a assinatura desta instância. O bootstrap estável é atualizado pelo instalador administrativo.</p><button class="btn btn-primary">Importar versão</button></form></section>';
    $baseUrl = '';
    try { $baseUrl = glpichat_desktop_base_url(); } catch (Throwable $e) { /* Administrator may enter externally visible root. */ }
    echo '<section class="col-lg-6"><h2>Preparar implantação</h2><form method="post">' . $csrf() . '<input type="hidden" name="action" value="export">';
    echo '<label for="deployment-url">Endereço do GLPI usado pelos computadores</label><input class="form-control" id="deployment-url" name="base_url" value="' . $escape($baseUrl) . '" required maxlength="2048">';
    echo '<label for="enrollment-root">Pasta de provisionamento de usuários (opcional)</label><input class="form-control" id="enrollment-root" name="enrollment_root" maxlength="1024" placeholder="C:\\ProgramData\\G4F\\GLPIChat\\enrollment ou compartilhamento UNC">';
    echo '<label for="registration-limit">Número máximo de computadores</label><input class="form-control" id="registration-limit" name="max_uses" type="number" min="1" max="10000" value="100" required>';
    echo '<label for="registration-days">Validade em dias</label><input class="form-control" id="registration-days" name="ttl_days" type="number" min="1" max="30" value="7" required>';
    echo '<p class="form-text">O arquivo deployment.json contém um segredo temporário para o administrador usar na instalação ou atualização inicial. Ele registra a máquina para manutenção; o acesso ao chat usa o provisionamento de usuários existente.</p><button class="btn btn-primary">Baixar deployment.json</button></form></section></div><hr>';
}
echo '<h2>Computadores</h2><p class="text-muted">Até 200 registros recentes. As datas são UTC. Um computador sem contato recente não confirmou a conclusão da operação.</p>';
if ($canUpdate) { echo '<form method="post" id="desktop-assignment">' . $csrf() . '<input type="hidden" name="action" value="assign">'; }
echo '<div class="table-responsive"><table class="table"><thead><tr><th>Selecionar</th><th>Computador</th><th>Versão / bootstrap</th><th>Último contato UTC</th><th>Saúde / resultado</th><th>Solicitação</th><th>Registro</th></tr></thead><tbody>';
foreach ($machines as $machine) {
    $id = (int) $machine['id']; $assignment = $latest[$id] ?? [];
    echo '<tr><td>' . ($canUpdate && $machine['status'] === 'active' ? '<input type="checkbox" name="machine_ids[]" value="' . $id . '" aria-label="Selecionar ' . $escape($machine['computer_name']) . '">' : '') . '</td>';
    echo '<td>' . $escape($machine['computer_name']) . '<br><small>' . $escape($machine['installation_id']) . '</small></td>';
    echo '<td>' . $escape($machine['current_version'] ?: 'Não informada') . ' / ' . $escape($machine['bootstrap_version']) . '</td><td>' . $escape($machine['last_seen'] ?? 'Nunca') . '</td>';
    echo '<td>' . $escape($machine['health']) . ' / ' . $escape($machine['last_result']) . '<br><small>' . $escape($machine['last_error']) . '</small></td>';
    echo '<td>' . ($assignment ? $escape(($versions[(int) $assignment['releases_id']] ?? '?') . ' — ' . $assignment['action'] . ' — ' . $assignment['status']) : 'Nenhuma') . '</td>';
    echo '<td>' . $escape($machine['status']);
    if ($canUpdate && $machine['status'] === 'active') { echo '<br><button class="btn btn-sm btn-outline-danger" form="revoke-machine-' . $id . '">Revogar máquina</button>'; }
    echo '</td></tr>';
}
echo '</tbody></table></div>';
if ($canUpdate) {
    echo '<label for="assignment-release">Versão para os computadores selecionados</label><select class="form-select" id="assignment-release" name="release_id" required><option value="">Selecione</option>';
    foreach ($releases as $release) { echo '<option value="' . (int) $release['id'] . '">' . $escape($release['version']) . ' — sequência ' . $escape($release['sequence']) . '</option>'; }
    echo '</select><label for="assignment-action">Operação</label><select class="form-select" id="assignment-action" name="operation"><option value="update">Atualizar</option><option value="repair">Reparar (autoriza tentar novamente esta versão)</option></select><p class="form-text">Reparar permite recuperar arquivos ausentes ou uma tentativa que falhou. A conclusão depende da verificação e do relatório do computador.</p><button class="btn btn-primary">Solicitar operação</button></form>';
    foreach ($machines as $machine) {
        if ($machine['status'] !== 'active') { continue; }
        echo '<form method="post" id="revoke-machine-' . (int) $machine['id'] . '">' . $csrf() . '<input type="hidden" name="action" value="revoke_machine"><input type="hidden" name="id" value="' . (int) $machine['id'] . '"></form>';
    }
}
echo '<hr><h2>Arquivos de implantação emitidos</h2><p>Revogar um arquivo impede novos registros. Para interromper o gerenciamento de uma máquina já registrada, revogue a máquina acima.</p><table class="table"><thead><tr><th>Identificador</th><th>Validade UTC</th><th>Usos</th><th>Estado</th></tr></thead><tbody>';
foreach ($grants as $grant) {
    echo '<tr><td>' . $escape($grant['registration_id']) . '</td><td>' . $escape($grant['expires_at']) . '</td><td>' . (int) $grant['used_count'] . ' / ' . (int) $grant['max_uses'] . '</td><td>' . $escape($grant['status']);
    if ($canUpdate && $grant['status'] === 'issued') { echo '<form method="post">' . $csrf() . '<input type="hidden" name="action" value="revoke_registration"><input type="hidden" name="id" value="' . (int) $grant['id'] . '"><button class="btn btn-sm btn-outline-danger">Revogar arquivo</button></form>'; }
    echo '</td></tr>';
}
echo '</tbody></table></div>';
Html::footer();
