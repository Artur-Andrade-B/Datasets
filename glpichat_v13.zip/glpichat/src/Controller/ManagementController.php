<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpichat\Controller;

use Glpi\Controller\AbstractController;
use Glpi\Http\Firewall;
use Glpi\Security\Attribute\SecurityStrategy;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

require_once dirname(__DIR__) . '/desktop/management.php';

/** Machine credentials are independent of GLPI sessions and user chat tokens. */
final class ManagementController extends AbstractController
{
    #[Route('/Management/V1/{operation}', name: 'glpichat_management_v1', requirements: ['operation' => '.+'], methods: ['GET', 'POST'])]
    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]
    public function dispatch(Request $request, string $operation): Response
    {
        \glpichat_desktop_reset_request_context();
        $stage = 'management_request';
        try {
            \glpichat_management_require_schema();
            // Real method only; a browser override must never turn a GET into mutation.
            $method = $request->getRealMethod();
            if ($method === 'POST' && $operation === 'Register') {
                $stage = 'management_register';
                $result = \glpichat_management_register(\glpichat_desktop_json_body($request));
            } else {
                $token = \glpichat_desktop_bearer($request);
                $installation = (string) $request->headers->get('X-GLPIChat-Installation', '');
                if ($method === 'POST' && $operation === 'Poll') {
                    $stage = 'management_poll';
                    $result = \glpichat_management_poll($token, $installation, \glpichat_desktop_json_body($request));
                } elseif ($method === 'GET' && preg_match('~\AArtifact/([1-9][0-9]{0,9})/(GLPIChat\.(?:Agent|Widget)\.exe)\z~D', $operation, $match) === 1) {
                    $stage = 'management_artifact';
                    $path = \glpichat_management_artifact($token, $installation, (int) $match[1], $match[2]);
                    $response = new BinaryFileResponse($path);
                    $response->headers->set('Content-Type', 'application/octet-stream');
                    $response->headers->set('Content-Disposition', 'attachment; filename="' . $match[2] . '"');
                    return $this->headers($response);
                } else {
                    \glpichat_desktop_fail('not_found', 'Operação indisponível.', 404);
                }
            }
            $response = new JsonResponse($result);
        } catch (\GlpichatDesktopException $error) {
            $response = new JsonResponse(['error' => ['code' => $error->errorCode, 'message' => $error->getMessage()]], $error->httpStatus);
        } catch (\Symfony\Component\HttpFoundation\Exception\RequestExceptionInterface $error) {
            $response = new JsonResponse(['error' => ['code' => 'invalid_request', 'message' => 'Solicitação inválida.']], 400);
        } catch (\Throwable $error) {
            $reference = \glpichat_desktop_log_failure($stage, $error);
            $response = new JsonResponse(['error' => ['code' => 'temporarily_unavailable', 'message' => 'Serviço indisponível. Referência: ' . $reference . '.']], 503);
        }
        return $this->headers($response);
    }

    private function headers(Response $response): Response
    {
        $response->headers->set('Cache-Control', 'no-store, private');
        $response->headers->set('Pragma', 'no-cache');
        $response->headers->set('X-Content-Type-Options', 'nosniff');
        $response->headers->set('Referrer-Policy', 'no-referrer');
        $response->headers->set('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'");
        if ($response->getStatusCode() === 401) { $response->headers->set('WWW-Authenticate', 'Bearer realm="GLPIChat Management"'); }
        if ($response->getStatusCode() === 503) { $response->headers->set('Retry-After', '15'); }
        return $response;
    }
}
