<?php

declare(strict_types=1);

require_once __DIR__ . '/common.php';

const GLPICHAT_MANAGEMENT_RELEASES = 'glpi_plugin_glpichat_desktopreleases';
const GLPICHAT_MANAGEMENT_GRANTS = 'glpi_plugin_glpichat_desktopmachinegrants';
const GLPICHAT_MANAGEMENT_MACHINES = 'glpi_plugin_glpichat_desktopmachines';
const GLPICHAT_MANAGEMENT_ASSIGNMENTS = 'glpi_plugin_glpichat_desktopassignments';
const GLPICHAT_MANAGEMENT_MAX_FILE = 16777216;
const GLPICHAT_MANAGEMENT_MAX_ZIP = 34603008;

function glpichat_management_require_schema(): void
{
    if ((string) glpichat_desktop_config('desktop_schema_version') !== '3') {
        glpichat_desktop_fail('schema_unavailable', 'Conclua a atualização do plugin para administrar o Windows.', 503);
    }
}

function glpichat_management_one(string $table, string $where, bool $lock = false): array
{
    $rows = glpichat_desktop_db_rows('SELECT * FROM ' . $table . ' WHERE ' . $where . ' LIMIT 1' . ($lock ? ' FOR UPDATE' : ''));
    return $rows[0] ?? [];
}

function glpichat_management_write(string $table, array $values, ?array $where = null): int
{
    global $DB;
    $ok = $where === null ? $DB->insert($table, $values) : $DB->update($table, $values, $where);
    if (!$ok) { throw new RuntimeException('Management storage failed.'); }
    return $where === null ? (int) $DB->insertId() : 0;
}

function glpichat_management_hex(array $input, string $key, int $length = 64): string
{
    $value = glpichat_desktop_string($input, $key, $length);
    if (preg_match('/\A[a-f0-9]{' . $length . '}\z/D', $value) !== 1) {
        glpichat_desktop_fail('invalid_request', 'Credencial inválida.', 400);
    }
    return $value;
}

function glpichat_management_uuid(string $value): string
{
    if (preg_match('/\A[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}\z/D', $value) !== 1) {
        glpichat_desktop_fail('invalid_request', 'Identificador de instalação inválido.', 400);
    }
    return $value;
}

function glpichat_management_hash(string $purpose, string $value): string
{
    return hash('sha256', "glpichat-management-v1\0" . $purpose . "\0" . $value);
}

function glpichat_management_text(array $input, string $key, int $maximum): string
{
    $value = glpichat_desktop_string($input, $key, $maximum);
    if (preg_match('/[\x00-\x1f\x7f]/', $value)) {
        glpichat_desktop_fail('invalid_request', 'Texto inválido.', 400);
    }
    return $value;
}

/** Core's plugin document directory is protected storage, never an artifact URL. */
function glpichat_management_storage(): string
{
    if (!defined('GLPI_PLUGIN_DOC_DIR')) { throw new RuntimeException('GLPI plugin storage unavailable.'); }
    $base = rtrim(GLPI_PLUGIN_DOC_DIR, '/\\');
    if (is_link($base)) { throw new RuntimeException('Management storage must not be a symlink.'); }
    foreach ([$base, $base . '/glpichat', $base . '/glpichat/management'] as $directory) {
        if (is_link($directory) || (!is_dir($directory) && !mkdir($directory, 0700, true))) {
            throw new RuntimeException('Management storage unavailable.');
        }
    }
    $path = $base . '/glpichat/management';
    if (!chmod($path, 0700)) { throw new RuntimeException('Management storage permissions failed.'); }
    if (defined('GLPI_ROOT')) {
        $public = realpath(GLPI_ROOT . '/public');
        $real = realpath($path);
        if ($public !== false && $real !== false && ($real === $public || str_starts_with($real, $public . DIRECTORY_SEPARATOR))) {
            throw new RuntimeException('Management storage must be outside the public document root.');
        }
    }
    return $path;
}

function glpichat_management_storage_lock(callable $action): mixed
{
    $path = glpichat_management_storage();
    $lockPath = $path . '/management.lock';
    if (is_link($lockPath)) { throw new RuntimeException('Invalid storage lock.'); }
    $lock = fopen($lockPath, 'c+b');
    if ($lock === false) { throw new RuntimeException('Storage lock unavailable.'); }
    try {
        if (!chmod($lockPath, 0600) || !flock($lock, LOCK_EX)) { throw new RuntimeException('Storage lock failed.'); }
        return $action($path);
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
}

function glpichat_management_file(string $path, string $bytes): void
{
    $handle = fopen($path, 'x+b');
    if ($handle === false) { throw new RuntimeException('Artifact write failed.'); }
    try {
        if (!chmod($path, 0600)) { throw new RuntimeException('Artifact permissions failed.'); }
        $written = 0;
        while ($written < strlen($bytes)) {
            $part = fwrite($handle, substr($bytes, $written));
            if ($part === false || $part === 0) { throw new RuntimeException('Artifact write incomplete.'); }
            $written += $part;
        }
        if (!fflush($handle) || (function_exists('fsync') && !fsync($handle))) { throw new RuntimeException('Artifact flush failed.'); }
    } finally { fclose($handle); }
}

/** Called while storage lock is held. Never silently replace a lost signing key. */
function glpichat_management_signing_key(string $storage): OpenSSLAsymmetricKey
{
    if (!extension_loaded('openssl')) { glpichat_desktop_fail('openssl_required', 'Ative a extensão OpenSSL do PHP.', 503); }
    $path = $storage . '/instance-signing.pem';
    if (is_link($path)) { throw new RuntimeException('Invalid signing key path.'); }
    if (!is_file($path)) {
        foreach ([GLPICHAT_MANAGEMENT_RELEASES, GLPICHAT_MANAGEMENT_MACHINES, GLPICHAT_MANAGEMENT_GRANTS] as $table) {
            if (glpichat_desktop_db_rows('SELECT id FROM ' . $table . ' LIMIT 1')) {
                glpichat_desktop_fail('signing_key_missing', 'Restaure a chave de assinatura protegida do backup do GLPI.', 503);
            }
        }
        $key = openssl_pkey_new(['private_key_bits' => 2048, 'private_key_type' => OPENSSL_KEYTYPE_RSA]);
        if ($key === false || !openssl_pkey_export($key, $pem)) { throw new RuntimeException('Signing key generation failed.'); }
        glpichat_management_file($path, $pem);
    }
    if (!chmod($path, 0600)) { throw new RuntimeException('Signing key permissions failed.'); }
    $pem = file_get_contents($path);
    $key = is_string($pem) ? openssl_pkey_get_private($pem) : false;
    $details = $key === false ? false : openssl_pkey_get_details($key);
    if ($key === false || $details === false || ($details['type'] ?? -1) !== OPENSSL_KEYTYPE_RSA || ($details['bits'] ?? 0) < 2048) {
        throw new RuntimeException('Invalid signing key.');
    }
    return $key;
}

function glpichat_management_public_key(OpenSSLAsymmetricKey $key): string
{
    $details = openssl_pkey_get_details($key);
    if (!is_array($details) || !isset($details['rsa']['n'], $details['rsa']['e'])) { throw new RuntimeException('Invalid RSA public key.'); }
    return '<RSAKeyValue><Modulus>' . base64_encode($details['rsa']['n']) . '</Modulus><Exponent>' . base64_encode($details['rsa']['e']) . '</Exponent></RSAKeyValue>';
}

/** Read exact bounded entries; never extract an archive into the filesystem. */
function glpichat_management_release_bytes(string $zipPath): array
{
    if (!class_exists(ZipArchive::class)) { glpichat_desktop_fail('zip_required', 'Ative a extensão ZIP do PHP.', 503); }
    if (!is_file($zipPath) || filesize($zipPath) > GLPICHAT_MANAGEMENT_MAX_ZIP) {
        glpichat_desktop_fail('release_invalid', 'Arquivo de versão inválido ou muito grande.', 400);
    }
    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::RDONLY) !== true) { glpichat_desktop_fail('release_invalid', 'ZIP inválido.', 400); }
    try {
        $allowed = ['release.json' => 16384, 'GLPIChat.Agent.exe' => GLPICHAT_MANAGEMENT_MAX_FILE, 'GLPIChat.Widget.exe' => GLPICHAT_MANAGEMENT_MAX_FILE];
        if ($zip->numFiles !== 3) { glpichat_desktop_fail('release_invalid', 'O ZIP deve conter somente o manifesto e os dois componentes.', 400); }
        $entries = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            $name = is_array($stat) ? ($stat['name'] ?? '') : '';
            if (!isset($allowed[$name]) || isset($entries[$name]) || ($stat['size'] ?? 0) < 1 || $stat['size'] > $allowed[$name] || ($stat['encryption_method'] ?? 0) !== 0) {
                glpichat_desktop_fail('release_invalid', 'Conteúdo de ZIP inválido.', 400);
            }
            if ($zip->getExternalAttributesIndex($i, $opsys, $attributes) && (($attributes >> 16) & 0170000) === 0120000) {
                glpichat_desktop_fail('release_invalid', 'Links não são permitidos no ZIP.', 400);
            }
            $bytes = $zip->getFromIndex($i, (int) $stat['size']);
            if (!is_string($bytes) || strlen($bytes) !== $stat['size']) { glpichat_desktop_fail('release_invalid', 'Entrada de ZIP incompleta.', 400); }
            $entries[$name] = $bytes;
        }
        try { $metadata = json_decode($entries['release.json'], true, 12, JSON_THROW_ON_ERROR); }
        catch (JsonException $e) { glpichat_desktop_fail('release_invalid', 'Manifesto JSON inválido.', 400); }
        if (!is_array($metadata) || ($metadata['schema'] ?? null) !== 1 || ($metadata['product'] ?? '') !== 'glpichat-desktop'
            || !is_string($metadata['version'] ?? null) || strlen($metadata['version']) > 32 || preg_match('/\A[0-9]+\.[0-9]+\.[0-9]+\z/D', $metadata['version']) !== 1
            || !is_array($metadata['files'] ?? null) || !array_is_list($metadata['files']) || count($metadata['files']) !== 2) {
            glpichat_desktop_fail('release_invalid', 'Manifesto de versão inválido.', 400);
        }
        $components = [];
        foreach (['agent' => 'GLPIChat.Agent.exe', 'widget' => 'GLPIChat.Widget.exe'] as $role => $filename) {
            $matches = array_values(array_filter($metadata['files'], static fn ($f): bool => is_array($f) && ($f['role'] ?? '') === $role));
            $f = $matches[0] ?? [];
            $bytes = $entries[$filename];
            if (count($matches) !== 1 || ($f['filename'] ?? '') !== $filename || !is_int($f['size'] ?? null) || $f['size'] !== strlen($bytes)
                || !is_string($f['sha256'] ?? null) || !hash_equals(hash('sha256', $bytes), $f['sha256']) || strlen($bytes) < 128 || substr($bytes, 0, 2) !== 'MZ') {
                glpichat_desktop_fail('release_invalid', 'Tamanho, hash ou executável inválido.', 400);
            }
            $pe = unpack('Voffset', substr($bytes, 60, 4))['offset'];
            if ($pe < 64 || $pe > strlen($bytes) - 24 || substr($bytes, $pe, 4) !== "PE\0\0") { glpichat_desktop_fail('release_invalid', 'Cabeçalho PE inválido.', 400); }
            $components[] = ['role' => $role, 'filename' => $filename, 'size' => strlen($bytes), 'sha256' => hash('sha256', $bytes)];
        }
        return ['version' => $metadata['version'], 'components' => $components, 'entries' => $entries];
    } finally { $zip->close(); }
}

function glpichat_management_import(string $zipPath, int $adminId): array
{
    glpichat_management_require_schema();
    $release = glpichat_management_release_bytes($zipPath);
    return glpichat_management_storage_lock(static function (string $storage) use ($release, $adminId): array {
        $key = glpichat_management_signing_key($storage);
        $directory = '';
        try {
            return glpichat_desktop_transaction(static function () use ($storage, $release, $adminId, $key, &$directory): array {
                if (glpichat_management_one(GLPICHAT_MANAGEMENT_RELEASES, 'version=' . glpichat_desktop_quote($release['version']))) {
                    glpichat_desktop_fail('release_exists', 'Esta versão já foi importada. Publique uma versão nova.', 409);
                }
                $maxRelease = glpichat_desktop_db_rows('SELECT sequence FROM ' . GLPICHAT_MANAGEMENT_RELEASES . ' ORDER BY sequence DESC LIMIT 1')[0]['sequence'] ?? 0;
                $maxMachine = glpichat_desktop_db_rows('SELECT current_sequence FROM ' . GLPICHAT_MANAGEMENT_MACHINES . ' ORDER BY current_sequence DESC LIMIT 1')[0]['current_sequence'] ?? 0;
                $sequence = max((int) floor(microtime(true) * 1000), (int) $maxRelease + 1, (int) $maxMachine + 1);
                if ($sequence <= 0 || $sequence >= PHP_INT_MAX) { throw new RuntimeException('Release sequence exhausted.'); }
                $manifest = json_encode(['schema' => 1, 'product' => 'glpichat-desktop', 'version' => $release['version'], 'sequence' => $sequence,
                    'platform' => 'windows', 'architecture' => 'x64', 'bootstrap_abi' => 1, 'state_schema_min' => 1, 'state_schema_max' => 1, 'components' => $release['components']], JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
                if (!openssl_sign($manifest, $signature, $key, OPENSSL_ALGO_SHA256)) { throw new RuntimeException('Manifest signing failed.'); }
                $storageKey = bin2hex(random_bytes(16));
                $newDirectory = $storage . '/' . $storageKey;
                if (!mkdir($newDirectory, 0700)) { throw new RuntimeException('Release directory failed.'); }
                $directory = $newDirectory;
                foreach ($release['components'] as $file) { glpichat_management_file($directory . '/' . $file['filename'], $release['entries'][$file['filename']]); }
                $id = glpichat_management_write(GLPICHAT_MANAGEMENT_RELEASES, ['version' => $release['version'], 'sequence' => $sequence, 'manifest_json' => $manifest,
                    'signature' => base64_encode($signature), 'storage_key' => $storageKey, 'created_at' => glpichat_desktop_now(), 'created_by' => $adminId]);
                return ['id' => $id, 'version' => $release['version'], 'sequence' => $sequence];
            });
        } catch (Throwable $e) {
            if ($directory !== '') { foreach (['GLPIChat.Agent.exe', 'GLPIChat.Widget.exe'] as $name) { if (is_file($directory . '/' . $name)) { unlink($directory . '/' . $name); } } if (is_dir($directory)) { rmdir($directory); } }
            throw $e;
        }
    });
}

function glpichat_management_deployment(string $baseUrl, string $enrollmentRoot, int $maxUses, int $ttlDays, int $adminId): array
{
    glpichat_management_require_schema();
    $parts = parse_url($baseUrl);
    if (!is_array($parts) || !in_array($parts['scheme'] ?? '', ['http', 'https'], true) || empty($parts['host']) || isset($parts['user'], $parts['pass']) || isset($parts['user']) || isset($parts['query']) || isset($parts['fragment'])
        || preg_match('/[\x00-\x20\x7f\\\\]/', $baseUrl) || preg_match('~(?:^|/)\.{1,2}(?:/|$)~', rawurldecode($parts['path'] ?? '')) || strlen($baseUrl) > 2048
        || strlen($enrollmentRoot) > 1024 || preg_match('/[\x00-\x1f\x7f]/', $enrollmentRoot) || $maxUses < 1 || $maxUses > 10000 || $ttlDays < 1 || $ttlDays > 30) {
        glpichat_desktop_fail('invalid_request', 'Endereço, prazo ou limite de instalações inválido.', 400);
    }
    return glpichat_management_storage_lock(static function (string $storage) use ($baseUrl, $enrollmentRoot, $maxUses, $ttlDays, $adminId): array {
        $public = glpichat_management_public_key(glpichat_management_signing_key($storage));
        $id = bin2hex(random_bytes(16)); $secret = bin2hex(random_bytes(32));
        glpichat_management_write(GLPICHAT_MANAGEMENT_GRANTS, ['registration_id' => $id, 'secret_hash' => glpichat_management_hash('registration', $secret), 'status' => 'issued',
            'expires_at' => gmdate('Y-m-d H:i:s', time() + $ttlDays * 86400), 'max_uses' => $maxUses, 'used_count' => 0, 'created_at' => glpichat_desktop_now(), 'created_by' => $adminId]);
        return ['schema' => 1, 'product' => 'glpichat-desktop', 'base_url' => rtrim($baseUrl, '/'), 'management_public_key_xml' => $public,
            'registration_id' => $id, 'registration_secret' => $secret, 'enrollment_root' => $enrollmentRoot];
    });
}

function glpichat_management_register(array $input): array
{
    glpichat_management_require_schema();
    $grantId = glpichat_management_hex($input, 'registration_id', 32);
    $secret = glpichat_management_hex($input, 'registration_secret');
    $token = glpichat_management_hex($input, 'machine_token');
    $installation = glpichat_management_uuid(glpichat_desktop_string($input, 'installation_id', 36));
    $computer = strtoupper(glpichat_management_text($input, 'computer_name', 63));
    $bootstrap = glpichat_management_text($input, 'bootstrap_version', 32);
    if (preg_match('/\A[A-Z0-9][A-Z0-9_-]{0,62}\z/D', $computer) !== 1) { glpichat_desktop_fail('invalid_request', 'Nome de computador inválido.', 400); }
    return glpichat_desktop_transaction(static function () use ($grantId, $secret, $token, $installation, $computer, $bootstrap): array {
        // Lock the grant first: registration consumption and revocation share this order.
        $grant = glpichat_management_one(GLPICHAT_MANAGEMENT_GRANTS, 'registration_id=' . glpichat_desktop_quote($grantId), true);
        if (!$grant || $grant['status'] !== 'issued' || !hash_equals($grant['secret_hash'], glpichat_management_hash('registration', $secret))) {
            glpichat_desktop_fail('registration_invalid', 'Registro indisponível ou revogado.', 401);
        }
        $machine = glpichat_management_one(GLPICHAT_MANAGEMENT_MACHINES, 'installation_id=' . glpichat_desktop_quote($installation), true);
        if ($machine) {
            if ($machine['status'] !== 'active' || $machine['registration_id'] !== $grantId || !hash_equals($machine['token_hash'], glpichat_management_hash('machine', $token))) {
                glpichat_desktop_fail('registration_conflict', 'Esta instalação já possui outro registro.', 409);
            }
        } else {
            if ($grant['expires_at'] <= glpichat_desktop_now() || (int) $grant['used_count'] >= (int) $grant['max_uses']) { glpichat_desktop_fail('registration_expired', 'Registro expirado ou limite atingido.', 410); }
            glpichat_management_write(GLPICHAT_MANAGEMENT_MACHINES, ['installation_id' => $installation, 'token_hash' => glpichat_management_hash('machine', $token), 'registration_id' => $grantId,
                'status' => 'active', 'computer_name' => $computer, 'bootstrap_version' => $bootstrap, 'current_version' => '', 'current_sequence' => 0, 'current_slot' => '', 'health' => 'unavailable',
                'last_result' => '', 'last_error' => '', 'last_seen' => null, 'created_at' => glpichat_desktop_now()]);
            glpichat_management_write(GLPICHAT_MANAGEMENT_GRANTS, ['used_count' => (int) $grant['used_count'] + 1], ['id' => (int) $grant['id']]);
        }
        return ['ok' => true, 'installation_id' => $installation, 'poll_seconds' => 60];
    });
}

function glpichat_management_authenticate(string $token, string $installation, bool $lock = false): array
{
    glpichat_management_require_schema();
    glpichat_management_uuid($installation);
    if (preg_match('/\A[a-f0-9]{64}\z/D', $token) !== 1) { glpichat_desktop_fail('machine_invalid', 'Registro da máquina inválido.', 401); }
    $machine = glpichat_management_one(GLPICHAT_MANAGEMENT_MACHINES, 'installation_id=' . glpichat_desktop_quote($installation), $lock);
    if (!$machine || $machine['status'] !== 'active' || !hash_equals($machine['token_hash'], glpichat_management_hash('machine', $token))) {
        glpichat_desktop_fail('machine_invalid', 'Registro da máquina inválido ou revogado.', 401);
    }
    return $machine;
}

function glpichat_management_pending(int $machineId, bool $lock = false): array
{
    $rows = glpichat_desktop_db_rows('SELECT * FROM ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' WHERE machines_id=' . $machineId . " AND status IN ('pending','started') ORDER BY id DESC LIMIT 1" . ($lock ? ' FOR UPDATE' : ''));
    return $rows[0] ?? [];
}

function glpichat_management_poll(string $token, string $installation, array $input): array
{
    $values = [];
    foreach (['bootstrap_version' => 32, 'current_version' => 32, 'current_slot' => 1, 'health' => 16, 'result' => 80, 'error_code' => 100] as $key => $bound) {
        $values[$key] = glpichat_management_text($input, $key, $bound);
    }
    foreach (['current_sequence', 'assignment_id'] as $key) {
        if (!isset($input[$key]) || !is_int($input[$key]) || $input[$key] < 0 || $input[$key] >= PHP_INT_MAX) { glpichat_desktop_fail('invalid_request', 'Contador inválido.', 400); }
        $values[$key] = $input[$key];
    }
    if (!in_array($values['current_slot'], ['', 'a', 'b'], true) || !in_array($values['health'], ['healthy', 'damaged', 'trial', 'unavailable'], true)) { glpichat_desktop_fail('invalid_request', 'Estado inválido.', 400); }
    return glpichat_desktop_transaction(static function () use ($token, $installation, $values): array {
        $machine = glpichat_management_authenticate($token, $installation, true);
        $assignment = glpichat_management_pending((int) $machine['id'], true);
        $release = $assignment ? glpichat_management_one(GLPICHAT_MANAGEMENT_RELEASES, 'id=' . (int) $assignment['releases_id']) : [];
        if ($assignment && (int) $assignment['id'] === $values['assignment_id']) {
            $newStatus = null;
            if ($values['result'] === 'started') { $newStatus = 'started'; }
            elseif (in_array($values['result'], ['failed', 'rolled_back', 'interrupted'], true)) { $newStatus = 'failed'; }
            elseif (in_array($values['result'], ['committed', 'repaired', 'current'], true) && $values['health'] === 'healthy'
                && $release && (int) $release['sequence'] === $values['current_sequence'] && $release['version'] === $values['current_version']) { $newStatus = 'completed'; }
            if ($newStatus !== null) {
                glpichat_management_write(GLPICHAT_MANAGEMENT_ASSIGNMENTS, ['status' => $newStatus, 'completed_at' => in_array($newStatus, ['completed', 'failed'], true) ? glpichat_desktop_now() : null], ['id' => (int) $assignment['id']]);
                if ($newStatus !== 'started') { $assignment = []; }
            }
        }
        glpichat_management_write(GLPICHAT_MANAGEMENT_MACHINES, ['bootstrap_version' => $values['bootstrap_version'], 'current_version' => $values['current_version'],
            // Never lower the machine's reported highwater, including after rollback.
            'current_sequence' => max((int) $machine['current_sequence'], $values['current_sequence']), 'current_slot' => $values['current_slot'], 'health' => $values['health'],
            'last_result' => $values['result'], 'last_error' => $values['error_code'], 'last_seen' => glpichat_desktop_now()], ['id' => (int) $machine['id']]);
        return ['ok' => true, 'poll_seconds' => 60, 'assignment' => $assignment && $release ? ['id' => (int) $assignment['id'], 'action' => $assignment['action'], 'release_id' => (int) $release['id'],
            'sequence' => (int) $release['sequence'], 'manifest_json' => $release['manifest_json'], 'signature' => $release['signature']] : null];
    });
}

function glpichat_management_assign(int $machineId, int $releaseId, string $action, int $adminId): int
{
    glpichat_management_require_schema();
    if (!in_array($action, ['update', 'repair'], true)) { glpichat_desktop_fail('invalid_request', 'Ação inválida.', 400); }
    return glpichat_desktop_transaction(static function () use ($machineId, $releaseId, $action, $adminId): int {
        $machine = glpichat_management_one(GLPICHAT_MANAGEMENT_MACHINES, 'id=' . $machineId, true);
        $release = glpichat_management_one(GLPICHAT_MANAGEMENT_RELEASES, 'id=' . $releaseId);
        if (!$machine || $machine['status'] !== 'active' || !$release) { glpichat_desktop_fail('not_found', 'Máquina ou versão indisponível.', 404); }
        if ((int) $release['sequence'] < (int) $machine['current_sequence'] || ($action === 'update' && (int) $release['sequence'] === (int) $machine['current_sequence'])) {
            glpichat_desktop_fail('sequence_conflict', 'Selecione uma versão com sequência maior; para a versão atual use Reparar.', 409);
        }
        // Explicit repair may retry a quarantined release. Ordinary update may not.
        if ($action === 'update' && glpichat_management_one(GLPICHAT_MANAGEMENT_ASSIGNMENTS, 'machines_id=' . $machineId . ' AND releases_id=' . $releaseId . " AND status='failed'")) {
            glpichat_desktop_fail('release_quarantined', 'Esta atualização falhou. Publique outra versão ou solicite reparo explicitamente.', 409);
        }
        $previous = glpichat_management_pending($machineId, true);
        if ($previous) { glpichat_management_write(GLPICHAT_MANAGEMENT_ASSIGNMENTS, ['status' => 'superseded', 'completed_at' => glpichat_desktop_now()], ['id' => (int) $previous['id']]); }
        return glpichat_management_write(GLPICHAT_MANAGEMENT_ASSIGNMENTS, ['machines_id' => $machineId, 'releases_id' => $releaseId, 'action' => $action,
            'status' => 'pending', 'created_at' => glpichat_desktop_now(), 'created_by' => $adminId, 'completed_at' => null]);
    });
}

function glpichat_management_revoke(string $kind, int $id): void
{
    glpichat_management_require_schema();
    $table = match ($kind) { 'machine' => GLPICHAT_MANAGEMENT_MACHINES, 'registration' => GLPICHAT_MANAGEMENT_GRANTS, default => '' };
    if ($table === '' || $id < 1) { glpichat_desktop_fail('invalid_request', 'Registro inválido.', 400); }
    glpichat_desktop_transaction(static function () use ($table, $id): void {
        if (!glpichat_management_one($table, 'id=' . $id, true)) { glpichat_desktop_fail('not_found', 'Registro não encontrado.', 404); }
        glpichat_management_write($table, ['status' => 'revoked'], ['id' => $id]);
    });
}

/** Machine must report started for its current assignment before either payload. */
function glpichat_management_artifact(string $token, string $installation, int $releaseId, string $filename): string
{
    if (!in_array($filename, ['GLPIChat.Agent.exe', 'GLPIChat.Widget.exe'], true)) { glpichat_desktop_fail('not_found', 'Arquivo indisponível.', 404); }
    return glpichat_desktop_transaction(static function () use ($token, $installation, $releaseId, $filename): string {
        $machine = glpichat_management_authenticate($token, $installation, true);
        $assignment = glpichat_management_pending((int) $machine['id'], true);
        if (!$assignment || (int) $assignment['releases_id'] !== $releaseId || $assignment['status'] !== 'started') { glpichat_desktop_fail('not_found', 'Arquivo fora da operação autorizada.', 404); }
        $release = glpichat_management_one(GLPICHAT_MANAGEMENT_RELEASES, 'id=' . $releaseId);
        if (!$release || preg_match('/\A[a-f0-9]{32}\z/D', $release['storage_key']) !== 1) { throw new RuntimeException('Release storage invalid.'); }
        $path = glpichat_management_storage() . '/' . $release['storage_key'] . '/' . $filename;
        if (is_link(dirname($path)) || is_link($path) || !is_file($path)) { throw new RuntimeException('Release artifact unavailable.'); }
        return $path;
    });
}
