<?php

namespace GlpiPlugin\G4freports\Ses;

/** Native editable spreadsheet chart parts with references to visible source cells. */
final class XlsxChart
{
    public static function anchor(array $chart, string $relationship, int $id): string
    {
        [$left, $top, $right, $bottom] = $chart['anchor'];
        $xml = '<xdr:twoCellAnchor editAs="oneCell">';
        foreach (['from' => [$left, $top], 'to' => [$right, $bottom]] as $tag => $position) {
            $xml .= '<xdr:' . $tag . '><xdr:col>' . $position[0] . '</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>' . $position[1] . '</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:' . $tag . '>';
        }
        return $xml . '<xdr:graphicFrame macro=""><xdr:nvGraphicFramePr><xdr:cNvPr id="' . $id . '" name="' . OfficePackage::xml($chart['title']) . '"/><xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr><xdr:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/></xdr:xfrm><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart"><c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:id="' . $relationship . '"/></a:graphicData></a:graphic></xdr:graphicFrame><xdr:clientData/></xdr:twoCellAnchor>';
    }

    public static function xml(array $chart): string
    {
        $horizontal = $chart['kind'] === 'bar';
        $percent = $chart['unit'] === 'percent';
        $format = $percent ? '0.0%' : '#,##0';
        $count = count($chart['categories']);
        $dense = $count > 12;
        $maximum = 0;
        foreach ($chart['series'] as $series) { foreach ($series['values'] as $value) { if ($value !== null) { $maximum = max($maximum, $value); } } }
        if (!empty($chart['stacked'])) {
            for ($i = 0; $i < $count; $i++) {
                $sum = 0; foreach ($chart['series'] as $series) { $sum += $series['values'][$i] ?? 0; }
                $maximum = max($maximum, $sum);
            }
        }
        $maximum = $percent ? max(0.05, ceil($maximum * 110) / 100) : max(1, ceil($maximum * 1.15));
        // A count axis must not show half-count tick marks rounded into duplicate integers.
        $majorUnit = !$percent && $maximum <= 20 ? max(1, ceil($maximum / 6)) : null;
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><c:lang val="pt-BR"/><c:roundedCorners val="0"/><c:chart><c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="1250" b="1"/></a:pPr><a:r><a:rPr lang="pt-BR"/><a:t>' . OfficePackage::xml($chart['title']) . '</a:t></a:r></a:p></c:rich></c:tx><c:overlay val="0"/></c:title><c:autoTitleDeleted val="0"/><c:plotArea><c:layout/><c:barChart><c:barDir val="' . ($horizontal ? 'bar' : 'col') . '"/><c:grouping val="' . (!empty($chart['stacked']) ? 'stacked' : 'clustered') . '"/><c:varyColors val="0"/>';
        foreach ($chart['series'] as $index => $series) {
            $xml .= '<c:ser><c:idx val="' . $index . '"/><c:order val="' . $index . '"/><c:tx><c:v>' . OfficePackage::xml($series['name']) . '</c:v></c:tx><c:spPr><a:solidFill><a:srgbClr val="' . $series['color'] . '"/></a:solidFill><a:ln><a:noFill/></a:ln></c:spPr>';
            $xml .= '<c:cat><c:strRef><c:f>' . OfficePackage::xml($chart['category_ref']) . '</c:f><c:strCache><c:ptCount val="' . $count . '"/>';
            foreach ($chart['categories'] as $point => $label) { $xml .= '<c:pt idx="' . $point . '"><c:v>' . OfficePackage::xml($label) . '</c:v></c:pt>'; }
            $xml .= '</c:strCache></c:strRef></c:cat><c:val><c:numRef><c:f>' . OfficePackage::xml($series['value_ref']) . '</c:f><c:numCache><c:formatCode>' . $format . '</c:formatCode><c:ptCount val="' . $count . '"/>';
            foreach ($series['values'] as $point => $value) {
                // Missing/pending values have no numerical point. A measured zero is retained.
                if ($value !== null) { $xml .= '<c:pt idx="' . $point . '"><c:v>' . sprintf('%.15g', $value) . '</c:v></c:pt>'; }
            }
            $xml .= '</c:numCache></c:numRef></c:val></c:ser>';
        }
        if (!$dense) { $xml .= '<c:dLbls><c:numFmt formatCode="' . $format . '" sourceLinked="0"/><c:dLblPos val="outEnd"/><c:showLegendKey val="0"/><c:showVal val="1"/><c:showCatName val="0"/><c:showSerName val="0"/><c:showPercent val="0"/><c:showBubbleSize val="0"/></c:dLbls>'; }
        $xml .= '<c:gapWidth val="' . ($dense ? '45' : '65') . '"/><c:overlap val="' . (!empty($chart['stacked']) ? '100' : '0') . '"/><c:axId val="100"/><c:axId val="200"/></c:barChart>';
        $xml .= '<c:catAx><c:axId val="100"/><c:scaling><c:orientation val="' . ($horizontal ? 'maxMin' : 'minMax') . '"/></c:scaling><c:axPos val="' . ($horizontal ? 'l' : 'b') . '"/><c:majorTickMark val="none"/><c:minorTickMark val="none"/><c:tickLblPos val="nextTo"/><c:spPr><a:ln><a:noFill/></a:ln></c:spPr><c:crossAx val="200"/><c:crosses val="autoZero"/><c:auto val="1"/><c:lblAlgn val="ctr"/><c:lblOffset val="100"/><c:noMultiLvlLbl val="1"/></c:catAx>';
        $xml .= '<c:valAx><c:axId val="200"/><c:scaling><c:orientation val="minMax"/><c:max val="' . sprintf('%.15g', $maximum) . '"/><c:min val="0"/></c:scaling><c:axPos val="' . ($horizontal ? 'b' : 'l') . '"/><c:majorGridlines><c:spPr><a:ln w="6350"><a:solidFill><a:srgbClr val="E5EBF0"/></a:solidFill></a:ln></c:spPr></c:majorGridlines><c:numFmt formatCode="' . ($percent ? '0%' : '#,##0') . '" sourceLinked="0"/><c:majorTickMark val="none"/><c:minorTickMark val="none"/><c:tickLblPos val="nextTo"/><c:spPr><a:ln><a:noFill/></a:ln></c:spPr><c:crossAx val="100"/><c:crosses val="' . ($horizontal ? 'max' : 'autoZero') . '"/><c:crossBetween val="between"/>' . ($majorUnit !== null ? '<c:majorUnit val="' . $majorUnit . '"/>' : '') . '</c:valAx></c:plotArea>';
        if (count($chart['series']) > 1) { $xml .= '<c:legend><c:legendPos val="b"/><c:overlay val="0"/></c:legend>'; }
        return $xml . '<c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/><c:showDLblsOverMax val="0"/></c:chart><c:spPr><a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill><a:ln><a:noFill/></a:ln></c:spPr><c:txPr><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="1000"><a:solidFill><a:srgbClr val="223344"/></a:solidFill><a:latin typeface="Arial"/></a:defRPr></a:pPr><a:endParaRPr lang="pt-BR"/></a:p></c:txPr></c:chartSpace>';
    }
}
