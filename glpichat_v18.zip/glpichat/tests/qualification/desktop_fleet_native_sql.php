<?php

declare(strict_types=1);
/** Production fleet SQL/services/schema migration, native GLPI DBmysql query
 * builders + savepoints, real disposable MariaDB. No installed Windows clients.
 * Usage: php desktop_fleet_native_sql.php PLUGIN_ROOT GLPI_ROOT [--worker DATABASE]
 */
if (PHP_SAPI !== 'cli' || $argc < 3) { exit(2); }
[$unused, $plugin, $core] = $argv;
require $core . '/vendor/autoload.php';
require_once $core . '/src/DBmysql.php';
require_once $core . '/src/DBmysqlIterator.php';
require_once $core . '/src/DBConnection.php';
require $plugin . '/src/desktop/rollouts.php';
require $plugin . '/src/desktop/schema.php';
final class Config {
    public static array $values = ['desktop_schema_version' => '5', 'desktop_enabled' => '1', 'desktop_idempotency_key' => ''];
    public static function getConfigurationValues(string $scope): array { return self::$values; }
    public static function getConfigurationValue(string $scope, string $key): mixed { return self::$values[$key] ?? null; }
    public static function setConfigurationValues(string $scope, array $values): void { self::$values = array_replace(self::$values, $values); }
}
final class FleetNativeDB extends DBmysql {
    public array $queries = [];
    public bool $fault = false;
    public function __construct(mysqli $connection) { $this->dbh = $connection; $this->connected = true; }
    public function doQuery($query) {
        $this->queries[] = $query;
        if ($this->fault && str_starts_with($query, 'INSERT INTO `glpi_plugin_glpichat_desktopassignments`')) { $this->fault = false; throw new RuntimeException('Injected assignment persistence failure.'); }
        return $this->dbh->query($query);
    }
}
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$connection = new mysqli(getenv('GLPICHAT_TEST_DB_HOST') ?: '127.0.0.1', getenv('GLPICHAT_TEST_DB_USER') ?: 'root', getenv('GLPICHAT_TEST_DB_PASSWORD') ?: '', '', (int) getenv('GLPICHAT_TEST_DB_PORT'));
$connection->set_charset('utf8mb4');
$worker = in_array(($argv[3] ?? ''), ['--worker','--create','--create-later'],true);
$database = $worker ? $argv[4] : 'glpichat_fleet_' . bin2hex(random_bytes(6));
if (!preg_match('/\Aglpichat_fleet_[a-f0-9]+\z/D', $database)) { throw new RuntimeException('Disposable database name required.'); }
if (!$worker) { $connection->query('CREATE DATABASE `' . $database . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci'); }
$connection->select_db($database); $DB = new FleetNativeDB($connection); $DB->dbdefault = $database;
if ($worker) {
    Config::$values['desktop_schema_version']='6';
    if ($argv[3] === '--worker') { glpichat_management_process_rollouts(1000,30);echo 'worker complete'; }
    else { $admin=$argv[3]==='--create'?99:(int)$argv[5];$request=str_pad(dechex($admin),32,'e',STR_PAD_LEFT);$job=glpichat_management_create_rollout(3,'update',glpichat_management_filters([]),'selected',[5999,6000],[],$admin,$request);echo json_encode(['id'=>(int)$job['id']]); }
    exit;
}
$checks = 0;
function fleet_check(bool $condition, string $description): void { global $checks; ++$checks; if (!$condition) { throw new RuntimeException($description); } }
function fleet_fail(callable $action, string $code): void { try { $action(); } catch (GlpichatDesktopException $error) { fleet_check($error->errorCode === $code, 'Expected ' . $code . ', got ' . $error->errorCode); return; } throw new RuntimeException('Expected ' . $code); }
function fleet_ddl(string $table, array $definition): string {
    $parts = [];
    foreach ($definition['columns'] as $name => $column) { $parts[] = '`' . $name . '` ' . str_replace(' ascii_bin', ' CHARACTER SET ascii COLLATE ascii_bin', $column['type']) . ($column['nullable'] ? ' NULL DEFAULT NULL' : ' NOT NULL') . ' ' . $column['extra']; }
    foreach ($definition['indexes'] as $name => $index) { $parts[] = ($name === 'PRIMARY' ? 'PRIMARY KEY' : ($index['unique'] ? 'UNIQUE KEY ' : 'KEY ') . '`' . $name . '`') . ' (`' . implode('`,`', $index['columns']) . '`)'; }
    return 'CREATE TABLE `' . $table . '` (' . implode(',', $parts) . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
}
function fleet_machine(int $id, string $version = '0.5.0'): array {
    return ['id' => $id, 'installation_id' => sprintf('aaaaaaaa-aaaa-aaaa-aaaa-%012d', $id), 'token_hash' => glpichat_management_hash('machine', str_pad(dechex($id), 64, '0', STR_PAD_LEFT)),
        'registration_id' => str_repeat('a',32), 'status' => 'active', 'computer_name' => sprintf('PC-%06d', $id), 'bootstrap_version' => '0.5.0', 'current_version' => $version,
        'current_sequence' => 1, 'current_slot' => 'a', 'health' => 'healthy', 'last_result' => 'initial_install', 'last_error' => '', 'last_seen' => null, 'created_at' => glpichat_desktop_now()];
}
$started = microtime(true);
try {
    // Build a v5-shaped database, then execute the production additive migration.
    $definitions = glpichat_desktop_schema_definitions();
    foreach ($definitions as $table => $definition) {
        if (in_array($table, [GLPICHAT_MANAGEMENT_ROLLOUTS, GLPICHAT_MANAGEMENT_TARGETS, 'glpi_plugin_glpichat_guestsends'], true)) { continue; }
        foreach (['previous_computer_name','enrollment_computer_name','renamed_at','started_at','last_reported_at'] as $column) { unset($definition['columns'][$column]); }
        if ($table === GLPICHAT_MANAGEMENT_ASSIGNMENTS) { unset($definition['columns']['last_result'], $definition['columns']['last_error']); }
        foreach (['desktop_machine_name','desktop_machine_version','desktop_assignment_history','enrollment_identity_latest'] as $index) { unset($definition['indexes'][$index]); }
        $connection->query(fleet_ddl($table, $definition));
    }
    $connection->query('CREATE TABLE glpi_plugin_glpichat_messages (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,itilfollowups_id INT UNSIGNED NULL) ENGINE=InnoDB');
    glpichat_desktop_schema_install(); glpichat_desktop_reset_request_context();
    fleet_check(Config::$values['desktop_schema_version'] === '6' && glpichat_desktop_schema_health()['healthy'], 'Production v5-to6 migration reads back actual native schema');
    $before = count($DB->queries); glpichat_desktop_schema_install();
    fleet_check(!array_filter(array_slice($DB->queries, $before), static fn($sql) => str_starts_with($sql,'ALTER') || str_starts_with($sql,'CREATE')), 'Repeated migration performs no DDL');
    $DB->beginTransaction();
    for ($id=1; $id<=6000; ++$id) { $DB->insert(GLPICHAT_MANAGEMENT_MACHINES, fleet_machine($id)); }
    $DB->commit();
    foreach ([1=>['0.6.0',10],2=>['0.7.0',20],3=>['0.8.0',30]] as $id => [$version,$sequence]) {
        $manifest = json_encode(['schema'=>1,'product'=>'glpichat-desktop','version'=>$version,'sequence'=>$sequence,'platform'=>'windows','architecture'=>'x64','bootstrap_abi'=>2,'state_schema_min'=>1,'state_schema_max'=>1,'components'=>[]]);
        $DB->insert(GLPICHAT_MANAGEMENT_RELEASES,['id'=>$id,'version'=>$version,'sequence'=>$sequence,'manifest_json'=>$manifest,'signature'=>'test-only','storage_key'=>str_pad(dechex($id),32,'0',STR_PAD_LEFT),'created_by'=>1,'created_at'=>glpichat_desktop_now()]);
    }
    $filters = glpichat_management_filters([]); $page = glpichat_management_machine_page($filters);
    fleet_check($page['total']===6000 && count($page['rows'])===50 && (int)$page['rows'][0]['id']===6000, '6000-machine list is SQL-bounded to50');
    $last = glpichat_management_machine_page($filters,120,50);
    fleet_check(count($last['rows'])===50 && (int)end($last['rows'])['id']===1, 'Deep final page reaches oldest installation');
    fleet_check(glpichat_management_machine_page(glpichat_management_filters(['q'=>'PC-000123']))['total']===1, 'Computer search resolves exact matching row');
    fleet_check(glpichat_management_machine_page(glpichat_management_filters(['q'=>"%' OR 1=1 --"]))['total']===0, 'Quoted wildcard/injection text remains literal search');
    fleet_check(glpichat_management_machine_page(glpichat_management_filters(['q'=>'PC-%']))['total']===0, 'LIKE wildcard is escaped');
    fleet_fail(static fn()=>glpichat_management_filters(['status'=>"active' OR 1=1"]),'invalid_request');
    $old = glpichat_management_assign(1,1,'update',1);
    for ($i=0;$i<1001;++$i) { $DB->insert(GLPICHAT_MANAGEMENT_ASSIGNMENTS,['machines_id'=>2,'releases_id'=>1,'action'=>'repair','status'=>'completed','created_by'=>1,'created_at'=>glpichat_desktop_now(),'completed_at'=>glpichat_desktop_now()]); }
    $oldPage = glpichat_management_machine_page(glpichat_management_filters(['q'=>'PC-000001']));
    fleet_check((int)$oldPage['rows'][0]['assignment_id']===$old,'Latest operation query survives >1000 newer operations elsewhere');
    $token=str_pad(dechex(1),64,'0',STR_PAD_LEFT); $installation=fleet_machine(1)['installation_id'];
    $report=['bootstrap_version'=>'0.5.0','current_version'=>'0.5.0','current_sequence'=>1,'current_slot'=>'a','health'=>'healthy','result'=>'started','error_code'=>'','assignment_id'=>$old];
    glpichat_management_poll($token,$installation,$report);
    fleet_fail(static fn()=>glpichat_management_assign(1,2,'update',1),'operation_in_progress');
    $rename=$report+['computer_name'=>'RENAMED-PC']; glpichat_management_poll($token,$installation,$rename);
    $renamed=glpichat_management_one(GLPICHAT_MANAGEMENT_MACHINES,'id=1');
    fleet_check($renamed['computer_name']==='RENAMED-PC' && $renamed['previous_computer_name']==='PC-000001','Authenticated rename keeps stable installation');
    glpichat_management_poll($token,$installation,array_replace($report,['computer_name'=>'RENAMED-TWICE']));
    fleet_check(glpichat_management_one(GLPICHAT_MANAGEMENT_MACHINES,'id=1')['enrollment_computer_name']==='PC-000001','Repeated renames preserve original legacy enrollment revocation anchor');
    glpichat_management_poll($token,$installation,array_replace($report,['result'=>'retrying','error_code'=>'MANAGEMENT_NETWORK_FAILED']));
    fleet_check(glpichat_management_one(GLPICHAT_MANAGEMENT_ASSIGNMENTS,'id='.$old)['status']==='started','Retrying does not quarantine a preactivation transfer');
    $wait=glpichat_management_create_rollout(2,'update',$filters,'selected',[1],[],1,str_repeat('b',32));
    $r=glpichat_management_process_rollouts();
    fleet_check($r['waiting']===1 && glpichat_management_one(GLPICHAT_MANAGEMENT_ASSIGNMENTS,'id='.$old)['status']==='started','Rollout waits behind a started update');
    glpichat_management_poll($token,$installation,array_replace($report,['result'=>'committed','current_version'=>'0.6.0','current_sequence'=>10]));
    $connection->query('UPDATE '.GLPICHAT_MANAGEMENT_TARGETS.' SET available_at=UTC_TIMESTAMP()');
    $DB->fault=true; $waitingFault=glpichat_management_process_rollouts();
    $waitingTarget=glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS,'rollouts_id='.(int)$wait['id']);
    fleet_check($waitingFault['deferred']===1 && $waitingTarget['status']==='waiting' && $waitingTarget['reason']==='storage_retry' && $waitingTarget['available_at']>glpichat_desktop_now(),'Transient failure defers already-waiting targets without starving the due queue');
    $connection->query('UPDATE '.GLPICHAT_MANAGEMENT_TARGETS.' SET available_at=UTC_TIMESTAMP()'); glpichat_management_process_rollouts();
    $next=glpichat_management_pending(1);
    fleet_check((int)$next['releases_id']===2,'Waiting next operation dispatches after exact prior success');
    glpichat_management_poll($token,$installation,array_replace($report,['result'=>'committed','current_version'=>'0.6.0','current_sequence'=>10]));
    fleet_check(glpichat_management_one(GLPICHAT_MANAGEMENT_ASSIGNMENTS,'id='.(int)$next['id'])['status']==='pending','Late prior completion never completes newer assignment');
    fleet_check(glpichat_management_one(GLPICHAT_MANAGEMENT_ASSIGNMENTS,'id='.$old)['last_result']==='committed','Exact historical operation keeps result detail');
    glpichat_management_poll($token,$installation,$report);
    fleet_check(glpichat_management_one(GLPICHAT_MANAGEMENT_ASSIGNMENTS,'id='.$old)['last_result']==='committed','Delayed started report cannot erase terminal result');
    // Mixed eligibility is resolved per target, without failing the whole job.
    $DB->update(GLPICHAT_MANAGEMENT_MACHINES,['status'=>'revoked'],['id'=>3]);
    $DB->update(GLPICHAT_MANAGEMENT_MACHINES,['bootstrap_version'=>'0.3.0'],['id'=>4]);
    $DB->update(GLPICHAT_MANAGEMENT_MACHINES,['current_sequence'=>10,'current_version'=>'0.6.0'],['id'=>5]);
    $DB->insert(GLPICHAT_MANAGEMENT_ASSIGNMENTS,['machines_id'=>6,'releases_id'=>1,'action'=>'update','status'=>'failed','created_by'=>1,'created_at'=>glpichat_desktop_now()]);
    $all=glpichat_management_create_rollout(1,'update',$filters,'all',[],[1,2],7,str_repeat('c',32));
    fleet_check((int)$all['target_count']===5998,'All matching target snapshot applies exact exclusions');
    $again=glpichat_management_create_rollout(1,'update',$filters,'all',[],[1,2],7,str_repeat('c',32));
    fleet_check((int)$again['id']===(int)$all['id'],'Duplicate request key returns original rollout');
    $DB->insert(GLPICHAT_MANAGEMENT_MACHINES,fleet_machine(6001));
    fleet_check(!glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS,'rollouts_id='.(int)$all['id'].' AND machines_id=6001'),'New registration never enters an existing snapshot');
    // Two independent native DB connections concurrently dispatch the same due queue.
    $children=[];
    for($i=0;$i<2;++$i){$pipes=[];$process=proc_open([PHP_BINARY,'-c',php_ini_loaded_file(),__FILE__,$plugin,$core,'--worker',$database],[1=>['pipe','w'],2=>['pipe','w']],$pipes); if(!is_resource($process))throw new RuntimeException('Worker startup failed');$children[]=[$process,$pipes];}
    foreach($children as [$process,$pipes]){$out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);fleet_check(proc_close($process)===0,'Concurrent worker completed: '.$err.$out);}
    // Simulate repeated bounded cron executions after process boundaries.
    for($i=0;$i<10;++$i){$r=glpichat_management_process_rollouts(1000,30);if($r['assigned']+$r['skipped']===0)break;}
    $snapshot=glpichat_desktop_db_rows('SELECT status,COUNT(*) AS total FROM '.GLPICHAT_MANAGEMENT_TARGETS.' WHERE rollouts_id='.(int)$all['id'].' GROUP BY status');
    $counts=array_column($snapshot,'total','status');
    fleet_check((int)($counts['assigned']??0)===5994 && (int)($counts['skipped']??0)===4,'5994 offline targets pending; four ineligible targets independently skipped');
    fleet_check((int)glpichat_desktop_db_rows('SELECT COUNT(*) AS total FROM '.GLPICHAT_MANAGEMENT_ASSIGNMENTS." WHERE machines_id>=7 AND machines_id<=6000 AND status='pending'")[0]['total']===5994,'Concurrent resumed workers do not duplicate assignments');
    fleet_check(glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS,'rollouts_id='.(int)$all['id'].' AND machines_id=3')['reason']==='not_found','Revocation has a per-target reason');
    $history=glpichat_management_rollout_page();fleet_check(count($history['rows'])===2 && isset($history['counts'][(int)$all['id']]['pending']),'Rollout count query reflects exact current assignment states');
    glpichat_management_revoke('machine',7);glpichat_management_process_rollouts();
    fleet_check(glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS,'rollouts_id='.(int)$all['id'].' AND machines_id=7')['reason']==='machine_revoked','Revocation gives queued rollout target an explicit unconfirmed outcome');
    $fault=glpichat_management_create_rollout(3,'update',$filters,'selected',[6001],[],7,str_repeat('d',32));$DB->fault=true;
    $failed=glpichat_management_process_rollouts();fleet_check($failed['deferred']===1,'Injected assignment failure leaves resumable target');
    $connection->query('UPDATE '.GLPICHAT_MANAGEMENT_TARGETS.' SET available_at=UTC_TIMESTAMP() WHERE rollouts_id='.(int)$fault['id']);
    glpichat_management_process_rollouts();fleet_check(glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS,'rollouts_id='.(int)$fault['id'])['status']==='assigned','Resumed worker dispatches failed transaction once');
    // Concurrent duplicate submissions retain one job; separate administrators
    // preserve only the newest not-yet-dispatched intent for an overlapping set.
    foreach(['--create','--create-later'] as $mode) {
        $children=[];
        for($i=0;$i<2;++$i){$pipes=[];$process=proc_open([PHP_BINARY,'-c',php_ini_loaded_file(),__FILE__,$plugin,$core,$mode,$database,(string)(100+$i)],[1=>['pipe','w'],2=>['pipe','w']],$pipes);if(!is_resource($process))throw new RuntimeException('Creator startup failed');$children[]=[$process,$pipes];}
        $jobIds=[];
        foreach($children as [$process,$pipes]){$out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);fleet_check(proc_close($process)===0,'Concurrent administrator request committed: '.$err.$out);$jobIds[]=json_decode($out,true,8,JSON_THROW_ON_ERROR)['id'];}
        if($mode==='--create')fleet_check($jobIds[0]===$jobIds[1],'Concurrent duplicate administrator submissions create exactly one snapshot');
        else { $new=max($jobIds);$old=min($jobIds);fleet_check((int)glpichat_desktop_db_rows('SELECT COUNT(*) AS total FROM '.GLPICHAT_MANAGEMENT_TARGETS." WHERE rollouts_id=".$new." AND status='queued'")[0]['total']===2 && (int)glpichat_desktop_db_rows('SELECT COUNT(*) AS total FROM '.GLPICHAT_MANAGEMENT_TARGETS." WHERE rollouts_id=".$old." AND status='skipped'")[0]['total']===2,'Concurrent distinct rollouts preserve newest undispatched intent'); }
    }
    $filtered=glpichat_management_create_rollout(3,'update',glpichat_management_filters(['q'=>'PC-006']),'all',[],[6000],7,str_repeat('f',32));
    fleet_check((int)$filtered['target_count']===1 && (int)glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS,'rollouts_id='.(int)$filtered['id'])['machines_id']===6001,'Filter plus exclusion produces exact immutable target IDs');
    $manual=glpichat_management_create_rollout(3,'update',$filters,'selected',[6001],[6001],7,str_repeat('a',32));
    fleet_check((int)$manual['target_count']===1,'All-mode exclusion cannot silently remove a manually selected installation');
    $plans=[];
    foreach(array_reverse($DB->queries) as $query){if(str_starts_with($query,'SELECT id FROM '.GLPICHAT_MANAGEMENT_TARGETS)){ $plans=$connection->query('EXPLAIN '.$query)->fetch_all(MYSQLI_ASSOC);break;}}
    fleet_check($plans!==[],'Actual worker EXPLAIN recorded');
    echo json_encode(['suite'=>'desktop_fleet_native_sql','checks'=>$checks,'machines'=>6001,'elapsed_seconds'=>round(microtime(true)-$started,3),'worker_plan'=>$plans,'boundaries'=>'Production fleet SQL/schema/services; actual GLPI11 DBmysql builders/savepoints; MariaDB; explicit Config fixture; no installed Windows acceptance'],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)."\n";
} finally {$connection->query('DROP DATABASE `'.$database.'`');}
