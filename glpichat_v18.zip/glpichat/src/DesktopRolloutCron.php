<?php

declare(strict_types=1);
namespace GlpiPlugin\Glpichat;
use CronTask;
require_once __DIR__ . '/desktop/rollouts.php';
final class DesktopRolloutCron
{
    public static function cronInfo(string $name): array
    {
        return $name === 'ProcessDesktopRollouts' ? ['description' => __('Dispatch and reconcile queued GLPI Chat desktop updates in bounded batches.')] : [];
    }
    public static function cronProcessDesktopRollouts(CronTask $task): int
    {
        $result = \glpichat_management_process_rollouts();
        $count = array_sum($result);
        $task->addVolume($count);
        $task->log(sprintf('Desktop rollouts: %d dispatched, %d waiting, %d skipped, %d reconciled, %d deferred.', $result['assigned'], $result['waiting'], $result['skipped'], $result['reconciled'], $result['deferred']));
        return $count > 0 ? 1 : 0;
    }
}
