<?php

namespace GlpiPlugin\G4freports\Ses;

/** One telephone response per call ID, after the saved test-number exclusions. */
final class PhoneSurveySummary
{
    public static function normalizedRating(array $call): ?int
    {
        $hasOriginal = array_key_exists('satisfaction_raw', $call);
        $value = $hasOriginal ? $call['satisfaction_raw'] : ($call['satisfaction'] ?? null);
        if (!is_numeric($value) || !in_array((float)$value, [1.0, 2.0, 3.0, 4.0, 5.0], true)) return null;
        // Live extraction retains the original score. Older imported evidence
        // may contain only the already-converted score: do not reverse it twice.
        return $hasOriginal ? 6 - (int)$value : (int)$value;
    }

    public static function build(array $calls, bool $available, string $followup = '', string $mode = 'glpi_and_phone'): array
    {
        $included = $mode === 'glpi_and_phone';
        $unique = [];
        foreach ($calls as $call) {
            $id = (string)$call['id'];
            $key = (string)($call['call_key'] ?? ($id . '|' . $call['queue']));
            $call['call_key'] = $key;
            // All queue rows receive the same latest non-null survey from SQL.
            // Select one stable row to anchor its evidence and daily count.
            $order = (string)($call['entered_at'] ?? '') . '|' . $key;
            if (isset($unique[$id]) && strcmp($unique[$id]['order'], $order) <= 0) continue;
            $unique[$id] = ['order' => $order, 'call' => $call];
        }
        $responses = $valid = $favorable = 0;
        $representativeKeys = $validKeys = $favorableKeys = [];
        foreach ($unique as $row) {
            $call = $row['call'];
            $key = $call['call_key'];
            $representativeKeys[] = $key;
            if (!$available) continue;
            $raw = array_key_exists('satisfaction_raw', $call) ? $call['satisfaction_raw'] : ($call['satisfaction'] ?? null);
            if ($raw === null) continue;
            $responses++;
            $score = self::normalizedRating($call);
            if ($score === null) continue;
            $valid++;
            $validKeys[] = $key;
            if ($score >= 4) {
                $favorable++;
                $favorableKeys[] = $key;
            }
        }
        $status = !$available ? ($included ? 'Telefonia selecionada, mas indisponível: INS12 pendente' : 'Telefonia indisponível; modo somente GLPI')
            : ($included ? 'Telefonia incluída no INS12' : 'Telefonia excluída por seleção: somente GLPI');
        if ($available && $responses === 0) $status .= '; nenhuma resposta vinculada';
        $explanation = $included
            ? 'O INS12 soma as respostas favoráveis do GLPI e da telefonia e divide pela soma das respostas válidas das duas fontes. Cada resposta tem o mesmo peso; não se faz média dos percentuais das fontes. '
            : 'O INS12 usa somente as pesquisas dos chamados GLPI, conforme a opção escolhida. As respostas telefônicas abaixo são demonstradas para conferência e não participam da fração. ';
        $explanation .= 'Na telefonia, a nota original inteira de 1 a 5 é convertida por 6 menos a nota; as notas convertidas 4 e 5 (originais 2 e 1) são favoráveis. No GLPI, as notas 4 e 5 já são favoráveis, sem inversão. '
            . 'Respostas ausentes ou fora da escala não entram na base de cálculo. A telefonia conta uma resposta por identificador único de ligação, após excluir números de teste, mesmo quando a ligação aparece em várias filas. '
            . 'A consulta mantém a resposta não nula mais recente por identificador, inclusive recebida após o mês; a data de referência é a primeira entrada nas filas selecionadas dentro do mês. '
            . 'O recorte cobre as ligações do período e filas selecionados, não todas as pesquisas da central. Uma resposta de chamado e uma resposta de ligação são registros distintos; não se presume que pertençam à mesma interação.';
        if (!$available) $explanation .= $included
            ? ' A fonte telefônica não pôde ser consultada: o resultado combinado fica pendente, sem substituir silenciosamente a seleção por somente GLPI.'
            : ' A fonte telefônica indisponível não impede o cálculo no modo somente GLPI.';
        return [
            'available' => $available, 'included' => $included, 'mode' => $mode,
            'unique_calls' => count($unique),
            'responses' => $available ? $responses : null,
            'valid_responses' => $available ? $valid : null,
            'favorable_responses' => $available ? $favorable : null,
            'invalid_responses' => $available ? $responses - $valid : null,
            'without_response' => $available ? count($unique) - $responses : null,
            'representative_call_keys' => $representativeKeys,
            'valid_call_keys' => $validKeys,
            'favorable_call_keys' => $favorableKeys,
            'status' => $status, 'explanation' => $explanation,
            'actions' => self::actions($available, $followup, $mode),
        ];
    }

    public static function actions(bool $available, string $followup, string $mode = 'glpi_and_phone'): string
    {
        $included = $mode === 'glpi_and_phone';
        $text = $included
            ? 'Critério aplicado: GLPI e telefonia incluídos, com soma das respostas favoráveis e válidas, deduplicação da pesquisa por ligação e exclusão dos números de teste. '
            : 'Critério aplicado: somente GLPI; a pesquisa telefônica foi excluída por seleção, mantendo suas evidências disponíveis para conferência. ';
        if (!$available) $text .= 'Acompanhamento técnico: verificar acesso e estrutura da tabela tab_pesquisa na conexão de telefonia. ';
        $text .= 'As notas originais e convertidas, as contagens por fonte e a seleção aplicada ficam registradas no relatório.';
        return $text . (trim($followup) !== '' ? "\nAcompanhamento informado: " . trim($followup)
            : "\nAcompanhamento gerencial: não informado nesta extração.");
    }
}
