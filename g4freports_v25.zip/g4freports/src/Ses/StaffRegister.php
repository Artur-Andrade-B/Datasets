<?php

namespace GlpiPlugin\G4freports\Ses;

/** Saved contract roster and an auditable, date-based INS10 working calculation. */
final class StaffRegister
{
    public const CONFIG_KEY = 'ses_staff_register_json';
    private const MAX_ROWS = 500;
    private const MAX_BYTES = 60000;

    public static function fromSettings(array $settings): array
    {
        return self::rows($settings[self::CONFIG_KEY] ?? '[]');
    }

    /** Normalize a complete register before saving; never infer an exit's reason. */
    public static function rows($raw): array
    {
        if (is_string($raw)) {
            if (strlen($raw) > self::MAX_BYTES || substr(ltrim($raw), 0, 1) !== '[') {
                throw new \InvalidArgumentException('O cadastro de profissionais deve ser uma lista JSON de até 60.000 bytes.');
            }
            $raw = json_decode($raw, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new \InvalidArgumentException('O cadastro de profissionais contém JSON inválido.');
            }
        }
        if (!is_array($raw) || ($raw && array_keys($raw) !== range(0, count($raw) - 1)) || count($raw) > self::MAX_ROWS) {
            throw new \InvalidArgumentException('Informe uma lista com até 500 profissionais.');
        }
        $result = [];
        $seen = [];
        foreach ($raw as $index => $row) {
            if (!is_array($row)) throw new \InvalidArgumentException('Cadastro de profissionais: linha inválida.');
            $label = 'Profissional ' . ($index + 1);
            $id = self::text($row['id'] ?? '', $label . ': identificador', 64, false);
            if ($id === '') $id = bin2hex(random_bytes(16));
            if (!preg_match('/\A[A-Za-z0-9_-]{1,64}\z/D', $id) || isset($seen[$id])) {
                throw new \InvalidArgumentException($label . ': identificador inválido ou duplicado.');
            }
            $admission = self::date($row['admission_date'] ?? '', $label . ': data de admissão');
            $departure = self::date($row['departure_date'] ?? null, $label . ': data de saída', true);
            if ($departure !== null && $departure < $admission) {
                throw new \InvalidArgumentException($label . ': a data de saída não pode ser anterior à admissão.');
            }
            $reason = $row['departure_reason'] ?? 'pending';
            if ($reason === '' || $reason === null) $reason = 'pending';
            if (!is_string($reason) || !in_array($reason, ['pending', 'replacement', 'contractor_reduction', 'other'], true)) {
                throw new \InvalidArgumentException($label . ': classificação de saída inválida.');
            }
            // Existing registers predate the billing flag and retain their inclusion.
            // Explicit false must survive both JSON persistence and report generation.
            $billed = array_key_exists('billed', $row) ? $row['billed'] : true;
            if (!in_array($billed, [true, false, 1, 0, '1', '0'], true)) {
                throw new \InvalidArgumentException($label . ': informe se foi faturado.');
            }
            $seen[$id] = true;
            $result[] = [
                'id' => $id,
                'billed' => in_array($billed, [true, 1, '1'], true),
                'name' => self::text($row['name'] ?? '', $label . ': nome', 240),
                'profile' => self::text($row['profile'] ?? '', $label . ': perfil profissional', 300),
                'admission_date' => $admission,
                'departure_date' => $departure,
                'monthly_value' => self::money($row['monthly_value'] ?? '', $label . ': valor mensal'),
                // Clearing the exit date also clears its previous classification.
                'departure_reason' => $departure === null ? 'pending' : $reason,
            ];
        }
        if (strlen(self::json($result)) > self::MAX_BYTES) {
            throw new \InvalidArgumentException('O cadastro de profissionais excede o limite de armazenamento de 60.000 bytes.');
        }
        return $result;
    }

    public static function json(array $rows): string
    {
        return json_encode($rows, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    }

    /** Used by the form to avoid silently overwriting another administrator's edits. */
    public static function revision(array $rows): string
    {
        return hash('sha256', self::json($rows));
    }

    /**
     * Departure is the last active day. The denominator is month-end headcount.
     * A date alone is not evidence of substitution: unclassified exits remain pending.
     * This is an explicit operational convention, not a reconstruction of absent HR history.
     */
    public static function summarize(array $rows, string $month): array
    {
        if (!preg_match('/\A(20\d{2}|2100)-(0[1-9]|1[0-2])\z/D', $month)) {
            throw new \InvalidArgumentException('Mês inválido para apuração do cadastro de profissionais.');
        }
        $rows = self::rows($rows);
        $first = new \DateTimeImmutable($month . '-01', new \DateTimeZone('America/Sao_Paulo'));
        $monthStart = $first->format('Y-m-d');
        $monthEnd = $first->modify('last day of this month')->format('Y-m-d');
        $windowStart = $first->modify('-2 months')->format('Y-m-d');
        $active = $replacements = $reductions = $other = $pending = $monthlyValueCents = $billedTotal = 0;
        $annotated = [];
        $activeIds = $replacementIds = $reductionIds = $pendingIds = $unbilledIds = [];
        $labels = ['pending' => 'Classificação pendente', 'replacement' => 'Substituição',
            'contractor_reduction' => 'Redução determinada pela contratante', 'other' => 'Outra saída sem substituição'];
        foreach ($rows as $row) {
            $departure = $row['departure_date'];
            if ($row['billed']) $billedTotal++;
            else $unbilledIds[] = $row['id'];
            $atMonthEnd = $row['billed'] && $row['admission_date'] <= $monthEnd && ($departure === null || $departure >= $monthEnd);
            $inMonth = $row['billed'] && $row['admission_date'] <= $monthEnd && ($departure === null || $departure >= $monthStart);
            $inWindow = $row['billed'] && $departure !== null && $departure >= $windowStart && $departure <= $monthEnd;
            $counted = $inWindow && $row['departure_reason'] === 'replacement';
            if ($atMonthEnd) {
                $active++;
                $activeIds[] = $row['id'];
                $monthlyValueCents += (int)str_replace('.', '', $row['monthly_value']);
            }
            if ($inWindow) {
                if ($row['departure_reason'] === 'replacement') { $replacements++; $replacementIds[] = $row['id']; }
                elseif ($row['departure_reason'] === 'contractor_reduction') { $reductions++; $reductionIds[] = $row['id']; }
                elseif ($row['departure_reason'] === 'other') $other++;
                else { $pending++; $pendingIds[] = $row['id']; }
            }
            $row['relevant_month'] = $inMonth;
            $row['departure_in_window'] = $inWindow;
            $row['active_at_month_end'] = $atMonthEnd;
            $row['counted_replacement'] = $counted;
            $row['classification_label'] = !$row['billed'] ? 'Não faturado' : ($departure === null ? 'Sem saída registrada' : $labels[$row['departure_reason']]);
            $row['reason'] = !$row['billed'] ? 'Não faturado: não compõe a equipe, as saídas, as substituições nem o valor mensal do INS10.' : ($counted ? 'Substituição confirmada dentro da janela de três meses.'
                : ($inWindow ? $labels[$row['departure_reason']] . ' dentro da janela de três meses.'
                    : ($atMonthEnd ? 'Faturado e ativo no último dia do mês; compõe a equipe de referência.' : 'Fora da equipe de referência e da janela de saídas.')));
            $annotated[] = $row;
        }
        $configured = count($rows) > 0;
        $complete = $configured && $pending === 0;
        $note = 'Convenção operacional: equipe de referência faturada e ativa no último dia do mês; a data de saída é o último dia ativo. '
            . 'A janela de saídas vai de ' . $windowStart . ' a ' . $monthEnd . '. '
            . 'Profissionais com “Foi faturado?” desmarcado permanecem no cadastro, mas não entram na equipe, nas saídas, nas substituições ou no valor mensal do INS10. '
            . 'Somente saídas classificadas como substituição contam para a rotatividade. Reduções determinadas pela contratante e outras saídas sem substituição ficam discriminadas e não contam. '
            . 'O valor mensal é o valor cadastrado, sem rateio, encargos ou reajustes históricos; a soma usa os profissionais faturados e ativos no fechamento.';
        if (!$configured) $note .= ' Apuração pendente: cadastre os profissionais e suas datas.';
        if ($pending > 0) $note .= ' Apuração pendente: classifique ' . $pending . ' saída(s) na janela; não é possível inferir substituição apenas pelas datas.';
        if ($configured && $active === 0) $note .= ' Não há profissionais faturados e ativos no fechamento; o percentual não pode ser calculado.';
        return [
            'rows' => $annotated, 'month' => $month, 'window_start' => $windowStart, 'window_end' => $monthEnd,
            'month_end' => $monthEnd, 'configured' => $configured, 'complete' => $complete,
            'active_total' => $active, 'replacements' => $replacements, 'reductions' => $reductions,
            'billed_total' => $billedTotal, 'unbilled_total' => count($unbilledIds),
            'other_departures' => $other, 'pending_departures' => $pending,
            'numerator' => $complete ? $replacements : null, 'denominator' => $configured ? $active : null,
            'value' => $complete && $active > 0 ? $replacements * 100 / $active : null,
            'monthly_value_total' => number_format($monthlyValueCents / 100, 2, '.', ''),
            'active_ids' => $activeIds, 'replacement_ids' => $replacementIds,
            'reduction_ids' => $reductionIds, 'pending_ids' => $pendingIds,
            'unbilled_ids' => $unbilledIds,
            'method' => 'Substituições confirmadas de profissionais faturados nos três meses até o fechamento ÷ profissionais faturados e ativos no último dia do mês × 100.',
            'note' => $note,
        ];
    }

    private static function text($value, string $label, int $limit, bool $required = true): string
    {
        if (!is_string($value)) throw new \InvalidArgumentException($label . ': informe um texto válido.');
        $value = trim($value);
        if (($required && $value === '') || strlen($value) > $limit || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', $value) || !preg_match('//u', $value)) {
            throw new \InvalidArgumentException($label . ': texto vazio, inválido ou acima do limite de ' . $limit . ' bytes.');
        }
        return $value;
    }

    private static function date($value, string $label, bool $optional = false): ?string
    {
        if ($optional && ($value === null || $value === '')) return null;
        if (!is_string($value) || !preg_match('/\A(19\d{2}|20\d{2}|2100)-(\d{2})-(\d{2})\z/D', $value, $match)
            || !checkdate((int)$match[2], (int)$match[3], (int)$match[1])) {
            throw new \InvalidArgumentException($label . ': informe uma data válida no formato AAAA-MM-DD, entre 1900 e 2100.');
        }
        return $value;
    }

    private static function money($value, string $label): string
    {
        if (!is_string($value) && !is_int($value)) throw new \InvalidArgumentException($label . ': informe um valor em reais com até duas casas decimais.');
        $value = trim((string)$value);
        $value = preg_replace('/\AR\$\s*/u', '', $value);
        if (strpos($value, ',') !== false) {
            if (!preg_match('/\A(?:\d+|\d{1,3}(?:\.\d{3})+),\d{1,2}\z/D', $value)) {
                throw new \InvalidArgumentException($label . ': formato monetário inválido.');
            }
            $value = str_replace(['.', ','], ['', '.'], $value);
        }
        if (!preg_match('/\A\d{1,8}(?:\.\d{1,2})?\z/D', $value)) {
            throw new \InvalidArgumentException($label . ': informe de R$ 0,00 a R$ 99.999.999,99, com até duas casas decimais.');
        }
        $parts = explode('.', $value, 2);
        return (string)(int)$parts[0] . '.' . str_pad($parts[1] ?? '', 2, '0');
    }
}
