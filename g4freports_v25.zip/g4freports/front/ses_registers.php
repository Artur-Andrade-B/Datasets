<?php

// Normal GLPI bootstrap retains its native POST/CSRF validation. The session
// nonce below independently binds this endpoint to the open SES reporting page.
require_once dirname(__DIR__) . '/inc/bootstrap.php';

use GlpiPlugin\G4freports\Config;
use GlpiPlugin\G4freports\Security;
use GlpiPlugin\G4freports\Ses\Settings;
use GlpiPlugin\G4freports\Ses\StaffRegister;

@ini_set('display_errors', '0');
header('Cache-Control: no-store');
$cfg = Config::merged();
if (Security::currentUserId() <= 0 || !Security::canUse($cfg) || !Security::canConfigure()) {
    g4fr_json_response(403, ['ok' => false, 'error' => 'É necessária permissão de configuração para alterar os cadastros.']);
}
if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
    header('Allow: POST');
    g4fr_json_response(405, ['ok' => false, 'error' => 'Método não permitido.']);
}
$nonce = $_POST['_ses_nonce'] ?? null;
$expected = $_SESSION['g4freports_ses_nonce'] ?? null;
if (!is_string($nonce) || !is_string($expected) || $expected === '' || !hash_equals($expected, $nonce)) {
    g4fr_json_response(403, ['ok' => false, 'error' => 'Sessão expirada. Recarregue a área SES antes de alterar os cadastros.']);
}
$csrf = class_exists('Session') && method_exists('Session', 'getNewCSRFToken') ? Session::getNewCSRFToken() : '';
$reply = static function (int $code, array $result) use ($csrf): void {
    g4fr_json_response($code, array_merge($result, ['csrf_token' => $csrf]));
};

try {
    $action = $_POST['action'] ?? '';
    if (!in_array($action, ['save_tests', 'save_staff'], true)) {
        throw new InvalidArgumentException('Cadastro desconhecido.');
    }
    $raw = $_POST['rows'] ?? null;
    $revision = $_POST['revision'] ?? null;
    if (!is_string($raw) || !is_string($revision) || !preg_match('/\A[a-f0-9]{64}\z/D', $revision)) {
        throw new InvalidArgumentException('Conteúdo ou versão do cadastro inválidos. Recarregue a página.');
    }
    $staff = $action === 'save_staff';
    $current = $staff ? StaffRegister::fromSettings($cfg) : Settings::testNumbers($cfg['ses_test_numbers_json'] ?? '[]');
    $currentRevision = StaffRegister::revision($current);
    if (!hash_equals($currentRevision, $revision)) {
        $reply(409, ['ok' => false, 'error' => 'Este cadastro foi alterado em outra sessão. Suas alterações ainda estão na tela; copie o que precisar e recarregue a página para conferir a versão salva antes de editar novamente.']);
    }
    $rows = $staff ? StaffRegister::rows($raw) : Settings::testNumbers($raw);
    $key = $staff ? StaffRegister::CONFIG_KEY : 'ses_test_numbers_json';
    // Only the selected register is written. Connection secrets, report criteria
    // and other plugin settings are not supplied to the configuration writer.
    Config::save([$key => StaffRegister::json($rows)]);
    $savedConfig = Config::merged();
    $savedRows = $staff ? StaffRegister::fromSettings($savedConfig) : Settings::testNumbers($savedConfig[$key] ?? '[]');
    if (!hash_equals(StaffRegister::revision($rows), StaffRegister::revision($savedRows))) {
        throw new RuntimeException('O GLPI não confirmou o cadastro salvo. Recarregue a página para conferir os dados antes de tentar novamente.');
    }
    $reply(200, ['ok' => true, 'rows' => $savedRows, 'revision' => StaffRegister::revision($savedRows)]);
} catch (InvalidArgumentException $e) {
    $reply(400, ['ok' => false, 'error' => $e->getMessage()]);
} catch (RuntimeException $e) {
    $reply(500, ['ok' => false, 'error' => $e->getMessage()]);
} catch (Throwable $e) {
    $reply(500, ['ok' => false, 'error' => 'Não foi possível salvar o cadastro. Suas alterações continuam nesta tela. Verifique a sessão e tente novamente.']);
}
