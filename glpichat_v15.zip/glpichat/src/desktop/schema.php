<?php

declare(strict_types=1);

/** Desktop pilot schema. Included only by the desktop/admin/install paths. */
function glpichat_desktop_schema_definitions(): array
{
    $column = static fn (string $type, bool $nullable = false, string $extra = ''): array => [
        'type' => $type, 'nullable' => $nullable, 'extra' => $extra,
    ];
    $index = static fn (array $columns, bool $unique = false): array => [
        'columns' => $columns, 'unique' => $unique,
    ];
    return [
        'glpi_plugin_glpichat_desktopgrants' => [
            'columns' => [
                'id' => $column('int unsigned', false, 'AUTO_INCREMENT'),
                'grant_id' => $column('char(32) ascii_bin'),
                'secret_hash' => $column('char(64) ascii_bin'),
                'status' => $column('varchar(16)', false, "DEFAULT 'issued'"),
                'users_id' => $column('int unsigned'),
                'profiles_id' => $column('int unsigned'),
                'entities_id' => $column('int unsigned'),
                'auths_id' => $column('int unsigned'),
                'sync_anchor' => $column('char(64) ascii_bin'),
                'user_incarnation' => $column('char(64) ascii_bin'),
                'auth_source_fingerprint' => $column('char(64) ascii_bin'),
                'windows_sid' => $column('varchar(184)'),
                'computer_name' => $column('varchar(63)'),
                'created_at' => $column('datetime'),
                'expires_at' => $column('datetime'),
                'consumed_at' => $column('datetime', true),
                'revoked_at' => $column('datetime', true),
            ],
            'indexes' => [
                'PRIMARY' => $index(['id'], true),
                'desktop_grant_id' => $index(['grant_id'], true),
                'desktop_grant_expiry' => $index(['status', 'expires_at']),
                'desktop_grant_user' => $index(['users_id', 'status']),
            ],
        ],
        'glpi_plugin_glpichat_desktopregistrations' => [
            'columns' => [
                'devices_id' => $column('int unsigned'),
                'grant_id' => $column('char(32) ascii_bin'),
                'refresh_secret_hash' => $column('char(64) ascii_bin'),
                'refresh_expires_at' => $column('datetime'),
                'enrollment_access_hash' => $column('char(64) ascii_bin'),
                'created_at' => $column('datetime'),
                'rotated_at' => $column('datetime', true),
            ],
            'indexes' => [
                'PRIMARY' => $index(['devices_id'], true),
                'desktop_registration_grant' => $index(['grant_id'], true),
            ],
        ],
        'glpi_plugin_glpichat_desktopdevices' => [
            'columns' => [
                'id' => $column('int unsigned', false, 'AUTO_INCREMENT'),
                'pairing_id' => $column('char(32) ascii_bin'),
                'poll_secret_hash' => $column('char(64) ascii_bin'),
                'token_hash' => $column('char(64) ascii_bin', true),
                'device_id' => $column('char(36) ascii_bin'),
                'device_name' => $column('varchar(100)'),
                'windows_login' => $column('varchar(200)'),
                'request_ip_hash' => $column('char(64) ascii_bin'),
                'user_code' => $column('char(9) ascii_bin'),
                'status' => $column('varchar(16)', false, "DEFAULT 'pending'"),
                'users_id' => $column('int unsigned', false, 'DEFAULT 0'),
                'profiles_id' => $column('int unsigned', false, 'DEFAULT 0'),
                'entities_id' => $column('int unsigned', false, 'DEFAULT 0'),
                'auths_id' => $column('int unsigned', false, 'DEFAULT 0'),
                'sync_anchor' => $column('char(64) ascii_bin', false, "DEFAULT ''"),
                'user_incarnation' => $column('char(64) ascii_bin', false, "DEFAULT ''"),
                'auth_source_fingerprint' => $column('char(64) ascii_bin', false, "DEFAULT ''"),
                'created_at' => $column('datetime'),
                'pairing_expires_at' => $column('datetime'),
                'approved_at' => $column('datetime', true),
                'token_expires_at' => $column('datetime', true),
                'revoked_at' => $column('datetime', true),
            ],
            'indexes' => [
                'PRIMARY' => $index(['id'], true),
                'desktop_pairing' => $index(['pairing_id'], true),
                'desktop_token' => $index(['token_hash'], true),
                'desktop_request_ip' => $index(['request_ip_hash', 'created_at']),
                'desktop_expiry' => $index(['status', 'pairing_expires_at']),
                'desktop_user_status' => $index(['users_id', 'status']),
            ],
        ],
        'glpi_plugin_glpichat_desktopsends' => [
            'columns' => [
                'id' => $column('bigint unsigned', false, 'AUTO_INCREMENT'),
                'users_id' => $column('int unsigned'),
                'client_message_id' => $column('char(36) ascii_bin'),
                'tickets_id' => $column('int unsigned'),
                'payload_hash' => $column('char(64) ascii_bin'),
                'itilfollowups_id' => $column('int unsigned', true),
                'created_at' => $column('datetime'),
            ],
            'indexes' => [
                'PRIMARY' => $index(['id'], true),
                'desktop_send_uuid' => $index(['users_id', 'client_message_id'], true),
                'desktop_send_followup' => $index(['tickets_id', 'itilfollowups_id']),
                'desktop_send_rate' => $index(['users_id', 'created_at']),
            ],
        ],
        'glpi_plugin_glpichat_desktopreads' => [
            'columns' => [
                'id' => $column('bigint unsigned', false, 'AUTO_INCREMENT'),
                'users_id' => $column('int unsigned'),
                'itilfollowups_id' => $column('int unsigned'),
                'created_at' => $column('datetime'),
            ],
            'indexes' => [
                'PRIMARY' => $index(['id'], true),
                'desktop_read_followup' => $index(['users_id', 'itilfollowups_id'], true),
            ],
        ],
        'glpi_plugin_glpichat_desktopreleases' => [
            'columns' => [
                'id' => $column('int unsigned', false, 'AUTO_INCREMENT'),
                'version' => $column('varchar(32)'),
                'sequence' => $column('bigint unsigned'),
                'manifest_json' => $column('text'),
                'signature' => $column('text'),
                'storage_key' => $column('char(32) ascii_bin'),
                'created_at' => $column('datetime'),
                'created_by' => $column('int unsigned'),
            ],
            'indexes' => [
                'PRIMARY' => $index(['id'], true),
                'desktop_release_version' => $index(['version'], true),
                'desktop_release_sequence' => $index(['sequence'], true),
                'desktop_release_storage' => $index(['storage_key'], true),
            ],
        ],
        'glpi_plugin_glpichat_desktopmachinegrants' => [
            'columns' => [
                'id' => $column('int unsigned', false, 'AUTO_INCREMENT'),
                'registration_id' => $column('char(32) ascii_bin'),
                'secret_hash' => $column('char(64) ascii_bin'),
                'status' => $column('varchar(16)'),
                'expires_at' => $column('datetime'),
                'max_uses' => $column('int unsigned'),
                'used_count' => $column('int unsigned', false, 'DEFAULT 0'),
                'created_at' => $column('datetime'),
                'created_by' => $column('int unsigned'),
            ],
            'indexes' => [
                'PRIMARY' => $index(['id'], true),
                'desktop_machine_grant_id' => $index(['registration_id'], true),
                'desktop_machine_grant_expiry' => $index(['status', 'expires_at']),
            ],
        ],
        'glpi_plugin_glpichat_desktopmachines' => [
            'columns' => [
                'id' => $column('int unsigned', false, 'AUTO_INCREMENT'),
                'installation_id' => $column('char(36) ascii_bin'),
                'token_hash' => $column('char(64) ascii_bin'),
                'registration_id' => $column('char(32) ascii_bin'),
                'status' => $column('varchar(16)'),
                'computer_name' => $column('varchar(63)'),
                'bootstrap_version' => $column('varchar(32)'),
                'current_version' => $column('varchar(32)'),
                'current_sequence' => $column('bigint unsigned', false, 'DEFAULT 0'),
                'current_slot' => $column('char(1)'),
                'health' => $column('varchar(16)'),
                'last_result' => $column('varchar(80)'),
                'last_error' => $column('varchar(100)'),
                'last_seen' => $column('datetime', true),
                'created_at' => $column('datetime'),
            ],
            'indexes' => [
                'PRIMARY' => $index(['id'], true),
                'desktop_machine_installation' => $index(['installation_id'], true),
                'desktop_machine_token' => $index(['token_hash'], true),
                'desktop_machine_grant' => $index(['registration_id']),
                'desktop_machine_seen' => $index(['status', 'last_seen']),
            ],
        ],
        'glpi_plugin_glpichat_desktopassignments' => [
            'columns' => [
                'id' => $column('int unsigned', false, 'AUTO_INCREMENT'),
                'machines_id' => $column('int unsigned'),
                'releases_id' => $column('int unsigned'),
                'action' => $column('varchar(16)'),
                'status' => $column('varchar(16)'),
                'created_at' => $column('datetime'),
                'created_by' => $column('int unsigned'),
                'completed_at' => $column('datetime', true),
            ],
            'indexes' => [
                'PRIMARY' => $index(['id'], true),
                'desktop_assignment_machine' => $index(['machines_id', 'status']),
                'desktop_assignment_release' => $index(['releases_id']),
            ],
        ],
        'glpi_plugin_glpichat_desktopautobindings' => [
            'columns' => [
                'id' => $column('int unsigned', false, 'AUTO_INCREMENT'),
                'machines_id' => $column('int unsigned'),
                'windows_sid' => $column('varchar(184)'),
                'users_id' => $column('int unsigned'),
                'auths_id' => $column('int unsigned'),
                'sync_anchor' => $column('char(64) ascii_bin'),
                'user_incarnation' => $column('char(64) ascii_bin'),
                'auth_source_fingerprint' => $column('char(64) ascii_bin'),
                'current_grant_id' => $column('char(32) ascii_bin', true),
                'status' => $column('varchar(16)', false, "DEFAULT 'active'"),
                'created_at' => $column('datetime'),
                'updated_at' => $column('datetime'),
                'released_by' => $column('int unsigned', false, 'DEFAULT 0'),
            ],
            'indexes' => [
                'PRIMARY' => $index(['id'], true),
                'desktop_auto_machine_sid' => $index(['machines_id', 'windows_sid'], true),
                'desktop_auto_current_grant' => $index(['current_grant_id'], true),
                'desktop_auto_user' => $index(['users_id']),
            ],
        ],
    ];
}

function glpichat_desktop_schema_tables(): array
{
    return array_keys(glpichat_desktop_schema_definitions());
}

/** Metadata only: no CREATE/ALTER and no installation calls on runtime paths. */
function glpichat_desktop_schema_metadata(): array
{
    global $DB;
    $tables = array_merge(glpichat_desktop_schema_tables(), ['glpi_plugin_glpichat_messages']);
    // All identifiers are fixed in this source file, never request input.
    $in = "'" . implode("','", $tables) . "'";
    $where = "TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ($in)";
    $queries = [
        'tables' => "SELECT TABLE_NAME, ENGINE FROM information_schema.TABLES WHERE $where",
        'columns' => "SELECT TABLE_NAME, COLUMN_NAME, COLUMN_TYPE, COLUMN_DEFAULT, IS_NULLABLE, COLLATION_NAME, EXTRA FROM information_schema.COLUMNS WHERE $where",
        'indexes' => "SELECT TABLE_NAME, INDEX_NAME, NON_UNIQUE, SEQ_IN_INDEX, COLUMN_NAME, SUB_PART FROM information_schema.STATISTICS WHERE $where ORDER BY TABLE_NAME, INDEX_NAME, SEQ_IN_INDEX",
    ];
    $metadata = [];
    foreach ($queries as $kind => $sql) {
        $result = $DB->doQuery($sql);
        if ($result === false) {
            throw new RuntimeException('Desktop schema metadata unavailable.');
        }
        $metadata[$kind] = [];
        while ($row = $DB->fetchAssoc($result)) {
            $metadata[$kind][] = $row;
        }
    }
    return $metadata;
}

/** Full readback for install/admin qualification; deliberately not called on each poll. */
function glpichat_desktop_schema_health(
    bool $check_marker = true,
    ?callable $metadata_reader = null,
    ?callable $config_value = null
): array {
    $metadata_reader ??= 'glpichat_desktop_schema_metadata';
    $config_value ??= static fn (string $key): mixed => Config::getConfigurationValue('plugin:glpichat', $key);
    $issues = [];
    try {
        $metadata = $metadata_reader();
        $tables = [];
        foreach ($metadata['tables'] as $row) {
            $tables[$row['TABLE_NAME']] = strtolower((string) $row['ENGINE']);
        }
        $columns = [];
        foreach ($metadata['columns'] as $row) {
            $columns[$row['TABLE_NAME']][$row['COLUMN_NAME']] = $row;
        }
        $indexes = [];
        foreach ($metadata['indexes'] as $row) {
            $table = (string) $row['TABLE_NAME'];
            $index = (string) $row['INDEX_NAME'];
            $indexes[$table][$index]['unique'] = (int) $row['NON_UNIQUE'] === 0;
            $indexes[$table][$index]['columns'][(int) $row['SEQ_IN_INDEX']] = (string) $row['COLUMN_NAME'];
            if (($row['SUB_PART'] ?? null) !== null) {
                $indexes[$table][$index]['prefix'] = true;
            }
        }
        $definitions = glpichat_desktop_schema_definitions();
        $definitions['glpi_plugin_glpichat_messages'] = [
            'columns' => [],
            'indexes' => ['desktop_followup_id' => ['columns' => ['itilfollowups_id'], 'unique' => false]],
        ];
        foreach ($definitions as $table => $definition) {
            if (($tables[$table] ?? '') !== 'innodb') {
                $issues[] = $table . ':missing_or_nontransactional';
                continue;
            }
            foreach ($definition['columns'] as $name => $expected) {
                $actual = $columns[$table][$name] ?? null;
                if ($actual === null) {
                    $issues[] = $table . '.' . $name . ':missing';
                    continue;
                }
                // MariaDB reports integer display widths; MySQL 8 may omit them.
                $type = strtolower((string) $actual['COLUMN_TYPE']);
                $type = preg_replace('/\b(bigint|int)\([0-9]+\)/', '$1', $type);
                $expected_type = str_replace(' ascii_bin', '', $expected['type']);
                $binary_ascii = str_contains($expected['type'], ' ascii_bin');
                $default_matches = true;
                if (str_starts_with($expected['extra'], 'DEFAULT ')) {
                    // MariaDB quotes literal string defaults, MySQL may not.
                    $expected_default = trim(substr($expected['extra'], 8), "'");
                    $actual_default = $actual['COLUMN_DEFAULT'] ?? null;
                    if (is_string($actual_default) && str_starts_with($actual_default, "'") && str_ends_with($actual_default, "'")) {
                        $actual_default = substr($actual_default, 1, -1);
                    }
                    $default_matches = $actual_default !== null && (string) $actual_default === $expected_default;
                }
                if ($type !== $expected_type
                    || !$default_matches
                    || (($actual['IS_NULLABLE'] === 'YES') !== $expected['nullable'])
                    || ($binary_ascii && ($actual['COLLATION_NAME'] ?? '') !== 'ascii_bin')
                    || ($name === 'id' && !str_contains(strtolower((string) $actual['EXTRA']), 'auto_increment'))
                ) {
                    $issues[] = $table . '.' . $name . ':shape';
                }
            }
            foreach ($definition['indexes'] as $name => $expected) {
                $actual = $indexes[$table][$name] ?? null;
                if ($actual !== null) {
                    ksort($actual['columns']);
                    $actual['columns'] = array_values($actual['columns']);
                }
                if ($actual === null
                    || ($actual['prefix'] ?? false)
                    || $actual['unique'] !== $expected['unique']
                    || $actual['columns'] !== $expected['columns']
                ) {
                    $issues[] = $table . '.' . $name . ':missing_or_shape';
                }
            }
        }
        $key = $config_value('desktop_idempotency_key');
        if (!is_string($key) || preg_match('/\A[a-f0-9]{64}\z/', $key) !== 1) {
            $issues[] = 'desktop_idempotency_key:invalid';
        }
        if ($check_marker) {
            $marker = $config_value('desktop_schema_version');
            if ($marker !== '4' && $marker !== 4) {
                $issues[] = 'desktop_schema_version:unsupported';
            }
        }
    } catch (Throwable $e) {
        // Keep diagnostic location, but never log SQL, credentials or exception text.
        error_log('glpichat desktop schema: ' . get_class($e) . ' at ' . basename($e->getFile()) . ':' . $e->getLine());
        $issues[] = 'schema_metadata:unavailable';
    }
    return ['healthy' => $issues === [], 'issues' => array_values(array_unique($issues)), 'schema_version' => '4'];
}

/** Preserve a future marker when older code is accidentally installed. */
function glpichat_desktop_schema_version_to_store(mixed $raw): string
{
    if ((is_string($raw) || is_int($raw)) && preg_match('/\A[1-9][0-9]*\z/', (string) $raw) === 1) {
        return (int) $raw >= 4 ? (string) $raw : '4';
    }
    return '4';
}

/** Called solely by GLPI's explicit install/update hook. */
function glpichat_desktop_schema_install(
    ?callable $table_exists = null,
    ?callable $execute = null,
    ?callable $metadata_reader = null,
    ?callable $config_value = null,
    ?callable $config_write = null
): void {
    global $DB;
    $table_exists ??= static fn (string $table): bool => (bool) $DB->tableExists($table);
    $execute ??= static fn (string $sql): mixed => $DB->doQuery($sql);
    $metadata_reader ??= 'glpichat_desktop_schema_metadata';
    $config_value ??= static fn (string $key): mixed => Config::getConfigurationValue('plugin:glpichat', $key);
    $config_write ??= static fn (array $values): mixed => Config::setConfigurationValues('plugin:glpichat', $values);
    $previous_marker = $config_value('desktop_schema_version');
    foreach (glpichat_desktop_schema_definitions() as $table => $definition) {
        if ($table_exists($table)) {
            continue;
        }
        $parts = [];
        foreach ($definition['columns'] as $name => $column) {
            $type = str_replace(' ascii_bin', ' CHARACTER SET ascii COLLATE ascii_bin', $column['type']);
            $parts[] = '`' . $name . '` ' . $type . ($column['nullable'] ? ' NULL DEFAULT NULL' : ' NOT NULL') . ' ' . $column['extra'];
        }
        foreach ($definition['indexes'] as $name => $index) {
            $prefix = $name === 'PRIMARY' ? 'PRIMARY KEY' : ($index['unique'] ? 'UNIQUE KEY ' : 'KEY ') . '`' . $name . '`';
            $parts[] = $prefix . ' (`' . implode('`,`', $index['columns']) . '`)';
        }
        $execute('CREATE TABLE `' . $table . '` (' . implode(', ', $parts) . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC');
    }

    // Native public history excludes attachment mirrors by followup ID.
    // Add only the missing index; incompatible existing shapes fail readback.
    $metadata = $metadata_reader();
    $has_followup_index = false;
    foreach ($metadata['indexes'] as $row) {
        if ($row['TABLE_NAME'] === 'glpi_plugin_glpichat_messages' && $row['INDEX_NAME'] === 'desktop_followup_id') {
            $has_followup_index = true;
        }
    }
    if (!$has_followup_index) {
        $execute('ALTER TABLE `glpi_plugin_glpichat_messages` ADD KEY `desktop_followup_id` (`itilfollowups_id`)');
    }

    $key = $config_value('desktop_idempotency_key');
    if ($key === null || $key === false || $key === '') {
        $key = bin2hex(random_bytes(32));
    }
    if (!is_string($key) || preg_match('/\A[a-f0-9]{64}\z/', $key) !== 1) {
        throw new RuntimeException('Desktop idempotency key is invalid; existing key was not replaced.');
    }
    $config_write([
        'desktop_enabled' => (string) $config_value('desktop_enabled') === '1' ? '1' : '0',
        'desktop_idempotency_key' => $key,
    ]);
    $health = glpichat_desktop_schema_health(false, $metadata_reader, $config_value);
    if (!$health['healthy']) {
        throw new RuntimeException('GLPI Chat desktop schema: ' . implode(', ', $health['issues']));
    }
    // This marker is the last write and is never downgraded by an old package.
    $config_write(['desktop_schema_version' => glpichat_desktop_schema_version_to_store($previous_marker)]);
}
