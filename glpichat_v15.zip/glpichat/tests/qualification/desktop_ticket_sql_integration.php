<?php

declare(strict_types=1);

/**
 * Actual production conversation/history/ticket SELECTs executed by MariaDB/MySQL.
 * Uses unmodified pinned GLPI11.0.7 table DDL and the plugin's schema definitions.
 * Creates and drops only a new random test database. Requires a disposable test
 * server account with CREATE/DROP DATABASE rights; never supply production access.
 * Usage: php desktop_ticket_sql_integration.php PLUGIN_ROOT CORE_GLPI_EMPTY_SQL SOCKET [USER]
 * Optional password: GLPICHAT_TEST_DB_PASSWORD (never printed).
 */
if (PHP_SAPI !== 'cli' || $argc < 4 || $argc > 5) {
    fwrite(STDERR, "Usage: desktop_ticket_sql_integration.php PLUGIN_ROOT CORE_GLPI_EMPTY_SQL TEST_SOCKET [USER]\n"); exit(2);
}
[$unused, $plugin, $schemaFile, $socket] = $argv;
if (hash_file('sha256', $schemaFile) !== '5be41e407778eaa321a53a9fddb67b95de611037335836e2bf4cc2bfd554644f') {
    throw new RuntimeException('Unmodified GLPI11.0.7 glpi-empty.sql required.');
}
require $plugin . '/src/desktop/common.php';
require $plugin . '/src/desktop/conversations.php';
require $plugin . '/src/desktop/schema.php';
require $plugin . '/src/db/setup_helpers.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$connection = new mysqli('localhost', $argv[4] ?? 'root', getenv('GLPICHAT_TEST_DB_PASSWORD') ?: '', '', 0, $socket);
$connection->set_charset('utf8mb4');
$database = 'glpichat_ticket_sql_' . bin2hex(random_bytes(8));
$connection->query('CREATE DATABASE `' . $database . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
$connection->select_db($database);
final class DesktopNativeSqlDB
{
    public array $queries = [];
    public function __construct(public mysqli $connection) {}
    public function doQuery(string $query): mysqli_result|bool { $this->queries[] = $query; return $this->connection->query($query); }
    public function fetchAssoc(mysqli_result $rows): array|false|null { return $rows->fetch_assoc(); }
    public function escape(string $value): string { return $this->connection->real_escape_string($value); }
}
$DB = new DesktopNativeSqlDB($connection);
$checks = 0;
function verify(bool $condition, string $message): void { global $checks; if (!$condition) { throw new RuntimeException($message); } ++$checks; }
function unavailable(callable $action): void {
    try { $action(); } catch (GlpichatDesktopException $error) { verify($error->errorCode === 'conversation_unavailable' && $error->httpStatus === 404, 'Current requester/entity/deletion/status guard rejects the ticket'); return; }
    throw new RuntimeException('Expected unavailable ticket');
}
try {
    $coreSchema = file_get_contents($schemaFile);
    foreach (['glpi_tickets', 'glpi_tickets_users', 'glpi_itilfollowups', 'glpi_users'] as $table) {
        if (preg_match('/CREATE TABLE `' . $table . '` \(.*?\) ENGINE=InnoDB[^;]*;/s', $coreSchema, $match) !== 1) { throw new RuntimeException('Core table DDL missing: ' . $table); }
        $connection->query($match[0]);
    }
    $owned = glpichat_schema_queries();
    foreach (['glpi_plugin_glpichat_rooms', 'glpi_plugin_glpichat_messages'] as $table) { $connection->query($owned[$table]); }
    $definition = glpichat_desktop_schema_definitions()['glpi_plugin_glpichat_desktopreads'];
    $parts = [];
    foreach ($definition['columns'] as $name => $column) {
        $type = str_replace(' ascii_bin', ' CHARACTER SET ascii COLLATE ascii_bin', $column['type']);
        $parts[] = '`' . $name . '` ' . $type . ($column['nullable'] ? ' NULL DEFAULT NULL' : ' NOT NULL') . ' ' . $column['extra'];
    }
    foreach ($definition['indexes'] as $name => $index) {
        $prefix = $name === 'PRIMARY' ? 'PRIMARY KEY' : ($index['unique'] ? 'UNIQUE KEY ' : 'KEY ') . '`' . $name . '`';
        $parts[] = $prefix . ' (`' . implode('`,`', $index['columns']) . '`)';
    }
    $connection->query('CREATE TABLE glpi_plugin_glpichat_desktopreads (' . implode(', ', $parts) . ') ENGINE=InnoDB');
    verify($connection->query("SHOW COLUMNS FROM glpi_tickets LIKE 'is_template'")->num_rows === 0, 'Actual GLPI tickets schema has no invented is_template column');
    $connection->query("INSERT INTO glpi_users (id,name,firstname,realname) VALUES (10,'requester','Test','Requester'),(11,'technician','Test','Technician')");
    $connection->query("INSERT INTO glpi_tickets (id,name,status,entities_id,is_deleted,tickettemplates_id) VALUES
        (7,'Ordinary ticket',2,2,0,0),(8,'Created from template',1,2,0,123),(9,'Deleted',2,2,1,0),
        (10,'Foreign entity',2,3,0,0),(11,'Other requester',2,2,0,0),(12,'Observer only',2,2,0,0),
        (13,'Unsupported status',99,2,0,0),(14,'Closed',6,2,0,0),(15,'Solved',5,2,0,0),
        (16,'Technician only',2,2,0,0),(17,'Pending',4,2,0,0),(18,'Planned',3,2,0,0)");
    $connection->query("INSERT INTO glpi_tickets_users (tickets_id,users_id,type) VALUES
        (7,10,1),(8,10,1),(9,10,1),(10,10,1),(11,11,1),(12,10,3),(13,10,1),
        (14,10,1),(15,10,1),(16,10,2),(17,10,1),(18,10,1)");
    $connection->query("INSERT INTO glpi_itilfollowups (id,itemtype,items_id,date,users_id,content,is_private) VALUES
        (101,'Ticket',7,'2026-10-02 12:00:00',11,'Public message',0),
        (102,'Ticket',7,'2026-10-02 12:01:00',11,'Private message',1),
        (103,'Ticket',8,'2026-10-02 12:02:00',10,'Template ticket message',0)");
    $actor = ['user_id' => 10, 'entity_id' => 2, 'can_read' => true, 'can_create' => true];
    $list = glpichat_desktop_conversations($actor, 0, 30);
    $listQuery = $DB->queries[0];
    verify(array_column($list['conversations'], 'ticket_id') === [18,17,15,14,8,7], 'Production list executes against native schema and retains requester/entity/status/deleted boundaries');
    $listed = array_column($list['conversations'], null, 'ticket_id');
    verify($listed[8]['can_send'] === true && $listed[8]['title'] === 'Created from template', 'A real ticket created from a template remains visible and writable');
    verify($listed[7]['unread_count'] === 1 && $listed[7]['latest_message_id'] === 101, 'Native unread aggregate excludes private followups');
    verify($listed[14]['can_send'] === false && $listed[15]['can_send'] === false, 'Closed and solved tickets remain visible as read-only');
    verify(!$list['has_more'] && $list['next_before'] === 0, 'Final list page terminates');
    $page = glpichat_desktop_conversations($actor, 0, 2);
    verify(array_column($page['conversations'], 'ticket_id') === [18,17] && $page['has_more'] && $page['next_before'] === 17, 'Actual list SQL preserves bounded pagination');
    $next = glpichat_desktop_conversations($actor, $page['next_before'], 30);
    verify(array_column($next['conversations'], 'ticket_id') === [15,14,8,7], 'Actual cursor query retains the template-created ticket');
    $start = count($DB->queries);
    verify((int) glpichat_desktop_ticket($actor, 8)['id'] === 8, 'Shared ticket lookup executes against native schema');
    $ticketQuery = $DB->queries[$start];
    $history = glpichat_desktop_history($actor, 7, 0, 50);
    verify(array_column($history['messages'], 'id') === [101], 'Production history executes current ticket guard and excludes private followups');
    verify(glpichat_desktop_history($actor, 8, 0, 50)['messages'][0]['content'] === 'Template ticket message', 'History opens for a ticket created from a template');
    foreach ([false, true] as $locked) {
        $connection->begin_transaction();
        try {
            verify((int) glpichat_desktop_ticket($actor, 8, $locked)['id'] === 8, 'Read and FOR UPDATE variants execute against native schema');
            foreach ([9,10,11,12,13,16] as $ticket) { unavailable(static fn() => glpichat_desktop_ticket($actor, $ticket, $locked)); }
        } finally { $connection->rollback(); }
    }
    $connection->query('DELETE FROM glpi_tickets_users WHERE tickets_id=8 AND users_id=10 AND type=1');
    unavailable(static fn() => glpichat_desktop_history($actor, 8, 0, 50));
    verify(!in_array(8, array_column(glpichat_desktop_conversations($actor, 0, 30)['conversations'], 'ticket_id'), true), 'Requester removal immediately removes list visibility');
    // Reintroduce only the previous defective predicates into the captured real
    // production queries; the SQL engine must reject both with unknown column1054.
    foreach ([str_replace('t.is_deleted = 0', 't.is_deleted = 0 AND t.is_template = 0', $listQuery),
        str_replace('is_deleted = 0', 'is_deleted = 0 AND is_template = 0', $ticketQuery)] as $oldQuery) {
        try { $connection->query($oldQuery); throw new RuntimeException('Previous invalid SQL unexpectedly executed'); }
        catch (mysqli_sql_exception $error) { verify($error->getCode() === 1054, 'Engine reproduces unknown-column failure for the previous production predicate'); }
    }
    echo 'PASS native ticket SQL: ' . $checks . ' assertions; actual ' . $connection->server_info
        . '; pinned GLPI11.0.7 table DDL; production list, shared ticket lookup, history, aggregates and locking SQL; no live GLPI HTTP/session execution.' . "\n";
} finally {
    $connection->query('DROP DATABASE `' . $database . '`');
    $connection->close();
}
