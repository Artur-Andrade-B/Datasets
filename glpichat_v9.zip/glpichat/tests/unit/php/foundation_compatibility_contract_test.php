<?php

declare(strict_types=1);

/**
 * Source-level inherited compatibility boundary for the 1.1.2 desktop pilot.
 *
 * The pilot adds DesktopController and separately owned desktop tables. The
 * inherited browser/Guest bytes and 19-route protocol, scheduler, public assets
 * and seven original tables remain fixed. Desktop invariants have their own
 * schema/auth/conversation tests; this test does not silently allow new files.
 */

require dirname(__DIR__, 2) . '/bootstrap/unit.php';
require_once dirname(__DIR__, 3) . '/src/desktop/schema.php';

$plugin_root = dirname(__DIR__, 3);

$read = static function (string $relative_path) use ($plugin_root): string {
    $content = file_get_contents($plugin_root . '/' . $relative_path);
    if (!is_string($content)) {
        glpichat_unit_fail('Unable to read compatibility fixture: ' . $relative_path);
    }

    return $content;
};

$expected_hashes = [
    'public/css/glpichat.css'                 => '2af5240faa9df663328765bf0555b6f03321267a25a7852890c8ec6396404bde',
    'public/img/launcher-placeholder.png'     => '19c7ce8bae9212f92fd82976bc4444c132f93815f44d37404d2b2a1aa945c9a2',
    'public/img/logo-glpichat.svg'            => 'c3b579d429e3187eddf2ce2581784d0d5b6f7299c1be03647473c7c512805aa7',
    'public/img/screenshots/glpi-screenshots.png' => '1b02b2d113d4179bde0a4ef3b52c08123749ebdb546d607cd194ca567d7601f8',
    'public/js/glpichat-guest.js'             => 'f08cb37d8f200173f24ca098abcf610e9921f8019ad5147f3c7f1d9275a32094',
    'public/js/glpichat-widget.js'            => '0158d2a8346f364ffd84ee21d0186413d1da755d350415a3895a6bc9af00e9f9',
    'src/Controller/GuestController.php'      => 'cbfdb35ef6b1a4c2ee9a1de61a4355cdedcde8911258489f95d7f6a226b5f675',
    'src/Controller/InviteController.php'     => '9a59b3b644ceaf1e90eb47b3f04867983114375aa413cbae2cf40c1cac1d4a50',
    'src/Controller/InviteManageController.php' => '4f468bd921e0cf18caa458e335bfcecc525800323e590b5e25dc0f78cd389ec5',
    'src/Controller/SendController.php'       => 'eb9c6048dfd8ab76f067efc47c786ea092ed9c122b8b9e37092f9db147be7d44',
    'src/Controller/SyncController.php'       => '52e1f211b3bcddd1ad2af7140092fac0a69d9a8b9a48d7231a0121b434593d34',
    'src/Controller/UploadController.php'     => '0dc76407f1f4f5c57397c34f4a1ffe8f9609a13172b209f0ed0a656b475ae376',
    'src/Controller/WidgetController.php'     => '635342b42e5b78fd8f9fd9868dd8c7b8359105df4250e8f27773e76e01a17dcf',
    'src/domain/access.php'                   => 'e953517108d49573434ae1c01ac30d5e9125e1ed10d4dbb1f72d8bb30bfdbbf5',
    'src/db/guest_db.php'                     => 'b0ac0b9147633d9b39aed2195b3472c0400a25415bf3059f8fbaca67d1c42224',
    'src/db/invite_db.php'                    => 'c914924f68c99e0238b3e06629c709071fa7e7f138bf9afd6cd37d7166614026',
    'src/EventCleanupCron.php'                => '3878e001117a3d8cb071edd25cf929666eb2fdd11b8b0a7bee5c2f84dd135ee1',
    'src/flows/guest_flow.php'                => '7249601c3dffd319f6d345fe64f6b7553e0c46cbc99676bd3cdd27677bc292f4',
    'src/flows/invite_flow.php'               => 'a362e9f2d0ec9c8dfdcbc2d5068f5f8a891d9e16e85e5c974d91af3adb43afc6',
    'src/js/glpichat-guest.js'                => '8a21d3cb4f0dc410d248bdd4cfd7c0ad9244795fc5e6ae99a0df1487d3f99b3d',
    'src/js/glpichat-widget.js'               => '6040ed17ee6c452d8e57fdd55d88bfad9b45493d6cb4b50f6d2ebac443df5e3f',
    'src/js/modules/channel-state.js'         => 'ad6e746a790caf6fcc5e7521a2c768c1b7fe7bfe52e5c9c0472feb3054f10eb0',
    'src/js/modules/constants.js'             => '6da8c0749e348bb1942600eb047aaa5f9277dad01cf059f9e6360c7ebd820179',
    'src/js/modules/dom.js'                   => '2aed68172b35d2811a4cab16aa87ff347303056c14786ed0c00c7c756596fc9e',
    'src/js/modules/format.js'                => 'e63dd8878463c8d6649d132ba42ae7e74810148542f2d38f3e9392e043c70639',
    'src/js/modules/http.js'                  => '53a851a2c118fb3a72d242a7c13063019f449fb364ff38ce789f01886114167f',
    'src/js/modules/sanitize.js'              => 'c75b3ab425ccdb1286a5b32bcda372bc78577b7dc5a0dae5874f0a8a2f548b91',
    'src/js/modules/scheduler.js'             => '02a2fd136ad6124c58bef1c436cb63b8dc29735174db568cd76bef347c1e1617',
    'src/js/modules/shared.js'                => 'f4c07c47d9a0b067770a3507562c3c6388bd9486f0e8603279af5d8e99138118',
    'src/js/modules/state.js'                 => 'db9665a787f8e438b38b33088a048f187ca71927615a1428e40a5a3de45321b1',
    'src/js/modules/widget-http.js'           => 'c4edd64965b0213080fa5f2010a10208967d6dd0c421e552a78a2ee25ce84acd',
];

foreach ($expected_hashes as $relative_path => $expected_hash) {
    $actual_hash = hash_file('sha256', $plugin_root . '/' . $relative_path);
    glpichat_unit_assert_same(
        $expected_hash,
        is_string($actual_hash) ? $actual_hash : '',
        '1.1.2 preserves inherited production browser/Guest bytes for ' . $relative_path
    );
}
glpichat_unit_pass('Browser, Guest, controller, invite and cleanup-cron bytes remain production-identical');

$expected_controller_files = [
    'DesktopController.php',
    'GuestController.php',
    'InviteController.php',
    'InviteManageController.php',
    'SendController.php',
    'SyncController.php',
    'UploadController.php',
    'WidgetController.php',
];
$controller_paths = glob($plugin_root . '/src/Controller/*.php') ?: [];
$actual_controller_files = array_map('basename', $controller_paths);
sort($actual_controller_files, SORT_STRING);
glpichat_unit_assert_same_array(
    $expected_controller_files,
    $actual_controller_files,
    '1.1.2 adds only the explicitly allowed DesktopController file'
);

$expected_public_files = [];
foreach (array_keys($expected_hashes) as $relative_path) {
    if (str_starts_with($relative_path, 'public/')) {
        $expected_public_files[] = substr($relative_path, strlen('public/'));
    }
}
sort($expected_public_files, SORT_STRING);
$actual_public_files = [];
$public_iterator = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($plugin_root . '/public', FilesystemIterator::SKIP_DOTS)
);
foreach ($public_iterator as $public_file) {
    if ($public_file->isFile()) {
        $actual_public_files[] = str_replace('\\', '/', substr(
            $public_file->getPathname(),
            strlen($plugin_root . '/public/')
        ));
    }
}
sort($actual_public_files, SORT_STRING);
glpichat_unit_assert_same_array(
    $expected_public_files,
    $actual_public_files,
    '1.1.2 has exactly the inherited public asset file set'
);
glpichat_unit_pass('Controller and browser-public file inventories cannot grow silently');

$controller_source = '';
foreach ($controller_paths as $controller_path) {
    if (basename($controller_path) === 'DesktopController.php') {
        continue; // Audited separately; inherited protocol below stays exact.
    }
    $source = file_get_contents($controller_path);
    if (!is_string($source)) {
        glpichat_unit_fail('Unable to read controller route source: ' . basename($controller_path));
    }
    $controller_source .= "\n" . $source;
}

preg_match_all(
    "/#\\[Route\\(\\s*'([^']+)'\\s*,\\s*name:\\s*'([^']+)'\\s*,\\s*methods:\\s*\\[([^]]+)\\]\\s*\\)\\]/",
    $controller_source,
    $route_matches,
    PREG_SET_ORDER
);
glpichat_unit_assert_same(
    19,
    substr_count($controller_source, '#[Route('),
    'Controller source contains exactly 19 route attributes'
);
glpichat_unit_assert_same(
    19,
    count($route_matches),
    'Every route attribute matches the inherited path/name/method contract syntax'
);

$actual_routes = [];
foreach ($route_matches as $match) {
    preg_match_all("/'([^']+)'/", (string) $match[3], $method_matches);
    $methods = $method_matches[1] ?? [];
    sort($methods, SORT_STRING);
    $actual_routes[] = implode(',', $methods) . ' ' . $match[1] . ' ' . $match[2];
}
sort($actual_routes, SORT_STRING);

$expected_routes = [
    'GET /Accept/{token} glpichat_accept',
    'GET /Guest glpichat_guest_page',
    'GET /Guest/Sync glpichat_guest_sync',
    'GET /Invite/List glpichat_invite_list',
    'GET /Sync glpichat_sync',
    'GET /Widget/Channels glpichat_widget_channels',
    'GET /Widget/Config glpichat_widget_config',
    'GET /Widget/History glpichat_widget_history',
    'POST /Guest/Leave glpichat_guest_leave',
    'POST /Guest/Send glpichat_guest_send',
    'POST /Guest/Upload glpichat_guest_upload',
    'POST /Invite glpichat_invite',
    'POST /Invite/Reissue glpichat_invite_reissue',
    'POST /Invite/Revoke glpichat_invite_revoke',
    'POST /Send glpichat_send',
    'POST /Upload glpichat_upload',
    'POST /Widget/Leave glpichat_widget_leave',
    'POST /Widget/MarkRead glpichat_widget_mark_read',
    'POST /Widget/Poll glpichat_widget_poll',
];
sort($expected_routes, SORT_STRING);

glpichat_unit_assert_same_array($expected_routes, $actual_routes, '1.1.2 preserves the inherited 19-route browser/Guest protocol');
foreach (['/External', 'External/V1', '/Capabilities'] as $forbidden_route) {
    if (str_contains($controller_source, $forbidden_route)) {
        glpichat_unit_fail('Inherited controllers must not contain new external routes: ' . $forbidden_route);
    }
}
glpichat_unit_pass('No External or Capabilities route is present');

$setup = $read('setup.php');
glpichat_unit_assert_same(
    2,
    substr_count($setup, 'registerPluginStatelessPath'),
    '1.1.2 has exactly the inherited Guest and explicit Desktop registrations'
);
if (!str_contains($setup, "registerPluginStatelessPath('glpichat', '#^/Guest/.*#')")) {
    glpichat_unit_fail('The inherited Guest stateless registration must remain unchanged.');
}
if (!str_contains($setup, "registerPluginStatelessPath('glpichat', '#^/Desktop/V1(?:/|$)#')")) {
    glpichat_unit_fail('Desktop must use its exact bounded API prefix.');
}
glpichat_unit_pass('Stateless registrations are bounded to Guest and Desktop/V1');

$hook = $read('hook.php');
$runtime_php_sources = $read('setup.php') . "\n" . $hook . "\n" . $read('front/config.php');
$runtime_iterator = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($plugin_root . '/src', FilesystemIterator::SKIP_DOTS)
);
foreach ($runtime_iterator as $runtime_file) {
    if ($runtime_file->isFile() && strtolower($runtime_file->getExtension()) === 'php') {
        $runtime_source = file_get_contents($runtime_file->getPathname());
        if (!is_string($runtime_source)) {
            glpichat_unit_fail('Unable to read runtime PHP source: ' . $runtime_file->getPathname());
        }
        $runtime_php_sources .= "\n" . $runtime_source;
    }
}
glpichat_unit_assert_same(
    3,
    substr_count($runtime_php_sources, 'addCrontask('),
    '1.1.2 runtime contains no delegated or additional scheduled task registration'
);
foreach (['CleanEvents', 'CleanMessages', 'CleanAuditlogs'] as $cron_name) {
    glpichat_unit_assert_same(
        1,
        substr_count($hook, "addCrontask(\\GlpiPlugin\\Glpichat\\EventCleanupCron::class, '{$cron_name}'"),
        'Inherited cleanup task remains singular: ' . $cron_name
    );
}
glpichat_unit_pass('Only the three inherited daily cleanup tasks are registered');

$expected_tables = [
    'glpi_plugin_glpichat_rooms',
    'glpi_plugin_glpichat_participants',
    'glpi_plugin_glpichat_messages',
    'glpi_plugin_glpichat_events',
    'glpi_plugin_glpichat_invites',
    'glpi_plugin_glpichat_readstates',
    'glpi_plugin_glpichat_auditlogs',
];
glpichat_unit_assert_same_array($expected_tables, glpichat_table_names(), 'Inherited browser data schema remains seven tables');
glpichat_unit_assert_same_array([
    'glpi_plugin_glpichat_desktopdevices',
    'glpi_plugin_glpichat_desktopsends',
    'glpi_plugin_glpichat_desktopreads',
], glpichat_desktop_schema_tables(), 'Desktop pilot adds only its three owned tables');
glpichat_unit_pass('Browser and desktop data ownership remain explicit');

$config_page = $read('front/config.php');
$widget_controller = $read('src/Controller/WidgetController.php');
foreach ([
    'public_authorization_shadow_enabled',
    'public_projection_shadow_enabled',
    'external_v1_enabled',
    'external_v1_enrollment_enabled',
    'external_v1_read_enabled',
    'external_v1_write_enabled',
] as $foundation_flag) {
    if (str_contains($config_page, $foundation_flag) || str_contains($widget_controller, $foundation_flag)) {
        glpichat_unit_fail('Internal foundation flag leaked into browser configuration/protocol: ' . $foundation_flag);
    }
}
glpichat_unit_pass('Internal foundation flags are absent from the browser config form and Widget/Config payload');

$composer = json_decode($read('composer.json'), true, 512, JSON_THROW_ON_ERROR);
$package = json_decode($read('package.json'), true, 512, JSON_THROW_ON_ERROR);
glpichat_unit_assert_same_array(['php' => '>=8.2'], $composer['require'] ?? [], 'Composer runtime requirements remain PHP-only');
glpichat_unit_assert_true(!array_key_exists('dependencies', $package), 'No JavaScript runtime dependency section is introduced');
glpichat_unit_pass('1.1.2 adds no PHP/JavaScript runtime dependency');

fwrite(STDOUT, "[PASS] 1.1.2 inherited foundation compatibility contract completed\n");
