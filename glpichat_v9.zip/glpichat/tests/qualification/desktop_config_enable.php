<?php

declare(strict_types=1);

/**
 * CLI-only regression for the real desktop configuration POST handler.
 *
 * Usage:
 *   php desktop_config_enable.php /path/to/glpichat /path/to/autoload.php
 *
 * The autoloader must provide the real Symfony HttpFoundation Request (GLPI
 * 11.0.7 pins v6.4.35). No Request replacement is defined here. The selected
 * source tree's config.php and common.php are copied unchanged into a temporary
 * GLPI-shaped directory. Its actual functions.php supplies plugin helpers.
 *
 * ONLY core bootstrap/Config/Session/Html/translation and schema-health results
 * are fixtures. Save and redirect sentinels stop before unrelated UI rendering.
 * This is not a GLPI boot, CSRF, permissions, database or browser integration test.
 * Pass the old desktop2 tree to reproduce rejection of the healthy HTTPS case.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

$sourceRoot = realpath($argv[1] ?? dirname(__DIR__, 2));
$autoload = $argv[2] ?? getenv('GLPICHAT_HTTP_FOUNDATION_AUTOLOAD');
if ($sourceRoot === false || !is_file($sourceRoot . '/front/config.php')
    || !is_file($sourceRoot . '/src/desktop/common.php')
    || !is_file($sourceRoot . '/src/functions.php')
    || !is_string($autoload) || !is_file($autoload)) {
    fwrite(STDERR, "Usage: php desktop_config_enable.php /path/to/glpichat /path/to/real-symfony-autoload.php\n");
    exit(2);
}
require $autoload;
if (!class_exists(\Symfony\Component\HttpFoundation\Request::class)) {
    fwrite(STDERR, "The supplied autoloader must provide real Symfony HttpFoundation.\n");
    exit(2);
}

final class DesktopConfigSaved extends RuntimeException {}
final class DesktopConfigRedirect extends RuntimeException {}

/** Explicit core persistence fixture: capture the actual handler's write. */
final class Config
{
    public static array $writes = [];

    public static function getConfigurationValue(string $context, string $name): mixed
    {
        return null;
    }

    public static function setConfigurationValues(string $context, array $values): void
    {
        self::$writes[] = ['context' => $context, 'values' => $values];
        throw new DesktopConfigSaved();
    }
}

/** Explicit authenticated-admin fixture; actual core authorization is not tested. */
final class Session
{
    public static array $checks = [];
    public static array $messages = [];

    public static function checkRight(string $name, int $right): void
    {
        self::$checks[] = [$name, $right];
    }

    public static function addMessageAfterRedirect(string $message, bool $checkOnce = false, int $type = 0): void
    {
        self::$messages[] = $message;
    }
}

/** Explicit core HTML boundary fixture; stop on redirect, before any full render. */
final class Html
{
    public static function header(mixed ...$arguments): void {}

    public static function back(): never
    {
        throw new DesktopConfigRedirect();
    }
}

function __(string $message, string $domain = ''): string
{
    return $message;
}

define('READ', 1);
define('UPDATE', 2);
define('ERROR', 3);
require $sourceRoot . '/src/functions.php';

$tempRoot = sys_get_temp_dir() . '/glpichat-config-' . bin2hex(random_bytes(12));
$pluginRoot = $tempRoot . '/plugins/glpichat';
$assertions = 0;
$savedServer = $_SERVER;
$savedPost = $_POST;

$cleanup = static function () use ($tempRoot): void {
    if (!is_dir($tempRoot)) {
        return;
    }
    $entries = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($tempRoot, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($entries as $entry) {
        if ($entry->isDir() && !$entry->isLink()) {
            rmdir($entry->getPathname());
        } else {
            unlink($entry->getPathname());
        }
    }
    rmdir($tempRoot);
};
register_shutdown_function($cleanup);

set_error_handler(static function (int $severity, string $message, string $file, int $line): bool {
    // Repeated includes run independent request cases in this one CLI process.
    // The unmodified front file defines the same fixed temp-root constant each
    // time. Ignore only that known repeat; all other PHP warnings fail the test.
    if ($severity === E_WARNING && $message === 'Constant GLPI_ROOT already defined') {
        return true;
    }
    throw new ErrorException($message, 0, $severity, $file, $line);
});

$check = static function (bool $condition, string $message) use (&$assertions): void {
    ++$assertions;
    if (!$condition) {
        throw new RuntimeException($message);
    }
};

try {
    foreach ([$tempRoot . '/inc', $pluginRoot . '/front', $pluginRoot . '/src/desktop'] as $directory) {
        mkdir($directory, 0700, true);
    }
    copy($sourceRoot . '/front/config.php', $pluginRoot . '/front/config.php');
    copy($sourceRoot . '/src/desktop/common.php', $pluginRoot . '/src/desktop/common.php');
    file_put_contents($tempRoot . '/inc/includes.php', "<?php\n// Core-bootstrap fixture only; no GLPI instance is loaded.\n");
    file_put_contents($pluginRoot . '/src/desktop/schema.php', <<<'PHP'
<?php
// Explicit schema result fixture; this test executes no schema or database work.
function glpichat_desktop_schema_health(): array
{
    return ['healthy' => $GLOBALS['desktop_config_schema_healthy'], 'issues' => [], 'schema_version' => '1'];
}
PHP);

    $check(hash_file('sha256', $sourceRoot . '/front/config.php') === hash_file('sha256', $pluginRoot . '/front/config.php'), 'Configuration source must be copied unchanged.');
    $check(hash_file('sha256', $sourceRoot . '/src/desktop/common.php') === hash_file('sha256', $pluginRoot . '/src/desktop/common.php'), 'URL resolver source must be copied unchanged.');

    $run = static function (bool $secure, bool $healthy, string $basePath = '', int $port = 443, string $configuredUrl = '') use ($pluginRoot, $tempRoot): array {
        global $CFG_GLPI;
        Config::$writes = [];
        Session::$checks = [];
        Session::$messages = [];
        $GLOBALS['desktop_config_schema_healthy'] = $healthy;
        $CFG_GLPI = ['url_base' => $configuredUrl, 'root_doc' => $basePath];
        $_SERVER = [
            'REQUEST_METHOD' => 'POST',
            'HTTPS' => $secure ? 'on' : 'off',
            'HTTP_HOST' => 'support.example.test' . ($port === 443 || $port === 80 ? '' : ':' . $port),
            'SERVER_NAME' => 'support.example.test',
            'SERVER_PORT' => (string) $port,
            'REMOTE_ADDR' => '192.0.2.10',
            'SCRIPT_FILENAME' => $tempRoot . '/public/index.php',
            'SCRIPT_NAME' => $basePath . '/index.php',
            'PHP_SELF' => $basePath . '/index.php',
            'REQUEST_URI' => $basePath . '/plugins/glpichat/front/config.php',
        ];
        $_POST = [
            'update' => '1', 'desktop_enabled' => '1', 'external_followup_user_id' => '0',
            'poll_focused_ms' => '2500', 'poll_idle_ms' => '9000', 'poll_bg_ms' => '18000',
            'guest_poll_ms' => '5000', 'meta_sync_ms' => '15000', 'invite_poll_ms' => '10000',
            'poll_max_channels' => '20', 'user_inactivity_timeout_s' => '120',
            'guest_session_ttl' => '3600', 'invite_ttl_seconds' => '3600',
            'guest_send_throttle_s' => '2', 'accept_rate_limit_window_s' => '60',
            'accept_rate_limit_max_attempts' => '10', 'max_invites_per_ticket' => '10',
            'desktop_max_open' => '3', 'widget_default_position' => 'bottom-right',
            'typing_indicator_timeout_ms' => '3000', 'auto_scroll_threshold_px' => '160',
            'unread_badge_threshold' => '2', 'history_page_default' => '30', 'history_page_max' => '50',
            'events_retention_days' => '30', 'messages_retention_days' => '365', 'auditlogs_retention_days' => '180',
        ];
        // This is the real HttpFoundation object passed to the actual front file,
        // as GLPI's LegacyFileLoadController does when requiring a legacy script.
        $request = \Symfony\Component\HttpFoundation\Request::createFromGlobals();
        $outcome = 'rendered';
        ob_start();
        try {
            include $pluginRoot . '/front/config.php';
        } catch (DesktopConfigSaved) {
            $outcome = 'saved';
        } catch (DesktopConfigRedirect) {
            $outcome = 'redirected';
        } finally {
            ob_end_clean();
        }
        return ['outcome' => $outcome, 'url' => $desktop_base_url ?? '', 'messages' => Session::$messages];
    };

    $result = $run(true, true);
    $check($result['outcome'] === 'saved', 'HTTPS with healthy schema and empty url_base must enable desktop; observed ' . $result['outcome'] . '. ' . implode(' ', $result['messages']));
    $check(count(Config::$writes) === 1 && Config::$writes[0]['context'] === 'plugin:glpichat', 'The real handler must make exactly one plugin configuration write.');
    $check(Config::$writes[0]['values']['desktop_enabled'] === '1', 'The actual submitted desktop flag must be persisted as enabled.');
    $check($result['url'] === 'https://support.example.test', 'Configuration handler must derive the current HTTPS origin without url_base.');
    $check($result['messages'] === [], 'Successful enable must not display a configuration error.');
    $check(Session::$checks === [['plugin_glpichat_admin', READ], ['plugin_glpichat_admin', UPDATE]], 'The form must retain both inherited right-check calls.');

    $result = $run(true, true, '/glpi', 8443);
    $check($result['outcome'] === 'saved' && Config::$writes[0]['values']['desktop_enabled'] === '1', 'HTTPS subdirectory deployment must enable desktop.');
    $check($result['url'] === 'https://support.example.test:8443/glpi', 'Configuration handler must preserve port and GLPI subdirectory.');

    $result = $run(true, false);
    $check($result['outcome'] === 'redirected', 'Unhealthy schema must reject enablement.');
    $check(Config::$writes === [] && count($result['messages']) === 1, 'Schema rejection must show an error and perform no configuration write.');

    // Even an unrelated HTTPS configuration value cannot turn an HTTP request
    // into a secure request or bypass the actual connection requirement.
    $result = $run(false, true, '', 80, 'https://old.example.test');
    $check($result['outcome'] === 'redirected', 'Plain HTTP must reject enablement.');
    $check(Config::$writes === [] && count($result['messages']) === 1, 'HTTP rejection must show an error and perform no configuration write.');

    echo "desktop_config_enable: PASS ($assertions assertions; actual config/common + real Symfony Request; core/schema fixtures; no GLPI/DB integration).\n";
} catch (Throwable $error) {
    fwrite(STDERR, 'desktop_config_enable: FAIL: ' . $error->getMessage() . "\n");
    exit(1);
} finally {
    $_SERVER = $savedServer;
    $_POST = $savedPost;
    restore_error_handler();
    $cleanup();
}
