# Managed connection controls and runtime reporting

Managed desktop credentials are deployment policy. The normal user can inspect
status and retry connectivity but cannot disable the managed connection through
the Widget or the GLPI connection page. The shared self-revoke service checks
ownership, then managed registration or the original managed creation marker,
before any mutation. A managed credential with missing registration metadata also
fails authentication explicitly rather than falling back to personal access.
Old Widgets receive HTTP 403 with
`managed_connection_required`; they never receive `ok: true`, which would cause
them to clear their local credentials. Legacy browser-approved personal devices
retain self-revocation. This rule also applies when an administrator uses the
personal connection page: administrative revocation uses its dedicated path.

Administrative grant revocation still invalidates chat access and renewal.
`Liberar nova conexão` releases one automatic binding so a fresh credential can
be issued; it never restores the revoked token. Historical revocations are not
reactivated because older records do not distinguish user and administrator
origins. Revoking machine management blocks management commands and new automatic
authorizations; it does not itself invalidate existing chat credentials.

Schema 8's existing nullable `desktopmachines.runtime_json` stores three
independent optional snapshots. Widget execution reports retain the existing
format. Supervisor reports additionally track running Bootstrap versions and
supervisor totals, including standby supervisors that do not own a Widget.
`runtime_supervisor_current_sessions` means the count matching the installed
Bootstrap version reported in the same poll. Delivery reports record the expected
Bootstrap version, phase, error, retry time and pending state. Component versions
are independent; a newer Agent/Widget version never implies that Bootstrap needs
an update.

Each group is bounded and validated independently. Missing fields on an older
client mark that group unreported without refreshing its last reception time.
Reports older than five minutes lose current status. Invalid optional telemetry
cannot fail the authenticated management command loop and never invents healthy
runtime. Reports remain advisory: the installed-payload assignment result and
running adoption are shown separately. Fleet rendering uses the paginated row's
stored snapshot without per-machine SQL or remote requests.

Regression coverage includes the actual browser page and shared policy, managed
HTTP controller dispatch, preserved administrator revoke/release behavior, and
compiled `ManagementClient.BuildPollBody` JSON through the PHP management
controller, persistence boundary and fleet presentation. SQL/session fixtures
are labeled; these tests do not claim deployed GLPI, Windows or AD execution.
