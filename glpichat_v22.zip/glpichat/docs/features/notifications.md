# Notificações — Documentação Técnica

> **Audiência:** Administrador técnico
> **Relacionado:** [Seção no README principal](../../README.md#-notificações-personalizadas)

## O que faz

Registra oito eventos e os modos nativos AJAX e email no sistema de notificações do GLPI. Quando mensagens são enviadas ou convidados entram e saem, o plugin levanta o evento; o GLPI decide quais canais habilitados processar e quando entregá-los.

## Fluxo completo

### Como configurar

1. Acesse **Administração > Notificações** no GLPI.
2. Filtre por "GLPI CHAT" na lista — os 8 eventos registrados aparecerão.
3. Para cada notificação: edite o modelo de email, adicione ou remova destinatários, ative ou desative o evento individualmente.
4. Salve. As alterações entram em vigor imediatamente para os próximos eventos.

### Como funciona a entrega

Quando um evento ocorre (ex: mensagem enviada no canal público):
1. O envio grava a intenção de notificação na mesma transação da mensagem. A ação automática `DeliverChatNotifications` relê a origem e chama `NotificationEvent::raiseEvent()`; isso evita preparar notificações dentro da requisição de envio.
2. O GLPI avalia os destinatários configurados para aquele evento no perfil de notificação.
3. O GLPI processa os meios e destinatários configurados no subsistema nativo de notificações (por exemplo, email). O Poll do GLPI Chat transporta mensagens/eventos do chat e não possui payload nem lógica própria de toast de notificação.

### Capacidade, tentativas e retenção operacional

Cada execução prepara no máximo 100 intenções, com orçamento de 10 segundos verificado **entre transações**. Uma preparação nativa já iniciada termina antes da próxima verificação; esse orçamento não interrompe uma chamada nativa lenta. As intenções vencidas são processadas por `available_at` e ID. Falhas permanecem pendentes, com espera crescente de 60 segundos até uma hora, sem descartar mensagens ou tentativas antigas.

O log da ação automática informa pendências, intenções prontas, itens em nova tentativa, maior número de tentativas e data da pendência mais antiga. Para consultar os mesmos indicadores sem executar entregas:

```sh
php plugins/glpichat/bin/notification-queue-status.php
```

A consulta é somente leitura e não retorna texto, destinatários ou credenciais. Uma fila cuja idade/quantidade aumenta continuamente exige verificar a execução das ações automáticas, os erros de preparação e a capacidade no ambiente. A taxa real depende do custo dos modelos, destinatários e meios nativos; o limite de 100 não é uma garantia de vazão.

Cada execução remove no máximo 500 intenções já concluídas (`done`) ou suprimidas (`suppressed`) há mais de 30 dias. Pendências nunca entram nessa limpeza. Os recibos de envio/idempotência de mensagens, anexos e convidados pertencem a outra política e não são alterados por essa rotina. A atualização explícita do plugin adiciona o índice `notification_completed` usado nessa manutenção.

## Permissões — detalhamento

As notificações não têm um direito próprio no GLPI Chat. A entrega segue os direitos dos canais:

- Notificações de `glpichat_public_message` e `glpichat_guest_message` só fazem sentido para usuários com `plugin_glpichat_public` (Read).
- Notificações de `glpichat_internal_message` só fazem sentido para usuários com `plugin_glpichat_internal` (Read).
- A **configuração** das notificações (criar/editar modelos, ativar/desativar eventos) exige o direito nativo do GLPI `config` (UPDATE) em **Administração > Notificações**.

## Tabelas de referência

### Eventos disponíveis

| Evento (código interno) | Disparado quando | Para quem |
|------------------------|------------------|-----------|
| `glpichat_public_message` | Alguém envia mensagem no canal Solicitante | Técnicos designados, grupos, observadores |
| `glpichat_internal_message` | Alguém envia mensagem no canal Discussão técnica | Técnicos designados, grupos, observadores |
| `glpichat_guest_message` | Um convidado externo envia mensagem | Técnicos designados, grupos, observadores |
| `glpichat_guest_joined` | Um convidado aceita o convite e entra no chat | Técnicos designados, grupos, observadores |
| `glpichat_guest_left` | Um convidado sai do chat (fecha a aba) | Técnicos designados, grupos, observadores |
| `glpichat_guest_left_timeout` | Sessão do convidado expira por inatividade | Técnicos designados, grupos, observadores |
| `glpichat_user_joined` | Entrada de usuário por um fluxo que solicita notificação síncrona; os caminhos interativos History/Poll/MarkRead do perf2 suprimem esta entrega | Destinatários configurados no GLPI |
| `glpichat_user_left` | Saída explícita ou expiração processada de participante | Destinatários configurados no GLPI |

### Tags disponíveis no modelo de notificação

| Tag | O que retorna | Exemplo |
|-----|---------------|---------|
| `##glpichat.ticket_label##` | Nome e ID do chamado | `Helpdesk Ticket #42` |
| `##glpichat.sender_name##` | Nome de quem enviou a mensagem | `João Silva` / `Convidado #7` / `Sistema` |
| `##glpichat.message_preview##` | Preview da mensagem (máx. 180 caracteres) ou texto do evento | `Estou com problema no sistema...` |
| `##glpichat.unread_count##` | Total de mensagens não lidas (só aparece se >= 2) | `3` |
| `##glpichat.unread_badge##` | Badge formatado com total de não lidas | `(3)` |

## Comportamentos não óbvios

### Entrega pertence ao subsistema nativo do GLPI

O plugin levanta o evento e deixa o GLPI decidir os canais configurados. Não atribua timing de entrega ao intervalo de Poll do widget: perf2 pode pausar Poll durante uma History ativa/falha, e esse endpoint não consulta notificações pendentes.

### Destinatários ainda obedecem filtros

Os destinatários são definidos pelas regras/modelos do GLPI e pelos filtros de segurança do plugin, incluindo a remoção de usuários sem acesso ao canal interno. O widget não implementa uma regra própria de toast para o remetente.

### Notificações de convidado sempre aparecem como evento de sistema

As tags `##glpichat.sender_name##` para eventos de convidado retornam o nome informado no convite (ex: `João`), não um ID de usuário GLPI.

### Presença de usuário no perf2

Abrir uma sala continua criando o participante e o evento persistente `user_joined` usado na timeline/auditoria. Para remover trabalho síncrono da hidratação, History, Poll e MarkRead passam `raise_presence_notification=false`; portanto a notificação GLPI `glpichat_user_joined` não é levantada por esses caminhos. `glpichat_user_left` continua sendo levantado na saída explícita. A expiração global de participantes não roda mais dentro de cada Poll; presença obsoleta pode durar até uma saída explícita ou rotina administrativa dedicada.

## Limitações conhecidas

- As definições padrão do plugin registram os modos nativos AJAX e email. O plugin não implementa SMS, webhook ou um toast próprio no widget.
- As notificações seguem as mesmas regras de throttling e fila do sistema de notificações do GLPI — emails podem atrasar em instâncias com alta carga.
- Não é possível configurar destinatários diferentes por chamado — a configuração de destinatários é global por tipo de evento.
- O evento `glpichat_guest_left_timeout` pode demorar até o próximo ciclo de detecção de inatividade para ser disparado (não é instantâneo).
- A notificação GLPI de entrada de usuário fica deliberadamente suprimida nos caminhos interativos do perf2; o evento persistente `user_joined` continua existindo.

<br>

<p align="center">
  <sub>━━━━━━━━━━━━━━━━━━━━━━━</sub><br>
  <sub>Curtiu o plugin? Deixe uma ⭐ no repositório para ajudar outros administradores a encontrá-lo.</sub><br>
  <sub>Desenvolvido e mantido com apoio de <a href="https://www.forq.com.br/">Forq</a></sub>
</p>
