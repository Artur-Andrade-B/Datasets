<?php
declare(strict_types=1);
/** Actual controller/services/Symfony/OpenSSL/ZIP/files; explicit DB/config/container fixtures. */
namespace Glpi\Controller { abstract class AbstractController {} }
namespace {
    if (PHP_SAPI !== 'cli' || $argc !== 3) { fwrite(STDERR, "Usage: desktop_management_controller.php PLUGIN_ROOT AUTOLOAD\n"); exit(2); }
    [$unused, $plugin, $autoload] = $argv; require $autoload;
    final class Config {
        public static array $values = ['desktop_schema_version' => '8', 'desktop_enabled' => '0'];
        public static int $reads = 0;
        public static function getConfigurationValues(string $context): array { ++self::$reads; return self::$values; }
    }
    require $plugin . '/tests/fixtures/desktop_management_db.php';
    $temporary = sys_get_temp_dir() . '/glpichat-management-http-' . bin2hex(random_bytes(8)); mkdir($temporary, 0700);
    define('GLPI_PLUGIN_DOC_DIR', $temporary . '/private');
    require $plugin . '/src/Controller/ManagementController.php';
    $DB = new DesktopManagementDB(); $controller = new \GlpiPlugin\Glpichat\Controller\ManagementController(); $checks = 0;
    $check = static function(bool $condition, string $message) use (&$checks): void { ++$checks; if (!$condition) { throw new \RuntimeException($message); } };
    $cleanup = static function(string $path) use (&$cleanup): void {
        if (is_dir($path) && !is_link($path)) { foreach (scandir($path) as $name) { if ($name !== '.' && $name !== '..') { $cleanup($path . '/' . $name); } } rmdir($path); }
        elseif (file_exists($path) || is_link($path)) { unlink($path); }
    };
    $call = static function(string $operation, string $method, mixed $body = null, ?string $token = null, ?string $installation = null, array $headers = []) use ($controller): array {
        $server = array_replace(['REQUEST_METHOD' => $method, 'HTTPS' => 'off', 'SERVER_PORT' => 80, 'HTTP_HOST' => 'backend.internal', 'HTTP_X_FORWARDED_PROTO' => 'https', 'HTTP_ORIGIN' => 'https://unrelated.example', 'CONTENT_TYPE' => 'application/json'], $headers);
        if ($token !== null) { $server['HTTP_AUTHORIZATION'] = 'Bearer ' . $token; }
        if ($installation !== null) { $server['HTTP_X_GLPICHAT_INSTALLATION'] = $installation; }
        $request = new \Symfony\Component\HttpFoundation\Request([], [], [], ['GLPI_SESSION' => 'not-a-machine-token'], [], $server, is_string($body) ? $body : json_encode($body ?? new \stdClass()));
        $response = $controller->dispatch($request, $operation);
        return [$response->getStatusCode(), $response instanceof \Symfony\Component\HttpFoundation\JsonResponse ? json_decode($response->getContent(), true, 512, JSON_THROW_ON_ERROR) : null, $response];
    };
    try {
        $deployment = glpichat_management_deployment('http://lab.example/glpi', '', 2, 7, 1);
        $token = str_repeat('a', 64); $installation = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
        $registration = ['registration_id' => $deployment['registration_id'], 'registration_secret' => $deployment['registration_secret'], 'installation_id' => $installation, 'machine_token' => $token, 'computer_name' => 'API_TEST', 'bootstrap_version' => '0.3.0'];
        [$status, $body] = $call('Register', 'POST', '{broken'); $check($status === 400 && $body['error']['code'] === 'invalid_json', 'Malformed JSON has client-error response');
        [$status] = $call('Register', 'POST', $registration, null, null, ['CONTENT_TYPE' => 'text/plain']); $check($status === 415, 'Non-JSON registration refused');
        [$status, $body] = $call('Register', 'POST', array_replace($registration, ['registration_secret' => str_repeat('b', 64)]));
        $check($status === 401 && $body['error']['code'] === 'registration_invalid' && $DB->tables[GLPICHAT_MANAGEMENT_MACHINES] === [], 'Wrong deployment secret cannot create a machine');
        Config::$reads = 0; [$status, $registered, $response] = $call('Register', 'POST', $registration);
        $check($status === 200 && $registered['installation_id'] === $installation && $registered['ok'], 'Actual registration dispatch succeeds on backend HTTP with chat disabled');
        $check(Config::$reads === 1 && $DB->tables[GLPICHAT_MANAGEMENT_GRANTS][0]['used_count'] === 1, 'Request shares config snapshot and consumes one grant use');
        $check(!$response->headers->has('Access-Control-Allow-Origin') && str_contains($response->headers->get('Cache-Control'), 'no-store'), 'Irrelevant browser headers do not grant CORS or cacheability');
        $check(!str_contains($response->getContent(), $token) && !str_contains($response->getContent(), $deployment['registration_secret']), 'Registration response never echoes machine or deployment credentials');
        [$status, $again] = $call('Register', 'POST', $registration);
        $check($status === 200 && $again === $registered && $DB->tables[GLPICHAT_MANAGEMENT_GRANTS][0]['used_count'] === 1, 'Lost registration response retry is idempotent through controller');
        $poll = ['bootstrap_version' => '0.3.0', 'current_version' => '0.2.0', 'current_sequence' => 1, 'current_slot' => 'a', 'health' => 'healthy', 'result' => '', 'error_code' => '', 'assignment_id' => 0];
        [$status, $body, $response] = $call('Poll', 'POST', $poll);
        $check($status === 401 && $response->headers->get('WWW-Authenticate') === 'Bearer realm="GLPIChat Management"', 'Cookie-only request cannot authorize a machine poll');
        [$status] = $call('Poll', 'POST', $poll, str_repeat('c', 64), $installation); $check($status === 401, 'Another bearer cannot use this installation identity');
        [$status] = $call('Poll', 'POST', $poll, $token); $check($status === 400, 'Machine bearer still requires its explicit installation header');
        [$status, $body] = $call('Poll', 'POST', $poll, $token, $installation); $check($status === 200 && $body['assignment'] === null, 'Registered machine polls without implicit deployment');
        // Optional cross-language contract: use the actual compiled client's
        // serialized SafeReport result instead of rebuilding its wire fields.
        $wirePath = getenv('GLPICHAT_RUNTIME_WIRE_FILE');
        $runtimeReport = $wirePath ? json_decode(file_get_contents($wirePath), true, 16, JSON_THROW_ON_ERROR) : array_replace($poll, [
            'runtime_state' => 'current', 'runtime_version' => '0.2.0', 'runtime_sessions' => 1,
            'runtime_current_sessions' => 1, 'runtime_unmanaged_sessions' => 0,
            'runtime_supervisor_version' => '0.3.0', 'runtime_supervisor_versions' => '0.3.0',
            'runtime_supervisor_sessions' => 2, 'runtime_supervisor_current_sessions' => 2,
            'bootstrap_expected_version' => '0.9.0', 'bootstrap_delivery_phase' => 'retry_pending',
            'bootstrap_delivery_error' => 'BOOTSTRAP_REPLACE_FAILED', 'bootstrap_retry_utc' => '2026-10-07T20:00:00Z', 'bootstrap_delivery_pending' => true]);
        $check(is_array($runtimeReport) && array_key_exists('runtime_state', $runtimeReport)
            && array_key_exists('runtime_supervisor_sessions', $runtimeReport) && array_key_exists('bootstrap_delivery_pending', $runtimeReport), 'Client wire contains all optional telemetry groups');
        [$status] = $call('Poll', 'POST', $runtimeReport, $token, $installation);
        $runtimeMachine = $DB->tables[GLPICHAT_MANAGEMENT_MACHINES][0];
        $runtimeView = glpichat_management_runtime_view($runtimeMachine);
        $deliveryView = glpichat_management_bootstrap_view($runtimeMachine);
        $check($status === 200 && $runtimeView['state'] === $runtimeReport['runtime_state']
            && $runtimeView['sessions'] === $runtimeReport['runtime_sessions'], 'Actual controller persists client Widget telemetry for fleet rendering');
        $check($runtimeView['supervisor_reported'] && $runtimeView['supervisor_sessions'] === $runtimeReport['runtime_supervisor_sessions']
            && $runtimeView['supervisor_current_sessions'] === $runtimeReport['runtime_supervisor_current_sessions'], 'Actual controller preserves independent standby supervisor counts');
        $check($deliveryView['reported'] && $deliveryView['pending'] === $runtimeReport['bootstrap_delivery_pending']
            && $deliveryView['expected_version'] === $runtimeReport['bootstrap_expected_version']
            && $deliveryView['phase'] === $runtimeReport['bootstrap_delivery_phase'] && $deliveryView['error'] === $runtimeReport['bootstrap_delivery_error']
            && $deliveryView['retry_utc'] === $runtimeReport['bootstrap_retry_utc'], 'Actual client-to-controller storage preserves actionable migration state');
        // Runtime reports are advisory and cannot create or complete an assignment.
        $check($DB->tables[GLPICHAT_MANAGEMENT_ASSIGNMENTS] === [], 'Fresh runtime health never fabricates update completion');
        [$status] = $call('Poll', 'POST', $poll, $token, $installation);
        $legacyMachine = $DB->tables[GLPICHAT_MANAGEMENT_MACHINES][0];
        $check($status === 200 && glpichat_management_runtime_view($legacyMachine)['state'] === 'unknown'
            && !glpichat_management_bootstrap_view($legacyMachine)['reported'], 'Older client poll keeps command loop alive without refreshing prior runtime confirmation');
        [$status, $body] = $call('Poll', 'POST', $poll, null, $installation, ['HTTP_X_GLPICHAT_AUTHORIZATION' => 'Bearer ' . $token]);
        $check($status === 200 && $body['assignment'] === null, 'Dedicated header authenticates when upstream omits Authorization');
        [$status, $body] = $call('Poll', 'POST', $poll, $token, $installation, ['HTTP_X_GLPICHAT_AUTHORIZATION' => 'Bearer ' . str_repeat('c', 64)]);
        $check($status === 401 && $body['error']['code'] === 'invalid_credential', 'Conflicting transport credentials fail before machine access');
        [$status, $body] = $call('AuthorizeUser', 'POST', new \stdClass(), $token, $installation);
        $check($status === 503 && $body['error']['code'] === 'desktop_disabled', 'Automatic enrollment honors disabled chat even with valid machine authentication');
        [$status] = $call('Register', 'GET', $registration, $token, $installation, ['HTTP_X_HTTP_METHOD_OVERRIDE' => 'POST']);
        $check($status === 404 && count($DB->tables[GLPICHAT_MANAGEMENT_MACHINES]) === 1, 'Method override cannot turn real GET into Register mutation');

        $pe = 'MZ' . str_repeat("\0", 58) . pack('V', 64) . "PE\0\0" . str_repeat("\0", 140);
        $files = []; $zip = new \ZipArchive(); $zipPath = $temporary . '/release.zip'; $zip->open($zipPath, \ZipArchive::CREATE);
        foreach (['agent' => 'GLPIChat.Agent.exe', 'widget' => 'GLPIChat.Widget.exe'] as $role => $name) {
            $bytes = $pe . $role; $zip->addFromString($name, $bytes); $files[] = ['role' => $role, 'filename' => $name, 'size' => strlen($bytes), 'sha256' => hash('sha256', $bytes)];
        }
        $zip->addFromString('release.json', json_encode(['schema' => 1, 'product' => 'glpichat-desktop', 'version' => '0.3.0', 'files' => $files])); $zip->close();
        $release = glpichat_management_import($zipPath, 1); $assignment = glpichat_management_assign(1, $release['id'], 'update', 1);
        [$status] = $call('Artifact/' . $release['id'] . '/GLPIChat.Widget.exe', 'GET', null, $token, $installation);
        $check($status === 404, 'Artifact unavailable before machine reports started');
        [$status, $body] = $call('Poll', 'POST', array_replace($poll, ['assignment_id' => $assignment, 'result' => 'started']), $token, $installation);
        $check($status === 200 && $body['assignment']['id'] === $assignment && is_string($body['assignment']['manifest_json']), 'Started poll returns exact authorized signed manifest');
        [$status, $body, $download] = $call('Artifact/' . $release['id'] . '/GLPIChat.Widget.exe', 'GET', null, $token, $installation);
        $check($status === 200 && $download instanceof \Symfony\Component\HttpFoundation\BinaryFileResponse && file_get_contents($download->getFile()->getPathname()) === $pe . 'widget', 'Actual BinaryFileResponse targets exact authenticated artifact bytes');
        $check($download->headers->get('Content-Type') === 'application/octet-stream' && str_contains($download->headers->get('Cache-Control'), 'no-store'), 'Artifact response retains binary and private cache headers');
        [$status] = $call('Artifact/' . $release['id'] . '/../GLPIChat.Widget.exe', 'GET', null, $token, $installation); $check($status === 404, 'Artifact route refuses path traversal');
        [$status] = $call('Artifact/999/GLPIChat.Widget.exe', 'GET', null, $token, $installation); $check($status === 404, 'Bearer cannot download an unassigned release');
        [$status, $body] = $call('Poll', 'POST', array_replace($poll, ['assignment_id' => $assignment, 'result' => 'committed', 'current_version' => '0.3.0', 'current_sequence' => $release['sequence']]), $token, $installation);
        $check($status === 200 && $body['assignment'] === null && $DB->tables[GLPICHAT_MANAGEMENT_ASSIGNMENTS][0]['status'] === 'completed', 'Only matching healthy version/sequence acknowledgment completes operation');
        [$status] = $call('Artifact/' . $release['id'] . '/GLPIChat.Widget.exe', 'GET', null, $token, $installation); $check($status === 404, 'Completed assignment no longer grants artifact access');
        $beforeFailure = $DB->tables;
        $DB->failUpdate = GLPICHAT_MANAGEMENT_MACHINES;
        [$status, $body, $response] = $call('Poll', 'POST', $poll, $token, $installation);
        $check($status === 503 && $body['error']['code'] === 'temporarily_unavailable' && $response->headers->get('Retry-After') === '15', 'Storage exception becomes a bounded retryable controller error');
        $check($DB->tables === $beforeFailure && !str_contains($response->getContent(), $token), 'Failed poll rolls back machine state and response omits machine credential');
        glpichat_management_revoke('machine', 1);
        [$status] = $call('Poll', 'POST', $poll, $token, $installation); $check($status === 401, 'Revoked machine rejected by actual controller authentication');
        Config::$values['desktop_schema_version'] = '2'; [$status, $body, $response] = $call('Register', 'POST', $registration);
        $check($status === 503 && $body['error']['code'] === 'schema_unavailable' && $response->headers->get('Retry-After') === '15', 'Schema3 remains required independently of chat enable flag');
        $check(!$DB->snapshots, 'All API transaction boundaries close');
        echo "PASS management controller: $checks assertions; actual controller/services/Symfony/ZIP/OpenSSL/filesystem; DB/config/container fixtures, no live GLPI or concurrent SQL qualification.\n";
    } finally { $cleanup($temporary); }
}
