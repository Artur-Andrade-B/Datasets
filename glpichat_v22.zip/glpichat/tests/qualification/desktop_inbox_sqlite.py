#!/usr/bin/env python3
"""Execute production inbox/history/read SQL against a standalone SQLite fixture.

Usage: desktop_inbox_sqlite.py PHP PLUGIN_ROOT [--output JSON]
No production SQL filters, joins, bounds or ordering are emulated in Python.
Only MySQL BINARY/FOR UPDATE/upsert syntax is adapted; native MySQL collation,
locking, GLPI authentication and HTTP remain separate qualification gates.
"""
import argparse
import hashlib
import json
import re
import sqlite3
import subprocess
import tempfile
from pathlib import Path

HARNESS = r'''<?php
declare(strict_types=1);
require $argv[1] . '/src/desktop/conversations.php';
require $argv[1] . '/src/db/readstate_db.php';
function bridge(string $sql, bool $write = false): mixed {
    echo json_encode(['sql' => $sql, 'write' => $write], JSON_THROW_ON_ERROR) . "\n"; flush();
    $line = fgets(STDIN);
    if ($line === false) { throw new RuntimeException('SQL bridge closed.'); }
    return json_decode($line, true, 512, JSON_THROW_ON_ERROR);
}
function glpichat_desktop_fail(string $code, string $message, int $status): never { throw new RuntimeException($code); }
function glpichat_desktop_db_rows(string $sql): array { return bridge($sql); }
function glpichat_desktop_quote(string $value): string { return "'" . str_replace("'", "''", $value) . "'"; }
function glpichat_desktop_now(): string { return '2026-10-14 10:00:00'; }
function glpichat_desktop_validate_actor(array $actor, bool $lock): array { return $actor; }
function glpichat_desktop_transaction(callable $operation): mixed {
    bridge('BEGIN', true);
    try { $result = $operation(); bridge('COMMIT', true); return $result; }
    catch (Throwable $error) { bridge('ROLLBACK', true); throw $error; }
}
function glpichat_browser_delivery_ready(): bool { return true; }
$DB = new class { public function doQuery(string $sql): bool { return bridge($sql, true); } };
try {
    $input = json_decode(fgets(STDIN), true, 512, JSON_THROW_ON_ERROR);
    $actor = ['user_id' => $input['user'] ?? 10, 'entity_id' => $input['entity'] ?? 2,
        'device_id' => $input['device'] ?? 1, 'can_read' => $input['can_read'] ?? true, 'can_create' => true];
    $result = match ($input['mode']) {
        'list' => glpichat_desktop_conversations($actor, $input['before'] ?? 0, 30),
        'inbox' => glpichat_desktop_inbox($actor, $input['before'] ?? 0, $input['limit'] ?? 30, $input['summary'] ?? true),
        'history' => glpichat_desktop_history($actor, $input['ticket'], $input['before'] ?? 0, $input['limit'] ?? 50),
        'window' => glpichat_desktop_history_window($actor, $input['ticket'], $input['after'] ?? 0, $input['unread'] ?? false, $input['limit'] ?? 50),
        'read' => glpichat_desktop_read($actor, $input['ticket'], $input['ids']),
        'web_read' => glpichat_bridge_web_read($input['room'], $actor['user_id'], $input['last']),
        'web_unread' => glpichat_desktop_db_rows('SELECT m.id FROM glpi_plugin_glpichat_messages m WHERE m.rooms_id=1 AND '
            . glpichat_current_message_predicate('m') . ' AND ' . glpichat_public_read_bridge_predicate($actor['user_id'], 'm')),
    };
    echo json_encode(['result' => $result], JSON_THROW_ON_ERROR) . "\n";
} catch (Throwable $error) { echo json_encode(['error' => $error->getMessage()], JSON_THROW_ON_ERROR) . "\n"; }
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('php')
    parser.add_argument('plugin_root', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    db = sqlite3.connect(':memory:', isolation_level=None)
    db.row_factory = sqlite3.Row
    db.create_function('OCTET_LENGTH', 1, lambda value: len(value.encode()) if value is not None else None)
    db.create_function('UTC_TIMESTAMP', 0, lambda: '2026-10-14 10:00:00')
    # Explicit minimal columns are a fixture boundary, not a claim to reproduce
    # native GLPI DDL. Production queries still execute unchanged in scope/order.
    db.executescript('''
        CREATE TABLE glpi_tickets(id INTEGER PRIMARY KEY,name TEXT,status INTEGER,entities_id INTEGER,is_deleted INTEGER);
        CREATE TABLE glpi_tickets_users(id INTEGER PRIMARY KEY,tickets_id INTEGER,users_id INTEGER,type INTEGER);
        CREATE INDEX requester ON glpi_tickets_users(tickets_id,users_id,type);
        CREATE TABLE glpi_itilfollowups(id INTEGER PRIMARY KEY,itemtype TEXT,items_id INTEGER,date TEXT,users_id INTEGER,content TEXT,is_private INTEGER);
        CREATE INDEX ticket_followups ON glpi_itilfollowups(itemtype,items_id,id);
        CREATE TABLE glpi_users(id INTEGER PRIMARY KEY,name TEXT,firstname TEXT,realname TEXT);
        CREATE TABLE glpi_plugin_glpichat_rooms(id INTEGER PRIMARY KEY,tickets_id INTEGER,room_type TEXT);
        CREATE TABLE glpi_plugin_glpichat_messages(id INTEGER PRIMARY KEY,rooms_id INTEGER,tickets_id INTEGER,participant_type TEXT,users_id INTEGER,message_type TEXT,content TEXT,documents_id INTEGER,itilfollowups_id INTEGER);
        CREATE INDEX native_source ON glpi_plugin_glpichat_messages(itilfollowups_id);
        CREATE TABLE glpi_plugin_glpichat_desktopreads(id INTEGER PRIMARY KEY,users_id INTEGER,itilfollowups_id INTEGER,created_at TEXT,UNIQUE(users_id,itilfollowups_id));
        CREATE TABLE glpi_plugin_glpichat_desktopsends(id INTEGER PRIMARY KEY,users_id INTEGER,client_message_id TEXT,tickets_id INTEGER,itilfollowups_id INTEGER);
        CREATE INDEX send_followup ON glpi_plugin_glpichat_desktopsends(tickets_id,itilfollowups_id);
        CREATE TABLE glpi_documents(id INTEGER PRIMARY KEY,name TEXT,filename TEXT,filepath TEXT,mime TEXT,sha1sum TEXT,entities_id INTEGER,is_deleted INTEGER,is_blacklisted INTEGER);
        CREATE TABLE glpi_documents_items(id INTEGER PRIMARY KEY,documents_id INTEGER,itemtype TEXT,items_id INTEGER);
    ''')
    evidence, checks = [], []

    def check(condition, description):
        checks.append({'description': description, 'pass': bool(condition)})
        if not condition:
            raise AssertionError(description)

    def followup(message, ticket, author=11, private=0, itemtype='Ticket'):
        db.execute('INSERT INTO glpi_itilfollowups VALUES(?,?,?,?,?,?,?)',
                   (message, itemtype, ticket, '2026-10-14 09:00:00', author, 'Message ' + str(message), private))

    for ticket in range(1, 41):
        db.execute('INSERT INTO glpi_tickets VALUES(?,?,?,?,0)', (ticket, 'Ticket ' + str(ticket), (ticket % 6) + 1, 2))
        db.execute('INSERT INTO glpi_tickets_users(tickets_id,users_id,type) VALUES(?,10,1)', (ticket,))
        if ticket != 1:
            followup(ticket * 1000, ticket)
    for message in range(1, 122):
        followup(message, 1, 10 if message % 10 == 0 else 11)
    db.execute('INSERT INTO glpi_tickets_users(tickets_id,users_id,type) VALUES(1,12,1)')
    db.executemany('INSERT INTO glpi_users VALUES(?,?,?,?)', [(10, 'requester', 'A', 'User'), (11, 'technician', 'A', 'Tech'), (12, 'other', 'Other', 'User')])
    for ticket, entity, deleted, requester, role in [(100, 2, 0, 11, 1), (101, 3, 0, 10, 1), (102, 2, 1, 10, 1), (103, 2, 0, 10, 2)]:
        db.execute('INSERT INTO glpi_tickets VALUES(?,?,?,?,?)', (ticket, 'Forbidden', 2, entity, deleted))
        db.execute('INSERT INTO glpi_tickets_users(tickets_id,users_id,type) VALUES(?,?,?)', (ticket, requester, role))
        followup(ticket * 1000, ticket)
    db.executemany('INSERT INTO glpi_plugin_glpichat_rooms VALUES(?,?,?)', [(1, 1, 'public'), (2, 1, 'internal'), (3, 100, 'public')])
    for message in range(200, 207):
        followup(message, 1, private=int(message == 200), itemtype='Problem' if message == 205 else 'Ticket')
    db.executemany('INSERT INTO glpi_plugin_glpichat_messages VALUES(?,?,?,?,?,?,?,?,?)', [
        (201, 2, 1, 'user', 11, 'message', '', 0, 201),
        (202, 1, 1, 'guest', 11, 'message', '', 0, 202),
        (203, 3, 100, 'user', 11, 'message', '', 0, 203),
        (204, 999, 1, 'user', 11, 'message', '', 0, 204),
        (206, 1, 1, 'user', 11, 'message', '', 9, 206),
        (500, 1, 1, 'user', 11, 'message', '', 0, 24),
        (501, 1, 1, 'user', 11, 'message', '', 0, 200),
    ])
    db.executemany('INSERT INTO glpi_plugin_glpichat_desktopreads(users_id,itilfollowups_id) VALUES(10,?)', [(i,) for i in range(1, 21)])
    db.execute('INSERT INTO glpi_plugin_glpichat_desktopreads(users_id,itilfollowups_id) VALUES(12,21)')
    expected_old = {i for i in range(21, 122) if i % 10 != 0}

    with tempfile.TemporaryDirectory(prefix='glpichat-inbox-') as temporary:
        harness = Path(temporary) / 'bridge.php'
        harness.write_text(HARNESS)

        def request(case, expected_error=None):
            process = subprocess.Popen([args.php, str(harness), str(args.plugin_root.resolve())],
                                       stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            queries = []
            try:
                process.stdin.write(json.dumps(case) + '\n')
                process.stdin.flush()
                while True:
                    line = process.stdout.readline()
                    if not line:
                        raise RuntimeError('PHP bridge stopped: ' + process.stderr.read())
                    event = json.loads(line)
                    if 'result' in event or 'error' in event:
                        process.stdin.close()
                        process.wait(timeout=10)
                        if process.returncode:
                            raise RuntimeError(process.stderr.read())
                        evidence.append({'case': case, 'queries': queries})
                        if expected_error:
                            check(event.get('error') == expected_error, 'Reject ' + str(case) + ' as ' + expected_error)
                        elif 'error' in event:
                            raise RuntimeError(event['error'])
                        return event.get('result'), queries
                    original = event['sql']
                    sql = re.sub(r'\bBINARY ', '', original)
                    sql = re.sub(r' FOR UPDATE$', '', sql)
                    sql = sql.replace(' ON DUPLICATE KEY UPDATE users_id = VALUES(users_id)', ' ON CONFLICT(users_id,itilfollowups_id) DO NOTHING')
                    sql = sql.replace(' ON DUPLICATE KEY UPDATE users_id=VALUES(users_id)', ' ON CONFLICT(users_id,itilfollowups_id) DO NOTHING')
                    cursor = db.execute(sql)
                    rows = True if event['write'] else [dict(row) for row in cursor]
                    queries.append({'production_sql': original, 'sqlite_sql': sql, 'rows': None if event['write'] else len(rows)})
                    process.stdin.write(json.dumps(rows) + '\n')
                    process.stdin.flush()
            finally:
                if process.poll() is None:
                    process.kill()
                    process.wait()
                for pipe in (process.stdin, process.stdout, process.stderr):
                    if not pipe.closed:
                        pipe.close()

        listing, unused = request({'mode': 'list'})
        check(1 not in [row['ticket_id'] for row in listing['conversations']], 'Old unread ticket lies beyond the ordinary thirty-ticket list')
        first, queries = request({'mode': 'inbox'})
        total = len(expected_old) + 39
        check(first['unread_total'] == total and first['unread_conversations'] == 40, 'Complete unread totals span all authorized statuses and exclude private/guest/internal/foreign/deleted/observer sources')
        check(len(queries) == 2 and queries[0]['rows'] == 1 and queries[1]['rows'] == 31, 'Inbox returns one aggregate and at most limit+1 metadata rows without bodies')
        second, unused = request({'mode': 'inbox', 'before': first['next_before']})
        check(second['unread_total'] == total and len(second['conversations']) == 10 and not second['has_more'], 'Keyset second page retains complete totals and reaches oldest unread ticket')
        check([r['ticket_id'] for r in first['conversations'] + second['conversations']] == list(range(40, 0, -1)), 'Unread conversation keyset has no duplicates or gaps')
        light, queries = request({'mode': 'inbox', 'before': first['next_before'], 'summary': False})
        check(not light['summary_included'] and 'unread_total' not in light and len(queries) == 1 and light['conversations'] == second['conversations'], 'Continuation can omit repeated global aggregation while preserving the exact metadata page')
        old = second['conversations'][-1]
        check(old['unread_count'] == len(expected_old) and old['first_unread_id'] == 21 and old['last_unread_id'] == 121, 'First/latest unread identifiers exclude own messages and respect existing shared-user receipts')
        check(any(row['status'] == 6 and not row['can_send'] for row in first['conversations']), 'Closed tickets stay in unread inbox with read-only sending policy')
        window, queries = request({'mode': 'window', 'ticket': 1, 'unread': True})
        check([m['id'] for m in window['messages']] == list(range(21, 71)) and window['has_newer'] and window['next_after'] == 70, 'First unread older than the latest fifty opens a bounded ascending window')
        check(window['has_more'] and window['next_before'] == 21 and all(m['is_unread'] == (m['id'] in expected_old) for m in window['messages']), 'History reports exact incoming unread flags and older-context navigation')
        check(all(q['rows'] <= 51 for q in queries if q['rows'] is not None), 'History navigation transfers only bounded source and attachment windows')
        rest, unused = request({'mode': 'window', 'ticket': 1, 'after': window['next_after']})
        final, unused = request({'mode': 'window', 'ticket': 1, 'after': rest['next_after']})
        check([m['id'] for m in rest['messages'] + final['messages']] == list(range(71, 122)) and not final['has_newer'], 'Forward continuation reaches latest without skipping the unread backlog')
        older, unused = request({'mode': 'history', 'ticket': 1, 'before': 21})
        check([m['id'] for m in older['messages']] == list(range(1, 21)) and older['next_after'] == 20 and older['has_newer'], 'Backward context retains a forward cursor to the unread window')
        capped, unused = request({'mode': 'window', 'ticket': 1, 'unread': True, 'limit': 9999})
        check(len(capped['messages']) == 50, 'Oversized history request remains capped at fifty')
        request({'mode': 'read', 'ticket': 1, 'ids': [21, 23]})
        peer, unused = request({'mode': 'inbox', 'before': 2, 'device': 2})
        check(peer['conversations'][0]['unread_count'] == len(expected_old) - 2 and peer['conversations'][0]['first_unread_id'] == 22, 'Exact reads on one PC update another PC for the same GLPI user without acknowledging gaps')
        other, unused = request({'mode': 'inbox', 'user': 12})
        check(other['unread_total'] == 120, 'Different GLPI user retains independent receipts and treats the other user messages as incoming')
        before_bad = db.execute('SELECT COUNT(*) FROM glpi_plugin_glpichat_desktopreads').fetchone()[0]
        request({'mode': 'read', 'ticket': 1, 'ids': [22, 200]}, 'message_unavailable')
        check(db.execute('SELECT COUNT(*) FROM glpi_plugin_glpichat_desktopreads').fetchone()[0] == before_bad, 'Mixed visible/private read set writes nothing')
        web, unused = request({'mode': 'web_unread'})
        check(500 in [r['id'] for r in web], 'Web bridge initially sees the public unread mirror')
        request({'mode': 'read', 'ticket': 1, 'ids': [24]})
        web, unused = request({'mode': 'web_unread'})
        check(500 not in [r['id'] for r in web], 'Desktop exact read suppresses the matching browser unread without touching the browser cursor')
        db.execute('DELETE FROM glpi_plugin_glpichat_desktopreads WHERE users_id=10 AND itilfollowups_id=24')
        request({'mode': 'web_read', 'room': 1, 'last': 501})
        read_ids = {r[0] for r in db.execute('SELECT itilfollowups_id FROM glpi_plugin_glpichat_desktopreads WHERE users_id=10')}
        check(24 in read_ids and 200 not in read_ids and 202 not in read_ids, 'Browser read bridge acknowledges current native public user source only')
        request({'mode': 'window', 'ticket': 101, 'unread': True}, 'conversation_unavailable')
        request({'mode': 'window', 'ticket': 100, 'unread': True}, 'conversation_unavailable')
        unused, denied_queries = request({'mode': 'inbox', 'can_read': False}, 'conversation_unavailable')
        check(denied_queries == [], 'Denied inbox actor performs no metadata query')
        db.execute('DELETE FROM glpi_tickets_users WHERE tickets_id=1 AND users_id=10')
        denied, unused = request({'mode': 'inbox', 'before': 2})
        check(denied['conversations'] == [], 'Requester removal immediately hides unread ticket metadata')
        request({'mode': 'window', 'ticket': 1, 'unread': True}, 'conversation_unavailable')

    result = {'engine': 'Python sqlite3 ' + sqlite3.sqlite_version, 'checks': checks, 'passed': len(checks),
              'source_sha256': hashlib.sha256((args.plugin_root / 'src/desktop/conversations.php').read_bytes()).hexdigest(),
              'cases': evidence, 'limits': ['Minimal explicit column schema; native GLPI DDL/types/collation and MySQL planner/locking not reproduced.',
                  'Production SQL executed with only BINARY/FOR UPDATE removal and equivalent unique receipt upsert syntax adaptation.',
                  'Actor validation and transaction wrapper are fixtures; real read write, visibility rules and web read bridge execute. No HTTP/AD/live GLPI execution.']}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print('PASS desktop inbox SQL: ' + str(len(checks)) + ' checks; SQLite adapter; native database/HTTP qualification remains separate.')


if __name__ == '__main__':
    main()
