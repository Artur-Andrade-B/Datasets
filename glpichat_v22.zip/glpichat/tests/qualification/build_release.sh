#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
export TZ=UTC

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
plugin_root="$(cd "$script_dir/../.." && pwd)"
output_arg="${1:-$(dirname "$plugin_root")/glpichat-1.9.0-desktop13.zip}"
output_dir="$(dirname "$output_arg")"
output_name="$(basename "$output_arg")"

if [[ ! -d "$output_dir" ]]; then
    printf '[FAIL] Output directory does not exist: %s\n' "$output_dir" >&2
    exit 1
fi
output_path="$(cd "$output_dir" && pwd)/$output_name"
if [[ "$output_path" == "$plugin_root" || "$output_path" == "$plugin_root/"* ]]; then
    printf '[FAIL] Output archive must be outside the plugin source tree.\n' >&2
    exit 1
fi

# Packaging is also an artifact freshness gate. Dependencies are developer-only
# and are removed from the package below; a server installation needs no npm.
(
    cd "$plugin_root"
    npm run build
    npm test -- tests/unit/js/release_bundle.test.js
)

staging_dir="$(mktemp -d)"
cleanup() {
    rm -rf "$staging_dir"
}
trap cleanup EXIT

# Explicit runtime allowlist. Developer tests, npm manifests, workflows and
# historical reports stay in the complete source archive, outside the web root.
mkdir -p "$staging_dir/glpichat/docs"
for entry in src public front bin setup.php hook.php plugin.xml composer.json release-manifest.json LICENSE README.md; do
    cp -a "$plugin_root/$entry" "$staging_dir/glpichat/$entry"
done
cp -a "$plugin_root/docs/INSTALLATION_PT-BR.md" "$staging_dir/glpichat/docs/INSTALLATION_PT-BR.md"

find "$staging_dir/glpichat" -type d -exec chmod 0755 {} +
find "$staging_dir/glpichat" -type f -exec chmod 0644 {} +
find "$staging_dir/glpichat" -type f -name '*.sh' -exec chmod 0755 {} +

# ZIP stores timestamps at two-second resolution. A fixed even UTC timestamp,
# sorted entries and stripped extra fields make repeated builds byte-identical.
find "$staging_dir/glpichat" -exec touch -h -d '@1791936000' {} +

archive_tmp="$staging_dir/glpichat-1.9.0-desktop13.zip"
(
    cd "$staging_dir"
    find glpichat -print | LC_ALL=C sort | zip -X -q -9 "$archive_tmp" -@
)

entry_count="$(unzip -Z1 "$archive_tmp" | wc -l | tr -d ' ')"
if [[ "$entry_count" -le 1 ]]; then
    printf '[FAIL] Release archive is unexpectedly empty.\n' >&2
    exit 1
fi
if unzip -Z1 "$archive_tmp" | grep -Ev '^glpichat(/|$)' >/dev/null; then
    printf '[FAIL] Release archive contains an entry outside the glpichat/ root.\n' >&2
    exit 1
fi

mv -f "$archive_tmp" "$output_path"
sha256sum "$output_path"
