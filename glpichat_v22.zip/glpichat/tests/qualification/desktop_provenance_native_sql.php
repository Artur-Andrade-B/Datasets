<?php

declare(strict_types=1);

/** Execute the schema8-to9 provenance migration on a disposable native database.
 * Usage: GLPICHAT_TEST_DB_HOST=... GLPICHAT_TEST_DB_PORT=... php desktop_provenance_native_sql.php
 * The randomly named database is created/dropped by this test. No GLPI session
 * or production database is opened. Credentials follow other native fixtures.
 */
if (PHP_SAPI !== 'cli' || !getenv('GLPICHAT_TEST_DB_HOST')) {
    throw new RuntimeException('Disposable SQL endpoint required.');
}
require dirname(__DIR__, 2) . '/src/desktop/schema.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$connection = new mysqli(getenv('GLPICHAT_TEST_DB_HOST'), getenv('GLPICHAT_TEST_DB_USER') ?: 'root',
    getenv('GLPICHAT_TEST_DB_PASSWORD') ?: '', '', (int) getenv('GLPICHAT_TEST_DB_PORT'));
$database = 'glpichat_provenance_' . bin2hex(random_bytes(6));
$connection->query('CREATE DATABASE `' . $database . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
$connection->select_db($database);
$DB = new class($connection) {
    public array $queries = [];
    public function __construct(public mysqli $connection) {}
    public function tableExists(string $table): bool {
        return $this->connection->query("SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='"
            . $this->connection->real_escape_string($table) . "'")->num_rows > 0;
    }
    public function doQuery(string $sql): mysqli_result|bool { $this->queries[] = $sql; return $this->connection->query($sql); }
    public function fetchAssoc(mysqli_result $rows): array|false|null { return $rows->fetch_assoc(); }
};
$config = ['desktop_enabled' => '1', 'desktop_idempotency_key' => str_repeat('a', 64)];
$read = static function (string $key) use (&$config): mixed { return $config[$key] ?? null; };
$write = static function (array $values) use (&$config): void { $config = array_replace($config, $values); };
$checks = 0;
$check = static function (bool $ok, string $description) use (&$checks): void { ++$checks; if (!$ok) { throw new RuntimeException($description); } };
try {
    $connection->query('CREATE TABLE glpi_plugin_glpichat_messages(id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,itilfollowups_id INT UNSIGNED NOT NULL) ENGINE=InnoDB');
    glpichat_desktop_schema_install(config_value: $read, config_write: $write);
    $check($config['desktop_schema_version'] === '9', 'Fresh native installation completes schema9.');
    // Recreate missing schema8 structures, with realistic existing rows.
    $connection->query('ALTER TABLE glpi_plugin_glpichat_desktopgrants DROP INDEX desktop_grant_machine_sid_latest');
    $connection->query('ALTER TABLE glpi_plugin_glpichat_desktopgrants DROP INDEX desktop_grant_legacy_identity_latest');
    $connection->query('ALTER TABLE glpi_plugin_glpichat_desktopgrants DROP COLUMN automatic_machines_id');
    $connection->query('ALTER TABLE glpi_plugin_glpichat_notificationjobs DROP INDEX notification_completed');
    $config['desktop_schema_version'] = '8';
    $insert = static function (string $table, array $overrides) use ($connection): void {
        $values = [];
        foreach (glpichat_desktop_schema_definitions()[$table]['columns'] as $name => $column) {
            if ($name === 'id' || $name === 'automatic_machines_id') { continue; }
            $values[$name] = $column['nullable'] ? null : (str_contains($column['type'], 'int') ? 0
                : ($column['type'] === 'datetime' ? '2026-10-14 10:00:00' : ''));
        }
        $values = array_replace($values, $overrides);
        $quoted = array_map(static fn(mixed $value): string => $value === null ? 'NULL' : "'" . $connection->real_escape_string((string) $value) . "'", $values);
        $connection->query('INSERT INTO `' . $table . '` (`' . implode('`,`', array_keys($values)) . '`) VALUES (' . implode(',', $quoted) . ')');
    };
    $grant = static fn(int $n): string => str_pad((string) $n, 32, '0', STR_PAD_LEFT);
    foreach ([1, 2, 3, 4] as $id) {
        $insert('glpi_plugin_glpichat_desktopgrants', ['grant_id' => $grant($id), 'users_id' => 10, 'auths_id' => 5,
            'windows_sid' => 'S-1-5-21-1-2-3-1000', 'computer_name' => 'SAME-PC']);
    }
    $insert('glpi_plugin_glpichat_desktopautobindings', ['machines_id' => 11, 'current_grant_id' => $grant(1),
        'users_id' => 10, 'auths_id' => 5, 'windows_sid' => 'S-1-5-21-1-2-3-1000']);
    // Grant2 shares every hostname/SID attribute but is unlinked legacy data.
    // Grant3 is superseded and likewise has no current binding. Grant4 has a
    // malformed user identity despite the pointer and must remain unproven.
    $insert('glpi_plugin_glpichat_desktopautobindings', ['machines_id' => 44, 'current_grant_id' => $grant(4),
        'users_id' => 99, 'auths_id' => 5, 'windows_sid' => 'S-1-5-21-1-2-3-1000']);
    glpichat_desktop_schema_install(config_value: $read, config_write: $write);
    $owners = [];
    foreach ($connection->query('SELECT grant_id,automatic_machines_id FROM glpi_plugin_glpichat_desktopgrants') as $row) {
        $owners[$row['grant_id']] = (int) $row['automatic_machines_id'];
    }
    $check($owners[$grant(1)] === 11, 'Only explicit matching current binding backfills its machine.');
    $check($owners[$grant(2)] === 0 && $owners[$grant(3)] === 0, 'Same-host/SID legacy and superseded grants remain unproven.');
    $check($owners[$grant(4)] === 0, 'Conflicting binding identity never creates provenance.');
    $check($config['desktop_schema_version'] === '9' && $config['desktop_idempotency_key'] === str_repeat('a', 64), 'Migration commits schema9 and preserves existing key.');
    $check(glpichat_desktop_schema_health(config_value: $read)['healthy'], 'Native metadata validates new column and notification retention index.');
    // Simulate interruption after successful backfill but before marker commit.
    $connection->query('UPDATE glpi_plugin_glpichat_desktopgrants SET automatic_machines_id=22 WHERE grant_id=\'' . $grant(1) . "'");
    $config['desktop_schema_version'] = '8';
    glpichat_desktop_schema_install(config_value: $read, config_write: $write);
    $owner = $connection->query('SELECT automatic_machines_id FROM glpi_plugin_glpichat_desktopgrants WHERE grant_id=\'' . $grant(1) . "'")->fetch_assoc();
    $check((int) $owner['automatic_machines_id'] === 22, 'Retry never overwrites an existing nonzero provenance.');
    $DB->queries = [];
    glpichat_desktop_schema_install(config_value: $read, config_write: $write);
    $check(count(array_filter($DB->queries, static fn(string $sql): bool => !str_starts_with($sql, 'SELECT '))) === 0, 'Completed native migration repeats no DDL or DML.');
    echo "PASS desktop provenance native SQL: $checks checks; actual schema installer and native metadata/data; no GLPI session.\n";
} finally {
    $connection->query('DROP DATABASE `' . $database . '`');
    $connection->close();
}
