import { describe, expect, it } from 'vitest';
import { buildPollPayload, createPollForm, POLL_FORM_INPUT_BUDGET } from '../../../src/js/modules/poll-payload.js';

const room = (ticket, type, count = 200) => ({
  tickets_id: ticket, room_type: type, messages_loaded: true,
  last_message_id: count, last_event_id: '42', isTyping: type === 'public',
  messages: Array.from({ length: count }, (_, index) => ({ id: index + 1 })),
});
const payloadFor = (rooms, tickets = [1, 2, 3]) => buildPollPayload(rooms, tickets, String);

describe('shared multipart poll budget', () => {
  it('keeps all six loaded rooms within PHP default max_input_vars, including CSRF and cursors', () => {
    const rooms = [1, 2, 3].flatMap((ticket) => [room(ticket, 'public'), room(ticket, 'internal')]);
    const payload = payloadFor(rooms);
    const form = createPollForm(payload, 'csrf-token');
    expect([...form.entries()].length).toBeLessThanOrEqual(POLL_FORM_INPUT_BUDGET);
    expect([...form.entries()].length).toBeLessThan(1000);
    expect(form.get('_glpi_csrf_token')).toBe('csrf-token');
    expect(payload).toHaveLength(6);
    for (let index = 0; index < 6; index++) {
      expect(form.get(`channels[${index}][tickets_id]`)).toBe(String(rooms[index].tickets_id));
      expect(form.get(`channels[${index}][after_id]`)).toBe('200');
      expect(form.get(`channels[${index}][after_event_id]`)).toBe('42');
      expect(payload[index].visible_message_ids.length).toBeGreaterThan(0);
    }
  });
  it('eventually refreshes every retained message in every room, without duplicates in a poll', () => {
    const rooms = [1, 2, 3].flatMap((ticket) => [room(ticket, 'public', 1000), room(ticket, 'internal', 1000)]);
    const seen = rooms.map(() => new Set());
    for (let round = 0; round < 8; round++) {
      const payload = payloadFor(rooms);
      expect([...createPollForm(payload, 'csrf').entries()].length).toBeLessThanOrEqual(POLL_FORM_INPUT_BUDGET);
      payload.forEach((item, index) => {
        expect(new Set(item.visible_message_ids).size).toBe(item.visible_message_ids.length);
        item.visible_message_ids.forEach((id) => seen[index].add(id));
      });
    }
    seen.forEach((ids) => expect(ids.size).toBe(1000));
  });
  it('preserves the 200-row server limit and ignores optimistic, unopened and unloaded rooms', () => {
    const active = room(1, 'public', 400);
    active.messages.push({ id: 501, is_optimistic: true }, { id: -1 });
    const unloaded = { ...room(1, 'internal'), messages_loaded: false };
    const payload = payloadFor([active, unloaded, room(99, 'public')]);
    expect(payload).toHaveLength(1);
    expect(payload[0].visible_message_ids).toHaveLength(200);
    expect(payloadFor([active])[0].visible_message_ids).toEqual(Array.from({ length: 200 }, (_, i) => i + 201));
    expect(payloadFor([room(1, 'public', 0)])[0].visible_message_ids).toEqual([]);
  });
});
