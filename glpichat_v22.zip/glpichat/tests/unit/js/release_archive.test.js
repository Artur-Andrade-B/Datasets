// @vitest-environment node

import { execFileSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { createHash } from "node:crypto";
import { describe, expect, it } from "vitest";

const root = resolve(import.meta.dirname, "../../..");
const builder = resolve(root, "tests/qualification/build_release.sh");

const sha256 = (path) =>
  createHash("sha256").update(readFileSync(path)).digest("hex");

describe("desktop13 minimal runtime archive", () => {
  it("builds byte-identically with one safe glpichat root", () => {
    const buildDir = mkdtempSync(join(tmpdir(), "glpichat-desktop13-"));
    const first = join(buildDir, "first.zip");
    const second = join(buildDir, "second.zip");

    try {
      execFileSync("bash", [builder, first], {
        cwd: root,
        env: { ...process.env, LC_ALL: "C.UTF-8", TZ: "Pacific/Honolulu" },
        stdio: "pipe",
      });
      execFileSync("bash", [builder, second], {
        cwd: root,
        env: { ...process.env, LC_ALL: "C", TZ: "Asia/Tokyo" },
        stdio: "pipe",
      });

      expect(sha256(first)).toBe(sha256(second));
      expect(readFileSync(first).equals(readFileSync(second))).toBe(true);

      const entries = execFileSync("unzip", ["-Z1", first], {
        encoding: "utf8",
      })
        .trim()
        .split("\n");
      expect(entries.length).toBeGreaterThan(1);
      expect(entries[0]).toBe("glpichat/");
      expect(entries).toEqual([...entries].sort());
      expect(entries.every((entry) => /^glpichat(?:\/|$)/.test(entry))).toBe(true);
      expect(entries.every((entry) => !/(?:^|\/)\.\.(?:\/|$)/.test(entry))).toBe(true);

      for (const forbidden of [
        "glpichat/.git/",
        "glpichat/node_modules/",
        "glpichat/tests/logs/",
        "glpichat/tests/performance/logs/",
        "glpichat/coverage/",
        "glpichat/tests/",
        "glpichat/.github/",
        "glpichat/package.json",
        "glpichat/package-lock.json",
        "glpichat/docs/history/",
      ]) {
        expect(entries.some((entry) => entry.startsWith(forbidden))).toBe(false);
      }

      for (const required of [
        "glpichat/docs/INSTALLATION_PT-BR.md",
        "glpichat/src/DesktopRolloutCron.php",
        "glpichat/src/desktop/rollouts.php",
        "glpichat/src/guest_delivery.php",
        "glpichat/src/message_source.php",
        "glpichat/public/js/desktop-management.js",
        "glpichat/setup.php",
        "glpichat/hook.php",
        "glpichat/release-manifest.json",
        "glpichat/LICENSE",
        "glpichat/src/Controller/DesktopController.php",
        "glpichat/src/desktop/schema.php",
        "glpichat/src/desktop/auth.php",
        "glpichat/src/desktop/conversations.php",
        "glpichat/src/desktop/common.php",
        "glpichat/src/desktop/enrollment.php",
        "glpichat/src/desktop/provision.php",
        "glpichat/bin/desktop-provision.php",
        "glpichat/front/desktop.php",
      ]) {
        expect(entries).toContain(required);
      }

      const longListing = execFileSync("unzip", ["-Z", "-l", first], {
        encoding: "utf8",
      });
      const modeLines = longListing
        .split("\n")
        .filter((line) => /\s+glpichat(?:\/|$)/.test(line));
      expect(modeLines).toHaveLength(entries.length);
      for (const line of modeLines) {
        const entry = line.trim().split(/\s+/).at(-1);
        const expectedMode = entry.endsWith("/")
          ? "drwxr-xr-x"
          : entry.endsWith(".sh")
            ? "-rwxr-xr-x"
            : "-rw-r--r--";
        expect(line.trim().startsWith(expectedMode)).toBe(true);
      }
    } finally {
      rmSync(buildDir, { recursive: true, force: true });
    }
  });
});
