<?php

declare(strict_types=1);

// Actual front/desktop.php and auth/enrollment policy. Session/bootstrap/SQL are
// explicit fixtures; GLPI's real CSRF listener is qualified by its own harness.
define('READ', 1); define('CREATE', 4);
class Auth { public const LDAP = 3; public const CAS = 5; public const X509 = 6; public const EXTERNAL = 4; }
class Ticket { public const READMY = 1; public const READALL = 1024; }
class ITILFollowup { public const SEEPUBLIC = 1; public const ADDMY = 4; public const ADDALLITEM = 4096; }
class Config {
    public static function getConfigurationValues(string $context): array { return ['desktop_enabled' => '1', 'desktop_schema_version' => '8', 'desktop_idempotency_key' => str_repeat('a', 64)]; }
}
class Session {
    public static function checkLoginUser(): void {}
    public static function getLoginUserID(): int { return 10; }
    public static function getNewCSRFToken(): string { return str_repeat('a', 64); }
}
require_once dirname(__DIR__, 2) . '/fixtures/desktop_enrollment_db.php';
require_once dirname(__DIR__, 3) . '/src/desktop/common.php';
require_once dirname(__DIR__, 3) . '/src/desktop/auth.php';
$DB = new DesktopEnrollmentDB(); $count = 0;
$temporary = sys_get_temp_dir() . '/glpichat-managed-page-' . bin2hex(random_bytes(8));
mkdir($temporary . '/inc', 0700, true);
file_put_contents($temporary . '/inc/includes.php', '<?php // Explicit GLPI bootstrap fixture.');
define('GLPI_ROOT', $temporary);
$CFG_GLPI = ['root_doc' => '/glpi'];
$_SESSION = ['glpiname' => 'employee', 'glpiactiveprofile' => ['id' => 3], 'glpiactive_entity' => 1];
$_GET = [];
function page_check(bool $condition, string $message): void { ++$GLOBALS['count']; if (!$condition) { throw new RuntimeException($message); } }
function managed_page(array $post = []): string {
    global $DB, $CFG_GLPI;
    $_POST = $post; $_SERVER['REQUEST_METHOD'] = $post ? 'POST' : 'GET';
    ob_start();
    try { include dirname(__DIR__, 3) . '/front/desktop.php'; return ob_get_contents(); }
    finally { ob_end_clean(); }
}
try {
    $grant = glpichat_desktop_grant_issue(['users_id' => 10, 'profiles_id' => 3, 'entities_id' => 1,
        'windows_sid' => 'S-1-5-21-111-222-333-1001', 'computer_name' => 'office-pc']);
    $request = ['grant_id' => $grant['grant_id'], 'grant_secret' => $grant['grant_secret'],
        'device_id' => '11111111-2222-4333-8444-555555555555', 'windows_sid' => $grant['windows_sid'],
        'computer_name' => 'office-pc', 'access_token' => str_repeat('b', 64), 'refresh_secret' => str_repeat('c', 64)];
    $identity = glpichat_desktop_enroll($request);
    $before = $DB->tables;
    $html = managed_page();
    page_check(str_contains($html, 'Gerenciada pela empresa · conexão automática') && !str_contains($html, 'name="desktop_action" value="revoke"'), 'Managed connection renders read-only with no self-revoke control');
    page_check(!str_contains($html, $request['access_token']) && !str_contains($html, $request['refresh_secret']), 'Page never renders desktop credentials');
    $html = managed_page(['desktop_action' => 'revoke', 'device_id' => (string) $identity['device']['id']]);
    page_check(str_contains($html, 'Esta conexão é gerenciada pela empresa') && !str_contains($html, 'A conexão foi revogada.'), 'Forged self-revoke POST returns policy failure through actual browser page');
    page_check($DB->tables === $before && glpichat_desktop_authenticate($request['access_token'])['user_id'] === 10, 'Browser policy rejection preserves working access and enrollment state');
    $DB->tables[GLPICHAT_DESKTOP_REGISTRATIONS_TABLE] = [];
    page_check(!str_contains(managed_page(), 'name="desktop_action" value="revoke"'), 'Creation marker keeps damaged managed metadata read-only');
    $DB->tables[GLPICHAT_DESKTOP_DEVICES_TABLE][0]['request_ip_hash'] = glpichat_desktop_auth_hash('pairing-ip', '127.0.0.1');
    $html = managed_page();
    page_check(str_contains($html, 'Revogar conexão pessoal'), 'Legacy personal record remains explicitly revocable');
    $html = managed_page(['desktop_action' => 'revoke', 'device_id' => (string) $identity['device']['id']]);
    page_check(str_contains($html, 'A conexão foi revogada.') && $DB->tables[GLPICHAT_DESKTOP_DEVICES_TABLE][0]['status'] === 'revoked', 'Personal browser revocation retains its previous behavior');
    echo "PASS managed page: $count assertions; actual browser front/policy, SQL/session/core-bootstrap fixtures.\n";
} finally { unlink($temporary . '/inc/includes.php'); rmdir($temporary . '/inc'); rmdir($temporary); }
