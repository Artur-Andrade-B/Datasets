<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/notification_queue.php';

final class MaintenanceRows extends ArrayIterator {
    public function current(): mixed { return $this->valid() ? parent::current() : false; }
}
final class MaintenanceDb {
    public array $jobs = [], $receipts = ['durable' => 'untouched'];
    public int $affected = 0;
    public bool $changeAfterSelect = false;
    private function matches(array $row, array $where): bool {
        foreach ($where as $field => $value) {
            if (is_array($value) && ($value[0] ?? null) === '<') { if ($row[$field] === null || $row[$field] >= $value[1]) { return false; } }
            elseif (is_array($value) && ($value[0] ?? null) === '<=') { if ($row[$field] > $value[1]) { return false; } }
            elseif (is_array($value)) { if (!in_array($row[$field], $value, true)) { return false; } }
            elseif ($row[$field] !== $value) { return false; }
        }
        return true;
    }
    public function request(array $query): MaintenanceRows {
        if ($query['FROM'] !== 'glpi_plugin_glpichat_notificationjobs') { throw new RuntimeException('Unexpected table'); }
        $rows = array_values(array_filter($this->jobs, fn(array $row): bool => $this->matches($row, $query['WHERE'])));
        usort($rows, static function (array $a, array $b) use ($query): int {
            foreach ($query['ORDER'] ?? [] as $order) { $field = explode(' ', $order)[0]; $value = $a[$field] <=> $b[$field]; if ($value !== 0) { return $value; } }
            return 0;
        });
        $rows = array_slice($rows, 0, $query['LIMIT']);
        if ($this->changeAfterSelect && $rows !== []) { $this->jobs[$rows[0]['id']]['status'] = 'pending'; $this->changeAfterSelect = false; }
        return new MaintenanceRows($rows);
    }
    public function delete(string $table, array $where): bool {
        if ($table !== 'glpi_plugin_glpichat_notificationjobs') { throw new RuntimeException('Cleanup must never touch receipts'); }
        $this->affected = 0;
        foreach ($this->jobs as $id => $row) { if ($this->matches($row, $where)) { unset($this->jobs[$id]); ++$this->affected; } }
        return true;
    }
    public function affectedRows(): int { return $this->affected; }
    public function beginTransaction(): void {}
    public function commit(): void {}
    public function rollBack(): void {}
    public function doQuery(string $sql): array|false {
        if (preg_match('/WHERE id = (\d+) FOR UPDATE$/', $sql, $match)) { return $this->jobs[(int) $match[1]] ?? false; }
        if (!str_starts_with($sql, 'SELECT COUNT(*) AS pending') || !str_ends_with($sql, "WHERE status = 'pending'")) { throw new RuntimeException('Unexpected metric SQL'); }
        $rows = array_values(array_filter($this->jobs, static fn(array $row): bool => $row['status'] === 'pending'));
        return ['pending' => count($rows), 'due' => count(array_filter($rows, static fn(array $row): bool => $row['available_at'] <= date('Y-m-d H:i:s'))),
            'retrying' => count(array_filter($rows, static fn(array $row): bool => $row['attempts'] > 0)),
            'max_attempts' => $rows ? max(array_column($rows, 'attempts')) : null,
            'oldest_pending_at' => $rows ? min(array_column($rows, 'created_at')) : null];
    }
    public function fetchAssoc(array|false $row): array|false { return $row; }
    public function update(string $table, array $values, array $where): bool {
        foreach ($this->jobs as $id => $row) { if ($this->matches($row, $where)) { $this->jobs[$id] = array_replace($row, $values); } }
        return true;
    }
}
function maintenance_check(bool $ok, string $label): void { if (!$ok) { throw new RuntimeException($label); } echo '[PASS] ' . $label . "\n"; }
function maintenance_job(int $id, string $status = 'pending', ?string $completed = null): array {
    return ['id' => $id, 'status' => $status, 'completed_at' => $completed, 'created_at' => '2020-01-01 00:00:00',
        'available_at' => '2020-01-01 00:00:00', 'attempts' => 0, 'last_error' => ''];
}
$DB = new MaintenanceDb();
$DB->jobs = [1 => maintenance_job(1), 2 => maintenance_job(2, 'done', '2020-01-01 00:00:00'),
    3 => maintenance_job(3, 'suppressed', '2020-01-01 00:00:00'), 4 => maintenance_job(4, 'done', date('Y-m-d H:i:s')),
    5 => maintenance_job(5, 'done', null)];
maintenance_check(glpichat_cleanup_notification_jobs(1) === 1 && !isset($DB->jobs[2]), 'Retention obeys per-run row budget');
maintenance_check(glpichat_cleanup_notification_jobs() === 1 && isset($DB->jobs[1], $DB->jobs[4], $DB->jobs[5]), 'Only old completed/suppressed jobs are deleted; pending, recent and incomplete state survives');
maintenance_check($DB->receipts === ['durable' => 'untouched'], 'Message idempotency receipts are untouched');
$DB->jobs[6] = maintenance_job(6, 'done', '2020-01-01 00:00:00');
$DB->changeAfterSelect = true;
maintenance_check(glpichat_cleanup_notification_jobs() === 0 && $DB->jobs[6]['status'] === 'pending', 'Cleanup rechecks status after candidate selection');
$DB->jobs[6]['attempts'] = 8; $DB->jobs[6]['available_at'] = date('Y-m-d H:i:s', time() + 3600);
$metrics = glpichat_notification_queue_metrics();
maintenance_check($metrics === ['pending' => 2, 'due' => 1, 'retrying' => 1, 'max_attempts' => 8, 'oldest_pending_at' => '2020-01-01 00:00:00'], 'Metrics distinguish due work, backed-off retries and oldest backlog');
$DB->jobs = [];
maintenance_check(glpichat_notification_queue_metrics() === ['pending' => 0, 'due' => 0, 'retrying' => 0, 'max_attempts' => 0, 'oldest_pending_at' => null], 'Empty queue metrics have explicit zero/null values');
for ($id = 1; $id <= 105; ++$id) { $DB->jobs[$id] = maintenance_job($id); }
$result = glpichat_process_notification_jobs(1000, static fn(array $job): bool => true);
maintenance_check($result['delivered'] === 100 && glpichat_notification_queue_metrics()['pending'] === 5, 'Worker caps each invocation at 100 jobs');
$calls = 0;
$result = glpichat_process_notification_jobs(100, static function (array $job) use (&$calls): bool { ++$calls; usleep(30000); return true; }, 0.02);
maintenance_check($calls === 1 && $result['delivered'] === 1 && glpichat_notification_queue_metrics()['pending'] === 4, 'Elapsed budget stops between complete transactions and preserves remaining work');
