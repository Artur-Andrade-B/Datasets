<?php

declare(strict_types=1);

require dirname(__DIR__, 3) . '/src/desktop/conversations.php';

$checks = 0;
$check = static function (bool $ok, string $description) use (&$checks): void {
    ++$checks;
    if (!$ok) { throw new RuntimeException($description); }
};
$check(class_exists(DOMDocument::class), 'GLPI-required DOM extension must be available to exercise links.');
$source = '<p>Use <a href="https://help.example.test/path?a=1&amp;b=2">Ajuda &lt;TI&gt;</a> ou '
    . '<a href="mailto:support@example.test">suporte</a>.</p>';
$canonical = glpichat_desktop_text($source);
$links = glpichat_desktop_message_links($source);
$check($links === [
    ['label' => 'Ajuda <TI>', 'url' => 'https://help.example.test/path?a=1&b=2'],
    ['label' => 'suporte', 'url' => 'mailto:support@example.test'],
], 'Named link labels and decoded destinations survive display metadata.');
$check(glpichat_desktop_text($source) === $canonical && $canonical === 'Use Ajuda <TI> ou suporte.',
    'Link metadata does not change canonical receipt/idempotency text.');
$unsafe = [
    'javascript:alert(1)', 'data:text/html,test', 'file:///C:/Windows/test', 'shell:startup',
    '//outside.example.test/path', '/relative/path', 'https://user:secret@example.test/',
    "https://example.test/a\\b", "https://example.test/a\tb", 'mailto:a@example.test?subject=Injection',
    'mailto:a@example.test,b@example.test', 'https://',
];
foreach ($unsafe as $url) {
    $check(glpichat_desktop_message_links('<a href="' . htmlspecialchars($url, ENT_QUOTES) . '">Unsafe</a>') === [],
        'Reject non-display-safe destination: ' . $url);
}
$check(glpichat_desktop_message_links('<script><a href="https://example.test">Hidden</a></script>') === [], 'Script content cannot create a displayed link.');
$check(glpichat_desktop_message_links(str_repeat('a', 262145)) === [], 'Oversized native HTML does not enter DOM parsing.');
$check(glpichat_desktop_message_links("<a href='https://example.test'>\xff</a>") === [], 'Malformed UTF-8 is rejected before parsing.');
$many = '';
for ($i = 0; $i < 30; ++$i) { $many .= '<a href="https://example.test/' . $i . '">Link ' . $i . '</a>'; }
$check(count(glpichat_desktop_message_links($many)) === 20, 'Link metadata is capped at twenty destinations per message.');
$duplicate = '<a href="https://example.test/">A</a>';
$check(count(glpichat_desktop_message_links($duplicate . $duplicate)) === 1, 'Duplicate label/destination does not inflate metadata.');
$output = glpichat_desktop_message_output(['user_id' => 10], ['id' => 1, 'users_id' => 10, 'content' => $source,
    'date' => '2026-10-14 10:00:00', 'is_unread' => 1]);
$check($output['links'] === $links && $output['content'] === $canonical && !$output['is_unread'],
    'Message output adds display metadata but never labels own messages unread.');
echo "[PASS] Desktop display links: $checks assertions.\n";
