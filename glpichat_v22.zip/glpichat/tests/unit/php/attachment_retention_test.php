<?php

declare(strict_types=1);

// Production cleanup + Document authorization hook against a small DB fixture.
// This does not emulate the native GLPI document permission implementation.
namespace Glpi\DBAL {
    final class QueryFunction {
        public static function now(): string { return '2026-10-01 00:00:00'; }
        public static function dateSub(string $date, int $days, string $unit): string { return date('Y-m-d H:i:s', strtotime($date . ' -' . $days . ' days')); }
        public static function min(string $field, string $alias): string { return 'MIN(' . $field . ') AS ' . $alias; }
    }
}
namespace {
    define('READ', 1);
    final class Document { public array $fields = []; public mixed $right = READ; }
    final class Session {
        public static function haveRight(string $name, int $right): bool { return false; }
    }
    final class RetentionRows extends ArrayIterator {
        public function current(): mixed { return $this->valid() ? parent::current() : false; }
    }
    final class RetentionDb {
        public array $messages = [], $events = [];
        public int $affected = 0;
        private function expired(array $row, array $where): bool {
            return $row['date_creation'] < $where['date_creation'][1]
                && (!isset($where['documents_id']) || $row['documents_id'] === $where['documents_id']);
        }
        public function request(array $query): RetentionRows {
            if ($query['FROM'] === 'glpi_plugin_glpichat_rooms') { return new RetentionRows([['tickets_id' => 7]]); }
            if (isset($query['WHERE']['glpi_plugin_glpichat_messages.documents_id'])) {
                $document = $query['WHERE']['glpi_plugin_glpichat_messages.documents_id'];
                return new RetentionRows(array_values(array_filter($this->messages,
                    static fn(array $row): bool => $row['documents_id'] === $document && $row['room_type'] === 'internal')));
            }
            $rooms = [];
            foreach ($this->messages as $row) {
                if ($this->expired($row, $query['WHERE'])) { $rooms[$row['rooms_id']] = ['rooms_id' => $row['rooms_id'], 'oldest' => $row['date_creation']]; }
            }
            return new RetentionRows(array_values($rooms));
        }
        public function insert(string $table, array $row): bool { $this->events[] = $row; return true; }
        public function delete(string $table, array $where): bool {
            if ($table !== 'glpi_plugin_glpichat_messages') { throw new RuntimeException('Cleanup touched unrelated table'); }
            $this->affected = 0;
            foreach ($this->messages as $id => $row) {
                if ($this->expired($row, $where)) { unset($this->messages[$id]); ++$this->affected; }
            }
            return true;
        }
        public function affectedRows(): int { return $this->affected; }
    }
    require_once dirname(__DIR__, 3) . '/src/EventCleanupCron.php';
    require_once dirname(__DIR__, 3) . '/src/HookHandler.php';
    function retention_check(bool $ok, string $label): void { if (!$ok) { throw new RuntimeException($label); } echo '[PASS] ' . $label . "\n"; }
    $DB = new RetentionDb();
    foreach ([[1, 0, 'internal', '2020-01-01'], [2, 501, 'internal', '2020-01-01'],
        [3, 502, 'public', '2020-01-01'], [4, 0, 'public', '2026-09-30']] as [$id, $document, $room, $date]) {
        $DB->messages[$id] = ['id' => $id, 'rooms_id' => $room === 'internal' ? 1 : 2,
            'documents_id' => $document, 'room_type' => $room, 'date_creation' => $date . ' 00:00:00'];
    }
    $document = new Document(); $document->fields = ['id' => 501];
    \GlpiPlugin\Glpichat\HookHandler::canDocument($document);
    retention_check($document->right === null, 'Legacy internal attachment is denied before retention');
    $deleted = \GlpiPlugin\Glpichat\EventCleanupCron::deleteExpiredMessages(30);
    retention_check($deleted === 1 && array_keys($DB->messages) === [2, 3, 4], 'Only expired text is removed; old internal/public attachment evidence and recent text survive');
    retention_check(count($DB->events) === 1 && $DB->events[0]['rooms_id'] === 1, 'Purge events describe rooms with deleted text, not retained attachments');
    $document->right = READ;
    \GlpiPlugin\Glpichat\HookHandler::canDocument($document);
    retention_check($document->right === null, 'Legacy internal attachment is still denied after retention');
    retention_check(\GlpiPlugin\Glpichat\EventCleanupCron::deleteExpiredMessages(30) === 0, 'Repeated cleanup preserves authorization evidence');
}
