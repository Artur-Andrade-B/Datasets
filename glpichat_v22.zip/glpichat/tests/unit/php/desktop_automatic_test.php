<?php

declare(strict_types=1);

// Real issuance/authorization/redemption/revocation; fixture SQL and directory boundaries.
define('READ', 1); define('CREATE', 4);
class Auth { public const LDAP = 3; public const CAS = 5; public const X509 = 6; public const EXTERNAL = 4; }
class Ticket { public const READMY = 1; public const READALL = 1024; }
class ITILFollowup { public const SEEPUBLIC = 1; public const ADDMY = 4; public const ADDALLITEM = 4096; }
class Config {
    public static array $values = ['desktop_enabled' => '1', 'desktop_schema_version' => '9', 'desktop_idempotency_key' => 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'];
    public static function getConfigurationValues(string $context): array { return self::$values; }
}
require_once dirname(__DIR__, 2) . '/fixtures/desktop_enrollment_db.php';
require_once dirname(__DIR__, 3) . '/src/desktop/automatic.php';
$count = 0;
function check(bool $condition, string $message): void { global $count; if (!$condition) { throw new RuntimeException($message); } $count++; }
function rejects(callable $action, string $code): void {
    try { $action(); } catch (GlpichatDesktopException $e) { check($e->errorCode === $code, 'Expected ' . $code . '; got ' . $e->errorCode); return; }
    throw new RuntimeException('Missing error ' . $code);
}
function fixture(): array {
    global $DB;
    $DB = new DesktopEnrollmentDB(); glpichat_desktop_reset_request_context();
    $DB->tables['glpi_users'][0]['sync_field'] = '12345678-1234-1234-1234-1234567890ab';
    $DB->tables[GLPICHAT_MANAGEMENT_MACHINES][] = ['id' => 1, 'installation_id' => 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
        'token_hash' => glpichat_management_hash('machine', str_repeat('a', 64)), 'status' => 'active', 'computer_name' => 'OFFICE-PC'];
    $input = ['grant_id' => str_repeat('b', 32), 'grant_secret' => str_repeat('c', 64), 'windows_sid' => 'S-1-5-21-111-222-333-1001', 'computer_name' => 'OFFICE-PC'];
    return $input;
}
$reader = static fn(array $source, string $sid): array => [['login' => 'employee', 'object_guid' => '12345678-1234-1234-1234-1234567890ab', 'sync_value' => 'employee-sync']];
$authorize = static fn(array $input): array => glpichat_desktop_automatic_authorize(str_repeat('a', 64), 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', $input, $reader);
$input = fixture();
check(glpichat_desktop_automatic_sid_filter($input['windows_sid']) === '\\01\\05\\00\\00\\00\\00\\00\\05\\15\\00\\00\\00\\6f\\00\\00\\00\\de\\00\\00\\00\\4d\\01\\00\\00\\e9\\03\\00\\00', 'SID octets escaped exactly');
rejects(fn() => glpichat_desktop_automatic_sid_filter('S-1-5-21-1-2-3-4294967296'), 'invalid_enrollment');
rejects(fn() => $authorize($input + ['users_id' => 999]), 'invalid_request');
$renameInput = array_replace($input, ['computer_name' => 'OTHER-PC']);
$renamed = $authorize($renameInput);
check($renamed['grant']['computer_name'] === 'OTHER-PC' && $DB->tables[GLPICHAT_MANAGEMENT_MACHINES][0]['computer_name'] === 'OTHER-PC', 'Authenticated installation rename updates telemetry and issues name-bound grant');
rejects(fn() => $authorize($input), 'automatic_proposal_conflict');
$input = fixture();
$DB->tables[GLPICHAT_MANAGEMENT_MACHINES][0]['status'] = 'revoked';
rejects(fn() => $authorize($input), 'machine_invalid');
$DB->tables[GLPICHAT_MANAGEMENT_MACHINES][0]['status'] = 'active';
$DB->tables[GLPICHAT_MANAGEMENT_MACHINES][0]['computer_name'] = 'Office-PC';
$first = $authorize($input);
check($first['ok'] === true && $first['grant']['user_id'] === 10 && $first['grant']['grant_id'] === $input['grant_id'], 'Existing replicated user is bound automatically');
check(!isset($first['grant']['base_url']), 'Origin filled by trusted broker, never proxy guess');
check($authorize($input) === $first && count($DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE]) === 1, 'Lost-response exact retry is idempotent');
check(count($DB->tables[GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE]) === 1 && !str_contains(serialize($DB->tables), $input['grant_secret']), 'One binding, no plaintext secret stored');
rejects(fn() => $authorize(array_replace($input, ['grant_secret' => str_repeat('d', 64)])), 'automatic_proposal_conflict');
$enroll = $input + ['device_id' => '11111111-2222-4333-8444-555555555555', 'access_token' => str_repeat('e', 64), 'refresh_secret' => str_repeat('f', 64)];
$identity = glpichat_desktop_enroll($enroll);
check($identity['user']['id'] === 10 && $authorize($input) === $first, 'Issued grant redeems through unchanged enrollment, then replays');
$next = array_replace($input, ['grant_id' => str_repeat('d', 32), 'grant_secret' => str_repeat('e', 64)]);
$authorize($next);
check($DB->tables[GLPICHAT_DESKTOP_DEVICES_TABLE][0]['status'] === 'superseded' && $DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE][0]['status'] === 'superseded', 'Recovery supersedes previous credentials retaining history');
rejects(fn() => glpichat_desktop_authenticate($enroll['access_token']), 'device_revoked');
rejects(fn() => $authorize($input), 'automatic_proposal_conflict');
glpichat_desktop_grant_revoke($next['grant_id']);
$third = array_replace($input, ['grant_id' => str_repeat('e', 32), 'grant_secret' => str_repeat('f', 64)]);
rejects(fn() => $authorize($third), 'automatic_binding_revoked');
glpichat_desktop_automatic_release(1, 99);
rejects(fn() => $authorize($next), 'automatic_proposal_conflict');
check($authorize($third)['ok'] === true && $DB->tables[GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE][0]['released_by'] === 99, 'Administrative release permits held new proposal without reviving revoked grant');
$thirdEnroll = $third + ['device_id' => '21111111-2222-4333-8444-555555555555', 'access_token' => str_repeat('1', 64), 'refresh_secret' => str_repeat('2', 64)];
glpichat_desktop_enroll($thirdEnroll);
$thirdDevice = $DB->tables[GLPICHAT_DESKTOP_DEVICES_TABLE][1];
$beforeRevoke = $DB->tables;
rejects(fn() => glpichat_desktop_revoke_user_device((int) $thirdDevice['id'], 10), 'managed_connection_required');
check($DB->tables === $beforeRevoke && $authorize($third)['ok'] === true, 'Self-revoke cannot disable automatic managed binding');
glpichat_desktop_grant_revoke($third['grant_id']);
rejects(fn() => $authorize(array_replace($input, ['grant_id' => str_repeat('9', 32)])), 'automatic_binding_revoked');
glpichat_desktop_automatic_release(1, 99);
$newest = array_replace($input, ['grant_id' => str_repeat('9', 32)]);
$authorize($newest);
$DB->tables['glpi_users'][0]['date_creation'] = '2026-01-01 00:00:00';
rejects(fn() => $authorize($newest), 'automatic_identity_changed');

$input = fixture();
$legacy = glpichat_desktop_grant_issue(['users_id' => 10, 'profiles_id' => 3, 'entities_id' => 1, 'windows_sid' => $input['windows_sid'], 'computer_name' => $input['computer_name']]);
glpichat_desktop_grant_revoke($legacy['grant_id']);
rejects(fn() => $authorize($input), 'automatic_binding_revoked');
check(count($DB->tables[GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE]) === 1 && $DB->tables[GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE][0]['current_grant_id'] === $legacy['grant_id'], 'Legacy explicit revocation adopted durably for admin release');
glpichat_desktop_automatic_release(1, 99);
check($authorize($input)['ok'] === true, 'Legacy release completes automatic migration');

$input = fixture();
$legacy = glpichat_desktop_grant_issue(['users_id' => 10, 'profiles_id' => 3, 'entities_id' => 1,
    'windows_sid' => $input['windows_sid'], 'computer_name' => $input['computer_name']]);
glpichat_desktop_grant_revoke($legacy['grant_id']);
rejects(fn() => $authorize(array_replace($input, ['computer_name' => 'RENAMED-PC'])), 'automatic_binding_revoked');
check(count($DB->tables[GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE]) === 1, 'Rename adopts legacy revocation before issuing a new-name grant');

$input = fixture();
$legacy = glpichat_desktop_grant_issue(['users_id' => 10, 'profiles_id' => 3, 'entities_id' => 1,
    'windows_sid' => $input['windows_sid'], 'computer_name' => $input['computer_name']]);
glpichat_desktop_grant_revoke($legacy['grant_id']);
$DB->tables[GLPICHAT_MANAGEMENT_MACHINES][0]['previous_computer_name'] = $input['computer_name'];
$DB->tables[GLPICHAT_MANAGEMENT_MACHINES][0]['computer_name'] = 'POLL-RENAMED';
rejects(fn() => $authorize(array_replace($input, ['computer_name' => 'POLL-RENAMED'])), 'automatic_binding_revoked');

$input = fixture();
$DB->beforeQuery = static function (string $sql, DesktopEnrollmentDB $db): void {
    if (str_contains($sql, 'FROM glpi_users WHERE id=')) {
        $db->beforeQuery = null;
        $db->tables['glpi_users'][0]['sync_field'] = 'ffffffff-1234-1234-1234-1234567890ab';
    }
};
rejects(fn() => $authorize($input), 'automatic_identity_changed');
check($DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE] === [] && $DB->tables[GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE] === [], 'Account changed between directory comparison and context lookup cannot receive credentials');

$input = fixture();
rejects(fn() => glpichat_desktop_automatic_resolve($input['windows_sid'], static fn() => []), 'directory_identity_missing');
$DB->tables['glpi_authldaps'][] = array_replace($DB->tables['glpi_authldaps'][0], ['id' => 4]);
rejects(fn() => glpichat_desktop_automatic_resolve($input['windows_sid'], $reader), 'directory_identity_ambiguous');
array_pop($DB->tables['glpi_authldaps']);
$DB->tables['glpi_users'][0]['sync_field'] = 'aaaaaaaa-1234-1234-1234-1234567890ab';
rejects(fn() => $authorize($input), 'directory_identity_missing');
$DB->tables['glpi_users'][0]['sync_field'] = '12345678-1234-1234-1234-1234567890ab';
$DB->tables['glpi_users'][0]['is_active'] = 0;
rejects(fn() => $authorize($input), 'automatic_context_unavailable');
$DB->tables['glpi_users'][0]['is_active'] = 1;
$DB->tables['glpi_authldaps'][0]['sync_field'] = 'employeeNumber';
$DB->tables['glpi_users'][0]['sync_field'] = 'employee-sync';
check($authorize($input)['ok'] === true, 'Configured non-objectGUID synchronization attribute supported');

$input = fixture();
$first = $authorize($input);
$DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE][0]['expires_at'] = '2000-01-01 00:00:00';
rejects(fn() => $authorize($input), 'grant_expired');
$before = $DB->tables;
$DB->failInsert = GLPICHAT_DESKTOP_GRANTS_TABLE;
try { $authorize($next); throw new LogicException('Expected DB failure'); } catch (RuntimeException $e) { check($DB->tables === $before, 'Failed replacement rolls back supersession and binding atomically'); }
$DB->queries = [];
$authorize($next);
$locks = array_values(array_filter($DB->queries, static fn(string $q): bool => str_ends_with($q, 'FOR UPDATE')));
check(str_contains($locks[0], GLPICHAT_MANAGEMENT_MACHINES) && str_contains($locks[1], GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE), 'Same-machine requests serialize before binding creation/issuance');

// A directory user may use multiple registered computers concurrently. Names
// are display/delivery metadata; only installation + SID scopes the binding.
foreach (['SECOND-PC', 'OFFICE-PC'] as $secondHost) {
    $input = fixture();
    $first = $authorize($input);
    $firstEnroll = $input + ['device_id' => '11111111-2222-4333-8444-555555555555', 'access_token' => str_repeat('e', 64), 'refresh_secret' => str_repeat('f', 64)];
    $firstIdentity = glpichat_desktop_enroll($firstEnroll);
    $DB->tables[GLPICHAT_MANAGEMENT_MACHINES][] = ['id' => 2, 'installation_id' => 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
        'token_hash' => glpichat_management_hash('machine', str_repeat('2', 64)), 'status' => 'active', 'computer_name' => $secondHost];
    $secondInput = array_replace($input, ['grant_id' => str_repeat('3', 32), 'grant_secret' => str_repeat('4', 64), 'computer_name' => $secondHost]);
    $secondAuthorize = static fn(array $request): array => glpichat_desktop_automatic_authorize(str_repeat('2', 64), 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', $request, $reader);
    $second = $secondAuthorize($secondInput);
    $secondEnroll = $secondInput + ['device_id' => '22222222-2222-4333-8444-555555555555', 'access_token' => str_repeat('5', 64), 'refresh_secret' => str_repeat('6', 64)];
    $secondIdentity = glpichat_desktop_enroll($secondEnroll);
    $bindings = $DB->tables[GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE];
    check(count($bindings) === 2 && array_column($bindings, 'machines_id') === [1, 2]
        && array_column($bindings, 'windows_sid') === [$input['windows_sid'], $input['windows_sid']], 'Same SID has independent machine bindings, including reused host name: ' . $secondHost);
    check($firstIdentity['user']['subject_id'] === $secondIdentity['user']['subject_id']
        && $firstIdentity['device']['id'] !== $secondIdentity['device']['id'], 'Same GLPI principal receives independent simultaneous devices: ' . $secondHost);
    check(glpichat_desktop_authenticate($firstEnroll['access_token'])['user_id'] === 10
        && glpichat_desktop_authenticate($secondEnroll['access_token'])['user_id'] === 10, 'Both computers remain authorized after second enrollment: ' . $secondHost);
    $renew = ['grant_id' => $input['grant_id'], 'device_id' => $firstEnroll['device_id'], 'refresh_secret' => $firstEnroll['refresh_secret'], 'access_token' => str_repeat('7', 64)];
    $renewed = glpichat_desktop_renew($renew);
    $secondSnapshot = [$DB->tables[GLPICHAT_DESKTOP_DEVICES_TABLE][1], $DB->tables[GLPICHAT_DESKTOP_REGISTRATIONS_TABLE][1], $bindings[1]];
    check(glpichat_desktop_renew($renew) === $renewed && glpichat_desktop_authenticate($secondEnroll['access_token'])['user_id'] === 10,
        'Lost renewal response replays same operation without invalidating other computer: ' . $secondHost);
    $recovery = array_replace($input, ['grant_id' => str_repeat('8', 32), 'grant_secret' => str_repeat('9', 64)]);
    $authorize($recovery);
    rejects(fn() => glpichat_desktop_authenticate($renew['access_token']), 'device_revoked');
    check(glpichat_desktop_authenticate($secondEnroll['access_token'])['user_id'] === 10 &&
        [$DB->tables[GLPICHAT_DESKTOP_DEVICES_TABLE][1], $DB->tables[GLPICHAT_DESKTOP_REGISTRATIONS_TABLE][1], $DB->tables[GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE][1]] === $secondSnapshot,
        'Lost local state supersedes only recovering computer, preserving other credential and binding: ' . $secondHost);
    glpichat_desktop_grant_revoke($recovery['grant_id']);
    rejects(fn() => $authorize(array_replace($recovery, ['grant_id' => str_repeat('a', 32)])), 'automatic_binding_revoked');
    check($secondAuthorize($secondInput) === $second && glpichat_desktop_authenticate($secondEnroll['access_token'])['user_id'] === 10,
        'Explicit revoke of one machine does not revoke same user on another: ' . $secondHost);
    glpichat_desktop_automatic_release(1, 99);
    check($authorize(array_replace($recovery, ['grant_id' => str_repeat('a', 32)]))['ok'] === true
        && glpichat_desktop_authenticate($secondEnroll['access_token'])['user_id'] === 10,
        'Administrator release restores only selected machine binding: ' . $secondHost);
}

// A newly logged-on Windows account receives its own GLPI identity on the
// existing machine without a user-entered token or an administrator-issued file.
$input = fixture();
$authorize($input);
$firstEnroll = $input + ['device_id' => '11111111-2222-4333-8444-555555555555', 'access_token' => str_repeat('e', 64), 'refresh_secret' => str_repeat('f', 64)];
glpichat_desktop_enroll($firstEnroll);
$DB->tables['glpi_users'][] = array_replace($DB->tables['glpi_users'][0], ['id' => 20, 'name' => 'second.employee', 'sync_field' => '87654321-1234-1234-1234-1234567890ab']);
$DB->tables['glpi_profiles_users'][] = array_replace($DB->tables['glpi_profiles_users'][0], ['id' => 2, 'users_id' => 20]);
$newUser = array_replace($input, ['windows_sid' => 'S-1-5-21-111-222-333-1002', 'grant_id' => str_repeat('1', 32), 'grant_secret' => str_repeat('2', 64)]);
$newUserReader = static fn(array $source, string $sid): array => $sid === $newUser['windows_sid']
    ? [['login' => 'second.employee', 'object_guid' => '87654321-1234-1234-1234-1234567890ab', 'sync_value' => 'second-sync']] : $reader($source, $sid);
$newGrant = glpichat_desktop_automatic_authorize(str_repeat('a', 64), 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', $newUser, $newUserReader);
$newIdentity = glpichat_desktop_enroll($newUser + ['device_id' => '33333333-2222-4333-8444-555555555555', 'access_token' => str_repeat('3', 64), 'refresh_secret' => str_repeat('4', 64)]);
check($newGrant['grant']['user_id'] === 20 && $newIdentity['user']['id'] === 20
    && $newIdentity['device']['windows_sid'] === $newUser['windows_sid'], 'Second Windows user is resolved and enrolled automatically as their own GLPI user');
check(array_column($DB->tables[GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE], 'machines_id') === [1, 1]
    && array_column($DB->tables[GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE], 'users_id') === [10, 20]
    && glpichat_desktop_authenticate($firstEnroll['access_token'])['user_id'] === 10, 'Multiple Windows accounts on one computer retain independent bindings and credentials');

// A released automatic grant must retain its original machine provenance even
// when no current binding references it. A newly installed PC with the same
// display name and same user cannot inherit the other PC's revoked grant.
$input = fixture();
$authorize($input);
check($DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE][0]['automatic_machines_id'] === 1, 'Automatic grant records durable owning installation');
glpichat_desktop_grant_revoke($input['grant_id']);
glpichat_desktop_automatic_release(1, 99);
check($DB->tables[GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE][0]['current_grant_id'] === null, 'Administrative release detaches revoked current grant');
$DB->tables[GLPICHAT_MANAGEMENT_MACHINES][] = ['id' => 2, 'installation_id' => 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
    'token_hash' => glpichat_management_hash('machine', str_repeat('2', 64)), 'status' => 'active', 'computer_name' => 'OFFICE-PC'];
$newMachine = array_replace($input, ['grant_id' => str_repeat('3', 32), 'grant_secret' => str_repeat('4', 64)]);
check(glpichat_desktop_automatic_authorize(str_repeat('2', 64), 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', $newMachine, $reader)['ok'] === true,
    'Reused hostname cannot inherit released automatic revocation from another installation');
check($DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE][0]['status'] === 'revoked'
    && $DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE][0]['automatic_machines_id'] === 1
    && $DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE][1]['automatic_machines_id'] === 2,
    'Reused hostname leaves old revocation intact and records independent new owner');

$input = fixture();
$authorize($input);
glpichat_desktop_grant_revoke($input['grant_id']);
$DB->tables[GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE] = [];
rejects(fn() => $authorize(array_replace($input, ['grant_id' => str_repeat('3', 32)])), 'automatic_binding_revoked');
check($DB->tables[GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE][0]['current_grant_id'] === $input['grant_id'],
    'Missing binding row can recover its own proven machine grant without bypassing revocation');

$input = fixture();
$authorize($input);
glpichat_desktop_grant_revoke($input['grant_id']);
$DB->tables[GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE] = [];
$DB->tables[GLPICHAT_MANAGEMENT_MACHINES][] = ['id' => 2, 'installation_id' => 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
    'token_hash' => glpichat_management_hash('machine', str_repeat('2', 64)), 'status' => 'active', 'computer_name' => 'OFFICE-PC'];
$newMachine = array_replace($input, ['grant_id' => str_repeat('3', 32), 'grant_secret' => str_repeat('4', 64)]);
glpichat_desktop_automatic_authorize(str_repeat('2', 64), 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', $newMachine, $reader);
rejects(fn() => $authorize(array_replace($input, ['grant_id' => str_repeat('5', 32)])), 'automatic_binding_revoked');
check(count($DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE]) === 2
    && $DB->tables[GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE][1]['machines_id'] === 1
    && $DB->tables[GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE][1]['current_grant_id'] === $input['grant_id'],
    'Newer same-name foreign grant cannot hide original machine revocation when its binding row is missing');

// An existing automatic connection may rotate after an administrator issued a
// separate legacy-file grant. Its newer grant must not conceal that unproven
// legacy revocation from the first automatic connection on the other machine.
$input = fixture();
$DB->tables[GLPICHAT_MANAGEMENT_MACHINES][] = ['id' => 2, 'installation_id' => 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
    'token_hash' => glpichat_management_hash('machine', str_repeat('2', 64)), 'status' => 'active', 'computer_name' => 'OFFICE-PC'];
$foreign = array_replace($input, ['grant_id' => str_repeat('3', 32), 'grant_secret' => str_repeat('4', 64)]);
glpichat_desktop_automatic_authorize(str_repeat('2', 64), 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', $foreign, $reader);
$legacy = glpichat_desktop_grant_issue(['users_id' => 10, 'profiles_id' => 3, 'entities_id' => 1, 'windows_sid' => $input['windows_sid'], 'computer_name' => $input['computer_name']]);
glpichat_desktop_grant_revoke($legacy['grant_id']);
glpichat_desktop_automatic_authorize(str_repeat('2', 64), 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', array_replace($foreign, ['grant_id' => str_repeat('5', 32)]), $reader);
rejects(fn() => $authorize($input), 'automatic_binding_revoked');
check(count($DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE]) === 3
    && $DB->tables[GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE][1]['current_grant_id'] === $legacy['grant_id']
    && $DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE][1]['automatic_machines_id'] === 1,
    'Newer foreign automatic grant cannot hide legacy revocation, and adopted legacy ownership is durable');

$input = fixture();
$legacy = glpichat_desktop_grant_issue(['users_id' => 10, 'profiles_id' => 3, 'entities_id' => 1, 'windows_sid' => $input['windows_sid'], 'computer_name' => $input['computer_name']]);
glpichat_desktop_grant_revoke($legacy['grant_id']);
$DB->beforeQuery = static function (string $sql, DesktopEnrollmentDB $db): void {
    if (str_contains($sql, 'FROM ' . GLPICHAT_DESKTOP_GRANTS_TABLE) && str_ends_with($sql, 'FOR UPDATE')) {
        $db->beforeQuery = null;
        $db->tables[GLPICHAT_DESKTOP_GRANTS_TABLE][0]['automatic_machines_id'] = 2;
    }
};
check($authorize($input)['ok'] === true && $DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE][0]['status'] === 'revoked'
    && $DB->tables[GLPICHAT_DESKTOP_GRANTS_TABLE][0]['automatic_machines_id'] === 2
    && $DB->tables[GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE][0]['current_grant_id'] === $input['grant_id'],
    'Ownership assigned while waiting for the grant lock cannot attach another machine revoked authority');

Config::$values['desktop_schema_version'] = '8'; glpichat_desktop_reset_request_context();
rejects(fn() => $authorize($input), 'schema_unavailable');
Config::$values['desktop_schema_version'] = '9'; glpichat_desktop_reset_request_context();

Config::$values['desktop_enabled'] = '0'; glpichat_desktop_reset_request_context();
rejects(fn() => $authorize($next), 'desktop_disabled');
Config::$values['desktop_enabled'] = '1'; Config::$values['desktop_schema_version'] = '3'; glpichat_desktop_reset_request_context();
rejects(fn() => $authorize($next), 'schema_unavailable');
echo 'PASS desktop_automatic_test: ' . $count . " assertions; fixture SQL/directory boundary, no live AD claim.\n";
