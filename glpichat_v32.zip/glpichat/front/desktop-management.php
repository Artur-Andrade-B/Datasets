<?php

declare(strict_types=1);

// Sessionful GLPI11 page. Core consumes the native CSRF token on every POST.
// Every page-returning mutation redirects to a GET; never make this route stateless.
if (!defined('GLPI_ROOT')) { define('GLPI_ROOT', dirname(__DIR__, 3)); }
include GLPI_ROOT . '/inc/includes.php';
require_once dirname(__DIR__) . '/src/desktop/fleet.php';
require_once dirname(__DIR__) . '/src/desktop/authority.php';
require_once dirname(__DIR__) . '/src/desktop/queue_health.php';
require_once dirname(__DIR__) . '/src/desktop/runtime.php';
require_once dirname(__DIR__) . '/src/desktop/automatic.php';
Session::checkRight('plugin_glpichat_admin', READ);
glpichat_desktop_reset_request_context();
header('Cache-Control: no-store, private');
header('Referrer-Policy: no-referrer');
header('X-Content-Type-Options: nosniff');
$escape = static fn (mixed $value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$text = static fn (array $input, string $key): string => isset($input[$key]) && is_string($input[$key]) ? $input[$key] : '';
$integer = static function (array $input, string $key, bool $optional = false): int {
    $value = $input[$key] ?? ($optional ? '0' : '');
    if (!is_string($value) || preg_match('/\A[0-9]{1,10}\z/D', $value) !== 1 || (int) $value > 4294967295) { glpichat_desktop_fail('invalid_request', 'Número inválido.', 400); }
    return (int) $value;
};
$number = static fn (string $key): int => isset($_GET[$key]) && is_string($_GET[$key]) && ctype_digit($_GET[$key]) ? max(1, min(1000000, (int) $_GET[$key])) : 1;
$views = ['computers' => 'Computadores', 'connections' => 'Conexões de usuários', 'jobs' => 'Operações em lote', 'releases' => 'Versões e implantação'];
$view = $text($_GET, 'view'); if (!isset($views[$view])) { $view = 'computers'; }
$base = rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/') . '/plugins/glpichat';
$pageUrl = $base . '/front/desktop-management.php';
$navigation = ['view' => $view]; $filters = []; $error = ''; $message = ''; $preview = null; $fleetReady = false; $bindingStatus = ''; $resolvedRequest = '';
$canUpdate = Session::haveRight('plugin_glpichat_admin', UPDATE);
try {
    glpichat_management_require_schema();
    glpichat_management_authority_require_schema();
    if (!glpichat_management_admin_has_right((int) Session::getLoginUserID(), glpichat_management_issuing_profile(), READ)) {
        throw new \Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException('A permissão de consulta foi alterada.');
    }
    $fleetReady = true;
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        $canUpdate = $canUpdate && glpichat_management_admin_has_right((int) Session::getLoginUserID(), glpichat_management_issuing_profile(), UPDATE);
    }
    $filters = glpichat_management_filters([]);
    $filters = glpichat_management_filters($_GET);
    $navigation += $filters;
    foreach (['page', 'size', 'binding_page', 'rollout_page', 'target_page', 'grant_page', 'rollout_id', 'machine_id'] as $key) {
        if (isset($_GET[$key])) { $navigation[$key] = $number($key); }
    }
    $bindingStatus = $text($_GET, 'binding_status');
    if (in_array($bindingStatus, ['blocked', 'allowed'], true)) { $navigation['binding_status'] = $bindingStatus; }
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        Session::checkRight('plugin_glpichat_admin', UPDATE);
        $adminId = (int) Session::getLoginUserID();
        if ($adminId < 1 || !glpichat_management_admin_has_right($adminId, glpichat_management_issuing_profile(), UPDATE)) {
            throw new \Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException('A permissão de alteração foi removida.');
        }
        $action = $text($_POST, 'action');
        if ($action === 'import') {
            $file = $_FILES['release'] ?? [];
            if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_string($file['tmp_name'] ?? null) || !is_uploaded_file($file['tmp_name'])) {
                glpichat_desktop_fail('upload_failed', 'Selecione o ZIP da versão. Verifique os limites de upload do PHP se necessário.', 400);
            }
            $release = glpichat_management_import($file['tmp_name'], $adminId);
            $message = 'Versão ' . $release['version'] . ' importada.'; $navigation['view'] = 'releases';
        } elseif ($action === 'export') {
            // Deliberate separate download. Secrets never enter a redirect, flash or URL.
            $deployment = glpichat_management_deployment($text($_POST, 'base_url'), $text($_POST, 'enrollment_root'), $integer($_POST, 'max_uses'), $integer($_POST, 'ttl_days'), $adminId);
            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename="deployment.json"');
            echo json_encode($deployment, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR); exit;
        } elseif ($action === 'preview') {
            $filterText = $text($_POST, 'filters');
            if (strlen($filterText) > 4096) { glpichat_desktop_fail('invalid_request', 'Filtros inválidos.', 400); }
            try { $submittedFilters = json_decode($filterText, true, 4, JSON_THROW_ON_ERROR); }
            catch (JsonException $e) { glpichat_desktop_fail('invalid_request', 'Filtros inválidos.', 400); }
            if (!is_array($submittedFilters)) { glpichat_desktop_fail('invalid_request', 'Filtros inválidos.', 400); }
            $selected = $text($_POST, 'selected_ids');
            $ids = glpichat_management_selection_ids($selected !== '' ? $selected : ($_POST['machine_ids'] ?? []));
            $excluded = glpichat_management_selection_ids($text($_POST, 'excluded_ids') ?: '[]');
            $preview = glpichat_management_create_preview($integer($_POST, 'release_id', true), $text($_POST, 'operation'), $submittedFilters,
                $text($_POST, 'selection'), $ids, $excluded, $adminId, $text($_POST, 'request_id'), $text($_POST, 'reason'), $integer($_POST, 'concurrency'));
            if ($preview['committed'] ?? false) { $navigation['view'] = 'jobs'; $navigation['rollout_id'] = (int) $preview['rollout_id']; }
            else { $navigation['preview_id'] = $preview['preview_id']; }
            $message = ($preview['committed'] ?? false) ? 'Esta solicitação já foi registrada. Confira o recibo existente.' : 'Confira os alvos e confirme a operação. Nenhuma operação foi enviada aos computadores nesta prévia.';
        } elseif ($action === 'confirm') {
            $rollout = glpichat_management_confirm_preview($text($_POST, 'preview_id'), $adminId);
            // Receipt is durable before a bounded processing slice; processing failure
            // must not turn an accepted request into an ambiguous creation failure.
            try { glpichat_management_process_rollouts(100, 2.0); } catch (Throwable $e) { glpichat_desktop_log_failure('management_initial_slice', $e); }
            $navigation['view'] = 'jobs'; $navigation['rollout_id'] = (int) $rollout['id']; unset($navigation['preview_id']);
            if (preg_match('/\A[a-f0-9]{32}\z/D', $text($_POST, 'request_id')) === 1) { $navigation['request_id'] = $text($_POST, 'request_id'); }
            $message = 'Solicitação #' . (int) $rollout['id'] . ' registrada. Acompanhe os resultados confirmados abaixo; fechar esta página não interrompe a operação.';
        } elseif ($action === 'authority') {
            $result = glpichat_management_authority_change($text($_POST, 'kind'), $integer($_POST, 'id'), $text($_POST, 'operation'),
                $integer($_POST, 'revision'), $adminId, $text($_POST, 'request_id'), $text($_POST, 'reason'));
            $message = 'Permissão administrativa registrada. A alteração de permissão não confirma contato ou execução no computador.';
        } elseif ($action === 'pause_job') {
            glpichat_management_rollout_pause($integer($_POST, 'id'), $text($_POST, 'paused') === '1', $integer($_POST, 'revision'), $adminId, $text($_POST, 'request_id'), $text($_POST, 'reason'));
            $message = 'Distribuição da solicitação ajustada. Operações já entregues ao computador podem continuar.';
        } elseif ($action === 'cancel_job') {
            glpichat_management_rollout_cancel($integer($_POST, 'id'), $integer($_POST, 'revision'), $adminId, $text($_POST, 'request_id'), $text($_POST, 'reason'));
            $message = 'Lote cancelado para novos inícios. Operações já autorizadas conservam seus resultados e podem concluir.';
        } elseif ($action === 'dispatch_control') {
            glpichat_management_dispatch_control($integer($_POST, 'active_limit'), $text($_POST, 'paused') === '1', $integer($_POST, 'revision'), $adminId, $text($_POST, 'request_id'), $text($_POST, 'reason'));
            $message = 'Controle global atualizado. A pausa impede novas autorizações; resultados de operações autorizadas continuam aceitos.';
        } elseif ($action === 'revoke_registration') {
            glpichat_management_revoke('registration', $integer($_POST, 'id'));
            $message = 'Arquivo revogado para novos registros. Computadores já registrados permanecem gerenciados.';
        } else { glpichat_desktop_fail('invalid_request', 'Ação inválida.', 400); }
    }
} catch (GlpichatDesktopException $e) { $error = $e->getMessage(); }
catch (\Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException $e) { throw $e; }
catch (Throwable $e) { $reference = glpichat_desktop_log_failure('management_admin', $e); $error = 'Não foi possível concluir a operação. Referência para os logs: ' . $reference . '.'; }

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    // Bounded, per-session feedback. Request data/credentials never enter this store.
    $notice = bin2hex(random_bytes(16));
    $notices = is_array($_SESSION['glpichat_desktop_notices'] ?? null) ? $_SESSION['glpichat_desktop_notices'] : [];
    $notices = array_slice($notices, -9, null, true);
    $notices[$notice] = ['error' => substr($error, 0, 1000), 'message' => substr($message, 0, 1000), 'created' => time()];
    $_SESSION['glpichat_desktop_notices'] = $notices;
    header('Location: ' . $pageUrl . '?' . http_build_query($navigation + ['notice' => $notice]), true, 303);
    return;
}
$notice = $text($_GET, 'notice');
if (preg_match('/\A[a-f0-9]{32}\z/D', $notice) === 1) {
    $feedback = $_SESSION['glpichat_desktop_notices'][$notice] ?? null;
    if (is_array($feedback) && (int) $feedback['created'] >= time() - 900) { $error = $error ?: (string) $feedback['error']; $message = (string) $feedback['message']; }
    unset($_SESSION['glpichat_desktop_notices'][$notice]);
}
if ($fleetReady && $text($_GET, 'request_id') !== '') {
    try {
        $receipt = glpichat_management_request_receipt($text($_GET, 'request_id'), (int) Session::getLoginUserID());
        if ($receipt['status'] === 'committed') {
            $view = 'jobs'; $navigation['view'] = 'jobs'; $_GET['rollout_id'] = (string) $receipt['rollout_id']; $navigation['rollout_id'] = (int) $receipt['rollout_id']; $resolvedRequest = $receipt['request_id'];
            $message = 'Solicitação já registrada #' . (int) $receipt['rollout_id'] . '. A consulta não repetiu a operação.';
        } elseif ($receipt['status'] === 'preview') {
            $_GET['preview_id'] = $receipt['preview_id']; $resolvedRequest = $receipt['request_id'];
            $message = 'Prévia recuperada. Nenhuma confirmação foi repetida.';
        } elseif ($receipt['status'] === 'expired') { $resolvedRequest = $receipt['request_id']; $error = 'A prévia expirou sem confirmação. Prepare uma nova seleção.'; }
        else { $error = 'Nenhum recibo encontrado para esta solicitação. Se o envio acabou de ocorrer, aguarde e consulte novamente antes de criar outra operação.'; }
    } catch (GlpichatDesktopException $e) { $error = $e->getMessage(); }
    catch (Throwable $e) { $error = 'Consulta de recibo temporariamente indisponível. Referência: ' . glpichat_desktop_log_failure('management_receipt', $e); }
}
Html::header('GLPI Chat — Desktop Windows', $_SERVER['PHP_SELF'], 'config', 'plugins');
echo '<div class="container-fluid" id="desktop-console" data-owner="' . (int) Session::getLoginUserID() . '" data-receipt-url="' . $escape($pageUrl) . '" data-resolved-request="' . $escape($resolvedRequest) . '"><h1>Desktop Windows</h1><p>Gerencie permissões, instalações e operações. Datas em UTC; último contato não informa se o computador está ligado.</p>';
if ($error !== '') { echo '<div class="alert alert-danger" role="alert">' . $escape($error) . '</div>'; }
if ($message !== '') { echo '<div class="alert alert-success" role="status">' . $escape($message) . '</div>'; }
if (!$fleetReady) { echo '<p>Conclua a atualização do plugin pela gestão de plugins do GLPI.</p></div>'; Html::footer(); return; }
$csrf = static fn (): string => '<input type="hidden" name="_glpi_csrf_token" value="' . $escape(Session::getNewCSRFToken(true)) . '">';
$link = static fn (array $params): string => $pageUrl . '?' . http_build_query($params);
$pages = static function (string $parameter, int $current, int $maximum, array $extra = []) use ($navigation, $escape, $link): void {
    echo '<nav class="d-flex gap-3 my-2" aria-label="Paginação"><span>Página ' . $current . ' de ' . $maximum . '</span>';
    foreach (['Primeira' => 1, 'Anterior' => $current - 1, 'Próxima' => $current + 1, 'Última' => $maximum] as $label => $page) {
        if ($page < 1 || $page > $maximum || $page === $current) { continue; }
        echo '<a href="' . $escape($link(array_replace($navigation, $extra, [$parameter => $page]))) . '">' . $label . '</a>';
    } echo '</nav>';
};
$select = static function (string $name, string $label, array $options, string $current) use ($escape): void {
    echo '<label class="form-label" for="fleet-' . $name . '">' . $escape($label) . '</label><select class="form-select" name="' . $name . '" id="fleet-' . $name . '">';
    foreach ($options as $value => $title) { echo '<option value="' . $escape($value) . '"' . ((string) $value === $current ? ' selected' : '') . '>' . $escape($title) . '</option>'; } echo '</select>';
};
$stateLabel = static fn (string $state, string $action = ''): string => $state === 'completed' && in_array($action, ['suspend', 'resume'], true) ? 'Permissão aplicada' : glpichat_management_queue_state_label($state);
$operationLabel = static fn (string $action): string => ['update' => 'Atualizar', 'repair' => 'Reparar', 'suspend' => 'Suspender gerenciamento', 'resume' => 'Reativar gerenciamento', 'block' => 'Bloquear conexão', 'release' => 'Liberar nova conexão', 'recover_registration' => 'Permitir recuperar registro inicial'] [$action] ?? $action;
$authorityForm = static function (string $kind, array $target, string $action) use ($csrf, $escape, $operationLabel): void {
    echo '<details><summary>' . $escape($operationLabel($action)) . '</summary><form method="post" class="my-2">' . $csrf()
        . '<input type="hidden" name="action" value="authority"><input type="hidden" name="kind" value="' . $kind . '"><input type="hidden" name="id" value="' . (int) $target['id'] . '"><input type="hidden" name="revision" value="' . (int) ($target['admin_revision'] ?? 0) . '"><input type="hidden" name="operation" value="' . $action . '"><input type="hidden" name="request_id" value="' . bin2hex(random_bytes(16)) . '">'
        . '<label>Motivo <input class="form-control" name="reason" required minlength="3" maxlength="500"></label><p class="form-text">A alteração se aplica somente a este registro; restrições de outros usuários ou computadores são preservadas.</p><button class="btn btn-outline-primary">Confirmar ' . $escape($operationLabel($action)) . '</button></form></details>';
};
$monitorIds = []; $monitorJob = 0; $monitorTargetPage = 1;
echo '<p id="fleet-pending-receipt" class="alert alert-warning" hidden>Há um envio anterior sem recibo confirmado neste navegador. <a id="fleet-receipt-link">Consultar recibo sem repetir a operação</a></p>';
echo '<nav class="nav nav-tabs mb-3" aria-label="Desktop Windows">';
foreach ($views as $key => $label) { echo '<a class="nav-link' . ($key === $view ? ' active' : '') . '"' . ($key === $view ? ' aria-current="page"' : '') . ' href="' . $escape($link(['view' => $key])) . '">' . $escape($label) . '</a>'; } echo '</nav>';
try {
    if ($text($_GET, 'preview_id') !== '') {
        if (!$canUpdate) { Session::checkRight('plugin_glpichat_admin', UPDATE); }
        $preview = glpichat_management_get_preview($text($_GET, 'preview_id'), (int) Session::getLoginUserID());
        $intent = $preview['intent'] ?? $preview; $previewCommitted = (bool) ($preview['committed'] ?? false);
        echo '<span hidden id="fleet-preview-receipt" data-request-id="' . $escape($intent['request_id'] ?? '') . '"></span>';
        echo '<section class="card p-3 mb-3" aria-labelledby="preview-title"><h2 id="preview-title">' . ($previewCommitted ? 'Prévia já confirmada' : 'Confirmar alvos exatos') . '</h2><p>' . $escape($operationLabel((string) ($intent['action'] ?? ''))) . ': <strong>' . (int) $preview['target_count'] . '</strong> computadores; ' . (int) $preview['eligible_count'] . ' elegíveis; ' . (int) $preview['ineligible_count'] . ' inelegíveis; ' . (int) ($preview['waiting_count'] ?? 0) . ' aguardam uma operação em andamento. Prévia válida até ' . $escape($preview['expires_at']) . ' UTC.</p><p>Novos resultados da pesquisa não serão incluídos. Cada alvo será revalidado antes da execução; uma alteração administrativa concorrente pode gerar conflito.</p><p>Motivo: ' . $escape($intent['reason'] ?? '') . '</p><ul>';
        foreach ($preview['targets'] ?? [] as $target) { echo '<li>' . $escape($target['computer_name'] ?? ('#' . ($target['machines_id'] ?? $target['id'] ?? ''))) . ' — ' . $escape(($target['reason'] ?? '') !== '' ? glpichat_management_rollout_reason((string) $target['reason']) : (($target['waiting'] ?? false) ? 'Aguardará uma operação em andamento' : 'Elegível para revalidação')) . '</li>'; }
        echo '</ul><p>A lista acima é uma amostra limitada; a contagem se refere ao conjunto completo armazenado no servidor.</p>';
        if ($previewCommitted) { echo '<p>Esta prévia já originou uma solicitação. <a href="' . $escape($link(['view' => 'jobs', 'rollout_id' => (int) $preview['rollout_id']])) . '">Acompanhar solicitação #' . (int) $preview['rollout_id'] . '</a></p>'; }
        else { echo '<form method="post" id="fleet-confirm">' . $csrf() . '<input type="hidden" name="request_id" value="' . $escape($intent['request_id'] ?? '') . '"><input type="hidden" name="action" value="confirm"><input type="hidden" name="preview_id" value="' . $escape($preview['preview_id']) . '"><button class="btn btn-primary">Confirmar operação para estes alvos</button> <a href="' . $escape($link($navigation)) . '">Voltar sem confirmar</a></form>'; } echo '</section>';
    }
    if ($view === 'computers') {
        $list = glpichat_management_machine_page($filters, $number('page'), $number('size'));
        $releases = $canUpdate ? glpichat_desktop_db_rows('SELECT id,version,sequence FROM ' . GLPICHAT_MANAGEMENT_RELEASES . ' ORDER BY sequence DESC LIMIT 200') : [];
        echo '<h2>Computadores</h2><div class="d-flex gap-3 flex-wrap mb-3">';
        foreach (['Todos' => [], 'Gerenciamento suspenso' => ['status' => 'revoked'], 'Falhas' => ['operation_status' => 'failed'], 'Na fila' => ['operation_status' => 'queued'], 'Sem contato recente' => ['contact' => 'offline'], 'Conexões bloqueadas' => ['binding_status' => 'blocked']] as $label => $quick) {
            echo '<a href="' . $escape($link(['view' => 'computers'] + $quick)) . '">' . $label . '</a>';
        }
        echo '</div><form method="get" class="row g-2"><input type="hidden" name="view" value="computers">';
        foreach (['q' => ['Nome atual/anterior ou instalação', 100], 'user' => ['Usuário GLPI ou SID associado', 100], 'version' => ['Versão instalada', 32], 'contact_from' => ['Contato desde (UTC: AAAA-MM-DD HH:MM:SS)', 19], 'contact_to' => ['Contato até (UTC: AAAA-MM-DD HH:MM:SS)', 19]] as $key => [$label, $limit]) {
            echo '<div class="col-md-4"><label for="fleet-' . $key . '">' . $label . '</label><input class="form-control" id="fleet-' . $key . '" name="' . $key . '" maxlength="' . $limit . '" value="' . $escape($filters[$key] ?? '') . '"></div>';
        }
        foreach ([['search_mode', 'Busca por nome/instalação', ['exact' => 'Exata', 'prefix' => 'Começa com', 'contains' => 'Contém']], ['status', 'Permissão de gerenciamento', ['' => 'Todas', 'active' => 'Permitido', 'revoked' => 'Suspenso']], ['binding_status', 'Conexões de usuários', ['' => 'Todas', 'blocked' => 'Com conexão bloqueada', 'allowed' => 'Com conexão liberada']], ['health', 'Arquivos instalados', ['' => 'Todos', 'healthy' => 'Saudáveis', 'damaged' => 'Danificados', 'trial' => 'Em validação', 'unavailable' => 'Indisponíveis']], ['contact', 'Contato', ['' => 'Todos', 'recent' => 'Últimos 5 minutos', 'offline' => 'Sem contato há 5 minutos', 'never' => 'Nunca']], ['operation_status', 'Operação efetiva', ['' => 'Todas', 'none' => 'Nenhuma', 'queued' => 'Na fila', 'pending' => 'Execução autorizada', 'started' => 'Processamento iniciado', 'unknown' => 'Sem resultado recente', 'cancelled' => 'Cancelada antes da autorização', 'withdrawn' => 'Retirada confirmada; sem ativação', 'completed' => 'Concluída (resultado por operação)', 'failed' => 'Falha', 'superseded' => 'Substituída']], ['sort', 'Ordenar por', ['id' => 'Identificador', 'name' => 'Nome', 'contact' => 'Último contato']], ['direction', 'Ordem', ['desc' => 'Decrescente', 'asc' => 'Crescente']]] as [$key, $label, $options]) {
            echo '<div class="col-md-3">'; $select($key, $label, $options, (string) ($filters[$key] ?? ($key === 'binding_status' ? $bindingStatus : ''))); echo '</div>';
        }
        echo '<div class="col-md-2">'; $select('size', 'Por página', [50 => '50', 100 => '100'], (string) $list['size']);
        echo '</div><div class="col-12"><button class="btn btn-primary">Pesquisar</button> <a href="' . $escape($link(['view' => 'computers'])) . '">Limpar filtros</a></div></form><p class="mt-3">' . (int) $list['total'] . ' computadores encontrados. Uma conexão associada é histórica e não confirma uma sessão atual.</p>';
        $pages('page', $list['page'], $list['pages']);
        if ($canUpdate) {
            $filterJson = json_encode($filters, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
            echo '<form method="post" id="desktop-assignment" data-filter-key="' . $escape($filterJson) . '" data-total="' . (int) $list['total'] . '" data-owner="' . (int) Session::getLoginUserID() . '">' . $csrf()
                . '<input type="hidden" name="action" value="preview"><input type="hidden" name="request_id" value="' . bin2hex(random_bytes(16)) . '"><input type="hidden" name="filters" value="' . $escape($filterJson) . '"><input type="hidden" name="selected_ids" value=""><input type="hidden" name="excluded_ids" value="[]">';
            echo '<fieldset class="my-3"><legend>Selecionar computadores</legend><label class="me-3"><input type="radio" name="selection" value="selected" checked> Seleção manual entre páginas</label><label><input type="radio" name="selection" value="all"> Selecionar todos os ' . (int) $list['total'] . ' computadores correspondentes</label><br><button type="button" class="btn btn-sm btn-outline-secondary mt-2" id="fleet-select-page">Selecionar esta página</button> <button type="button" class="btn btn-sm btn-outline-secondary mt-2" id="fleet-clear-selection">Limpar seleção</button><p id="fleet-selection-count" aria-live="polite">Nenhum computador selecionado.</p><noscript>Sem JavaScript, a seleção manual vale somente para esta página. A opção Todos considera todos os resultados, sem exclusões. O servidor apresentará uma prévia antes da confirmação.</noscript></fieldset>';
        }
        echo '<div class="table-responsive"><table class="table"><thead><tr><th>Selecionar</th><th>Computador / instalação</th><th>Gerenciamento</th><th>Último contato UTC</th><th>Versão instalada</th><th>Operação efetiva</th><th>Execução / atenção</th></tr></thead><tbody>';
        foreach ($list['rows'] as $machine) {
            $id = (int) $machine['id']; $monitorIds[] = $id;
            $runtime = glpichat_management_runtime_view($machine); $bootstrap = glpichat_management_bootstrap_view($machine);
            $operation = (string) ($machine['operation_label'] ?? ($machine['assignment_status'] ? glpichat_management_queue_state_label((string) $machine['assignment_status']) : 'Nenhuma'));
            echo '<tr data-machine-id="' . $id . '"><td>' . ($canUpdate ? '<input type="checkbox" class="fleet-machine" name="machine_ids[]" value="' . $id . '" aria-label="Incluir ' . $escape($machine['computer_name']) . '">' : '—') . '</td><td><a href="' . $escape($link(array_replace($navigation, ['machine_id' => $id]))) . '#machine-detail">' . $escape($machine['computer_name']) . '</a><br><small>' . $escape($machine['installation_id']) . '</small>';
            if (($machine['previous_computer_name'] ?? '') !== '') { echo '<br><small>Nome anterior: ' . $escape($machine['previous_computer_name']) . '</small>'; }
            echo '</td><td data-field="permission_label">' . ($machine['status'] === 'active' ? 'Permitido' : 'Suspenso') . '</td><td data-field="last_seen">' . $escape($machine['last_seen'] ?? 'Nunca') . '</td><td><span data-field="current_version">' . $escape($machine['current_version'] ?: 'Não informada') . '</span><br><small>Bootstrap: <span data-field="bootstrap_version">' . $escape($machine['bootstrap_version']) . '</span></small></td><td><span data-field="operation_label">' . $escape($operation) . '</span><br><small data-field="operation_version">' . $escape($machine['assignment_version'] ?? '') . '</small><br><a data-job-link' . ((int) ($machine['rollout_id'] ?? 0) > 0 ? ' href="' . $escape($link(['view' => 'jobs', 'rollout_id' => (int) $machine['rollout_id']])) . '"' : ' hidden') . '>Solicitação <span data-field="rollout_id">' . ((int) ($machine['rollout_id'] ?? 0) > 0 ? '#' . (int) $machine['rollout_id'] : '') . '</span></a></td><td><span data-field="runtime_label">' . $escape($runtime['label']) . '</span><br><small data-field="bootstrap_label">' . $escape($bootstrap['label']) . '</small><br><small data-field="error_label">' . $escape(glpichat_management_error_label((string) ($machine['last_error'] ?? ''))) . '</small></td></tr>';
        }
        echo '</tbody></table></div>';
        if ($canUpdate) {
            echo '<div class="row g-2"><div class="col-md-4"><label for="assignment-action">Operação</label><select class="form-select" id="assignment-action" name="operation"><option value="update">Atualizar</option><option value="repair">Reparar</option><option value="suspend">Suspender gerenciamento</option><option value="resume">Reativar gerenciamento</option></select></div><div class="col-md-4"><label for="assignment-release">Versão (atualização/reparo)</label><select class="form-select" id="assignment-release" name="release_id"><option value="0">Selecione</option>';
            foreach ($releases as $release) { echo '<option value="' . (int) $release['id'] . '">' . $escape($release['version']) . ' — sequência ' . (int) $release['sequence'] . '</option>'; }
            echo '</select></div><div class="col-md-4"><label for="fleet-concurrency">Máximo de operações simultâneas neste lote</label><input class="form-control" type="number" id="fleet-concurrency" name="concurrency" value="25" min="1" max="250" required></div><div class="col-12"><label for="fleet-reason">Motivo</label><input class="form-control" id="fleet-reason" name="reason" required minlength="3" maxlength="500"></div></div><p class="form-text">A prévia armazena os alvos exatos antes da confirmação. Suspender gerenciamento bloqueia novos comandos e autorizações automáticas; credenciais de chat já emitidas exigem bloqueio específico da conexão.</p><button class="btn btn-primary" id="fleet-submit">Revisar alvos antes de confirmar</button></form>';
        }
        $pages('page', $list['page'], $list['pages']);
        if (isset($_GET['machine_id'])) {
            $detail = glpichat_management_machine_detail($number('machine_id')); $machine = $detail['machine'];
            $runtime = $machine['runtime'] ?? glpichat_management_runtime_view($machine); $bootstrap = $machine['bootstrap'] ?? glpichat_management_bootstrap_view($machine);
            echo '<section id="machine-detail" class="card p-3 mt-3"><p class="form-text">Detalhes e permissões capturados ao abrir esta página. Reabra os detalhes para obter o estado mais recente antes de alterar permissões.</p><h3>' . $escape($machine['computer_name']) . '</h3><p>Instalação: ' . $escape($machine['installation_id']) . '<br>Permissão: ' . ($machine['status'] === 'active' ? 'Permitido' : 'Suspenso') . '<br>Último contato UTC: ' . $escape($machine['last_seen'] ?? 'Nunca') . '</p>';
            echo '<p>Arquivos Agent/Widget: ' . $escape($machine['current_version'] ?: 'Não informados') . '; Bootstrap: ' . $escape($machine['bootstrap_version']) . '<br>' . $escape($bootstrap['label']) . '<br>' . $escape($runtime['label']) . '<br>Widget: ' . $escape($runtime['version']) . '; sessões na versão instalada: ' . (int) $runtime['current_sessions'] . ' / ' . (int) $runtime['sessions'] . '<br>Telemetria recebida UTC: ' . $escape($runtime['received_at'] ?: 'Não informada') . '<br>Erro: ' . $escape(glpichat_management_error_label((string) ($machine['last_error'] ?? ''))) . '</p>';
            if ($canUpdate) { $authorityForm('machine', $machine, $machine['status'] === 'active' ? 'suspend' : 'resume');
                echo '<p class="form-text">Reativar mantém bloqueios individuais de usuários. Uma instalação com credencial comprometida exige substituição controlada pelo administrador/GPO.</p>';
                if ($machine['status'] === 'active') { $authorityForm('machine', $machine, 'recover_registration'); }
                echo '<p class="form-text">Recuperar registro inicial permite repetir por tempo limitado a mesma inscrição, quando a resposta inicial foi perdida. Não cria ou substitui a credencial local.</p>';
            }
            echo '<p><a href="' . $escape($link(['view' => 'connections', 'machine_id' => (int) $machine['id']])) . '">Ver conexões de usuários desta instalação</a></p><details><summary>Operações recentes</summary><ul>';
            foreach ($detail['assignments'] ?? [] as $assignment) { echo '<li>#' . (int) $assignment['id'] . ' — ' . $escape(glpichat_management_queue_state_label((string) $assignment['status'])) . ' — ' . $escape($assignment['created_at'] ?? '') . '</li>'; } echo '</ul></details><details><summary>Histórico administrativo recente</summary><ul>';
            foreach ($detail['audit'] ?? [] as $audit) { echo '<li>' . $escape($audit['created_at']) . ' — ' . ((int) $audit['actor_id'] > 0 ? 'administrador #' . (int) $audit['actor_id'] : 'administração local/serviço') . ' — ' . $escape($operationLabel((string) $audit['action'])) . ' — ' . $escape($audit['reason']) . '</li>'; } echo '</ul></details></section>';
        }
    } elseif ($view === 'connections') {
        $bindingFilters = ['q' => $filters['q'], 'user' => $filters['user'] ?? '', 'machine_id' => isset($_GET['machine_id']) ? $number('machine_id') : 0, 'status' => $bindingStatus];
        $bindings = glpichat_management_binding_page($bindingFilters, $number('binding_page'), $number('size'));
        echo '<h2>Conexões de usuários</h2><p>Bloquear uma conexão revoga suas credenciais atuais. Liberar permite uma nova autorização automática; credenciais antigas permanecem revogadas. A associação não confirma logon atual.</p><form method="get" class="row g-2"><input type="hidden" name="view" value="connections"><div class="col-md-3"><label for="connections-q">Computador / instalação</label><input class="form-control" id="connections-q" name="q" maxlength="100" value="' . $escape($filters['q']) . '"></div><div class="col-md-3"><label for="connections-user">Usuário GLPI / SID</label><input class="form-control" id="connections-user" name="user" maxlength="100" value="' . $escape($filters['user'] ?? '') . '"></div><div class="col-md-3">';
        $select('binding_status', 'Permissão da conexão', ['' => 'Todas', 'blocked' => 'Bloqueada', 'allowed' => 'Liberada'], $bindingStatus);
        if ($bindingFilters['machine_id']) { echo '<input type="hidden" name="machine_id" value="' . (int) $bindingFilters['machine_id'] . '"><p>Somente instalação #' . (int) $bindingFilters['machine_id'] . '</p>'; }
        echo '</div><div class="col-md-3"><button class="btn btn-primary mt-4">Pesquisar</button> <a href="' . $escape($link(['view' => 'connections'])) . '">Limpar</a></div></form><p class="mt-3">' . (int) $bindings['total'] . ' conexões.</p><div class="table-responsive"><table class="table"><thead><tr><th>Computador</th><th>Usuário GLPI / SID</th><th>Permissão / ação</th></tr></thead><tbody>';
        foreach ($bindings['rows'] as $binding) {
            $blocked = (bool) ($binding['blocked'] ?? glpichat_desktop_automatic_blocked($binding, ['status' => $binding['device_status'] ?? '', 'revoked_at' => $binding['device_revoked_at'] ?? null], ['status' => $binding['grant_status'] ?? '', 'revoked_at' => $binding['grant_revoked_at'] ?? null]));
            echo '<tr><td><a href="' . $escape($link(['view' => 'computers', 'machine_id' => (int) ($binding['machines_id'] ?? 0)])) . '#machine-detail">' . $escape($binding['computer_name']) . '</a><br><small>' . $escape($binding['installation_id'] ?? '') . '</small></td><td>' . $escape($binding['user_name']) . '<br><small>' . $escape($binding['windows_sid']) . '</small></td><td>' . ($blocked ? 'Bloqueada' : 'Liberada');
            if (!glpichat_desktop_canonical_sid((string) $binding['windows_sid'])) { echo '<p class="text-warning">SID histórico não canônico: requer revisão administrativa; este registro não será normalizado automaticamente.</p>'; }
            if ($blocked && ($binding['machine_status'] ?? 'active') !== 'active') { echo '<p class="form-text">Reative o gerenciamento do computador antes de liberar esta conexão.</p>'; }
            if ($canUpdate && (!$blocked || (glpichat_desktop_canonical_sid((string) $binding['windows_sid']) && ($binding['machine_status'] ?? 'active') === 'active'))) { $authorityForm('binding', $binding, $blocked ? 'release' : 'block'); } echo '</td></tr>';
        }
        echo '</tbody></table></div>'; $pages('binding_page', $bindings['page'], $bindings['pages']);
    } elseif ($view === 'jobs') {
        $rollouts = glpichat_management_rollout_page($number('rollout_page'));
        $queueHealth = glpichat_management_queue_health();
        echo '<h2>Operações em lote</h2><p>Na fila: aguardando contato ou capacidade, sem ocupar vaga de execução. Autorizada: o computador pode iniciar mesmo se a confirmação não chegou. Sem resultado recente: a vaga é conservada até reconciliar o resultado. Processamento iniciado: o computador confirmou o início, antes do download. Arquivos confirmados: resultado instalado informado; execução do Widget e migração do Bootstrap são verificadas separadamente. Um lote encerrado pode conter falhas ou alvos ignorados.</p>';
        $dispatch = glpichat_management_one('glpi_plugin_glpichat_desktopdispatch', 'id=1');
        echo '<section class="card p-3 mb-3"><h3>Controle global de novas autorizações</h3><p><span id="fleet-dispatch-state">Limite global: ' . (int) ($dispatch['active_limit'] ?? 0) . ' operações autorizadas. Estado: ' . (!empty($dispatch['paused']) ? 'Pausado' : 'Permitido') . '.</span> O limite de cada lote também se aplica; lotes com contato recente compartilham as vagas. Operações sem resultado continuam contabilizadas.</p>';
        if ($canUpdate && $dispatch) {
            echo '<form method="post" class="row g-2">' . $csrf() . '<input type="hidden" name="action" value="dispatch_control"><input type="hidden" name="revision" value="' . (int) $dispatch['admin_revision'] . '"><input type="hidden" name="request_id" value="' . bin2hex(random_bytes(16)) . '"><div class="col-md-3"><label>Limite global <input class="form-control" name="active_limit" type="number" min="1" max="250" required value="' . (int) $dispatch['active_limit'] . '"></label></div><div class="col-md-3"><label>Novas autorizações <select class="form-select" name="paused"><option value="0"' . (empty($dispatch['paused']) ? ' selected' : '') . '>Permitir</option><option value="1"' . (!empty($dispatch['paused']) ? ' selected' : '') . '>Pausar</option></select></label></div><div class="col-md-6"><label>Motivo <input class="form-control" name="reason" minlength="3" maxlength="500" required></label></div><div><button class="btn btn-outline-primary">Aplicar controle global</button></div></form>';
        }
        echo '<p class="form-text">Reduzir o limite não interrompe instalações já autorizadas. Após restauração do banco, mantenha a distribuição pausada até revisar operações e revogações. O orçamento de bytes para download é independente e configurado no plugin.</p></section>';
        echo '<div class="alert alert-' . $escape($queueHealth['tone']) . '" data-role="queue-health"><strong>' . $escape($queueHealth['status']) . '</strong><br>Modo da ação auxiliar: ' . $escape($queueHealth['mode']) . '<br>Última execução registrada: ' . $escape($queueHealth['last_run']);
        if ($queueHealth['reference'] !== '') { echo '<br>Referência: ' . $escape($queueHealth['reference']); } echo '<br><small>O cadastro da ação automática não confirma atualização dos computadores. A distribuição continua sem esta página aberta. Lotes de permissões exigem que ProcessDesktopRollouts permaneça habilitada e executando no GLPI.</small></div>';
        echo '<div class="table-responsive"><table class="table"><thead><tr><th>Solicitação</th><th>Operação / versão</th><th>Alvos</th><th>Resultados confirmados</th><th>Criada UTC</th></tr></thead><tbody>';
        foreach ($rollouts['rows'] as $rollout) {
            $id = (int) $rollout['id']; $parts = [];
            foreach ($rollouts['counts'][$id] ?? [] as $state => $count) { $parts[] = $stateLabel((string) $state, (string) $rollout['action']) . ': ' . (int) $count; }
            echo '<tr data-job-row="' . $id . '"><td><a href="' . $escape($link(['view' => 'jobs', 'rollout_id' => $id])) . '#rollout-details">#' . $id . '</a><br><span data-job-field="status_label">' . $escape(glpichat_management_queue_state_label((string) $rollout['status'], '', true)) . '</span></td><td>' . $escape($operationLabel((string) $rollout['action'])) . ' / ' . $escape($rollout['version'] ?? '') . '</td><td>' . (int) $rollout['target_count'] . '</td><td data-job-field="counts">' . $escape(implode(' · ', $parts)) . '</td><td>' . $escape($rollout['created_at']) . '</td></tr>';
        } echo '</tbody></table></div>'; $pages('rollout_page', $rollouts['page'], $rollouts['pages']);
        if (isset($_GET['rollout_id'])) {
            $rolloutId = $number('rollout_id'); $targetPage = $number('target_page');
            $snapshot = glpichat_management_status_snapshot([], $rolloutId, $targetPage); $job = $snapshot['job'];
            if (!$job) { glpichat_desktop_fail('not_found', 'Solicitação indisponível.', 404); }
            $monitorJob = $rolloutId; $monitorTargetPage = (int) ($job['target_page'] ?? $targetPage);
            echo '<section id="rollout-details" class="card p-3"><h3>Computadores da solicitação #' . $rolloutId . '</h3><p id="fleet-job-state">' . $escape($job['status_label'] ?? glpichat_management_queue_state_label((string) $job['status'], '', true)) . '</p><p id="fleet-job-counts">';
            $parts = []; foreach ($job['counts'] ?? [] as $state => $count) { $parts[] = $stateLabel((string) $state, (string) $job['action']) . ': ' . (int) $count; } echo $escape(implode(' · ', $parts)) . '</p>';
            if ($canUpdate && in_array($job['action'], ['update', 'repair'], true) && in_array($job['status'], ['queued', 'running'], true)) {
                $paused = (bool) ($job['paused'] ?? false);
                echo '<form method="post" class="mb-3">' . $csrf() . '<input type="hidden" name="action" value="pause_job"><input type="hidden" name="id" value="' . $rolloutId . '"><input type="hidden" name="revision" value="' . (int) ($job['admin_revision'] ?? 0) . '"><input type="hidden" name="request_id" value="' . bin2hex(random_bytes(16)) . '"><input type="hidden" name="paused" value="' . ($paused ? '0' : '1') . '"><label>Motivo <input class="form-control" name="reason" minlength="3" maxlength="500" required></label><button class="btn btn-outline-secondary mt-2">' . ($paused ? 'Retomar distribuição' : 'Pausar distribuição') . '</button><p class="form-text">A pausa impede novas entregas; tarefas já entregues podem continuar. Atualize a lista antes de alterar novamente esta permissão.</p></form>';
            }
            if ($canUpdate && in_array($job['action'], ['update', 'repair'], true) && in_array($job['status'], ['queued', 'running'], true)) {
                echo '<form method="post" class="mb-3">' . $csrf() . '<input type="hidden" name="action" value="cancel_job"><input type="hidden" name="id" value="' . $rolloutId . '"><input type="hidden" name="revision" value="' . (int) ($job['admin_revision'] ?? 0) . '"><input type="hidden" name="request_id" value="' . bin2hex(random_bytes(16)) . '"><label>Motivo do cancelamento <input class="form-control" name="reason" minlength="3" maxlength="500" required></label><button class="btn btn-outline-danger mt-2">Cancelar novos inícios deste lote</button><p class="form-text">O cancelamento é definitivo para alvos ainda não autorizados. Operações já autorizadas podem continuar; seus resultados permanecem acompanhados.</p></form>';
            }
            echo '<div class="table-responsive"><table class="table"><thead><tr><th>Computador</th><th>Estado</th><th>Motivo / resultado</th><th>Distribuição no servidor</th><th>Último contato UTC</th></tr></thead><tbody>';
            foreach ($job['targets'] ?? [] as $target) {
                $state = $target['status'] === 'assigned' ? (string) ($target['operation_status'] ?? 'unknown') : (string) $target['status'];
                echo '<tr data-target-id="' . (int) $target['id'] . '"><td>' . $escape($target['computer_name'] ?? ('#' . $target['machines_id'])) . '</td><td data-target-field="status_label">' . $escape($target['status_label'] ?? glpichat_management_queue_state_label($state, (string) $target['reason'])) . '</td><td data-target-field="result_label">' . $escape($target['result_label'] ?? (glpichat_management_rollout_reason((string) $target['reason']) . ' ' . ($target['last_result'] ?? '') . ' ' . glpichat_management_error_label((string) ($target['last_error'] ?? '')))) . '</td><td><span data-target-field="dispatch_label">Tentativas com falha: ' . (int) $target['dispatch_attempts'] . ' / 5; última tentativa UTC: ' . $escape($target['last_attempt_at'] ?? 'Ainda não registrada') . '</span><br><small data-target-field="retry_label">' . ($target['reason'] === 'storage_retry' ? 'Nova tentativa UTC: ' . $escape($target['available_at']) : '') . '</small><br><small data-target-field="last_error_ref">' . $escape($target['last_error_ref'] ?? '') . '</small></td><td data-target-field="last_seen">' . $escape($target['last_seen'] ?? 'Nunca') . '</td></tr>';
            } echo '</tbody></table></div>'; $pages('target_page', $monitorTargetPage, (int) ($job['target_pages'] ?? 1), ['rollout_id' => $rolloutId]); echo '</section>';
        }
    } elseif ($view === 'releases') {
        $releases = glpichat_desktop_db_rows('SELECT id,version,sequence FROM ' . GLPICHAT_MANAGEMENT_RELEASES . ' ORDER BY sequence DESC LIMIT 200');
        $grantTotal = (int) (glpichat_desktop_db_rows('SELECT COUNT(*) AS total FROM ' . GLPICHAT_MANAGEMENT_GRANTS)[0]['total'] ?? 0);
        $grantPages = max(1, (int) ceil($grantTotal / 50)); $grantPage = min($number('grant_page'), $grantPages);
        $grants = glpichat_desktop_db_rows('SELECT id,registration_id,status,expires_at,max_uses,used_count,created_at FROM ' . GLPICHAT_MANAGEMENT_GRANTS . ' ORDER BY id DESC LIMIT 50 OFFSET ' . (($grantPage - 1) * 50));
        echo '<h2>Versões e implantação</h2>';
        if ($canUpdate) {
            echo '<div class="row"><section class="col-lg-6"><h3>Importar versão</h3><form method="post" enctype="multipart/form-data">' . $csrf() . '<input type="hidden" name="action" value="import"><label for="desktop-release">ZIP de versão desktop</label><input class="form-control" id="desktop-release" type="file" name="release" accept=".zip" required><p class="form-text">O ZIP contém Agent + Widget e Bootstrap compatível. Acompanhe arquivos instalados e componentes em execução separadamente.</p><button class="btn btn-primary">Importar versão</button></form></section>';
            $baseUrl = ''; try { $baseUrl = glpichat_desktop_base_url(); } catch (Throwable $e) { }
            echo '<section class="col-lg-6"><h3>Preparar implantação</h3><form method="post" target="_blank" id="desktop-export">' . $csrf() . '<input type="hidden" name="action" value="export"><label for="deployment-url">Endereço do GLPI usado pelos computadores</label><input class="form-control" id="deployment-url" name="base_url" value="' . $escape($baseUrl) . '" required maxlength="2048"><label for="registration-limit">Número máximo de computadores</label><input class="form-control" id="registration-limit" name="max_uses" type="number" min="1" max="10000" value="100" required><label for="registration-days">Validade em dias</label><input class="form-control" id="registration-days" name="ttl_days" type="number" min="1" max="30" value="7" required><p class="form-text">deployment.json contém credenciais de implantação e prepara conexão automática sem arquivo por usuário. O download abre separadamente. Uma nova exportação cria outra autorização; atualize esta página antes de solicitar outro arquivo.</p><button class="btn btn-primary">Baixar deployment.json</button><p id="desktop-export-feedback" role="status"></p></form></section></div>';
        }
        echo '<h3 class="mt-3">Versões disponíveis (até 200 mais recentes)</h3><ul>';
        foreach ($releases as $release) { echo '<li>' . $escape($release['version']) . ' — sequência ' . (int) $release['sequence'] . '</li>'; } echo '</ul><h3>Arquivos de implantação (' . $grantTotal . ')</h3><p>Revogar impede novos registros com esse arquivo; máquinas registradas permanecem gerenciadas.</p><div class="table-responsive"><table class="table"><thead><tr><th>Identificador</th><th>Validade UTC</th><th>Usos</th><th>Estado</th></tr></thead><tbody>';
        foreach ($grants as $grant) {
            echo '<tr><td>' . $escape($grant['registration_id']) . '</td><td>' . $escape($grant['expires_at']) . '</td><td>' . (int) $grant['used_count'] . ' / ' . (int) $grant['max_uses'] . '</td><td>' . $escape($grant['status']);
            if ($canUpdate && $grant['status'] === 'issued') { echo '<form method="post">' . $csrf() . '<input type="hidden" name="action" value="revoke_registration"><input type="hidden" name="id" value="' . (int) $grant['id'] . '"><button class="btn btn-sm btn-outline-danger">Revogar arquivo</button></form>'; } echo '</td></tr>';
        } echo '</tbody></table></div>'; $pages('grant_page', $grantPage, $grantPages);
    }
} catch (GlpichatDesktopException $e) { echo '<div class="alert alert-danger" role="alert">' . $escape($e->getMessage()) . '</div>'; }
catch (\Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException $e) { throw $e; }
catch (Throwable $e) { $reference = glpichat_desktop_log_failure('management_view', $e); echo '<div class="alert alert-danger" role="alert">Dados temporariamente indisponíveis. Referência: ' . $escape($reference) . '</div>'; }
if ($view === 'computers' || $view === 'jobs') {
    echo '<section id="fleet-monitor" class="card p-3 my-3" data-status-url="' . $escape($base . '/Admin/Desktop/Status') . '" data-machine-ids="' . $escape(json_encode($monitorIds, JSON_THROW_ON_ERROR)) . '" data-job-id="' . $monitorJob . '" data-target-page="' . $monitorTargetPage . '"><strong id="fleet-monitor-state" role="status">Atualização automática aguardando primeira consulta</strong><span>Última consulta: <time id="fleet-monitor-time">ainda não realizada</time></span><p id="fleet-monitor-detail">A consulta atualiza as linhas das tabelas e mantém sua seleção e posição. Detalhes e formulários conservam o estado da abertura da página. Para acompanhar os alvos de um lote, abra a solicitação.</p><button type="button" class="btn btn-outline-secondary align-self-start" id="fleet-refresh-now">Atualizar agora</button><a id="fleet-refresh-list" href="' . $escape($link($navigation)) . '" hidden>Reaplicar filtros e atualizar a lista</a></section>';
}
echo '</div><script src="' . $escape($base . '/public/js/desktop-management.js?v=' . rawurlencode(defined('PLUGIN_GLPICHAT_VERSION') ? PLUGIN_GLPICHAT_VERSION : '0.9.12')) . '"></script>';
Html::footer();
