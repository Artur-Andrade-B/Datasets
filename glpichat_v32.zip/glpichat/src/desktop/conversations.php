<?php

declare(strict_types=1);

require_once __DIR__ . '/../admission.php';
require_once __DIR__ . '/sync.php';

/**
 * Desktop requester conversations, text and attachments. Native public ITILFollowup rows are the readable source.
 * No browser Session actor is fabricated. These functions receive a freshly
 * authenticated actor and revalidate it within every mutation transaction.
 */

function glpichat_desktop_text(string $html, int $maxCharacters = 16000): string
{
    // Bounds apply before DOM/regex processing, including malicious native HTML.
    if (strlen($html) > 262144 || preg_match('//u', $html) !== 1) {
        return 'Conteúdo disponível no GLPI.';
    }
    $html = preg_replace('~<(script|style|iframe|object|svg|math|template)\b[^>]*>.*?</\1\s*>~isu', '', $html) ?? '';
    $html = preg_replace('~<!--.*?-->~su', '', $html) ?? '';
    $html = preg_replace('~<(?:br\b[^>]*|/(?:p|div|li|tr|h[1-6]|pre|blockquote)\s*)>~iu', "\n", $html) ?? '';
    $text = html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = str_replace(["\r\n", "\r"], "\n", $text);
    $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F\x{202A}-\x{202E}\x{2066}-\x{2069}]/u', '', $text) ?? '';
    // Preserve internal whitespace exactly: submitted plain text is escaped to
    // HTML once, and idempotent replay must compare that lossless inverse.
    $text = trim($text);
    if ($text === '') {
        return 'Conteúdo disponível no GLPI.';
    }
    if (mb_strlen($text, 'UTF-8') > $maxCharacters) {
        return mb_substr($text, 0, $maxCharacters, 'UTF-8') . "\n[Continue a leitura no GLPI.]";
    }
    return $text;
}

function glpichat_desktop_normalize_message(string $content): string
{
    if (strlen($content) > 16000 || preg_match('//u', $content) !== 1) {
        glpichat_desktop_fail('invalid_content', 'A mensagem deve conter texto UTF-8 de até 4000 caracteres.', 400);
    }
    $content = str_replace(["\r\n", "\r"], "\n", $content);
    if (class_exists('Normalizer')) {
        $normalized = Normalizer::normalize($content, Normalizer::FORM_C);
        if (!is_string($normalized)) {
            glpichat_desktop_fail('invalid_content', 'Texto inválido.', 400);
        }
        $content = $normalized;
    }
    if (preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F\x{202A}-\x{202E}\x{2066}-\x{2069}]/u', $content)) {
        glpichat_desktop_fail('invalid_content', 'O texto contém caracteres de controle não permitidos.', 400);
    }
    $content = preg_replace('/^\s+|\s+$/u', '', $content) ?? '';
    if ($content === '' || mb_strlen($content, 'UTF-8') > 4000) {
        glpichat_desktop_fail('invalid_content', 'A mensagem deve conter de 1 a 4000 caracteres.', 400);
    }
    return $content;
}

/** This predicate is shared by History, unread metadata, replay and exact-ID Read. */
function glpichat_desktop_public_followup_predicate(string $alias = 'f'): string
{
    // Only a compiled alias is accepted; never a route/body value.
    if ($alias !== 'f') {
        throw new LogicException('Unsupported followup alias.');
    }
    return "f.itemtype = 'Ticket' AND f.is_private = 0 AND NOT EXISTS ("
        . 'SELECT 1 FROM glpi_plugin_glpichat_messages gm '
        . 'LEFT JOIN glpi_plugin_glpichat_rooms gr ON gr.id = gm.rooms_id '
        . 'WHERE gm.itilfollowups_id = f.id AND ('
        . 'gm.tickets_id <> f.items_id OR gr.id IS NULL '
        . 'OR gr.tickets_id <> f.items_id OR BINARY gr.room_type <> BINARY \'public\' '
        . "OR BINARY gm.participant_type <> BINARY 'user' "
        . "OR NOT ((gm.documents_id = 0 AND BINARY gm.message_type IN (BINARY 'message', BINARY 'text')) "
        . "OR (gm.documents_id > 0 AND BINARY gm.message_type = BINARY 'attachment'))))";
}

function glpichat_desktop_ticket(array $actor, int $ticketId, bool $lock = false): array
{
    if ($ticketId <= 0 || (int) ($actor['user_id'] ?? 0) <= 0 || empty($actor['can_read'])) {
        glpichat_desktop_fail('conversation_unavailable', 'Conversa indisponível.', 404);
    }
    $userId = (int) $actor['user_id'];
    $entityId = (int) $actor['entity_id'];
    // Explicit locks cover the ticket and direct requester row on mutation.
    $rows = glpichat_desktop_db_rows('SELECT id, name, status, entities_id FROM glpi_tickets '
        . "WHERE id = $ticketId AND entities_id = $entityId AND is_deleted = 0 AND status IN (1,2,3,4,5,6)"
        . ($lock ? ' FOR UPDATE' : ''));
    if (!$rows) {
        glpichat_desktop_fail('conversation_unavailable', 'Conversa indisponível.', 404);
    }
    $requesters = glpichat_desktop_db_rows('SELECT id FROM glpi_tickets_users '
        . "WHERE tickets_id = $ticketId AND users_id = $userId AND type = 1 LIMIT 1"
        . ($lock ? ' FOR UPDATE' : ''));
    if (!$requesters) {
        glpichat_desktop_fail('conversation_unavailable', 'Conversa indisponível.', 404);
    }
    return $rows[0];
}

function glpichat_desktop_ticket_output(array $actor, array $ticket): array
{
    $reason = !empty($ticket['is_deleted']) ? 'conversation_merged'
        : (!in_array((int) $ticket['status'], [1, 2, 3, 4], true) ? 'conversation_closed'
            : (empty($actor['can_create']) ? 'authorization_denied' : ''));
    return [
        'ticket_id' => (int) $ticket['id'],
        'title' => glpichat_desktop_text((string) $ticket['name'], 250),
        'status' => (int) $ticket['status'],
        'can_send' => $reason === '',
        'read_only_reason' => $reason,
    ];
}

/** Own-actor receipt metadata only; message visibility is checked by the caller. */
function glpichat_desktop_message_uuid_select(int $userId): string
{
    if ($userId <= 0) {
        throw new InvalidArgumentException('A current desktop actor is required.');
    }
    // The existing (tickets_id,itilfollowups_id) index bounds each receipt lookup.
    // A scalar lookup also avoids duplicate message IDs if receipts are repaired.
    return '(SELECT ds.client_message_id FROM glpi_plugin_glpichat_desktopsends ds '
        . "WHERE ds.users_id = $userId AND ds.users_id = f.users_id "
        . 'AND ds.tickets_id = f.items_id AND ds.itilfollowups_id = f.id '
        . 'ORDER BY ds.id DESC LIMIT 1) AS client_message_id';
}

function glpichat_desktop_conversations(array $actor, int $before, int $limit): array
{
    // The controller supplies the freshly authenticated request actor. Reads
    // reuse that snapshot; mutations revalidate it under transaction locks.
    if ((int) ($actor['user_id'] ?? 0) <= 0 || !isset($actor['entity_id'])
        || (int) $actor['entity_id'] < 0 || empty($actor['can_read'])) {
        glpichat_desktop_fail('conversation_unavailable', 'Conversa indisponível.', 404);
    }
    $limit = max(1, min(30, $limit));
    $userId = (int) $actor['user_id'];
    $entityId = (int) $actor['entity_id'];
    $beforeSql = $before > 0 ? ' AND t.id < ' . $before : '';
    $tickets = glpichat_desktop_db_rows('SELECT t.id, t.name, t.status, t.entities_id FROM glpi_tickets t '
        . "WHERE t.entities_id = $entityId AND t.is_deleted = 0 AND t.status IN (1,2,3,4,5,6)"
        . $beforeSql . ' AND EXISTS (SELECT 1 FROM glpi_tickets_users tu '
        . "WHERE tu.tickets_id = t.id AND tu.users_id = $userId AND tu.type = 1) "
        . 'ORDER BY t.id DESC LIMIT ' . ($limit + 1));
    $hasMore = count($tickets) > $limit;
    $tickets = array_slice($tickets, 0, $limit);
    $summaryByTicket = [];
    if ($tickets) {
        $ticketIds = implode(',', array_map(static fn(array $row): int => (int) $row['id'], $tickets));
        // Aggregate metadata only, never fetch a ticket's entire body history.
        // count:sum:max is a change hint, not a cursor or cryptographic set proof.
        $unread = "(f.users_id <> $userId AND dr.id IS NULL)";
        $summaries = glpichat_desktop_db_rows('SELECT f.items_id, MAX(f.id) AS latest_message_id, '
            . "SUM(CASE WHEN $unread THEN 1 ELSE 0 END) AS unread_count, "
            . "SUM(CASE WHEN $unread THEN f.id ELSE 0 END) AS unread_sum, "
            . "MAX(CASE WHEN $unread THEN f.id ELSE 0 END) AS unread_max "
            . 'FROM glpi_itilfollowups f LEFT JOIN glpi_plugin_glpichat_desktopreads dr '
            . "ON dr.itilfollowups_id = f.id AND dr.users_id = $userId "
            . "WHERE f.items_id IN ($ticketIds) AND " . glpichat_desktop_public_followup_predicate()
            . ' GROUP BY f.items_id');
        foreach ($summaries as $summary) {
            $summaryByTicket[(int) $summary['items_id']] = $summary;
        }
    }
    // One database round trip, with at most30 independently limited index walks.
    // Derived tables with LIMIT keep this compatible with supported MySQL/MariaDB
    // versions without a window function or an unbounded history transfer.
    $activityQueries = [];
    foreach ($tickets as $ticket) {
        $ticketId = (int) $ticket['id'];
        $latest = (int) ($summaryByTicket[$ticketId]['latest_message_id'] ?? 0);
        if ($latest > 0) {
            $activityQueries[] = 'SELECT * FROM (SELECT f.items_id, f.id, '
                . glpichat_desktop_message_uuid_select($userId) . ' FROM glpi_itilfollowups f '
                . "WHERE f.items_id = $ticketId AND f.id <= $latest AND "
                . glpichat_desktop_public_followup_predicate() . ' ORDER BY f.id DESC LIMIT 21) activity_'
                . count($activityQueries);
        }
    }
    $activityByTicket = [];
    if ($activityQueries) {
        foreach (glpichat_desktop_db_rows(implode(' UNION ALL ', $activityQueries)) as $activityRow) {
            $activityByTicket[(int) $activityRow['items_id']][] = $activityRow;
        }
    }
    $output = [];
    foreach ($tickets as $ticket) {
        $summary = $summaryByTicket[(int) $ticket['id']] ?? [];
        $count = (int) ($summary['unread_count'] ?? 0);
        $ticketId = (int) $ticket['id'];
        $latest = (int) ($summary['latest_message_id'] ?? 0);
        // Unlike unread state, activity includes messages by this same GLPI user
        // on another client. A receipt UUID lets this desktop suppress its own
        // acknowledged or still-pending idempotent send without hiding web sends.
        $activity = $activityByTicket[$ticketId] ?? [];
        usort($activity, static fn(array $a, array $b): int => (int) $b['id'] <=> (int) $a['id']);
        $activityHasMore = count($activity) > 20;
        $activity = array_slice($activity, 0, 20);
        $output[] = glpichat_desktop_ticket_output($actor, $ticket) + [
            'unread_count' => $count,
            'unread_revision' => $count . ':' . (string) ($summary['unread_sum'] ?? '0') . ':' . (string) ($summary['unread_max'] ?? '0'),
            'latest_message_id' => $latest,
            'recent_activity' => array_map(static fn(array $row): array => [
                'id' => (int) $row['id'],
                'client_message_id' => isset($row['client_message_id']) ? (string) $row['client_message_id'] : null,
            ], $activity),
            // Existing History(before=activity_before) continues strictly below
            // this window if the client cannot yet classify all unseen activity.
            'activity_before' => $activityHasMore ? (int) $activity[count($activity) - 1]['id'] : 0,
        ];
    }
    return [
        'conversations' => $output,
        'next_before' => $hasMore && $tickets ? (int) $tickets[count($tickets) - 1]['id'] : 0,
        'has_more' => $hasMore,
    ];
}

/** Complete unread totals are independent of the visible ticket page. Only
 * aggregate metadata is read across the authorized scope; bodies and attachment
 * metadata remain restricted to the bounded History request. */
function glpichat_desktop_inbox(array $actor, int $before, int $limit, bool $includeSummary = true): array
{
    if ((int) ($actor['user_id'] ?? 0) <= 0 || !isset($actor['entity_id'])
        || (int) $actor['entity_id'] < 0 || empty($actor['can_read'])) {
        glpichat_desktop_fail('conversation_unavailable', 'Conversa indisponível.', 404);
    }
    $userId = (int) $actor['user_id'];
    $entityId = (int) $actor['entity_id'];
    $limit = max(1, min(30, $limit));
    $scope = ' FROM glpi_tickets t JOIN glpi_itilfollowups f ON f.items_id=t.id AND f.itemtype=\'Ticket\' '
        . 'LEFT JOIN glpi_plugin_glpichat_desktopreads dr ON dr.itilfollowups_id=f.id AND dr.users_id=' . $userId
        . " WHERE t.entities_id = $entityId AND t.is_deleted = 0 AND t.status IN (1,2,3,4,5,6)"
        . ' AND EXISTS (SELECT 1 FROM glpi_tickets_users tu WHERE tu.tickets_id=t.id'
        . " AND tu.users_id = $userId AND tu.type = 1) AND f.users_id <> $userId AND dr.id IS NULL AND "
        . glpichat_desktop_public_followup_predicate();
    // Continuation pages can retain the first page's summary, avoiding another
    // whole-scope aggregate for every navigation click. Default stays complete.
    $includeSummary = $includeSummary || $before <= 0;
    $totals = $includeSummary
        ? glpichat_desktop_db_rows('SELECT COUNT(*) AS unread_total,COUNT(DISTINCT t.id) AS unread_conversations' . $scope)[0] ?? []
        : [];
    // Stable ticket-ID keyset: a new reply cannot move an existing row behind
    // the cursor. Totals intentionally never inherit this page's before filter.
    $rows = glpichat_desktop_db_rows('SELECT t.id,t.name,t.status,t.entities_id,COUNT(*) AS unread_count,'
        . 'MIN(f.id) AS first_unread_id,MAX(f.id) AS last_unread_id,SUM(f.id) AS unread_sum'
        . $scope . ($before > 0 ? ' AND t.id < ' . $before : '')
        . ' GROUP BY t.id,t.name,t.status,t.entities_id ORDER BY t.id DESC LIMIT ' . ($limit + 1));
    $hasMore = count($rows) > $limit;
    $rows = array_slice($rows, 0, $limit);
    $conversations = [];
    foreach ($rows as $row) {
        $count = (int) $row['unread_count'];
        $conversations[] = glpichat_desktop_ticket_output($actor, $row) + [
            'unread_count' => $count,
            'unread_revision' => $count . ':' . $row['unread_sum'] . ':' . $row['last_unread_id'],
            'first_unread_id' => (int) $row['first_unread_id'],
            'last_unread_id' => (int) $row['last_unread_id'],
        ];
    }
    $result = ['summary_included' => $includeSummary, 'conversations' => $conversations, 'has_more' => $hasMore,
        'next_before' => $hasMore && $rows ? (int) $rows[count($rows) - 1]['id'] : 0];
    if ($includeSummary) {
        $result['unread_total'] = (int) ($totals['unread_total'] ?? 0);
        $result['unread_conversations'] = (int) ($totals['unread_conversations'] ?? 0);
    }
    return $result;
}

/** Display-only destinations. Do not change glpichat_desktop_text(): its exact
 * output participates in existing send receipt/idempotency comparisons. */
function glpichat_desktop_message_links(string $html): array
{
    if (strlen($html) > 262144 || preg_match('//u', $html) !== 1 || !class_exists(DOMDocument::class)) { return []; }
    $html = preg_replace('~<(script|style|iframe|object|svg|math|template)\b[^>]*>.*?</\1\s*>~isu', '', $html) ?? '';
    $previous = libxml_use_internal_errors(true);
    try {
        $document = new DOMDocument();
        if (!$document->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING)) { return []; }
        $links = [];
        foreach ($document->getElementsByTagName('a') as $anchor) {
            $url = trim($anchor->getAttribute('href'));
            if ($url === '' || strlen($url) > 2048 || preg_match('/[\x00-\x20\x7f\\\\]/', $url)) { continue; }
            $parts = parse_url($url);
            if (!is_array($parts) || isset($parts['user']) || isset($parts['pass'])) { continue; }
            $scheme = strtolower((string) ($parts['scheme'] ?? ''));
            if (in_array($scheme, ['http', 'https'], true)) {
                if (empty($parts['host'])) { continue; }
            } elseif ($scheme === 'mailto') {
                if (!filter_var($parts['path'] ?? '', FILTER_VALIDATE_EMAIL) || isset($parts['query']) || isset($parts['fragment'])) { continue; }
            } else { continue; }
            $label = glpichat_desktop_text(htmlspecialchars($anchor->textContent, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'), 250);
            $links[$url . "\0" . $label] = ['label' => $label, 'url' => $url];
            if (count($links) >= 20) { break; }
        }
        return array_values($links);
    } finally { libxml_clear_errors(); libxml_use_internal_errors($previous); }
}

function glpichat_desktop_message_output(array $actor, array $followup): array
{
    $author = trim((string) ($followup['firstname'] ?? '') . ' ' . (string) ($followup['realname'] ?? ''));
    if ($author === '') {
        $author = (string) ($followup['author_login'] ?? '');
    }
    return [
        'id' => (int) $followup['id'],
        'author_id' => (int) $followup['users_id'],
        'author_name' => $author !== '' ? glpichat_desktop_text($author, 150) : 'Usuário GLPI',
        'content' => glpichat_desktop_text((string) $followup['content']),
        'created_at' => (string) $followup['date'],
        'own' => (int) $followup['users_id'] === (int) $actor['user_id'],
        'is_unread' => (int) $followup['users_id'] !== (int) $actor['user_id'] && !empty($followup['is_unread']),
        'client_message_id' => isset($followup['client_message_id']) ? (string) $followup['client_message_id'] : null,
        'attachments' => $followup['attachments'] ?? [],
        'links' => glpichat_desktop_message_links((string) $followup['content']),
    ];
}

function glpichat_desktop_followup_select(int $actorUserId = 0): string
{
    // Avoid transferring unbounded native HTML from the database to PHP.
    return 'SELECT f.id, f.items_id, f.users_id, f.date, '
        . "CASE WHEN OCTET_LENGTH(f.content) <= 262144 THEN f.content ELSE '' END AS content, "
        . 'u.name AS author_login, u.firstname, u.realname, '
        . ($actorUserId > 0 ? glpichat_desktop_message_uuid_select($actorUserId) : 'NULL AS client_message_id')
        . ($actorUserId > 0 ? ", (f.users_id <> $actorUserId AND NOT EXISTS (SELECT 1 FROM glpi_plugin_glpichat_desktopreads mr WHERE mr.users_id=$actorUserId AND mr.itilfollowups_id=f.id)) AS is_unread" : ', 0 AS is_unread')
        . ' FROM glpi_itilfollowups f '
        . 'LEFT JOIN glpi_users u ON u.id = f.users_id ';
}

/** Exact incoming unread total for an already authorized ticket. Unlike the
 * history window, this aggregate includes unread messages outside the page;
 * it transfers one scalar and no message bodies. */
function glpichat_desktop_history_unread_count(array $actor, int $ticketId): int
{
    $userId = (int) $actor['user_id'];
    $rows = glpichat_desktop_db_rows('SELECT COUNT(*) AS unread_count FROM glpi_itilfollowups f '
        . "WHERE f.items_id = $ticketId AND " . glpichat_desktop_public_followup_predicate()
        . " AND f.users_id <> $userId AND NOT EXISTS (SELECT 1 FROM glpi_plugin_glpichat_desktopreads hr WHERE hr.users_id=$userId AND hr.itilfollowups_id=f.id)");
    return (int) $rows[0]['unread_count'];
}

function glpichat_desktop_history(array $actor, int $ticketId, int $before, int $limit): array
{
    // Authentication was performed for this request by the controller. The
    // ticket/requester lookup below still checks the current conversation.
    $ticket = glpichat_desktop_ticket($actor, $ticketId);
    $limit = max(1, min(50, $limit));
    $rows = glpichat_desktop_db_rows(glpichat_desktop_followup_select((int) $actor['user_id'])
        . "WHERE f.items_id = $ticketId AND " . glpichat_desktop_public_followup_predicate()
        . ($before > 0 ? " AND f.id < $before" : '')
        . ' ORDER BY f.id DESC LIMIT ' . ($limit + 1));
    $hasMore = count($rows) > $limit;
    $rows = array_slice($rows, 0, $limit);
    $oldest = $rows ? (int) $rows[count($rows) - 1]['id'] : 0;
    $newest = $rows ? (int) $rows[0]['id'] : 0;
    $hasNewer = $before > 0 && $newest > 0 && glpichat_desktop_db_rows('SELECT f.id FROM glpi_itilfollowups f '
        . "WHERE f.items_id = $ticketId AND " . glpichat_desktop_public_followup_predicate()
        . " AND f.id > $newest ORDER BY f.id ASC LIMIT 1") !== [];
    require_once __DIR__ . '/attachments.php';
    $attachments = glpichat_desktop_message_attachments($actor, $ticketId, array_column($rows, 'id'));
    foreach ($rows as &$row) {
        $row['attachments'] = $attachments[(int) $row['id']] ?? [];
    }
    unset($row);
    return [
        'ticket' => glpichat_desktop_ticket_output($actor, $ticket),
        'unread_count' => glpichat_desktop_history_unread_count($actor, $ticketId),
        'messages' => array_map(static fn(array $row): array => glpichat_desktop_message_output($actor, $row), array_reverse($rows)),
        'next_before' => $hasMore ? $oldest : 0,
        'has_more' => $hasMore,
        'next_after' => $hasNewer ? $newest : 0,
        'has_newer' => $hasNewer,
    ];
}

/** First-unread/forward navigation, without acknowledging unseen messages.
 * Oldest unread is selected with an indexed exact ticket walk; every payload
 * page has at most 50 messages and one batched attachment lookup. */
function glpichat_desktop_history_window(array $actor, int $ticketId, int $after, bool $unread, int $limit): array
{
    $ticket = glpichat_desktop_ticket($actor, $ticketId);
    $userId = (int) $actor['user_id'];
    $limit = max(1, min(50, $limit));
    $where = "WHERE f.items_id = $ticketId AND " . glpichat_desktop_public_followup_predicate();
    if ($unread) {
        $first = glpichat_desktop_db_rows('SELECT f.id FROM glpi_itilfollowups f ' . $where
            . " AND f.users_id <> $userId AND NOT EXISTS (SELECT 1 FROM glpi_plugin_glpichat_desktopreads ur WHERE ur.users_id=$userId AND ur.itilfollowups_id=f.id) ORDER BY f.id ASC LIMIT 1");
        if (!$first) { return glpichat_desktop_history($actor, $ticketId, 0, $limit); }
        $range = ' AND f.id >= ' . (int) $first[0]['id'];
    } else {
        $range = ' AND f.id > ' . max(0, $after);
    }
    $rows = glpichat_desktop_db_rows(glpichat_desktop_followup_select($userId) . $where . $range . ' ORDER BY f.id ASC LIMIT ' . ($limit + 1));
    $hasNewer = count($rows) > $limit;
    $rows = array_slice($rows, 0, $limit);
    // A message may disappear between summary and navigation; return the latest
    // currently authorized page, never an empty permanent navigation trap.
    if (!$rows) { return glpichat_desktop_history($actor, $ticketId, 0, $limit); }
    $oldest = (int) $rows[0]['id'];
    $hasOlder = glpichat_desktop_db_rows('SELECT f.id FROM glpi_itilfollowups f ' . $where . ' AND f.id < ' . $oldest . ' ORDER BY f.id DESC LIMIT 1') !== [];
    require_once __DIR__ . '/attachments.php';
    $attachments = glpichat_desktop_message_attachments($actor, $ticketId, array_column($rows, 'id'));
    foreach ($rows as &$row) { $row['attachments'] = $attachments[(int) $row['id']] ?? []; }
    unset($row);
    return ['ticket' => glpichat_desktop_ticket_output($actor, $ticket),
        'unread_count' => glpichat_desktop_history_unread_count($actor, $ticketId),
        'messages' => array_map(static fn(array $row): array => glpichat_desktop_message_output($actor, $row), $rows),
        'next_before' => $hasOlder ? $oldest : 0, 'has_more' => $hasOlder,
        'next_after' => $hasNewer ? (int) $rows[count($rows) - 1]['id'] : 0, 'has_newer' => $hasNewer];
}

function glpichat_desktop_payload_hash(int $ticketId, string $content): string
{
    $key = (string) glpichat_desktop_config('desktop_idempotency_key');
    if (preg_match('/^[0-9a-f]{64}$/D', $key) !== 1) {
        glpichat_desktop_fail('desktop_unavailable', 'Execute a atualização do plugin antes de enviar.', 503);
    }
    return hash_hmac('sha256', "glpichat-desktop-send-v1\0" . $ticketId . "\0" . $content, hex2bin($key));
}

/** Resolve a usable followup source through GLPI's existing dropdown APIs. */
function glpichat_desktop_requesttype_id(): int
{
    $requestType = new RequestType();
    // Respect the database's normal name matching and accept the first suitable
    // row. Duplicate display labels are not ambiguous identities or credentials.
    $matches = $requestType->find([
        'name' => 'GLPI Chat', 'is_active' => 1, 'is_itilfollowup' => 1,
    ], ['id'], 1);
    $row = $matches ? reset($matches) : [];
    if (!$row) {
        // An administrator may rename the catalog entry. GLPI's configured
        // followup source remains usable; do not create catalog rows on send.
        $defaultId = (int) RequestType::getDefault('followup');
        $row = $defaultId > 0 && $requestType->getFromDB($defaultId) ? $requestType->fields : [];
    }
    if ((int) ($row['id'] ?? 0) <= 0 || (int) ($row['is_active'] ?? 0) !== 1
        || (int) ($row['is_itilfollowup'] ?? 0) !== 1) {
        glpichat_desktop_fail('request_type_unavailable', 'Configure uma origem ativa para acompanhamentos no GLPI.', 503);
    }
    return (int) $row['id'];
}

function glpichat_desktop_send(array $actor, int $ticketId, string $uuid, string $content): array
{
    global $DB;

    if ((string) glpichat_desktop_config('desktop_schema_version') !== '13') {
        glpichat_desktop_fail('schema_unavailable', 'Conclua a atualização do plugin antes de enviar mensagens.', 503);
    }

    $uuid = strtolower($uuid);
    if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/D', $uuid) !== 1) {
        glpichat_desktop_fail('invalid_message_id', 'Identificador de mensagem inválido.', 400);
    }
    $content = glpichat_desktop_normalize_message($content);
    $hash = glpichat_desktop_payload_hash($ticketId, $content);
    return glpichat_desktop_transaction(function () use ($actor, $ticketId, $uuid, $content, $hash): array {
        global $DB;
        $actor = glpichat_desktop_validate_actor($actor, true);
        glpichat_admission_message_lock((int) $actor['user_id']);
        $ticket = glpichat_desktop_ticket($actor, $ticketId, true);
        $userId = (int) $actor['user_id'];
        $uuidSql = glpichat_desktop_quote($uuid);
        $receipts = glpichat_desktop_db_rows('SELECT id, tickets_id, payload_hash, itilfollowups_id '
            . 'FROM glpi_plugin_glpichat_desktopsends '
            . "WHERE users_id = $userId AND client_message_id = $uuidSql FOR UPDATE");
        if ($receipts) {
            $receipt = $receipts[0];
            if ((int) $receipt['tickets_id'] !== $ticketId || !hash_equals((string) $receipt['payload_hash'], $hash)) {
                glpichat_desktop_fail('idempotency_conflict', 'Este identificador já pertence a outra mensagem.', 409);
            }
            $followupId = (int) $receipt['itilfollowups_id'];
            $rows = glpichat_desktop_db_rows(glpichat_desktop_followup_select()
                . "WHERE f.id = $followupId AND f.items_id = $ticketId AND "
                . glpichat_desktop_public_followup_predicate() . ' LIMIT 1 FOR UPDATE');
            if (!$rows || (int) $rows[0]['users_id'] !== $userId) {
                glpichat_desktop_fail('message_unavailable', 'A mensagem enviada não está mais disponível.', 409);
            }
            $currentContent = glpichat_desktop_text((string) $rows[0]['content']);
            if (!hash_equals($hash, glpichat_desktop_payload_hash($ticketId, $currentContent))) {
                glpichat_desktop_fail('message_changed', 'A mensagem já foi enviada e alterada no GLPI. Atualize a conversa.', 409);
            }
            return ['message' => glpichat_desktop_message_output($actor, $rows[0]), 'client_message_id' => $uuid];
        }
        if (empty($actor['can_create']) || !in_array((int) $ticket['status'], [1, 2, 3, 4], true)) {
            glpichat_desktop_fail('conversation_read_only', 'Esta conversa está disponível somente para leitura.', 403);
        }
        // Core addToMergedTickets can fan out a followup; this pilot never does.
        if (Ticket::getMergedTickets($ticketId) !== []) {
            glpichat_desktop_fail('conversation_merge_unsupported', 'Envie este acompanhamento pela interface do GLPI.', 409);
        }
        $now = glpichat_desktop_now();
        glpichat_admission_message($userId);
        $requestTypeId = glpichat_desktop_requesttype_id();
        if (!$DB->insert('glpi_plugin_glpichat_desktopsends', [
            'users_id' => $userId, 'client_message_id' => $uuid, 'tickets_id' => $ticketId,
            'payload_hash' => $hash, 'itilfollowups_id' => null, 'created_at' => $now,
        ])) {
            throw new RuntimeException('Desktop send receipt insert failed.');
        }
        $receiptId = (int) $DB->insertId();
        $followup = new ITILFollowup();
        // Use GLPI's real followup writer, explicit actor/time, escaped plain text.
        // No user/profile/entity is installed in $_SESSION. The native add
        // notification remains suppressed; the plugin event is durably queued.
        $nativeTime = date('Y-m-d H:i:s');
        $followupId = (int) $followup->add([
            'itemtype' => Ticket::class, 'items_id' => $ticketId, 'users_id' => $userId,
            'content' => str_replace("\n", '<br>', htmlspecialchars($content, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')),
            'is_private' => 0, 'requesttypes_id' => $requestTypeId,
            'date' => $nativeTime, 'date_creation' => $nativeTime, 'date_mod' => $nativeTime,
            '_disablenotif' => true, '_no_reopen' => true,
        ]);
        if ($followupId <= 0) {
            throw new RuntimeException('Native followup insert failed.');
        }
        // A desktop device is not a browser presence participant. participants_id
        // zero is supported by the original message writer; users_id is explicit.
        $messageId = glpichat_add_message($ticketId, 'public', 'user', $userId, 0, $content, 0, $followupId, false);
        $mirror = glpichat_desktop_db_rows('SELECT id FROM glpi_plugin_glpichat_messages '
            . "WHERE id = $messageId AND itilfollowups_id = $followupId AND tickets_id = $ticketId AND users_id = $userId");
        if ($messageId <= 0 || !$mirror) {
            throw new RuntimeException('Browser message insert failed.');
        }
        if (!$DB->update('glpi_plugin_glpichat_desktopsends', ['itilfollowups_id' => $followupId], ['id' => $receiptId])) {
            throw new RuntimeException('Desktop send receipt completion failed.');
        }
        $rows = glpichat_desktop_db_rows(glpichat_desktop_followup_select()
            . "WHERE f.id = $followupId AND f.items_id = $ticketId AND "
            . glpichat_desktop_public_followup_predicate() . ' LIMIT 1');
        if (!$rows || (int) $rows[0]['users_id'] !== $userId
            || !hash_equals($hash, glpichat_desktop_payload_hash($ticketId, glpichat_desktop_text((string) $rows[0]['content'])))) {
            throw new RuntimeException('Native followup verification failed.');
        }
        glpichat_queue_message_notifications($ticketId, 'public', 'user', $userId, $content, $messageId, $followupId);
        return ['message' => glpichat_desktop_message_output($actor, $rows[0]), 'client_message_id' => $uuid];
    });
}

function glpichat_desktop_read(array $actor, int $ticketId, array $messageIds): void
{
    if (count($messageIds) > 50) {
        glpichat_desktop_fail('invalid_message_ids', 'Informe no máximo 50 mensagens.', 400);
    }
    $ids = [];
    foreach ($messageIds as $id) {
        if (!is_int($id) || $id <= 0) {
            glpichat_desktop_fail('invalid_message_ids', 'Identificador de mensagem inválido.', 400);
        }
        $ids[$id] = $id;
    }
    glpichat_desktop_transaction(function () use ($actor, $ticketId, $ids): void {
        global $DB;
        $actor = glpichat_desktop_validate_actor($actor, true);
        glpichat_desktop_ticket($actor, $ticketId, true);
        if (!$ids) {
            return;
        }
        $userId = (int) $actor['user_id'];
        $rows = glpichat_desktop_db_rows('SELECT f.id FROM glpi_itilfollowups f '
            . "WHERE f.items_id = $ticketId AND f.id IN (" . implode(',', $ids) . ') AND '
            . glpichat_desktop_public_followup_predicate() . ' FOR UPDATE');
        // A forged/private/other-ticket ID yields no write, including partial sets.
        if (count($rows) !== count($ids)) {
            glpichat_desktop_fail('message_unavailable', 'Uma mensagem não está mais disponível. Atualize a conversa.', 404);
        }
        $now = glpichat_desktop_quote(glpichat_desktop_now());
        $values = [];
        foreach ($rows as $row) {
            $values[] = '(' . $userId . ',' . (int) $row['id'] . ',' . $now . ')';
        }
        $sql = 'INSERT INTO glpi_plugin_glpichat_desktopreads (users_id,itilfollowups_id,created_at) VALUES '
            . implode(',', $values) . ' ON DUPLICATE KEY UPDATE users_id = VALUES(users_id)';
        if (!$DB->doQuery($sql)) {
            throw new RuntimeException('Desktop read-state write failed.');
        }
        glpichat_desktop_sync_touch_user($userId);
    });
}
