# GLPI Chat — 1.9.10-desktop23

Plugin GLPI 11.x / PHP 8.2+ com desktop Windows 0.9.13. Candidato de preparação, schema desktop **13 aditivo**. Preserva identidades, credenciais, revogações, rascunhos e recuperação. Utilize versões corrigidas e qualificadas pela organização.

Atualize **sem desinstalar**. Conclua migração e verifique o gerenciamento antes do rollout Windows. Leia docs/INSTALLATION_PT-BR.md e docs/releases/1.9.10-desktop23.md. O ZIP runtime contém somente glpichat/; desktop release e admin são separados. Não inclua configuração de implantação, chaves ou credenciais nos pacotes.

A versão acrescenta validação canônica de SID, controles auditados de gerenciamento e vínculos, prévias de alvos fixos, limites/pausa de distribuição e console com quatro áreas e acompanhamento automático. Ações retornam por HTTP303 a uma consulta GET; atualizar a página não repete o POST. Permissão, contato recente, processamento, arquivos instalados e prontidão do Widget são apresentados separadamente.

Suspender gerenciamento não é quarentena integral de chat. Reativar uma máquina não libera usuários bloqueados nem revive trabalho pendente substituído. Liberar uma conexão permite nova autorização; credenciais antigas continuam revogadas.

Quem aguarda importação AD/GLPI continua tentando sem token manual ou limite total de tentativas. Usuários no mesmo PC e a mesma conta em PCs distintos mantêm conexões independentes. O chat do navegador permanece desabilitado por padrão.

A política de publisher é independente e protegida; não é habilitada automaticamente no piloto sem assinatura. Qualificação nativa Windows/GPO/AD, CA/TLS, capacidade, assinatura final1.0.0 e Kaspersky permanecem gates específicos, documentados no pacote completo.
