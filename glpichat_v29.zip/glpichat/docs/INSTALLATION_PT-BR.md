# GLPIChat 1.9.7-desktop20 / Windows 0.9.10

Versão corretiva sem assinatura após a atualização Windows 0.9.9 confirmada no piloto. A promoção para 1.0.0 exige validação nativa e assinatura dos bytes finais.

## Atualização do plugin

1. Faça backup do banco, da pasta atual do plugin e da chave protegida de assinatura do gerenciamento.
2. Substitua a pasta `glpichat` pelos arquivos de `glpichat-1.9.7-desktop20.zip` e execute a atualização normal no GLPI. Não desinstale: a desinstalação remove dados.
3. Guarde o backup fora da pasta de plugins; não mantenha cópias antigas renomeadas nesse diretório.
4. Confirme versão 1.9.6, build desktop19 e esquema Desktop 10. A migração é aditiva e preserva credenciais, revogações e identificadores existentes. Ela acrescenta prova canônica somente a vínculos legados cuja identidade ainda seja verificável. Preserve o fuso padrão do GLPI/servidor durante essa migração.
5. Na configuração Desktop, confirme **Estrutura desktop → Atualização registrada** e abra **Gerenciar versões e computadores Windows** com uma conta autorizada. Confirme autorização de um usuário existente antes de atribuir Windows 0.9.10. Não reduza o marcador de esquema para recuperar controles.

Uma migração incompleta mantém a autorização Desktop indisponível com `schema_unavailable`; corrija a causa e execute novamente a atualização do plugin. O marcador 10 só é concluído após a migração. Um vínculo legado já incompatível com a identidade/fuso conhecido não é associado a outra identidade por tentativa. Preserve os dados para análise administrativa.

## Escolher o caminho Windows

| Situação | Pacote e ação |
| --- | --- |
| Frota gerenciada saudável | Importe somente `GLPIChat-Desktop-0.9.10-release.zip` e atribua primeiro ao piloto 0.9.9. |
| Computador novo ou GPO | Use `GLPIChat-Desktop-0.9.10-admin.zip`, `Deploy-Desktop.cmd` na inicialização do computador/SYSTEM e o `deployment.json` automático protegido. |
| Recuperação administrativa necessária | Extraia somente o ZIP admin em pasta local nova e execute `desktop/tools/Repair-DesktopRecovery.cmd` em console administrativo. Preserve a evidência e a autoridade de recuperação existente. |

O Bootstrap está incorporado no Agent do ZIP gerenciado. Não importe admin ou fontes como release, não misture os ZIPs e não substitua bytes mantendo uma versão antiga. O ZIP completo contém fontes e testes para a estação de qualificação. As instruções de GPO, aceitação e os resultados executados acompanham o admin e o completo.

## Conexão automática

Configure centralmente LDAP, sincronização de usuários, perfis, entidades e direitos de chat. A conta AD precisa existir e estar autorizada no GLPI. O usuário final não precisa visitar previamente o GLPI, fornecer senha/token, parear uma conta ou executar comandos. Contas locais ou somente Entra não estão cobertas pelo fluxo automático AD.

Cada computador possui registro próprio. O serviço verifica o usuário real da sessão Windows; usuários diferentes no mesmo computador mantêm credenciais e trabalho separados, e o mesmo usuário pode usar computadores diferentes simultaneamente. Não clone estado já registrado em imagens de máquinas. Valide esses cenários no ambiente antes de ampliar o lote.

Restrinja o segredo de registro às contas dos computadores alvo e aos administradores, com escrita somente administrativa. Renove centralmente a exportação antes do vencimento ou esgotamento de novas máquinas. Isso é manutenção administrativa, sem participação do usuário final. A revogação permanece válida até liberação administrativa explícita.

## Diagnóstico e aceitação

Confira separadamente Bootstrap, payload, broker e Widget carregados, registro da máquina e conexão de usuários novos. Serviço em execução não comprova círculo visível ou autorização de outra conta. Os novos diagnósticos mostram inicialização sem prontidão, heartbeat vencido ou perda de prontidão sem matar automaticamente o Widget.

O renderizador funcional da versão 0.9.9 permanece. O círculo deve aparecer antes de clicar na bandeja, inclusive sem mensagens não lidas. Valide logon/reinício, notificações e mensagens recebidas offline, navegação para a mensagem mais recente, anexos, rascunhos e filas preservadas. Recuperação de texto legado retido exige revisão explícita em Envios e não inicia envio automático.

Use `Get-DesktopStatus.ps1` e `Test-LiveUpdate.ps1` do pacote admin em PowerShell administrativo. Não é necessário console de usuário comum. Não distribua tokens, configuração ou estado privado bruto. Veja `releases/1.9.7-desktop20.md` e a matriz Windows 0.9.10. Testes portáteis e SQL descartável não certificam Windows, AD, política de assinatura ou liberação pelo Kaspersky.

O utilitário `bin/audit-private-attachments.php` permanece somente leitura para uso administrativo antes de reconciliação manual. O ZIP do plugin contém execução e documentação operacional; executáveis Windows, testes e evidência ficam em seus pacotes separados.
