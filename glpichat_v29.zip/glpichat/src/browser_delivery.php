<?php

declare(strict_types=1);

require_once __DIR__ . '/desktop/common.php';
require_once __DIR__ . '/desktop/conversations.php';
require_once __DIR__ . '/desktop/attachments.php';
require_once __DIR__ . '/flows/message_flow.php';

// Fresh browser text must fit the native text reader before and after escaping.
// Keep this byte ceiling aligned with glpichat_desktop_text().
const GLPICHAT_BROWSER_TEXT_MAX_BYTES = 262144;

/** Receipt identity is independent of the desktop feature switch. */
function glpichat_browser_delivery_ready(): bool
{
    return in_array((string) Config::getConfigurationValue('plugin:glpichat', 'desktop_schema_version'), ['5', '6', '7', '8', '9', '10'], true);
}

/** Bind a captured browser draft to its account despite a cross-tab login switch. */
function glpichat_browser_assert_expected_user(int $expectedUserId): void
{
    if ($expectedUserId <= 0 || $expectedUserId !== glpichat_current_user_id()) {
        glpichat_desktop_fail('account_context_changed', 'A conta conectada mudou. Reabra a conversa antes de enviar este rascunho.', 409);
    }
}

function glpichat_browser_message_uuid(string $uuid): string
{
    if ($uuid === '') {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 15) | 64);
        $bytes[8] = chr((ord($bytes[8]) & 63) | 128);
        $hex = bin2hex($bytes);
        $uuid = substr($hex, 0, 8) . '-' . substr($hex, 8, 4) . '-' . substr($hex, 12, 4)
            . '-' . substr($hex, 16, 4) . '-' . substr($hex, 20);
    }
    $uuid = strtolower($uuid);
    if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/D', $uuid) !== 1) {
        glpichat_desktop_fail('invalid_message_id', 'Identificador de mensagem inválido.', 400);
    }
    return $uuid;
}

/** A receipt read needs current room access, not permission to create another message. */
function glpichat_browser_assert_can_read(int $ticketId, string $roomType): void
{
    $ticket = new Ticket();
    if (!$ticket->getFromDB($ticketId)) {
        glpichat_desktop_fail('not_found', 'Chamado não encontrado.', 404);
    }
    $cache = &glpichat_ticket_or_fail_cache();
    $cache[$ticketId] = $ticket;
    if (!glpichat_can_read_room($ticketId, $roomType)) {
        glpichat_desktop_fail('authorization_denied', 'Você não tem permissão para acessar este chat.', 403);
    }
}

/** Refresh the core object before evaluating the existing browser policy. */
function glpichat_browser_assert_can_send(int $ticketId, string $roomType): void
{
    $ticket = new Ticket();
    if (!$ticket->getFromDB($ticketId)) {
        glpichat_desktop_fail('not_found', 'Chamado não encontrado.', 404);
    }
    $cache = &glpichat_ticket_or_fail_cache();
    $cache[$ticketId] = $ticket;
    if (glpichat_is_ticket_terminal_for_chat($ticketId)) {
        glpichat_desktop_fail('conversation_read_only', 'O chat está arquivado para este chamado.', 403);
    }
    if (!glpichat_can_send($ticketId, $roomType)) {
        glpichat_desktop_fail('authorization_denied', 'Você não tem permissão para enviar mensagens neste chat.', 403);
    }
}

/**
 * Store native followup, browser mirror, receipt and deferred events together.
 * A nonblocking per-user/per-token lock avoids a second writer waiting behind
 * an already running send. The unique table key remains the persistent guard.
 */
function glpichat_browser_send(int $ticketId, string $roomType, string $content, string $uuid = ''): array
{
    global $DB;
    $content = trim($content);
    if ($ticketId <= 0 || $content === '' || !glpichat_is_valid_room_type($roomType) || preg_match('//u', $content) !== 1) {
        glpichat_desktop_fail('invalid_content', 'Parâmetros de mensagem inválidos.', 400);
    }
    $uuid = glpichat_browser_message_uuid($uuid);
    $userId = glpichat_current_user_id();
    glpichat_browser_assert_can_read($ticketId, $roomType);
    if (!glpichat_browser_delivery_ready()) {
        glpichat_desktop_fail('schema_unavailable', 'Conclua a atualização do plugin antes de enviar mensagens.', 503);
    }
    $hash = hash('sha256', json_encode([$ticketId, $roomType, $content], JSON_THROW_ON_ERROR));
    $lock = glpichat_desktop_quote('glpichat-send-' . substr(hash('sha256', $userId . ':' . $uuid), 0, 48));
    $locked = glpichat_desktop_db_rows("SELECT GET_LOCK($lock, 0) AS acquired");
    if ((int) ($locked[0]['acquired'] ?? 0) !== 1) {
        glpichat_desktop_fail('send_busy', 'O envio desta mensagem ainda está em andamento.', 503);
    }
    try {
        return glpichat_desktop_transaction(function () use ($ticketId, $roomType, $content, $uuid, $userId, $hash): array {
            global $DB;
            // Core parent writes also lock the ticket. Taking it before ACL and
            // receipts keeps the source stable through persistence.
            $ticket = glpichat_desktop_db_rows("SELECT id FROM glpi_tickets WHERE id = $ticketId FOR UPDATE");
            if (!$ticket) {
                glpichat_desktop_fail('not_found', 'Chamado não encontrado.', 404);
            }
            glpichat_browser_assert_can_read($ticketId, $roomType);
            $uuidSql = glpichat_desktop_quote($uuid);
            $receipts = glpichat_desktop_db_rows('SELECT * FROM glpi_plugin_glpichat_browsersends '
                . "WHERE users_id = $userId AND client_message_id = $uuidSql FOR UPDATE");
            if ($receipts) {
                $receipt = $receipts[0];
                if ((int) $receipt['tickets_id'] !== $ticketId || $receipt['room_type'] !== $roomType
                    || !hash_equals((string) $receipt['payload_hash'], $hash)) {
                    glpichat_desktop_fail('idempotency_conflict', 'Este identificador já pertence a outra mensagem.', 409);
                }
                $messageId = (int) $receipt['messages_id'];
                $message = glpichat_browser_receipt_message($receipt, $ticketId, $roomType, $userId, $content, $uuid);
                return ['message_id' => $messageId, 'message' => $message, 'client_message_id' => $uuid];
            }
            glpichat_browser_assert_can_send($ticketId, $roomType);
            // Check only fresh sends: older committed receipts must retain their
            // existing replay contract. Validate before receipt/source/job writes.
            $tooLarge = 'A mensagem é muito longa. Reduza o texto ou envie-o como anexo.';
            $sizeLimits = ['max_text_bytes' => GLPICHAT_BROWSER_TEXT_MAX_BYTES,
                'max_native_bytes' => GLPICHAT_BROWSER_TEXT_MAX_BYTES];
            if (strlen($content) > GLPICHAT_BROWSER_TEXT_MAX_BYTES) {
                glpichat_desktop_fail('content_too_large', $tooLarge, 400, $sizeLimits);
            }
            // The composer submits plain text; only the native rich-text
            // boundary receives HTML. Keep the mirror and receipt hash plain.
            $nativeContent = str_replace(["\r\n", "\r"], "\n", $content);
            $nativeContent = str_replace("\n", '<br>', htmlspecialchars($nativeContent, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));
            if (strlen($nativeContent) > GLPICHAT_BROWSER_TEXT_MAX_BYTES) {
                glpichat_desktop_fail('content_too_large', $tooLarge, 400, $sizeLimits);
            }
            if (!$DB->insert('glpi_plugin_glpichat_browsersends', [
                'users_id' => $userId, 'client_message_id' => $uuid, 'tickets_id' => $ticketId,
                'room_type' => $roomType, 'payload_hash' => $hash, 'messages_id' => null,
                'itilfollowups_id' => null, 'created_at' => gmdate('Y-m-d H:i:s'),
            ])) {
                throw new RuntimeException('Browser send receipt insert failed.');
            }
            $receiptId = (int) $DB->insertId();
            $roomId = glpichat_room_id($ticketId, $roomType);
            $participantId = glpichat_participant_id_for_user($roomId, $userId, true, true);
            $followupId = glpichat_add_followup($ticketId, $userId, $nativeContent, glpichat_is_private_room_type($roomType), true);
            $messageId = glpichat_add_message($ticketId, $roomType, 'user', $userId, $participantId, $content, 0, $followupId, false);
            if ($messageId <= 0 || !$DB->update('glpi_plugin_glpichat_browsersends', [
                'messages_id' => $messageId, 'itilfollowups_id' => $followupId,
            ], ['id' => $receiptId])) {
                throw new RuntimeException('Browser send receipt completion failed.');
            }
            glpichat_queue_message_notifications($ticketId, $roomType, 'user', $userId, $content, $messageId, $followupId);
            // Build the response before commit: a rendering/readback error must
            // not turn an acknowledged database write into an ambiguous retry.
            $message = glpichat_browser_receipt_message(['messages_id' => $messageId, 'itilfollowups_id' => $followupId],
                $ticketId, $roomType, $userId, $content, $uuid, false);
            return ['message_id' => $messageId, 'message' => $message, 'client_message_id' => $uuid];
        });
    } finally {
        try {
            glpichat_desktop_db_rows("SELECT RELEASE_LOCK($lock) AS released");
        } catch (Throwable $ignored) {
            // Connection disposal releases named locks. Do not replace a
            // committed send result with a cleanup failure.
            error_log('glpichat send: receipt lock cleanup failed.');
        }
    }
}

/**
 * Browser attachments use the same native storage policy as desktop uploads,
 * but retain the authenticated browser's existing public/internal permissions.
 * Commit the document, followup, mirror and notification intents together.
 * The same stable per-user receipt contract covers text and files. Domain
 * separation rejects reuse of a text token for a file or different file bytes.
 */
function glpichat_browser_upload(int $ticketId, string $roomType, mixed $file, string $uuid = ''): array
{
    if ($ticketId <= 0 || !glpichat_is_valid_room_type($roomType)) {
        glpichat_desktop_fail('invalid_request', 'Parâmetros de upload inválidos.', 400);
    }
    glpichat_browser_assert_can_read($ticketId, $roomType);
    if (!glpichat_browser_delivery_ready()) {
        glpichat_desktop_fail('schema_unavailable', 'Conclua a atualização do plugin antes de enviar anexos.', 503);
    }
    $uuid = glpichat_browser_message_uuid($uuid);
    $input = glpichat_desktop_attachment_input($file);
    $userId = glpichat_current_user_id();
    $hash = hash('sha256', json_encode(['attachment-v1', $ticketId, $roomType, $input], JSON_THROW_ON_ERROR));
    $lock = glpichat_desktop_quote('glpichat-send-' . substr(hash('sha256', $userId . ':' . $uuid), 0, 48));
    $locked = glpichat_desktop_db_rows("SELECT GET_LOCK($lock, 0) AS acquired");
    if ((int) ($locked[0]['acquired'] ?? 0) !== 1) {
        glpichat_desktop_fail('send_busy', 'O envio deste anexo ainda está em andamento.', 503);
    }
    try {
      return glpichat_desktop_transaction(static function () use ($ticketId, $roomType, $file, $input, $userId, $uuid, $hash): array {
        global $DB;
        $rows = glpichat_desktop_db_rows("SELECT id, entities_id FROM glpi_tickets WHERE id = $ticketId FOR UPDATE");
        if (!$rows) {
            glpichat_desktop_fail('not_found', 'Chamado não encontrado.', 404);
        }
        glpichat_browser_assert_can_read($ticketId, $roomType);
        $content = glpichat_attachment_message_content($input['name'], 'GLPI Chat');
        $receipts = glpichat_desktop_db_rows('SELECT * FROM glpi_plugin_glpichat_browsersends '
            . 'WHERE users_id = ' . $userId . ' AND client_message_id = ' . glpichat_desktop_quote($uuid) . ' FOR UPDATE');
        if ($receipts) {
            $receipt = $receipts[0];
            if ((int) $receipt['tickets_id'] !== $ticketId || $receipt['room_type'] !== $roomType
                || !hash_equals((string) $receipt['payload_hash'], $hash)) {
                glpichat_desktop_fail('idempotency_conflict', 'Este identificador já pertence a outra mensagem ou arquivo.', 409);
            }
            $message = glpichat_browser_receipt_message($receipt, $ticketId, $roomType, $userId, $content, $uuid);
            $documentId = (int) ($message['documents_id'] ?? 0);
            if ($documentId <= 0) {
                glpichat_desktop_fail('message_unavailable', 'O anexo enviado não está mais disponível.', 409,
                    ['committed' => true, 'message_id' => (int) $receipt['messages_id'], 'client_message_id' => $uuid]);
            }
            return ['message_id' => (int) $receipt['messages_id'], 'documents_id' => $documentId,
                'message' => $message, 'client_message_id' => $uuid];
        }
        glpichat_browser_assert_can_send($ticketId, $roomType);
        // Core propagates followup text from a deleted merged source. Its copied
        // followup IDs are not this upload's attachment authority; ask for the
        // actual destination rather than leave copied text without its file.
        if (Ticket::getMergedTickets($ticketId) !== []) {
            glpichat_desktop_fail('conversation_merge_unsupported', 'Este chamado foi mesclado. Envie o anexo no chamado de destino.', 409);
        }
        if (!$DB->insert('glpi_plugin_glpichat_browsersends', [
            'users_id' => $userId, 'client_message_id' => $uuid, 'tickets_id' => $ticketId,
            'room_type' => $roomType, 'payload_hash' => $hash, 'messages_id' => null,
            'itilfollowups_id' => null, 'created_at' => gmdate('Y-m-d H:i:s'),
        ])) { throw new RuntimeException('Browser attachment receipt insert failed.'); }
        $receiptId = (int) $DB->insertId();
        $roomId = glpichat_room_id($ticketId, $roomType);
        $participantId = glpichat_participant_id_for_user($roomId, $userId, true, true);
        $private = glpichat_is_private_room_type($roomType);
        $followupId = glpichat_add_followup($ticketId, $userId,
            htmlspecialchars($content, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'), $private, true);
        $documentId = glpichat_desktop_store_attachment(
            ['user_id' => $userId, 'entity_id' => (int) $rows[0]['entities_id']],
            $ticketId, $followupId, $file, $input
        );
        // Files are linked only to their native followup. A direct Ticket
        // association would bypass privacy if this followup becomes private.
        $messageId = glpichat_add_message($ticketId, $roomType, 'user', $userId, $participantId,
            $content, $documentId, $followupId, false);
        if ($messageId <= 0) {
            throw new RuntimeException('Browser upload mirror creation failed.');
        }
        glpichat_queue_message_notifications($ticketId, $roomType, 'user', $userId, $content, $messageId, $followupId);
        if (!$DB->update('glpi_plugin_glpichat_browsersends', [
            'messages_id' => $messageId, 'itilfollowups_id' => $followupId,
        ], ['id' => $receiptId])) { throw new RuntimeException('Browser attachment receipt completion failed.'); }
        $message = glpichat_message_by_id($messageId);
        $message['client_message_id'] = $uuid;
        return ['message_id' => $messageId, 'documents_id' => $documentId,
            'message' => $message, 'client_message_id' => $uuid];
      });
    } finally {
        try { glpichat_desktop_db_rows("SELECT RELEASE_LOCK($lock) AS released"); }
        catch (Throwable $ignored) { error_log('glpichat upload: receipt lock cleanup failed.'); }
    }
}

/** Replays remain bound to the current native source, author and room privacy. */
function glpichat_browser_receipt_message(array $receipt, int $ticketId, string $roomType, int $userId, string $content, string $uuid, bool $committed = true): array
{
    $messageId = (int) $receipt['messages_id'];
    $followupId = (int) $receipt['itilfollowups_id'];
    $private = glpichat_is_private_room_type($roomType) ? 1 : 0;
    $rooms = glpichat_desktop_quote($roomType);
    $rows = glpichat_desktop_db_rows('SELECT m.id, m.content, f.content AS native_content FROM glpi_plugin_glpichat_messages m '
        . 'INNER JOIN glpi_itilfollowups f ON f.id = m.itilfollowups_id '
        . 'INNER JOIN glpi_plugin_glpichat_rooms r ON r.id = m.rooms_id '
        . "WHERE m.id = $messageId AND m.itilfollowups_id = $followupId AND m.tickets_id = $ticketId "
        . "AND m.users_id = $userId AND m.participant_type = 'user' AND r.room_type = $rooms AND r.tickets_id = $ticketId "
        . "AND f.itemtype = 'Ticket' AND f.items_id = $ticketId AND f.users_id = $userId AND f.is_private = $private FOR UPDATE");
    $nativeContent = (string) ($rows[0]['native_content'] ?? '');
    // Submitted text is never HTML: stripping tags/entities from it would
    // falsely acknowledge a native edit that removed literal <placeholders>.
    $plainContent = str_replace(["\r\n", "\r"], "\n", $content);
    $plainContent = trim(preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F\x{202A}-\x{202E}\x{2066}-\x{2069}]/u', '', $plainContent) ?? '');
    $sameNative = hash_equals($content, $nativeContent)
        || (strlen($content) <= GLPICHAT_BROWSER_TEXT_MAX_BYTES && strlen($nativeContent) <= GLPICHAT_BROWSER_TEXT_MAX_BYTES
            && preg_match('//u', $nativeContent) === 1
            && hash_equals($plainContent, glpichat_desktop_text($nativeContent, GLPICHAT_BROWSER_TEXT_MAX_BYTES)));
    if (!$rows || !hash_equals($content, (string) $rows[0]['content']) || !$sameNative) {
        if (!$committed) { throw new RuntimeException('New browser send readback did not match its source.'); }
        glpichat_desktop_fail('message_unavailable', 'A mensagem enviada foi alterada ou não está mais disponível.', 409,
            ['committed' => true, 'message_id' => $messageId, 'client_message_id' => $uuid]);
    }
    $message = glpichat_message_by_id($messageId);
    $message['client_message_id'] = $uuid;
    return $message;
}

/** Add exact receipt tokens only to already-authorized message rows. */
function glpichat_browser_attach_receipts(array $rows): array
{
    global $DB;
    $userId = (int) Session::getLoginUserID();
    if ($rows === [] || $userId <= 0 || !glpichat_browser_delivery_ready()) {
        return $rows;
    }
    $ids = array_values(array_filter(array_map(static fn(array $row): int => (int) ($row['id'] ?? 0), $rows)));
    if (!$ids) {
        return $rows;
    }
    $tokens = [];
    foreach (glpichat_desktop_db_rows('SELECT b.messages_id, b.users_id, b.tickets_id, b.client_message_id, r.id AS rooms_id '
        . 'FROM glpi_plugin_glpichat_browsersends b INNER JOIN glpi_plugin_glpichat_rooms r '
        . 'ON r.tickets_id = b.tickets_id AND r.room_type = b.room_type '
        . 'WHERE b.users_id = ' . $userId . ' AND b.messages_id IN (' . implode(',', $ids) . ')') as $receipt) {
        $tokens[(int) $receipt['messages_id']] = $receipt;
    }
    foreach ($rows as &$row) {
        $receipt = $tokens[(int) ($row['id'] ?? 0)] ?? null;
        if ($receipt && (int) $receipt['users_id'] === (int) ($row['users_id'] ?? 0)
            && (int) $receipt['tickets_id'] === (int) ($row['tickets_id'] ?? 0)
            && (int) $receipt['rooms_id'] === (int) ($row['rooms_id'] ?? 0)
            && ($row['participant_type'] ?? null) === 'user') {
            $row['client_message_id'] = (string) $receipt['client_message_id'];
        }
    }
    unset($row);
    return $rows;
}
