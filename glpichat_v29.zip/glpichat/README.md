# GLPI Chat —1.9.7-desktop20

Plugin GLPI 11.0.7+ / PHP 8.2+ com desktop Windows 0.9.10. Versão corretiva, schema desktop 10 aditivo, preservando subjects/credenciais e rascunhos.

Atualize sem desinstalar e conclua a migração antes do rollout Windows. Leia docs/INSTALLATION_PT-BR.md e docs/releases/1.9.7-desktop20.md. O ZIP de runtime contém somente glpichat/; desktop release e admin são entregues separadamente. Não distribua configuração de implantação/chaves/credenciais em pacotes.

A integração automática exige usuários AD já importados e autorizados no GLPI. Novos usuários não precisam de login prévio no navegador quando a sincronização central está preparada. A superfície de chat do navegador permanece desabilitada por padrão. Assinatura Windows 1.0.0 e aceitação Kaspersky são etapas posteriores.
