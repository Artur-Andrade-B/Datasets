# Relatórios G4F

Plugin GLPI API-first para gerar rascunhos de relatórios com múltiplos contextos, revisão manual e exportação DOCX.

## Principais pontos

- A extração de dados de relatório é feita pela API REST do GLPI.
- Não cria tabelas de negócio próprias.
- Não usa PHPWord, ZipArchive, bibliotecas JS externas ou CDN.
- Composer é opcional: o plugin inclui autoload interno em `inc/autoload.php`.
- `vendor/autoload.php` é intencionalmente vazio, seguindo o padrão usado no GLPIBot.
- O menu em Ferramentas abre somente o gerador de relatório.
- A configuração administrativa fica em Configurar > Geral > Relatórios G4F.
- Chamadas de teste e extração usam endpoints em `front/`, não `ajax/`.
- CSS/JS das páginas são inseridos pelo PHP da própria página, evitando 404 de assets estáticos em instalações com public-root/proxy.

## Instalação

```bash
cd /var/www/html/glpi/plugins
rm -rf g4freports
unzip g4freports_v0.7.0_batch_explicit_groups.zip
chown -R www-data:www-data g4freports
```

Composer continua opcional:

```bash
cd /var/www/html/glpi/plugins/g4freports
composer install --no-dev --optimize-autoloader
chown -R www-data:www-data /var/www/html/glpi/plugins/g4freports
```

Depois:

1. Configurar > Plugins > Relatórios G4F > Instalar/Habilitar.
2. Configurar > Geral > Relatórios G4F.
3. Preencher o perfil padrão da API GLPI.
4. Usar o botão `Testar conexão padrão`.
5. Ferramentas > Relatórios G4F para gerar o relatório.

## Autenticação GLPI API

O perfil padrão aceita:

- App token + User token.
- Session token fixo.
- Tokens por variável de ambiente.

A URL aceita tanto `https://servidor/apirest.php` quanto `https://servidor`; o plugin normaliza para `/apirest.php`.

## Contextos do relatório

O usuário pode marcar múltiplos contextos ao mesmo tempo:

- Chamados atribuídos ao agente.
- Chamados solicitados pelo agente.
- Chamados atribuídos aos grupos selecionados explicitamente.
- Tarefas de chamado feitas pelo agente.
- Acompanhamentos feitos pelo agente.
- Soluções registradas pelo agente.
- Projetos gerenciados pelo agente.
- Projetos gerenciados pelos grupos selecionados explicitamente.
- Projetos em que o agente participa.
- Tarefas de projeto do agente.
- Tarefas de projeto dos grupos selecionados explicitamente.
- Entradas narrativas manuais.


## Alterações v0.5.1

- Os quatro modelos DOCX agora geram estruturas distintas: operacional, gerencial formal, técnico/projeto e anexo evidencial.
- A identidade visual do DOCX usa elementos editáveis do Word: cabeçalho, rodapé, tabelas, sombreamentos e faixas decorativas. O exportador não insere imagens de fundo no corpo do documento.
- Chamados e projetos priorizam a última atividade/comentário/tarefa registrada pelo agente no período antes de cair para descrição ou solução.
- Status numéricos de chamados são convertidos para nomes; status de projeto/tarefa de projeto tentam resolver ProjectState/ProjectTaskState via API.
- Grupos adicionais podem ser pesquisados por nome ou ID na tela de geração do relatório.

## Correções adicionais v0.5.1

- Geração de rascunho limitada por tempo e volume para evitar 504.
- O padrão da tela agora começa com contexto operacional seguro; grupos e projetos devem ser marcados quando forem necessários.
- Campo de limite de entradas adicionado à tela de geração.
- A sondagem ampla de todos os projetos atualizados no período foi removida.
- Leitura de subitens usa cache e não faz segunda tentativa expandida quando um subitem não existe.


## Alterações v0.7.0

- Contextos por grupo deixam de usar fallback automático para os grupos do agente. O plugin só consulta grupos que o usuário seleciona no campo de busca de grupos.
- A geração do rascunho passou a trabalhar em lotes pelo navegador: cada contexto é consultado em páginas pequenas, evitando que uma única chamada ao `front/api.php` fique presa até o nginx/PHP retornar 504.
- O campo de limite manual de entradas foi removido da tela operacional. O tamanho do lote é controlado pelo plugin, não pelo usuário final.
- A prévia editável exibe somente as primeiras entradas quando o volume é grande, mas o DOCX usa todas as entradas carregadas no rascunho.
- A busca de participação em projetos foi endurecida: para tipos como `ProjectTeam`, o plugin não usa IDs de campo chutados; ele só pesquisa quando a API expõe campos pesquisáveis seguros ou quando o admin define overrides.
- A leitura de subitens foi ampliada para melhorar a chance de capturar o comentário/tarefa/solução mais recente do agente, mantendo limite por lote.

## Alterações v0.7.0

- Exportação DOCX agora usa `resources/docx/papel_timbrado_G4F.docx` como base do pacote, preservando o papel timbrado/letterhead do Word, incluindo logo, grafismo inferior e rodapé visual.
- O conteúdo do relatório continua editável no Word; somente o fundo/identidade visual fica preservado no cabeçalho/plano de fundo do modelo.
- Removidas mensagens operacionais indevidas geradas por lotes sem retorno quando outros contextos já trouxeram entradas.
- Pesquisas diretas em TicketTask, ITILFollowup, ITILSolution, ProjectTask e ProjectTeam não usam mais IDs de campos presumidos. O plugin só usa campos expostos por searchOptions ou definidos por override administrativo, evitando erros HTTP 400 de “ID de campo inválido”.
- Falhas técnicas de search option deixam de aparecer como conteúdo do relatório; a tela de Diagnóstico continua sendo o local para investigar e configurar overrides.
- Mantida extração em lotes e uso explícito de grupos selecionados.
