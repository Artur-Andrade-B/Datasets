# GLPI Chat — 1.9.3-desktop16

Chat contextual dos chamados do GLPI, com cliente Windows 0.9.3 e conexão automática gerenciada pela empresa.

Esta versão acompanha a correção de inicialização do lançador flutuante Windows, que em 0.9.2 podia permanecer como uma linha de um pixel de altura. O código de execução do GLPI, a autorização e o esquema desktop 9 não mudam nesta correção; os metadados identificam o novo pacote correspondente.

O cliente permanece uma versão de homologação sem assinatura Authenticode. Windows 1.0.0 será a promoção assinada após validação no ambiente. A aceitação nativa Windows/DPI da correção ainda precisa ser executada. O problema separado de serialização do checkpoint agregado de notificações continua pendente.

Leia [a instalação](docs/INSTALLATION_PT-BR.md) e [as notas de desktop16](docs/releases/1.9.3-desktop16.md). Use o ZIP do plugin no GLPI e o ZIP Windows de release na área de gerenciamento de versões. Não importe o pacote administrativo ou de código-fonte como release Windows. Preserve estado, credenciais e versões anteriores; não desinstale para atualizar.
