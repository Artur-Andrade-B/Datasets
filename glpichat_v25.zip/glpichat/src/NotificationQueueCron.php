<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpichat;

use CronTask;

require_once __DIR__ . '/notification_queue.php';

final class NotificationQueueCron
{
    public static function cronInfo(string $name): array
    {
        return $name === 'DeliverChatNotifications'
            ? ['description' => __('Prepare queued GLPI Chat notifications without delaying chat messages.')]
            : [];
    }

    public static function cronDeliverChatNotifications(CronTask $task): int
    {
        $result = \glpichat_process_notification_jobs();
        $count = array_sum($result);
        $task->addVolume($count);
        $task->log(sprintf('Chat notifications: %d prepared, %d source no longer eligible, %d deferred after failure.',
            $result['delivered'], $result['suppressed'], $result['failed']));
        // Maintenance failure cannot undo already-committed notification work.
        $deleted = 0;
        try {
            $deleted = \glpichat_cleanup_notification_jobs();
            $metrics = \glpichat_notification_queue_metrics();
            $task->log(sprintf('Queue: %d pending, %d due, %d retrying, maximum %d attempts; oldest pending %s. Removed %d completed jobs older than 30 days.',
                $metrics['pending'], $metrics['due'], $metrics['retrying'], $metrics['max_attempts'],
                $metrics['oldest_pending_at'] ?? 'none', $deleted));
        } catch (\Throwable $error) {
            $task->log('Notification queue maintenance failed: ' . get_class($error));
        }
        $task->addVolume($deleted);
        return ($count + $deleted) > 0 ? 1 : 0;
    }
}
