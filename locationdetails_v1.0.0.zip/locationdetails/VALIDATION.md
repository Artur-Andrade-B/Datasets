# Validação da versão 1.0.0

Ambiente descartável: distribuição oficial **GLPI 11.0.7**, PHP **8.3.6** e
MariaDB **10.11**, com dados sintéticos. Nenhuma chamada foi feita ao GLPI do usuário
ou à integração externa. Credenciais e tokens das capturas não foram utilizados.

| Verificação | Resultado |
| --- | --- |
| Sintaxe de todos os arquivos PHP | Aprovada |
| Configuração, escape, campos vazios/zero, preservação e substituição de blocos | 21 verificações aprovadas |
| Middleware com classes reais do GLPI, serviços de dados isolados | 85 verificações aprovadas |
| Integração com banco e classes reais do GLPI | 45 verificações aprovadas |
| HTTP real, OAuth, API v2 e configuração autenticada | 16 verificações aprovadas |
| Instalação e ativação pela CLI nativa do GLPI | Aprovadas |
| Revisão independente do código | Nenhum defeito bloqueador identificado |

## Banco e núcleo GLPI

- Criação por `Ticket::add` nos quatro modos, com o hook registrado no plugin.
- Categorias incluídas/excluídas e opção de descendentes.
- Endereço e sala, coordenada zero, escape de conteúdo e acentos.
- Localização ausente, localização recursiva de entidade superior e bloqueio de
  localização de entidade não relacionada.
- API com dados atuais da localização sem alteração de `content` ou `date_mod` no banco.
- Um único bloco ao combinar os modos; retrato salvo preservado após leitura API.
- Sanitização nativa do GLPI preservando o marcador e a possibilidade de substituição.
- Configuração nativa com valores válidos e rejeição de entradas inválidas.
- Descarte de chaves arbitrárias, preservação de configuração nas atualizações.
- Renderização real do template Twig com os controles, destino e token nativos.
- Desinstalação preservando chamados e removendo somente a configuração própria.

## HTTP real

Um servidor PHP local executou o roteador e o fluxo de autenticação reais do GLPI.
Um cliente OAuth e uma senha temporários foram criados somente no banco descartável.

- Obtenção de token por `POST /api.php/token`.
- Consulta de coleção filtrada por `id`, com `start`, `limit` e `sort`, equivalente
  à estrutura exibida nas capturas da integração.
- Consulta de detalhe e coleção com múltiplos chamados.
- Conteúdo original e IDs preservados; apenas as categorias elegíveis enriquecidas.
- Rejeição de consulta não autenticada.
- Login web, redirecionamento da configuração, carregamento da aba pelo AJAX nativo.
- Gravação pelo formulário nativo; desativação observada na próxima consulta API.
- Rejeição de alteração de configuração sem token CSRF.

## Testes reproduzíveis incluídos

`block_test.php` é independente. `api_middleware_test.php` usa as dependências e
classes da instalação GLPI indicada no argumento, sem modificar seu banco.

`core_integration_test.php` cria e altera registros sintéticos e reinstala a
configuração do plugin. Ele exige execução CLI, autorização explícita pela variável
abaixo e um banco chamado exatamente `glpi_location_test`. Destina-se exclusivamente
a uma instalação descartável, com o plugin já instalado e ativo:

```bash
GLPI_LOCATIONDETAILS_TEST_ROOT=/caminho/para/glpi-descartavel \
GLPI_LOCATIONDETAILS_ALLOW_DESTRUCTIVE_TESTS=1 \
php tests/core_integration_test.php
```

## Limites

Os testes comprovam comportamento no GLPI 11.0.7 local; não representam uma medição
de desempenho da base de produção nem uma execução pelo software da empresa externa.
O pacote declara GLPI 11.0.7 ou superior na série 11.x e PHP 8.2 ou superior;
outras combinações devem passar pela validação de homologação descrita no README.

O enriquecimento durante leitura é específico dos GETs JSON de coleção/detalhe
de Ticket na API v2. Não cobre subrecursos, GraphQL ou enriquecimento virtual na API
legada. O modo de descrição atua na criação, sem migração automática de históricos.
