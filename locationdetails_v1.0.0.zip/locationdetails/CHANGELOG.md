# Histórico

## 1.0.0

- Configuração nativa com modos Desativado, Somente descrição, Somente API e Ambos.
- Seleção de categorias, subcategorias e atributos da localização.
- Enriquecimento durante criação, após regras e antes da inserção do chamado.
- Enriquecimento virtual do `content` nos GETs de coleção e detalhe da API v2.
- Formatação compartilhada, escape de valores e substituição de blocos identificados.
- Consultas em lote, respeito à entidade da localização e preservação do fluxo em falhas.
