<?php
declare(strict_types=1);

require_once __DIR__ . '/inc/autoload.php';

function plugin_locationdetails_install(): bool
{
    $context = \GlpiPlugin\Locationdetails\Settings::CONTEXT;
    $existing = \Config::getConfigurationValues($context);
    $defaults = \GlpiPlugin\Locationdetails\Settings::toStorage(
        \GlpiPlugin\Locationdetails\Settings::defaults()
    );
    $missing = array_diff_key($defaults, $existing);
    if ($missing !== []) {
        \Config::setConfigurationValues($context, $missing);
    }
    return true;
}

function plugin_locationdetails_uninstall(): bool
{
    // Never rewrite historical descriptions when disabling or uninstalling.
    (new \Config())->deleteByCriteria(['context' => \GlpiPlugin\Locationdetails\Settings::CONTEXT]);
    return true;
}
