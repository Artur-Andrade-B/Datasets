<?php
declare(strict_types=1);

namespace GlpiPlugin\Locationdetails;

final class Diagnostics
{
    public static function failure(string $context, \Throwable $error): void
    {
        // No ticket descriptions, location values, tokens or raw SQL in logs.
        try {
            \Toolbox::logInFile('locationdetails', sprintf(
                "[%s] %s failed (%s). Original GLPI operation preserved.\n",
                date('c'), $context, get_class($error)
            ));
        } catch (\Throwable) {
            // A logging problem must not prevent ticket creation/API reads.
        }
    }
}
