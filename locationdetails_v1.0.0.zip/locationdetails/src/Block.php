<?php
declare(strict_types=1);

namespace GlpiPlugin\Locationdetails;

final class Block
{
    // A class survives GLPI 11's native HTML sanitizer. Custom data-* attributes
    // and HTML comments do not, so they must not be used as the sole marker.
    public const MARKER = 'locationdetails-block-v1';

    public static function render(array $location, array $fields): string
    {
        $rows = '';
        foreach (Settings::fieldLabels() as $field => $label) {
            if (!in_array($field, $fields, true)) {
                continue;
            }
            $value = $location[$field] ?? null;
            if (!is_scalar($value) || trim((string) $value) === '') {
                continue;
            }
            $rows .= '<p><strong>' . self::escape($label) . ':</strong> '
                . nl2br(self::escape(trim((string) $value)), false) . '</p>';
        }
        if ($rows === '') {
            return '';
        }
        return '<div class="' . self::MARKER . '"><p><strong>Detalhes da localização</strong></p>'
            . $rows . '</div>';
    }

    public static function replace(string $content, string $block): string
    {
        $ranges = self::ranges($content);
        if ($ranges === []) {
            return $block === '' ? $content : $content . $block;
        }
        // Replace the first managed block in its original position, and remove
        // duplicate managed blocks. Bytes outside those blocks are preserved.
        for ($i = count($ranges) - 1; $i >= 0; --$i) {
            [$start, $length] = $ranges[$i];
            $content = substr_replace($content, $i === 0 ? $block : '', $start, $length);
        }
        return $content;
    }

    public static function remove(string $content): string
    {
        return self::replace($content, '');
    }

    private static function ranges(string $content): array
    {
        if (!str_contains($content, self::MARKER)) {
            return [];
        }
        preg_match_all('~</?div\b(?:[^>"\x27]|"[^"]*"|\x27[^\x27]*\x27)*>~i', $content, $tags, PREG_OFFSET_CAPTURE);
        $ranges = [];
        $start = null;
        $depth = 0;
        foreach ($tags[0] as [$tag, $offset]) {
            $closing = str_starts_with($tag, '</');
            if ($start === null) {
                if ($closing || !preg_match('~\bclass\s*=\s*(["\x27])(.*?)\1~is', $tag, $match)) {
                    continue;
                }
                $classes = preg_split('/\s+/', trim(html_entity_decode($match[2], ENT_QUOTES | ENT_HTML5, 'UTF-8')));
                if (!in_array(self::MARKER, $classes, true)) {
                    continue;
                }
                $start = $offset;
                $depth = 1;
                continue;
            }
            $depth += $closing ? -1 : 1;
            if ($depth === 0) {
                $ranges[] = [$start, $offset + strlen($tag) - $start];
                $start = null;
            }
        }
        // An incomplete/malformed marked block is left untouched, never guessed.
        return $ranges;
    }

    private static function escape(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5, 'UTF-8');
    }
}
