<?php
declare(strict_types=1);

namespace GlpiPlugin\Locationdetails;

final class Enricher
{
    private array $eligibleCategories;
    private array $locations = [];

    public function __construct(private array $config)
    {
        $this->eligibleCategories = array_fill_keys($config['category_ids'], true);
        if ($config['include_children']) {
            foreach ($config['category_ids'] as $id) {
                foreach (getSonsOf('glpi_itilcategories', $id) as $child) {
                    $this->eligibleCategories[(int) $child] = true;
                }
            }
        }
    }

    public static function beforeAdd(\CommonDBTM $item): void
    {
        if (!$item instanceof \Ticket || !is_array($item->input)) {
            return;
        }
        try {
            $cfg = Settings::get();
            if (!in_array($cfg['mode'], ['description', 'both'], true)
                || $cfg['category_ids'] === [] || $cfg['fields'] === []) {
                return;
            }
            $engine = new self($cfg);
            $input = $item->input;
            if (!$engine->eligible($input) || !is_string($input['content'] ?? null)) {
                return;
            }
            $engine->loadLocations([(int) ($input['locations_id'] ?? 0)]);
            $item->input['content'] = $engine->content($input['content'], $input);
        } catch (\Throwable $error) {
            Diagnostics::failure('ticket creation', $error);
        }
    }

    /**
     * Called only with successful native API Ticket results already authorized
     * by GLPI. Never discovers additional tickets or modifies the result set.
     */
    public static function enrichApiRows(array $rows, ?array $cfg = null): array
    {
        global $DB;
        $cfg ??= Settings::get();
        if (!in_array($cfg['mode'], ['api', 'both'], true)
            || $cfg['category_ids'] === [] || $cfg['fields'] === []) {
            return $rows;
        }
        $ids = [];
        foreach ($rows as $row) {
            if (!is_array($row) || !is_string($row['content'] ?? null)) {
                continue;
            }
            $id = $row['id'] ?? null;
            if ((is_int($id) || is_string($id)) && ctype_digit((string) $id) && (int) $id > 0) {
                $ids[(int) $id] = (int) $id;
            }
        }
        if ($ids === []) {
            return $rows;
        }
        $engine = new self($cfg);
        $metadata = [];
        $locationIds = [];
        foreach (array_chunk(array_values($ids), 500) as $chunk) {
            foreach ($DB->request([
                'SELECT' => ['id', 'entities_id', 'itilcategories_id', 'locations_id'],
                'FROM' => 'glpi_tickets', 'WHERE' => ['id' => $chunk],
            ]) as $ticket) {
                if ($engine->eligible($ticket)) {
                    $metadata[(int) $ticket['id']] = $ticket;
                    $locationIds[] = (int) $ticket['locations_id'];
                }
            }
        }
        $engine->loadLocations($locationIds);
        foreach ($rows as &$row) {
            if (!is_array($row) || !is_string($row['content'] ?? null)) {
                continue;
            }
            $id = (int) ($row['id'] ?? 0);
            if (isset($metadata[$id])) {
                $row['content'] = $engine->content($row['content'], $metadata[$id]);
            }
        }
        unset($row);
        return $rows;
    }

    private function eligible(array $ticket): bool
    {
        return isset($this->eligibleCategories[(int) ($ticket['itilcategories_id'] ?? 0)]);
    }

    private function loadLocations(array $ids): void
    {
        global $DB;
        $ids = array_values(array_unique(array_filter($ids, static fn($id) => $id > 0)));
        foreach (array_chunk($ids, 500) as $chunk) {
            foreach ($DB->request(['FROM' => 'glpi_locations', 'WHERE' => ['id' => $chunk]]) as $location) {
                $this->locations[(int) $location['id']] = $location;
            }
        }
    }

    private function content(string $original, array $ticket): string
    {
        $location = $this->locations[(int) ($ticket['locations_id'] ?? 0)] ?? null;
        if ($location === null || !array_key_exists('entities_id', $ticket)) {
            return $original;
        }
        $item = new \Location();
        $item->fields = $location;
        // Follow GLPI's recursive-entity visibility; do not import attributes
        // from an unrelated entity. No fallback to names, requester or parents.
        if (!$item->isAccessibleFromEntities([(int) $ticket['entities_id']])) {
            return $original;
        }
        $block = Block::render($location, $this->config['fields']);
        return $block === '' ? $original : Block::replace($original, $block);
    }
}
