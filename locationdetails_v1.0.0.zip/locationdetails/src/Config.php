<?php

namespace GlpiPlugin\Locationdetails;

use CommonGLPI;
use Glpi\Application\View\TemplateRenderer;
use Session;

/** Administration through GLPI's native Setup > General configuration form. */
class Config extends \Config
{
    public static function getTypeName($nb = 0)
    {
        return __('Detalhes da localização', 'locationdetails');
    }

    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        if ($item->getType() === \Config::class && Session::haveRight('config', READ)) {
            return self::createTabEntry(self::getTypeName());
        }
        return '';
    }

    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        if ($item->getType() !== \Config::class || !Session::haveRight('config', READ)) {
            return false;
        }

        $settings = Settings::get();
        TemplateRenderer::getInstance()->display('@locationdetails/config.html.twig', [
            'settings' => $settings,
            'mode_labels' => Settings::modeLabels(),
            'field_labels' => Settings::fieldLabels(),
            'category_choices' => self::categoryChoices($settings['category_ids']),
            'can_edit' => Session::haveRight('config', UPDATE),
        ]);
        return true;
    }

    /**
     * Called by core Config::prepareInputForUpdate before storing plugin settings.
     * Return only known settings; never persist POST control fields or arbitrary keys.
     */
    public static function configUpdate($input)
    {
        Session::checkRight('config', UPDATE);
        try {
            if (!is_array($input)
                || !is_string($input['mode'] ?? null)
                || !array_key_exists($input['mode'], Settings::modeLabels())) {
                throw new \InvalidArgumentException('Selecione um modo de enriquecimento válido.');
            }

            // Native multiple dropdowns submit an empty string when fully cleared.
            $categories = $input['category_ids'] ?? [];
            $fields = $input['fields'] ?? [];
            $categories = $categories === '' ? [] : $categories;
            $fields = $fields === '' ? [] : $fields;
            if (!is_array($categories) || !is_array($fields)) {
                throw new \InvalidArgumentException('Categorias e campos devem ser listas válidas.');
            }
            foreach ($categories as $id) {
                if ((!is_int($id) && !is_string($id))
                    || filter_var($id, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) === false) {
                    throw new \InvalidArgumentException('A seleção contém uma categoria inválida.');
                }
            }
            foreach ($fields as $field) {
                if (!is_string($field) || !array_key_exists($field, Settings::fieldLabels())) {
                    throw new \InvalidArgumentException('A seleção contém um campo de localização inválido.');
                }
            }
            $children = $input['include_children'] ?? '0';
            if (!in_array($children, [0, 1, '0', '1', false, true], true)) {
                throw new \InvalidArgumentException('A opção de subcategorias é inválida.');
            }

            $settings = Settings::normalize([
                'mode' => $input['mode'],
                'category_ids' => array_map('intval', $categories),
                'include_children' => (bool) $children,
                'fields' => $fields,
            ]);
            if ($settings['category_ids'] !== []) {
                global $DB;
                $found = [];
                foreach ($DB->request([
                    'SELECT' => ['id'],
                    'FROM' => 'glpi_itilcategories',
                    'WHERE' => ['id' => $settings['category_ids']],
                ]) as $row) {
                    $found[] = (int) $row['id'];
                }
                if (array_diff($settings['category_ids'], $found) !== []) {
                    throw new \InvalidArgumentException('Uma categoria selecionada não existe mais. Revise a seleção.');
                }
            }
            Session::addMessageAfterRedirect(__('Configuração salva.', 'locationdetails'));
            return Settings::toStorage($settings);
        } catch (\InvalidArgumentException $e) {
            Session::addMessageAfterRedirect(htmlescape($e->getMessage()), false, ERROR);
            return []; // Core writes no keys, preserving the previously saved configuration.
        }
    }

    private static function categoryChoices(array $selected): array
    {
        global $DB;
        $choices = [];
        // Admin-page-only query: no category list is loaded during plugin initialization.
        foreach ($DB->request([
            'SELECT' => ['id', 'name', 'completename'],
            'FROM' => 'glpi_itilcategories',
            'ORDER' => ['completename', 'id'],
        ]) as $row) {
            $id = (int) $row['id'];
            $name = (string) ($row['completename'] ?: $row['name']);
            $choices[$id] = $name . ' [#' . $id . ']';
        }
        foreach ($selected as $id) {
            if (!isset($choices[$id])) {
                $choices[$id] = 'Categoria indisponível [#' . $id . ']';
            }
        }
        return $choices;
    }
}
