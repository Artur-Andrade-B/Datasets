<?php

declare(strict_types=1);

namespace GlpiPlugin\Locationdetails\Api;

use Glpi\Api\HL\Middleware\AbstractMiddleware;
use Glpi\Api\HL\Middleware\MiddlewareInput;
use Glpi\Api\HL\Middleware\ResponseMiddlewareInterface;
use Glpi\Api\HL\RoutePath;
use GlpiPlugin\Locationdetails\Diagnostics;
use GlpiPlugin\Locationdetails\Enricher;
use GlpiPlugin\Locationdetails\Settings;
use GuzzleHttp\Psr7\Utils;
use stdClass;
use Throwable;

/**
 * Enrich only existing REST ticket reads after GLPI has applied its permissions.
 * GLPI normalizes api.php and the optional API version before middleware runs.
 */
final class LocationResponseMiddleware extends AbstractMiddleware implements ResponseMiddlewareInterface
{
    /**
     * The ITIL controller shares these route templates with Changes and Problems.
     * The request's resolved itemtype is checked separately in process().
     */
    public static function supportsRoute(RoutePath $route): bool
    {
        return in_array('GET', $route->getRouteMethods(), true)
            && in_array($route->getRoutePath(), [
                '/Assistance/{itemtype}',
                '/Assistance/{itemtype}/{id}',
                '/Assistance/Ticket',
                '/Assistance/Ticket/{id}',
            ], true);
    }

    public function process(MiddlewareInput $input, callable $next): void
    {
        // Keep downstream middleware outside our catch: its errors belong to GLPI.
        try {
            $this->enrichResponse($input);
        } catch (Throwable $error) {
            // No modified response is assigned until enrichment and encoding succeed.
            Diagnostics::failure('api_response', $error);
        }

        $next($input);
    }

    private function enrichResponse(MiddlewareInput $input): void
    {
        $response = $input->response;
        if ($response === null
            || $input->request->getMethod() !== 'GET'
            || !self::supportsRoute($input->route_path)
            || $response->getStatusCode() < 200
            || $response->getStatusCode() >= 300
        ) {
            return;
        }

        $route = $input->route_path->getRoutePath();
        if (str_contains($route, '{itemtype}')
            && $input->request->getAttribute('itemtype') !== 'Ticket'
        ) {
            return;
        }

        // GLPI's formatter runs after this middleware. Do not enrich CSV/XML reads.
        $accept = strtolower(trim($input->request->getHeaderLine('Accept')));
        if (in_array($accept, ['text/csv', 'application/xml'], true)) {
            return;
        }
        $contentType = strtolower(trim(explode(';', $response->getHeaderLine('Content-Type'), 2)[0]));
        if ($contentType !== 'application/json'
            || $response->getHeaderLine('Content-Encoding') !== ''
        ) {
            return;
        }
        $config = Settings::get();
        if (!in_array($config['mode'], ['api', 'both'], true)) {
            return;
        }

        $stream = $response->getBody();
        // Reading a non-seekable stream would prevent returning it unchanged on failure.
        if (!$stream->isReadable() || !$stream->isSeekable()) {
            return;
        }
        $position = $stream->tell();
        try {
            $stream->rewind();
            $raw = $stream->getContents();
        } finally {
            $stream->seek($position);
        }

        // Preserve nested JSON objects (including {}) by avoiding recursive array decoding.
        $document = json_decode($raw, false, 512, JSON_THROW_ON_ERROR);
        $collection = !str_ends_with($route, '/{id}');
        if (($collection && !is_array($document))
            || (!$collection && !$document instanceof stdClass)
        ) {
            return;
        }

        $objects = $collection ? $document : [$document];
        $rows = [];
        foreach ($objects as $key => $object) {
            // A projection without content is left as requested; no fields are added.
            if ($object instanceof stdClass
                && isset($object->id, $object->content)
                && is_string($object->content)
            ) {
                $rows[$key] = (array) $object;
            }
        }
        if ($rows === []) {
            return;
        }

        $enriched = Enricher::enrichApiRows($rows, $config);
        $changed = false;
        foreach ($rows as $key => $row) {
            if (isset($enriched[$key]['content'])
                && is_string($enriched[$key]['content'])
                && $enriched[$key]['content'] !== $row['content']
            ) {
                $objects[$key]->content = $enriched[$key]['content'];
                $changed = true;
            }
        }
        if (!$changed) {
            return;
        }

        $body = json_encode($document, JSON_THROW_ON_ERROR | JSON_PRESERVE_ZERO_FRACTION);
        $updated = $response->withBody(Utils::streamFor($body));
        // Preserve all pagination and status information; refresh body-dependent headers.
        if ($response->hasHeader('Content-Length')) {
            $updated = $updated->withHeader('Content-Length', (string) strlen($body));
        }
        foreach (['ETag', 'Content-MD5', 'Digest'] as $header) {
            if ($updated->hasHeader($header)) {
                $updated = $updated->withoutHeader($header);
            }
        }
        $input->response = $updated;
    }
}
