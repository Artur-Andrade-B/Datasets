<?php
declare(strict_types=1);

// Scoped fallback: GLPI also discovers namespaced plugin classes itself.
spl_autoload_register(static function (string $class): void {
    $prefix = 'GlpiPlugin\\Locationdetails\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }
    $relative = substr($class, strlen($prefix));
    if (!preg_match('/^[A-Za-z0-9_\\\\]+$/D', $relative)) {
        return;
    }
    $path = dirname(__DIR__) . '/src/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($path)) {
        require_once $path;
    }
});
