<?php

// Configuration is saved by GLPI's core Config form. This page only opens its tab.
if (!defined('GLPI_ROOT')) {
    define('GLPI_ROOT', dirname(__DIR__, 3));
}
require_once GLPI_ROOT . '/inc/includes.php';

Session::checkRight('config', READ);
$target = Toolbox::getItemTypeFormURL('Config');
$separator = str_contains($target, '?') ? '&' : '?';
Html::redirect($target . $separator . 'forcetab=' . rawurlencode('GlpiPlugin\\Locationdetails\\Config$1'));
