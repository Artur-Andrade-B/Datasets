<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
require dirname(__DIR__) . '/inc/autoload.php';

use GlpiPlugin\Locationdetails\Block;
use GlpiPlugin\Locationdetails\Settings;

$checks = 0;
function verify(bool $ok, string $message): void
{
    global $checks;
    ++$checks;
    if (!$ok) {
        throw new RuntimeException($message);
    }
}

$cfg = Settings::normalize(['mode' => 'both', 'category_ids' => '[4,4,7,-1,"x"]',
    'include_children' => '0', 'fields' => ['room', 'unknown', 'latitude', 'room']]);
verify($cfg['category_ids'] === [4, 7], 'Deduplicate IDs and reject malformed identifiers');
verify($cfg['include_children'] === false, 'Preserve explicit disabled option');
verify($cfg['fields'] === ['room', 'latitude'], 'Only known fields, in stable order');
verify(Settings::normalize(['mode' => 'arbitrary'])['mode'] === 'off', 'Unknown mode is inactive');
verify(Settings::normalize(Settings::toStorage($cfg)) === $cfg, 'Configuration storage roundtrip');
verify(Settings::normalize(['fields' => []])['fields'] === [], 'Empty field selection is retained');

$location = ['name' => 'Conselho de Saúde', 'room' => '0', 'latitude' => '0',
    'address' => "A & B <script>alert(1)</script>\n2º andar", 'country' => '   '];
$block = Block::render($location, ['name', 'room', 'latitude', 'address', 'country']);
verify(str_contains($block, 'Conselho de Saúde'), 'Preserve accents');
verify(str_contains($block, '<strong>Sala:</strong> 0'), 'Zero-valued room is not empty');
verify(str_contains($block, '<strong>Latitude:</strong> 0'), 'Equator coordinate is not empty');
verify(!str_contains($block, '<script>') && str_contains($block, '&lt;script&gt;'), 'Escape location HTML');
verify(str_contains($block, 'A &amp; B') && str_contains($block, '<br>'), 'Preserve escaped multiline values');
verify(!str_contains($block, '<strong>País:'), 'Omit blank fields');
verify(Block::render($location, ['country']) === '', 'Do not generate an empty block');

$original = '<p><strong>Localização:</strong> Conselho</p><p>Descrição com <a href="/x">anexo</a>.</p>';
$enriched = Block::replace($original, $block);
verify(str_starts_with($enriched, $original), 'Preserve original description bytes');
verify(Block::replace($enriched, $block) === $enriched, 'Repeated enrichment does not duplicate');
verify(Block::remove($enriched) === $original, 'Remove only the owned block');
$new = Block::render(['room' => '304'], ['room']);
verify(Block::replace($enriched, $new) === $original . $new, 'Refresh managed block');
verify(Block::replace($enriched . '<p>Later note</p>' . $block, $new) === $original . $new . '<p>Later note</p>', 'Deduplicate while preserving later notes');
$nested = '<div class="other ' . Block::MARKER . '"><p>old</p><div title="x > y"><p>nested</p></div></div>';
verify(Block::replace('before' . $nested . 'after', $new) === 'before' . $new . 'after', 'Balanced removal of nested divs');
$unmanaged = '<div class="not-' . Block::MARKER . '">Keep me</div>';
verify(Block::remove($unmanaged) === $unmanaged, 'Do not match partial class names');
verify(Block::remove('<div class="' . Block::MARKER . '">Unclosed') === '<div class="' . Block::MARKER . '">Unclosed', 'Leave malformed unclosed block untouched');

echo "Block and settings tests passed: $checks checks.\n";
