<?php
declare(strict_types=1);
// Executes real GLPI core with synthetic fixtures. Never run against production.
// GLPI_LOCATIONDETAILS_TEST_ROOT=/path/to/disposable/glpi
// GLPI_LOCATIONDETAILS_ALLOW_DESTRUCTIVE_TESTS=1 php tests/core_integration_test.php
if (PHP_SAPI !== 'cli' || getenv('GLPI_LOCATIONDETAILS_ALLOW_DESTRUCTIVE_TESTS') !== '1') {
    throw new RuntimeException('CLI and explicit disposable-test opt-in required');
}
$glpiRoot = getenv('GLPI_LOCATIONDETAILS_TEST_ROOT');
if (!$glpiRoot || !is_file($glpiRoot . '/vendor/autoload.php')) {
    throw new RuntimeException('GLPI_LOCATIONDETAILS_TEST_ROOT must point to a full GLPI 11 installation');
}
require $glpiRoot . '/vendor/autoload.php';
$kernel = new \Glpi\Kernel\Kernel();
$kernel->boot();
global $DB;
if ($DB->dbdefault !== 'glpi_location_test') { throw new RuntimeException('Disposable database required'); }
$user = new User(); $user->getFromDBbyName('glpi');
$auth = new Auth(); $auth->auth_succeded = true; $auth->user = $user; Session::init($auth);
require_once dirname(__DIR__) . '/hook.php';
plugin_locationdetails_uninstall();
plugin_locationdetails_install();
use GlpiPlugin\Locationdetails\Settings;
use GlpiPlugin\Locationdetails\Enricher;
use GlpiPlugin\Locationdetails\Block;
use GlpiPlugin\Locationdetails\Config as PluginConfig;
use Glpi\RichText\RichText;
$results=[];
function check(bool $ok,string $name):void { global $results; if(!$ok)throw new RuntimeException($name); $results[]=$name; }
function add(string $type,array $input):int { $o=new $type();$id=$o->add($input);if(!$id)throw new RuntimeException('add '.$type.' failed: '.json_encode($o->input));return (int)$id; }
function ticket(int $cat,int $loc,int $entity=0):array { $id=add(Ticket::class,['name'=>'Location runtime test','content'=>'<p>Original &amp; body <strong>intact</strong>.</p>','itilcategories_id'=>$cat,'locations_id'=>$loc,'entities_id'=>$entity,'_users_id_requester'=>2,'urgency'=>3,'impact'=>3,'type'=>1,'_disablenotif'=>true]); $t=new Ticket();$t->getFromDB($id);return $t->fields; }
function readable(array $t):string { return RichText::getSafeHtml($t['content']); }
$cat=add(ITILCategory::class,['name'=>'Runtime selected '.uniqid(),'entities_id'=>0,'is_recursive'=>1]);
$child=add(ITILCategory::class,['name'=>'Runtime child '.uniqid(),'itilcategories_id'=>$cat,'entities_id'=>0,'is_recursive'=>1]);
$excluded=add(ITILCategory::class,['name'=>'Runtime excluded '.uniqid(),'entities_id'=>0,'is_recursive'=>1]);
$entity=add(Entity::class,['name'=>'Runtime child entity '.uniqid(),'entities_id'=>0]);
$otherEntity=add(Entity::class,['name'=>'Runtime other entity '.uniqid(),'entities_id'=>0]);
$loc=add(Location::class,['name'=>'Local & test '.uniqid(),'entities_id'=>0,'is_recursive'=>1,'address'=>'Rua <Teste> & 42','room'=>'Sala 9','latitude'=>'0','longitude'=>'-47.91','postcode'=>'70000-000']);
$otherLoc=add(Location::class,['name'=>'Other entity location','entities_id'=>$otherEntity,'is_recursive'=>0,'address'=>'Must not leak']);
$base=['category_ids'=>[$cat],'fields'=>['name','address','room','latitude','longitude'],'include_children'=>false];
check(Settings::get()['mode']==='off','install starts disabled');
foreach(['off','api','description','both'] as $mode){
 Settings::save($base+['mode'=>$mode]);
 $row=ticket($cat,$loc);$html=readable($row);$expects=in_array($mode,['description','both'],true);
 check(str_contains($html,Block::MARKER)===$expects,'creation mode '.$mode);
 if($expects){check(str_contains($html,'Sala 9')&&str_contains($html,'Latitude:</strong> 0'),'populated room and zero coordinate '.$mode);check(str_contains($html,'Rua &lt;Teste&gt; &amp; 42'),'location HTML escaped '.$mode);check(substr_count($html,Block::MARKER)===1,'one saved block '.$mode);}
 $api=Enricher::enrichApiRows([['id'=>$row['id'],'content'=>$html,'name'=>$row['name']]]);
 check(str_contains($api[0]['content'],Block::MARKER)===($expects||$mode==='api'),'API mode '.$mode);
 $again=new Ticket();$again->getFromDB($row['id']);check($again->fields['content']===$row['content']&&$again->fields['date_mod']===$row['date_mod'],'API does not write '.$mode);
}
Settings::save($base+['mode'=>'both']);
check(!str_contains(readable(ticket($excluded,$loc)),Block::MARKER),'excluded category untouched');
check(!str_contains(readable(ticket($child,$loc)),Block::MARKER),'child category excluded by default');
Settings::save(array_replace($base,['mode'=>'both','include_children'=>true]));
check(str_contains(readable(ticket($child,$loc)),Block::MARKER),'child category included when enabled');
check(!str_contains(readable(ticket($cat,0)),Block::MARKER),'missing location untouched');
check(str_contains(readable(ticket($cat,$loc,$entity)),Block::MARKER),'recursive parent entity location allowed');
check(!str_contains(readable(ticket($cat,$otherLoc,$entity)),Block::MARKER),'unrelated entity location blocked');
$row=ticket($cat,$loc); $before=$row;
(new Location())->update(['id'=>$loc,'room'=>'Sala atualizada']);
$api=Enricher::enrichApiRows([['id'=>$row['id'],'content'=>readable($row)]]);
check(str_contains($api[0]['content'],'Sala atualizada')&&!str_contains($api[0]['content'],'Sala 9'),'API refreshes current location fields');
check(substr_count($api[0]['content'],Block::MARKER)===1,'both mode replaces without duplication');
$after=new Ticket();$after->getFromDB($row['id']);check($after->fields['content']===$before['content'],'saved snapshot retained after API refresh');
$block=Block::render(['name'=>'Teste & <tag>','room'=>'Sala 2','latitude'=>'0'],['name','room','latitude']);
$sanitized=RichText::getSafeHtml($block);
check(str_contains($sanitized,Block::MARKER),'native GLPI sanitizer preserves marker');
check(substr_count(Block::replace($sanitized,$block),Block::MARKER)===1,'sanitized block remains replaceable');
$cfg=new Config();
$valid=['config_context'=>Settings::CONTEXT,'config_class'=>PluginConfig::class,'mode'=>'api','category_ids'=>[(string)$cat],'include_children'=>'1','fields'=>['room','latitude'],'update'=>'1','unexpected'=>'discard me'];
$cfg->prepareInputForUpdate($valid);$saved=Settings::get();
check($saved['mode']==='api'&&$saved['fields']===['room','latitude']&&$saved['include_children'],'native Config saves known fields');
check(!isset(Config::getConfigurationValues(Settings::CONTEXT)['unexpected']),'native Config drops unknown keys');
foreach([['mode'=>'bad'],['fields'=>['invalid']],['category_ids'=>['-2']],['category_ids'=>['9999999']],['include_children'=>'bad']] as $bad){
 $cfg->prepareInputForUpdate(array_replace($valid,$bad));check(Settings::get()===$saved,'invalid Config rejected '.json_encode($bad));
}
plugin_locationdetails_install();check(Settings::get()===$saved,'upgrade preserves configured values');
Settings::save(['mode'=>'off','category_ids'=>[],'fields'=>[],'include_children'=>false]);plugin_locationdetails_install();check(Settings::get()['mode']==='off'&&Settings::get()['fields']===[],'upgrade preserves disabled mode and empty fields');
Settings::save($base+['mode'=>'api']);
ob_start();PluginConfig::displayTabContentForItem(new Config());$render=ob_get_clean();

check(str_contains($render,'Modo de enriquecimento')&&str_contains($render,'category_ids'),'native Twig configuration renders');
check(str_contains($render,'/front/config.form.php'),'native config target resolves');
check(str_contains($render,'name="_glpi_csrf_token"'),'native configuration has CSRF token');
plugin_locationdetails_uninstall();
$afterUninstall = new Ticket(); $afterUninstall->getFromDB($row['id']);
check($afterUninstall->fields['content'] === $before['content'], 'uninstall preserves ticket descriptions');
check(Config::getConfigurationValues(Settings::CONTEXT) === [], 'uninstall removes only plugin configuration');
plugin_locationdetails_install();
check(Settings::get()['mode'] === 'off', 'reinstall begins disabled');
Settings::save($base + ['mode' => 'api']);
$summary=['passed' =>count($results),'checks'=>$results,'fixtures'=>['category'=>$cat,'child_category'=>$child,'excluded_category'=>$excluded,'location'=>$loc,'ticket'=>(int)$row['id'],'entity'=>$entity,'other_entity'=>$otherEntity]];

echo json_encode($summary,JSON_PRETTY_PRINT),"\n";
