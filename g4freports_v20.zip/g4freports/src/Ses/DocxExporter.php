<?php

namespace GlpiPlugin\G4freports\Ses;

/** SES managerial report built from the same frozen dataset as the workbook. */
final class DocxExporter
{
    private WordChart $charts;

    public function filename(array $snapshot): string
    {
        return 'Relatorio_Mensal_SES_' . preg_replace('/[^0-9-]/', '', $snapshot['period']['month'] ?? '') . '.docx';
    }

    public function toBinary(array $snapshot): string
    {
        $path = dirname(__DIR__, 2) . '/resources/docx/papel_timbrado_G4F.docx';
        $binary = @file_get_contents($path);
        if (!is_string($binary)) {
            throw new \RuntimeException('O papel timbrado G4F não foi encontrado no pacote do plugin.');
        }
        $files = OfficePackage::read($binary);
        if (!isset($files['word/document.xml'], $files['word/_rels/document.xml.rels'])) {
            throw new \RuntimeException('O modelo G4F não contém os componentes necessários.');
        }
        $this->charts = new WordChart();
        $files['word/document.xml'] = $this->document($snapshot);
        $this->charts->attach($files);
        $files['word/styles.xml'] = $this->styles();
        $files['docProps/core.xml'] = '<?xml version="1.0" encoding="UTF-8"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>Relatório mensal SES</dc:title><dc:creator>G4F</dc:creator><dc:description>' . OfficePackage::xml(($snapshot['period']['month'] ?? '') . ' | ' . ($snapshot['rules_version'] ?? '')) . '</dc:description></cp:coreProperties>';
        return OfficePackage::write($files);
    }

    private function document(array $s): string
    {
        $period = $s['period'];
        $totals = $s['totals'];
        $input = $s['input'] ?? [];
        $manual = $s['manual'] ?? [];
        $figures = ChartData::build($s);
        $heatmaps = HeatmapData::build($s);
        $title = trim((string)($input['report_title'] ?? '')) ?: 'Relatório técnico de execução mensal';
        $body = $this->p('G4F  |  Secretaria de Estado de Saúde do Distrito Federal', '', false, 20, 'center');
        $body .= '<w:p><w:pPr><w:spacing w:before="3000" w:after="320"/></w:pPr></w:p>';
        $body .= $this->p($title, 'Title', true, 40, 'center');
        $body .= $this->p('Contrato SES/DF 053592/2025', '', true, 25, 'center');
        $body .= $this->p((string)($period['label'] ?? $period['month']), '', false, 26, 'center');
        $body .= $this->p('Chamados por data de solução e telefonia por entrada na fila', '', false, 21, 'center');
        $body .= $this->p('Extração: ' . OfficePackage::date($s['generated_at'] ?? ''), '', false, 18, 'center');
        $body .= $this->page();
        $body .= $this->heading('1 Apresentação e objetivo');
        $body .= $this->p('Este relatório apresenta a execução mensal dos serviços de atendimento de TIC e os indicadores operacionais do Contrato SES/DF 053592/2025. As medições utilizam os registros do GLPI, os eventos de telefonia do Asterisk e as informações gerenciais complementadas para o período.');
        $body .= $this->p('Os chamados são selecionados pela data de solução, entre ' . OfficePackage::date($period['start']) . ' e ' . OfficePackage::date($period['end_exclusive']) . ' (limite final exclusivo). Chamados abertos antes do mês integram a apuração quando solucionados no período. As ligações são selecionadas pela entrada na fila.');
        $body .= $this->heading('2 Resumo de chamados');
        $body .= $this->table(['Descrição', 'Quantidade'], [
            ['Total de chamados solucionados', OfficePackage::number($totals['tickets'] ?? 0)],
            ['Requisições', OfficePackage::number($totals['requests'] ?? 0)],
            ['Incidentes', OfficePackage::number($totals['incidents'] ?? 0)],
            ['Chamados sem prazo de solução registrado', OfficePackage::number($totals['missing_deadline'] ?? 0)],
        ], [7100, 2400]);
        $body .= $this->p('Os registros sem prazo de solução são informados separadamente e não são classificados automaticamente como atendimento no prazo. A planilha de evidências acompanha os resultados e permite identificar os registros de cada população.');
        $body .= $this->figure($figures['tickets_types'], 3000);
        $body .= $this->page();
        $body .= $this->heading('3 Resumo de telefonia');
        $body .= $this->table(['Descrição', 'Apuração'], [
            ['Ligações recebidas após exclusões de teste', OfficePackage::number($totals['calls_received'] ?? 0)],
            ['Ligações atendidas', OfficePackage::number($totals['calls_answered'] ?? 0)],
            ['Ligações abandonadas no total', OfficePackage::number($totals['calls_abandoned'] ?? 0)],
            ['Abandonos após mais de 30 segundos (INS9)', OfficePackage::number($totals['calls_abandoned_over_30'] ?? null)],
            ['Ligações de teste excluídas', OfficePackage::number($totals['calls_excluded'] ?? 0)],
            ['Duração média das conversas atendidas', OfficePackage::duration($totals['mean_talk_seconds'] ?? null)],
            ['Espera média antes da conexão ao agente', OfficePackage::duration($totals['mean_wait_seconds'] ?? null)],
        ], [7100, 2400]);
        $body .= $this->p('Os tempos individuais representam durações reais: TMA corresponde à conversa e TME à espera na fila antes da conexão. As médias acima são calculadas sobre as ligações com tempos válidos. INS7 e INS8 são percentuais de atendimento dentro dos limites definidos, com denominador de ligações recebidas.');
        $body .= $this->p('O total de abandonos inclui esperas de até 30 segundos; o INS9 considera somente os abandonos após mais de 30 segundos. Por isso, pode haver ligações abandonadas e resultado de 0,00% no INS9.');
        $body .= $this->figure($figures['calls_daily'], 3200);
        if (trim((string)($manual['executive_summary'] ?? '')) !== '') {
            $body .= $this->heading('Análise executiva');
            $body .= $this->text($manual['executive_summary']);
        }
        $body .= $this->page();
        $body .= $this->heading('4 Indicadores do contrato');
        $body .= $this->p('Os resultados abaixo seguem as definições operacionais registradas nesta extração. Meta atingida exige uma medição aplicável e completa. Pendências e apurações provisórias permanecem identificadas.');
        $rows = [];
        foreach ($s['metrics'] as $m) {
            $rows[] = [$m['id'], $m['label'], ($m['direction'] === 'lte' ? '≤ ' : '≥ ') . OfficePackage::percent($m['target']), $m['value'] === null ? ($m['status'] === 'not_applicable' ? 'N/A' : 'Pendente') : OfficePackage::percent($m['value']), OfficePackage::status($m)];
        }
        $body .= $this->table(['INS', 'Indicador', 'Meta', 'Resultado', 'Situação'], $rows, [850, 4050, 1150, 1250, 2200], 18);
        $body .= $this->p('As identificações INS1 a INS4 e sua associação à prioridade do GLPI são declaradas nas medições a seguir. O cumprimento do prazo usa a data limite armazenada no chamado, conforme o SLA e calendário aplicados na origem.');
        $body .= $this->page();
        $body .= $this->heading('Resultados e metas dos indicadores');
        $body .= $this->p('As barras comparam resultados percentuais e metas, separados pelo sentido da regra. As medições provisórias conservam essa identificação; indicadores pendentes ou não aplicáveis aparecem na tabela anterior e não são representados como resultado zero.');
        $body .= $this->figure($this->overview($s['metrics'], 'gte'), 4600);
        $body .= $this->figure($this->overview($s['metrics'], 'lte'), 2400);
        $body .= $this->page();
        $body .= $this->heading('5 Medição dos indicadores');
        $previousUnavailable = false;
        $blocksOnPage = 0;
        foreach ($s['metrics'] as $index => $m) {
            $figure = $figures[$m['id']];
            if ($index > 0 && (!$previousUnavailable || $blocksOnPage >= 2)) {
                $body .= $this->page();
                $blocksOnPage = 0;
            }
            $body .= $this->heading($m['id'] . ' ' . $m['label'], 2);
            $body .= $this->table(['Numerador', 'Denominador', 'Resultado', 'Meta', 'Situação'], [[
                OfficePackage::number($m['numerator']), OfficePackage::number($m['denominator']),
                $m['value'] === null ? ($m['status'] === 'not_applicable' ? 'N/A' : 'Pendente') : OfficePackage::percent($m['value']),
                ($m['direction'] === 'lte' ? '≤ ' : '≥ ') . OfficePackage::percent($m['target']), OfficePackage::status($m),
            ]], [1500, 1700, 1600, 1600, 3100], 19);
            $body .= $this->p('Critério de cálculo: ' . $m['method']);
            if (!empty($m['note'])) {
                $body .= $this->p('Observação: ' . $m['note']);
            }
            $body .= $this->figure($figure, 3500);
            $previousUnavailable = empty($figure['available']);
            $blocksOnPage++;
        }
        $body .= $this->page();
        $body .= $this->heading('6 Distribuição temporal da operação');
        $body .= $this->p('A evolução diária mostra o volume de chamados solucionados. Os mapas de calor totalizam o volume do mês por hora e dia da semana, com os horários locais registrados na origem. Não representam médias por dia da semana nem o cumprimento dos níveis de serviço.');
        $body .= $this->figure($figures['tickets_daily'], 4400);
        foreach ($heatmaps as $heatmap) {
            $body .= $this->page();
            $body .= $this->heading($heatmap['title'], 2);
            $body .= $this->heatmap($heatmap);
        }
        $body .= $this->page();
        $body .= $this->heading('7 Ajustes e regularizações do faturamento');
        $body .= $this->p('Os percentuais operacionais deste relatório constituem a evidência da medição. Ajustes financeiros, justificativas e valores de faturamento dependem da base financeira e da validação contratual correspondente; não são calculados automaticamente a partir dos indicadores.');
        $body .= $this->heading('8 Propostas de melhoria e ações corretivas');
        $body .= $this->text(trim((string)($manual['actions'] ?? '')) ?: 'Não foram registradas ações gerenciais complementares nesta extração.');
        $body .= $this->heading('9 Equipe e rotatividade de profissionais');
        $body .= $this->p('O INS10 é apurado com informações de pessoal referentes à janela de três meses. Os registros abaixo são complementações gerenciais e não são extraídos dos chamados do GLPI.');
        $body .= $this->table(['Informação de pessoal', 'Quantidade'], [
            ['Profissionais na base de cálculo', OfficePackage::number($input['staff_total'] ?? null)],
            ['Substituições no período de três meses', OfficePackage::number($input['staff_replacements'] ?? null)],
            ['Exclusões por determinação da contratante', OfficePackage::number($input['staff_excluded'] ?? null)],
        ], [7100, 2400]);
        $body .= $this->heading('10 Observações e encerramento');
        $body .= $this->text(trim((string)($manual['notes'] ?? '')) ?: 'Não foram registradas observações complementares.');
        $body .= $this->page();
        $body .= $this->heading('11 Metodologia e evidências');
        $body .= $this->table(['Parâmetro', 'Valor'], [
            ['Competência', $period['label'] ?? $period['month']],
            ['Extração', OfficePackage::date($s['generated_at'] ?? '')],
            ['Versão das regras', $s['rules_version'] ?? ''],
            ['Base temporal dos chamados', 'Data de solução'],
            ['Base temporal das ligações', 'Entrada na fila'],
            ['Entidade GLPI', (string)($input['entity_id'] ?? '')],
            ['Grupos técnicos selecionados', !empty($input['group_ids']) ? implode(', ', $input['group_ids']) : 'Todos os grupos do escopo da entidade'],
            ['Filtro de fila', (string)($input['queue_filter'] ?? '')],
            ['Referência de horário', (string)($input['timezone'] ?? 'America/Sao_Paulo')],
            ['Chamadas de teste excluídas', OfficePackage::number($totals['calls_excluded'] ?? 0)],
        ], [3600, 5900]);
        foreach ($s['rule_notes'] ?? [] as $note) {
            $body .= $this->p($note);
        }
        if (!empty($s['warnings'])) {
            $body .= $this->heading('Limitações da apuração', 2);
            foreach ($s['warnings'] as $warning) {
                $body .= $this->p($warning);
            }
        }
        $body .= $this->p('A planilha anexa contém o painel consolidado, as abas individuais INS1 a INS12, as bases de chamados e ligações consideradas, a aba Distribuição Temporal e a aba Auditoria de exclusões. Essa aba preserva a lista de números de teste aplicada e os registros excluídos, com seus identificadores e motivos. Foram excluídas ' . OfficePackage::number($totals['calls_excluded'] ?? 0) . ' ligações nesta extração. As exclusões aplicam-se às contagens, aos percentuais e às médias de telefonia.');
        $body .= $this->heading('12 Aprovação');
        $body .= $this->p('Responsável pela elaboração: ____________________________________');
        $body .= $this->p('Responsável pela validação: _____________________________________');
        $body .= $this->p('Data: ____/____/________');
        $section = '<w:sectPr><w:headerReference w:type="even" r:id="rId11"/><w:headerReference w:type="default" r:id="rId12"/><w:footerReference w:type="default" r:id="rId13"/><w:headerReference w:type="first" r:id="rId14"/><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1560" w:right="1134" w:bottom="1560" w:left="1134" w:header="709" w:footer="709"/><w:cols w:space="708"/></w:sectPr>';
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart"><w:body>' . $body . $section . '</w:body></w:document>';
    }

    private function figure(array $definition, int $height): string
    {
        if (empty($definition['available'])) {
            return $this->p('Gráfico não apresentado: ' . ($definition['note'] ?? 'medição pendente ou não aplicável.'), '', false, 20);
        }
        $xml = $this->charts->paragraph($definition, $height);
        if (in_array($definition['kind'] ?? '', ['pie', 'doughnut'], true)) {
            $xml .= $this->compositionTable($definition);
        }
        return $xml . $this->p((string)($definition['note'] ?? ''), '', false, 19);
    }


    private function compositionTable(array $definition): string
    {
        $values = $definition['series'][0]['values'];
        $total = array_sum($values);
        $rows = [];
        foreach ($definition['categories'] as $index => $category) {
            $rows[] = [$category, OfficePackage::number($values[$index]), $total > 0 ? OfficePackage::percent($values[$index] * 100 / $total) : 'N/A'];
        }
        $xml = $this->table(['Composição', 'Quantidade', 'Participação'], $rows, [5900, 1700, 1900], 18);
        // A narrow, colored left border links each exact-count row to its slice without relying on color alone.
        $index = -1;
        return preg_replace_callback('/<w:tr>.*?<\/w:tr>/s', static function (array $match) use (&$index, $definition): string {
            $index++;
            $color = $definition['point_colors'][$index - 1] ?? '';
            if ($index === 0 || !preg_match('/^[0-9A-Fa-f]{6}$/', $color)) {
                return $match[0];
            }
            return preg_replace('/<w:tcPr>/', '<w:tcPr><w:tcBorders><w:left w:val="single" w:sz="28" w:color="' . $color . '"/></w:tcBorders>', $match[0], 1);
        }, $xml);
    }

    private function heatmap(array $definition): string
    {
        if (empty($definition['available'])) {
            return $this->p('Mapa de calor não apresentado: ' . $definition['note'], '', false, 20);
        }
        $maximum = max(1, (int)$definition['maximum']);
        $xml = $this->p('Volume representado: ' . OfficePackage::number($definition['total']) . ' | Registros fora da matriz: ' . OfficePackage::number($definition['omitted']), '', false, 20);
        $xml .= '<w:tbl><w:tblPr><w:tblW w:w="9500" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders>';
        foreach (['top', 'left', 'bottom', 'right', 'insideH', 'insideV'] as $edge) {
            $xml .= '<w:' . $edge . ' w:val="single" w:sz="4" w:color="' . ReportStyle::BORDER . '"/>';
        }
        $xml .= '</w:tblBorders><w:tblCellMar><w:top w:w="65" w:type="dxa"/><w:left w:w="60" w:type="dxa"/><w:bottom w:w="65" w:type="dxa"/><w:right w:w="60" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid><w:gridCol w:w="1100"/>' . str_repeat('<w:gridCol w:w="1200"/>', 7) . '</w:tblGrid>';
        $rows = array_merge([array_merge(['Hora'], $definition['column_labels'])], array_map(static function ($label, $values) { return array_merge([$label], $values); }, $definition['row_labels'], $definition['values']));
        foreach ($rows as $rowIndex => $row) {
            $xml .= '<w:tr><w:trPr><w:cantSplit/>' . ($rowIndex === 0 ? '<w:tblHeader/>' : '') . '</w:trPr>';
            foreach ($row as $columnIndex => $value) {
                $heading = $rowIndex === 0 || $columnIndex === 0;
                $ratio = $heading ? 0 : (int)$value / $maximum;
                $fill = $heading ? ReportStyle::NAVY : ReportStyle::heatmapColor($ratio);
                $color = $heading ? ReportStyle::WHITE : ReportStyle::NAVY;
                $text = $heading ? (string)$value : OfficePackage::number((int)$value);
                $paragraph = str_replace('w:after="140" w:line="270"', 'w:after="0" w:line="210"', $this->p($text, '', $heading, 19, 'center', $color));
                $xml .= '<w:tc><w:tcPr><w:tcW w:w="' . ($columnIndex === 0 ? '1100' : '1200') . '" w:type="dxa"/><w:shd w:val="clear" w:fill="' . $fill . '"/><w:vAlign w:val="center"/></w:tcPr>' . $paragraph . '</w:tc>';
            }
            $xml .= '</w:tr>';
        }
        $xml .= '</w:tbl>' . $this->p('Escala própria deste mapa: 0 (branco) → ' . OfficePackage::number($maximum) . ' (azul). Células mais escuras representam maior volume; os valores exatos permanecem visíveis.', '', false, 18);
        return $xml . $this->p($definition['note'], '', false, 19);
    }

    private function overview(array $metrics, string $direction): array
    {
        $categories = [];
        $values = [];
        $targets = [];
        foreach ($metrics as $metric) {
            if (($metric['direction'] ?? '') !== $direction || $metric['value'] === null) {
                continue;
            }
            $categories[] = $metric['id'] . (($metric['status'] ?? '') === 'provisional' ? ' (provisório)' : '');
            $values[] = $metric['value'] / 100;
            $targets[] = $metric['target'] / 100;
        }
        return [
            'id' => 'overview_' . $direction,
            'title' => $direction === 'gte' ? 'Indicadores com meta mínima' : 'Indicadores com limite máximo',
            'categories' => $categories,
            'series' => [
                ['name' => 'Resultado', 'values' => $values, 'color' => ReportStyle::BLUE],
                ['name' => $direction === 'gte' ? 'Meta mínima' : 'Limite máximo', 'values' => $targets, 'color' => ReportStyle::NAVY],
            ],
            'kind' => 'bar', 'stacked' => false, 'unit' => 'percent', 'available' => count($categories) > 0,
            'note' => $direction === 'gte'
                ? 'Regra: resultado maior ou igual à meta. Um resultado provisório não confirma o cumprimento da meta até a regularização das pendências.'
                : 'Regra: resultado menor ou igual ao limite. Valores menores são favoráveis; zero é um resultado válido quando há população para apuração.',
        ];
    }

    private function text(string $text): string
    {
        $xml = '';
        foreach (preg_split('/\r\n|\r|\n/', $text) as $line) {
            if (trim($line) !== '') {
                $xml .= $this->p($line);
            }
        }
        return $xml;
    }

    private function heading(string $text, int $level = 1): string
    {
        return $this->p($text, 'Heading' . $level, true, $level === 1 ? 28 : 23);
    }

    private function p(string $text, string $style = '', bool $bold = false, int $size = 21, string $align = 'left', string $color = ReportStyle::NAVY): string
    {
        return '<w:p><w:pPr>' . ($style !== '' ? '<w:pStyle w:val="' . $style . '"/>' : '') . '<w:jc w:val="' . $align . '"/><w:spacing w:after="140" w:line="270" w:lineRule="auto"/>' . ($style === 'Heading1' || $style === 'Heading2' ? '<w:keepNext/>' : '') . '</w:pPr><w:r><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/>' . ($bold ? '<w:b/>' : '') . '<w:color w:val="' . ($style !== '' ? ReportStyle::NAVY : $color) . '"/><w:sz w:val="' . $size . '"/></w:rPr><w:t xml:space="preserve">' . OfficePackage::xml($text) . '</w:t></w:r></w:p>';
    }

    private function page(): string
    {
        return '<w:p><w:pPr><w:pageBreakBefore/><w:spacing w:after="0" w:before="0"/></w:pPr></w:p>';
    }

    private function table(array $headers, array $rows, array $widths, int $size = 20): string
    {
        $xml = '<w:tbl><w:tblPr><w:tblW w:w="9500" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders>';
        foreach (['top', 'left', 'bottom', 'right', 'insideH', 'insideV'] as $edge) {
            $xml .= '<w:' . $edge . ' w:val="single" w:sz="4" w:color="' . ReportStyle::BORDER . '"/>';
        }
        $xml .= '</w:tblBorders><w:tblCellMar><w:top w:w="85" w:type="dxa"/><w:left w:w="95" w:type="dxa"/><w:bottom w:w="85" w:type="dxa"/><w:right w:w="95" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>';
        foreach ($widths as $width) {
            $xml .= '<w:gridCol w:w="' . $width . '"/>';
        }
        $xml .= '</w:tblGrid>';
        foreach (array_merge([$headers], $rows) as $i => $row) {
            $xml .= '<w:tr><w:trPr><w:cantSplit/>' . ($i === 0 ? '<w:tblHeader/>' : '') . '</w:trPr>';
            foreach ($row as $j => $cell) {
                $fill = $i === 0 ? ReportStyle::NAVY : ($i % 2 === 0 ? ReportStyle::POSITIVE_FILL : ReportStyle::WHITE);
                $cellParagraph = str_replace('w:after="140" w:line="270"', 'w:after="20" w:line="240"', $this->p((string)$cell, '', $i === 0, $size, 'left', $i === 0 ? ReportStyle::WHITE : ReportStyle::NAVY));
                $xml .= '<w:tc><w:tcPr><w:tcW w:w="' . $widths[$j] . '" w:type="dxa"/><w:shd w:val="clear" w:fill="' . $fill . '"/><w:vAlign w:val="center"/></w:tcPr>' . $cellParagraph . '</w:tc>';
            }
            $xml .= '</w:tr>';
        }
        return $xml . '</w:tbl><w:p><w:pPr><w:spacing w:after="80"/></w:pPr></w:p>';
    }

    private function styles(): string
    {
        return '<?xml version="1.0" encoding="UTF-8"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:sz w:val="21"/><w:lang w:val="pt-BR"/></w:rPr></w:rPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style><w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:rPr><w:b/><w:color w:val="' . ReportStyle::NAVY . '"/><w:sz w:val="40"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:before="240" w:after="180"/><w:outlineLvl w:val="0"/></w:pPr><w:rPr><w:b/><w:color w:val="' . ReportStyle::NAVY . '"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:before="200" w:after="140"/><w:outlineLvl w:val="1"/></w:pPr><w:rPr><w:b/><w:color w:val="' . ReportStyle::NAVY . '"/></w:rPr></w:style></w:styles>';
    }
}
