<?php

namespace GlpiPlugin\G4freports\Ses;

/**
 * Read-only operational clock. Source deadlines and statistics are evidence, not
 * eligibility gates. The selected current-level calendar is applied consistently
 * to the complete life and to every suspension; historic changes remain visible.
 * No rule, deadline or ticket is written back to GLPI.
 */
class SlaEvaluator
{
    private $context;
    private $input;
    private $zone;
    private $timezoneAvailable;
    private $days = [];

    public function __construct(array $context, array $input)
    {
        $this->context = $context;
        $this->input = $input;
        $this->timezoneAvailable = !empty($context['timezone']) && (($context['capabilities']['timezone'] ?? true) !== false);
        try {
            $this->zone = new \DateTimeZone((string)($context['timezone'] ?? 'UTC'));
        } catch (\Exception $e) {
            $this->zone = new \DateTimeZone('UTC');
            $this->timezoneAvailable = false;
        }
    }

    public function evaluate(array $ticket): array
    {
        $out = [
            'sla_evaluated' => true, 'within_sla' => null, 'sla_result' => 'unresolved',
            'sla_target_seconds' => null, 'sla_calendar_id' => null, 'sla_calendar_name' => '',
            'sla_gross_seconds' => null, 'sla_pending_seconds' => null,
            'sla_net_seconds' => null, 'sla_active_seconds' => null,
            'sla_method' => 'unresolved', 'sla_reason' => '', 'sla_flags' => [], 'sla_flags_text' => '',
            'sla_history_complete' => false, 'sla_stored_within' => null, 'sla_difference' => false,
            'sla_pending_intervals' => [], 'sla_history_log_ids' => [],
            'sla_calendar_source' => '', 'sla_suspension_counter_matches' => null,
            'sla_upper_bound_seconds' => null, 'sla_provisional' => false,
        ];
        if (!$this->timezoneAvailable) {
            return $this->finish($out, 'Fuso horário da fonte não confirmado ou incompatível com os horários extraídos. A avaliação de SLA está pendente para evitar conversão incorreta dos prazos e calendários.');
        }
        $open = $this->time($ticket['opened_at'] ?? $ticket['date'] ?? null);
        $solved = $this->time($ticket['solved_at'] ?? $ticket['solvedate'] ?? null);
        $created = $this->time($ticket['created_at'] ?? $ticket['date_creation'] ?? null);
        $deadline = $this->time($ticket['deadline'] ?? $ticket['time_to_resolve'] ?? null);
        $priority = (int)($ticket['priority'] ?? 0);
        $slaId = (int)($ticket['sla_id'] ?? $ticket['slas_id_ttr'] ?? 0);
        $target = [2 => 28800, 3 => 21600, 4 => 14400, 5 => 7200][$priority] ?? null;
        $out['sla_target_seconds'] = $target;
        if ($deadline !== null && $solved !== null) {
            $out['sla_stored_within'] = $solved <= $deadline;
        } elseif ($deadline === null) {
            $out['sla_flags'][] = 'source_deadline_empty';
        }
        if ($open === null || $solved === null || $solved < $open) {
            return $this->finish($out, 'Datas de abertura e solução ausentes, inválidas ou invertidas.');
        }
        if ($target === null) {
            return $this->finish($out, 'Prioridade sem meta de solução configurada nesta apuração (códigos 2, 3, 4 e 5).');
        }
        $history = $this->history($ticket);
        $actualCreationAfterSolution = false;
        foreach ($history as $row) {
            if ($row['_ts'] > $solved && ((int)($row['linked_action'] ?? 0) === 20 || !empty($row['is_clone'])
                || ((int)($row['linked_action'] ?? 0) === 12
                    && preg_match('/\A(?:clone de|cloned from)\b/iu', (string)($row['new_value'] ?? ''))))) {
                $actualCreationAfterSolution = true;
                $out['sla_flags'][] = 'creation_log_after_solution';
                break;
            }
        }
        $changes = $this->changes($history, $open, $solved);
        $out['sla_flags'] = array_merge($out['sla_flags'], $changes['flags']);
        $out['sla_history_log_ids'] = $changes['log_ids'];
        if ($created === null || $created > $open + 5) {
            $out['sla_flags'][] = 'creation_after_opening';
        }
        if ($created !== null && $created > $solved) {
            $out['sla_flags'][] = 'creation_after_solution';
        }
        if ($changes['clone']) {
            $out['sla_flags'][] = 'copied_lifecycle';
        }
        $choice = $this->chooseCalendar($ticket, $history);
        $out['sla_calendar_id'] = $choice['id'];
        $out['sla_calendar_source'] = $choice['source'];
        if ($choice['id'] === null) {
            return $this->finish($out, $choice['reason']);
        }
        $calendarId = $choice['id'];
        $out['sla_calendar_name'] = $calendarId === 0 ? '24 horas / sem calendário restritivo'
            : (string)($this->context['calendars'][$calendarId]['name'] ?? ('Calendário #' . $calendarId));
        if (!empty($choice['historical'])) {
            $out['sla_flags'][] = 'calendar_from_history';
        }
        $gross = $this->activeSeconds($open, $solved, $calendarId);
        if ($gross === null) {
            return $this->finish($out, 'Calendário não acessível, segmentos inválidos ou período excessivo para reconstrução.');
        }
        $out['sla_gross_seconds'] = $gross;
        $state = $this->suspensions($history, $open, $solved, $created);
        $out['sla_pending_intervals'] = $state['intervals'];
        $out['sla_history_log_ids'] = array_values(array_unique(array_merge($out['sla_history_log_ids'], $state['log_ids'])));
        $out['sla_history_complete'] = $state['complete'] && !$changes['clone'] && !$actualCreationAfterSolution;
        $postdated = $this->calendarPostdatesTicket($calendarId, $open, $solved);
        if ($postdated) {
            $out['sla_flags'][] = 'calendar_changed_after_period';
        }
        if ($out['sla_history_complete']) {
            $pending = 0;
            foreach ($state['intervals'] as &$interval) {
                $seconds = $this->activeSeconds($interval['start_ts'], $interval['end_ts'], $calendarId);
                if ($seconds === null) {
                    return $this->finish($out, 'Não foi possível calcular todas as suspensões no calendário selecionado.');
                }
                $interval['seconds'] = $seconds;
                $interval['calendar_id'] = $calendarId;
                $pending += $seconds;
            }
            unset($interval);
            $out['sla_pending_intervals'] = $state['intervals'];
            $out['sla_pending_seconds'] = $pending;
            $out['sla_net_seconds'] = $out['sla_active_seconds'] = max(0, $gross - $pending);
            $waiting = $this->integer($ticket['waiting_seconds'] ?? $ticket['waiting_duration'] ?? null);
            $out['sla_suspension_counter_matches'] = $waiting === null ? null : $waiting === $pending;
            if ($waiting !== null && $waiting !== $pending) {
                $out['sla_flags'][] = 'suspension_counter_difference';
            }
            $stored = $this->integer($ticket['solve_seconds'] ?? $ticket['solve_delay_stat'] ?? null);
            if ($stored !== null && $stored !== $out['sla_net_seconds']) {
                $out['sla_flags'][] = 'stored_statistic_difference';
            }
            $out['sla_method'] = $changes['changed_clock'] ? 'reconstructed_current_calendar' : 'reconstructed';
            $out['within_sla'] = $out['sla_net_seconds'] <= $target;
            $out['sla_result'] = $out['within_sla'] ? 'within' : 'late';
            return $this->finish($out, 'Tempo útil entre abertura e solução, descontadas as suspensões (pendente e períodos solucionados/fechados antes de reabertura), todos no mesmo calendário selecionado. '
                . ($changes['changed_clock'] ? 'Houve mudança de nível, prioridade, entidade ou SLA; foi aplicada a política explícita de meta/prioridade e calendário do vínculo atual a todo o ciclo. ' : '')
                . ($postdated ? 'A configuração atual contém alterações posteriores ao atendimento; esta avaliação não certifica a configuração histórica. ' : '')
                . 'Prazo armazenado usado apenas para conferência.');
        }
        $out['sla_flags'][] = 'incomplete_history';
        // Even with copied/incomplete history, the complete active interval is
        // an upper bound for net time: subtracting any nonnegative suspension
        // cannot turn an interval already inside the target into a breach.
        // This proves a classification, never an invented exact duration.
        if ($gross <= $target && $created !== null && $created <= $solved && !$actualCreationAfterSolution) {
            $out['within_sla'] = true;
            $out['sla_result'] = 'within';
            $out['sla_method'] = 'within_by_upper_bound';
            $out['sla_upper_bound_seconds'] = $gross;
            return $this->finish($out, 'Cumprimento demonstrado pelo limite superior: o intervalo útil integral entre abertura e solução já é menor ou igual à meta. '
                . 'Qualquer suspensão não negativa somente reduz esse intervalo. O tempo líquido exato e o total de suspensões permanecem desconhecidos; não foram preenchidos com zero. '
                . 'Foi aplicado o calendário selecionado para o vínculo atual; alterações de grupo, prioridade e configuração estão identificadas nas ressalvas.');
        }
        // With incomplete histories, require independent consistency of ALL
        // stored clocks. A plausible deadline or a zero statistic is not enough.
        $agreement = $this->context['agreements'][$slaId] ?? null;
        $waiting = $this->integer($ticket['waiting_seconds'] ?? $ticket['waiting_duration'] ?? null);
        $slaWaiting = $this->integer($ticket['sla_waiting_seconds'] ?? $ticket['sla_waiting_duration'] ?? null);
        $statistic = $this->integer($ticket['solve_seconds'] ?? $ticket['solve_delay_stat'] ?? null);
        $copyRisk = $created === null || $created > $open + 5 || $changes['clone'] || $actualCreationAfterSolution
            || in_array('opening_changed', $out['sla_flags'], true);
        $sourceCalendar = $agreement ? $this->agreementCalendar($agreement, $ticket) : null;
        if (!$copyRisk && !$changes['changed_clock'] && !$postdated && $deadline !== null && $agreement
            && $sourceCalendar === $calendarId && $this->duration($agreement) === $target
            && $waiting !== null && $waiting >= 0 && $slaWaiting === $waiting
            && $statistic !== null && $statistic >= 0 && $statistic === max(0, $gross - $waiting)
            && $waiting <= $gross && empty($agreement['end_of_working_day'])) {
            $expected = $this->addActiveSeconds($open, $target + $slaWaiting, $calendarId);
            if ($expected !== null && abs($expected - $deadline) <= 1) {
                $out['sla_method'] = 'stored_validated';
                $out['sla_pending_seconds'] = $waiting;
                $out['sla_net_seconds'] = $out['sla_active_seconds'] = $statistic;
                $out['sla_suspension_counter_matches'] = true;
                $out['within_sla'] = $statistic <= $target;
                $out['sla_result'] = $out['within_sla'] ? 'within' : 'late';
                return $this->finish($out, 'Histórico incompleto; avaliação pelo relógio armazenado validado: meta e calendário do SLA conferem, contadores de suspensão geral/SLA coincidem, estatística útil e reconstrução do prazo conferem. Os intervalos históricos não foram presumidos.');
            }
        }
        return $this->finish($out, 'Meta aplicável identificada, mas a cadeia histórica não permite reconstruir todas as suspensões e os relógios armazenados não passaram em todas as verificações independentes. '
            . 'O chamado permanece elegível no recorte, com apuração pendente; não é considerado automaticamente no prazo ou fora do prazo.');
    }

    private function history(array $ticket): array
    {
        $rows = $ticket['sla_history'] ?? $this->context['histories'][(int)($ticket['id'] ?? 0)] ?? [];
        $history = [];
        foreach ($rows as $row) {
            $time = $this->time($row['date_mod'] ?? $row['at'] ?? null);
            if ($time === null) {
                continue;
            }
            $row['_ts'] = $time;
            $row['_id'] = (int)($row['id'] ?? $row['log_id'] ?? 0);
            $history[] = $row;
        }
        usort($history, static function (array $a, array $b): int {
            return [$a['_ts'], $a['_id']] <=> [$b['_ts'], $b['_id']];
        });
        return $history;
    }

    private function changes(array $history, int $open, int $solved): array
    {
        $result = ['flags' => [], 'changed_clock' => false, 'clone' => false, 'log_ids' => []];
        foreach ($history as $row) {
            $option = (int)($row['id_search_option'] ?? 0);
            $action = (int)($row['linked_action'] ?? 0);
            $at = $row['_ts'];
            if (!empty($row['is_clone']) || ($option === 0 && in_array($action, [0, 12], true)
                && preg_match('/\A(?:clone de|cloned from|clonagem|clon[ée])\b/iu', (string)($row['new_value'] ?? '')))) {
                $result['clone'] = true;
            }
            if ($at > $solved && ((in_array($option, [3, 15, 30, 80], true) && $action === 0)
                || (($row['itemtype_link'] ?? '') === 'Group' && ($option === 8 || $action === 16)))) {
                $result['flags'][] = 'post_solution_change';
                $result['log_ids'][] = $row['_id'];
                $result['changed_clock'] = true;
            }
            if ($at < $open || $at > $solved) {
                continue;
            }
            $flag = null;
            if ($option === 30 && $action === 0) {
                $old = $this->valueId($row, 'old');
                $new = $this->valueId($row, 'new');
                if ($new === 0 && $old > 0) {
                    $flag = 'sla_removed';
                } elseif ($new > 0 && $old === 0 && $at > $open + 5) {
                    $flag = 'sla_assigned_late';
                } elseif ($old !== $new) {
                    $flag = 'sla_changed';
                }
                if ($old !== $new && $at > $open + 5) {
                    $result['changed_clock'] = true;
                }
            } elseif ($option === 18 && $action === 0 && trim((string)($row['new_value'] ?? '')) === '') {
                $flag = 'deadline_removed';
            } elseif (in_array($option, [3, 80], true) && $action === 0 && $at > $open + 5) {
                $flag = $option === 3 ? 'priority_changed' : 'entity_changed';
                $result['changed_clock'] = true;
            } elseif (($row['itemtype_link'] ?? '') === 'Group' && ($option === 8 || $action === 16) && $at > $open + 5) {
                $flag = 'group_changed';
                $result['changed_clock'] = true;
            } elseif ($option === 15 && $action === 0) {
                $flag = 'opening_changed';
                $result['changed_clock'] = true;
            }
            if ($flag !== null) {
                $result['flags'][] = $flag;
                $result['log_ids'][] = $row['_id'];
            }
        }
        return $result;
    }

    private function chooseCalendar(array $ticket, array $history): array
    {
        $groups = array_map('intval', $ticket['group_ids'] ?? []);
        $levels = [];
        foreach (['n1', 'n2', 'n3'] as $level) {
            if (array_intersect($groups, $this->input[$level . '_group_ids'] ?? [])) {
                $levels[] = $level;
            }
        }
        if (count($levels) > 1) {
            return ['id' => null, 'source' => '', 'reason' => 'Vínculos atuais a mais de um nível de atendimento: calendário de apuração ambíguo.'];
        }
        $level = $levels[0] ?? null;
        $override = $level === null ? 0 : (int)($this->input['sla_' . $level . '_calendar_id'] ?? 0);
        if ($override > 0) {
            return ['id' => isset($this->context['calendars'][$override]) ? $override : null,
                'source' => 'selected_' . $level, 'reason' => 'Calendário selecionado não encontrado no catálogo acessível.'];
        }
        if ($level === 'n1' || $level === 'n2') {
            $candidates = [];
            foreach ($this->context['agreements'] ?? [] as $agreement) {
                if ((int)($agreement['type'] ?? 0) !== 0 || !preg_match('/\b' . $level . '\b/i', (string)($agreement['name'] ?? ''))
                    || $this->duration($agreement) === null || !$this->agreementApplies($agreement, $ticket)) {
                    continue;
                }
                $id = $this->agreementCalendar($agreement, $ticket);
                if ($id !== null) {
                    $candidates[$id] = $id;
                }
            }
            if (count($candidates) === 1) {
                return ['id' => reset($candidates), 'source' => 'catalog_' . $level, 'reason' => ''];
            }
            return ['id' => null, 'source' => '', 'reason' => count($candidates) > 1
                ? 'SLAs do nível atual apontam para calendários distintos. Selecione explicitamente o calendário na configuração do relatório.'
                : 'Calendário do nível atual não identificado de forma única no catálogo de SLAs. Selecione explicitamente o calendário na configuração do relatório.'];
        }
        $bound = $this->context['agreements'][(int)($ticket['sla_id'] ?? $ticket['slas_id_ttr'] ?? 0)] ?? null;
        if ($bound && (int)($bound['type'] ?? 0) === 0) {
            $id = $this->agreementCalendar($bound, $ticket);
            if ($id !== null) {
                return ['id' => $id, 'source' => 'bound_sla', 'reason' => ''];
            }
        }
        $candidates = [];
        $solved = $this->time($ticket['solved_at'] ?? $ticket['solvedate'] ?? null);
        foreach ($history as $row) {
            if ((int)($row['id_search_option'] ?? 0) !== 30 || (int)($row['linked_action'] ?? 0) !== 0
                || ($solved !== null && $row['_ts'] > $solved)) {
                continue;
            }
            foreach (['old', 'new'] as $side) {
                $id = $this->valueId($row, $side);
                $agreement = $this->context['agreements'][$id] ?? null;
                if (!$agreement || (int)($agreement['type'] ?? 0) !== 0) {
                    continue;
                }
                $calendar = $this->agreementCalendar($agreement, $ticket);
                if ($calendar !== null) {
                    $candidates[$calendar] = $calendar;
                }
            }
        }
        if (count($candidates) === 1) {
            return ['id' => reset($candidates), 'source' => 'historical_sla', 'historical' => true, 'reason' => ''];
        }
        return ['id' => null, 'source' => '', 'reason' => 'Sem calendário de apuração unívoco para o nível atual: nenhum SLA positivo aplicável, histórico ausente ou calendários históricos divergentes. A ausência de vínculo SLA não elimina a meta de prioridade.'];
    }

    /** Catalogue discovery respects entity scope; an observed bound SLA remains evidence. */
    private function agreementApplies(array $agreement, array $ticket): bool
    {
        if (!array_key_exists('entities_id', $agreement)) {
            return false;
        }
        $owner = (int)$agreement['entities_id'];
        $id = (int)($ticket['entity_id'] ?? $ticket['entities_id'] ?? 0);
        if ($owner === $id) {
            return true;
        }
        if (empty($agreement['is_recursive'])) {
            return false;
        }
        $seen = [];
        while (!isset($seen[$id])) {
            $seen[$id] = true;
            $entity = $this->context['entities'][$id] ?? null;
            if (!$entity) {
                return false;
            }
            $id = (int)($entity['entities_id'] ?? $entity['parent_entities_id'] ?? 0);
            if ($id === $owner) {
                return true;
            }
        }
        return false;
    }

    private function agreementCalendar(array $agreement, array $ticket): ?int
    {
        if (!empty($agreement['use_ticket_calendar'])) {
            $id = (int)($ticket['entity_id'] ?? $ticket['entities_id'] ?? 0);
            $seen = [];
            while (!isset($seen[$id])) {
                $seen[$id] = true;
                $entity = $this->context['entities'][$id] ?? null;
                if (!$entity) {
                    return null;
                }
                $calendar = (int)($entity['calendars_id'] ?? -1);
                if ((int)($entity['calendars_strategy'] ?? $calendar) !== -2 && $calendar !== -2) {
                    return $this->knownCalendar($calendar);
                }
                $id = (int)($entity['entities_id'] ?? $entity['parent_entities_id'] ?? 0);
            }
            return null;
        }
        return $this->knownCalendar((int)($agreement['calendars_id'] ?? $agreement['parent_slm_calendars_id'] ?? -1));
    }

    private function knownCalendar(int $id): ?int
    {
        return $id === 0 || isset($this->context['calendars'][$id]) ? $id : null;
    }

    private function duration(array $agreement): ?int
    {
        $number = $this->integer($agreement['number_time'] ?? null);
        $multiplier = ['minute' => 60, 'hour' => 3600, 'day' => 86400][(string)($agreement['definition_time'] ?? '')] ?? null;
        return $number !== null && $number > 0 && $multiplier !== null ? $number * $multiplier : null;
    }

    private function suspensions(array $history, int $open, int $solved, ?int $created): array
    {
        $result = ['complete' => false, 'intervals' => [], 'log_ids' => []];
        if (empty($this->context['history_available']) || $created === null || $created > $open + 5) {
            return $result;
        }
        $creation = false;
        $events = [];
        foreach ($history as $row) {
            if ((int)($row['linked_action'] ?? 0) === 20 && abs($row['_ts'] - $created) <= 5) {
                $creation = true;
                $result['log_ids'][] = $row['_id'];
            }
            if ((int)($row['id_search_option'] ?? 0) === 12 && (int)($row['linked_action'] ?? 0) === 0
                && $row['_ts'] >= $open && $row['_ts'] <= $solved) {
                $events[] = $row;
            }
        }
        if (!$creation || !$events) {
            return $result;
        }
        $state = $this->valueId($events[0], 'old');
        if ($state < 1 || $state > 6) {
            return $result;
        }
        $cursor = $open;
        $valid = true;
        $solutionAtEnd = false;
        foreach ($events as $event) {
            $old = $this->valueId($event, 'old');
            $new = $this->valueId($event, 'new');
            if ($old !== $state || $new < 1 || $new > 6) {
                $valid = false;
                break;
            }
            if (in_array($state, [4, 5, 6], true) && $event['_ts'] > $cursor) {
                $result['intervals'][] = ['start' => $this->format($cursor), 'end' => $this->format($event['_ts']),
                    'start_ts' => $cursor, 'end_ts' => $event['_ts'], 'status' => $state,
                    'exit_log_id' => $event['_id']];
            }
            $result['log_ids'][] = $event['_id'];
            $cursor = $event['_ts'];
            $state = $new;
            if ($new === 5 && abs($cursor - $solved) <= 1) {
                $solutionAtEnd = true;
            }
        }
        $result['complete'] = $valid && $solutionAtEnd && in_array($state, [5, 6], true);
        return $result;
    }

    /** Positive number of active seconds; null means uncomputable, never zero by default. */
    private function activeSeconds(int $start, int $end, int $calendarId): ?int
    {
        if ($end < $start || $end - $start > 3660 * 86400) {
            return null;
        }
        if ($calendarId === 0) {
            return $end - $start;
        }
        $total = 0;
        $day = (new \DateTimeImmutable('@' . $start))->setTimezone($this->zone)->setTime(0, 0);
        while ($day->getTimestamp() < $end) {
            $intervals = $this->dayIntervals($calendarId, $day);
            if ($intervals === null) {
                return null;
            }
            foreach ($intervals as $interval) {
                $total += max(0, min($end, $interval[1]) - max($start, $interval[0]));
            }
            $day = $day->modify('+1 day');
        }
        return $total;
    }

    private function addActiveSeconds(int $start, int $seconds, int $calendarId): ?int
    {
        if ($seconds < 0) {
            return null;
        }
        if ($calendarId === 0) {
            return $start + $seconds;
        }
        $day = (new \DateTimeImmutable('@' . $start))->setTimezone($this->zone)->setTime(0, 0);
        for ($i = 0; $i < 3660; $i++, $day = $day->modify('+1 day')) {
            $intervals = $this->dayIntervals($calendarId, $day);
            if ($intervals === null) {
                return null;
            }
            foreach ($intervals as $interval) {
                $from = max($start, $interval[0]);
                $available = max(0, $interval[1] - $from);
                if ($available >= $seconds && $from <= $interval[1]) {
                    return $from + $seconds;
                }
                $seconds -= $available;
            }
        }
        return null;
    }

    private function dayIntervals(int $calendarId, \DateTimeImmutable $day): ?array
    {
        $date = $day->format('Y-m-d');
        $key = $calendarId . ':' . $date;
        if (array_key_exists($key, $this->days)) {
            return $this->days[$key];
        }
        $calendar = $this->context['calendars'][$calendarId] ?? null;
        if (!$calendar || empty($calendar['segments']) || !is_array($calendar['segments'])) {
            return $this->days[$key] = null;
        }
        foreach ($calendar['holidays'] ?? [] as $holiday) {
            if ($this->isHoliday($date, $holiday)) {
                return $this->days[$key] = [];
            }
        }
        $intervals = [];
        foreach ($calendar['segments'] as $segment) {
            $weekday = (int)($segment['day'] ?? $segment['day_raw'] ?? -1);
            if ($weekday !== (int)$day->format('w')) {
                continue;
            }
            $begin = $this->daySecond($segment['begin'] ?? $segment['begin_raw'] ?? null);
            $end = $this->daySecond($segment['end'] ?? $segment['end_raw'] ?? null);
            if ($begin === null || $end === null || $end < $begin) {
                return $this->days[$key] = null;
            }
            // Calendar segments are local wall times. setTime handles timezone
            // changes correctly instead of treating every local day as 86400 s.
            $a = $day->setTime(intdiv($begin, 3600), intdiv($begin % 3600, 60), $begin % 60)->getTimestamp();
            $b = $day->setTime(intdiv($end, 3600), intdiv($end % 3600, 60), $end % 60)->getTimestamp();
            $intervals[] = [$a, $b];
        }
        usort($intervals, static function (array $a, array $b): int { return $a[0] <=> $b[0]; });
        $merged = [];
        foreach ($intervals as $interval) {
            $last = count($merged) - 1;
            if ($last >= 0 && $interval[0] <= $merged[$last][1]) {
                $merged[$last][1] = max($merged[$last][1], $interval[1]);
            } else {
                $merged[] = $interval;
            }
        }
        return $this->days[$key] = $merged;
    }

    private function isHoliday(string $date, array $holiday): bool
    {
        $begin = substr((string)($holiday['begin_date'] ?? ''), 0, 10);
        $end = substr((string)($holiday['end_date'] ?? ''), 0, 10);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/D', $begin) || !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $end)) {
            return false;
        }
        if (!empty($holiday['is_perpetual'])) {
            $begin = substr($begin, 5);
            $end = substr($end, 5);
            $date = substr($date, 5);
            return $begin <= $end ? ($date >= $begin && $date <= $end) : ($date >= $begin || $date <= $end);
        }
        return $date >= $begin && $date <= $end;
    }

    private function calendarPostdatesTicket(int $calendarId, int $start, int $end): bool
    {
        if ($calendarId === 0) {
            return false;
        }
        $calendar = $this->context['calendars'][$calendarId] ?? [];
        $modified = $this->time($calendar['date_mod'] ?? null);
        if ($modified !== null && $modified > $end) {
            return true;
        }
        $startDate = $this->format($start);
        $endDate = $this->format($end);
        foreach ($calendar['holidays'] ?? [] as $holiday) {
            $created = $this->time($holiday['date_creation'] ?? null);
            if ($created === null || $created <= $end) {
                continue;
            }
            // Only flag a later holiday whose dates overlap the measured cycle.
            $day = (new \DateTimeImmutable($startDate, $this->zone))->setTime(0, 0);
            for ($i = 0; $i < 3660 && $day->format('Y-m-d') <= substr($endDate, 0, 10); $i++, $day = $day->modify('+1 day')) {
                if ($this->isHoliday($day->format('Y-m-d'), $holiday)) {
                    return true;
                }
            }
        }
        return false;
    }

    private function valueId(array $row, string $side): ?int
    {
        $numeric = $this->integer($row[$side . '_id'] ?? null);
        if ($numeric !== null && $numeric > 0) {
            return $numeric;
        }
        $value = trim((string)($row[$side . '_value'] ?? ''));
        if (preg_match('/\A\d+\z/D', $value)) {
            return (int)$value;
        }
        return preg_match('/\((\d+)\)\s*$/D', $value, $matches) ? (int)$matches[1] : $numeric;
    }

    private function integer($value): ?int
    {
        return $value !== null && preg_match('/\A-?\d+\z/D', (string)$value) ? (int)$value : null;
    }

    private function time($value): ?int
    {
        if (!is_string($value) || !preg_match('/\A(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})(?:\.\d+)?\z/D', $value, $match)) {
            return null;
        }
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $match[1], $this->zone);
        return $date && $date->format('Y-m-d H:i:s') === $match[1] ? $date->getTimestamp() : null;
    }

    private function format(int $time): string
    {
        return (new \DateTimeImmutable('@' . $time))->setTimezone($this->zone)->format('Y-m-d H:i:s');
    }

    private function daySecond($value): ?int
    {
        if (!is_string($value) || !preg_match('/\A(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?\z/D', $value, $match)) {
            return null;
        }
        $seconds = (int)$match[1] * 3600 + (int)$match[2] * 60 + (int)$match[3];
        return (int)$match[2] < 60 && (int)$match[3] < 60 && $seconds <= 86400 ? $seconds : null;
    }

    private function finish(array $out, string $reason): array
    {
        $labels = [
            'source_deadline_empty' => 'Prazo original vazio', 'sla_removed' => 'SLA removido no histórico',
            'sla_assigned_late' => 'SLA atribuído após a abertura', 'sla_changed' => 'SLA alterado durante o atendimento',
            'deadline_removed' => 'Prazo removido no histórico', 'priority_changed' => 'Prioridade alterada',
            'entity_changed' => 'Entidade alterada', 'group_changed' => 'Grupo alterado',
            'opening_changed' => 'Data de abertura alterada', 'creation_after_opening' => 'Criação não coincide com a abertura',
            'creation_after_solution' => 'Linha criada após a solução', 'copied_lifecycle' => 'Clonagem registrada',
            'creation_log_after_solution' => 'Evento de criação/clonagem posterior à solução',
            'calendar_from_history' => 'Calendário recuperado de vínculo SLA histórico',
            'calendar_changed_after_period' => 'Configuração atual alterada após o atendimento',
            'suspension_counter_difference' => 'Suspensão recalculada difere do contador original',
            'stored_statistic_difference' => 'Tempo útil recalculado difere da estatística original',
            'incomplete_history' => 'Histórico insuficiente para reconstrução integral',
            'post_solution_change' => 'Grupo, prioridade, entidade, SLA ou abertura alterados após a solução; critério atual explicitamente aplicado',
        ];
        $out['sla_flags'] = array_values(array_unique($out['sla_flags']));
        $out['sla_flags_text'] = implode('; ', array_map(static function (string $flag) use ($labels): string {
            return $labels[$flag] ?? $flag;
        }, $out['sla_flags']));
        $out['sla_reason'] = $reason;
        $out['sla_provisional'] = (bool)array_intersect($out['sla_flags'], [
            'priority_changed', 'entity_changed', 'group_changed', 'opening_changed',
            'sla_changed', 'sla_removed', 'sla_assigned_late',
            'calendar_from_history', 'calendar_changed_after_period', 'post_solution_change',
        ]);
        $out['sla_difference'] = $out['within_sla'] !== null && $out['sla_stored_within'] !== null && $out['within_sla'] !== $out['sla_stored_within'];
        return $out;
    }
}
