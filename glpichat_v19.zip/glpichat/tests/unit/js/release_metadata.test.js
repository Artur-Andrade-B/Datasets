import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = resolve(import.meta.dirname, "../../..");
const readText = (relativePath) => readFileSync(resolve(root, relativePath), "utf8");

describe("desktop10fix1 release metadata and inherited foundation helper", () => {
  it("keeps plugin, catalogue, package and manifest versions aligned", () => {
    const setup = readText("setup.php");
    const pluginXml = readText("plugin.xml");
    const packageJson = JSON.parse(readText("package.json"));
    const packageLock = JSON.parse(readText("package-lock.json"));
    const manifest = JSON.parse(readText("release-manifest.json"));
    const runbook = readText("docs/releases/1.6.1-desktop10fix1.md");
    const builder = readText("tests/qualification/build_release.sh");
    const foundationRunbook = readText("docs/releases/1.0.6-foundation1.md");
    const qualificationHelper = readText("tests/qualification/foundation_shadow.php");

    expect(setup).toContain("define('PLUGIN_GLPICHAT_VERSION', '1.6.1');");
    expect(setup).toContain("define('PLUGIN_GLPICHAT_BUILD', 'desktop10fix1');");
    expect(pluginXml).toContain("<num>1.6.1</num>");
    expect(pluginXml).not.toContain("/refs/tags/v1.0.6.zip");
    expect(packageJson.version).toBe("1.6.1");
    expect(packageLock.version).toBe("1.6.1");
    expect(packageLock.packages[""].version).toBe("1.6.1");
    expect(manifest).toMatchObject({
      plugin: "glpichat",
      version: "1.6.1",
      build: "desktop10fix1",
      build_date: "2026-10-05",
      baseline: {
        version: "1.0.6",
        build: "foundation1",
      },
      parent_candidate: {
        version: "1.6.0",
        build: "desktop10",
      },
      browser_surface_default_enabled: false,
      public_authorization_shadow_default_enabled: false,
      foundation_schema_version: 1,
      foundation_scope: [
        "immutable_actor_context",
        "pure_public_authorization_policy",
        "non_authoritative_public_authorization_shadow",
        "read_only_schema_health_snapshot",
      ],
      external_desktop_api_included: true,
      external_routes_added: true,
      desktop_default_enabled: false,
      desktop_schema_version: 7,
      desktop_client_version: "0.6.0",
      database_tables_added: [
        "glpi_plugin_glpichat_desktopdevices",
        "glpi_plugin_glpichat_desktopsends",
        "glpi_plugin_glpichat_desktopreads",
        "glpi_plugin_glpichat_desktopgrants",
        "glpi_plugin_glpichat_desktopregistrations",
        "glpi_plugin_glpichat_desktopreleases",
        "glpi_plugin_glpichat_desktopmachinegrants",
        "glpi_plugin_glpichat_desktopmachines",
        "glpi_plugin_glpichat_desktopassignments",
        "glpi_plugin_glpichat_desktopautobindings",
        "glpi_plugin_glpichat_browsersends",
        "glpi_plugin_glpichat_notificationjobs",
        "glpi_plugin_glpichat_desktoprollouts",
        "glpi_plugin_glpichat_desktoprollouttargets",
        "glpi_plugin_glpichat_guestsends",
      ],
      cron_tasks_added: ["DeliverChatNotifications", "ProcessDesktopRollouts"],
      runtime_dependencies_added: [],
    });
    expect(manifest.archive.source_date_epoch).toBe(1791158400);
    expect(builder).toContain(`touch -h -d '@${manifest.archive.source_date_epoch}'`);
    expect(new Date(manifest.archive.source_date_epoch * 1000).toISOString().slice(0, 10)).toBe(manifest.build_date);
    expect(runbook).toContain("GLPIChat 1.6.1-desktop10fix1");
    expect(runbook).toContain("Windows 0.6.0");
    expect(manifest.desktop_schema_version).toBe(7);
    expect(foundationRunbook).toContain("# GLPI Chat 1.0.6-foundation1");

    const helperCommand =
      "docker exec glpi php /var/www/glpi/plugins/glpichat/tests/qualification/foundation_shadow.php";
    expect(foundationRunbook).toContain(`${helperCommand} status`);
    expect(foundationRunbook).toContain(`${helperCommand} enable`);
    expect(foundationRunbook).toContain(`${helperCommand} disable`);
    expect(foundationRunbook.split(`${helperCommand} status`).length - 1).toBe(3);

    expect(qualificationHelper).toContain('if (PHP_SAPI !== \'cli\')');
    expect(qualificationHelper).toContain("Usage: php foundation_shadow.php [status|enable|disable]");
    expect(qualificationHelper).toContain("['status', 'enable', 'disable']");
    expect(qualificationHelper).toContain("$argv[1] ?? 'status'");
    expect(qualificationHelper).toContain("$action === 'enable'");
    expect(qualificationHelper).toContain("$action === 'disable'");
    expect(qualificationHelper).toContain("foundation_schema_version >= 1");
    expect(qualificationHelper).toContain("Config::setConfigurationValues");
    expect(qualificationHelper).toContain("Config::getConfigurationValue");
    expect(qualificationHelper).toContain("Shadow flag read-back did not match");
    expect(qualificationHelper).not.toMatch(/\$DB|glpi_configs|->(?:insert|update|delete|doQuery)\s*\(/);
    expect(qualificationHelper).not.toContain("browser_surface_enabled");

    const cliGuard = qualificationHelper.indexOf("if (PHP_SAPI !== 'cli')");
    const bootstrap = qualificationHelper.indexOf("/vendor/autoload.php");
    const markerRead = qualificationHelper.indexOf("Config::getConfigurationValue($context, $markerKey)");
    const markerGate = qualificationHelper.indexOf("if (!$markerIsAdopted)");
    const enableWrite = qualificationHelper.indexOf("Config::setConfigurationValues($context, [$flagKey => '1'])");
    const disableWrite = qualificationHelper.indexOf("Config::setConfigurationValues($context, [$flagKey => '0'])");
    const flagReadBack = qualificationHelper.indexOf("Config::getConfigurationValue($context, $flagKey)");
    const strictReadBack = qualificationHelper.indexOf("$rawFlag === 1 || $rawFlag === '1'");
    expect(cliGuard).toBeGreaterThanOrEqual(0);
    expect(bootstrap).toBeGreaterThan(cliGuard);
    expect(markerRead).toBeGreaterThan(bootstrap);
    expect(markerGate).toBeGreaterThan(markerRead);
    expect(enableWrite).toBeGreaterThan(markerGate);
    expect(disableWrite).toBeGreaterThan(enableWrite);
    expect(flagReadBack).toBeGreaterThan(disableWrite);
    expect(strictReadBack).toBeGreaterThan(flagReadBack);
    expect(qualificationHelper.split("Config::setConfigurationValues").length - 1).toBe(2);
  });
});
