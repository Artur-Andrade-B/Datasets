<?php

declare(strict_types=1);

/** Presentation only. Reading this page never starts, registers or resets cron. */
function glpichat_management_queue_state_label(string $state, string $reason = '', bool $rollout = false): string
{
    if ($reason === 'dispatch_failed' || $state === 'dispatch_failed') { return 'Falha na distribuição pelo servidor'; }
    if ($reason === 'storage_retry' || $state === 'dispatch_retry') { return 'Aguardando nova tentativa de distribuição'; }
    return match ($state) {
        'queued' => 'Na fila — aguardando distribuição',
        'waiting' => 'Aguardando a operação anterior',
        'assigned', 'pending' => 'Distribuído — aguardando contato do computador',
        'started' => 'Em execução no computador',
        'running' => 'Lote em andamento',
        'completed' => $rollout ? 'Processamento do lote encerrado' : 'Concluído pelo computador',
        'failed' => 'Falha informada pelo computador',
        'skipped' => 'Não executado',
        'superseded' => 'Substituído por outra solicitação',
        'none' => 'Nenhuma',
        default => 'Estado não informado',
    };
}

/** Native GLPI fields describe scheduler observations, never fleet success. */
function glpichat_management_cron_health_view(?array $row): array
{
    if ($row === null) {
        return ['status' => 'Ação auxiliar não registrada', 'mode' => 'Não informado', 'last_run' => 'Nenhuma execução registrada', 'tone' => 'warning'];
    }
    $mode = match ((int) ($row['mode'] ?? 0)) {
        1 => 'GLPI (interno)',
        2 => 'Externo (CLI)',
        default => 'Modo não informado',
    };
    $lastRun = trim((string) ($row['lastrun'] ?? ''));
    $neverRun = $lastRun === '' || $lastRun === '0000-00-00 00:00:00';
    $state = (int) ($row['state'] ?? -1);
    $status = match ($state) {
        0 => 'Ação auxiliar desativada',
        1 => $neverRun ? 'Habilitada, sem execução registrada' : 'Habilitada, aguardando execução',
        2 => 'Em execução segundo o GLPI',
        default => 'Estado da ação auxiliar não informado',
    };
    return ['status' => $status, 'mode' => $mode,
        'last_run' => $neverRun ? 'Nenhuma execução registrada' : $lastRun,
        'tone' => $state === 0 || $neverRun ? 'warning' : 'info'];
}

/** One exact native task lookup; no machine scan or scheduler side effects. */
function glpichat_management_queue_health(): array
{
    try {
        $rows = glpichat_desktop_db_rows('SELECT id,mode,state,lastrun FROM glpi_crontasks WHERE itemtype='
            . glpichat_desktop_quote('GlpiPlugin\\Glpichat\\DesktopRolloutCron')
            . " AND name='ProcessDesktopRollouts' LIMIT 1");
        return glpichat_management_cron_health_view($rows[0] ?? null) + ['reference' => ''];
    } catch (Throwable $error) {
        return ['status' => 'Não foi possível consultar a ação auxiliar', 'mode' => 'Não informado',
            'last_run' => 'Não consultado', 'tone' => 'warning',
            'reference' => glpichat_desktop_log_failure('management_queue_health', $error)];
    }
}
