<?php

declare(strict_types=1);

require_once __DIR__ . '/management.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/provision.php';

const GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE = 'glpi_plugin_glpichat_desktopautobindings';

function glpichat_desktop_automatic_require_schema(): void
{
    glpichat_desktop_auth_available();
    if (!in_array((string) glpichat_desktop_config('desktop_schema_version'), ['4', '5', '6', '7'], true)) {
        glpichat_desktop_fail('schema_unavailable', 'Conclua a atualização do plugin para conectar automaticamente.', 503);
    }
}

/** Exact AD objectSid octets; each byte is escaped, never interpolated as LDAP syntax. */
function glpichat_desktop_automatic_sid_filter(string $sid): string
{
    [$sid] = glpichat_desktop_delivery_identity($sid, 'VALIDATION');
    $parts = explode('-', $sid);
    $bytes = chr(1) . chr(count($parts) - 3) . "\0\0\0\0\0\5";
    foreach (array_slice($parts, 3) as $part) { $bytes .= pack('V', (int) $part); }
    return implode('', array_map(static fn(string $byte): string => '\\' . bin2hex($byte), str_split($bytes)));
}

/** Reuse GLPI's connection/secret/TLS/replica configuration. No new directory credentials. */
function glpichat_desktop_automatic_ldap(array $source, string $sid): array
{
    if (!function_exists('ldap_search')) {
        glpichat_desktop_fail('directory_unavailable', 'A consulta ao diretório está indisponível.', 503);
    }
    $login = strtolower(trim((string) ($source['login_field'] ?? '')));
    $sync = strtolower(trim((string) ($source['sync_field'] ?? '')));
    foreach ([$login, $sync] as $attribute) {
        if (preg_match('/\A[a-z][a-z0-9;-]{0,127}\z/D', $attribute) !== 1) {
            glpichat_desktop_fail('directory_unavailable', 'Verifique os atributos do diretório no GLPI.', 503);
        }
    }
    $connection = false;
    try {
        $connection = @AuthLDAP::tryToConnectToServer($source, '', '');
        if ($connection === false) { throw new RuntimeException('LDAP connection failed.'); }
        $condition = trim((string) ($source['condition'] ?? ''));
        $filter = '(&(objectClass=user)(objectCategory=person)(objectSid=' . glpichat_desktop_automatic_sid_filter($sid) . ')'
            . ($condition !== '' ? $condition : '') . ')';
        $attributes = array_values(array_unique([$login, $sync, 'objectguid', 'objectsid', 'useraccountcontrol']));
        // A partial search result is never sufficient evidence of unique identity.
        $result = @ldap_search($connection, (string) $source['basedn'], $filter, $attributes, 0, 2, 10);
        if ($result === false || ldap_errno($connection) !== 0) { throw new RuntimeException('LDAP search incomplete.'); }
        $error = false;
        $entries = AuthLDAP::get_entries_clean($connection, $result, $error);
        if ($error || !isset($entries['count'])) { throw new RuntimeException('LDAP result unavailable.'); }
        $rows = [];
        for ($i = 0; $i < (int) $entries['count']; $i++) {
            $entry = $entries[$i];
            if (($entry['useraccountcontrol']['count'] ?? 0) !== 1 || !ctype_digit((string) ($entry['useraccountcontrol'][0] ?? ''))) { throw new RuntimeException('LDAP account status unavailable.'); }
            if (((int) $entry['useraccountcontrol'][0] & 2) !== 0) { continue; }
            foreach ([$login, $sync, 'objectguid', 'objectsid'] as $attribute) {
                if (($entry[$attribute]['count'] ?? 0) !== 1 || !is_string($entry[$attribute][0] ?? null)) {
                    throw new RuntimeException('LDAP identity attribute unavailable.');
                }
            }
            $sidHex = implode('', array_map(static fn(string $byte): string => '\\' . bin2hex($byte), str_split($entry['objectsid'][0])));
            if (!hash_equals(glpichat_desktop_automatic_sid_filter($sid), $sidHex)) { throw new RuntimeException('LDAP SID mismatch.'); }
            $loginValue = AuthLDAP::getFieldValue($entry, $login);
            if (!is_string($loginValue)) { throw new RuntimeException('LDAP login unavailable.'); }
            $rows[] = ['login' => $loginValue, 'object_guid' => $entry['objectguid'][0], 'sync_value' => $entry[$sync][0]];
        }
        return $rows;
    } catch (Throwable $error) {
        // Exception messages may contain directory credentials or server details.
        glpichat_desktop_fail('directory_unavailable', 'Não foi possível consultar o diretório configurado no GLPI.', 503);
    } finally {
        if ($connection !== false) { @ldap_unbind($connection); }
    }
}

/** The broker attests SID; AD supplies stable account anchor, GLPI supplies authorization. */
function glpichat_desktop_automatic_resolve(string $sid, ?callable $directoryReader = null): array
{
    $directoryReader ??= 'glpichat_desktop_automatic_ldap';
    $sources = glpichat_desktop_db_rows('SELECT * FROM glpi_authldaps WHERE is_active=1');
    $matches = [];
    foreach ($sources as $source) {
        $rows = $directoryReader($source, $sid);
        if (count($rows) > 1) { glpichat_desktop_fail('directory_identity_ambiguous', 'A identidade não é única nos diretórios configurados.', 409); }
        foreach ($rows as $row) { $matches[] = [$source, $row]; }
    }
    if (!$matches) { glpichat_desktop_fail('directory_identity_missing', 'A conta Windows não foi encontrada no diretório ativo.', 403); }
    if (count($matches) !== 1) { glpichat_desktop_fail('directory_identity_ambiguous', 'A identidade não é única nos diretórios configurados.', 409); }
    [$source, $row] = $matches[0];
    try { $user = glpichat_desktop_provision_user($row, $source); }
    catch (RuntimeException $e) { glpichat_desktop_fail('directory_identity_missing', 'Sincronize esta conta do diretório existente no GLPI.', 403); }
    try { $facts = glpichat_desktop_provision_context($user, null, null); }
    catch (RuntimeException $e) { glpichat_desktop_fail('automatic_context_unavailable', 'Verifique o perfil padrão, a entidade e as permissões de chat da conta no GLPI.', 403); }
    $checked = ['users_id' => (int) $user['id'], 'auths_id' => (int) $source['id'],
        'sync_anchor' => glpichat_desktop_auth_hash('directory-anchor', (string) $user['sync_field']),
        'user_incarnation' => glpichat_desktop_auth_hash('user-incarnation', (string) $user['date_creation'] . "\0" . (int) $user['authtype']),
        'auth_source_fingerprint' => 'v2:' . substr(glpichat_desktop_auth_hash('source-identity-v2',
            serialize([(string) $source['id'], (string) $source['date_creation'], strtolower(trim((string) $source['sync_field']))])), 0, 61)];
    if (!glpichat_desktop_automatic_identity_matches($checked, $facts)) {
        glpichat_desktop_fail('automatic_identity_changed', 'A conta mudou durante a consulta ao diretório. Tente novamente.', 409);
    }
    return $facts;
}

function glpichat_desktop_automatic_identity_matches(array $binding, array $facts): bool
{
    foreach (['users_id' => 'user_id', 'auths_id' => 'auths_id'] as $left => $right) {
        if ((int) ($binding[$left] ?? 0) !== (int) ($facts[$right] ?? 0)) { return false; }
    }
    foreach (['sync_anchor', 'user_incarnation', 'auth_source_fingerprint'] as $field) {
        if (!hash_equals((string) ($binding[$field] ?? ''), (string) ($facts[$field] ?? ''))) { return false; }
    }
    return true;
}

/** Device/registration/grant order matches Enroll/Renew, including first-enrollment races. */
function glpichat_desktop_automatic_lock_grant(string $grantId): array
{
    if ($grantId === '') { return [[], [], []]; }
    $where = ' WHERE grant_id=' . glpichat_desktop_quote($grantId) . ' LIMIT 1';
    $registration = glpichat_desktop_auth_one('SELECT * FROM ' . GLPICHAT_DESKTOP_REGISTRATIONS_TABLE . $where);
    if ($registration) { return glpichat_desktop_managed_lock($grantId); }
    $grant = glpichat_desktop_auth_one('SELECT * FROM ' . GLPICHAT_DESKTOP_GRANTS_TABLE . $where . ' FOR UPDATE');
    if ($grant && $grant['status'] === 'consumed') {
        glpichat_desktop_fail('enrollment_busy', 'Aguarde alguns segundos para retomar a conexão automática.', 503);
    }
    return [[], [], $grant];
}

function glpichat_desktop_automatic_blocked(array $binding, array $device, array $grant): bool
{
    return ($binding['status'] ?? '') === 'revoked'
        || ($grant['status'] ?? '') === 'revoked' || ($device['status'] ?? '') === 'revoked'
        || !empty($grant['revoked_at']) || !empty($device['revoked_at']);
}

function glpichat_desktop_automatic_response(array $grant, string $secret): array
{
    $facts = glpichat_desktop_managed_facts($grant, true);
    return ['ok' => true, 'grant' => ['schema' => 1, 'grant_id' => $grant['grant_id'], 'secret' => $secret,
        'windows_sid' => $grant['windows_sid'], 'computer_name' => $grant['computer_name'],
        'user_id' => (int) $grant['users_id'], 'subject_id' => glpichat_desktop_subject_id($facts),
        'expires_at' => gmdate('Y-m-d\TH:i:s\Z', glpichat_desktop_auth_timestamp($grant['expires_at']))]];
}

/** Adopt the latest legacy file enrollment so upgrading cannot evade an explicit revocation.
 * This small committed boundary records its existing state; no credential is issued here.
 */
function glpichat_desktop_automatic_adopt_legacy(string $token, string $installation, string $sid, string $computer, array $facts): void
{
    glpichat_desktop_transaction(static function () use ($token, $installation, $sid, $computer, $facts): void {
        $machine = glpichat_management_authenticate($token, $installation, true);
        if (!hash_equals(strtoupper((string) $machine['computer_name']), $computer)) { glpichat_desktop_fail('machine_identity_mismatch', 'O computador não corresponde ao registro instalado.', 403); }
        if (glpichat_management_one(GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE, 'machines_id=' . (int) $machine['id'] . ' AND windows_sid=' . glpichat_desktop_quote($sid), true)) { return; }
        $names = array_values(array_unique(array_filter([$computer, strtoupper((string) ($machine['previous_computer_name'] ?? '')),
            strtoupper((string) ($machine['enrollment_computer_name'] ?? ''))])));
        $rows = [];
        // Each exact SID/name lookup retains the bounded identity index walk.
        // Adopt any explicit revocation before a newer unrevoked legacy grant.
        foreach ($names as $legacyName) {
            $found = glpichat_desktop_db_rows('SELECT * FROM ' . GLPICHAT_DESKTOP_GRANTS_TABLE
                . ' WHERE windows_sid=' . glpichat_desktop_quote($sid) . ' AND computer_name=' . glpichat_desktop_quote($legacyName) . ' ORDER BY id DESC LIMIT 1');
            if (!$found) { continue; }
            if (!$rows || $found[0]['status'] === 'revoked' || (int) $found[0]['id'] > (int) $rows[0]['id']) { $rows = $found; }
            if ($found[0]['status'] === 'revoked') { break; }
        }
        if (!$rows) { return; }
        // An automatic grant belongs to its exact installation, even if another machine reused the host name.
        if (glpichat_management_one(GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE, 'current_grant_id=' . glpichat_desktop_quote($rows[0]['grant_id']))) { return; }
        [, , $grant] = glpichat_desktop_automatic_lock_grant($rows[0]['grant_id']);
        if (!glpichat_desktop_automatic_identity_matches($grant, $facts)) { glpichat_desktop_fail('automatic_identity_changed', 'O vínculo anterior pertence a outra identidade. Verifique a conta no GLPI.', 403); }
        $now = glpichat_desktop_now();
        glpichat_management_write(GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE, ['machines_id' => (int) $machine['id'], 'windows_sid' => $sid,
            'users_id' => $facts['user_id'], 'auths_id' => $facts['auths_id'], 'sync_anchor' => $facts['sync_anchor'],
            'user_incarnation' => $facts['user_incarnation'], 'auth_source_fingerprint' => $facts['auth_source_fingerprint'],
            'current_grant_id' => $grant['grant_id'], 'status' => 'active', 'created_at' => $now, 'updated_at' => $now, 'released_by' => 0]);
    });
}

function glpichat_desktop_automatic_authorize(string $token, string $installation, array $input, ?callable $directoryReader = null): array
{
    glpichat_desktop_automatic_require_schema();
    if (array_diff(array_keys($input), ['grant_id', 'grant_secret', 'windows_sid', 'computer_name'])) {
        glpichat_desktop_fail('invalid_request', 'O vínculo de usuário é determinado pelo Windows e pelo GLPI.', 400);
    }
    $proposal = glpichat_management_hex($input, 'grant_id', 32);
    $secret = glpichat_management_hex($input, 'grant_secret');
    [$sid, $computer] = glpichat_desktop_delivery_identity(glpichat_desktop_string($input, 'windows_sid', 184), glpichat_desktop_string($input, 'computer_name', 63));
    $machine = glpichat_management_authenticate($token, $installation);
    // Resolve directory identity without locks, then anchor any legacy file-era
    // revocation to this installation before changing its display name.
    $resolved = glpichat_desktop_automatic_resolve($sid, $directoryReader);
    glpichat_desktop_automatic_adopt_legacy($token, $installation, $sid, strtoupper((string) $machine['computer_name']), $resolved);
    if (!hash_equals(strtoupper((string) $machine['computer_name']), $computer)) {
        glpichat_desktop_transaction(static function () use ($token, $installation, $computer): void {
            $current = glpichat_management_authenticate($token, $installation, true);
            glpichat_management_reconcile_name($current, $computer);
        });
    }
    // Revalidate all local authority inside the issuance transaction.
    return glpichat_desktop_transaction(static function () use ($token, $installation, $proposal, $secret, $sid, $computer, $resolved): array {
        $machine = glpichat_management_authenticate($token, $installation, true);
        if (!hash_equals(strtoupper((string) $machine['computer_name']), $computer)) { glpichat_desktop_fail('machine_identity_mismatch', 'O computador não corresponde ao registro instalado.', 403); }
        $binding = glpichat_management_one(GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE, 'machines_id=' . (int) $machine['id'] . ' AND windows_sid=' . glpichat_desktop_quote($sid), true);
        [$oldDevice, $oldRegistration, $oldGrant] = glpichat_desktop_automatic_lock_grant((string) ($binding['current_grant_id'] ?? ''));
        if ($binding && !empty($binding['current_grant_id']) && !$oldGrant) { throw new RuntimeException('Automatic binding grant missing.'); }
        if (glpichat_desktop_automatic_blocked($binding, $oldDevice, $oldGrant)) { glpichat_desktop_fail('automatic_binding_revoked', 'A conexão foi revogada. O administrador deve liberar esta conta e computador no GLPI.', 403); }
        if ($binding && !glpichat_desktop_automatic_identity_matches($binding, $resolved)) { glpichat_desktop_fail('automatic_identity_changed', 'A identidade vinculada mudou. Verifique a sincronização da conta no GLPI.', 403); }
        $existing = glpichat_management_one(GLPICHAT_DESKTOP_GRANTS_TABLE, 'grant_id=' . glpichat_desktop_quote($proposal));
        if ($existing) {
            if (($binding['current_grant_id'] ?? '') !== $proposal
                || !hash_equals(strtoupper((string) $existing['computer_name']), $computer)
                || !hash_equals((string) $existing['secret_hash'], glpichat_desktop_auth_hash('enrollment-grant', $secret))) {
                glpichat_desktop_fail('automatic_proposal_conflict', 'A proposta de conexão já está em uso.', 409);
            }
            if ($oldGrant['expires_at'] <= glpichat_desktop_now()) { glpichat_desktop_fail('grant_expired', 'Renove a proposta de conexão automática.', 410); }
            return glpichat_desktop_automatic_response($oldGrant, $secret);
        }
        $facts = glpichat_desktop_auth_user((int) $resolved['user_id'], (int) $resolved['profile_id'], (int) $resolved['entity_id'], true);
        $identity = ['users_id' => $resolved['user_id']] + $resolved;
        if (!glpichat_desktop_automatic_identity_matches($identity, $facts)) { glpichat_desktop_fail('automatic_identity_changed', 'A conta mudou durante a conexão. Tente novamente.', 409); }
        $now = glpichat_desktop_now();
        if ($oldGrant) {
            // Lost local state may recover only this same verified machine/SID/account.
            // Mark superseded, retaining history; explicit revoked states never enter here.
            if ($oldDevice) { glpichat_management_write(GLPICHAT_DESKTOP_DEVICES_TABLE, ['status' => 'superseded', 'revoked_at' => $now], ['id' => (int) $oldDevice['id']]); }
            glpichat_management_write(GLPICHAT_DESKTOP_GRANTS_TABLE, ['status' => 'superseded', 'revoked_at' => $now], ['id' => (int) $oldGrant['id']]);
        }
        $grant = ['grant_id' => $proposal, 'secret_hash' => glpichat_desktop_auth_hash('enrollment-grant', $secret), 'status' => 'issued',
            'users_id' => $facts['user_id'], 'profiles_id' => $facts['profile_id'], 'entities_id' => $facts['entity_id'],
            'auths_id' => $facts['auths_id'], 'sync_anchor' => $facts['sync_anchor'], 'user_incarnation' => $facts['user_incarnation'],
            'auth_source_fingerprint' => $facts['auth_source_fingerprint'], 'windows_sid' => $sid, 'computer_name' => $computer,
            'created_at' => $now, 'expires_at' => gmdate('Y-m-d H:i:s', glpichat_desktop_auth_timestamp($now) + 600)];
        glpichat_management_write(GLPICHAT_DESKTOP_GRANTS_TABLE, $grant);
        $values = ['current_grant_id' => $proposal, 'updated_at' => $now];
        if ($binding) { glpichat_management_write(GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE, $values, ['id' => (int) $binding['id']]); }
        else {
            $values += ['machines_id' => (int) $machine['id'], 'windows_sid' => $sid, 'users_id' => $facts['user_id'], 'auths_id' => $facts['auths_id'],
                'sync_anchor' => $facts['sync_anchor'], 'user_incarnation' => $facts['user_incarnation'], 'auth_source_fingerprint' => $facts['auth_source_fingerprint'],
                'status' => 'active', 'created_at' => $now, 'released_by' => 0];
            glpichat_management_write(GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE, $values);
        }
        return glpichat_desktop_automatic_response($grant, $secret);
    });
}

/** Administrative release never resurrects a revoked credential or changes account identity. */
function glpichat_desktop_automatic_release(int $bindingId, int $adminId): void
{
    glpichat_desktop_automatic_require_schema();
    if ($bindingId < 1 || $adminId < 1) { glpichat_desktop_fail('invalid_request', 'Vínculo inválido.', 400); }
    $initial = glpichat_management_one(GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE, 'id=' . $bindingId);
    if (!$initial) { glpichat_desktop_fail('not_found', 'Vínculo indisponível.', 404); }
    glpichat_desktop_transaction(static function () use ($initial, $bindingId, $adminId): void {
        $machine = glpichat_management_one(GLPICHAT_MANAGEMENT_MACHINES, 'id=' . (int) $initial['machines_id'], true);
        $binding = glpichat_management_one(GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE, 'id=' . $bindingId, true);
        if (!$machine || $machine['status'] !== 'active' || !$binding) { glpichat_desktop_fail('machine_invalid', 'A máquina precisa ter um registro ativo.', 409); }
        [$device, , $grant] = glpichat_desktop_automatic_lock_grant((string) ($binding['current_grant_id'] ?? ''));
        if (!glpichat_desktop_automatic_blocked($binding, $device, $grant)) { glpichat_desktop_fail('binding_not_revoked', 'Este vínculo já está liberado.', 409); }
        glpichat_management_write(GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE, ['current_grant_id' => null, 'status' => 'active',
            'updated_at' => glpichat_desktop_now(), 'released_by' => $adminId], ['id' => $bindingId]);
    });
}
