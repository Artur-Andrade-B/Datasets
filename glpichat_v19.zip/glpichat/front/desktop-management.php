<?php

declare(strict_types=1);

// Sessionful GLPI11 legacy page: core CheckCsrfListener validates and consumes
// every POST token before execution. Never register this front path stateless.
if (!defined('GLPI_ROOT')) { define('GLPI_ROOT', dirname(__DIR__, 3)); }
include GLPI_ROOT . '/inc/includes.php';
require_once dirname(__DIR__) . '/src/desktop/rollouts.php';
require_once dirname(__DIR__) . '/src/desktop/queue_health.php';
require_once dirname(__DIR__) . '/src/desktop/automatic.php';
Session::checkRight('plugin_glpichat_admin', READ);
glpichat_desktop_reset_request_context();
header('Cache-Control: no-store, private');
header('Referrer-Policy: no-referrer');
header('X-Content-Type-Options: nosniff');
$escape = static fn (mixed $value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$text = static fn (array $input, string $key): string => isset($input[$key]) && is_string($input[$key]) ? $input[$key] : '';
$integer = static function (array $input, string $key): int {
    $value = $input[$key] ?? '';
    if (!is_string($value) || preg_match('/\A[0-9]{1,10}\z/D', $value) !== 1) { glpichat_desktop_fail('invalid_request', 'Número inválido.', 400); }
    return (int) $value;
};
$error = ''; $message = ''; $selectionCommitted = false;
try {
    glpichat_management_require_schema();
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        Session::checkRight('plugin_glpichat_admin', UPDATE);
        $adminId = (int) Session::getLoginUserID();
        if ($adminId < 1) { throw new RuntimeException('Administrator required.'); }
        $action = $text($_POST, 'action');
        if ($action === 'import') {
            $file = $_FILES['release'] ?? [];
            if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_string($file['tmp_name'] ?? null) || !is_uploaded_file($file['tmp_name'])) {
                glpichat_desktop_fail('upload_failed', 'Selecione o ZIP da versão. Verifique os limites de upload do PHP se necessário.', 400);
            }
            $release = glpichat_management_import($file['tmp_name'], $adminId);
            $message = 'Versão ' . $release['version'] . ' importada. Selecione os computadores para atualizar.';
        } elseif ($action === 'export') {
            $deployment = glpichat_management_deployment($text($_POST, 'base_url'), $text($_POST, 'enrollment_root'), $integer($_POST, 'max_uses'), $integer($_POST, 'ttl_days'), $adminId);
            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename="deployment.json"');
            echo json_encode($deployment, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
            exit;
        } elseif ($action === 'assign') {
            $filterText = $text($_POST, 'filters');
            if (strlen($filterText) > 4096) { glpichat_desktop_fail('invalid_request', 'Filtros inválidos.', 400); }
            try { $submittedFilters = json_decode($filterText, true, 4, JSON_THROW_ON_ERROR); }
            catch (JsonException $e) { glpichat_desktop_fail('invalid_request', 'Filtros inválidos.', 400); }
            if (!is_array($submittedFilters)) { glpichat_desktop_fail('invalid_request', 'Filtros inválidos.', 400); }
            $selected = $text($_POST, 'selected_ids');
            $ids = glpichat_management_selection_ids($selected !== '' ? $selected : ($_POST['machine_ids'] ?? []));
            $excluded = glpichat_management_selection_ids($text($_POST, 'excluded_ids') ?: '[]');
            $rollout = glpichat_management_create_rollout($integer($_POST, 'release_id'), $text($_POST, 'operation'), $submittedFilters,
                $text($_POST, 'selection'), $ids, $excluded, $adminId, $text($_POST, 'request_id'));
            $message = 'Solicitação #' . $rollout['id'] . ' registrada para ' . $rollout['target_count'] . ' computadores. Cada computador recebe sua atualização no próximo contato autenticado. A ação automática do GLPI também auxilia a distribuição; computadores offline continuam na fila.';
            $selectionCommitted = true;
        } elseif ($action === 'release_binding') {
            glpichat_desktop_automatic_release($integer($_POST, 'id'), $adminId);
            $message = 'Conexão automática liberada. O aplicativo tentará novamente; as credenciais antigas continuam revogadas.';
        } elseif ($action === 'revoke_machine' || $action === 'revoke_registration') {
            glpichat_management_revoke($action === 'revoke_machine' ? 'machine' : 'registration', $integer($_POST, 'id'));
            $message = $action === 'revoke_machine' ? 'Gerenciamento desta máquina revogado.' : 'Novos registros e tentativas de registro com este arquivo foram revogados. As máquinas já registradas permanecem gerenciadas.';
        } else { glpichat_desktop_fail('invalid_request', 'Ação inválida.', 400); }
    }
} catch (GlpichatDesktopException $e) {
    $error = $e->getMessage();
} catch (\Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException $e) {
    throw $e;
} catch (Throwable $e) {
    $reference = glpichat_desktop_log_failure('management_admin', $e);
    $error = 'Não foi possível concluir a operação. Referência para os logs: ' . $reference . '.';
}

Html::header('GLPI Chat — Desktop Windows', $_SERVER['PHP_SELF'], 'config', 'plugins');
echo '<div class="container-fluid"><h1>Desktop Windows</h1>';
echo '<p>Importe uma versão do aplicativo, solicite atualizações ou reparos e acompanhe o resultado informado por cada computador.</p>';
if ($error !== '') { echo '<div class="alert alert-danger">' . $escape($error) . '</div>'; }
if ($message !== '') { echo '<div class="alert alert-success">' . $escape($message) . '</div>'; }
if ((string) glpichat_desktop_config('desktop_schema_version') !== '7') {
    echo '<p>Conclua a atualização do plugin pela gestão de plugins do GLPI.</p></div>'; Html::footer(); return;
}
$canUpdate = Session::haveRight('plugin_glpichat_admin', UPDATE);
$csrf = static function () use ($escape): string { return '<input type="hidden" name="_glpi_csrf_token" value="' . $escape(Session::getNewCSRFToken()) . '">'; };
$number = static fn (string $name): int => isset($_GET[$name]) && is_string($_GET[$name]) && ctype_digit($_GET[$name]) ? max(1, min(1000000, (int) $_GET[$name])) : 1;
try {
    $filters = glpichat_management_filters($_GET);
    $list = glpichat_management_machine_page($filters, $number('page'), $number('size'));
    $releases = glpichat_desktop_db_rows('SELECT id,version,sequence FROM ' . GLPICHAT_MANAGEMENT_RELEASES . ' ORDER BY sequence DESC LIMIT 200');
    $rollouts = glpichat_management_rollout_page($number('rollout_page'));
    $bindingPage = $number('binding_page'); $grantPage = $number('grant_page');
    $bindingTotal = (int) (glpichat_desktop_db_rows('SELECT COUNT(*) AS total FROM ' . GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE)[0]['total'] ?? 0);
    $grantTotal = (int) (glpichat_desktop_db_rows('SELECT COUNT(*) AS total FROM ' . GLPICHAT_MANAGEMENT_GRANTS)[0]['total'] ?? 0);
    $bindingPage = min($bindingPage, max(1, (int) ceil($bindingTotal / 50))); $grantPage = min($grantPage, max(1, (int) ceil($grantTotal / 50)));
    $grants = glpichat_desktop_db_rows('SELECT id,registration_id,status,expires_at,max_uses,used_count,created_at FROM ' . GLPICHAT_MANAGEMENT_GRANTS . ' ORDER BY id DESC LIMIT 50 OFFSET ' . (($grantPage - 1) * 50));
    $bindings = glpichat_desktop_db_rows('SELECT b.*, m.computer_name, u.name AS user_name, g.status AS grant_status, g.revoked_at AS grant_revoked_at, d.status AS device_status, d.revoked_at AS device_revoked_at FROM ' . GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE . ' b LEFT JOIN ' . GLPICHAT_MANAGEMENT_MACHINES . ' m ON m.id=b.machines_id LEFT JOIN glpi_users u ON u.id=b.users_id LEFT JOIN ' . GLPICHAT_DESKTOP_GRANTS_TABLE . ' g ON g.grant_id=b.current_grant_id LEFT JOIN ' . GLPICHAT_DESKTOP_REGISTRATIONS_TABLE . ' r ON r.grant_id=g.grant_id LEFT JOIN ' . GLPICHAT_DESKTOP_DEVICES_TABLE . ' d ON d.id=r.devices_id ORDER BY b.id DESC LIMIT 50 OFFSET ' . (($bindingPage - 1) * 50));
} catch (Throwable $e) {
    $reference = glpichat_desktop_log_failure('management_admin_list', $e);
    echo '<div class="alert alert-danger">Não foi possível consultar o gerenciamento. Referência: ' . $escape($reference) . '.</div></div>'; Html::footer(); return;
}
$query = $filters + ['size' => $list['size']];
$pages = static function (string $parameter, int $current, int $maximum, array $extra = []) use ($query, $escape): void {
    echo '<nav class="d-flex gap-3 my-2" aria-label="Paginação"><span>Página ' . $current . ' de ' . $maximum . '</span>';
    foreach (['Primeira' => 1, 'Anterior' => $current - 1, 'Próxima' => $current + 1, 'Última' => $maximum] as $label => $page) {
        if ($page < 1 || $page > $maximum || $page === $current) { continue; }
        echo '<a href="?' . $escape(http_build_query(array_replace($query, $extra, [$parameter => $page]))) . '">' . $label . '</a>';
    }
    echo '</nav>';
};
$select = static function (string $name, string $label, array $options, string $current) use ($escape): void {
    echo '<label class="form-label" for="fleet-' . $name . '">' . $escape($label) . '</label><select class="form-select" name="' . $name . '" id="fleet-' . $name . '">';
    foreach ($options as $value => $title) { echo '<option value="' . $escape($value) . '"' . ((string) $value === $current ? ' selected' : '') . '>' . $escape($title) . '</option>'; }
    echo '</select>';
};
if ($canUpdate) {
    echo '<details><summary>Importar versão e preparar novas instalações</summary><div class="row"><section class="col-lg-6"><h2>Importar versão</h2><form method="post" enctype="multipart/form-data">' . $csrf();
    echo '<input type="hidden" name="action" value="import"><label for="desktop-release">ZIP de versão desktop</label><input class="form-control" id="desktop-release" type="file" name="release" accept=".zip" required>';
    echo '<p class="form-text">O ZIP contém Agent + Widget. O bootstrap estável exige manutenção administrativa própria.</p><button class="btn btn-primary">Importar versão</button></form></section>';
    $baseUrl = ''; try { $baseUrl = glpichat_desktop_base_url(); } catch (Throwable $e) { }
    echo '<section class="col-lg-6"><h2>Preparar implantação</h2><form method="post">' . $csrf() . '<input type="hidden" name="action" value="export">';
    echo '<label for="deployment-url">Endereço do GLPI usado pelos computadores</label><input class="form-control" id="deployment-url" name="base_url" value="' . $escape($baseUrl) . '" required maxlength="2048">';
    echo '<label for="registration-limit">Número máximo de computadores</label><input class="form-control" id="registration-limit" name="max_uses" type="number" min="1" max="10000" value="100" required>';
    echo '<label for="registration-days">Validade em dias</label><input class="form-control" id="registration-days" name="ttl_days" type="number" min="1" max="30" value="7" required>';
    echo '<p class="form-text">O arquivo deployment.json prepara a instalação inicial e a conexão automática dos usuários. Não é necessário distribuir arquivos por usuário.</p><button class="btn btn-primary">Baixar deployment.json</button></form></section></div></details><hr>';
}
echo '<h2>Computadores</h2><form method="get" class="row g-2"><div class="col-md-4"><label for="fleet-q">Nome ou identificador da instalação</label><input class="form-control" id="fleet-q" name="q" maxlength="100" value="' . $escape($filters['q']) . '"></div>';
echo '<div class="col-md-2"><label for="fleet-version">Versão instalada</label><input class="form-control" id="fleet-version" name="version" maxlength="32" value="' . $escape($filters['version']) . '"></div>';
foreach ([['status', 'Registro', ['' => 'Todos', 'active' => 'Ativo', 'revoked' => 'Revogado']], ['health', 'Saúde', ['' => 'Todas', 'healthy' => 'Saudável', 'damaged' => 'Arquivos danificados', 'trial' => 'Em validação', 'unavailable' => 'Indisponível']], ['contact', 'Contato', ['' => 'Todos', 'recent' => 'Últimos 5 minutos', 'offline' => 'Sem contato há 5 minutos', 'never' => 'Nunca']], ['operation_status', 'Última operação', ['' => 'Todas', 'none' => 'Nenhuma', 'pending' => 'Aguardando o computador', 'started' => 'Em execução no computador', 'completed' => 'Concluída', 'failed' => 'Falha no computador', 'superseded' => 'Substituída']]] as [$key, $label, $options]) {
    echo '<div class="col-md-2">'; $select($key, $label, $options, $filters[$key]); echo '</div>';
}
echo '<div class="col-md-2">'; $select('size', 'Por página', [50 => '50', 100 => '100'], (string) $list['size']); echo '</div><div class="col-12"><button class="btn btn-primary">Pesquisar</button> <a href="desktop-management.php">Limpar filtros</a></div></form>';
echo '<p class="mt-3">' . $list['total'] . ' computadores encontrados. Datas em UTC. Contato recente indica comunicação; não confirma instalação concluída.</p>';
$pages('page', $list['page'], $list['pages']);
if ($canUpdate) {
    $filterJson = json_encode($filters, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    echo '<form method="post" id="desktop-assignment" data-filter-key="' . $escape($filterJson) . '" data-total="' . $list['total'] . '" data-owner="' . (int) Session::getLoginUserID() . '" data-committed="' . ($selectionCommitted ? '1' : '0') . '">' . $csrf()
        . '<input type="hidden" name="action" value="assign"><input type="hidden" name="request_id" value="' . bin2hex(random_bytes(16)) . '"><input type="hidden" name="filters" value="' . $escape($filterJson) . '">'
        . '<input type="hidden" name="selected_ids" value=""><input type="hidden" name="excluded_ids" value="[]">';
    echo '<fieldset class="my-3"><legend>Selecionar computadores</legend><label class="me-3"><input type="radio" name="selection" value="selected" checked> Seleção manual entre páginas</label><label><input type="radio" name="selection" value="all"> Selecionar todos os ' . $list['total'] . ' computadores correspondentes</label><br><button type="button" class="btn btn-sm btn-outline-secondary mt-2" id="fleet-select-page">Selecionar esta página</button> <button type="button" class="btn btn-sm btn-outline-secondary mt-2" id="fleet-clear-selection">Limpar seleção</button><p id="fleet-selection-count" aria-live="polite">Nenhum computador selecionado.</p><noscript>Sem JavaScript, a seleção manual vale somente para esta página; a opção Todos inclui todos os resultados, sem exclusões.</noscript></fieldset>';
}
echo '<div class="table-responsive"><table class="table"><thead><tr><th>Selecionar</th><th>Computador</th><th>Versão / bootstrap</th><th>Último contato UTC</th><th>Saúde / resultado</th><th>Última operação</th><th>Registro</th></tr></thead><tbody>';
foreach ($list['rows'] as $machine) {
    $id = (int) $machine['id'];
    echo '<tr><td>' . ($canUpdate ? '<input type="checkbox" class="fleet-machine" name="machine_ids[]" value="' . $id . '" aria-label="Incluir ' . $escape($machine['computer_name']) . '">' : '') . '</td>';
    echo '<td>' . $escape($machine['computer_name']) . '<br><small>' . $escape($machine['installation_id']) . '</small>';
    if ($machine['previous_computer_name'] !== '') { echo '<br><small>Nome anterior: ' . $escape($machine['previous_computer_name']) . '</small>'; }
    echo '</td><td>' . $escape($machine['current_version'] ?: 'Não informada') . ' / ' . $escape($machine['bootstrap_version']) . '</td><td>' . $escape($machine['last_seen'] ?? 'Nunca') . '</td>';
    echo '<td>' . $escape($machine['health']) . ' / ' . $escape($machine['last_result']) . '<br><small>' . $escape($machine['last_error']) . '</small></td>';
    echo '<td>' . ($machine['assignment_id'] ? $escape($machine['assignment_version'] . ' — ' . ($machine['assignment_action'] === 'repair' ? 'Reparar' : 'Atualizar') . ' — ' . glpichat_management_queue_state_label((string) $machine['assignment_status'])) . '<br><small>' . $escape($machine['assignment_error']) . '</small>' : 'Nenhuma') . '</td><td>' . $escape($machine['status']);
    if ($canUpdate && $machine['status'] === 'active') { echo '<br><button class="btn btn-sm btn-outline-danger" form="revoke-machine-' . $id . '">Revogar máquina</button>'; }
    echo '</td></tr>';
}
echo '</tbody></table></div>';
if ($canUpdate) {
    echo '<label for="assignment-release">Versão solicitada</label><select class="form-select" id="assignment-release" name="release_id" required><option value="">Selecione</option>';
    foreach ($releases as $release) { echo '<option value="' . (int) $release['id'] . '">' . $escape($release['version']) . ' — sequência ' . $escape($release['sequence']) . '</option>'; }
    echo '</select><label for="assignment-action">Operação</label><select class="form-select" id="assignment-action" name="operation"><option value="update">Atualizar</option><option value="repair">Reparar (tentar novamente uma versão autorizada)</option></select><p class="form-text">Computadores sem permissão ou compatibilidade serão informados individualmente. Operações em andamento são preservadas; máquinas offline aguardam contato.</p><button class="btn btn-primary" id="fleet-submit">Solicitar operação em lote</button></form>';
    foreach ($list['rows'] as $machine) {
        if ($machine['status'] !== 'active') { continue; }
        echo '<form method="post" id="revoke-machine-' . (int) $machine['id'] . '">' . $csrf() . '<input type="hidden" name="action" value="revoke_machine"><input type="hidden" name="id" value="' . (int) $machine['id'] . '"></form>';
    }
}
$pages('page', $list['page'], $list['pages']);
$queueHealth = glpichat_management_queue_health();
echo '<hr><section aria-labelledby="desktop-queue-health"><h2 id="desktop-queue-health">Distribuição das atualizações</h2>';
echo '<p>Um computador pode receber sua atualização ao entrar em contato autenticado com o GLPI. A ação automática ProcessDesktopRollouts auxilia a distribuição e o acompanhamento dos lotes. O contato do computador permite consultar a fila sem depender da execução manual da ação auxiliar.</p>';
echo '<div class="alert alert-' . $escape($queueHealth['tone']) . '" data-role="queue-health"><strong>' . $escape($queueHealth['status']) . '</strong><br>Modo da ação auxiliar: ' . $escape($queueHealth['mode']) . '<br>Última execução registrada no GLPI: ' . $escape($queueHealth['last_run']);
if ($queueHealth['reference'] !== '') { echo '<br>Referência da consulta: <code>' . $escape($queueHealth['reference']) . '</code>'; }
echo '<br><small>O cadastro ou a execução da ação automática não confirma que os computadores foram atualizados. Confira os estados e o resultado de cada computador abaixo.</small></div></section>';
echo '<h2>Solicitações de atualização</h2><p>Na fila: ainda aguarda distribuição. Distribuído: aguarda o computador. Em execução: o computador informou o início. Concluído: o computador confirmou o resultado. Atualize esta página para consultar o progresso.</p><div class="table-responsive"><table class="table"><thead><tr><th>Solicitação</th><th>Versão / operação</th><th>Alvos</th><th>Progresso informado</th><th>Criada UTC</th></tr></thead><tbody>';
foreach ($rollouts['rows'] as $rollout) {
    $id = (int) $rollout['id']; $parts = [];
    foreach ($rollouts['counts'][$id] ?? [] as $state => $count) { $parts[] = glpichat_management_queue_state_label((string) $state) . ': ' . $count; }
    echo '<tr><td><a href="?' . $escape(http_build_query($query + ['rollout_id' => $id])) . '#rollout-details">#' . $id . '</a> ' . $escape(glpichat_management_queue_state_label((string) $rollout['status'], '', true)) . '</td><td>' . $escape($rollout['version'] . ' / ' . ($rollout['action'] === 'repair' ? 'Reparar' : 'Atualizar')) . '</td><td>' . (int) $rollout['target_count'] . '</td><td>' . $escape(implode(' · ', $parts)) . '</td><td>' . $escape($rollout['created_at']) . '</td></tr>';
}
echo '</tbody></table></div>'; $pages('rollout_page', $rollouts['page'], $rollouts['pages']);
if (isset($_GET['rollout_id'])) {
    try {
        $rolloutId = $number('rollout_id'); $targetPage = $number('target_page');
        $targetTotal = (int) (glpichat_desktop_db_rows('SELECT COUNT(*) AS total FROM ' . GLPICHAT_MANAGEMENT_TARGETS . ' WHERE rollouts_id=' . $rolloutId)[0]['total'] ?? 0);
        $targetPages = max(1, (int) ceil($targetTotal / 50)); $targetPage = min($targetPage, $targetPages);
        $targets = glpichat_desktop_db_rows('SELECT t.*,m.computer_name,m.last_seen,a.status AS operation_status,a.last_result,a.last_error,a.started_at FROM ' . GLPICHAT_MANAGEMENT_TARGETS . ' t LEFT JOIN ' . GLPICHAT_MANAGEMENT_MACHINES . ' m ON m.id=t.machines_id LEFT JOIN ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' a ON a.id=t.assignments_id WHERE t.rollouts_id=' . $rolloutId . ' ORDER BY t.id LIMIT 50 OFFSET ' . (($targetPage - 1) * 50));
        echo '<section id="rollout-details"><h3>Computadores da solicitação #' . $rolloutId . '</h3><div class="table-responsive"><table class="table"><thead><tr><th>Computador</th><th>Estado</th><th>Motivo / resultado</th><th>Distribuição no servidor</th><th>Último contato UTC</th></tr></thead><tbody>';
        foreach ($targets as $target) {
            $targetState = $target['status'] === 'assigned' ? (string) ($target['operation_status'] ?? 'unknown') : (string) $target['status'];
            echo '<tr><td>' . $escape($target['computer_name'] ?? ('#' . $target['machines_id'])) . '</td><td>' . $escape(glpichat_management_queue_state_label($targetState, (string) $target['reason'])) . '</td><td>' . $escape(glpichat_management_rollout_reason($target['reason'])) . ' ' . $escape($target['last_result'] ?? '') . ' ' . $escape($target['last_error'] ?? '') . '</td><td>';
            echo 'Tentativas com falha: ' . (int) $target['dispatch_attempts'] . ' / 5<br><small>Última tentativa UTC: ' . $escape($target['last_attempt_at'] ?? 'Ainda não registrada') . '</small>';
            if (in_array($target['status'], ['queued', 'waiting'], true) && $target['reason'] === 'storage_retry') {
                echo '<br><small>Nova tentativa a partir de UTC: ' . $escape($target['available_at']) . '</small>';
            }
            if ((string) $target['last_error_ref'] !== '') { echo '<br><small>Referência do erro: <code>' . $escape($target['last_error_ref']) . '</code></small>'; }
            if ($target['reason'] === 'dispatch_failed') { echo '<br><small>O servidor interrompeu as tentativas após cinco falhas. Consulte a referência nos logs; após corrigir a causa, solicite uma nova operação para este computador.</small>'; }
            echo '</td><td>' . $escape($target['last_seen'] ?? 'Nunca') . '</td></tr>';
        }
        echo '</tbody></table></div>'; $pages('target_page', $targetPage, $targetPages, ['rollout_id' => $rolloutId]); echo '</section>';
    } catch (Throwable $error) { echo '<p class="alert alert-danger">Detalhes temporariamente indisponíveis.</p>'; }
}
echo '<hr><details><summary>Conexões automáticas (' . $bindingTotal . ')</summary><div class="table-responsive"><table class="table"><thead><tr><th>Computador</th><th>Conta GLPI</th><th>Conta Windows (SID)</th><th>Estado</th></tr></thead><tbody>';
foreach ($bindings as $binding) {
    $bindingRevoked = glpichat_desktop_automatic_blocked($binding, ['status' => $binding['device_status'], 'revoked_at' => $binding['device_revoked_at'] ?? null], ['status' => $binding['grant_status'], 'revoked_at' => $binding['grant_revoked_at'] ?? null]);
    echo '<tr><td>' . $escape($binding['computer_name']) . '</td><td>' . $escape($binding['user_name']) . '</td><td>' . $escape($binding['windows_sid']) . '</td><td>' . ($bindingRevoked ? 'Revogada' : 'Liberada');
    if ($canUpdate && $bindingRevoked) { echo '<form method="post">' . $csrf() . '<input type="hidden" name="action" value="release_binding"><input type="hidden" name="id" value="' . (int) $binding['id'] . '"><button class="btn btn-sm btn-outline-primary">Liberar nova conexão</button></form>'; }
    echo '</td></tr>';
}
echo '</tbody></table></div>'; $pages('binding_page', $bindingPage, max(1, (int) ceil($bindingTotal / 50))); echo '</details>';
echo '<hr><details><summary>Arquivos de implantação (' . $grantTotal . ')</summary><p>Revogar um arquivo impede novos registros; máquinas já registradas permanecem gerenciadas.</p><table class="table"><thead><tr><th>Identificador</th><th>Validade UTC</th><th>Usos</th><th>Estado</th></tr></thead><tbody>';
foreach ($grants as $grant) {
    echo '<tr><td>' . $escape($grant['registration_id']) . '</td><td>' . $escape($grant['expires_at']) . '</td><td>' . (int) $grant['used_count'] . ' / ' . (int) $grant['max_uses'] . '</td><td>' . $escape($grant['status']);
    if ($canUpdate && $grant['status'] === 'issued') { echo '<form method="post">' . $csrf() . '<input type="hidden" name="action" value="revoke_registration"><input type="hidden" name="id" value="' . (int) $grant['id'] . '"><button class="btn btn-sm btn-outline-danger">Revogar arquivo</button></form>'; }
    echo '</td></tr>';
}
echo '</tbody></table>'; $pages('grant_page', $grantPage, max(1, (int) ceil($grantTotal / 50))); echo '</details></div>';
if ($canUpdate) { echo '<script src="' . $escape(rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/') . '/plugins/glpichat/public/js/desktop-management.js?v=' . rawurlencode(defined('PLUGIN_GLPICHAT_VERSION') ? PLUGIN_GLPICHAT_VERSION : '1.6.0')) . '"></script>'; }
Html::footer();
