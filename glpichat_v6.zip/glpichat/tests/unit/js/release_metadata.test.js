import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = resolve(import.meta.dirname, "../../..");
const readText = (relativePath) => readFileSync(resolve(root, relativePath), "utf8");

describe("foundation1 release metadata", () => {
  it("keeps plugin, catalogue, package and manifest versions aligned", () => {
    const setup = readText("setup.php");
    const pluginXml = readText("plugin.xml");
    const packageJson = JSON.parse(readText("package.json"));
    const packageLock = JSON.parse(readText("package-lock.json"));
    const manifest = JSON.parse(readText("release-manifest.json"));
    const runbook = readText("docs/releases/1.0.6-foundation1.md");
    const qualificationHelper = readText("tests/qualification/foundation_shadow.php");

    expect(setup).toContain("define('PLUGIN_GLPICHAT_VERSION', '1.0.6');");
    expect(setup).toContain("define('PLUGIN_GLPICHAT_BUILD', 'foundation1');");
    expect(pluginXml).toContain("<num>1.0.6</num>");
    expect(pluginXml).toContain("/refs/tags/v1.0.6.zip");
    expect(packageJson.version).toBe("1.0.6");
    expect(packageLock.version).toBe("1.0.6");
    expect(packageLock.packages[""].version).toBe("1.0.6");
    expect(manifest).toMatchObject({
      plugin: "glpichat",
      version: "1.0.6",
      build: "foundation1",
      package_kind: "laboratory_candidate",
      build_date: "2026-09-02",
      baseline: {
        version: "1.0.5",
        build: "perf4",
        source_archive_sha256: "4ababd559ad1c7ed8620391b0bc254173534ad2c8e0a4f0710783f088330db0b",
      },
      parent_candidate: {
        version: "1.0.5",
        build: "perf4",
        package_sha256: "23feb1f7b4a64442df6fd0251eaad8200eaad52a73740b2519cf979282dc2903",
      },
      browser_surface_default_enabled: false,
      public_authorization_shadow_default_enabled: false,
      foundation_schema_version: 1,
      foundation_scope: [
        "immutable_actor_context",
        "pure_public_authorization_policy",
        "non_authoritative_public_authorization_shadow",
        "read_only_schema_health_snapshot",
      ],
      external_desktop_api_included: false,
      external_routes_added: false,
      database_tables_added: [],
      cron_tasks_added: [],
      runtime_dependencies_added: [],
    });
    expect(runbook).toContain("# GLPI Chat 1.0.6-foundation1");
    expect(runbook).toContain("active-production `1.0.5-perf4`");
    expect(runbook).toContain("does not add:");
    expect(runbook).toContain("`/External/V1`");

    const helperCommand =
      "docker exec glpi php /var/www/glpi/plugins/glpichat/tests/qualification/foundation_shadow.php";
    expect(runbook).toContain(`${helperCommand} status`);
    expect(runbook).toContain(`${helperCommand} enable`);
    expect(runbook).toContain(`${helperCommand} disable`);
    expect(runbook.split(`${helperCommand} status`).length - 1).toBe(3);

    expect(qualificationHelper).toContain('if (PHP_SAPI !== \'cli\')');
    expect(qualificationHelper).toContain("Usage: php foundation_shadow.php [status|enable|disable]");
    expect(qualificationHelper).toContain("['status', 'enable', 'disable']");
    expect(qualificationHelper).toContain("$argv[1] ?? 'status'");
    expect(qualificationHelper).toContain("$action === 'enable'");
    expect(qualificationHelper).toContain("$action === 'disable'");
    expect(qualificationHelper).toContain("foundation_schema_version >= 1");
    expect(qualificationHelper).toContain("Config::setConfigurationValues");
    expect(qualificationHelper).toContain("Config::getConfigurationValue");
    expect(qualificationHelper).toContain("Shadow flag read-back did not match");
    expect(qualificationHelper).not.toMatch(/\$DB|glpi_configs|->(?:insert|update|delete|doQuery)\s*\(/);
    expect(qualificationHelper).not.toContain("browser_surface_enabled");

    const cliGuard = qualificationHelper.indexOf("if (PHP_SAPI !== 'cli')");
    const bootstrap = qualificationHelper.indexOf("/vendor/autoload.php");
    const markerRead = qualificationHelper.indexOf("Config::getConfigurationValue($context, $markerKey)");
    const markerGate = qualificationHelper.indexOf("if (!$markerIsAdopted)");
    const enableWrite = qualificationHelper.indexOf("Config::setConfigurationValues($context, [$flagKey => '1'])");
    const disableWrite = qualificationHelper.indexOf("Config::setConfigurationValues($context, [$flagKey => '0'])");
    const flagReadBack = qualificationHelper.indexOf("Config::getConfigurationValue($context, $flagKey)");
    const strictReadBack = qualificationHelper.indexOf("$rawFlag === 1 || $rawFlag === '1'");
    expect(cliGuard).toBeGreaterThanOrEqual(0);
    expect(bootstrap).toBeGreaterThan(cliGuard);
    expect(markerRead).toBeGreaterThan(bootstrap);
    expect(markerGate).toBeGreaterThan(markerRead);
    expect(enableWrite).toBeGreaterThan(markerGate);
    expect(disableWrite).toBeGreaterThan(enableWrite);
    expect(flagReadBack).toBeGreaterThan(disableWrite);
    expect(strictReadBack).toBeGreaterThan(flagReadBack);
    expect(qualificationHelper.split("Config::setConfigurationValues").length - 1).toBe(2);
  });
});
