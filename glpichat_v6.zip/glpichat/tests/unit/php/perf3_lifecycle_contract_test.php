<?php

declare(strict_types=1);

/**
 * Source-level safety contract for the lifecycle slice inherited through
 * foundation1. The behavior remains the perf3/perf4 contract even as release
 * identity advances.
 *
 * This test intentionally has no GLPI or Composer dependency, so it can guard
 * package composition before a candidate is copied into a GLPI instance. The
 * destructive lifecycle suite performs the complementary database assertions.
 */

$plugin_root = dirname(__DIR__, 3);
$setup = file_get_contents($plugin_root . '/setup.php');
$hook = file_get_contents($plugin_root . '/hook.php');
$config = file_get_contents($plugin_root . '/front/config.php');
$plugin_xml = file_get_contents($plugin_root . '/plugin.xml');

if (!is_string($setup) || !is_string($hook) || !is_string($config) || !is_string($plugin_xml)) {
    fwrite(STDERR, "[FAIL] Nao foi possivel carregar os arquivos do contrato de lifecycle.\n");
    exit(1);
}

$assert = static function (bool $condition, string $message): void {
    if (!$condition) {
        fwrite(STDERR, "[FAIL] {$message}\n");
        exit(1);
    }
    fwrite(STDOUT, "[PASS] {$message}\n");
};

$assert(
    str_contains($setup, "define('PLUGIN_GLPICHAT_VERSION', '1.0.6');")
        && str_contains($setup, "define('PLUGIN_GLPICHAT_BUILD', 'foundation1');")
        && str_contains($plugin_xml, '<num>1.0.6</num>'),
    'Metadados identificam de forma consistente a versao 1.0.6-foundation1'
);

$init_start = strpos($setup, 'function plugin_init_glpichat(): void');
$version_start = strpos($setup, 'function plugin_version_glpichat(): array');
$assert($init_start !== false && $version_start !== false && $version_start > $init_start, 'plugin_init pode ser isolado para auditoria');
$init_body = substr($setup, $init_start, $version_start - $init_start);

$assert(
    !str_contains($init_body, 'glpichat_ensure_runtime_schema')
        && !str_contains($init_body, 'glpichat_ensure_profile_rights_model')
        && !str_contains($init_body, 'reloadCurrentProfile'),
    'plugin_init nao executa reparo de schema, direitos ou reload de perfil'
);

$assert(
    str_contains($init_body, "glpichat_config_bool('browser_surface_enabled', false)")
        && !str_contains($init_body, 'cap_browser_assets_enabled'),
    'Injecao usa o novo kill switch independente e fail-closed'
);

$assert(
    str_contains($init_body, "Hooks::ITEM_CAN")
        && str_contains($init_body, "HookHandler::class, 'canDocument'")
        && str_contains($init_body, "Hooks::ADD_RECIPIENT_TO_TARGET"),
    'Hooks obrigatorios de seguranca continuam registrados fora da injecao visual'
);

$assert(
    !str_contains($init_body, '/External/')
        && substr_count($init_body, 'registerPluginStatelessPath') === 1
        && str_contains($init_body, "#^/Guest/.*#"),
    'O candidato nao adiciona rota stateless ou API externa'
);

$field_positions = [];
foreach (['last_activity', 'last_seen', 'is_typing_until', 'last_send_at'] as $field) {
    $position = strpos($hook, "addField('glpi_plugin_glpichat_participants', '{$field}'");
    $assert($position !== false, "Migracao contempla participants.{$field}");
    $field_positions[] = $position;
}
$index_position = strpos($hook, 'glpichat_add_indexes($schema_migration);');
$assert(
    $index_position !== false && max($field_positions) < $index_position,
    'Todos os campos de compatibilidade sao enfileirados antes dos indices'
);

$assert(
    !str_contains($hook, "addCrontask(\\GlpiPlugin\\Glpichat\\EventCleanupCron::class, 'ExpireParticipants'")
        && str_contains($hook, "'name'     => 'ExpireParticipants'"),
    'Upgrade nao registra e remove com seguranca a crontask residual de lab1'
);

$assert(
    str_contains($hook, "'browser_surface_enabled'      => \$cfg_default('browser_surface_enabled', '0')")
        && str_contains($config, "\$_POST['browser_surface_enabled'] ?? '0'")
        && str_contains($config, "\$cfg('browser_surface_enabled', '0')"),
    'Kill switch nasce desligado, pode ser salvo e e exibido na configuracao'
);

$notification_postcondition = strpos($hook, 'glpichat_install_default_notifications();');
$foundation_marker_write = strpos($hook, "'foundation_schema_version' => glpichat_foundation_version_to_store(");
$install_return = strpos($hook, 'return true;', $foundation_marker_write === false ? 0 : $foundation_marker_write);
$assert(
    $notification_postcondition !== false
        && $foundation_marker_write !== false
        && $install_return !== false
        && $notification_postcondition < $foundation_marker_write
        && $foundation_marker_write < $install_return
        && substr_count($hook, "'foundation_schema_version' => glpichat_foundation_version_to_store(") === 1,
    'Marker foundation e gravado uma vez, somente apos os postconditions do lifecycle'
);

$assert(
    str_contains($hook, "'public_authorization_shadow_enabled' => glpichat_foundation_shadow_config_value(")
        && !str_contains($config, 'public_authorization_shadow_enabled'),
    'Shadow publico nasce fail-closed e permanece oculto da configuracao web'
);

fwrite(STDOUT, "[PASS] Contrato de lifecycle/configuracao herdado concluido\n");
