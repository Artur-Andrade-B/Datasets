<?php

declare(strict_types=1);

/**
 * Source-level integration contract for the deliberately non-authoritative
 * browser shadow. Loading functions.php without GLPI would couple this unit
 * layer to framework state, so the test isolates the exact wrapper functions
 * with PHP's tokenizer instead.
 */

require dirname(__DIR__, 2) . '/bootstrap/unit.php';

$plugin_root = dirname(__DIR__, 3);
$functions_source = file_get_contents($plugin_root . '/src/functions.php');
if (!is_string($functions_source)) {
    glpichat_unit_fail('Unable to read src/functions.php.');
}

$extract_function = static function (string $source, string $function_name): string {
    $tokens = token_get_all($source);
    $token_count = count($tokens);

    for ($index = 0; $index < $token_count; $index++) {
        $token = $tokens[$index];
        if (!is_array($token) || $token[0] !== T_FUNCTION) {
            continue;
        }

        $name_index = $index + 1;
        while ($name_index < $token_count) {
            $candidate = $tokens[$name_index];
            if (is_array($candidate) && $candidate[0] === T_WHITESPACE) {
                $name_index++;
                continue;
            }
            if ($candidate === '&') {
                $name_index++;
                continue;
            }
            break;
        }

        $name_token = $tokens[$name_index] ?? null;
        if (!is_array($name_token) || $name_token[0] !== T_STRING || $name_token[1] !== $function_name) {
            continue;
        }

        $body = '';
        $brace_depth = 0;
        $body_started = false;
        for ($body_index = $index; $body_index < $token_count; $body_index++) {
            $body_token = $tokens[$body_index];
            $text = is_array($body_token) ? $body_token[1] : $body_token;
            $body .= $text;

            if ($body_token === '{') {
                $body_started = true;
                $brace_depth++;
            } elseif ($body_token === '}') {
                $brace_depth--;
                if ($body_started && $brace_depth === 0) {
                    return $body;
                }
            }
        }
    }

    glpichat_unit_fail('Unable to isolate function: ' . $function_name);
};

$observe_body = $extract_function($functions_source, 'glpichat_observe_public_authorization');
$send_body = $extract_function($functions_source, 'glpichat_can_send');
$read_body = $extract_function($functions_source, 'glpichat_can_read_room');

glpichat_unit_assert_true(
    str_contains($observe_body, '): void'),
    'Browser shadow wrapper has an explicit void return type'
);
foreach (['Ticket::can', '->can(', 'Session::haveRight', '$DB', 'DBmysql', 'LDAP', 'AuthLDAP'] as $forbidden_lookup) {
    glpichat_unit_assert_true(
        !str_contains($observe_body, $forbidden_lookup),
        'Shadow helper must not recompute authorization or perform DB/LDAP work: ' . $forbidden_lookup
    );
}

$flag_guard_position = strpos($observe_body, 'if (!glpichat_public_authorization_shadow_enabled())');
$shadow_observe_position = strpos($observe_body, 'AuthorizationShadow::observe(');
$capture_position = strpos($observe_body, 'glpichat_capture_browser_actor_context(');
$dedupe_position = strpos($observe_body, 'static $observedFactTuples = []');
$dedupe_guard_position = strpos($observe_body, 'if (isset($observedFactTuples[$factTuple]))');
glpichat_unit_assert_true(
    $flag_guard_position !== false
        && $shadow_observe_position !== false
        && $capture_position !== false
        && $dedupe_position !== false
        && $dedupe_guard_position !== false
        && $flag_guard_position < $shadow_observe_position
        && $flag_guard_position < $dedupe_position
        && $dedupe_guard_position < $shadow_observe_position
        && $shadow_observe_position < $capture_position
        && $flag_guard_position < $capture_position,
    'Fail-closed flag guard precedes actor capture and evaluator work'
);
glpichat_unit_assert_true(
    !str_contains($observe_body, '$tickets_id')
        && !str_contains($observe_body, '$rooms_id')
        && !str_contains($observe_body, '$userId')
        && !str_contains($observe_body, '$profileId')
        && !str_contains($observe_body, '$entityId')
        && !str_contains($observe_body, '$groupIds'),
    'Request-local shadow deduplication stores no ticket, room or actor identity'
);
glpichat_unit_assert_same(
    1,
    substr_count($observe_body, 'glpichat_capture_browser_actor_context('),
    'Enabled shadow captures exactly one immutable actor snapshot'
);
glpichat_unit_pass('Shadow helper is void, gated and request-bounded before work, and performs no ticket/DB/LDAP lookup');

$assert_legacy_wrapper = static function (
    string $body,
    string $legacy_expression,
    int $expected_ticket_can_calls,
    string $decision
): void {
    $current_position = strpos($body, '$currentAllowed = ' . $legacy_expression);
    $observe_position = strpos($body, 'glpichat_observe_public_authorization(');
    $return_position = strrpos($body, 'return $currentAllowed;');

    glpichat_unit_assert_true(
        $current_position !== false
            && $observe_position !== false
            && $return_position !== false
            && $current_position < $observe_position
            && $observe_position < $return_position,
        $decision . ' computes the inherited decision before its void shadow side effect and returns afterward'
    );
    glpichat_unit_assert_same(
        $expected_ticket_can_calls,
        substr_count($body, '->can('),
        $decision . ' preserves the inherited Ticket::can call count'
    );
    glpichat_unit_assert_same(
        1,
        substr_count($body, 'glpichat_observe_public_authorization('),
        $decision . ' has one and only one shadow observation site'
    );
    $ticket_load_position = strpos($body, 'glpichat_ticket_or_fail(');
    $first_ticket_can_position = strpos($body, '->can(');
    $last_right_position = strrpos($body, 'Session::haveRight(');
    glpichat_unit_assert_true(
        $ticket_load_position !== false
            && $first_ticket_can_position !== false
            && $last_right_position !== false
            && $ticket_load_position < $first_ticket_can_position
            && $last_right_position < $observe_position,
        $decision . ' completes inherited ticket/right evaluation before shadow observation'
    );
    glpichat_unit_assert_true(
        preg_match(
            '/if\s*\(\$room_type\s*===\s*GLPICHAT_ROOM_PUBLIC\)\s*\{\s*glpichat_observe_public_authorization\(/',
            $body
        ) === 1,
        $decision . ' observes only inside the explicit public-room branch'
    );
    glpichat_unit_assert_true(
        preg_match('/return\s+\$currentAllowed;\s*\}\s*\z/', $body) === 1,
        $decision . ' final statement returns the established decision unchanged'
    );

    $after_observation = substr($body, $observe_position);
    glpichat_unit_assert_true(
        preg_match('/\$currentAllowed\s*=/', $after_observation) !== 1,
        $decision . ' never reassigns the established decision after observation'
    );
};

$assert_legacy_wrapper(
    $send_body,
    'glpichat_can_send_from_state(',
    2,
    'Public send wrapper'
);
$assert_legacy_wrapper(
    $read_body,
    'glpichat_can_read_room_from_state(',
    1,
    'Public read wrapper'
);
glpichat_unit_assert_true(
    preg_match(
        '/glpichat_observe_public_authorization\(\s*AuthorizationShadow::PUBLIC_READ,\s*\$currentAllowed,\s*\$ticketCanRead,\s*false,\s*\$publicReadRight,\s*false\s*\)/',
        $read_body
    ) === 1,
    'Public read shadow receives explicit false terminal/CREATE facts and performs no irrelevant CREATE lookup'
);
glpichat_unit_assert_true(
    preg_match(
        '/glpichat_observe_public_authorization\(\s*AuthorizationShadow::PUBLIC_SEND,\s*\$currentAllowed,\s*\$publicTicketCanRead,\s*\$ticketTerminal,\s*\$publicReadRight,\s*\$publicCreateRight\s*\)/',
        $send_body
    ) === 1,
    'Public send shadow reuses the already-captured public CREATE fact'
);
glpichat_unit_pass('Read/send wrappers preserve current decisions and skip shadow work for internal rooms');

foreach (['src/Controller/GuestController.php', 'src/flows/guest_flow.php'] as $guest_path) {
    $guest_source = file_get_contents($plugin_root . '/' . $guest_path);
    if (!is_string($guest_source)) {
        glpichat_unit_fail('Unable to read Guest boundary: ' . $guest_path);
    }
    foreach ([
        'glpichat_observe_public_authorization',
        'PublicTicketAuthorization',
        'public_authorization_shadow_enabled',
    ] as $forbidden_guest_dependency) {
        glpichat_unit_assert_true(
            !str_contains($guest_source, $forbidden_guest_dependency),
            'Guest flow remains isolated from browser public shadow: ' . $forbidden_guest_dependency
        );
    }
}
glpichat_unit_pass('Guest protocol has no dependency on browser public-authorization shadow');

fwrite(STDOUT, "[PASS] Foundation authorization wiring contract completed\n");
