<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpichat;

use CronTask;
use Glpi\DBAL\QueryFunction;

use function glpichat_config_int;

final class EventCleanupCron
{
    // A scheduled run processes at most ten bounded batches. Oldest-first selection makes progress
    // after restarts without an OFFSET/cursor that could skip a late commit.
    public const BATCH_SIZE = 500;
    public const MAX_BATCHES = 10;
    public const RUN_BUDGET_SECONDS = 5;

    /** Bound work between batches; database lock/query timeouts remain server policy. */
    private static function runBatches(callable $batch): int
    {
        $start = hrtime(true);
        $deleted = 0;
        for ($n = 0; $n < self::MAX_BATCHES; ++$n) {
            if ($n > 0 && (hrtime(true) - $start) / 1e9 >= self::RUN_BUDGET_SECONDS) { break; }
            $count = $batch();
            $deleted += $count;
            if ($count < self::BATCH_SIZE) { break; }
        }
        return $deleted;
    }

    private static function logBacklog(CronTask $task, string $table, int $days, bool $textOnly = false): void
    {
        global $DB;
        $where = ['date_creation' => ['<', QueryFunction::dateSub(QueryFunction::now(), max(1, $days), 'DAY')]];
        if ($textOnly) { $where['documents_id'] = 0; }
        // Indexed LIMIT 1: no full backlog COUNT or GROUP BY on the hot table.
        foreach ($DB->request([
            'SELECT' => ['date_creation'], 'FROM' => $table, 'WHERE' => $where,
            'ORDERBY' => ['date_creation ASC', 'id ASC'], 'LIMIT' => 1,
        ]) as $row) {
            $task->log('Retention backlog remains; oldest eligible record: ' . (string) $row['date_creation'] . '.');
            return;
        }
        $task->log('No eligible retention backlog observed after this run.');
    }

    public static function cronInfo(string $name): array
    {
        return match ($name) {
            'CleanEvents'    => ['description' => __('Delete GLPI Chat events older than configured retention days.')],
            'CleanMessages'  => ['description' => __('Delete expired GLPI Chat text messages; preserve attachment authorization evidence.')],
            'CleanAuditlogs' => ['description' => __('Delete GLPI Chat audit logs older than configured retention days.')],
            default => [],
        };
    }

    public static function cronCleanEvents(CronTask $task): int
    {
        $days = glpichat_config_int('events_retention_days', 30);
        $deleted = self::runBatches(static fn(): int => self::deleteExpiredEvents($days));
        require_once __DIR__ . '/db/guest_db.php';
        $receipts = \glpichat_cleanup_guest_receipts();
        if ($receipts > 0) { $task->log(sprintf('Deleted %d expired guest delivery receipts.', $receipts)); }
        $task->addVolume($deleted + $receipts);
        $task->log(sprintf('Deleted %d GLPI Chat event records older than %d days (up to %d per run).', $deleted, $days, self::BATCH_SIZE * self::MAX_BATCHES));

        self::logBacklog($task, 'glpi_plugin_glpichat_events', $days);
        return ($deleted + $receipts) > 0 ? 1 : 0;
    }

    public static function deleteExpiredEvents(?int $days = null): int
    {
        global $DB;

        $days = $days ?? glpichat_config_int('events_retention_days', 30);

        return self::deleteExpiredBatch('glpi_plugin_glpichat_events', $days);
    }

    /** Select no more than one indexed oldest-first batch before deleting. */
    private static function deleteExpiredBatch(string $table, int $days): int
    {
        global $DB;
        $where = ['date_creation' => ['<', QueryFunction::dateSub(QueryFunction::now(), max(1, $days), 'DAY')]];
        $ids = [];
        foreach ($DB->request([
            'SELECT' => ['id'], 'FROM' => $table, 'WHERE' => $where,
            'ORDERBY' => ['date_creation ASC', 'id ASC'], 'LIMIT' => self::BATCH_SIZE,
        ]) as $row) {
            $ids[] = (int) $row['id'];
        }
        if ($ids === []) { return 0; }
        // Retention is rechecked, so a stale selection is not deletion authority.
        if ($DB->delete($table, ['id' => $ids] + $where) === false) {
            throw new \RuntimeException('GLPI Chat retention batch could not be deleted.');
        }
        return (int) $DB->affectedRows();
    }

    public static function cronCleanMessages(CronTask $task): int
    {
        $days = glpichat_config_int('messages_retention_days', 365);
        $deleted = self::runBatches(static fn(): int => self::deleteExpiredMessages($days));
        $task->addVolume($deleted);
        $task->log(sprintf('Deleted %d GLPI Chat text message records older than %d days. Attachment records retained for authorization and audit; up to %d text records per run.', $deleted, $days, self::BATCH_SIZE * self::MAX_BATCHES));

        self::logBacklog($task, 'glpi_plugin_glpichat_messages', $days, true);
        return $deleted > 0 ? 1 : 0;
    }

    public static function deleteExpiredMessages(?int $days = null): int
    {
        global $DB;

        $days = $days ?? glpichat_config_int('messages_retention_days', 365);
        $days = max(1, $days);
        // Attachment mirrors are authorization evidence for canDocument(). Keep
        // every attachment, including public mirrors that can become private.
        // Lock only one indexed text batch and publish its purge events in the
        // same transaction: an insert/delete failure cannot leave false evidence.
        $DB->beginTransaction();
        try {
            $result = $DB->doQuery('SELECT id, rooms_id, date_creation FROM glpi_plugin_glpichat_messages'
                . ' WHERE documents_id = 0 AND date_creation < DATE_SUB(NOW(), INTERVAL ' . $days . ' DAY)'
                . ' ORDER BY date_creation ASC, id ASC LIMIT ' . self::BATCH_SIZE . ' FOR UPDATE');
            if ($result === false) { throw new \RuntimeException('GLPI Chat retention batch could not be selected.'); }
            $ids = [];
            $rooms = [];
            while ($row = $DB->fetchAssoc($result)) {
                $ids[] = (int) $row['id'];
                $roomId = (int) $row['rooms_id'];
                if (!isset($rooms[$roomId])) { $rooms[$roomId] = (string) $row['date_creation']; }
            }
            if ($ids === []) {
                $DB->commit();
                return 0;
            }
            // One bounded lookup instead of a query per message/room. Orphaned
            // text can still be removed, as before, without a fabricated event.
            foreach ($DB->request([
                'SELECT' => ['id', 'tickets_id'], 'FROM' => 'glpi_plugin_glpichat_rooms',
                'WHERE' => ['id' => array_keys($rooms)], 'LIMIT' => self::BATCH_SIZE,
            ]) as $room) {
                $roomId = (int) $room['id'];
                if (!isset($rooms[$roomId])) { continue; }
                if ($DB->insert('glpi_plugin_glpichat_events', [
                    'rooms_id' => $roomId, 'tickets_id' => (int) $room['tickets_id'],
                    'event_type' => 'messages_purged', 'actor_type' => 'system',
                    'users_id' => 0, 'participants_id' => 0,
                    'payload_json' => json_encode(['purged_before' => substr($rooms[$roomId], 0, 10)]),
                    'date_creation' => QueryFunction::now(),
                ]) === false) { throw new \RuntimeException('GLPI Chat retention evidence could not be recorded.'); }
            }
            if ($DB->delete('glpi_plugin_glpichat_messages', [
                'id' => $ids, 'documents_id' => 0,
                'date_creation' => ['<', QueryFunction::dateSub(QueryFunction::now(), $days, 'DAY')],
            ]) === false) { throw new \RuntimeException('GLPI Chat text retention batch could not be deleted.'); }
            $deleted = (int) $DB->affectedRows();
            $DB->commit();
            return $deleted;
        } catch (\Throwable $error) {
            $DB->rollBack();
            throw $error;
        }
    }

    public static function cronCleanAuditlogs(CronTask $task): int
    {
        $days = glpichat_config_int('auditlogs_retention_days', 180);
        $deleted = self::runBatches(static fn(): int => self::deleteExpiredAuditlogs($days));
        $task->addVolume($deleted);
        $task->log(sprintf('Deleted %d GLPI Chat audit log records older than %d days (up to %d per run).', $deleted, $days, self::BATCH_SIZE * self::MAX_BATCHES));

        self::logBacklog($task, 'glpi_plugin_glpichat_auditlogs', $days);
        return $deleted > 0 ? 1 : 0;
    }

    public static function deleteExpiredAuditlogs(?int $days = null): int
    {
        global $DB;

        $days = $days ?? glpichat_config_int('auditlogs_retention_days', 180);

        return self::deleteExpiredBatch('glpi_plugin_glpichat_auditlogs', $days);
    }
}
