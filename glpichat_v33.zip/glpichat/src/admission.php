<?php

declare(strict_types=1);

require_once __DIR__ . '/desktop/common.php';

/** Internal rollback signal, never serialized to an HTTP response. */
final class GlpichatAdmissionRejected extends RuntimeException
{
    public function __construct(public readonly array $result) { parent::__construct('Admission rejected.'); }
}

/** SQL unsigned BIGINT must fit PHP's signed integer without lossy coercion. */
function glpichat_admission_integer(mixed $value): int
{
    if (is_int($value) && $value >= 0) { return $value; }
    if (is_string($value) && preg_match('/\A(?:0|[1-9][0-9]{0,18})\z/D', $value) === 1
        && (strlen($value) < strlen((string) PHP_INT_MAX)
            || (strlen($value) === strlen((string) PHP_INT_MAX) && strcmp($value, (string) PHP_INT_MAX) <= 0))) {
        return (int) $value;
    }
    throw new RuntimeException('Invalid admission counter storage.');
}

/** Transaction-local row lock; same primary key also serializes first creation. */
function glpichat_admission_lock_bucket(string $key): array
{
    global $DB;
    if (preg_match('/\A[a-f0-9]{64}\z/D', $key) !== 1) { throw new InvalidArgumentException('Invalid admission key.'); }
    $keySql = glpichat_desktop_quote($key);
    if ($DB->doQuery('INSERT INTO glpi_plugin_glpichat_admission (bucket_key, window_start, used, expires_at) '
        . "VALUES ($keySql, 0, 0, DATE_ADD(UTC_TIMESTAMP(), INTERVAL 2 DAY)) ON DUPLICATE KEY UPDATE bucket_key=bucket_key") === false) {
        throw new RuntimeException('Admission bucket creation failed.');
    }
    $row = glpichat_desktop_db_rows('SELECT window_start, used FROM glpi_plugin_glpichat_admission '
        . "WHERE bucket_key=$keySql FOR UPDATE");
    if (count($row) !== 1) { throw new RuntimeException('Admission bucket unavailable.'); }
    return $row[0];
}

/** Acquire BEFORE ticket/receipt locks; does not consume a replay's allowance. */
function glpichat_admission_message_lock(int $userId): void
{
    if ($userId < 1) { throw new InvalidArgumentException('Invalid admission user.'); }
    glpichat_admission_lock_bucket(hash('sha256', "chat_mutation\0user:" . $userId . "\0" . '60'));
}

/**
 * Atomic, database-clock fixed-window admission. Subjects are trusted server
 * identities, never source IP addresses or raw credentials. One reused row per
 * scope/subject/window length bounds storage independently of request volume.
 * Fixed windows can admit two bursts across their boundary; these are not
 * advertised as an exact rolling-window quota.
 */
function glpichat_admission_take(array $rules): array
{
    try {
        return glpichat_desktop_transaction(static function () use ($rules): array {
            $result = glpichat_admission_take_locked($rules);
            // Roll back tentative row creation too: a throttled machine must
            // not grow storage by proposing unlimited distinct user subjects.
            if (!$result['allowed']) { throw new GlpichatAdmissionRejected($result); }
            return $result;
        });
    } catch (GlpichatAdmissionRejected $rejected) {
        return $rejected->result;
    }
}

/** Caller MUST own a transaction; rejection leaves every counter unchanged. */
function glpichat_admission_take_locked(array $rules): array
{
    global $DB;
    if (!$rules || count($rules) > 8) { throw new InvalidArgumentException('Invalid admission rule count.'); }
    $normalized = [];
    foreach ($rules as $rule) {
        if (!is_array($rule) || !is_string($rule['scope'] ?? null)
            || preg_match('/\A[a-z][a-z0-9_]{0,31}\z/D', $rule['scope']) !== 1
            || !is_string($rule['subject'] ?? null) || $rule['subject'] === '' || strlen($rule['subject']) > 512
            || !is_int($rule['limit'] ?? null) || $rule['limit'] < 1
            || !is_int($rule['window_seconds'] ?? null) || $rule['window_seconds'] < 1 || $rule['window_seconds'] > 86400) {
            throw new InvalidArgumentException('Invalid admission rule.');
        }
        $rule['cost'] ??= 1;
        if (!is_int($rule['cost']) || $rule['cost'] < 1 || $rule['cost'] > $rule['limit']) {
            throw new InvalidArgumentException('Invalid admission cost.');
        }
        $key = hash('sha256', $rule['scope'] . "\0" . $rule['subject'] . "\0" . $rule['window_seconds']);
        if (isset($normalized[$key])) { throw new InvalidArgumentException('Duplicate admission bucket.'); }
        $normalized[$key] = $rule;
    }
    ksort($normalized, SORT_STRING);
    $rows = [];
    foreach ($normalized as $key => $rule) {
        $rows[$key] = glpichat_admission_lock_bucket($key);
    }
    // Read time after acquiring all locks, so a wait across a window boundary
    // cannot debit an expired window. UNIX_TIMESTAMP is timezone independent.
    $clock = glpichat_desktop_db_rows('SELECT UNIX_TIMESTAMP() AS admission_now');
    $now = glpichat_admission_integer($clock[0]['admission_now'] ?? null);
    if ($now <= 0 || $now > PHP_INT_MAX - 172800) { throw new RuntimeException('Admission clock unavailable.'); }
    $wait = 0;
    $updates = [];
    foreach ($normalized as $key => $rule) {
        $window = $rule['window_seconds'];
        $start = intdiv($now, $window) * $window;
        $storedStart = glpichat_admission_integer($rows[$key]['window_start'] ?? null);
        $storedUsed = glpichat_admission_integer($rows[$key]['used'] ?? null);
        if ($storedStart > PHP_INT_MAX - 172800 || $storedStart % $window !== 0) {
            throw new RuntimeException('Invalid admission window storage.');
        }
        // Clock rollback must not replenish a still-future bucket.
        $used = $storedStart >= $start ? $storedUsed : 0;
        $start = max($start, $storedStart);
        if ($used < 0 || $used > $rule['limit'] || $rule['cost'] > $rule['limit'] - $used) {
            $wait = max($wait, min(86400, max(1, $start + $window - $now)));
        } else {
            $updates[$key] = [$start, $used + $rule['cost'], gmdate('Y-m-d H:i:s', $start + $window + 86400)];
        }
    }
    if ($wait > 0) { return ['allowed' => false, 'retry_after' => $wait]; }
    foreach ($updates as $key => [$start, $used, $expires]) {
        if ($DB->doQuery('UPDATE glpi_plugin_glpichat_admission SET window_start=' . $start . ', used=' . $used
            . ', expires_at=' . glpichat_desktop_quote($expires) . ' WHERE bucket_key=' . glpichat_desktop_quote($key)) === false) {
            throw new RuntimeException('Admission bucket update failed.');
        }
    }
    return ['allowed' => true, 'retry_after' => 0];
}

/** Fresh browser/desktop mutations only, AFTER authorization and receipt replay. */
function glpichat_admission_message(int $userId, ?int $attachmentBytes = null, ?int $maxFileBytes = null): void
{
    if ($userId < 1 || ($attachmentBytes !== null && ($attachmentBytes < 0 || $maxFileBytes === null || $maxFileBytes < $attachmentBytes))) {
        throw new InvalidArgumentException('Invalid message admission subject.');
    }
    // The native GLPI account ID is identical across web/device contexts. It is
    // not a device, ticket or session key, so switching those cannot refill it.
    // Rows expire after inactivity: this is a short-lived quota, not authority
    // evidence or a permanent block that could leak to a recreated identity.
    $rules = [['scope' => 'chat_mutation', 'subject' => 'user:' . $userId, 'limit' => 30, 'window_seconds' => 60]];
    if ($attachmentBytes !== null && $attachmentBytes > 0) {
        $rules[] = ['scope' => 'chat_upload_bytes', 'subject' => 'user:' . $userId,
            'limit' => max(100 * 1048576, $maxFileBytes), 'window_seconds' => 60, 'cost' => $attachmentBytes];
    }
    $result = glpichat_admission_take_locked($rules);
    if (!$result['allowed']) {
        glpichat_desktop_fail('send_throttled', 'Aguarde antes de enviar novas mensagens ou anexos.', 429,
            ['retry_after' => $result['retry_after']]);
    }
}

/** Pilot defaults are safety budgets, not a measured fleet capacity claim. */
function glpichat_admission_desktop_limit_specs(): array
{
    return [
        'desktop_read_device_per_minute' => [90, 30, 600],
        'desktop_read_summary_per_minute' => [6000, 64, 6000000],
        'desktop_read_identity_per_minute' => [30000, 64, 6000000],
        'desktop_download_mib_per_minute' => [256, 16, 4096],
        'desktop_directory_work_per_minute' => [600, 8, 600000],
        'desktop_poll_idle_seconds' => [30, 5, 60],
        'desktop_poll_active_seconds' => [5, 3, 15],
        'desktop_summary_reconcile_seconds' => [120, 30, 300],
    ];
}

/** Missing settings use the pilot defaults; corrupt explicit settings fail closed. */
function glpichat_admission_desktop_limit(string $key, mixed $value): int
{
    $specs = glpichat_admission_desktop_limit_specs();
    if (!isset($specs[$key])) { throw new InvalidArgumentException('Unknown desktop admission setting.'); }
    [$default, $minimum, $maximum] = $specs[$key];
    if ($value === null || $value === '') { return $default; }
    if ((!is_int($value) && (!is_string($value) || preg_match('/\A[1-9][0-9]{0,7}\z/D', $value) !== 1))
        || (int) $value < $minimum || (int) $value > $maximum) {
        throw new InvalidArgumentException('Invalid desktop admission setting: ' . $key);
    }
    return (int) $value;
}

/**
 * Background reads have independent device and shared-server budgets. The
 * authenticated database device id belongs to a single user/installation;
 * neither an IP, a login nor a client-selected identifier is a quota key.
 *
 * Sixty-four deterministic aggregate shards avoid one SQL lock for every
 * heartbeat. Their allowances sum to the configured total exactly, even when
 * it is not divisible by 64. A hot shard can run out while another has unused
 * capacity: this conservative partition is not a work-conserving scheduler.
 * Fixed minute windows are burst budgets, not an exact requests/second cap.
 */
function glpichat_admission_desktop_read_rules(array $actor, string $lane): array
{
    if (!in_array($lane, ['identity', 'summary'], true)) {
        throw new InvalidArgumentException('Invalid desktop read admission lane.');
    }
    $device = $actor['device_db_id'] ?? null;
    if (!is_int($device) || $device < 1) { throw new InvalidArgumentException('Invalid authenticated desktop device.'); }
    $deviceLimit = glpichat_admission_desktop_limit('desktop_read_device_per_minute',
        glpichat_desktop_config('desktop_read_device_per_minute'));
    $key = 'desktop_read_' . $lane . '_per_minute';
    $total = glpichat_admission_desktop_limit($key, glpichat_desktop_config($key));
    $shard = (int) (hexdec(substr(hash('sha256', 'desktop-read:' . $device), 0, 8)) % 64);
    $share = intdiv($total, 64) + ($shard < $total % 64 ? 1 : 0);
    return [
        ['scope' => 'desktop_' . $lane . '_device', 'subject' => 'device:' . $device,
            'limit' => $deviceLimit, 'window_seconds' => 60],
        ['scope' => 'desktop_' . $lane . '_fleet', 'subject' => 'shard:' . $shard,
            'limit' => $share, 'window_seconds' => 60],
    ];
}

/** Call after authentication, before background content work, outside content locks. */
function glpichat_admission_desktop_read(array $actor, string $lane): void
{
    try {
        $result = glpichat_admission_take(glpichat_admission_desktop_read_rules($actor, $lane));
    } catch (Throwable $error) {
        // A fleet-wide limiter outage must not generate one log line per
        // polling connection. This stable diagnostic code identifies the
        // failed subsystem without disclosing SQL or treating it as revoke.
        // The transaction helper already rolls back any partial reservation.
        glpichat_desktop_fail('read_budget_unavailable',
            'O controle de consultas está temporariamente indisponível. O aplicativo tentará novamente.', 503);
    }
    if (!$result['allowed']) {
        glpichat_desktop_fail('read_throttled', 'O servidor está limitando consultas em segundo plano. O aplicativo tentará novamente.',
            429, ['retry_after' => $result['retry_after']]);
    }
}

/** Reserve every configured LDAP source before starting any search. Eight
 * machine/SID shards avoid a single fleet lock while retaining an exact total
 * work budget. This counts directory searches, including failures and absent
 * users, not successful grants. Never hold SQL locks during network work.
 */
function glpichat_admission_directory_rules(int $machine, string $sid, int $sources): array
{
    if ($machine < 1 || $sid === '' || $sources < 1) { throw new InvalidArgumentException('Invalid directory admission subject.'); }
    $total = glpichat_admission_desktop_limit('desktop_directory_work_per_minute',
        glpichat_desktop_config('desktop_directory_work_per_minute'));
    $shard = (int) (hexdec(substr(hash('sha256', 'directory:' . $machine . ':' . $sid), 0, 8)) % 8);
    $share = intdiv($total, 8) + ($shard < $total % 8 ? 1 : 0);
    // An undersized configuration cannot be worked around by partial searches:
    // those would repeatedly spend the first sources without proving uniqueness.
    if ($sources > $share) { throw new InvalidArgumentException('Directory budget smaller than one complete resolution.'); }
    return [['scope' => 'automatic_directory_fleet', 'subject' => 'shard:' . $shard,
        'limit' => $share, 'window_seconds' => 60, 'cost' => $sources]];
}

function glpichat_admission_directory(int $machine, string $sid, int $sources): void
{
    if ($sources === 0) { return; } // No search to charge; normal identity resolution fails closed.
    try { $result = glpichat_admission_take(glpichat_admission_directory_rules($machine, $sid, $sources)); }
    catch (Throwable $error) {
        glpichat_desktop_fail('directory_budget_unavailable', 'O controle de consultas ao diretório está indisponível. Tentaremos novamente.',
            503, ['retry_after' => 60]);
    }
    if (!$result['allowed']) {
        glpichat_desktop_fail('directory_throttled', 'A consulta ao diretório foi adiada. A solicitação de conexão foi mantida.',
            429, ['retry_after' => $result['retry_after']]);
    }
}

/** Indexed, bounded maintenance; no receipt, credential or audit data removed. */
function glpichat_admission_cleanup(int $limit = 1000): int
{
    global $DB;
    if ((string) glpichat_desktop_config('desktop_schema_version') !== '14') { return 0; }
    $limit = max(1, min(1000, $limit));
    if ($DB->doQuery('DELETE FROM glpi_plugin_glpichat_admission WHERE expires_at < UTC_TIMESTAMP() '
        . 'ORDER BY expires_at, bucket_key LIMIT ' . $limit) === false) {
        throw new RuntimeException('Admission cleanup failed.');
    }
    return (int) $DB->affectedRows();
}
