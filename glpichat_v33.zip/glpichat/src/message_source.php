<?php

declare(strict_types=1);

/** One byte allowance for every message array in an HTTP response. JsonResponse
 * escapes these characters by default; count encoded UTF-8, never characters.
 * The controller reserves its complete non-message envelope before hydration. */
final class GlpichatMessageBudget
{
    public const MAX_BYTES = 4194304;
    private int $remaining;
    private $decorate;
    private ?self $parent = null;
    public function __construct(int $bytes = self::MAX_BYTES, ?callable $decorate = null)
    { $this->remaining = max(0, $bytes); $this->decorate = $decorate; }
    public static function bytes(array $value): int
    { return strlen(json_encode($value, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT | JSON_THROW_ON_ERROR)); }
    public function reserve(array $envelope, int $continuationBytes = 0): void
    {
        $cost = self::bytes($envelope) + max(0, $continuationBytes);
        if ($cost > $this->remaining) { throw new RuntimeException('Chat response metadata exceeds the response limit.'); }
        $this->remaining -= $cost;
    }
    public function prepare(array $rows): array
    { return $this->decorate === null ? $rows : ($this->decorate)($rows); }
    public function window(int $bytes = 2097152): self
    {
        $child = new self(min($this->remaining, max(0, $bytes)), $this->decorate);
        $child->parent = $this;
        return $child;
    }
    public function take(array $row): bool
    {
        $cost = self::bytes($row) + 1; // Includes the array separator.
        return $this->consume($cost);
    }
    private function consume(int $cost): bool
    {
        if ($cost > $this->remaining) { return false; }
        if ($this->parent !== null && !$this->parent->consume($cost)) { return false; }
        $this->remaining -= $cost;
        return true;
    }
}

/** Select only display/source metadata and bounded body bytes. Native bodies
 * are authoritative, so do not also fetch their obsolete mirror copy. */
function glpichat_message_projection(): array
{
    return ['id', 'rooms_id', 'tickets_id', 'participant_type', 'users_id', 'participants_id',
        'message_type', 'documents_id', 'itilfollowups_id', 'date_creation',
        new \Glpi\DBAL\QueryExpression("CASE WHEN itilfollowups_id > 0 THEN '' WHEN OCTET_LENGTH(content) <= 262144 THEN content ELSE 'Conteúdo disponível no GLPI.' END AS content")];
}

/** Size metadata keeps ordinary short-message windows batched. Fixed batches
 * of eight would multiply normal refresh queries. A hard 32-row cap also
 * bounds concurrent content growth between this metadata read and hydration
 * to 8MiB of native body bytes, even when every native row changes at once. */
function glpichat_message_hydration_chunks(array $ids): array
{
    if ($ids === []) { return []; }
    if (count($ids) > 200) { throw new InvalidArgumentException('Message window exceeds 200 IDs.'); }
    global $DB;
    $length = 'CASE WHEN itilfollowups_id>0 THEN COALESCE((SELECT CASE WHEN OCTET_LENGTH(bf.content)<=262144 '
        . 'THEN OCTET_LENGTH(bf.content) ELSE 0 END FROM glpi_itilfollowups bf '
        . 'WHERE bf.id=glpi_plugin_glpichat_messages.itilfollowups_id),0) '
        . 'ELSE LEAST(OCTET_LENGTH(content),262144) END AS body_bytes';
    $sizes = [];
    foreach ($DB->request(['SELECT' => ['id', new \Glpi\DBAL\QueryExpression($length)],
        'FROM' => 'glpi_plugin_glpichat_messages', 'WHERE' => ['id' => $ids], 'LIMIT' => 200]) as $row) {
        $sizes[(int) $row['id']] = max(0, min(262144, (int) $row['body_bytes']));
    }
    $chunks = $chunk = []; $bytes = 0;
    foreach ($ids as $id) {
        $cost = $sizes[$id] ?? 0;
        if ($chunk && (count($chunk) >= 32 || $bytes + $cost > 2097152)) { $chunks[] = $chunk; $chunk = []; $bytes = 0; }
        $chunk[] = $id; $bytes += $cost;
    }
    if ($chunk) { $chunks[] = $chunk; }
    return $chunks;
}

/** One current-source rule for browser/guest history, heads and unread counts. */
function glpichat_current_message_predicate(string $alias = 'glpi_plugin_glpichat_messages'): string
{
    if (!in_array($alias, ['m', 'glpi_plugin_glpichat_messages'], true)) {
        throw new InvalidArgumentException('Unsupported message alias.');
    }
    return "EXISTS (SELECT 1 FROM glpi_plugin_glpichat_rooms vr WHERE vr.id = $alias.rooms_id "
        . "AND vr.tickets_id = $alias.tickets_id AND BINARY vr.room_type IN (BINARY 'public',BINARY 'internal') AND ("
        . "($alias.itilfollowups_id = 0 AND $alias.participant_type IN (BINARY 'guest',BINARY 'system')) OR EXISTS ("
        . "SELECT 1 FROM glpi_itilfollowups vf WHERE vf.id = $alias.itilfollowups_id "
        . "AND BINARY vf.itemtype = BINARY 'Ticket' AND vf.items_id = $alias.tickets_id "
        . "AND ((BINARY vr.room_type = BINARY 'public' AND vf.is_private = 0) OR (BINARY vr.room_type = BINARY 'internal' AND vf.is_private = 1)))))";
}

/** Pure source check, also used by receipt and visibility qualification. */
function glpichat_current_message_visible(array $message, ?array $room, ?array $followup): bool
{
    if ($room === null || (int) ($room['id'] ?? 0) !== (int) ($message['rooms_id'] ?? 0)
        || (int) ($room['tickets_id'] ?? 0) !== (int) ($message['tickets_id'] ?? 0)
        || !in_array($room['room_type'] ?? '', ['public', 'internal'], true)) {
        return false;
    }
    if ((int) ($message['itilfollowups_id'] ?? 0) === 0) {
        return in_array($message['participant_type'] ?? '', ['guest', 'system'], true);
    }
    return $followup !== null && (int) ($followup['id'] ?? 0) === (int) $message['itilfollowups_id']
        && ($followup['itemtype'] ?? '') === 'Ticket'
        && (int) ($followup['items_id'] ?? 0) === (int) $message['tickets_id']
        && (int) ($followup['is_private'] ?? -1) === ($room['room_type'] === 'internal' ? 1 : 0);
}

/** Refresh a bounded mirror window; callers retain its raw cursor before filtering. */
function glpichat_current_message_rows(array $rows): array
{
    global $DB;
    if ($rows === []) { return []; }
    if (count($rows) > 200) { throw new InvalidArgumentException('Message window exceeds 200 rows.'); }
    $collect = static fn(string $key): array => array_values(array_unique(array_filter(array_map(
        static fn(array $row): int => (int) ($row[$key] ?? 0), $rows), static fn(int $id): bool => $id > 0)));
    $rooms = $followups = $documents = $links = [];
    foreach ($DB->request(['SELECT' => ['id', 'tickets_id', 'room_type'], 'FROM' => 'glpi_plugin_glpichat_rooms',
        'WHERE' => ['id' => $collect('rooms_id')]]) as $room) { $rooms[(int) $room['id']] = $room; }
    $followupIds = $collect('itilfollowups_id');
    if ($followupIds) {
        foreach ($DB->request(['SELECT' => ['id', 'itemtype', 'items_id', 'is_private',
            new \Glpi\DBAL\QueryExpression("CASE WHEN OCTET_LENGTH(content) <= 262144 THEN content ELSE '' END AS content")],
            'FROM' => 'glpi_itilfollowups', 'WHERE' => ['id' => $followupIds]]) as $followup) {
            $followups[(int) $followup['id']] = $followup;
        }
    }
    $documentIds = $collect('documents_id');
    if ($documentIds) {
        foreach ($DB->request(['SELECT' => ['id'], 'FROM' => 'glpi_documents',
            'WHERE' => ['id' => $documentIds, 'is_deleted' => 0, 'is_blacklisted' => 0]]) as $document) {
            $documents[(int) $document['id']] = true;
        }
        foreach ($DB->request(['SELECT' => ['documents_id', 'itemtype', 'items_id'], 'FROM' => 'glpi_documents_items',
            'WHERE' => ['documents_id' => $documentIds, 'OR' => [
                ['itemtype' => 'ITILFollowup', 'items_id' => $followupIds ?: [0]],
                ['itemtype' => 'Ticket', 'items_id' => $collect('tickets_id')],
            ]]]) as $link) {
            $links[(int) $link['documents_id'] . ':' . $link['itemtype'] . ':' . (int) $link['items_id']] = true;
        }
    }
    $visible = [];
    foreach ($rows as $row) {
        $followupId = (int) ($row['itilfollowups_id'] ?? 0);
        $followup = $followups[$followupId] ?? null;
        if (!glpichat_current_message_visible($row, $rooms[(int) $row['rooms_id']] ?? null, $followup)) { continue; }
        if ($followup !== null) {
            // The copied text is not authority after a native edit.
            $row['content'] = glpichat_desktop_text((string) $followup['content'], 262144);
        } elseif (preg_match('//u', (string) ($row['content'] ?? '')) !== 1) {
            $row['content'] = 'Conteúdo disponível no GLPI.';
        }
        $documentId = (int) ($row['documents_id'] ?? 0);
        if ($documentId > 0 && (!isset($documents[$documentId])
            || (!isset($links[$documentId . ':ITILFollowup:' . $followupId])
                && !isset($links[$documentId . ':Ticket:' . (int) $row['tickets_id']])))) {
            $row['documents_id'] = 0;
            $row['message_type'] = 'message';
        }
        $visible[] = $row;
    }
    return $visible;
}

/** Read acknowledgements share native IDs only for current public user messages. */
function glpichat_public_read_bridge_predicate(int $userId, string $alias = 'glpi_plugin_glpichat_messages'): string
{
    if ($userId <= 0 || !in_array($alias, ['m', 'glpi_plugin_glpichat_messages'], true)) {
        throw new InvalidArgumentException('Invalid read bridge scope.');
    }
    return "NOT ($alias.participant_type = 'user' AND EXISTS (SELECT 1 FROM glpi_plugin_glpichat_rooms br "
        . "WHERE br.id = $alias.rooms_id AND br.room_type = 'public') AND EXISTS ("
        . "SELECT 1 FROM glpi_plugin_glpichat_desktopreads dr WHERE dr.users_id = $userId "
        . "AND dr.itilfollowups_id = $alias.itilfollowups_id))";
}
