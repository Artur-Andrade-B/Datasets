<?php

declare(strict_types=1);
require_once __DIR__ . '/management.php';

const GLPICHAT_MANAGEMENT_ROLLOUTS = 'glpi_plugin_glpichat_desktoprollouts';
const GLPICHAT_MANAGEMENT_TARGETS = 'glpi_plugin_glpichat_desktoprollouttargets';

/** Fleet console fields are introduced in schema12; machine protocol keeps
 * its independently declared compatibility with older installed schemas. */
function glpichat_management_fleet_require_schema(): void
{
    if ((string) glpichat_desktop_config('desktop_schema_version') !== '14') { glpichat_desktop_fail('schema_unavailable', 'Conclua a atualização do plugin para abrir o gerenciamento de computadores.', 503); }
}

function glpichat_management_issuing_profile(): ?int
{
    $value = $_SESSION['glpiactiveprofile']['id'] ?? null;
    return (is_int($value) || is_string($value)) && preg_match('/\A[1-9][0-9]{0,9}\z/D', (string) $value) === 1 && (float) $value <= 4294967295 ? (int) $value : null;
}

/** Current rights protect new administrative intent and permission jobs.
 * Approved update campaigns belong to the organization, not an active session. */
function glpichat_management_admin_has_right(int $id, ?int $profile, int $mask, bool $lock = false): bool
{
    if ($id < 1 || $mask < 1) { return false; }
    $sql = 'SELECT u.id FROM glpi_users u INNER JOIN glpi_profiles_users pu ON pu.users_id=u.id INNER JOIN glpi_profiles p ON p.id=pu.profiles_id'
        . ' INNER JOIN glpi_profilerights pr ON pr.profiles_id=pu.profiles_id WHERE u.id=' . $id
        . " AND u.is_active=1 AND u.is_deleted=0 AND (u.begin_date IS NULL OR u.begin_date<=CURRENT_TIMESTAMP) AND (u.end_date IS NULL OR u.end_date>=CURRENT_TIMESTAMP)"
        . " AND pr.name='plugin_glpichat_admin' AND (pr.rights & " . $mask . ')=' . $mask . ($profile > 0 ? ' AND pu.profiles_id=' . $profile : '') . ' LIMIT 1' . ($lock ? ' LOCK IN SHARE MODE' : '');
    return (bool) glpichat_desktop_db_rows($sql);
}

function glpichat_management_require_rollout_actor(array $rollout, bool $lock = false): void
{
    if (glpichat_management_claims_ready() && in_array($rollout['action'] ?? '', ['update', 'repair'], true)) { return; }
    if (!glpichat_management_admin_has_right((int) ($rollout['created_by'] ?? 0), isset($rollout['issuing_profile_id']) ? (int) $rollout['issuing_profile_id'] : null, defined('UPDATE') ? (int) UPDATE : 2, $lock)) {
        glpichat_desktop_fail('issuer_authority_lost', 'O solicitante perdeu a permissão administrativa. Um administrador autorizado deve criar uma nova operação.', 409);
    }
}

/** One allowlisted vocabulary shared by the list and immutable previews. */
function glpichat_management_filters(array $input): array
{
    $filters = [];
    foreach (['q' => 100, 'user' => 100, 'search_mode' => 16, 'version' => 32, 'status' => 16, 'binding_status' => 16, 'health' => 16, 'contact' => 16, 'contact_from' => 19, 'contact_to' => 19, 'operation_status' => 16, 'sort' => 16, 'direction' => 4] as $key => $limit) {
        $value = $input[$key] ?? '';
        if (!is_string($value) || strlen($value) > $limit || preg_match('//u', $value) !== 1 || preg_match('/[\x00-\x1f\x7f]/', $value)) { glpichat_desktop_fail('invalid_request', 'Filtro inválido.', 400); }
        $filters[$key] = trim($value);
    }
    $filters['search_mode'] = $filters['search_mode'] ?: 'prefix';
    $filters['sort'] = $filters['sort'] ?: 'id'; $filters['direction'] = $filters['direction'] ?: 'desc';
    foreach (['search_mode' => ['exact', 'prefix', 'contains'], 'sort' => ['id', 'name', 'contact'], 'direction' => ['asc', 'desc'], 'status' => ['', 'active', 'revoked', 'retired', 'blocked_users'], 'binding_status' => ['', 'blocked', 'allowed'], 'health' => ['', 'healthy', 'damaged', 'trial', 'unavailable'], 'contact' => ['', 'recent', 'offline', 'never'], 'operation_status' => ['', 'none', 'queued', 'waiting', 'pending', 'started', 'unknown', 'completed', 'failed', 'skipped', 'superseded', 'cancelled', 'withdrawn', 'retired']] as $key => $allowed) {
        if (!in_array($filters[$key], $allowed, true)) { glpichat_desktop_fail('invalid_request', 'Filtro inválido.', 400); }
    }
    if ($filters['status'] === 'blocked_users' && $filters['binding_status'] === 'allowed') { glpichat_desktop_fail('invalid_request', 'Filtros de conexão contraditórios.', 400); }
    if ($filters['search_mode'] === 'contains' && $filters['q'] !== '' && strlen($filters['q']) < 3) { glpichat_desktop_fail('invalid_request', 'A busca por trecho exige pelo menos três caracteres.', 400); }
    foreach (['contact_from', 'contact_to'] as $key) {
        if ($filters[$key] !== '') {
            $date = DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $filters[$key], new DateTimeZone('UTC'));
            if (!$date || $date->format('Y-m-d H:i:s') !== $filters[$key]) { glpichat_desktop_fail('invalid_request', 'Data de contato inválida. Use AAAA-MM-DD HH:MM:SS UTC.', 400); }
        }
    }
    if ($filters['contact_from'] !== '' && $filters['contact_to'] !== '' && $filters['contact_from'] > $filters['contact_to']) { glpichat_desktop_fail('invalid_request', 'Intervalo de contato inválido.', 400); }
    return $filters;
}

function glpichat_management_latest_join(): string
{
    return ' LEFT JOIN ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' a ON a.id=(SELECT MAX(la.id) FROM ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' la WHERE la.machines_id=m.id)'
        . ' LEFT JOIN ' . GLPICHAT_MANAGEMENT_TARGETS . ' et ON et.id=(SELECT MAX(lt.id) FROM ' . GLPICHAT_MANAGEMENT_TARGETS . ' lt WHERE lt.machines_id=m.id)'
        . ' LEFT JOIN ' . GLPICHAT_MANAGEMENT_ROLLOUTS . ' eo ON eo.id=et.rollouts_id';
}

/** Prefer a newer accepted target even before its assignment exists. A newer
 * direct assignment still takes precedence over an older target. */
function glpichat_management_effective_target_sql(): string
{
    return '(et.id IS NOT NULL AND (a.id IS NULL OR et.assignments_id=a.id OR (et.assignments_id IS NULL AND ((et.previous_assignment_id IS NOT NULL AND a.id<=et.previous_assignment_id) OR (et.previous_assignment_id IS NULL AND et.created_at>a.created_at)))))';
}

/** Silence is an observation, never a terminal outcome or freed capacity. */
function glpichat_management_assignment_state_sql(): string
{
    return "CASE WHEN a.status IN ('pending','started') AND a.execution_authority IN ('legacy','authorized')"
        . " AND COALESCE(a.last_reported_at,a.authorized_at,a.created_at)<DATE_SUB(UTC_TIMESTAMP(),INTERVAL 5 MINUTE)"
        . " THEN 'unknown' ELSE a.status END";
}

function glpichat_management_operation_sql(): string
{
    $state = glpichat_management_assignment_state_sql();
    return 'CASE WHEN ' . glpichat_management_effective_target_sql() . " THEN CASE WHEN et.status='assigned' THEN COALESCE(" . $state . ",'unknown') ELSE et.status END ELSE " . $state . ' END';
}

function glpichat_management_filter_sql(array $filters, ?string $asOf = null): string
{
    $filters = glpichat_management_filters($filters);
    $parts = ['1=1'];
    if ($filters['q'] !== '') {
        $value = str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $filters['q']);
        $mode = $filters['search_mode'];
        $predicate = $mode === 'exact' ? '=' . glpichat_desktop_quote($filters['q']) : ' LIKE ' . glpichat_desktop_quote(($mode === 'contains' ? '%' : '') . $value . '%') . " ESCAPE '!'";
        $parts[] = '(m.computer_name' . $predicate . ' OR m.previous_computer_name' . $predicate . ' OR m.installation_id' . $predicate . ')';
    }
    if ($filters['user'] !== '' || $filters['status'] === 'blocked_users' || $filters['binding_status'] !== '') {
        $binding = 'EXISTS (SELECT 1 FROM glpi_plugin_glpichat_desktopautobindings fb LEFT JOIN glpi_users fu ON fu.id=fb.users_id LEFT JOIN glpi_plugin_glpichat_desktopgrants fg ON fg.grant_id=fb.current_grant_id LEFT JOIN glpi_plugin_glpichat_desktopregistrations fr ON fr.grant_id=fg.grant_id LEFT JOIN glpi_plugin_glpichat_desktopdevices fd ON fd.id=fr.devices_id WHERE fb.machines_id=m.id';
        if ($filters['user'] !== '') { $value = glpichat_desktop_quote(str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $filters['user']) . '%'); $binding .= ' AND (fb.windows_sid LIKE ' . $value . " ESCAPE '!' OR fu.name LIKE " . $value . " ESCAPE '!')"; }
        if ($filters['status'] === 'blocked_users' || $filters['binding_status'] !== '') {
            $blocked = "COALESCE((fb.status='revoked' OR fg.status='revoked' OR fg.revoked_at IS NOT NULL OR fd.status='revoked' OR fd.revoked_at IS NOT NULL),0)";
            $binding .= ' AND ' . ($filters['binding_status'] === 'allowed' && $filters['status'] !== 'blocked_users' ? 'NOT ' : '') . $blocked;
        }
        $parts[] = $binding . ')';
    }
    foreach (['version' => 'current_version', 'status' => 'status', 'health' => 'health'] as $key => $column) {
        if ($filters[$key] !== '' && $filters[$key] !== 'blocked_users') { $parts[] = 'm.' . $column . '=' . glpichat_desktop_quote($filters[$key]); }
    }
    $asOf ??= glpichat_desktop_now();
    $cutoff = gmdate('Y-m-d H:i:s', strtotime($asOf . ' UTC') - 300);
    if ($filters['contact'] === 'never') { $parts[] = 'm.last_seen IS NULL'; }
    elseif ($filters['contact'] === 'recent') { $parts[] = 'm.last_seen>=' . glpichat_desktop_quote($cutoff); }
    elseif ($filters['contact'] === 'offline') { $parts[] = '(m.last_seen IS NULL OR m.last_seen<' . glpichat_desktop_quote($cutoff) . ')'; }
    foreach (['contact_from' => '>=', 'contact_to' => '<='] as $key => $operator) { if ($filters[$key] !== '') { $parts[] = 'm.last_seen' . $operator . glpichat_desktop_quote($filters[$key]); } }
    if ($filters['operation_status'] === 'none') { $parts[] = glpichat_management_operation_sql() . ' IS NULL'; }
    elseif ($filters['operation_status'] !== '') { $parts[] = glpichat_management_operation_sql() . '=' . glpichat_desktop_quote($filters['operation_status']); }
    return implode(' AND ', $parts);
}

function glpichat_management_machine_columns(): string
{
    $effective = glpichat_management_effective_target_sql();
    return 'm.id,m.installation_id,m.computer_name,m.previous_computer_name,m.renamed_at,m.status,m.admin_revision,m.current_version,m.bootstrap_version,m.health,m.runtime_json,m.last_seen,m.last_result,m.last_error,'
        . 'a.id AS assignment_id,a.dispatch_blocked,a.execution_authority,a.authorized_at,CASE WHEN ' . $effective . ' THEN eo.action ELSE a.action END AS assignment_action,' . glpichat_management_operation_sql() . ' AS assignment_status,'
        . 'CASE WHEN ' . $effective . " AND et.status<>'assigned' THEN et.reason ELSE a.last_error END AS assignment_error,a.started_at,a.completed_at,"
        . 'CASE WHEN ' . $effective . ' THEN er.version ELSE r.version END AS assignment_version,CASE WHEN ' . $effective . ' THEN eo.id ELSE NULL END AS rollout_id';
}

function glpichat_management_machine_from(): string
{
    return GLPICHAT_MANAGEMENT_MACHINES . ' m' . glpichat_management_latest_join()
        . ' LEFT JOIN ' . GLPICHAT_MANAGEMENT_RELEASES . ' r ON r.id=a.releases_id LEFT JOIN ' . GLPICHAT_MANAGEMENT_RELEASES . ' er ON er.id=eo.releases_id';
}

function glpichat_management_machine_page(array $filters, int $page = 1, int $size = 50): array
{
    glpichat_management_fleet_require_schema(); $filters = glpichat_management_filters($filters);
    $size = in_array($size, [50, 100], true) ? $size : 50;
    $where = glpichat_management_filter_sql($filters);
    // Counts without an operation filter avoid the latest-assignment/target joins.
    $countFrom = GLPICHAT_MANAGEMENT_MACHINES . ' m' . ($filters['operation_status'] !== '' ? glpichat_management_latest_join() : '');
    $total = (int) (glpichat_desktop_db_rows('SELECT COUNT(*) AS total FROM ' . $countFrom . ' WHERE ' . $where)[0]['total'] ?? 0);
    $pages = max(1, (int) ceil($total / $size)); $page = max(1, min($page, $pages));
    $column = ['id' => 'm.id', 'name' => 'm.computer_name', 'contact' => 'm.last_seen'][$filters['sort']];
    $order = $column . ' ' . strtoupper($filters['direction']) . ($column === 'm.id' ? '' : ',m.id ' . strtoupper($filters['direction']));
    $rows = glpichat_desktop_db_rows('SELECT ' . glpichat_management_machine_columns() . ' FROM ' . glpichat_management_machine_from() . ' WHERE ' . $where . ' ORDER BY ' . $order . ' LIMIT ' . $size . ' OFFSET ' . (($page - 1) * $size));
    return ['rows' => $rows, 'total' => $total, 'page' => $page, 'pages' => $pages, 'size' => $size];
}

function glpichat_management_selection_ids(mixed $input): array
{
    if (is_string($input)) {
        if (strlen($input) > 120000) { glpichat_desktop_fail('invalid_request', 'Seleção muito grande.', 400); }
        try { $input = json_decode($input, true, 4, JSON_THROW_ON_ERROR); } catch (JsonException $error) { glpichat_desktop_fail('invalid_request', 'Seleção inválida.', 400); }
    }
    if (!is_array($input) || !array_is_list($input) || count($input) > 10000) { glpichat_desktop_fail('invalid_request', 'Seleção inválida.', 400); }
    $ids = [];
    foreach ($input as $id) {
        if ((!is_string($id) && !is_int($id)) || preg_match('/\A[1-9][0-9]{0,9}\z/D', (string) $id) !== 1 || (int) $id > 4294967295) { glpichat_desktop_fail('invalid_request', 'Computador inválido.', 400); }
        $ids[(int) $id] = true;
    }
    $result = array_keys($ids); sort($result, SORT_NUMERIC); return $result;
}

/** One SELECT freezes target identity; bounded VALUES batches persist it.
 * Filters never remain a live rule that silently enrolls future computers. */
function glpichat_management_create_rollout(int $releaseId, string $action, array $filters, string $selection, array $ids, array $excluded, int $adminId, string $requestId, int $attempt = 0): array
{
    global $DB;
    glpichat_management_require_schema();
    $filters = glpichat_management_filters($filters);
    $ids = glpichat_management_selection_ids($ids); $excluded = glpichat_management_selection_ids($excluded);
    // Exclusions belong solely to the all-matching mode. Retained browser state
    // from that mode must never silently remove explicitly selected IDs.
    if ($selection === 'selected') { $excluded = []; }
    if (!in_array($action, ['update', 'repair'], true) || !in_array($selection, ['selected', 'all'], true) || ($selection === 'selected' && !$ids)
        || $adminId < 1 || preg_match('/\A[a-f0-9]{32}\z/D', $requestId) !== 1) { glpichat_desktop_fail('invalid_request', 'Selecione os computadores e a operação.', 400); }
    $issuingProfile = glpichat_management_issuing_profile();
    $intentHash = hash('sha256', json_encode([$releaseId, $action, $filters, $selection, $ids, $excluded, $issuingProfile], JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
    // Repeated identity is valid only for the same normalized intent.
    $existing = glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS, 'created_by=' . $adminId . ' AND request_id=' . glpichat_desktop_quote($requestId));
    if ($existing) { if (!hash_equals((string) ($existing['intent_hash'] ?? ''), $intentHash)) { glpichat_desktop_fail('intent_conflict', 'Esta identificação já pertence a outra solicitação.', 409); } return $existing; }
    try {
        return glpichat_desktop_transaction(static function () use ($releaseId, $action, $filters, $selection, $ids, $excluded, $adminId, $requestId, $intentHash, $issuingProfile, $DB): array {
            if (!glpichat_management_one(GLPICHAT_MANAGEMENT_RELEASES, 'id=' . $releaseId)) { glpichat_desktop_fail('not_found', 'Versão indisponível.', 404); }
            $now = glpichat_desktop_now();
            $where = glpichat_management_filter_sql($filters, $now);
            if ($selection === 'selected') { $where .= ' AND m.id IN (' . implode(',', $ids) . ')'; }
            if ($excluded) { $where .= ' AND m.id NOT IN (' . implode(',', $excluded) . ')'; }
            // Exact target IDs live in the target table; keep the criteria
            // summary bounded even when many explicit exclusions were supplied.
            $audit = json_encode(['filters' => $filters, 'selection' => $selection, 'excluded_count' => count($excluded), 'selected_count' => count($ids), 'as_of' => $now], JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
            $rollout = glpichat_management_write(GLPICHAT_MANAGEMENT_ROLLOUTS, ['request_id' => $requestId, 'intent_hash' => $intentHash, 'releases_id' => $releaseId, 'action' => $action,
                'issuing_profile_id' => $issuingProfile, 'filters_json' => $audit, 'target_count' => 0, 'status' => 'queued', 'created_by' => $adminId, 'created_at' => $now, 'completed_at' => null]);
            $time = glpichat_desktop_quote($now);
            $modern = (string) glpichat_desktop_config('desktop_schema_version') === '14';
            $snapshot = glpichat_desktop_db_rows('SELECT m.id,' . ($modern ? 'm.admin_revision' : '0') . ' AS revision,COALESCE(a.id,0) AS previous_assignment_id FROM '
                . GLPICHAT_MANAGEMENT_MACHINES . ' m' . glpichat_management_latest_join() . ' WHERE ' . $where . ' ORDER BY m.id LIMIT 10001');
            $count = count($snapshot);
            if ($count === 0) { glpichat_desktop_fail('empty_selection', 'Nenhum computador corresponde à seleção atual.', 409); }
            if ($count > 10000) { glpichat_desktop_fail('selection_limit', 'Divida a operação em lotes de até 10.000 computadores.', 400); }
            // VALUES batches avoid INSERT SELECT's bulk AUTO_INCREMENT locking
            // under concurrent overlapping submissions on MariaDB. One SELECT
            // above still freezes the complete membership for this transaction.
            $values = [];
            foreach ($snapshot as $index => $machine) {
                $values[] = '(' . $rollout . ',' . (int) $machine['id'] . ",'queued',''," . $time . ',' . $time
                    . ($modern ? ',' . (int) $machine['revision'] . ',' . (int) $machine['previous_assignment_id'] : '') . ')';
                if (count($values) === 200 || $index === $count - 1) {
                    if ($DB->doQuery('INSERT INTO ' . GLPICHAT_MANAGEMENT_TARGETS . ' (rollouts_id,machines_id,status,reason,available_at,created_at'
                        . ($modern ? ',expected_admin_revision,previous_assignment_id' : '') . ') VALUES ' . implode(',', $values)) === false) { throw new RuntimeException('Rollout snapshot failed.'); }
                    $values = [];
                }
            }
            glpichat_management_write(GLPICHAT_MANAGEMENT_ROLLOUTS, ['target_count' => $count], ['id' => $rollout]);
            // New explicit intent supersedes only work not dispatched to a machine.
            if ($DB->doQuery('UPDATE ' . GLPICHAT_MANAGEMENT_TARGETS . ' old INNER JOIN ' . GLPICHAT_MANAGEMENT_TARGETS . ' newer ON newer.machines_id=old.machines_id AND newer.rollouts_id=' . $rollout
                . " SET old.status='skipped',old.reason='replaced_by_newer_rollout',old.completed_at=" . $time
                . " WHERE old.rollouts_id IN (SELECT legacy.id FROM " . GLPICHAT_MANAGEMENT_ROLLOUTS . " legacy WHERE legacy.action IN ('update','repair')) AND old.rollouts_id<" . $rollout . " AND old.status IN ('queued','waiting')") === false) { throw new RuntimeException('Rollout supersession failed.'); }
            return ['id' => $rollout, 'target_count' => $count, 'status' => 'queued'];
        });
    } catch (Throwable $error) {
        // Concurrent duplicate requests race on the unique request key.
        $existing = glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS, 'created_by=' . $adminId . ' AND request_id=' . glpichat_desktop_quote($requestId));
        if ($existing) { if (!hash_equals((string) ($existing['intent_hash'] ?? ''), $intentHash)) { glpichat_desktop_fail('intent_conflict', 'Esta identificação já pertence a outra solicitação.', 409); } return $existing; }
        // Snapshot creation and concurrent dispatch can briefly contend
        // on the same machine. Retry only the database's deadlock/lock-timeout
        // classifications, after the transaction helper has rolled back.
        $transient = ($error instanceof mysqli_sql_exception && in_array($error->getCode(), [1205, 1213], true))
            || (basename($error->getFile()) === 'DBmysql.php' && preg_match('/\A(?:MySQL query error:).*\((?:1205|1213)\) in SQL query /s', $error->getMessage()));
        if ($transient && $attempt < 2) {
            usleep(random_int(10000, 50000));
            return glpichat_management_create_rollout($releaseId, $action, $filters, $selection, $ids, $excluded, $adminId, $requestId, $attempt + 1);
        }
        throw $error;
    }
}

function glpichat_management_rollout_reason(string $code): string
{
    return ['sequence_conflict' => 'Versão já atual ou sequência mais recente instalada.', 'bootstrap_upgrade_required' => 'Manutenção do bootstrap necessária.',
        'state_upgrade_required' => 'Migração de dados do cliente necessária.', 'release_quarantined' => 'Falha anterior: solicite reparo explicitamente.',
        'not_found' => 'Máquina revogada/indisponível ou versão removida.', 'operation_in_progress' => 'Aguardando a operação em andamento.',
        'replaced_by_newer_rollout' => 'Substituída por uma solicitação posterior.', 'superseded' => 'Operação substituída antes da execução.',
        'assignment_missing' => 'Registro da operação indisponível.', 'machine_revoked' => 'Gerenciamento revogado; execução não confirmada.', 'storage_retry' => 'Falha na distribuição; nova tentativa automática programada.', 'issuer_authority_lost' => 'O solicitante perdeu a permissão administrativa; solicite uma nova operação.', 'machine_admin_changed' => 'A permissão administrativa mudou depois da prévia; confirme uma nova operação.', 'installation_retired' => 'Instalação retirada permanentemente após contenção declarada; não afirma sucesso ou falha de execução.', 'withdrawal_confirmed' => 'O computador confirmou que a operação retirada não foi ativada.', 'dispatch_paused' => 'Novas autorizações pausadas globalmente.', 'campaign_cancelled' => 'Lote cancelado antes de autorizar este computador.', 'concurrency_limit' => 'Aguardando capacidade global ou a vez deste lote.', 'permission_applied' => 'Permissão aplicada; o contato do computador será confirmado separadamente.', 'already_in_state' => 'A permissão já estava neste estado.', 'admin_state_conflict' => 'Outra ação administrativa alterou o estado; prepare nova operação.', 'request_conflict' => 'A identificação da ação não corresponde à intenção registrada.', 'revision_conflict' => 'Outra ação administrativa alterou o estado; consulte a máquina e prepare nova operação.', 'dispatch_failed' => 'A distribuição falhou após 5 tentativas. Consulte a referência e solicite novamente após corrigir a causa.'][$code] ?? $code;
}

/** Revalidate the caller while holding target -> machine locks, matching cron.
 * A credential is internal context from an already authenticated Poll. */
function glpichat_management_target_authenticate(array $target, ?array $credential): void
{
    if ($credential === null) { return; }
    if ((int) $target['machines_id'] !== $credential['machines_id']) {
        glpichat_desktop_fail('machine_invalid', 'Registro da máquina inválido.', 401);
    }
    $machine = glpichat_management_authenticate($credential['token'], $credential['installation'], true);
    if ((int) $machine['id'] !== (int) $target['machines_id']) {
        glpichat_desktop_fail('machine_invalid', 'Registro da máquina inválido.', 401);
    }
}

/** Finalize only after committing the target mutation. Snapshot membership is
 * immutable and terminal targets never become active again, so a fresh
 * nonlocking active-target check is sufficient. An UPDATE with a subquery
 * would lock other targets while holding the parent and invert dispatch order. */
function glpichat_management_complete_rollout(int $rolloutId, ?array $credential = null): void
{
    glpichat_management_transaction(static function () use ($rolloutId, $credential): void {
        if ($credential !== null) {
            $machine = glpichat_management_authenticate($credential['token'], $credential['installation'], true);
            if ((int) $machine['id'] !== $credential['machines_id']) { glpichat_desktop_fail('machine_invalid', 'Registro da máquina inválido.', 401); }
        }
        $active = glpichat_desktop_db_rows('SELECT id FROM ' . GLPICHAT_MANAGEMENT_TARGETS . ' WHERE rollouts_id=' . $rolloutId
            . " AND status IN ('queued','waiting','assigned') LIMIT 1");
        if (!$active) {
            glpichat_management_write(GLPICHAT_MANAGEMENT_ROLLOUTS, ['status' => 'completed', 'completed_at' => glpichat_desktop_now()],
                ['id' => $rolloutId, 'status' => ['queued', 'running']]);
        }
    });
}

/** Every caller uses this dispatcher. Invalid credentials never consume a
 * retry or mutate a target, including revocation racing with a valid Poll. */
function glpichat_management_dispatch_target(int $targetId, ?array $credential = null, ?bool &$capacityDeferred = null): string
{
    $capacityDeferred = false;
    $initialTarget = glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS, 'id=' . $targetId);
    $initialRollout = $initialTarget ? glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS, 'id=' . (int) $initialTarget['rollouts_id']) : [];
    if (in_array($initialRollout['action'] ?? '', ['suspend', 'resume'], true)) { return glpichat_management_dispatch_permission($targetId, $credential); }
    // Queued offline targets never reserve installation capacity.
    if (glpichat_management_claims_ready() && $credential === null) { return 'deferred'; }
    if (glpichat_management_claims_ready() && $initialTarget
        && in_array($initialTarget['status'], ['queued', 'waiting'], true) && $credential !== null) {
        // Check the caller before the advisory exit too; invalid/revoked
        // credentials never mutate a target or receive an execution command.
        $machine = glpichat_management_authenticate($credential['token'], $credential['installation']);
        if ((int) $machine['id'] !== (int) $initialTarget['machines_id'] || (int) $machine['id'] !== $credential['machines_id']) {
            glpichat_desktop_fail('machine_invalid', 'Registro da máquina inválido.', 401);
        }
        if (!glpichat_management_dispatch_advisory()) { $capacityDeferred = true; return 'deferred'; }
    }
    $rolloutId = 0;
    try {
        $outcome = glpichat_management_transaction(static function () use ($targetId, $credential, &$rolloutId, &$capacityDeferred): string {
            $budget = glpichat_management_claims_ready() ? glpichat_management_dispatch_lock() : null;
            $target = glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS, 'id=' . $targetId, true);
            if (!$target) { return 'deferred'; }
            glpichat_management_target_authenticate($target, $credential);
            $rolloutId = (int) $target['rollouts_id'];
            if (!in_array($target['status'], ['queued', 'waiting'], true) || $target['available_at'] > glpichat_desktop_now()) { return 'deferred'; }
            // Grant order: dispatch budget -> target -> machine -> parent.
            // A grant is committed before its manifest can leave this request.
            $machine = glpichat_management_one(GLPICHAT_MANAGEMENT_MACHINES, 'id=' . (int) $target['machines_id'], true);
            $rollout = glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS, 'id=' . (int) $target['rollouts_id'], true);
            if (!$rollout) { throw new RuntimeException('Rollout unavailable.'); }
            if ((int) ($rollout['paused'] ?? 0) === 1 || !in_array($rollout['status'], ['queued', 'running'], true)) { return 'deferred'; }
            if (!$machine || (int) ($machine['admin_revision'] ?? 0) !== (int) ($target['expected_admin_revision'] ?? 0)) {
                glpichat_management_write(GLPICHAT_MANAGEMENT_TARGETS, ['status' => 'skipped', 'reason' => 'machine_admin_changed', 'completed_at' => glpichat_desktop_now()], ['id' => $targetId]);
                return 'skipped';
            }
            $capacity = (int) ($rollout['concurrency_limit'] ?? 0);
            $active = (int) ($rollout['active_count'] ?? 0);
            if ($budget !== null) {
                glpichat_management_write(GLPICHAT_MANAGEMENT_ROLLOUTS, ['last_requested_at' => glpichat_desktop_now()], ['id' => $rolloutId]);
                // Fair sharing considers only campaigns with a recent actual
                // claimant. Offline inventory never reserves a global slot.
                $cutoff = glpichat_desktop_quote(gmdate('Y-m-d H:i:s', time() - 120));
                $contenders = count(glpichat_desktop_db_rows('SELECT id FROM ' . GLPICHAT_MANAGEMENT_ROLLOUTS
                    . " WHERE paused=0 AND status IN ('queued','running') AND action IN ('update','repair') AND last_requested_at>=" . $cutoff . ' ORDER BY id LIMIT 250'));
                $fairLimit = max(1, (int) ceil((int) $budget['active_limit'] / max(1, $contenders)));
                $capacity = min($capacity > 0 ? $capacity : (int) $budget['active_limit'], $fairLimit);
                $active = count(glpichat_desktop_db_rows('SELECT a.id FROM ' . GLPICHAT_MANAGEMENT_TARGETS . ' t INNER JOIN '
                    . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' a ON a.id=t.assignments_id WHERE t.rollouts_id=' . $rolloutId
                    . " AND t.status='assigned' AND a.status IN ('pending','started') ORDER BY a.id LIMIT 251"));
                if (!glpichat_management_dispatch_has_capacity($budget) || $active >= $capacity) {
                    $capacityDeferred = true;
                    glpichat_management_write(GLPICHAT_MANAGEMENT_TARGETS, ['reason' => (int) $budget['paused'] ? 'dispatch_paused' : 'concurrency_limit'], ['id' => $targetId]);
                    return 'deferred';
                }
            } elseif ($capacity > 0 && $active >= $capacity) { return 'deferred'; }
            try {
                glpichat_management_require_rollout_actor($rollout, true);
                // Never attach a second target to an existing authorized attempt.
                if ($budget !== null && glpichat_management_pending((int) $target['machines_id'], true)) {
                    glpichat_desktop_fail('operation_in_progress', 'Aguardando o resultado da operação autorizada.', 409);
                }
                $assignment = glpichat_management_assign_locked((int) $target['machines_id'], (int) $rollout['releases_id'], $rollout['action'], (int) $rollout['created_by']);
                if ($budget !== null) {
                    glpichat_management_write(GLPICHAT_MANAGEMENT_ASSIGNMENTS,
                        ['execution_authority' => 'authorized', 'authorized_at' => glpichat_desktop_now()], ['id' => $assignment]);
                }
                glpichat_management_write(GLPICHAT_MANAGEMENT_TARGETS, ['assignments_id' => $assignment, 'status' => 'assigned', 'reason' => '',
                    'last_attempt_at' => glpichat_desktop_now(), 'last_error_ref' => ''], ['id' => $targetId]);
                glpichat_management_write(GLPICHAT_MANAGEMENT_ROLLOUTS, ['status' => 'running', 'active_count' => $active + (($budget !== null || $capacity > 0) ? 1 : 0)], ['id' => (int) $rollout['id']]);
                return 'assigned';
            } catch (GlpichatDesktopException $error) {
                if (!in_array($error->errorCode, ['operation_in_progress', 'sequence_conflict', 'bootstrap_upgrade_required', 'state_upgrade_required', 'release_quarantined', 'not_found', 'issuer_authority_lost'], true)) { throw $error; }
                $waiting = $error->errorCode === 'operation_in_progress';
                glpichat_management_write(GLPICHAT_MANAGEMENT_TARGETS, ['status' => $waiting ? 'waiting' : 'skipped', 'reason' => $error->errorCode,
                    'last_attempt_at' => glpichat_desktop_now(), 'last_error_ref' => '',
                    'available_at' => gmdate('Y-m-d H:i:s', time() + 60), 'completed_at' => $waiting ? null : glpichat_desktop_now()], ['id' => $targetId]);
                return $waiting ? 'waiting' : 'skipped';
            }
        });
    } catch (Throwable $error) {
        if ($error instanceof GlpichatDesktopException && in_array($error->errorCode, ['machine_invalid', 'management_capacity_unavailable'], true)) { throw $error; }
        // A rollback failure poisons the connection boundary; do not begin a
        // diagnostic transaction inside that unresolved transaction either.
        if ($error instanceof GlpichatManagementTransactionStateException) { throw $error; }
        $reference = glpichat_desktop_log_failure('rollout_dispatch', $error);
        // The failed attempt rolled back. Record failure under the same lock
        // order, protecting against a concurrent success or supersession.
        $outcome = glpichat_management_transaction(static function () use ($targetId, $credential, $reference, &$rolloutId): string {
            $target = glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS, 'id=' . $targetId, true);
            if (!$target) { return 'deferred'; }
            glpichat_management_target_authenticate($target, $credential);
            $rolloutId = (int) $target['rollouts_id'];
            if (!in_array($target['status'], ['queued', 'waiting'], true) || $target['available_at'] > glpichat_desktop_now()) { return 'deferred'; }
            $attempts = min(5, max(0, (int) $target['dispatch_attempts']) + 1);
            $terminal = $attempts >= 5;
            glpichat_management_write(GLPICHAT_MANAGEMENT_TARGETS, ['dispatch_attempts' => $attempts,
                'last_attempt_at' => glpichat_desktop_now(), 'last_error_ref' => preg_replace('/[^a-f0-9]/', '', substr($reference, 0, 32)),
                'status' => $terminal ? 'failed' : $target['status'], 'reason' => $terminal ? 'dispatch_failed' : 'storage_retry',
                'available_at' => gmdate('Y-m-d H:i:s', time() + ($terminal ? 0 : [60, 120, 240, 480][$attempts - 1])),
                'completed_at' => $terminal ? glpichat_desktop_now() : null], ['id' => $targetId]);
            return $terminal ? 'failed' : 'deferred';
        });
    }
    if ($rolloutId > 0 && in_array($outcome, ['skipped', 'failed'], true)) { glpichat_management_complete_rollout($rolloutId, $credential); }
    return $outcome;
}

/** Reconcile only exact assigned targets; never alter assignment outcomes.
 * A Poll has a small machine-scoped limit; cron retains its bounded fleet pass. */
function glpichat_management_reconcile_rollout_targets(int $limit, float $deadline, ?array $credential = null, ?int $machineId = null): int
{
    $limit = max(1, min(1000, $limit));
    $scope = $credential === null ? ($machineId === null ? '' : ' AND t.machines_id=' . max(0, $machineId))
        : ' AND t.machines_id=' . (int) $credential['machines_id'];
    $finished = glpichat_desktop_db_rows('SELECT t.id FROM ' . GLPICHAT_MANAGEMENT_TARGETS . ' t LEFT JOIN ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS
        . ' a ON a.id=t.assignments_id LEFT JOIN ' . GLPICHAT_MANAGEMENT_MACHINES . " m ON m.id=t.machines_id WHERE t.status='assigned'" . $scope
        . " AND (a.id IS NULL OR a.status NOT IN ('pending','started') OR m.id IS NULL) ORDER BY t.id LIMIT " . $limit);
    $count = 0;
    foreach ($finished as $row) {
        if (microtime(true) >= $deadline) { break; }
        $rolloutId = 0;
        $changed = glpichat_management_transaction(static function () use ($row, $credential, &$rolloutId): bool {
            $target = glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS, 'id=' . (int) $row['id'], true);
            if (!$target || $target['status'] !== 'assigned') { return false; }
            glpichat_management_target_authenticate($target, $credential);
            // Cron also takes the machine lock before reading its assignment.
            $machine = glpichat_management_one(GLPICHAT_MANAGEMENT_MACHINES, 'id=' . (int) $target['machines_id'], true);
            $assignment = glpichat_management_one(GLPICHAT_MANAGEMENT_ASSIGNMENTS, 'id=' . (int) $target['assignments_id'] . ' AND machines_id=' . (int) $target['machines_id'], true);
            $status = $assignment['status'] ?? '';
            $revoked = !$machine && in_array($status, ['pending', 'started'], true);
            if (in_array($status, ['pending', 'started'], true) && !$revoked) { return false; }
            glpichat_management_write(GLPICHAT_MANAGEMENT_TARGETS, ['status' => in_array($status, ['completed', 'failed', 'withdrawn', 'retired'], true) ? $status : 'skipped',
                'reason' => $status === 'retired' ? 'installation_retired' : ($status === 'withdrawn' ? 'withdrawal_confirmed' : ($revoked ? 'machine_revoked' : ($status === 'superseded' ? 'superseded' : ($status === '' ? 'assignment_missing' : '')))),
                'completed_at' => glpichat_desktop_now()], ['id' => (int) $target['id']]);
            $rolloutId = (int) $target['rollouts_id'];
            $parent = glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS, 'id=' . $rolloutId, true);
            if (glpichat_management_claims_ready() || (int) ($parent['concurrency_limit'] ?? 0) > 0) { glpichat_management_write(GLPICHAT_MANAGEMENT_ROLLOUTS, ['active_count' => max(0, (int) $parent['active_count'] - 1)], ['id' => $rolloutId]); }
            return true;
        });
        if ($changed) { glpichat_management_complete_rollout($rolloutId, $credential); ++$count; }
    }
    return $count;
}

/** A permanently retired installation cannot Poll again. Close its unissued
 * intent in bounded slices, separately from the retirement transaction so the
 * established target -> machine lock order is preserved. No assignment result
 * is inferred and no authorized sibling operation is changed. */
function glpichat_management_reconcile_retired_targets(int $limit, float $deadline, ?int $machineId = null): int
{
    $limit = max(1, min(1000, $limit));
    $scope = $machineId === null ? '' : ' AND m.id=' . max(0, $machineId);
    $rows = glpichat_desktop_db_rows('SELECT t.id FROM ' . GLPICHAT_MANAGEMENT_MACHINES . ' m INNER JOIN '
        . GLPICHAT_MANAGEMENT_TARGETS . " t ON t.machines_id=m.id WHERE m.status='retired' AND t.status IN ('queued','waiting')"
        . $scope . ' ORDER BY t.id LIMIT ' . $limit);
    $count = 0;
    foreach ($rows as $row) {
        if (microtime(true) >= $deadline) { break; }
        $rolloutId = glpichat_management_transaction(static function () use ($row): int {
            $target = glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS, 'id=' . (int) $row['id'], true);
            if (!$target || !in_array($target['status'], ['queued', 'waiting'], true)) { return 0; }
            $machine = glpichat_management_one(GLPICHAT_MANAGEMENT_MACHINES, 'id=' . (int) $target['machines_id'], true);
            if (!$machine || $machine['status'] !== 'retired') { return 0; }
            glpichat_management_write(GLPICHAT_MANAGEMENT_TARGETS,
                ['status' => 'skipped', 'reason' => 'installation_retired', 'completed_at' => glpichat_desktop_now()], ['id' => (int) $target['id']]);
            return (int) $target['rollouts_id'];
        });
        if ($rolloutId > 0) { glpichat_management_complete_rollout($rolloutId); ++$count; }
    }
    return $count;
}

/** Skip paused or capacity-saturated parents before applying the work limit;
 * otherwise a large paused batch could starve unrelated later operations. */
function glpichat_management_due_targets(int $limit, ?int $machineId = null): array
{
    $limit = max(1, min(1000, $limit)); $schema12 = (string) glpichat_desktop_config('desktop_schema_version') === '14';
    $from = GLPICHAT_MANAGEMENT_TARGETS . ' t';
    $where = "t.status IN ('queued','waiting') AND t.available_at<=" . glpichat_desktop_quote(glpichat_desktop_now());
    if ($schema12) {
        $from .= ' INNER JOIN ' . GLPICHAT_MANAGEMENT_ROLLOUTS . ' r ON r.id=t.rollouts_id';
        $where .= " AND r.paused=0 AND r.status IN ('queued','running')";
    }
    if ($machineId !== null) { $where .= ' AND t.machines_id=' . $machineId . ($schema12 ? " AND r.action IN ('update','repair')" : ''); }
    elseif ($schema12) { $where .= " AND r.action IN ('suspend','resume')"; }
    return glpichat_desktop_db_rows('SELECT t.id FROM ' . $from . ' WHERE ' . $where . ' ORDER BY t.available_at,t.id LIMIT ' . $limit);
}

/** At most one due target, belonging to this authenticated installation only.
 * No queue work executes while the telemetry transaction holds machine locks. */
function glpichat_management_poll_rollouts(array $credential): bool
{
    $deadline = microtime(true) + 2.0;
    glpichat_management_reconcile_rollout_targets(10, $deadline, $credential);
    // If a previous response failed after the target committed but before its
    // parent summary did, the next authenticated Poll still finishes that job.
    // Only this machine's terminal targets participate, with bounded output.
    $complete = glpichat_desktop_db_rows('SELECT DISTINCT t.rollouts_id FROM ' . GLPICHAT_MANAGEMENT_TARGETS . ' t INNER JOIN '
        . GLPICHAT_MANAGEMENT_ROLLOUTS . ' r ON r.id=t.rollouts_id WHERE t.machines_id=' . (int) $credential['machines_id']
        . " AND t.status IN ('completed','failed','skipped','cancelled','withdrawn','retired') AND r.status IN ('queued','running') AND NOT EXISTS (SELECT 1 FROM "
        . GLPICHAT_MANAGEMENT_TARGETS . " active WHERE active.rollouts_id=r.id AND active.status IN ('queued','waiting','assigned')) ORDER BY t.rollouts_id LIMIT 10");
    foreach ($complete as $row) {
        if (microtime(true) >= $deadline) { break; }
        glpichat_management_complete_rollout((int) $row['rollouts_id'], $credential);
    }
    $due = glpichat_management_due_targets(1, (int) $credential['machines_id']);
    $capacityDeferred = false;
    if ($due) { glpichat_management_dispatch_target((int) $due[0]['id'], $credential, $capacityDeferred); }
    return $capacityDeferred;
}

/** Permission jobs execute on the server, including suspended installations.
 * Authority requests have a stable per-target identity. A crash after authority
 * commit but before recording the target resumes from the durable receipt. */
function glpichat_management_dispatch_permission(int $targetId, ?array $credential = null): string
{
    require_once __DIR__ . '/authority.php';
    $target = glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS, 'id=' . $targetId);
    if (!$target || !in_array($target['status'], ['queued', 'waiting'], true) || $target['available_at'] > glpichat_desktop_now()) { return 'deferred'; }
    if ($credential !== null) { return 'deferred'; } // A client never authorizes a server-side administrative action.
    $rollout = glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS, 'id=' . (int) $target['rollouts_id']);
    if (!$rollout || !in_array($rollout['action'], ['suspend', 'resume'], true) || (int) $rollout['paused'] === 1) { return 'deferred'; }
    $intent = json_decode($rollout['filters_json'], true, 12, JSON_THROW_ON_ERROR);
    $request = substr(hash('sha256', 'glpichat-permission-target:' . $rollout['id'] . ':' . $targetId), 0, 32);
    try {
        $receipt = glpichat_management_authority_change('machine', (int) $target['machines_id'], $rollout['action'], (int) $target['expected_admin_revision'], (int) $rollout['created_by'], $request, (string) $intent['reason'], 'glpi', static fn () => glpichat_management_require_rollout_actor($rollout, true));
        $status = 'completed'; $reason = ($receipt['status'] ?? '') === 'already_in_state' ? 'already_in_state' : 'permission_applied';
    } catch (GlpichatDesktopException $error) {
        if (!in_array($error->errorCode, ['revision_conflict', 'not_found', 'intent_conflict', 'state_conflict', 'admin_state_conflict', 'request_conflict', 'issuer_authority_lost', 'installation_retired'], true)) { throw $error; }
        $status = 'skipped'; $reason = $error->errorCode;
    } catch (GlpichatManagementTransactionStateException $error) { throw $error;
    } catch (Throwable $error) {
        $reference = glpichat_desktop_log_failure('permission_dispatch', $error);
        return glpichat_management_transaction(static function () use ($targetId, $reference): string {
            $current = glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS, 'id=' . $targetId, true);
            if (!$current || !in_array($current['status'], ['queued', 'waiting'], true)) { return 'deferred'; }
            $attempts = min(5, (int) $current['dispatch_attempts'] + 1); $terminal = $attempts >= 5;
            glpichat_management_write(GLPICHAT_MANAGEMENT_TARGETS, ['dispatch_attempts' => $attempts, 'last_attempt_at' => glpichat_desktop_now(),
                'last_error_ref' => preg_replace('/[^a-f0-9]/', '', substr($reference, 0, 32)), 'status' => $terminal ? 'failed' : $current['status'],
                'reason' => $terminal ? 'dispatch_failed' : 'storage_retry', 'available_at' => gmdate('Y-m-d H:i:s', time() + ($terminal ? 0 : 60 * (1 << ($attempts - 1)))),
                'completed_at' => $terminal ? glpichat_desktop_now() : null], ['id' => $targetId]);
            return $terminal ? 'failed' : 'deferred';
        });
    }
    glpichat_management_write(GLPICHAT_MANAGEMENT_TARGETS, ['status' => $status, 'reason' => $reason, 'completed_at' => glpichat_desktop_now(), 'last_attempt_at' => glpichat_desktop_now()], ['id' => $targetId, 'status' => ['queued', 'waiting']]);
    glpichat_management_complete_rollout((int) $rollout['id']);
    return $status === 'completed' ? 'assigned' : 'skipped';
}

/** Optional background dispatch/reconciliation. Poll does not require cron. */
function glpichat_management_process_rollouts(int $limit = 250, float $seconds = 8.0): array
{
    global $DB;
    glpichat_management_require_schema();
    $limit = max(1, min(1000, $limit)); $deadline = microtime(true) + max(0.1, min(30.0, $seconds));
    $result = ['assigned' => 0, 'waiting' => 0, 'skipped' => 0, 'reconciled' => 0, 'deferred' => 0, 'failed' => 0];
    $result['reconciled'] = glpichat_management_reconcile_rollout_targets($limit, $deadline);
    if (microtime(true) < $deadline) { $result['reconciled'] += glpichat_management_reconcile_retired_targets($limit, $deadline); }
    $due = glpichat_management_due_targets($limit);
    foreach ($due as $row) {
        if (microtime(true) >= $deadline) { break; }
        ++$result[glpichat_management_dispatch_target((int) $row['id'])];
    }
    // Also clean up older jobs whose remaining queued targets were superseded
    // by an administrator's newer request, without touching their history.
    $complete = glpichat_desktop_db_rows('SELECT r.id FROM ' . GLPICHAT_MANAGEMENT_ROLLOUTS . " r WHERE r.status IN ('queued','running') AND NOT EXISTS (SELECT 1 FROM "
        . GLPICHAT_MANAGEMENT_TARGETS . " t WHERE t.rollouts_id=r.id AND t.status IN ('queued','waiting','assigned')) ORDER BY r.id LIMIT " . $limit);
    foreach ($complete as $row) {
        if (microtime(true) >= $deadline) { break; }
        glpichat_management_complete_rollout((int) $row['id']);
    }
    if ((string) glpichat_desktop_config('desktop_schema_version') === '14' && microtime(true) < $deadline) {
        // Expired unconfirmed snapshots are disposable after seven days.
        // Confirmed preview receipts and durable job/audit rows remain.
        $cutoff = glpichat_desktop_quote(gmdate('Y-m-d H:i:s', time() - 7 * 86400));
        if ($DB->doQuery('DELETE FROM glpi_plugin_glpichat_desktoppreviews WHERE rollout_id IS NULL AND expires_at<' . $cutoff . ' ORDER BY id LIMIT 100') === false) { throw new RuntimeException('Preview retention cleanup failed.'); }
    }
    return $result;
}

function glpichat_management_rollout_page(int $page = 1): array
{
    $total = (int) (glpichat_desktop_db_rows('SELECT COUNT(*) AS total FROM ' . GLPICHAT_MANAGEMENT_ROLLOUTS)[0]['total'] ?? 0);
    $pages = max(1, (int) ceil($total / 20)); $page = max(1, min($pages, $page));
    $rows = glpichat_desktop_db_rows('SELECT o.id,o.action,o.target_count,o.status,o.created_by,o.created_at,o.completed_at,o.paused,o.admin_revision,o.concurrency_limit,o.active_count,r.version FROM ' . GLPICHAT_MANAGEMENT_ROLLOUTS . ' o LEFT JOIN ' . GLPICHAT_MANAGEMENT_RELEASES . ' r ON r.id=o.releases_id ORDER BY o.id DESC LIMIT 20 OFFSET ' . (($page - 1) * 20));
    $ids = array_map(static fn (array $row): int => (int) $row['id'], $rows);
    $counts = [];
    if ($ids) {
        foreach (glpichat_desktop_db_rows('SELECT t.rollouts_id,CASE WHEN t.reason=\'dispatch_failed\' THEN \'dispatch_failed\' WHEN t.reason=\'storage_retry\' AND t.status IN (\'queued\',\'waiting\') THEN \'dispatch_retry\' WHEN t.status=\'assigned\' THEN COALESCE(' . glpichat_management_assignment_state_sql() . ',\'unknown\') ELSE t.status END AS state,COUNT(*) AS total FROM '
            . GLPICHAT_MANAGEMENT_TARGETS . ' t LEFT JOIN ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' a ON a.id=t.assignments_id WHERE t.rollouts_id IN (' . implode(',', $ids) . ') GROUP BY t.rollouts_id,state') as $row) {
            $counts[(int) $row['rollouts_id']][$row['state']] = (int) $row['total'];
        }
    }
    return ['rows' => $rows, 'counts' => $counts, 'page' => $page, 'pages' => $pages, 'total' => $total];
}
