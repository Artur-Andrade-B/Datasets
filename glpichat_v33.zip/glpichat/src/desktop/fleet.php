<?php

declare(strict_types=1);
require_once __DIR__ . '/rollouts.php';
require_once __DIR__ . '/automatic.php';

const GLPICHAT_MANAGEMENT_PREVIEWS = 'glpi_plugin_glpichat_desktoppreviews';
const GLPICHAT_MANAGEMENT_ADMIN_AUDIT = 'glpi_plugin_glpichat_desktopadminaudit';

function glpichat_management_request_id(string $id): string
{
    if (preg_match('/\A[a-f0-9]{32}\z/D', $id) !== 1) { glpichat_desktop_fail('invalid_request', 'Identificação da solicitação inválida.', 400); }
    return $id;
}

function glpichat_management_preview_intent(int $releaseId, string $action, array $filters, string $selection, array $ids, array $excluded, string $requestId, string $reason, int $concurrency): array
{
    if (!in_array($action, ['update', 'repair', 'suspend', 'resume'], true) || !in_array($selection, ['selected', 'all'], true)) { glpichat_desktop_fail('invalid_request', 'Operação ou seleção inválida.', 400); }
    $ids = glpichat_management_selection_ids($ids); $excluded = $selection === 'all' ? glpichat_management_selection_ids($excluded) : [];
    if ($selection === 'selected' && !$ids) { glpichat_desktop_fail('empty_selection', 'Selecione pelo menos um computador.', 400); }
    $reason = trim($reason);
    if ($reason === '' || strlen($reason) > 500 || preg_match('//u', $reason) !== 1 || preg_match('/[\x00-\x1f\x7f]/', $reason)) { glpichat_desktop_fail('invalid_request', 'Informe o motivo, com até 500 caracteres.', 400); }
    if ($concurrency < 1 || $concurrency > 250) { glpichat_desktop_fail('invalid_request', 'O limite simultâneo deve estar entre 1 e 250 computadores.', 400); }
    return ['release_id' => in_array($action, ['update', 'repair'], true) ? $releaseId : 0, 'action' => $action,
        'filters' => glpichat_management_filters($filters), 'selection' => $selection, 'ids' => $ids, 'excluded' => $excluded,
        'request_id' => glpichat_management_request_id($requestId), 'issuing_profile_id' => glpichat_management_issuing_profile(), 'reason' => $reason, 'concurrency' => $concurrency];
}

/** Previews contain IDs and administrative revisions, never bearer credentials.
 * No live filter is evaluated during confirmation. */
function glpichat_management_create_preview(int $releaseId, string $action, array $filters, string $selection, array $ids, array $excluded, int $adminId, string $requestId, string $reason = '', int $concurrency = 25): array
{
    glpichat_management_fleet_require_schema();
    if ($adminId < 1) { glpichat_desktop_fail('forbidden', 'Administrador obrigatório.', 403); }
    $intent = glpichat_management_preview_intent($releaseId, $action, $filters, $selection, $ids, $excluded, $requestId, $reason, $concurrency);
    $json = json_encode($intent, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR); $hash = hash('sha256', $json);
    $existing = glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS, 'created_by=' . $adminId . ' AND request_id=' . glpichat_desktop_quote($requestId));
    if ($existing) {
        if (!hash_equals((string) $existing['intent_hash'], $hash)) { glpichat_desktop_fail('intent_conflict', 'Esta identificação já pertence a outra solicitação.', 409); }
        return ['preview_id' => '', 'rollout_id' => (int) $existing['id'], 'committed' => true, 'intent' => $intent, 'target_count' => (int) $existing['target_count']];
    }
    $prior = glpichat_management_one(GLPICHAT_MANAGEMENT_PREVIEWS, 'created_by=' . $adminId . ' AND request_id=' . glpichat_desktop_quote($requestId));
    if ($prior) { if (!hash_equals((string) $prior['intent_hash'], $hash)) { glpichat_desktop_fail('intent_conflict', 'Esta identificação já pertence a outra prévia.', 409); } return glpichat_management_get_preview($prior['preview_id'], $adminId); }
    $activePreviews = (int) (glpichat_desktop_db_rows('SELECT COUNT(*) AS total FROM ' . GLPICHAT_MANAGEMENT_PREVIEWS . ' WHERE created_by=' . $adminId . ' AND rollout_id IS NULL AND expires_at>' . glpichat_desktop_quote(glpichat_desktop_now()))[0]['total'] ?? 0);
    if ($activePreviews >= 10) { glpichat_desktop_fail('preview_limit', 'Existem dez prévias abertas. Confirme uma ou aguarde sua expiração.', 429); }
    $release = $intent['release_id'] > 0 ? glpichat_management_one(GLPICHAT_MANAGEMENT_RELEASES, 'id=' . $intent['release_id']) : [];
    if (in_array($action, ['update', 'repair'], true) && !$release) { glpichat_desktop_fail('not_found', 'Versão indisponível.', 404); }
    $now = glpichat_desktop_now(); $where = glpichat_management_filter_sql($intent['filters'], $now);
    if ($selection === 'selected') { $where .= ' AND m.id IN (' . implode(',', $intent['ids']) . ')'; }
    if ($intent['excluded']) { $where .= ' AND m.id NOT IN (' . implode(',', $intent['excluded']) . ')'; }
    $rows = glpichat_desktop_db_rows('SELECT m.id,m.computer_name,m.status,m.admin_revision,m.current_sequence,m.bootstrap_version,(SELECT COALESCE(MAX(pa.id),0) FROM ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' pa WHERE pa.machines_id=m.id) AS previous_assignment_id,EXISTS(SELECT 1 FROM ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' pf WHERE pf.machines_id=m.id AND pf.releases_id=' . (int) $intent['release_id'] . " AND pf.status='failed') AS preview_release_failed,EXISTS(SELECT 1 FROM " . GLPICHAT_MANAGEMENT_ASSIGNMENTS . " ps WHERE ps.machines_id=m.id AND ps.status='started') AS preview_started FROM " . GLPICHAT_MANAGEMENT_MACHINES . ' m'
        . ($intent['filters']['operation_status'] !== '' ? glpichat_management_latest_join() : '') . ' WHERE ' . $where . ' ORDER BY m.id LIMIT 10001');
    if (!$rows) { glpichat_desktop_fail('empty_selection', 'Nenhum computador corresponde à seleção.', 409); }
    if (count($rows) > 10000) { glpichat_desktop_fail('selection_limit', 'Divida a operação em lotes de até 10.000 computadores.', 400); }
    $targets = [];
    foreach ($rows as $machine) {
        $reasonCode = '';
        if (in_array($action, ['update', 'repair'], true)) { $reasonCode = glpichat_management_assignment_eligibility($machine, $release, $action, (bool) $machine['preview_release_failed']); }
        if ($machine['status'] !== 'active' && $reasonCode === 'not_found') { $reasonCode = 'machine_revoked'; }
        if ($machine['status'] === 'retired') { $reasonCode = 'installation_retired'; }
        $targets[] = ['id' => (int) $machine['id'], 'computer_name' => (string) $machine['computer_name'], 'revision' => (int) $machine['admin_revision'],
            'status' => $machine['status'], 'previous_assignment_id' => (int) $machine['previous_assignment_id'], 'eligible' => $reasonCode === '', 'waiting' => $reasonCode === '' && in_array($action, ['update', 'repair'], true) && (bool) $machine['preview_started'], 'reason' => $reasonCode];
    }
    $previewId = bin2hex(random_bytes(16));
    try { glpichat_management_write(GLPICHAT_MANAGEMENT_PREVIEWS, ['preview_id' => $previewId, 'request_id' => $requestId, 'created_by' => $adminId, 'intent_hash' => $hash,
        'intent_json' => $json, 'targets_json' => json_encode($targets, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR), 'created_at' => $now,
        'expires_at' => gmdate('Y-m-d H:i:s', time() + 600), 'rollout_id' => null]); } catch (Throwable $error) {
        $prior = glpichat_management_one(GLPICHAT_MANAGEMENT_PREVIEWS, 'created_by=' . $adminId . ' AND request_id=' . glpichat_desktop_quote($requestId));
        if (!$prior) { throw $error; }
        if (!hash_equals((string) $prior['intent_hash'], $hash)) { glpichat_desktop_fail('intent_conflict', 'Esta identificação já pertence a outra prévia.', 409); }
        return glpichat_management_get_preview($prior['preview_id'], $adminId);
    }
    return glpichat_management_get_preview($previewId, $adminId);
}

function glpichat_management_get_preview(string $previewId, int $adminId): array
{
    glpichat_management_fleet_require_schema();
    glpichat_management_request_id($previewId);
    $row = glpichat_management_one(GLPICHAT_MANAGEMENT_PREVIEWS, 'preview_id=' . glpichat_desktop_quote($previewId) . ' AND created_by=' . $adminId);
    if (!$row) { glpichat_desktop_fail('not_found', 'Prévia indisponível para este administrador.', 404); }
    if (!$row['rollout_id'] && $row['expires_at'] <= glpichat_desktop_now()) { glpichat_desktop_fail('preview_expired', 'A prévia expirou. Prepare uma nova seleção.', 409); }
    $targets = json_decode($row['targets_json'], true, 8, JSON_THROW_ON_ERROR);
    $eligible = count(array_filter($targets, static fn(array $item): bool => $item['eligible'] === true));
    return ['preview_id' => $previewId, 'expires_at' => $row['expires_at'], 'target_count' => count($targets), 'eligible_count' => $eligible,
        'ineligible_count' => count($targets) - $eligible, 'waiting_count' => count(array_filter($targets, static fn (array $item): bool => (bool) ($item['waiting'] ?? false))), 'targets' => array_slice($targets, 0, 100), 'targets_truncated' => count($targets) > 100,
        'intent' => json_decode($row['intent_json'], true, 12, JSON_THROW_ON_ERROR), 'rollout_id' => (int) ($row['rollout_id'] ?? 0), 'committed' => (bool) $row['rollout_id']];
}

function glpichat_management_confirm_preview(string $previewId, int $adminId): array
{
    glpichat_management_request_id($previewId); glpichat_management_fleet_require_schema();
    return glpichat_management_transaction(static function () use ($previewId, $adminId): array {
        global $DB;
        $row = glpichat_management_one(GLPICHAT_MANAGEMENT_PREVIEWS, 'preview_id=' . glpichat_desktop_quote($previewId) . ' AND created_by=' . $adminId, true);
        if (!$row) { glpichat_desktop_fail('not_found', 'Prévia indisponível para este administrador.', 404); }
        if ($row['rollout_id']) { return glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS, 'id=' . (int) $row['rollout_id']); }
        if ($row['expires_at'] <= glpichat_desktop_now()) { glpichat_desktop_fail('preview_expired', 'A prévia expirou. Prepare uma nova seleção.', 409); }
        $intent = json_decode($row['intent_json'], true, 12, JSON_THROW_ON_ERROR);
        $existing = glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS, 'created_by=' . $adminId . ' AND request_id=' . glpichat_desktop_quote($intent['request_id']));
        if ($existing) {
            if (!hash_equals((string) $existing['intent_hash'], (string) $row['intent_hash'])) { glpichat_desktop_fail('intent_conflict', 'Esta identificação já pertence a outra solicitação.', 409); }
            glpichat_management_write(GLPICHAT_MANAGEMENT_PREVIEWS, ['rollout_id' => (int) $existing['id']], ['id' => (int) $row['id']]); return $existing;
        }
        if (!glpichat_management_admin_has_right($adminId, glpichat_management_issuing_profile(), defined('UPDATE') ? (int) UPDATE : 2, true)) { glpichat_desktop_fail('forbidden', 'Permissão administrativa atual necessária para aprovar o lote.', 403); }
        $targets = json_decode($row['targets_json'], true, 8, JSON_THROW_ON_ERROR); $now = glpichat_desktop_now();
        $rollout = glpichat_management_write(GLPICHAT_MANAGEMENT_ROLLOUTS, ['request_id' => $intent['request_id'], 'intent_hash' => $row['intent_hash'], 'releases_id' => $intent['release_id'],
            'action' => $intent['action'], 'filters_json' => json_encode(['reason' => $intent['reason'], 'filters' => $intent['filters'], 'preview_id' => $previewId], JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
            'issuing_profile_id' => $intent['issuing_profile_id'], 'target_count' => count($targets), 'status' => 'queued', 'created_by' => $adminId, 'created_at' => $now, 'completed_at' => null,
            'concurrency_limit' => $intent['concurrency'], 'active_count' => 0, 'paused' => 0, 'admin_revision' => 0]);
        // Ordering metadata is observed at acceptance, after any assignments
        // created while the administrator reviewed the immutable preview.
        $previousAssignments = [];
        foreach (glpichat_desktop_db_rows('SELECT machines_id,MAX(id) AS previous_id FROM ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' WHERE machines_id IN (' . implode(',', array_column($targets, 'id')) . ') GROUP BY machines_id') as $prior) {
            $previousAssignments[(int) $prior['machines_id']] = (int) $prior['previous_id'];
        }
        // Store membership in bounded INSERT batches, without locking machines
        // or executing any action inside this snapshot transaction.
        $values = []; $stamp = glpichat_desktop_quote($now); $epoch = time();
        foreach ($targets as $index => $target) {
            $available = $now; // Contacting machines claim capacity; offline row order imposes no delay.
            $values[] = '(' . $rollout . ',' . (int) $target['id'] . ',' . (int) $target['revision'] . ',' . (int) ($previousAssignments[(int) $target['id']] ?? 0) . ','
                . glpichat_desktop_quote($target['eligible'] ? 'queued' : 'skipped') . ',' . glpichat_desktop_quote($target['reason']) . ','
                . glpichat_desktop_quote($available) . ',' . $stamp . ',' . ($target['eligible'] ? 'NULL' : $stamp) . ')';
            if (count($values) === 200 || $index === count($targets) - 1) {
                if ($DB->doQuery('INSERT INTO ' . GLPICHAT_MANAGEMENT_TARGETS . ' (rollouts_id,machines_id,expected_admin_revision,previous_assignment_id,status,reason,available_at,created_at,completed_at) VALUES ' . implode(',', $values)) === false) { throw new RuntimeException('Preview target persistence failed.'); }
                $values = [];
            }
        }
        if (in_array($intent['action'], ['update', 'repair'], true)) {
            // Supersede only undispatched update intent for these frozen IDs.
            // Permission jobs and started assignments retain independent history.
            if ($DB->doQuery('UPDATE ' . GLPICHAT_MANAGEMENT_TARGETS . ' old INNER JOIN ' . GLPICHAT_MANAGEMENT_TARGETS . ' newer ON newer.machines_id=old.machines_id AND newer.rollouts_id=' . $rollout
                . ' INNER JOIN ' . GLPICHAT_MANAGEMENT_ROLLOUTS . ' oldjob ON oldjob.id=old.rollouts_id'
                . " SET old.status='skipped',old.reason='replaced_by_newer_rollout',old.completed_at=" . glpichat_desktop_quote($now)
                . " WHERE old.rollouts_id<" . $rollout . " AND oldjob.action IN ('update','repair') AND old.status IN ('queued','waiting')") === false) { throw new RuntimeException('Rollout supersession failed.'); }
        }
        glpichat_management_write(GLPICHAT_MANAGEMENT_PREVIEWS, ['rollout_id' => $rollout], ['id' => (int) $row['id']]);
        return glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS, 'id=' . $rollout);
    });
}

function glpichat_management_rollout_pause(int $id, bool $paused, int $expectedRevision, int $adminId, string $requestId, string $reason): array
{
    glpichat_management_fleet_require_schema();
    glpichat_management_request_id($requestId); $reason = trim($reason);
    if ($adminId < 1 || $reason === '' || strlen($reason) > 500 || preg_match('//u', $reason) !== 1 || preg_match('/[\x00-\x1f\x7f]/', $reason)) { glpichat_desktop_fail('invalid_request', 'Informe o motivo da alteração.', 400); }
    $hash = hash('sha256', json_encode([$id, $paused, $expectedRevision, $reason], JSON_THROW_ON_ERROR));
    return glpichat_management_transaction(static function () use ($id, $paused, $expectedRevision, $adminId, $requestId, $reason, $hash): array {
        glpichat_management_dispatch_lock();
        $row = glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS, 'id=' . $id, true);
        if (!$row || !in_array($row['action'], ['update', 'repair'], true)) { glpichat_desktop_fail('not_found', 'Lote de atualização indisponível.', 404); }
        $existing = glpichat_management_one(GLPICHAT_MANAGEMENT_ADMIN_AUDIT, 'actor_id=' . $adminId . ' AND request_id=' . glpichat_desktop_quote($requestId));
        if ($existing) { if (!hash_equals((string) $existing['intent_hash'], $hash)) { glpichat_desktop_fail('intent_conflict', 'Identificação já usada por outra ação.', 409); } return $row; }
        if (!glpichat_management_admin_has_right($adminId, glpichat_management_issuing_profile(), defined('UPDATE') ? (int) UPDATE : 2, true)) { glpichat_desktop_fail('forbidden', 'Permissão administrativa atual necessária.', 403); }
        if (!in_array($row['status'], ['queued', 'running'], true)) { glpichat_desktop_fail('state_conflict', 'Lote encerrado; prepare uma nova solicitação.', 409); }
        if ((int) $row['admin_revision'] !== $expectedRevision) { glpichat_desktop_fail('revision_conflict', 'O lote foi alterado. Consulte o estado atual.', 409); }
        $after = ['paused' => $paused ? 1 : 0, 'admin_revision' => $expectedRevision + 1];
        glpichat_management_write(GLPICHAT_MANAGEMENT_ROLLOUTS, $after, ['id' => $id]);
        glpichat_management_write(GLPICHAT_MANAGEMENT_ADMIN_AUDIT, ['actor_id' => $adminId, 'request_id' => $requestId, 'intent_hash' => $hash, 'target_kind' => 'rollout', 'target_id' => $id,
            'action' => $paused ? 'pause' : 'resume', 'reason' => $reason, 'before_json' => json_encode(['paused' => (int) $row['paused'], 'admin_revision' => $expectedRevision], JSON_THROW_ON_ERROR),
            'after_json' => json_encode($after, JSON_THROW_ON_ERROR), 'outcome' => 'applied', 'created_at' => glpichat_desktop_now()]);
        return array_replace($row, $after);
    });
}

/** Cancellation and the first execution grant share dispatch_lock. A committed
 * grant remains an in-flight fact; cancellation never fabricates its outcome. */
function glpichat_management_rollout_cancel(int $id, int $expectedRevision, int $adminId, string $requestId, string $reason): array
{
    glpichat_management_fleet_require_schema(); glpichat_management_request_id($requestId);
    $reason = trim($reason);
    if ($adminId < 1 || $reason === '' || strlen($reason) > 500 || preg_match('//u', $reason) !== 1 || preg_match('/[\x00-\x1f\x7f]/', $reason)) { glpichat_desktop_fail('invalid_request', 'Informe o motivo do cancelamento.', 400); }
    $hash = hash('sha256', json_encode(['cancel', $id, $expectedRevision, $reason], JSON_THROW_ON_ERROR));
    return glpichat_management_transaction(static function () use ($id, $expectedRevision, $adminId, $requestId, $reason, $hash): array {
        global $DB;
        glpichat_management_dispatch_lock();
        $row = glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS, 'id=' . $id, true);
        if (!$row || !in_array($row['action'], ['update', 'repair'], true)) { glpichat_desktop_fail('not_found', 'Lote indisponível.', 404); }
        $existing = glpichat_management_one(GLPICHAT_MANAGEMENT_ADMIN_AUDIT, 'actor_id=' . $adminId . ' AND request_id=' . glpichat_desktop_quote($requestId));
        if ($existing) { if (!hash_equals((string) $existing['intent_hash'], $hash)) { glpichat_desktop_fail('intent_conflict', 'Identificação já usada por outra ação.', 409); } return $row; }
        if (!glpichat_management_admin_has_right($adminId, glpichat_management_issuing_profile(), defined('UPDATE') ? (int) UPDATE : 2, true)) { glpichat_desktop_fail('forbidden', 'Permissão administrativa atual necessária.', 403); }
        if ((int) $row['admin_revision'] !== $expectedRevision || !in_array($row['status'], ['queued', 'running'], true)) { glpichat_desktop_fail('revision_conflict', 'O lote mudou. Consulte o estado atual.', 409); }
        $after = ['status' => 'cancelled', 'paused' => 1, 'admin_revision' => $expectedRevision + 1, 'completed_at' => glpichat_desktop_now()];
        glpichat_management_write(GLPICHAT_MANAGEMENT_ROLLOUTS, $after, ['id' => $id]);
        // The snapshot is bounded to 10,000 targets; only unissued targets change.
        if ($DB->doQuery('UPDATE ' . GLPICHAT_MANAGEMENT_TARGETS . " SET status='cancelled',reason='campaign_cancelled',completed_at=" . glpichat_desktop_quote(glpichat_desktop_now())
            . ' WHERE rollouts_id=' . $id . " AND status IN ('queued','waiting')") === false) { throw new RuntimeException('Campaign cancellation failed.'); }
        glpichat_management_write(GLPICHAT_MANAGEMENT_ADMIN_AUDIT, ['actor_id' => $adminId, 'request_id' => $requestId, 'intent_hash' => $hash, 'target_kind' => 'rollout', 'target_id' => $id,
            'action' => 'cancel', 'reason' => $reason, 'before_json' => json_encode(['status' => $row['status'], 'admin_revision' => $expectedRevision], JSON_THROW_ON_ERROR),
            'after_json' => json_encode($after, JSON_THROW_ON_ERROR), 'outcome' => 'applied', 'created_at' => glpichat_desktop_now()]);
        return array_replace($row, $after);
    });
}

/** Global control is independent of each campaign's approved safety limit.
 * Pausing stops new grants only; exact reports and authorized recovery continue. */
function glpichat_management_dispatch_control(int $limit, bool $paused, int $expectedRevision, int $adminId, string $requestId, string $reason): array
{
    glpichat_management_fleet_require_schema(); glpichat_management_request_id($requestId); $reason = trim($reason);
    if ($limit < 1 || $limit > 250 || $adminId < 1 || $reason === '' || strlen($reason) > 500 || preg_match('//u', $reason) !== 1 || preg_match('/[\x00-\x1f\x7f]/', $reason)) { glpichat_desktop_fail('invalid_request', 'Limite ou justificativa inválidos.', 400); }
    $hash = hash('sha256', json_encode([$limit, $paused, $expectedRevision, $reason], JSON_THROW_ON_ERROR));
    return glpichat_management_transaction(static function () use ($limit, $paused, $expectedRevision, $adminId, $requestId, $reason, $hash): array {
        $row = glpichat_management_dispatch_lock();
        $existing = glpichat_management_one(GLPICHAT_MANAGEMENT_ADMIN_AUDIT, 'actor_id=' . $adminId . ' AND request_id=' . glpichat_desktop_quote($requestId));
        if ($existing) { if (!hash_equals((string) $existing['intent_hash'], $hash)) { glpichat_desktop_fail('intent_conflict', 'Identificação já usada por outra ação.', 409); } return $row; }
        if (!glpichat_management_admin_has_right($adminId, glpichat_management_issuing_profile(), defined('UPDATE') ? (int) UPDATE : 2, true)) { glpichat_desktop_fail('forbidden', 'Permissão administrativa atual necessária.', 403); }
        if ((int) $row['admin_revision'] !== $expectedRevision) { glpichat_desktop_fail('revision_conflict', 'O controle mudou. Consulte o estado atual.', 409); }
        $after = ['active_limit' => $limit, 'paused' => $paused ? 1 : 0, 'admin_revision' => $expectedRevision + 1];
        glpichat_management_write('glpi_plugin_glpichat_desktopdispatch', $after, ['id' => 1]);
        glpichat_management_write(GLPICHAT_MANAGEMENT_ADMIN_AUDIT, ['actor_id' => $adminId, 'request_id' => $requestId, 'intent_hash' => $hash, 'target_kind' => 'dispatch', 'target_id' => 1,
            'action' => 'configure', 'reason' => $reason, 'before_json' => json_encode($row, JSON_THROW_ON_ERROR), 'after_json' => json_encode($after, JSON_THROW_ON_ERROR), 'outcome' => 'applied', 'created_at' => glpichat_desktop_now()]);
        return array_replace($row, $after);
    });
}

function glpichat_management_operation_label(?string $status, string $action = '', bool $blocked = false): string
{
    if ($status === 'completed' && in_array($action, ['suspend', 'resume'], true)) { return 'Permissão administrativa aplicada'; }
    if ($status === 'started' && $blocked) { return 'Processamento iniciado; redistribuição suspensa; aguardando resultado'; }
    return ['' => 'Nenhuma', 'queued' => 'Na fila; aguardando contato ou capacidade', 'waiting' => 'Aguardando operação anterior', 'pending' => 'Execução autorizada; aguardando confirmação',
        'withdrawn' => 'Retirada confirmada pelo computador; sem ativação', 'retired' => 'Instalação retirada permanentemente; resultado de execução não afirmado', 'unknown' => 'Sem resultado recente; capacidade retida', 'cancelled' => 'Cancelada antes da autorização',
        'started' => 'Processamento iniciado', 'completed' => 'Arquivos instalados confirmados', 'failed' => 'Falha', 'skipped' => 'Não aplicada', 'superseded' => 'Substituída'][$status ?? ''] ?? 'Estado não reconhecido';
}

function glpichat_management_fleet_machine(array $machine): array
{
    $machine['id'] = (int) $machine['id']; $machine['admin_revision'] = (int) $machine['admin_revision'];
    $machine['runtime'] = glpichat_management_runtime_view($machine); $machine['bootstrap'] = glpichat_management_bootstrap_view($machine);
    $machine['operation_label'] = glpichat_management_operation_label($machine['assignment_status'] ?? null, (string) ($machine['assignment_action'] ?? ''), (bool) ($machine['dispatch_blocked'] ?? false));
    $errors = array_filter([(string) ($machine['last_error'] ?? ''), (string) ($machine['assignment_error'] ?? '')]);
    $machine['error_label'] = implode(' / ', array_map('glpichat_management_rollout_reason', array_unique($errors)));
    $machine['permission_label'] = $machine['status'] === 'active' ? 'Gerenciamento permitido' : ($machine['status'] === 'retired' ? 'Instalação retirada permanentemente' : 'Gerenciamento suspenso');
    unset($machine['runtime_json']); return $machine;
}

/** Read-only bounded snapshot. No dispatch, reconciliation, CSRF renewal or
 * administrative writes are permitted in this call graph. */
function glpichat_management_fleet_status(array $machineIds, int $rolloutId = 0, int $targetPage = 1, array $jobIds = []): array
{
    glpichat_management_fleet_require_schema(); $jobIds = glpichat_management_selection_ids($jobIds); $machineIds = glpichat_management_selection_ids($machineIds);
    if (count($machineIds) > 100 || count($jobIds) > 20 || $rolloutId < 0 || $targetPage < 1 || $targetPage > 1000000) { glpichat_desktop_fail('invalid_request', 'Consulta de acompanhamento inválida.', 400); }
    $rows = $machineIds ? glpichat_desktop_db_rows('SELECT ' . glpichat_management_machine_columns() . ' FROM ' . glpichat_management_machine_from() . ' WHERE m.id IN (' . implode(',', $machineIds) . ') ORDER BY m.id LIMIT 100') : [];
    $job = $rolloutId > 0 ? glpichat_management_rollout_detail($rolloutId, $targetPage) : null;
    return ['checked_at' => glpichat_desktop_now(), 'machines' => array_map('glpichat_management_fleet_machine', $rows), 'job' => $job, 'jobs' => glpichat_management_rollout_summaries($jobIds), 'dispatch' => glpichat_management_one('glpi_plugin_glpichat_desktopdispatch', 'id=1')];
}

function glpichat_management_rollout_detail(int $id, int $page = 1): array
{
    glpichat_management_fleet_require_schema();
    $row = glpichat_desktop_db_rows('SELECT o.id,o.action,o.target_count,o.status,o.created_by,o.created_at,o.completed_at,o.paused,o.admin_revision,o.concurrency_limit,o.active_count,r.version FROM ' . GLPICHAT_MANAGEMENT_ROLLOUTS . ' o LEFT JOIN ' . GLPICHAT_MANAGEMENT_RELEASES . ' r ON r.id=o.releases_id WHERE o.id=' . max(0, $id) . ' LIMIT 1')[0] ?? [];
    if (!$row) { glpichat_desktop_fail('not_found', 'Operação indisponível.', 404); }
    $counts = [];
    foreach (glpichat_desktop_db_rows('SELECT CASE WHEN t.status=\'assigned\' THEN COALESCE(' . glpichat_management_assignment_state_sql() . ',\'unknown\') ELSE t.status END AS state,COUNT(*) AS total FROM ' . GLPICHAT_MANAGEMENT_TARGETS . ' t LEFT JOIN ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' a ON a.id=t.assignments_id WHERE t.rollouts_id=' . $id . ' GROUP BY state') as $count) { $counts[$count['state']] = (int) $count['total']; }
    $pages = max(1, (int) ceil((int) $row['target_count'] / 50)); $page = max(1, min($page, $pages));
    $targets = glpichat_desktop_db_rows('SELECT t.id,t.machines_id,m.computer_name,m.installation_id,t.status,t.reason,t.last_error_ref,t.dispatch_attempts,t.last_attempt_at,t.available_at,t.completed_at,m.last_seen,a.dispatch_blocked,' . glpichat_management_assignment_state_sql() . ' AS assignment_status,' . glpichat_management_assignment_state_sql() . ' AS operation_status,a.last_result,a.last_error,a.last_error AS assignment_error FROM ' . GLPICHAT_MANAGEMENT_TARGETS . ' t LEFT JOIN ' . GLPICHAT_MANAGEMENT_MACHINES . ' m ON m.id=t.machines_id LEFT JOIN ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' a ON a.id=t.assignments_id WHERE t.rollouts_id=' . $id . ' ORDER BY t.id LIMIT 50 OFFSET ' . (($page - 1) * 50));
    foreach ($targets as &$target) { $target['effective_status'] = $target['status'] === 'assigned' ? ($target['assignment_status'] ?? 'unknown') : $target['status']; $target['status_label'] = glpichat_management_operation_label($target['effective_status'], (string) $row['action'], (bool) ($target['dispatch_blocked'] ?? false)); $target['reason_label'] = glpichat_management_rollout_reason($target['reason']); }
    unset($target);
    return $row + ['counts' => $counts, 'targets' => $targets, 'target_page' => $page, 'target_pages' => $pages];
}

function glpichat_management_binding_page(array $filters, int $page = 1, int $size = 50): array
{
    glpichat_management_fleet_require_schema();
    $size = in_array($size, [50, 100], true) ? $size : 50; $where = ['1=1'];
    $blocked = "COALESCE((b.status='revoked' OR g.status='revoked' OR g.revoked_at IS NOT NULL OR d.status='revoked' OR d.revoked_at IS NOT NULL),0)";
    foreach (['q', 'user'] as $key) {
        $value = $filters[$key] ?? '';
        if (!is_string($value) || strlen($value) > 100 || preg_match('//u', $value) !== 1 || preg_match('/[\x00-\x1f\x7f]/', $value)) { glpichat_desktop_fail('invalid_request', 'Filtro de conexão inválido.', 400); }
        if ($value !== '') { $like = glpichat_desktop_quote(str_replace(['!', '%', '_'], ['!!', '!%', '!_'], trim($value)) . '%'); $where[] = '(b.windows_sid LIKE ' . $like . " ESCAPE '!' OR u.name LIKE " . $like . " ESCAPE '!' OR m.computer_name LIKE " . $like . " ESCAPE '!')"; }
    }
    if (isset($filters['machine_id']) && (string) $filters['machine_id'] !== '' && (string) $filters['machine_id'] !== '0') { $ids = glpichat_management_selection_ids([(string) $filters['machine_id']]); $where[] = 'b.machines_id=' . $ids[0]; }
    $status = $filters['status'] ?? '';
    if (!in_array($status, ['', 'blocked', 'allowed'], true)) { glpichat_desktop_fail('invalid_request', 'Filtro de permissão inválido.', 400); }
    if ($status !== '') { $where[] = ($status === 'allowed' ? 'NOT ' : '') . $blocked; }
    $from = GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE . ' b LEFT JOIN ' . GLPICHAT_MANAGEMENT_MACHINES . ' m ON m.id=b.machines_id LEFT JOIN glpi_users u ON u.id=b.users_id LEFT JOIN ' . GLPICHAT_DESKTOP_GRANTS_TABLE . ' g ON g.grant_id=b.current_grant_id LEFT JOIN ' . GLPICHAT_DESKTOP_REGISTRATIONS_TABLE . ' r ON r.grant_id=g.grant_id LEFT JOIN ' . GLPICHAT_DESKTOP_DEVICES_TABLE . ' d ON d.id=r.devices_id';
    $condition = implode(' AND ', $where); $total = (int) (glpichat_desktop_db_rows('SELECT COUNT(*) AS total FROM ' . $from . ' WHERE ' . $condition)[0]['total'] ?? 0);
    $pages = max(1, (int) ceil($total / $size)); $page = max(1, min($page, $pages));
    $rows = glpichat_desktop_db_rows('SELECT b.id,b.machines_id,b.windows_sid,b.users_id,b.status,b.admin_revision,b.created_at,b.updated_at,b.released_by,m.computer_name,m.installation_id,m.status AS machine_status,u.name AS user_name,g.status AS grant_status,g.revoked_at AS grant_revoked_at,d.status AS device_status,d.revoked_at AS device_revoked_at,' . $blocked . ' AS blocked FROM ' . $from . ' WHERE ' . $condition . ' ORDER BY b.id DESC LIMIT ' . $size . ' OFFSET ' . (($page - 1) * $size));
    foreach ($rows as &$row) { $row['blocked'] = (bool) $row['blocked']; } unset($row);
    return ['rows' => $rows, 'total' => $total, 'pages' => $pages, 'page' => $page, 'size' => $size];
}

function glpichat_management_machine_detail(int $id): array
{
    $machine = glpichat_management_fleet_status([$id])['machines'][0] ?? null;
    if (!$machine) { glpichat_desktop_fail('not_found', 'Computador indisponível.', 404); }
    return ['machine' => $machine, 'bindings' => glpichat_management_binding_page(['machine_id' => $id])['rows'],
        'assignments' => glpichat_desktop_db_rows('SELECT a.id,a.action,a.status,a.admin_revision,a.dispatch_blocked,a.execution_authority,a.releases_id,a.created_at,a.started_at,a.completed_at,a.last_error,r.version,r.sequence,SHA2(r.manifest_json,256) AS manifest_sha256 FROM ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' a LEFT JOIN ' . GLPICHAT_MANAGEMENT_RELEASES . ' r ON r.id=a.releases_id WHERE a.machines_id=' . $id . ' ORDER BY a.id DESC LIMIT 50'),
        'audit' => glpichat_desktop_db_rows('SELECT id,actor_id,origin,action,reason,outcome,before_json,after_json,created_at FROM ' . GLPICHAT_MANAGEMENT_ADMIN_AUDIT . " WHERE target_kind='machine' AND target_id=" . $id . ' ORDER BY id DESC LIMIT 50')];
}

function glpichat_management_status_snapshot(array $ids, int $rolloutId = 0, int $targetPage = 1, array $jobIds = []): array
{
    return glpichat_management_fleet_status($ids, $rolloutId, $targetPage, $jobIds);
}

function glpichat_management_rollout_summaries(array $ids): array
{
    if (!$ids) { return []; }
    $rows = glpichat_desktop_db_rows('SELECT id,action,target_count,status,created_at,completed_at,paused,admin_revision,concurrency_limit,active_count FROM ' . GLPICHAT_MANAGEMENT_ROLLOUTS . ' WHERE id IN (' . implode(',', $ids) . ') ORDER BY id DESC LIMIT 20');
    $counts = [];
    foreach (glpichat_desktop_db_rows('SELECT t.rollouts_id,CASE WHEN t.status=\'assigned\' THEN COALESCE(' . glpichat_management_assignment_state_sql() . ',\'unknown\') ELSE t.status END AS state,COUNT(*) AS total FROM ' . GLPICHAT_MANAGEMENT_TARGETS . ' t LEFT JOIN ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' a ON a.id=t.assignments_id WHERE t.rollouts_id IN (' . implode(',', $ids) . ') GROUP BY t.rollouts_id,state') as $count) { $counts[(int) $count['rollouts_id']][$count['state']] = (int) $count['total']; }
    foreach ($rows as &$row) { $row['counts'] = $counts[(int) $row['id']] ?? []; } unset($row); return $rows;
}

/** Resolve an uncertain form response without replaying its mutation. The
 * request identity is scoped to its original administrator. */
function glpichat_management_request_receipt(string $requestId, int $adminId): array
{
    glpichat_management_fleet_require_schema(); glpichat_management_request_id($requestId);
    if ($adminId < 1) { glpichat_desktop_fail('forbidden', 'Administrador obrigatório.', 403); }
    $job = glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS, 'created_by=' . $adminId . ' AND request_id=' . glpichat_desktop_quote($requestId));
    if ($job) { return ['request_id' => $requestId, 'rollout_id' => (int) $job['id'], 'preview_id' => '', 'status' => 'committed']; }
    $preview = glpichat_management_one(GLPICHAT_MANAGEMENT_PREVIEWS, 'created_by=' . $adminId . ' AND request_id=' . glpichat_desktop_quote($requestId));
    if ($preview) { return ['request_id' => $requestId, 'rollout_id' => (int) ($preview['rollout_id'] ?? 0), 'preview_id' => $preview['preview_id'],
        'status' => $preview['expires_at'] <= glpichat_desktop_now() ? 'expired' : 'preview']; }
    return ['request_id' => $requestId, 'rollout_id' => 0, 'preview_id' => '', 'status' => 'not_found'];
}
