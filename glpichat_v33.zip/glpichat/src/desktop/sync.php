<?php

declare(strict_types=1);

require_once __DIR__ . '/visibility.php';

/** Optional invalidation hints, never content, permission or a delivery cursor.
 * One row per subject makes an idle /Me a primary-key lookup. Writes use the
 * caller's DB connection/transaction: concurrent writers serialize on that row;
 * a rollback also rolls back its hint. Native hooks are not assumed exhaustive,
 * so clients MUST reconcile independently within reconcile_seconds.
 */
function glpichat_desktop_sync_enabled(): bool
{
    if (!class_exists('Config')) { return false; }
    $config = function_exists('glpichat_desktop_config')
        ? ['desktop_enabled' => glpichat_desktop_config('desktop_enabled'), 'desktop_schema_version' => glpichat_desktop_config('desktop_schema_version')]
        : Config::getConfigurationValues('plugin:glpichat');
    return (string) ($config['desktop_enabled'] ?? '') === '1'
        && (string) ($config['desktop_schema_version'] ?? '') === '14';
}

/** Invalid optional tuning degrades to bounded defaults, never disables auth. */
function glpichat_desktop_poll_setting(string $key, int $default, int $minimum, int $maximum): int
{
    $value = glpichat_desktop_config($key);
    if ((!is_int($value) && (!is_string($value) || preg_match('/\A[1-9][0-9]{0,3}\z/D', $value) !== 1))
        || (int) $value < $minimum || (int) $value > $maximum) { return $default; }
    return (int) $value;
}

function glpichat_desktop_polling(): array
{
    return ['version' => 1,
        'idle_seconds' => glpichat_desktop_poll_setting('desktop_poll_idle_seconds', 30, 5, 60),
        'active_seconds' => glpichat_desktop_poll_setting('desktop_poll_active_seconds', 5, 3, 15)];
}

function glpichat_desktop_sync_hint(array $actor, bool $governedPolling = false): ?array
{
    $user = (int) ($actor['user_id'] ?? 0);
    if ($user <= 0 || empty($actor['can_read']) || !glpichat_desktop_sync_enabled()) { return null; }
    try {
        global $DB;
        $result = $DB->doQuery('SELECT revision FROM glpi_plugin_glpichat_desktopsync WHERE users_id = ' . $user);
        if ($result === false || $result === true) { throw new RuntimeException('Summary hint read failed'); }
        $row = $DB->fetchAssoc($result);
        if (method_exists($result, 'free')) { $result->free(); }
        $revision = (string) ($row['revision'] ?? str_repeat('0', 32));
        if (preg_match('/\A[a-f0-9]{32}\z/D', $revision) !== 1) { return null; }
        // The same user on another PC receives the same hint. Fresh authority
        // changes also invalidate summaries; a display login is never a key.
        $scope = [$user, (int) ($actor['profile_id'] ?? 0), (int) ($actor['entity_id'] ?? 0),
            !empty($actor['can_create']), (string) ($actor['canonical_identity'] ?? ''), $revision];
        return ['version' => $governedPolling ? 2 : 1, 'revision' => hash('sha256', json_encode($scope, JSON_THROW_ON_ERROR)),
            'reconcile_seconds' => $governedPolling ? glpichat_desktop_poll_setting('desktop_summary_reconcile_seconds', 120, 30, 300) : 30];
    } catch (Throwable $error) {
        // Losing an optimization must not break identity, enrollment or GLPI.
        // Omitting the hint makes the client use its existing complete reads.
        // Do not emit one log per polling device during a shared outage.
        return null;
    }
}

function glpichat_desktop_sync_touch_user(int $user): void
{
    if ($user <= 0 || !glpichat_desktop_sync_enabled()) { return; }
    glpichat_desktop_sync_write('SELECT ' . $user . ' AS users_id');
}

function glpichat_desktop_sync_touch_ticket(int $ticket): void
{
    if ($ticket <= 0 || !glpichat_desktop_sync_enabled()) { return; }
    // Requester changes explicitly dirty the removed user through the actor
    // hook as well. This set is ticket-scoped, never a whole-fleet wakeup.
    glpichat_desktop_sync_write('SELECT DISTINCT users_id FROM glpi_tickets_users WHERE tickets_id = '
        . $ticket . ' AND type = 1 AND users_id > 0 ORDER BY users_id');
}

function glpichat_desktop_sync_write(string $subjectSelect): void
{
    global $DB;
    try {
        $revision = "'" . $DB->escape(bin2hex(random_bytes(16))) . "'";
        $now = "'" . $DB->escape(gmdate('Y-m-d H:i:s')) . "'";
        // Sort recipients before locking multiple rows. Never start/commit a
        // separate transaction here or publish a hint on another connection.
        $sql = 'INSERT INTO glpi_plugin_glpichat_desktopsync (users_id,revision,changed_at) '
            . "SELECT subjects.users_id,$revision,$now FROM ($subjectSelect) subjects WHERE 1=1 ORDER BY subjects.users_id "
            . 'ON DUPLICATE KEY UPDATE revision = VALUES(revision), changed_at = VALUES(changed_at)';
        if (!$DB->doQuery($sql)) { throw new RuntimeException('Dirty hint write failed'); }
    } catch (Throwable $error) {
        // A deadlock or lost connection can invalidate the caller's complete
        // transaction. Never swallow that condition and report a partial send
        // or receipt as committed. Native autocommit callers likewise receive
        // an explicit failure; no hidden success is manufactured here.
        throw new RuntimeException('Desktop summary invalidation failed.', 0, $error);
    }
}

/** Relevant native writes include GLPI UI/API/mail integrations using the
 * ordinary CommonDBTM hooks. Out-of-band SQL and omitted native hooks converge
 * through bounded reconciliation, not an unsupported delta-only assumption.
 */
function glpichat_desktop_sync_item(object $item): void
{
    $fields = (array) ($item->fields ?? []);
    if ($item instanceof Ticket) {
        glpichat_desktop_sync_touch_ticket((int) ($fields['id'] ?? 0));
    } elseif ($item instanceof ITILFollowup && ($fields['itemtype'] ?? '') === 'Ticket') {
        glpichat_desktop_visibility_changed($item);
        glpichat_desktop_sync_touch_ticket((int) ($fields['items_id'] ?? 0));
    } elseif ($item instanceof Ticket_User) {
        // Dirty both current and former requester even after relation removal.
        glpichat_desktop_sync_touch_user((int) ($fields['users_id'] ?? 0));
        glpichat_desktop_sync_touch_user((int) ($item->oldvalues['users_id'] ?? 0));
        glpichat_desktop_sync_touch_ticket((int) ($fields['tickets_id'] ?? 0));
    }
}
