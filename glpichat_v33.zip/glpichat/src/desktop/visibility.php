<?php

declare(strict_types=1);

/** Weak object keys bind a token to one native update attempt without trusting
 * request input or leaking objects in a long-running GLPI process. A repeated
 * post hook on the same update reuses its token; the next pre-update replaces
 * it. Publication does not infer transitions from a possibly delayed hook. */
function glpichat_desktop_visibility_epochs(): WeakMap
{
    static $epochs;
    return $epochs ??= new WeakMap();
}

function glpichat_desktop_visibility_prepare(object $item): void
{
    if ($item instanceof ITILFollowup && glpichat_desktop_sync_enabled()) {
        glpichat_desktop_visibility_epochs()[$item] = bin2hex(random_bytes(16));
    }
}

/** Coalesced latest visibility event, separate from the creation ID. Store one
 * epoch per followup, never a history of intermediate privacy cycles or one
 * row per recipient/device. Duplicate post hooks on one update stay stable. */
function glpichat_desktop_visibility_changed(object $item): void
{
    $fields = (array) ($item->fields ?? []);
    $old = (array) ($item->oldvalues ?? []);
    if (!glpichat_desktop_sync_enabled() || !($item instanceof ITILFollowup)
        || ($fields['itemtype'] ?? '') !== 'Ticket'
        || !in_array('is_private', (array) ($item->updates ?? []), true)
        || !array_key_exists('is_private', $old) || !array_key_exists('is_private', $fields)
        || !in_array((int) $old['is_private'], [0, 1], true)
        || !in_array((int) $fields['is_private'], [0, 1], true)
        || (int) $old['is_private'] === (int) $fields['is_private']) { return; }
    $id = (int) ($fields['id'] ?? 0);
    $ticket = (int) ($fields['items_id'] ?? 0);
    if ($id <= 0 || $ticket <= 0) { return; }
    global $DB;
    $private = (int) $fields['is_private'];
    $epochs = glpichat_desktop_visibility_epochs();
    if (!isset($epochs[$item])) { $epochs[$item] = bin2hex(random_bytes(16)); }
    $token = $private === 0 ? "'" . $epochs[$item] . "'" : 'NULL';
    // Use the native writer's connection/transaction. The current-source test
    // rejects a callback whose privacy state no longer matches the source.
    // Concurrent public callbacks may still coalesce while it remains public.
    $sql = 'INSERT INTO glpi_plugin_glpichat_desktopvisibility (itilfollowups_id,tickets_id,is_private,token,changed_at) '
        . "SELECT id,items_id,$private,$token,UTC_TIMESTAMP(6) FROM glpi_itilfollowups "
        . "WHERE id=$id AND itemtype='Ticket' AND items_id=$ticket AND is_private=$private "
        . 'ON DUPLICATE KEY UPDATE token=IF(VALUES(is_private)=0,VALUES(token),glpi_plugin_glpichat_desktopvisibility.token),'
        . 'tickets_id=VALUES(tickets_id),is_private=VALUES(is_private),changed_at=VALUES(changed_at)';
    if (!$DB->doQuery($sql)) { throw new RuntimeException('Desktop visibility epoch write failed.'); }
}

/** Native followup deletion removes its one owned row in the same hook path;
 * no fleet scan, fanout job or unbounded retention work is introduced. */
function glpichat_desktop_visibility_deleted(object $item): void
{
    if (!($item instanceof ITILFollowup) || !glpichat_desktop_sync_enabled()) { return; }
    $id = (int) ($item->fields['id'] ?? 0);
    if ($id <= 0) { return; }
    global $DB;
    if (!$DB->doQuery('DELETE FROM glpi_plugin_glpichat_desktopvisibility WHERE itilfollowups_id=' . $id
        . ' AND NOT EXISTS (SELECT 1 FROM glpi_itilfollowups WHERE id=' . $id . ') LIMIT 1')) {
        throw new RuntimeException('Desktop visibility epoch cleanup failed.');
    }
}

/** Current actor/public/unread authorization is evaluated at every page. The
 * before cursor only partitions a repeated full sweep; it is not a delivery
 * checkpoint. Exact token deduplication catches late commits and old IDs on a
 * later sweep without assuming global transaction commit order. */
function glpichat_desktop_visibility_page(array $actor, int $before = 0): array
{
    $empty = ['visibility_events' => [], 'visibility_recent_events' => [], 'visibility_next_before' => 0, 'visibility_has_more' => false];
    if (!glpichat_desktop_sync_enabled()) { return $empty; }
    $user = (int) ($actor['user_id'] ?? 0);
    $entity = (int) ($actor['entity_id'] ?? -1);
    if ($user <= 0 || $entity < 0 || empty($actor['can_read'])) { return $empty; }
    $base = 'SELECT v.itilfollowups_id AS message_id,v.tickets_id AS ticket_id,v.token '
        . 'FROM glpi_plugin_glpichat_desktopvisibility v INNER JOIN glpi_tickets t ON t.id=v.tickets_id '
        . "INNER JOIN glpi_itilfollowups f ON f.id=v.itilfollowups_id AND f.items_id=v.tickets_id AND f.itemtype='Ticket' "
        . "WHERE v.is_private=0 AND v.token IS NOT NULL "
        . "AND EXISTS (SELECT 1 FROM glpi_tickets_users tu WHERE tu.tickets_id=t.id AND tu.users_id=$user AND tu.type=1) "
        . "AND t.entities_id=$entity AND t.is_deleted=0 AND t.status IN (1,2,3,4,5,6) AND f.users_id<>$user "
        . "AND NOT EXISTS (SELECT 1 FROM glpi_plugin_glpichat_desktopreads dr WHERE dr.itilfollowups_id=f.id AND dr.users_id=$user) AND "
        . glpichat_desktop_public_followup_predicate();
    $rows = glpichat_desktop_db_rows($base
        . ($before > 0 ? ' AND v.itilfollowups_id<' . $before : '')
        . ' ORDER BY v.itilfollowups_id DESC LIMIT 21');
    $hasMore = count($rows) > 20;
    $rows = array_slice($rows, 0, 20);
    $encode = static function (array $rows): array {
        $events = [];
        foreach ($rows as $row) {
            if (preg_match('/\A[a-f0-9]{32}\z/D', (string) $row['token']) !== 1) { throw new RuntimeException('Invalid desktop visibility epoch.'); }
            $events[] = ['ticket_id' => (int) $row['ticket_id'], 'message_id' => (int) $row['message_id'], 'token' => (string) $row['token']];
        }
        return $events;
    };
    $events = $encode($rows);
    // A newly public old ID must not wait for a long sweep of already-seen
    // unread epochs. The bounded recent head accompanies every summary page;
    // exact client token dedup is shared with the independent ID continuation.
    $recent = $encode(glpichat_desktop_db_rows($base . ' ORDER BY v.changed_at DESC,v.itilfollowups_id DESC LIMIT 20'));
    return ['visibility_events' => $events, 'visibility_recent_events' => $recent, 'visibility_has_more' => $hasMore,
        'visibility_next_before' => $hasMore && $events ? $events[count($events) - 1]['message_id'] : 0];
}
