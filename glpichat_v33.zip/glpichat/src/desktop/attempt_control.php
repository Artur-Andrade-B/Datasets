<?php

declare(strict_types=1);

require_once __DIR__ . '/authority.php';
require_once __DIR__ . '/rollouts.php';

/** An exact review snapshot, never execution authority or a local evidence claim. */
function glpichat_management_attempt_identity(array $machine, array $assignment, array $release): array
{
    return ['machine_id' => (int) $machine['id'], 'installation_id' => (string) $machine['installation_id'],
        'machine_revision' => (int) $machine['admin_revision'], 'assignment_id' => (int) $assignment['id'],
        'assignment_revision' => (int) ($assignment['admin_revision'] ?? 0),
        'assignment_release_id' => (int) $release['id'], 'assignment_sequence' => (int) $release['sequence'],
        'assignment_action' => (string) $assignment['action'],
        'assignment_manifest_sha256' => hash('sha256', (string) $release['manifest_json'])];
}

function glpichat_management_attempt_receipt(array $audit, string $intent): array
{
    if (!hash_equals((string) $audit['intent_hash'], $intent)) {
        glpichat_desktop_fail('request_conflict', 'Esta identificação pertence a outra solicitação. Reabra os detalhes.', 409);
    }
    return ['request_id' => (string) $audit['request_id'], 'outcome' => (string) $audit['outcome'],
        'action' => (string) $audit['action'], 'after' => json_decode((string) $audit['after_json'], true, 8, JSON_THROW_ON_ERROR)];
}

/** Request proof, or record separately attested permanent retirement. Silence,
 * telemetry age and installed version are never proof that execution ended.
 * Caller enforces native CSRF; current GLPI rights are rechecked under shared
 * locks in this transaction. No target locks: dispatch uses target -> machine. */
function glpichat_management_attempt_control(array $identity, string $action, int $adminId, string $requestId,
    string $reason, string $containment = '', string $containmentReference = '', bool $containmentConfirmed = false): array
{
    glpichat_management_authority_require_schema();
    $profile = glpichat_management_issuing_profile();
    $reason = trim($reason); $containmentReference = trim($containmentReference);
    $keys = ['machine_id', 'installation_id', 'machine_revision', 'assignment_id', 'assignment_revision',
        'assignment_release_id', 'assignment_sequence', 'assignment_action', 'assignment_manifest_sha256'];
    if (array_diff(array_keys($identity), $keys) || array_diff($keys, array_keys($identity))
        || !in_array($action, ['reconcile_attempt', 'retire_attempt'], true) || $adminId < 1 || !$profile
        || !glpichat_desktop_auth_hex($requestId, 32)) {
        glpichat_desktop_fail('invalid_request', 'Identidade ou ação de reconciliação inválida.', 400);
    }
    foreach (['machine_id', 'machine_revision', 'assignment_id', 'assignment_revision', 'assignment_release_id', 'assignment_sequence'] as $field) {
        if (!is_int($identity[$field]) || $identity[$field] < (str_ends_with($field, '_revision') ? 0 : 1)
            || $identity[$field] >= (str_ends_with($field, '_revision') ? 4294967295 : PHP_INT_MAX)) {
            glpichat_desktop_fail('invalid_request', 'Identificador ou revisão inválida.', 400);
        }
    }
    if (!is_string($identity['installation_id']) || !is_string($identity['assignment_action'])
        || !is_string($identity['assignment_manifest_sha256']) || !glpichat_desktop_auth_hex($identity['assignment_manifest_sha256'])) {
        glpichat_desktop_fail('invalid_request', 'Identidade da operação inválida.', 400);
    }
    glpichat_management_uuid($identity['installation_id']);
    foreach ([$reason, $containmentReference] as $text) {
        if (strlen($text) > 500 || preg_match('//u', $text) !== 1 || preg_match('/[\x00-\x1f\x7f]/', $text)) {
            glpichat_desktop_fail('invalid_request', 'Justificativa ou referência inválida.', 400);
        }
    }
    if (strlen($reason) < 3 || ($action === 'retire_attempt'
        && (!$containmentConfirmed || !in_array($containment, ['decommissioned', 'reimaged'], true) || strlen($containmentReference) < 3))
        || ($action === 'reconcile_attempt' && ($containment !== '' || $containmentReference !== '' || $containmentConfirmed))) {
        glpichat_desktop_fail('containment_required', 'Informe o motivo e, para retirada permanente, a contenção concluída e sua referência de evidência.', 400);
    }
    // Canonical key order makes retries independent of JSON object formatting.
    $identity = array_replace(array_fill_keys($keys, null), $identity);
    $intent = hash('sha256', json_encode([$identity, $action, $adminId, $profile, $reason, $containment, $containmentReference, $containmentConfirmed], JSON_THROW_ON_ERROR));
    $requestWhere = 'actor_id=' . $adminId . ' AND request_id=' . glpichat_desktop_quote($requestId);
    try { return glpichat_management_transaction(static function () use ($identity, $action, $adminId, $profile, $requestId, $reason, $containment, $containmentReference, $intent, $requestWhere): array {
        // Current rights are required even to resolve a receipt through this mutation service.
        if (!glpichat_management_admin_has_right($adminId, $profile, defined('UPDATE') ? (int) UPDATE : 2, true)) {
            glpichat_desktop_fail('forbidden', 'A permissão administrativa foi removida.', 403);
        }
        $machine = glpichat_management_one(GLPICHAT_MANAGEMENT_MACHINES, 'id=' . $identity['machine_id'], true);
        if (!$machine || !hash_equals((string) $machine['installation_id'], $identity['installation_id'])) {
            glpichat_desktop_fail('assignment_identity_mismatch', 'A instalação não corresponde à revisão solicitada.', 409);
        }
        $receipt = glpichat_management_one(GLPICHAT_MANAGEMENT_AUDIT, $requestWhere);
        if ($receipt) { return glpichat_management_attempt_receipt($receipt, $intent); }
        $assignment = glpichat_management_one(GLPICHAT_MANAGEMENT_ASSIGNMENTS,
            'id=' . $identity['assignment_id'] . ' AND machines_id=' . $identity['machine_id'], true);
        $release = $assignment ? glpichat_management_one(GLPICHAT_MANAGEMENT_RELEASES, 'id=' . (int) $assignment['releases_id']) : [];
        glpichat_management_validate_report($identity, $assignment, $release);
        if ((int) $machine['admin_revision'] !== $identity['machine_revision']
            || (int) ($assignment['admin_revision'] ?? 0) !== $identity['assignment_revision']) {
            glpichat_desktop_fail('revision_conflict', 'A instalação ou operação mudou. Reabra os detalhes antes de confirmar.', 409);
        }
        if (!in_array($assignment['status'], ['pending', 'started'], true)
            || !glpichat_management_assignment_authorized($assignment) || $machine['status'] === 'retired') {
            glpichat_desktop_fail('attempt_not_unresolved', 'Esta operação já tem uma disposição ou ainda não recebeu autorização de execução.', 409);
        }
        if ($action === 'reconcile_attempt' && $machine['status'] !== 'active') {
            glpichat_desktop_fail('machine_invalid', 'Reative o gerenciamento para que o computador possa entregar sua evidência. Isso não redistribui a operação bloqueada.', 409);
        }
        $before = ['identity' => $identity, 'machine_status' => $machine['status'], 'status' => $assignment['status'],
            'dispatch_blocked' => (int) $assignment['dispatch_blocked'], 'revision' => (int) ($assignment['admin_revision'] ?? 0)];
        $values = ['dispatch_blocked' => 1, 'admin_revision' => $identity['assignment_revision'] + 1];
        $after = $before; $after['dispatch_blocked'] = 1; $after['revision'] = $values['admin_revision'];
        $outcome = 'reconciliation_requested';
        if ($action === 'retire_attempt') {
            // Do not retire an installation while concealing a second unresolved
            // historical operation. Normal creation permits at most one.
            $active = glpichat_desktop_db_rows('SELECT id FROM ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' WHERE machines_id='
                . $identity['machine_id'] . " AND status IN ('pending','started') ORDER BY id LIMIT 2");
            if (count($active) !== 1 || (int) $active[0]['id'] !== $identity['assignment_id']) {
                glpichat_desktop_fail('multiple_unresolved_attempts', 'Há outra operação não resolvida nesta instalação. Preserve as evidências e revise o histórico.', 409);
            }
            $values += ['status' => 'retired', 'completed_at' => glpichat_desktop_now()];
            glpichat_management_write(GLPICHAT_MANAGEMENT_MACHINES, ['status' => 'retired',
                'admin_revision' => $identity['machine_revision'] + 1, 'registration_recovery_until' => null], ['id' => $identity['machine_id']]);
            $after += ['containment' => $containment, 'containment_reference' => $containmentReference];
            $after['status'] = 'retired'; $after['machine_status'] = 'retired';
            $after['machine_revision'] = $identity['machine_revision'] + 1;
            $outcome = 'installation_retired';
        }
        glpichat_management_write(GLPICHAT_MANAGEMENT_ASSIGNMENTS, $values, ['id' => $identity['assignment_id']]);
        $audit = ['actor_id' => $adminId, 'origin' => 'glpi', 'request_id' => $requestId, 'intent_hash' => $intent,
            'target_kind' => 'machine', 'target_id' => $identity['machine_id'], 'action' => $action, 'reason' => $reason,
            'before_json' => json_encode($before, JSON_THROW_ON_ERROR), 'after_json' => json_encode($after, JSON_THROW_ON_ERROR),
            'outcome' => $outcome, 'created_at' => glpichat_desktop_now()];
        glpichat_management_write(GLPICHAT_MANAGEMENT_AUDIT, $audit);
        return glpichat_management_attempt_receipt($audit, $intent);
    }); }
    catch (GlpichatManagementTransactionStateException $error) { throw $error; }
    catch (Throwable $error) {
        // A duplicate on another target can lose the unique audit-key race.
        // Only a known rolled-back boundary may resolve that durable receipt.
        if (!glpichat_management_admin_has_right($adminId, $profile, defined('UPDATE') ? (int) UPDATE : 2)) { throw $error; }
        $receipt = glpichat_management_one(GLPICHAT_MANAGEMENT_AUDIT, $requestWhere);
        if ($receipt) { return glpichat_management_attempt_receipt($receipt, $intent); }
        throw $error;
    }
}
