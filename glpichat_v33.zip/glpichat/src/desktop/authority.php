<?php

declare(strict_types=1);

require_once __DIR__ . '/automatic.php';

const GLPICHAT_MANAGEMENT_AUDIT = 'glpi_plugin_glpichat_desktopadminaudit';

/** Administrative services: callers must enforce GLPI UPDATE and native CSRF.
 * Machine suspension limits management; it is deliberately not chat quarantine. */
function glpichat_management_authority_require_schema(): void
{
    if ((string) glpichat_desktop_config('desktop_schema_version') !== '14') {
        glpichat_desktop_fail('schema_unavailable', 'Conclua a atualização antes de alterar permissões.', 503);
    }
}

function glpichat_management_authority_receipt(array $audit, string $intent): array
{
    if (!hash_equals((string) $audit['intent_hash'], $intent)) {
        glpichat_desktop_fail('request_conflict', 'O identificador já pertence a outra solicitação. Atualize a página.', 409);
    }
    $before = json_decode((string) $audit['before_json'], true, 8, JSON_THROW_ON_ERROR);
    $after = json_decode((string) $audit['after_json'], true, 8, JSON_THROW_ON_ERROR);
    return ['id' => (int) $audit['id'], 'status' => $audit['outcome'], 'before_status' => $before['status'],
        'after_status' => $after['status'], 'revision' => (int) $after['revision'], 'request_id' => $audit['request_id'],
        'registration_recovery_until' => $after['registration_recovery_until'] ?? null];
}

/** One target, one bounded transaction, no telemetry-derived revision. The
 * durable receipt is written in the same transaction as authority and credentials.
 * Poll retries never write audit rows. Replaying a receipt never reapplies it. */
function glpichat_management_authority_change(string $kind, int $id, string $action, int $expectedRevision,
    int $adminId, string $requestId, string $reason, string $origin = 'glpi', ?callable $beforeChange = null): array
{
    glpichat_management_authority_require_schema();
    $reason = trim($reason);
    $allowed = ['machine' => ['suspend', 'resume', 'recover_registration'], 'binding' => ['block', 'release']];
    $validActor = ($origin === 'glpi' && $adminId > 0) || ($origin === 'local' && $adminId === 0 && PHP_SAPI === 'cli');
    if (!isset($allowed[$kind]) || !in_array($action, $allowed[$kind], true) || $id < 1 || !$validActor
        || $expectedRevision < 0 || $expectedRevision >= 4294967295 || !glpichat_desktop_auth_hex($requestId, 32)
        || $reason === '' || strlen($reason) > 500 || preg_match('//u', $reason) !== 1 || preg_match('/[\x00-\x1f\x7f]/', $reason)) {
        glpichat_desktop_fail('invalid_request', 'Alvo, revisão, justificativa ou identificador de solicitação inválido.', 400);
    }
    $intent = hash('sha256', json_encode([$kind, $id, $action, $expectedRevision, $adminId, $reason, $origin], JSON_THROW_ON_ERROR));
    $requestWhere = 'actor_id=' . $adminId . ' AND request_id=' . glpichat_desktop_quote($requestId);
    $existing = glpichat_management_one(GLPICHAT_MANAGEMENT_AUDIT, $requestWhere);
    if ($existing) { return glpichat_management_authority_receipt($existing, $intent); }
    try {
        return glpichat_management_transaction(static function () use ($kind, $id, $action, $expectedRevision, $adminId, $requestId, $reason, $origin, $intent, $requestWhere, $beforeChange): array {
            $initial = $kind === 'binding' ? glpichat_management_one(GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE, 'id=' . $id) : [];
            $machineId = $kind === 'machine' ? $id : (int) ($initial['machines_id'] ?? 0);
            // All enrollment/admin writers use machine -> binding -> device /
            // registration / grant. Never lock rollout targets here: dispatch
            // owns target -> machine and handles revision invalidation separately.
            $machine = glpichat_management_one(GLPICHAT_MANAGEMENT_MACHINES, 'id=' . $machineId, true);
            $target = $kind === 'machine' ? $machine : glpichat_management_one(GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE, 'id=' . $id, true);
            if (!$machine || !$target || ($kind === 'binding' && (int) $target['machines_id'] !== $machineId)) {
                glpichat_desktop_fail('not_found', 'Computador ou conexão não encontrado.', 404);
            }
            $existing = glpichat_management_one(GLPICHAT_MANAGEMENT_AUDIT, $requestWhere);
            if ($existing) { return glpichat_management_authority_receipt($existing, $intent); }
            // Queued jobs supply a native user/profile/right revalidation that
            // holds shared authority locks through commit. An already committed
            // receipt above remains a fact even if its issuer has since lost rights.
            if ($beforeChange !== null) { $beforeChange(); }
            $revision = (int) ($target['admin_revision'] ?? 0);
            if ($revision !== $expectedRevision) {
                glpichat_desktop_fail('admin_state_conflict', 'A permissão foi alterada por outra solicitação. Consulte o estado atual.', 409);
            }
            if ($machine['status'] === 'retired') {
                glpichat_desktop_fail('installation_retired', 'Esta instalação foi retirada permanentemente. Uma reinstalação controlada deve criar uma nova identidade.', 409);
            }
            $now = glpichat_desktop_now();
            $before = ['status' => $target['status'], 'revision' => $revision];
            $after = ['status' => $target['status'], 'revision' => $revision + 1];
            $outcome = 'applied';
            if ($kind === 'machine') {
                $before['registration_recovery_until'] = $machine['registration_recovery_until'] ?? null;
                $values = ['admin_revision' => $revision + 1];
                if ($action === 'recover_registration') {
                    if ($machine['status'] !== 'active') { glpichat_desktop_fail('machine_invalid', 'Reative o gerenciamento antes de recuperar a confirmação do registro.', 409); }
                    $values['registration_recovery_until'] = gmdate('Y-m-d H:i:s', time() + 900);
                } else {
                    $values['status'] = $action === 'suspend' ? 'revoked' : 'active';
                    $values['registration_recovery_until'] = null;
                    $after['status'] = $values['status'];
                    $outcome = $before['status'] === $after['status'] ? 'already_in_state' : 'applied';
                    if ($action === 'suspend') { glpichat_management_suspend_assignments($id); }
                }
                $after['registration_recovery_until'] = $values['registration_recovery_until'];
                glpichat_management_write(GLPICHAT_MANAGEMENT_MACHINES, $values, ['id' => $id]);
            } else {
                if ($action === 'release' && !glpichat_desktop_canonical_sid((string) $target['windows_sid'])) {
                    glpichat_desktop_fail('legacy_sid_review_required', 'Este vínculo contém um SID antigo não canônico. Revise o inventário antes de liberar acesso.', 409);
                }
                [$device, , $grant] = glpichat_desktop_automatic_lock_grant((string) ($target['current_grant_id'] ?? ''));
                if (!empty($target['current_grant_id']) && !$grant) { throw new RuntimeException('Automatic binding grant missing.'); }
                $blocked = glpichat_desktop_automatic_blocked($target, $device, $grant);
                $before['status'] = $blocked ? 'revoked' : 'active';
                $values = ['admin_revision' => $revision + 1, 'updated_at' => $now];
                if ($action === 'block') {
                    $values['status'] = 'revoked';
                    // The current credential is resolved while the durable
                    // binding is locked, not from a stale form's grant ID.
                    $revoked = ['status' => 'revoked', 'revoked_at' => $now];
                    if ($device) { glpichat_management_write(GLPICHAT_DESKTOP_DEVICES_TABLE, $revoked, ['id' => (int) $device['id']]); }
                    if ($grant) { glpichat_management_write(GLPICHAT_DESKTOP_GRANTS_TABLE, $revoked, ['id' => (int) $grant['id']]); }
                    $after['status'] = 'revoked';
                    $outcome = $blocked ? 'already_in_state' : 'applied';
                } else {
                    if ($machine['status'] !== 'active') { glpichat_desktop_fail('machine_invalid', 'Reative o gerenciamento antes de liberar esta conexão.', 409); }
                    $values['status'] = 'active';
                    if ($blocked) { $values += ['current_grant_id' => null, 'released_by' => $adminId]; }
                    $after['status'] = 'active';
                    $outcome = $blocked ? 'applied' : 'already_in_state';
                }
                glpichat_management_write(GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE, $values, ['id' => $id]);
            }
            $audit = ['actor_id' => $adminId, 'origin' => $origin, 'request_id' => $requestId, 'intent_hash' => $intent, 'target_kind' => $kind,
                'target_id' => $id, 'action' => $action, 'reason' => $reason, 'before_json' => json_encode($before, JSON_THROW_ON_ERROR),
                'after_json' => json_encode($after, JSON_THROW_ON_ERROR), 'outcome' => $outcome, 'created_at' => $now];
            $audit['id'] = glpichat_management_write(GLPICHAT_MANAGEMENT_AUDIT, $audit);
            return glpichat_management_authority_receipt($audit, $intent);
        });
    } catch (GlpichatManagementTransactionStateException $error) { throw $error; }
    catch (Throwable $error) {
        // A concurrent duplicate may have committed on a different target.
        // The unique receipt key resolves that race after successful rollback.
        $existing = glpichat_management_one(GLPICHAT_MANAGEMENT_AUDIT, $requestWhere);
        if ($existing) { return glpichat_management_authority_receipt($existing, $intent); }
        throw $error;
    }
}

/** Caller owns the locked machine. At most one active assignment is allowed by
 * assignment creation. A retained started operation is historical/in-flight:
 * no resume can distribute its payload again, but exact late results still apply. */
function glpichat_management_suspend_assignments(int $machineId): void
{
    $assignment = glpichat_management_pending($machineId, true);
    if (!$assignment) { return; }
    $values = ['dispatch_blocked' => 1];
    if ($assignment['status'] === 'pending' && !glpichat_management_assignment_authorized($assignment)) {
        $values += ['status' => 'superseded', 'completed_at' => glpichat_desktop_now(), 'last_error' => 'management_suspended'];
    }
    glpichat_management_write(GLPICHAT_MANAGEMENT_ASSIGNMENTS, $values, ['id' => (int) $assignment['id']]);
}

function glpichat_management_authority_history(string $kind, int $id, int $limit = 50): array
{
    glpichat_management_authority_require_schema();
    if (!in_array($kind, ['machine', 'binding'], true) || $id < 1) { glpichat_desktop_fail('invalid_request', 'Alvo inválido.', 400); }
    $limit = max(1, min(100, $limit));
    return glpichat_desktop_db_rows('SELECT id,actor_id,origin,request_id,target_kind,target_id,action,reason,before_json,after_json,outcome,created_at FROM '
        . GLPICHAT_MANAGEMENT_AUDIT . ' WHERE target_kind=' . glpichat_desktop_quote($kind) . ' AND target_id=' . $id . ' ORDER BY id DESC LIMIT ' . $limit);
}

/** Read-only cursor scan; no full-fleet response and no mutation/merging of
 * historical identities or authority. Secret/hash columns never leave this API. */
function glpichat_desktop_sid_inventory(string $kind, int $afterId = 0, int $limit = 500): array
{
    glpichat_management_authority_require_schema();
    $table = match ($kind) { 'binding' => GLPICHAT_DESKTOP_AUTOBINDINGS_TABLE, 'grant' => GLPICHAT_DESKTOP_GRANTS_TABLE, default => '' };
    if ($table === '' || $afterId < 0) { glpichat_desktop_fail('invalid_request', 'Cursor de inventário inválido.', 400); }
    $limit = max(1, min(1000, $limit));
    $columns = $kind === 'binding' ? 'id,windows_sid,machines_id,users_id,status,current_grant_id' : 'id,windows_sid,automatic_machines_id,users_id,status,grant_id,computer_name';
    $rows = glpichat_desktop_db_rows('SELECT ' . $columns . ' FROM ' . $table . ' WHERE id>' . $afterId . ' ORDER BY id LIMIT ' . $limit);
    $findings = [];
    foreach ($rows as $row) {
        if (glpichat_desktop_canonical_sid((string) $row['windows_sid'])) { continue; }
        $finding = array_intersect_key($row, array_fill_keys(explode(',', $columns), true));
        $finding['issue'] = 'noncanonical_sid';
        if ($kind === 'grant') {
            $registration = glpichat_management_one(GLPICHAT_DESKTOP_REGISTRATIONS_TABLE, 'grant_id=' . glpichat_desktop_quote((string) $row['grant_id']));
            $finding['devices_id'] = (int) ($registration['devices_id'] ?? 0);
        }
        $findings[] = $finding;
    }
    return ['kind' => $kind, 'scanned' => count($rows), 'next_after_id' => count($rows) === $limit ? (int) end($rows)['id'] : null, 'findings' => $findings];
}
