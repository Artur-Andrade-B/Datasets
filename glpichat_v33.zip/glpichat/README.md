# GLPI Chat — 1.9.11-desktop24

Plugin GLPI 11.x / PHP 8.2+ com desktop Windows 0.9.14. Candidato de preparação, schema desktop **14 aditivo**. Preserva identidades, credenciais, revogações, rascunhos e recuperação. Utilize versões corrigidas e qualificadas pela organização.

Atualize **sem desinstalar**. Conclua migração e verifique o gerenciamento antes do rollout Windows. Leia docs/INSTALLATION_PT-BR.md e docs/releases/1.9.11-desktop24.md. O ZIP runtime contém somente glpichat/; desktop release e admin são separados. Não inclua configuração de implantação, chaves ou credenciais nos pacotes.

A versão acrescenta validação canônica de SID, controles auditados de gerenciamento e vínculos, prévias de alvos fixos, limites/pausa de distribuição e console com quatro áreas e acompanhamento automático. Ações retornam por HTTP303 a uma consulta GET; atualizar a página não repete o POST. Permissão, contato recente, processamento, arquivos instalados e prontidão do Widget são apresentados separadamente.

Suspender gerenciamento não é quarentena integral de chat. Reativar uma máquina não libera usuários bloqueados nem revive trabalho pendente substituído. Liberar uma conexão permite nova autorização; credenciais antigas continuam revogadas.

Quem aguarda importação AD/GLPI continua tentando sem token manual ou limite total de tentativas. Usuários no mesmo PC e a mesma conta em PCs distintos mantêm conexões independentes. O chat do navegador permanece desabilitado por padrão.

A política de publisher é independente e protegida; não é habilitada automaticamente no piloto sem assinatura. Qualificação nativa Windows/GPO/AD, CA/TLS, capacidade, assinatura final1.0.0 e Kaspersky permanecem gates específicos, documentados no pacote completo.


Nesta versão, solicitações de conciliação conservam capacidade até prova exata. Aposentadoria permanente é irreversível e exige contenção documentada; bloqueia a identidade antiga, sem declarar sucesso de atualização. O padrão de polling é 30 s em segundo plano, 5 s com chat aberto e reconciliação de resumos em 120 s, com jitter/esperas limitadas. Reservas de trabalho LDAP protegem consultas de enrollment. Estado protegido ilegível abre suporte visível e preserva arquivos; não o trate como conexão saudável. Consulte as notas desta versão para limites, testes e a sequência antes de 1.0.0.
