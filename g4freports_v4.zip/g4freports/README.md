# Relatórios G4F

Plugin GLPI API-first para gerar rascunhos de relatórios com múltiplos contextos, revisão manual, análises editáveis e exportação DOCX em papel timbrado G4F.

## Principais pontos

- Extração de dados via API REST do GLPI.
- Sem tabelas próprias de negócio.
- Sem PHPWord, ZipArchive, bibliotecas JS externas ou CDN.
- Composer é opcional: o plugin inclui autoload interno em `inc/autoload.php`.
- `vendor/autoload.php` é intencionalmente vazio, seguindo o padrão usado no GLPIBot.
- O menu em Ferramentas abre somente o gerador de relatório.
- A configuração administrativa fica em Configurar > Geral > Relatórios G4F.
- Chamadas de teste e extração usam endpoints em `front/`, não `ajax/`.
- CSS/JS das páginas são inseridos pelo PHP da própria página, evitando 404 de assets estáticos em instalações com public-root/proxy.
- Exportação DOCX usa o papel timbrado G4F base e preserva cabeçalho/rodapé/grafismo.

## Instalação

```bash
cd /var/www/html/glpi/plugins
rm -rf g4freports
unzip g4freports_v0.8.0_analytics_statefix.zip
chown -R www-data:www-data g4freports
```

Composer continua opcional:

```bash
cd /var/www/html/glpi/plugins/g4freports
composer install --no-dev --optimize-autoloader
chown -R www-data:www-data /var/www/html/glpi/plugins/g4freports
```

Depois:

1. Configurar > Plugins > Relatórios G4F > Instalar/Habilitar.
2. Configurar > Geral > Relatórios G4F.
3. Preencher o perfil padrão da API GLPI.
4. Usar o botão `Testar conexão padrão`.
5. Ferramentas > Relatórios G4F para gerar o relatório.

## Contextos do relatório

O usuário pode marcar múltiplos contextos ao mesmo tempo:

- Chamados atribuídos ao agente.
- Chamados solicitados pelo agente.
- Chamados atribuídos aos grupos selecionados explicitamente.
- Tarefas de chamado feitas pelo agente.
- Acompanhamentos feitos pelo agente.
- Soluções registradas pelo agente.
- Projetos gerenciados pelo agente.
- Projetos gerenciados pelos grupos selecionados explicitamente.
- Projetos em que o agente participa.
- Tarefas de projeto do agente.
- Tarefas de projeto dos grupos selecionados explicitamente.
- Entradas narrativas manuais.

## Análises selecionáveis

As análises são calculadas a partir do rascunho já extraído, sem criar uma segunda varredura independente na API:

- Resumo por dia.
- Distribuição por status.
- Origem das atividades.
- Agente x grupos selecionados.
- Top categorias.
- Localização dos chamados.
- Tempo médio de resposta.
- Tempo de primeira resposta.
- Eventos do solicitante sem resposta técnica.
- Tabela consolidada de indicadores.

As visualizações exportadas para DOCX são tabelas/gráficos editáveis em Word, sem imagens geradas dinamicamente.

## Alterações v0.8.0

- Corrigido ciclo de geração/exportação para evitar erro de autorização ao gerar um rascunho, exportar e depois alterar parâmetros sem recarregar a página.
- Exportação DOCX agora ocorre em iframe oculto, sem navegar a página principal.
- Sessões da API GLPI são finalizadas em `finally` nos endpoints de teste, busca e geração.
- Busca de grupos por nome usa descoberta de search options e tenta múltiplos campos seguros de nome/completename.
- ID e nome do agente são somente leitura e preenchidos pela busca.
- Adicionada área de análises selecionáveis junto dos contextos.
- Adicionadas análises de tempo de resposta com cálculo requester -> primeira ação técnica posterior.
- Adicionada análise de localização com fallback: localização do chamado, localização do solicitante e `Local não informado`.
- DOCX recebeu tabelas/gráficos editáveis para análises.
- Modelos operacional, gerencial, técnico/projeto e anexo ficaram mais diferenciados.
