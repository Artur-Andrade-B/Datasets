<?php
/**
 * Runs the real save endpoint, bootstrap and plugin classes in isolated PHP requests.
 * GLPI's Config/session APIs and DB transport are test doubles; this is not a live
 * MariaDB test. Optionally pass an official GLPI DBmysql.php path to inherit its
 * actual getLock/releaseLock implementations (including GLPI 11's query ban).
 * Usage: php tests/register_save_endpoint_test.php [/path/to/GLPI/src/DBmysql.php]
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }

if (($argv[1] ?? '') === '--request') {
    $fixture = json_decode(stream_get_contents(STDIN), true, 512, JSON_THROW_ON_ERROR);
    $GLOBALS['register_fixture'] = $fixture;
    $GLOBALS['register_trace'] = [];
    define('GLPI_ROOT', $fixture['root']);
    define('UPDATE', 2);
    class CommonGLPI {}
    class Config extends CommonGLPI
    {
        public static function getConfigurationValues($context): array
        {
            $GLOBALS['register_trace'][] = 'read';
            return json_decode(file_get_contents($GLOBALS['register_fixture']['state']), true, 512, JSON_THROW_ON_ERROR);
        }
        public static function setConfigurationValues($context, $values): void
        {
            $GLOBALS['register_trace'][] = 'write';
            $fixture = $GLOBALS['register_fixture'];
            if (($fixture['write'] ?? '') === 'throw') throw new RuntimeException('Test persistence failed.');
            if (($fixture['write'] ?? '') === 'ignore') return;
            $current = json_decode(file_get_contents($fixture['state']), true, 512, JSON_THROW_ON_ERROR);
            file_put_contents($fixture['state'], json_encode(array_replace($current, $values), JSON_THROW_ON_ERROR));
        }
    }
    class Session
    {
        public static function getLoginUserID(): int { return $GLOBALS['register_fixture']['user'] ?? 42; }
        public static function haveRight($right, $level): bool { return $GLOBALS['register_fixture']['configure'] ?? true; }
        public static function getNewCSRFToken(): string { return 'next-fixture-csrf'; }
    }
    if (!empty($fixture['upstream'])) {
        require $fixture['upstream'];
    } else {
        // Minimal public DBmysql contract. Use the optional source argument to
        // run these same requests against the real version-specific methods.
        class DBmysql
        {
            public $dbdefault = 'glpi_fixture';
            public function query($query) { throw new RuntimeException('Executing direct queries is not allowed!'); }
            public function getLock($name)
            {
                $result = $this->doQuery('SELECT GET_LOCK(' . $this->quote($this->dbdefault . '.' . $name) . ', 0)');
                [$ok] = $this->fetchRow($result);
                return (bool)$ok;
            }
            public function releaseLock($name)
            {
                $result = $this->doQuery('SELECT RELEASE_LOCK(' . $this->quote($this->dbdefault . '.' . $name) . ')');
                [$ok] = $this->fetchRow($result);
                return $ok;
            }
        }
    }
    class RegisterDbTransport extends DBmysql
    {
        public function __construct() { $this->dbdefault = 'glpi_fixture'; }
        public function query($query)
        {
            // GLPI 10's native lock implementation calls query internally;
            // calls originating in plugin code always fail in this harness.
            $caller = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2)[1] ?? [];
            if (in_array($caller['function'] ?? '', ['getLock', 'releaseLock'], true)
                && ($caller['class'] ?? '') === 'DBmysql') return $this->doQuery($query);
            $GLOBALS['register_trace'][] = 'forbidden_query';
            throw new RuntimeException('Executing direct queries is not allowed!');
        }
        public function quote($value, int $type = 2) { return "'" . addslashes($value) . "'"; }
        public function fetchRow($result) { return $result; }
        public function doQuery($query)
        {
            $fixture = $GLOBALS['register_fixture'];
            if (str_starts_with($query, 'SELECT GET_LOCK(')) {
                $GLOBALS['register_trace'][] = 'lock';
                $GLOBALS['register_trace'][] = $query;
                if (($fixture['lock'] ?? '') === 'throw') throw new RuntimeException('Test lock failed.');
                return [($fixture['lock'] ?? '') === 'occupied' ? 0 : 1];
            }
            if (str_starts_with($query, 'SELECT RELEASE_LOCK(')) {
                $GLOBALS['register_trace'][] = 'unlock';
                $GLOBALS['register_trace'][] = $query;
                if (($fixture['release'] ?? '') === 'throw') throw new RuntimeException('DO_NOT_LOG_PRIVATE_DATABASE_MESSAGE');
                return [($fixture['release'] ?? '') === 'false' ? 0 : 1];
            }
            throw new LogicException('Unexpected query in isolated register transport.');
        }
    }
    $DB = new RegisterDbTransport();
    $_SERVER['REQUEST_METHOD'] = $fixture['method'] ?? 'POST';
    $_SESSION = ['glpiID' => $fixture['user'] ?? 42, 'glpiname' => 'Fixture administrator', 'g4freports_ses_nonce' => 'fixture-nonce'];
    $_POST = $fixture['post'];
    register_shutdown_function(static function () use ($fixture): void {
        file_put_contents($fixture['metadata'], json_encode([
            'status' => http_response_code(), 'trace' => $GLOBALS['register_trace'],
        ], JSON_THROW_ON_ERROR));
    });
    // No endpoint code is copied, transformed or eval'd. Its own JSON response
    // exits this subprocess after the same validation/save/readback path.
    require dirname(__DIR__) . '/front/ses_registers.php';
    exit(99);
}

require dirname(__DIR__) . '/inc/autoload.php';
use GlpiPlugin\G4freports\Ses\StaffRegister as Staff;
use GlpiPlugin\G4freports\Ses\Settings;

$assertions = 0;
function saveCheck(bool $condition, string $message): void
{
    global $assertions;
    $assertions++;
    if (!$condition) throw new RuntimeException($message);
}
function saveRequest(array $post, array $options = []): array
{
    global $root, $state, $upstream;
    $metadata = $root . '/response-meta.json';
    $input = array_replace(['root' => $root, 'state' => $state, 'metadata' => $metadata,
        'upstream' => $upstream, 'post' => array_replace(['_ses_nonce' => 'fixture-nonce'], $post)], $options);
    $pipes = [];
    $command = [PHP_BINARY];
    // Preserve extension loading in isolated runtimes launched with php -n.
    if (!php_ini_loaded_file()) {
        array_push($command, '-n', '-d', 'extension_dir=' . ini_get('extension_dir'));
        foreach (['ctype', 'iconv', 'mbstring'] as $extension) {
            if (extension_loaded($extension) && is_file(ini_get('extension_dir') . '/' . $extension . '.so')) {
                array_push($command, '-d', 'extension=' . $extension);
            }
        }
    }
    array_push($command, __FILE__, '--request');
    $process = proc_open($command, [['pipe', 'r'], ['pipe', 'w'], ['pipe', 'w']], $pipes);
    if (!is_resource($process)) throw new RuntimeException('Could not launch endpoint fixture.');
    fwrite($pipes[0], json_encode($input, JSON_THROW_ON_ERROR)); fclose($pipes[0]);
    $stdout = stream_get_contents($pipes[1]); fclose($pipes[1]);
    $stderr = stream_get_contents($pipes[2]); fclose($pipes[2]);
    $exit = proc_close($process);
    saveCheck($exit === 0, 'Endpoint exits normally: ' . $stderr);
    saveCheck($stderr === '', 'No PHP warnings/fatal errors: ' . $stderr);
    $response = json_decode($stdout, true, 512, JSON_THROW_ON_ERROR);
    $meta = json_decode(file_get_contents($metadata), true, 512, JSON_THROW_ON_ERROR);
    saveCheck(!in_array('forbidden_query', $meta['trace'], true), 'Plugin never calls forbidden direct-query API');
    return [$response, $meta];
}
function savePayload(string $kind, array $before, array $after): array
{
    return ['action' => 'save_' . $kind, 'kind' => $kind,
        'revision' => Staff::revision($before), 'rows' => Staff::json($after)];
}
function persistedRows(string $kind): array
{
    global $state;
    $cfg = json_decode(file_get_contents($state), true, 512, JSON_THROW_ON_ERROR);
    return $kind === 'staff' ? Staff::fromSettings($cfg) : Settings::testNumbers($cfg['ses_test_numbers_json'] ?? '[]');
}
function staffFixture(int $id): array
{
    return ['id' => 'agent_' . $id, 'name' => 'Profissional ' . str_pad((string)$id, 2, '0', STR_PAD_LEFT),
        'profile' => 'Analista', 'admission_date' => '2025-01-01', 'departure_date' => null,
        'monthly_value' => '1000.00', 'not_billed' => $id === 3];
}

$upstream = isset($argv[1]) ? realpath($argv[1]) : null;
if (isset($argv[1]) && !$upstream) throw new RuntimeException('Official DBmysql source path not found.');
$root = sys_get_temp_dir() . '/g4fr-save-' . bin2hex(random_bytes(6));
mkdir($root . '/files/_log', 0700, true);
$state = $root . '/configuration.json';
try {
    $before = Staff::rows(array_map('staffFixture', range(1, 30)));
    $phones = Settings::testNumbers([['number' => '00123', 'label' => 'Teste 1', 'active' => true],
        ['number' => '00619', 'label' => 'Teste 2', 'active' => false]]);
    file_put_contents($state, json_encode([Staff::CONFIG_KEY => Staff::json($before), 'ses_test_numbers_json' => Staff::json($phones)], JSON_THROW_ON_ERROR));

    // The UI collects every page before this endpoint receives the payload.
    // Simulate edits from page 1/page 2 plus a new entry, preserving all others.
    $edited = $before;
    $edited[0]['name'] = 'Agente alterado na página 1';
    $edited[26]['monthly_value'] = '2500.50';
    $edited[] = staffFixture(31);
    $after = Staff::rows($edited);
    [$response, $meta] = saveRequest(savePayload('staff', $before, $edited));
    saveCheck($meta['status'] === 200 && $response['ok'], 'Staff create/edit request succeeds: ' . json_encode([$response, $meta]));
    saveCheck($response['rows'] === $after && persistedRows('staff') === $after, 'All 31 entries and cross-page edits survive actual save/readback');
    saveCheck($response['revision'] === Staff::revision($after), 'Saved revision matches returned complete register');
    saveCheck($response['csrf_token'] === 'next-fixture-csrf', 'Successful JSON includes refreshed CSRF token');
    saveCheck(array_column($after, 'not_billed', 'id')['agent_3'] === true, 'Existing exclusion marks remain unchanged');
    $events = array_values(array_filter($meta['trace'], static fn($event) => !str_starts_with($event, 'SELECT ')));
    saveCheck($events === ['read', 'lock', 'read', 'write', 'read', 'unlock'], 'Lock surrounds fresh revision check, persistence and readback');
    saveCheck(str_contains(implode('\n', $meta['trace']), 'glpi_fixture.g4fr_registers_'), 'Native lock API namespaces the lock by database');

    [$history, $historyMeta] = saveRequest(['action' => 'history', 'kind' => 'staff']);
    saveCheck($historyMeta['status'] === 200 && count($history['history']) === 1, 'History endpoint works with native lock');
    saveCheck($history['history'][0]['added'] === 1 && $history['history'][0]['updated'] === 2, 'History records both edits and added employment');
    [$detail] = saveRequest(['action' => 'history_detail', 'kind' => 'staff', 'history_id' => $history['history'][0]['id']]);
    saveCheck($detail['rows'] === $before, 'Actual history_detail endpoint recovers previous complete register');

    $newPhones = $phones;
    $newPhones[0]['label'] = 'Descrição alterada';
    $newPhones[] = ['number' => '0000077', 'label' => 'Novo teste', 'active' => true];
    [$phoneResponse, $phoneMeta] = saveRequest(savePayload('tests', $phones, $newPhones));
    saveCheck($phoneMeta['status'] === 200 && $phoneResponse['rows'] === $newPhones, 'Test-number register uses same successful save path');
    saveCheck(persistedRows('tests') === $newPhones && persistedRows('staff') === $after, 'Phone save retains leading zeros/status and does not alter staff');
    $staffLock = array_values(array_filter($meta['trace'], static fn($event) => str_starts_with($event, 'SELECT GET_LOCK(')));
    $phoneLock = array_values(array_filter($phoneMeta['trace'], static fn($event) => str_starts_with($event, 'SELECT GET_LOCK(')));
    saveCheck(count($staffLock) === 1 && $staffLock === $phoneLock, 'Both register kinds use the same native serialization lock');

    $snapshot = file_get_contents($state);
    [$conflict, $conflictMeta] = saveRequest(savePayload('staff', $before, $edited));
    saveCheck($conflictMeta['status'] === 409 && !$conflict['ok'], 'Stale revision remains a conflict');
    saveCheck(file_get_contents($state) === $snapshot && in_array('unlock', $conflictMeta['trace'], true), 'Conflict preserves saved configuration and releases lock');
    [$invalid, $invalidMeta] = saveRequest(['action' => 'save_staff', 'revision' => Staff::revision($after), 'rows' => '[invalid']);
    saveCheck($invalidMeta['status'] === 400 && !$invalid['ok'], 'Invalid rows rejected with structured response');
    saveCheck(file_get_contents($state) === $snapshot && in_array('unlock', $invalidMeta['trace'], true), 'Invalid rows cannot save and still release lock');
    [$revisionError, $revisionMeta] = saveRequest(['action' => 'save_staff', 'revision' => 'bad', 'rows' => '[]']);
    saveCheck($revisionMeta['status'] === 400 && !$revisionError['ok'], 'Malformed revision rejected');
    [$occupied, $occupiedMeta] = saveRequest(savePayload('staff', $after, $after), ['lock' => 'occupied']);
    saveCheck($occupiedMeta['status'] === 500 && str_contains($occupied['error'], 'Outro cadastro'), 'Busy native lock returns controlled retry response');
    saveCheck(!in_array('write', $occupiedMeta['trace'], true) && !in_array('unlock', $occupiedMeta['trace'], true), 'Unacquired lock is never released and cannot permit save');
    [$lockError, $lockMeta] = saveRequest(savePayload('staff', $after, $after), ['lock' => 'throw']);
    saveCheck($lockMeta['status'] === 500 && !in_array('unlock', $lockMeta['trace'], true), 'Acquisition exception becomes JSON without erroneous release');

    foreach (['throw', 'false'] as $releaseMode) {
        $updated = $after; $updated[0]['monthly_value'] = $releaseMode === 'throw' ? '1250.00' : '1300.00';
        [$releaseResult, $releaseMeta] = saveRequest(savePayload('staff', $after, $updated), ['release' => $releaseMode]);
        $after = Staff::rows($updated);
        saveCheck($releaseMeta['status'] === 200 && $releaseResult['ok'] && persistedRows('staff') === $after, 'Release failure cannot conceal confirmed save: ' . $releaseMode);
        saveCheck($releaseResult['csrf_token'] === 'next-fixture-csrf', 'Cleanup failure retains refreshed client token');
    }
    $log = file_get_contents($root . '/files/_log/g4freports-plugin.log');
    saveCheck(substr_count($log, 'SES_REGISTER_LOCK_RELEASE_FAILED') === 2, 'Both cleanup failure forms recorded as narrow events');
    saveCheck(!str_contains($log, 'DO_NOT_LOG') && !str_contains($log, 'Profissional'), 'Cleanup log contains no DB exception message or register values');
    [$badAndRelease, $badAndReleaseMeta] = saveRequest(['action' => 'save_staff', 'revision' => Staff::revision($after), 'rows' => '[invalid'], ['release' => 'throw']);
    saveCheck($badAndReleaseMeta['status'] === 400 && str_contains($badAndRelease['error'], 'JSON inválido'), 'Cleanup error does not replace original validation error');

    $updated = $after; $updated[0]['monthly_value'] = '1600.00';
    [$writeError, $writeMeta] = saveRequest(savePayload('staff', $after, $updated), ['write' => 'throw', 'release' => 'throw']);
    saveCheck($writeMeta['status'] === 500 && $writeError['error'] === 'Test persistence failed.', 'Cleanup error does not replace original persistence error');
    saveCheck(persistedRows('staff') === $after, 'Failed write preserves prior saved register');
    [$noWrite, $noWriteMeta] = saveRequest(savePayload('staff', $after, $updated), ['write' => 'ignore']);
    saveCheck($noWriteMeta['status'] === 500 && str_contains($noWrite['error'], 'não confirmou'), 'Readback mismatch still blocks a false success');

    foreach ([['configure' => false], ['user' => 0], ['post' => ['_ses_nonce' => 'wrong']], ['method' => 'GET']] as $denial) {
        [$denied, $deniedMeta] = saveRequest(savePayload('staff', $after, $after), $denial);
        saveCheck(in_array($deniedMeta['status'], [403, 405], true) && !$denied['ok'], 'Permission/session/method checks still apply');
        saveCheck(!in_array('lock', $deniedMeta['trace'], true) && !in_array('write', $deniedMeta['trace'], true), 'Denied requests never acquire lock or mutate register');
    }
    echo 'Register save endpoint checks passed: ' . $assertions . ' assertions; '
        . ($upstream ? 'official DBmysql methods from ' . basename($upstream) : 'GLPI API contract double')
        . "; DB transport/Config/session mocked, no live GLPI/MariaDB.\n";
} finally {
    foreach (glob($root . '/files/_log/*') ?: [] as $file) unlink($file);
    foreach (glob($root . '/*.json') ?: [] as $file) unlink($file);
    rmdir($root . '/files/_log'); rmdir($root . '/files'); rmdir($root);
}
