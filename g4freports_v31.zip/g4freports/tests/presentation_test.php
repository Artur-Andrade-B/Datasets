<?php
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
/** Synthetic reconciliation checks; no customer records or connection required. */
require dirname(__DIR__) . '/inc/autoload.php';
use GlpiPlugin\G4freports\Ses\ChartData;
use GlpiPlugin\G4freports\Ses\MetricEvidence;
use GlpiPlugin\G4freports\Ses\PhoneSurveySummary;

function verify(bool $condition, string $message): void {
    if (!$condition) throw new RuntimeException($message);
}
foreach ([5 => 1, 4 => 2, 3 => 3, 2 => 4] as $raw => $severity) {
    verify(MetricEvidence::contractSeverity($raw) === $severity, 'Contract severity mapping');
}
verify(str_contains(MetricEvidence::title('INS4', 5), 'Severidade 1'), 'Alternative selection preserves actual contractual severity');
verify(MetricEvidence::priorityName(5) === 'Muito alta', 'Named priority');
$calls = [
    ['id' => 'call-a', 'queue' => 'first', 'entered_at' => '2026-06-01 08:00:00', 'satisfaction_raw' => 1],
    ['id' => 'call-a', 'queue' => 'second', 'entered_at' => '2026-06-01 08:01:00', 'satisfaction_raw' => 1],
    ['id' => 'call-b', 'queue' => 'first', 'entered_at' => '2026-06-01 09:00:00', 'satisfaction_raw' => null],
    ['id' => 'call-c', 'queue' => 'first', 'entered_at' => '2026-06-01 10:00:00', 'satisfaction_raw' => ''],
    ['id' => 'call-d', 'queue' => 'first', 'entered_at' => '2026-06-01 11:00:00', 'satisfaction_raw' => 7],
];
foreach (['glpi_and_phone', 'glpi_only'] as $mode) {
    $summary = PhoneSurveySummary::build($calls, true, '', $mode);
    $dist = ChartData::phoneSurveyDistribution(['calls' => $calls, 'phone_survey' => $summary]);
    $counts = array_column($dist['rows'], 1, 0);
    verify($dist['total'] === 4, 'Distinct-call distribution does not count second queue twice');
    verify($counts[5] === 1 && $counts['Não preenchida'] === 2 && $counts['Nota inválida'] === 1, 'Separate rating, blank and invalid classifications');
    verify($summary['valid_responses'] === 1 && $summary['favorable_responses'] === 1, 'Blank and invalid surveys excluded from percentage');
    verify($summary['without_response'] === $counts['Não preenchida'], 'Summary reconciles with full distribution');
    verify($summary['included'] === ($mode === 'glpi_and_phone'), 'Selection changes participation, not the independent source evidence');
}
$missing = ChartData::phoneSurveyDistribution(['calls' => $calls, 'phone_survey' => PhoneSurveySummary::build($calls, false)]);
verify(!$missing['available'], 'Unavailable source is not zero answers');
$empty = ChartData::phoneSurveyDistribution(['calls' => [], 'phone_survey' => PhoneSurveySummary::build([], true)]);
verify($empty['available'] && $empty['total'] === 0, 'Available empty population distinguished from missing source');
echo "Presentation checks passed: severity, source separation, distinct calls, blanks, invalid and unavailable surveys.\n";
