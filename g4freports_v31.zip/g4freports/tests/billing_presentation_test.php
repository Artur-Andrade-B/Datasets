<?php
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }

/** Synthetic INS10 presentation checks; no customer records or connection required. */
require dirname(__DIR__) . '/inc/autoload.php';

use GlpiPlugin\G4freports\Ses\DocxExporter;
use GlpiPlugin\G4freports\Ses\ChartData;
use GlpiPlugin\G4freports\Ses\MetricEvidence;
use GlpiPlugin\G4freports\Ses\StaffRegister;
use GlpiPlugin\G4freports\Ses\XlsxExporter;

function billingPresentationVerify(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

$inputs = [];
// These are the original selections: legacy billed=true meant the user checked
// an EXCLUSION. The corrected exports must preserve that mark, never invert it.
$cases = [
    ['A', ['billed' => true], true],
    ['B', ['billed' => false], false],
    ['C', [], false],
    ['D', ['not_billed' => true], true],
    ['E', ['not_billed' => false], false],
    ['F', ['not_billed' => false, 'billed' => true], false],
    ['G', ['not_billed' => true, 'billed' => false], true],
];
foreach ($cases as [$name, $flags, $excluded]) {
    $inputs[] = [
        'id' => 'person-' . $name,
        'name' => $name,
        'profile' => 'Técnico',
        'admission_date' => '2026-01-01',
        'departure_date' => $excluded ? '2026-06-08' : '',
        'departure_reason' => 'pending',
        'monthly_value' => 100,
    ] + $flags;
}
$staff = StaffRegister::summarize($inputs, '2026-06');
billingPresentationVerify($staff['active_total'] === 4 && $staff['complete'] && $staff['pending_departures'] === 0,
    'Original checked exclusions cannot suppress the eligible headcount or cause pending departures');
$expectedMarks = ['Sim', 'Não', 'Não', 'Sim', 'Não', 'Não', 'Sim'];
$snapshot = ['period' => ['month' => '2026-06'], 'metrics' => [], 'tickets' => [], 'staff_register' => $staff];
$originalSnapshot = $snapshot;

$table = MetricEvidence::staffRegisterTable($snapshot);
billingPresentationVerify($table['headers'][10] === 'Não Faturar', 'Staff evidence uses the negative label');
billingPresentationVerify(array_column($table['rows'], 10) === $expectedMarks,
    'Exports retain original checkmarks and display canonical exclusions identically');
billingPresentationVerify(array_column(MetricEvidence::table($snapshot, 'INS10')['rows'], 0) === ['B', 'C', 'E', 'F'],
    'INS10 details contain only included professionals from the selected month');

// Also exercise the export fallback for legacy input without relying on the
// normalizer having renamed the field before presentation.
$legacySnapshot = $snapshot;
foreach ($legacySnapshot['staff_register']['rows'] as $index => &$row) {
    unset($row['not_billed'], $row['billed']);
    $row = array_merge($row, $cases[$index][1]);
}
unset($row);
billingPresentationVerify(array_column(MetricEvidence::staffRegisterTable($legacySnapshot)['rows'], 10) === $expectedMarks,
    'Legacy evidence flags preserve checked=excluded; missing flags include; canonical flags win');

$wordMethod = new ReflectionMethod(DocxExporter::class, 'staffRegister');
foreach ([$staff, $legacySnapshot['staff_register']] as $wordStaff) {
    $xml = $wordMethod->invoke(new DocxExporter(), $wordStaff);
    $document = new DOMDocument();
    billingPresentationVerify($document->loadXML('<root xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' . $xml . '</root>'),
        'Word staff section is well-formed XML');
    $xpath = new DOMXPath($document);
    $xpath->registerNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
    $tables = $xpath->query('//w:tbl');
    billingPresentationVerify($tables->length === 2, 'Word contains staff summary and full register');
    $staffRows = $xpath->query('./w:tr', $tables->item(1));
    billingPresentationVerify($staffRows->length === 10, 'Word keeps seven records and both totals');
    foreach (array_merge(['Não Faturar'], $expectedMarks, ['', 'Não']) as $index => $expected) {
        $cells = $xpath->query('./w:tc', $staffRows->item($index));
        billingPresentationVerify($cells->length === 6, 'Word staff row has six columns');
        billingPresentationVerify($cells->item(5)->textContent === $expected, 'Word negative billing flag at row ' . $index);
    }
}

$excel = new XlsxExporter();
$snapshotProperty = new ReflectionProperty(XlsxExporter::class, 'snapshot');
$snapshotProperty->setValue($excel, $snapshot);
$auditMethod = new ReflectionMethod(XlsxExporter::class, 'exclusionAudit');
$sheet = $auditMethod->invoke($excel);
$checkedFormulas = [];
foreach ($sheet['rows'] as $cells) {
    foreach ($cells as $cell) {
        $formula = $cell['formula'] ?? '';
        if (preg_match('/^(COUNTIFS|SUMIFS)\(/', $formula, $match) && str_contains($formula, '$K$')) {
            billingPresentationVerify(str_ends_with($formula, ',"Não")'), 'Excel negative billing criteria retain included records');
            billingPresentationVerify($cell['value'] === ($match[1] === 'COUNTIFS' ? 4 : 400.0),
                'Excel audit formula cache retains the included headcount or amount');
            $checkedFormulas[] = $match[1];
        }
    }
}
sort($checkedFormulas);
billingPresentationVerify($checkedFormulas === ['COUNTIFS', 'SUMIFS'], 'Headcount and amount formulas were both checked');

$foundStaffTable = false;
foreach ($sheet['tables'] as $excelTable) {
    if ($excelTable['name'] !== 'Cadastro_profissionais') {
        continue;
    }
    billingPresentationVerify(count($excelTable['headers']) === 13, 'All staff audit headers are retained');
    billingPresentationVerify(preg_match('/^A\d+:M\d+$/', $excelTable['ref']) === 1,
        'Staff audit table and filter range span all thirteen columns');
    $foundStaffTable = true;
}
billingPresentationVerify($foundStaffTable, 'Excel staff audit table was generated');
billingPresentationVerify($snapshot === $originalSnapshot, 'Export presentation does not mutate persisted billing semantics');

// Exercise the complete INS10 sheet with an 80-person active base and two exits.
// The same dates and marks must produce 2.50% for every optional reason.
$datedRoster = [];
for ($i = 1; $i <= 80; $i++) {
    $datedRoster[] = ['id' => 'active-' . $i, 'name' => sprintf('Ativo %02d', $i), 'profile' => 'Técnico',
        'admission_date' => '2026-01-01', 'departure_date' => '', 'monthly_value' => 100, 'not_billed' => false];
}
for ($i = 1; $i <= 2; $i++) {
    $datedRoster[] = ['id' => 'exit-' . $i, 'name' => 'Saída ' . $i, 'profile' => 'Técnico',
        'admission_date' => '2026-01-01', 'departure_date' => '2026-05-01', 'monthly_value' => 100, 'not_billed' => false];
}
$datedRoster[] = ['id' => 'excluded-exit', 'name' => 'Excluído', 'profile' => 'Técnico',
    'admission_date' => '2026-01-01', 'departure_date' => '2026-05-01', 'monthly_value' => 100, 'not_billed' => true];
$metricMethod = new ReflectionMethod(XlsxExporter::class, 'metric');
foreach (['pending', 'replacement', 'contractor_reduction', 'other'] as $reason) {
    $variant = $datedRoster;
    foreach ($variant as &$person) $person['departure_reason'] = $reason;
    unset($person);
    $summary = StaffRegister::summarize($variant, '2026-06');
    billingPresentationVerify($summary['numerator'] === 2 && $summary['denominator'] === 80 && $summary['value'] === 2.5,
        'Optional reason never changes the date-based INS10 result');
    $metric = ['id' => 'INS10', 'numerator' => $summary['numerator'], 'denominator' => $summary['denominator'],
        'value' => $summary['value'], 'target' => 10, 'direction' => 'lte', 'status' => 'met',
        'method' => $summary['method'], 'note' => $summary['note']];
    $datedSnapshot = ['period' => ['month' => '2026-06'], 'input' => [], 'metrics' => [$metric],
        'tickets' => [], 'calls' => [], 'staff_register' => $summary];
    $charts = ChartData::build($datedSnapshot);
    $expectedBreakdowns = [80, 2, $reason === 'contractor_reduction' ? 2 : 0,
        $reason === 'other' ? 2 : 0, $reason === 'pending' ? 2 : 0];
    billingPresentationVerify($charts['INS10']['series'][0]['values'] === $expectedBreakdowns,
        'Chart distinguishes total departures from optional descriptive breakdowns');
    billingPresentationVerify(!preg_match('/pendente|confirmar|confirmad/iu', $charts['INS10']['note'] . implode(' ', $charts['INS10']['categories'])),
        'Chart does not present optional departure descriptions as pending work');
    $datedExcel = new XlsxExporter();
    foreach (['snapshot' => $datedSnapshot, 'chartData' => $charts, 'evidence' => ['INS10' => ['available' => false]]] as $property => $value) {
        (new ReflectionProperty(XlsxExporter::class, $property))->setValue($datedExcel, $value);
    }
    $metricSheet = $metricMethod->invoke($datedExcel, $metric);
    foreach ([8 => 2, 9 => 80, 10 => 0.025, 24 => 80, 25 => 2, 26 => $expectedBreakdowns[2],
        27 => $expectedBreakdowns[3], 28 => $expectedBreakdowns[4]] as $row => $value) {
        billingPresentationVerify($metricSheet['rows'][$row][2]['value'] === $value,
            'INS10 numerical Excel cache at B' . $row . ' for ' . $reason);
    }
    billingPresentationVerify($metricSheet['rows'][8][2]['formula'] === 'B25'
        && $metricSheet['rows'][9][2]['formula'] === 'B24'
        && $metricSheet['rows'][10][2]['formula'] === 'IF(B9=0,"N/A",B8/B9)',
        'Excel INS10 remains linked to date-based departure and active headcount totals');
    billingPresentationVerify(str_contains($metricSheet['rows'][25][2]['formula'], 'COUNTIF($I$')
        && str_contains($metricSheet['rows'][28][2]['formula'], '"Motivo não informado"'),
        'Excel uses all counted departures for numerator and the optional reason only in its analytical breakdown');
    $reasonFormula = $metricSheet['rows'][['contractor_reduction' => 26, 'other' => 27, 'pending' => 28][$reason] ?? 28][2]['formula'];
    if ($reason !== 'replacement') {
        billingPresentationVerify(str_contains($reasonFormula, '"' . StaffRegister::departureReasonLabel($reason) . '"'),
            'Analytical Excel formula criteria match evidence labels exactly');
    }
    $wordXml = $wordMethod->invoke(new DocxExporter(), $summary);
    billingPresentationVerify(!preg_match('/pendente|confirmar|confirmad/iu', $wordXml)
        && str_contains($wordXml, 'Saídas consideradas no INS10') && str_contains($wordXml, 'Não Faturar'),
        'Word uses date-based counts and optional descriptions without pending labels');
    $wordDocument = new DOMDocument();
    billingPresentationVerify($wordDocument->loadXML('<root xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' . $wordXml . '</root>'),
        'Word exit detail is valid XML');
    $wordPath = new DOMXPath($wordDocument);
    $wordPath->registerNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
    $wordTables = $wordPath->query('//w:tbl');
    $exitRows = $wordPath->query('./w:tr', $wordTables->item(2));
    billingPresentationVerify($exitRows->length === 4, 'Word shows exactly two eligible departures and total');
    for ($row = 1; $row <= 2; $row++) {
        $cells = $wordPath->query('./w:tc', $exitRows->item($row));
        billingPresentationVerify($cells->item(2)->textContent === StaffRegister::departureReasonLabel($reason)
            && $cells->item(3)->textContent === 'Sim', 'Word counts both departures regardless of optional reason');
    }
}

echo "Billing presentation checks passed: original exclusions, canonical flags, date-based 2/80 INS10 across all optional reasons, Word details/totals, chart descriptions and Excel numerical/formula consistency.\n";
