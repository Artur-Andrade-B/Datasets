/* Native GLPI administration: bounded selection, read-only monitoring.
 * Mutations remain normal CSRF-protected forms and redirect to canonical GETs. */
(() => {
  'use strict';
  // A browser cache restore retains old DOM tokens and a stopped monitor.
  // Reload the canonical GET to obtain fresh CSRF state and current permissions.
  window.addEventListener('pageshow', event => { if (event.persisted) location.reload(); });
  const form = document.getElementById('desktop-assignment');
  if (form) {
    const limit = 10000;
    const lifetime = 30 * 60 * 1000;
    const key = `glpichat-fleet:${location.pathname}:${form.dataset.owner}:${form.dataset.filterKey}`;
    const rows = [...form.querySelectorAll('.fleet-machine')];
    const modes = [...form.querySelectorAll('input[name="selection"]')];
    const message = document.getElementById('fleet-selection-count');
    let state = { mode: 'selected', selected: [], excluded: [], expires: Date.now() + lifetime };
    let restored = false;
    try {
      if (form.dataset.committed === '1') sessionStorage.removeItem(key);
      const saved = JSON.parse(sessionStorage.getItem(key) || 'null');
      const valid = ids => Array.isArray(ids) && ids.length <= limit && ids.every(id => /^[1-9]\d{0,9}$/.test(String(id)) && Number(id) <= 4294967295);
      if (saved && ['selected', 'all'].includes(saved.mode) && valid(saved.selected) && valid(saved.excluded)
          && Number.isFinite(saved.expires) && saved.expires > Date.now() && saved.expires <= Date.now() + lifetime) {
        state = { mode: saved.mode, selected: [...new Set(saved.selected.map(String))], excluded: [...new Set(saved.excluded.map(String))], expires: saved.expires };
        restored = state.mode === 'all' || state.selected.length > 0;
      } else if (saved) sessionStorage.removeItem(key);
    } catch (_) { /* Without storage, selection is limited to this page. */ }
    const total = Number(form.dataset.total) || 0;
    const count = () => state.mode === 'all' ? Math.max(0, total - state.excluded.length) : state.selected.length;
    function render() {
      if (Date.now() >= state.expires) { state = { mode: 'selected', selected: [], excluded: [], expires: Date.now() + lifetime }; restored = false; }
      modes.forEach(radio => { radio.checked = radio.value === state.mode; });
      rows.forEach(row => { row.checked = state.mode === 'all' ? !state.excluded.includes(row.value) : state.selected.includes(row.value); });
      form.elements.selected_ids.value = JSON.stringify(state.selected);
      form.elements.excluded_ids.value = JSON.stringify(state.mode === 'all' ? state.excluded : []);
      message.textContent = `${restored ? 'Seleção restaurada para estes filtros. ' : ''}${count()} computadores selecionados ${state.mode === 'all' ? `em todos os resultados (${state.excluded.length} excluídos)` : 'entre páginas'}. Expira às ${new Date(state.expires).toLocaleTimeString()}. O servidor mostrará os alvos exatos antes da confirmação.${count() > limit ? ' Limite de 10.000 por lote: restrinja os filtros.' : ''}`;
      try { sessionStorage.setItem(key, JSON.stringify(state)); } catch (_) { }
    }
    modes.forEach(radio => radio.addEventListener('change', () => { state.mode = radio.value; restored = false; render(); }));
    rows.forEach(row => row.addEventListener('change', () => {
      const field = state.mode === 'all' ? 'excluded' : 'selected';
      const include = state.mode === 'all' ? !row.checked : row.checked;
      state[field] = state[field].filter(id => id !== row.value);
      if (include && state[field].length < limit) state[field].push(row.value);
      restored = false; render();
    }));
    document.getElementById('fleet-select-page').addEventListener('click', () => {
      if (state.mode === 'all') state.excluded = state.excluded.filter(id => !rows.some(row => row.value === id));
      else state.selected = [...new Set([...state.selected, ...rows.map(row => row.value)])].slice(0, limit);
      restored = false; render();
    });
    document.getElementById('fleet-clear-selection').addEventListener('click', () => {
      state = { mode: 'selected', selected: [], excluded: [], expires: Date.now() + lifetime }; restored = false; render();
    });
    form.addEventListener('submit', event => {
      render();
      if (count() < 1 || count() > limit) {
        event.preventDefault(); message.textContent = count() < 1 ? 'Selecione computadores antes de solicitar a operação.' : 'Limite de 10.000 computadores por lote. Restrinja os filtros.';
      }
    });
    render();
  }

  // Keep only an opaque request identity for uncertain form responses. A GET
  // receipt lookup resolves it; this code never retries a mutation automatically.
  const consoleRoot = document.getElementById('desktop-console');
  if (consoleRoot?.dataset.owner && consoleRoot.dataset.receiptUrl) {
    const receiptKey = `glpichat-fleet-receipt:${location.pathname}:${consoleRoot.dataset.owner}`;
    const validRequest = value => /^[a-f0-9]{32}$/.test(value || '');
    try {
      let pending = JSON.parse(sessionStorage.getItem(receiptKey) || 'null');
      const resolved = consoleRoot.dataset.resolvedRequest || document.getElementById('fleet-preview-receipt')?.dataset.requestId;
      if (pending && (pending.expires <= Date.now() || pending.request === resolved || !validRequest(pending.request))) { sessionStorage.removeItem(receiptKey); pending = null; }
      if (pending && Number.isFinite(pending.expires) && pending.expires <= Date.now() + 86400000) {
        const receiptLink = document.getElementById('fleet-receipt-link');
        const url = new URL(consoleRoot.dataset.receiptUrl, location.href); url.searchParams.set('view', 'computers'); url.searchParams.set('request_id', pending.request);
        receiptLink.href = url.href; document.getElementById('fleet-pending-receipt').hidden = false;
      }
    } catch (_) { }
    [form, document.getElementById('fleet-confirm')].filter(Boolean).forEach(mutation => mutation.addEventListener('submit', event => {
      const request = mutation.elements.request_id?.value;
      if (!event.defaultPrevented && validRequest(request)) {
        try { sessionStorage.setItem(receiptKey, JSON.stringify({ request, expires: Date.now() + 86400000 })); } catch (_) { }
      }
    }));
  }

  const exportForm = document.getElementById('desktop-export');
  if (exportForm) exportForm.addEventListener('submit', () => {
    // A download response cannot redirect the source page; never replay this POST.
    const button = exportForm.querySelector('button');
    setTimeout(() => { button.disabled = true; }, 0);
    document.getElementById('desktop-export-feedback').textContent = 'Download solicitado em uma janela separada. Se a resposta for incerta, consulte os arquivos de implantação após atualizar esta página antes de criar outra autorização.';
  });

  const monitor = document.getElementById('fleet-monitor');
  if (!monitor) return; // READ-only administrators reach this branch without an assignment form.
  const stateText = document.getElementById('fleet-monitor-state');
  const detailText = document.getElementById('fleet-monitor-detail');
  const lastCheck = document.getElementById('fleet-monitor-time');
  const refresh = document.getElementById('fleet-refresh-now');
  const relist = document.getElementById('fleet-refresh-list');
  let timer = null, controller = null, inFlight = false, stopped = false, generation = 0, failures = 0, active = true, writeRevoked = false;
  document.querySelectorAll('#desktop-console form[method="post"]').forEach(mutation => mutation.addEventListener('submit', event => {
    if (writeRevoked || stopped) event.preventDefault();
  }));
  const labels = {
    queued: 'Na fila — aguardando contato ou capacidade', waiting: 'Aguardando operação anterior', pending: 'Execução autorizada — aguardando confirmação',
    withdrawn: 'Retirada confirmada pelo computador — sem ativação', retired: 'Instalação retirada permanentemente — execução não afirmada', unknown: 'Sem resultado recente — capacidade retida', cancelled: 'Cancelado antes da autorização',
    started: 'Processamento iniciado no computador', completed: 'Arquivos instalados confirmados', failed: 'Falha informada pelo computador',
    skipped: 'Ignorado', superseded: 'Substituída', dispatch_retry: 'Aguardando nova tentativa de distribuição',
    dispatch_failed: 'Falha na distribuição pelo servidor', applied: 'Permissão aplicada', already_in_state: 'Permissão já estava neste estado', conflict: 'Conflito administrativo',
  };
  const label = value => labels[value] || String(value || 'Não informado');
  // Older responses exposed raw effective_status even for distribution errors.
  // Preserve their reason before using the current server classification.
  const targetState = target => target.reason === 'dispatch_failed' ? 'dispatch_failed'
    : target.reason === 'storage_retry' && ['queued', 'waiting'].includes(target.status) ? 'dispatch_retry'
    : target.effective_status || (target.status === 'assigned' ? (target.operation_status || 'unknown') : target.status);
  const put = (root, selector, value) => {
    const node = root.querySelector(selector);
    if (!node) return false;
    const text = String(value ?? '');
    if (node.textContent === text) return false;
    node.textContent = text; return true;
  };
  function countsText(counts, action) { return Object.entries(counts || {}).map(([key, value]) => `${key === 'completed' && ['suspend', 'resume'].includes(action) ? 'Permissão aplicada' : label(key)}: ${Number(value) || 0}`).join(' · '); }
  function renderJob(job) {
    if (!job) return;
    const row = document.querySelector(`[data-job-row="${Number(job.id)}"]`);
    const state = (Number(job.paused) === 1 ? 'Distribuição pausada. ' : '') + (job.status_label || ({completed: 'Lote encerrado — consulte os resultados', running: 'Lote em andamento', queued: 'Lote na fila', cancelled: 'Lote cancelado para novos inícios'}[job.status] || label(job.status)));
    if (row) { put(row, '[data-job-field="status_label"]', state); put(row, '[data-job-field="counts"]', countsText(job.counts, job.action)); }
    if (Number(monitor.dataset.jobId) === Number(job.id)) {
      const jobState = document.getElementById('fleet-job-state'); if (jobState) jobState.textContent = state;
      const jobCounts = document.getElementById('fleet-job-counts'); if (jobCounts) jobCounts.textContent = countsText(job.counts, job.action);
      (job.targets || []).forEach(target => {
        const targetRow = document.querySelector(`[data-target-id="${Number(target.id)}"]`); if (!targetRow) return;
        const status = targetState(target);
        const values = { status_label: status === 'completed' && ['suspend', 'resume'].includes(job.action) ? 'Permissão aplicada' : (['dispatch_failed', 'dispatch_retry'].includes(status) ? label(status) : (target.status_label || label(status))), result_label: target.result_label || [target.reason_label || target.reason, target.last_result, target.error_label || target.last_error].filter(Boolean).join(' '),
          dispatch_label: target.dispatch_label || `Tentativas com falha: ${Number(target.dispatch_attempts) || 0} / 5; última tentativa UTC: ${target.last_attempt_at || 'Ainda não registrada'}`,
          retry_label: target.reason === 'storage_retry' ? `Nova tentativa UTC: ${target.available_at || ''}` : '', last_error_ref: target.last_error_ref || '', last_seen: target.last_seen || 'Nunca' };
        Object.entries(values).forEach(([key, value]) => put(targetRow, `[data-target-field="${key}"]`, value));
      });
    }
  }
  function apply(snapshot) {
    let changed = false;
    active = false;
    snapshot.machines.forEach(machine => {
      const row = document.querySelector(`[data-machine-id="${Number(machine.id)}"]`); if (!row) return;
      const values = {
        permission_label: machine.permission_label || (machine.status === 'active' ? 'Permitido' : machine.status === 'retired' ? 'Retirado permanentemente' : 'Suspenso'), last_seen: machine.last_seen || 'Nunca',
        current_version: machine.current_version || 'Não informada', bootstrap_version: machine.bootstrap_version || '',
        operation_label: machine.operation_label || (machine.assignment_status ? label(machine.assignment_status) : 'Nenhuma'), operation_version: machine.assignment_version || '',
        runtime_label: machine.runtime?.label || 'Sem confirmação recente', bootstrap_label: machine.bootstrap?.label || 'Sem confirmação recente',
        error_label: machine.error_label || '',
      };
      Object.entries(values).forEach(([key, value]) => { changed = put(row, `[data-field="${key}"]`, value) || changed; });
      const jobLink = row.querySelector('[data-job-link]');
      if (jobLink) {
        const id = Number(machine.rollout_id);
        jobLink.hidden = !(Number.isInteger(id) && id > 0 && id <= 4294967295);
        if (!jobLink.hidden) {
          const url = new URL(consoleRoot.dataset.receiptUrl, location.href); url.searchParams.set('view', 'jobs'); url.searchParams.set('rollout_id', String(id));
          jobLink.href = url.href; put(jobLink, '[data-field="rollout_id"]', `#${id}`);
        }
      }
      if (['queued', 'waiting', 'pending', 'started', 'unknown'].includes(machine.assignment_status) || ['queued', 'waiting'].includes(machine.effective_status)) active = true;
    });
    const jobs = [...(snapshot.jobs || []), ...(snapshot.job ? [snapshot.job] : [])];
    jobs.forEach(job => { renderJob(job); if ((['queued', 'running', 'active', 'waiting'].includes(job.status) && Number(job.paused) !== 1) || ['pending', 'started', 'unknown'].some(status => Number(job.counts?.[status]) > 0)) active = true; });
    const dispatchState = document.getElementById('fleet-dispatch-state');
    if (dispatchState && snapshot.dispatch) dispatchState.textContent = `Limite global: ${Number(snapshot.dispatch.active_limit)} operações autorizadas. Estado: ${Number(snapshot.dispatch.paused) === 1 ? 'Pausado' : 'Permitido'}.`;
    if (changed) { relist.hidden = false; detailText.textContent = 'Informações atualizadas. As linhas permanecem na mesma posição; reaplique os filtros para recalcular a lista.'; }
    lastCheck.textContent = `${snapshot.checked_at} UTC`; lastCheck.dateTime = String(snapshot.checked_at);
  }
  function schedule() {
    clearTimeout(timer);
    if (stopped || document.hidden) return;
    const base = failures ? Math.min(300000, 15000 * 2 ** Math.min(failures - 1, 5)) : (active ? 12000 : 60000);
    timer = setTimeout(poll, Math.round(base * (1 + Math.random() * 0.2)));
  }
  function stopForSession() {
    stopped = true; clearTimeout(timer);
    stateText.textContent = 'Atualização automática interrompida: sessão expirada ou permissão indisponível.';
    detailText.textContent = 'Entre novamente no GLPI e reabra esta página. Os últimos dados confirmados foram mantidos; nenhuma operação foi repetida.';
    refresh.disabled = true;
    document.querySelectorAll('#desktop-console form[method="post"] button').forEach(button => { button.disabled = true; });
  }
  async function poll() {
    if (stopped || document.hidden || inFlight) return;
    clearTimeout(timer); inFlight = true; refresh.disabled = true;
    const request = ++generation; controller = new AbortController();
    const timeout = setTimeout(() => controller?.abort(), 10000);
    try {
      const url = new URL(monitor.dataset.statusUrl, location.href);
      url.searchParams.set('ids', monitor.dataset.machineIds || '[]');
      const jobs = [...document.querySelectorAll('[data-job-row]')].map(row => Number(row.dataset.jobRow)).slice(0, 20);
      url.searchParams.set('job_ids', JSON.stringify(jobs));
      if (Number(monitor.dataset.jobId) > 0) { url.searchParams.set('rollout_id', monitor.dataset.jobId); url.searchParams.set('target_page', monitor.dataset.targetPage || '1'); }
      const response = await fetch(url.href, { method: 'GET', credentials: 'same-origin', headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' }, cache: 'no-store', signal: controller.signal });
      if (request !== generation || stopped || document.hidden) return;
      const contentType = response.headers.get('content-type') || '';
      if ([401, 403].includes(response.status) || response.redirected || (response.ok && !contentType.includes('application/json'))) { stopForSession(); return; }
      if (!response.ok || !contentType.includes('application/json')) throw new Error('Status unavailable');
      const snapshot = await response.json();
      if (request !== generation || stopped || document.hidden) return;
      if (!snapshot || !Array.isArray(snapshot.machines) || snapshot.machines.length > 100 || typeof snapshot.checked_at !== 'string'
          || (snapshot.jobs && (!Array.isArray(snapshot.jobs) || snapshot.jobs.length > 50)) || (snapshot.job?.targets && snapshot.job.targets.length > 100)) throw new Error('Invalid status');
      if (snapshot.can_update === false) {
        writeRevoked = true;
        document.querySelectorAll('#desktop-console form[method="post"] button').forEach(button => { button.disabled = true; });
        detailText.textContent = 'Acesso somente para consulta. Reabra a página após recuperar a permissão de alteração; nenhuma operação foi repetida.';
      }
      apply(snapshot); failures = 0;
      if (writeRevoked) detailText.textContent = 'Acesso somente para consulta. Reabra a página após recuperar a permissão de alteração; nenhuma operação foi repetida.';
      stateText.textContent = writeRevoked ? 'Atualização automática ativa — somente consulta' : active ? 'Atualização automática ativa' : 'Atualização automática ativa — intervalo ampliado sem trabalho pendente';
    } catch (_) {
      if (request === generation && !stopped && !document.hidden) {
        failures++;
        stateText.textContent = 'Dados possivelmente desatualizados — consulta indisponível.';
        detailText.textContent = 'Os últimos dados confirmados foram mantidos. A consulta será repetida com intervalo maior; nenhuma operação foi reenviada.';
      }
    } finally {
      clearTimeout(timeout); inFlight = false; controller = null;
      if (!stopped) refresh.disabled = false;
      if (request !== generation && !stopped && !document.hidden) poll(); else schedule();
    }
  }
  refresh.addEventListener('click', () => { failures = 0; poll(); });
  document.addEventListener('visibilitychange', () => {
    clearTimeout(timer);
    if (document.hidden) { generation++; controller?.abort(); stateText.textContent = 'Atualização automática pausada — aba oculta.'; }
    else if (!stopped) { stateText.textContent = 'Atualização automática retomando'; if (!inFlight) poll(); else schedule(); }
  });
  window.addEventListener('pagehide', () => { stopped = true; generation++; clearTimeout(timer); controller?.abort(); });
  poll();
})();
