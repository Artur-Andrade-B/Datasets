# GLPIChat 1.9.12-desktop25 / Windows 0.9.15

Atualização corretiva sem assinatura após o piloto Windows 0.9.14 funcional. Concluir esta instalação não certifica produção em toda a frota; assinatura e aceitação dos bytes finais permanecem etapas posteriores.

## Atualização do plugin

1. Faça backup do banco, da pasta do plugin e da chave protegida de assinatura do gerenciamento.
2. Substitua a pasta `glpichat` pelos arquivos de `glpichat-1.9.12-desktop25.zip` e execute a atualização normal no GLPI. **Não desinstale:** desinstalação remove dados.
3. Guarde backups fora do diretório de plugins, sem cópias antigas renomeadas dentro dele.
4. Confirme versão **1.9.12**, build **desktop25** e schema desktop **14**. Esta correção não acrescenta uma migração para instalações que já utilizam schema 14; instalações anteriores ainda precisam das migrações aditivas existentes. Credenciais, revogações e identificadores são preservados. Em migração a partir de versões legadas, preserve o fuso do GLPI/servidor durante a verificação dos vínculos.
5. Confirme **Estrutura desktop → Atualização registrada**, abra **Gerenciar versões e computadores Windows** com conta autorizada e valide acesso de um usuário existente antes de atribuir Windows 0.9.15.

Uma migração incompleta pode impedir autorização/envios com `schema_unavailable`. Corrija a causa e execute a atualização novamente. Não reduza o marcador do schema, apague vínculos ou reinstale o plugin para contornar o erro.

## Escolher o caminho Windows

| Situação | Pacote e ação |
| --- | --- |
| Instalação gerenciada saudável | Importe somente `GLPIChat-Desktop-0.9.15-release.zip`, inicialmente no piloto 0.9.14. |
| Computador novo ou GPO | Extraia `GLPIChat-Desktop-0.9.15-admin.zip` sozinho em pasta nova. Use `Deploy-Desktop.cmd` na inicialização do computador/SYSTEM com `deployment.json` automático protegido. |
| Recuperação necessária | Use `desktop/tools/Repair-DesktopRecovery.cmd` do admin extraído em pasta local nova, em console administrativo. Preserve evidências e autoridade de recuperação. |
| Fontes e testes | Use o complete.zip na estação de qualificação. Não importe esse ZIP como release. |

O Agent do ZIP gerenciado incorpora o Bootstrap correspondente. Não misture ZIPs, substitua EXEs isoladamente ou altere bytes mantendo a versão anterior. Observe a atualização com `Test-LiveUpdate.ps1` e caminho absoluto de `desktop/dist/0.9.15` em `-BinaryDirectory`; confirme componentes carregados e círculo visível.

## Conexão automática e esperas

Configure centralmente LDAP, sincronização, perfis, entidades e direitos. Um usuário AD ainda ausente no GLPI continua aguardando e repetindo a proposta, inclusive após reinício, sem limite total de tentativas. Não precisa visitar o GLPI no navegador, fornecer senha/token ou executar comandos. A conexão ocorre quando identidade e autorização estiverem disponíveis. Contas locais ou somente Entra não estão cobertas pelo fluxo automático AD.

Cada máquina possui registro próprio. O serviço deriva o usuário da sessão Windows; usuários A/B no mesmo computador e A em computadores simultâneos mantêm credenciais e trabalho separados. Não clone uma instalação registrada em imagens de máquinas. Revogação explícita continua exigindo liberação apropriada; uma interrupção normal de rede não revoga o usuário.

Restrinja o segredo de registro às contas dos computadores alvo e administradores, com escrita somente administrativa. Renove a exportação antes de prazo/cota; isso é manutenção central, sem participação do usuário. Registros com resultado ambíguo devem ser reconciliados com a prova original, não apagados.

Mensagens/uploads autenticados continuam usando cota atômica compartilhada por usuário: 30 operações por janela fixa de 60 s; bytes de uploads têm orçamento do maior entre 100 MiB e o máximo de um arquivo configurado. Autorizações novas recebem limites por máquina/SID antes de LDAP e limites separados para emissão de grants. Essas cotas são controles herdados e não foram ampliadas neste candidato. Consulte `releases/1.9.12-desktop25.md` para o escopo da correção. HTTP 429 indica espera; não é revogação. Repetições preservam UUID/proposta/arquivo. No navegador, três repetições automáticas de envio temporariamente limitado são seguidas de ação manual com conteúdo preservado.

Sessões de convidado exigem prova CSRF própria. Abas antigas válidas recuperam a prova de forma limitada; a sessão expirada continua indisponível. Recarregue uma aba se houver arquivos estáticos desatualizados após a implantação e valide envio único.

## Diagnóstico e aceitação

Confira separadamente Bootstrap, payload, broker, Widget carregado, registro da máquina e autorização de usuários novos. Serviço em execução não comprova círculo visível nem acesso de outra conta. O renderizador funcional permanece; valide logon/reinício, notificações, mensagens offline, botão da mensagem mais recente, anexos e rascunhos.

Use `Get-DesktopStatus.ps1` e `Test-LiveUpdate.ps1` em PowerShell administrativo. Não é necessário console de usuário comum. Não distribua tokens, configuração ou estado privado bruto. As instruções completas acompanham o admin/completo em `docs/WINDOWS0915_ACCEPTANCE_PT-BR.md`; os resultados executados ficam em VERIFICATION.md no completo.

O ambiente interno e a segregação de rede reduzem exposição. Ainda é necessário registrar propagação AD → GLPI, retirada de rede e contas reativadas: acesso/renovação existentes revalidam GLPI, sem consulta AD a cada requisição. O candidato preserva a política independente de publisher, pacing e limites de distribuição; sua homologação nativa e capacidade real continuam pendentes. A suspensão normal continua separada da aposentadoria permanente; não se impõe uma mudança global de URLs nesta versão. Testes portáteis não certificam Windows/GPO/AD, escala da frota ou Kaspersky.

`bin/audit-private-attachments.php` permanece somente leitura para uso administrativo. O ZIP do plugin contém runtime/documentação operacional; executáveis Windows e testes ficam separados.

## Operação do console

Use as áreas Computadores, Conexões de usuários, Operações em lote e Versões/implantação. Revise a prévia de alvos antes de confirmar. As ações retornam à página GET e o acompanhamento é somente leitura, inclusive para administradores READ. Dados sem nova confirmação permanecem visíveis com aviso; não repita uma operação para atualizar a tela.

A suspensão de gerenciamento não é bloqueio integral de chat. Reativar a instalação não libera vínculos individualmente bloqueados e não revive atualizações pendentes substituídas. Trabalho iniciado pode concluir localmente. Credencial de máquina possivelmente copiada exige substituição administrativa controlada.

Uma alteração administrativa posterior invalida a revisão da prévia. Campanhas de atualização aprovadas pertencem à organização e sobrevivem ao logout ou à mudança de perfil do criador. Novas alterações, pausas e cancelamentos exigem autoridade administrativa atual. Lotes de mudança de permissão continuam revalidando o responsável.


O contrato existente de solicitações de conciliação conserva capacidade até prova exata. Aposentadoria permanente é irreversível e exige contenção documentada; bloqueia a identidade antiga, sem declarar sucesso de atualização. O padrão de polling é 30 s em segundo plano, 5 s com chat aberto e reconciliação de resumos em 120 s, com jitter/esperas limitadas. Reservas de trabalho LDAP protegem consultas de enrollment. Estado protegido ilegível abre suporte visível e preserva arquivos; não o trate como conexão saudável. Consulte as notas desta versão para limites, testes e a sequência antes de 1.0.0.
