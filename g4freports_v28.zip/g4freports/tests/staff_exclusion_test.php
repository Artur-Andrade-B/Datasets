<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require dirname(__DIR__) . '/src/Ses/StaffRegister.php';

use GlpiPlugin\G4freports\Ses\StaffRegister as Staff;

$assertions = 0;
function verify(bool $condition, string $message): void
{
    global $assertions;
    $assertions++;
    if (!$condition) throw new RuntimeException($message);
}
function employee(string $id, array $changes = []): array
{
    return array_replace([
        'id' => $id, 'name' => 'Profissional ' . $id, 'profile' => 'Analista',
        'admission_date' => '2025-01-01', 'departure_date' => null,
        'departure_reason' => 'pending', 'monthly_value' => '1000.00',
    ], $changes);
}

foreach ([true, 1, '1'] as $value) {
    verify(Staff::isNotBilled(['billed' => $value]), 'Legacy checked mark must exclude, without inversion.');
    verify(Staff::isNotBilled(['not_billed' => $value]), 'Canonical checked mark must exclude.');
}
foreach ([false, 0, '0'] as $value) {
    verify(!Staff::isNotBilled(['billed' => $value]), 'Legacy unchecked mark must include.');
    verify(!Staff::isNotBilled(['not_billed' => $value]), 'Canonical unchecked mark must include.');
}
verify(!Staff::isNotBilled([]), 'Missing flag includes the record.');
verify(!Staff::isNotBilled(['billed' => true, 'not_billed' => false]), 'Canonical false wins over legacy true.');
verify(Staff::isNotBilled(['billed' => false, 'not_billed' => true]), 'Canonical true wins over legacy false.');
verify(!Staff::isNotBilled(['billed' => 'invalid ignored legacy', 'not_billed' => false]), 'Unused legacy field cannot override canonical field.');
foreach ([null, '', 'false', 'true', 2, -1, 0.0, [], new stdClass()] as $value) {
    foreach (['billed', 'not_billed'] as $key) {
        $rejected = false;
        try { Staff::isNotBilled([$key => $value]); }
        catch (InvalidArgumentException $expected) { $rejected = true; }
        verify($rejected, 'Ambiguous or invalid exclusion flag must not be cast to a boolean.');
    }
}

$legacy = [
    employee('checked', ['billed' => true]),
    employee('unchecked', ['billed' => false]),
    employee('missing'),
    employee('explicit', ['billed' => true, 'not_billed' => false]),
];
$normalized = Staff::rows($legacy);
$byId = array_column($normalized, null, 'id');
verify($byId['checked']['not_billed'] === true, 'Normalization preserves the original checked exclusion.');
verify($byId['unchecked']['not_billed'] === false && $byId['missing']['not_billed'] === false, 'Normalization includes unchecked and pre-flag records.');
verify($byId['explicit']['not_billed'] === false, 'Canonical precedence persists through normalization.');
foreach ($normalized as $row) verify(!array_key_exists('billed', $row), 'Normalized output must contain only canonical exclusion field.');
verify(Staff::rows($normalized) === $normalized, 'Normalization is idempotent.');
$roundTrip = $normalized;
for ($i = 0; $i < 5; $i++) {
    $roundTrip = Staff::rows(Staff::json($roundTrip));
    verify($roundTrip === $normalized, 'Repeated save/reload must not flip marks.');
}

// Synthetic regression case: checked, unclassified departures were wrongly
// treated as eligible; the historical unchecked active team was wrongly omitted.
$reported = [];
for ($i = 1; $i <= 80; $i++) $reported[] = employee('active' . $i, ['billed' => false]);
for ($i = 1; $i <= 9; $i++) $reported[] = employee('excluded' . $i, [
    'billed' => true, 'departure_date' => '2026-06-08', 'monthly_value' => '9999.00',
]);
$reported[] = employee('old', ['billed' => false, 'departure_date' => '2026-02-01']);
$reported[] = employee('old2', ['billed' => false, 'departure_date' => '2026-03-31']);
$june = Staff::summarize($reported, '2026-06');
verify(count($june['rows']) === 91, 'Historical roster retains every record.');
verify($june['active_total'] === 80 && $june['denominator'] === 80, 'All 80 unchecked active professionals count.');
verify($june['unbilled_total'] === 9 && $june['billed_total'] === 82, 'Eligibility summaries preserve original marks.');
verify($june['pending_departures'] === 0 && $june['pending_ids'] === [], 'Excluded pending departures cannot block INS10.');
verify($june['replacements'] === 0 && $june['numerator'] === 0 && $june['value'] === 0, 'No eligible substitutions yields zero turnover.');
verify($june['complete'] && $june['monthly_value_total'] === '80000.00', 'Eligible active value and completeness calculated independently.');
$savedReported = Staff::rows(Staff::json(Staff::rows($reported)));
verify(Staff::summarize($savedReported, '2026-06') === $june, 'Saved canonical register gives exactly the same report.');
foreach ($june['rows'] as $row) if ($row['not_billed']) {
    verify(!$row['relevant_month'] && !$row['active_at_month_end'] && !$row['departure_in_window'] && !$row['counted_replacement'], 'Excluded employment has no INS10 contribution flags.');
}

$historical = [
    employee('ongoing', ['not_billed' => false]),
    employee('leaves-july', ['not_billed' => false, 'departure_date' => '2026-07-15', 'departure_reason' => 'replacement']),
    employee('future-join', ['not_billed' => false, 'admission_date' => '2026-08-01']),
    employee('old-exit', ['not_billed' => false, 'departure_date' => '2026-03-31']),
    employee('excluded-active', ['not_billed' => true]),
    employee('excluded-replacement', ['not_billed' => true, 'departure_date' => '2026-06-15', 'departure_reason' => 'replacement']),
    employee('excluded-reduction', ['not_billed' => true, 'departure_date' => '2026-06-15', 'departure_reason' => 'contractor_reduction']),
    employee('excluded-other', ['not_billed' => true, 'departure_date' => '2026-06-15', 'departure_reason' => 'other']),
];
$june = Staff::summarize($historical, '2026-06');
verify($june['active_total'] === 2 && $june['replacements'] === 0 && $june['pending_departures'] === 0, 'June uses historical dates, excludes future joins and ignores old exits.');
verify($june['reductions'] === 0 && $june['other_departures'] === 0, 'Excluded departures never enter classification subtotals.');
verify($june['value'] === 0 && $june['monthly_value_total'] === '2000.00', 'June zero-turnover percentage and value remain valid.');
$july = Staff::summarize($historical, '2026-07');
verify($july['active_total'] === 1 && $july['replacements'] === 1 && $july['value'] === 100, 'July includes actual eligible exit under unchanged month-end convention.');
$august = Staff::summarize($historical, '2026-08');
verify($august['active_total'] === 2 && $august['replacements'] === 1 && $august['value'] === 50, 'August includes the later admission and its selected three-month window.');
$october = Staff::summarize($historical, '2026-10');
verify($october['active_total'] === 2 && $october['replacements'] === 0 && $october['value'] === 0, 'An exit outside the selected three-month window no longer counts.');

$withPending = $historical;
$withPending[] = employee('eligible-pending', ['not_billed' => false, 'departure_date' => '2026-06-10']);
$pending = Staff::summarize($withPending, '2026-06');
verify(!$pending['complete'] && $pending['pending_departures'] === 1 && $pending['pending_ids'] === ['eligible-pending'], 'A genuinely eligible unclassified departure retains the existing classification requirement.');
verify($pending['active_total'] === 2 && $pending['denominator'] === 2 && $pending['monthly_value_total'] === '2000.00', 'Unclassified departure never suppresses the independent active headcount and value.');
verify($pending['numerator'] === null && $pending['value'] === null, 'Unresolved eligible exit does not fabricate substitution results.');

echo "Staff exclusion checks passed: {$assertions} assertions; original marks preserved, idempotent persistence and historical INS10 calculation.\n";
