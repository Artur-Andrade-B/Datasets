<?php
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }

/** Synthetic INS10 presentation checks; no customer records or connection required. */
require dirname(__DIR__) . '/inc/autoload.php';

use GlpiPlugin\G4freports\Ses\DocxExporter;
use GlpiPlugin\G4freports\Ses\MetricEvidence;
use GlpiPlugin\G4freports\Ses\StaffRegister;
use GlpiPlugin\G4freports\Ses\XlsxExporter;

function billingPresentationVerify(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

$inputs = [];
// These are the original selections: legacy billed=true meant the user checked
// an EXCLUSION. The corrected exports must preserve that mark, never invert it.
$cases = [
    ['A', ['billed' => true], true],
    ['B', ['billed' => false], false],
    ['C', [], false],
    ['D', ['not_billed' => true], true],
    ['E', ['not_billed' => false], false],
    ['F', ['not_billed' => false, 'billed' => true], false],
    ['G', ['not_billed' => true, 'billed' => false], true],
];
foreach ($cases as [$name, $flags, $excluded]) {
    $inputs[] = [
        'id' => 'person-' . $name,
        'name' => $name,
        'profile' => 'Técnico',
        'admission_date' => '2026-01-01',
        'departure_date' => $excluded ? '2026-06-08' : '',
        'departure_reason' => 'pending',
        'monthly_value' => 100,
    ] + $flags;
}
$staff = StaffRegister::summarize($inputs, '2026-06');
billingPresentationVerify($staff['active_total'] === 4 && $staff['complete'] && $staff['pending_departures'] === 0,
    'Original checked exclusions cannot suppress the eligible headcount or cause pending departures');
$expectedMarks = ['Sim', 'Não', 'Não', 'Sim', 'Não', 'Não', 'Sim'];
$snapshot = ['period' => ['month' => '2026-06'], 'metrics' => [], 'tickets' => [], 'staff_register' => $staff];
$originalSnapshot = $snapshot;

$table = MetricEvidence::staffRegisterTable($snapshot);
billingPresentationVerify($table['headers'][10] === 'Não foi faturado?', 'Staff evidence uses the negative label');
billingPresentationVerify(array_column($table['rows'], 10) === $expectedMarks,
    'Exports retain original checkmarks and display canonical exclusions identically');
billingPresentationVerify(array_column(MetricEvidence::table($snapshot, 'INS10')['rows'], 0) === ['B', 'C', 'E', 'F'],
    'INS10 details contain only included professionals from the selected month');

// Also exercise the export fallback for legacy input without relying on the
// normalizer having renamed the field before presentation.
$legacySnapshot = $snapshot;
foreach ($legacySnapshot['staff_register']['rows'] as $index => &$row) {
    unset($row['not_billed'], $row['billed']);
    $row = array_merge($row, $cases[$index][1]);
}
unset($row);
billingPresentationVerify(array_column(MetricEvidence::staffRegisterTable($legacySnapshot)['rows'], 10) === $expectedMarks,
    'Legacy evidence flags preserve checked=excluded; missing flags include; canonical flags win');

$wordMethod = new ReflectionMethod(DocxExporter::class, 'staffRegister');
foreach ([$staff, $legacySnapshot['staff_register']] as $wordStaff) {
    $xml = $wordMethod->invoke(new DocxExporter(), $wordStaff);
    $document = new DOMDocument();
    billingPresentationVerify($document->loadXML('<root xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' . $xml . '</root>'),
        'Word staff section is well-formed XML');
    $xpath = new DOMXPath($document);
    $xpath->registerNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
    $tables = $xpath->query('//w:tbl');
    billingPresentationVerify($tables->length === 2, 'Word contains staff summary and full register');
    $staffRows = $xpath->query('./w:tr', $tables->item(1));
    billingPresentationVerify($staffRows->length === 10, 'Word keeps seven records and both totals');
    foreach (array_merge(['Não foi faturado?'], $expectedMarks, ['', 'Não']) as $index => $expected) {
        $cells = $xpath->query('./w:tc', $staffRows->item($index));
        billingPresentationVerify($cells->length === 6, 'Word staff row has six columns');
        billingPresentationVerify($cells->item(5)->textContent === $expected, 'Word negative billing flag at row ' . $index);
    }
}

$excel = new XlsxExporter();
$snapshotProperty = new ReflectionProperty(XlsxExporter::class, 'snapshot');
$snapshotProperty->setValue($excel, $snapshot);
$auditMethod = new ReflectionMethod(XlsxExporter::class, 'exclusionAudit');
$sheet = $auditMethod->invoke($excel);
$checkedFormulas = [];
foreach ($sheet['rows'] as $cells) {
    foreach ($cells as $cell) {
        $formula = $cell['formula'] ?? '';
        if (preg_match('/^(COUNTIFS|SUMIFS)\(/', $formula, $match) && str_contains($formula, '$K$')) {
            billingPresentationVerify(str_ends_with($formula, ',"Não")'), 'Excel negative billing criteria retain included records');
            billingPresentationVerify($cell['value'] === ($match[1] === 'COUNTIFS' ? 4 : 400.0),
                'Excel audit formula cache retains the included headcount or amount');
            $checkedFormulas[] = $match[1];
        }
    }
}
sort($checkedFormulas);
billingPresentationVerify($checkedFormulas === ['COUNTIFS', 'SUMIFS'], 'Headcount and amount formulas were both checked');

$foundStaffTable = false;
foreach ($sheet['tables'] as $excelTable) {
    if ($excelTable['name'] !== 'Cadastro_profissionais') {
        continue;
    }
    billingPresentationVerify(count($excelTable['headers']) === 13, 'All staff audit headers are retained');
    billingPresentationVerify(preg_match('/^A\d+:M\d+$/', $excelTable['ref']) === 1,
        'Staff audit table and filter range span all thirteen columns');
    $foundStaffTable = true;
}
billingPresentationVerify($foundStaffTable, 'Excel staff audit table was generated');
billingPresentationVerify($snapshot === $originalSnapshot, 'Export presentation does not mutate persisted billing semantics');

echo "Billing presentation checks passed: original exclusions, canonical flags, included cohort, Word details/totals, Excel formula criteria and thirteen-column staff table.\n";
