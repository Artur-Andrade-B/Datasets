# GLPIChat 1.9.5-desktop18 / Windows 0.9.5

Esta versão corrige recuperação e acompanhamento de atualização Windows. O pacote Windows continua sem assinatura Authenticode; a versão 1.0.0 será promovida após a validação no ambiente e a assinatura dos bytes finais.

## Atualização do plugin

1. Faça backup do banco e da pasta atual do plugin.
2. Substitua a pasta `glpichat` pelos arquivos de `glpichat-1.9.5-desktop18.zip` e execute a atualização normal no GLPI. Não desinstale: a desinstalação remove dados.
3. Guarde o backup fora da pasta de plugins; não mantenha cópias antigas renomeadas nesse diretório.
4. Confirme versão 1.9.5, build desktop18 e esquema Desktop 9. Instalações já no esquema 9 o conservam; instalações anteriores seguem a migração existente, que preenche somente vínculos de máquina comprováveis.
5. Abra a configuração Desktop e confirme **Estrutura desktop → Atualização registrada**. Depois abra **Gerenciar versões e computadores Windows** com uma conta autorizada. A visão de solicitações inclui **Ver detalhes por computador**. Não reduza o marcador de esquema para recuperar controles.

Use o ZIP do plugin somente no GLPI. A atualização preserva a correção anterior da página de gerenciamento e não introduz migração de banco nem alteração da autorização LDAP. Os rótulos de erro novos explicam adiamento por recuperação e rollback de tentativa interrompida. Um rollback concluído não identifica, por si só, a causa da interrupção original.

## Escolher o caminho Windows

| Situação | Pacote e ação |
| --- | --- |
| Máquina afetada, ainda em 0.9.3 com Bootstrap antigo e recuperação retida | Extraia o pacote **admin 0.9.5** localmente e execute `desktop/tools/Repair-DesktopRecovery.cmd` em console administrativo. Ele usa tarefa SYSTEM, termina a recuperação do Bootstrap e depois solicita a atualização local normal. |
| Computador novo ou implantação por GPO | Use o pacote **admin 0.9.5** completo, `Deploy-Desktop.cmd` em inicialização do computador/SYSTEM e `deployment.json` automático protegido. |
| Frota gerenciada saudável | Importe somente `GLPIChat-Desktop-0.9.5-release.zip`, contendo Agent, Widget e `release.json`, e atribua primeiro a um piloto. |

O Bootstrap está incorporado no Agent do ZIP gerenciado. Não importe o pacote administrativo ou de fontes como release. Não substitua bytes de um release antigo mantendo a versão original. Preserve credenciais, rascunhos, filas e arquivos de recuperação. O [roteiro desktop18](releases/1.9.5-desktop18.md) descreve o escopo e a aceitação; instruções completas de recuperação/GPO acompanham o pacote administrativo.

## Conexão automática

Configure centralmente LDAP, sincronização de usuários, perfis, entidades e direitos de chat. A conta precisa existir e estar autorizada no GLPI. O usuário final não precisa visitar previamente o GLPI, fornecer senha/token, parear uma conta ou executar comandos.

Cada computador possui registro próprio. O serviço local verifica o usuário real da sessão Windows e solicita autorização automaticamente. Usuários diferentes no mesmo computador mantêm credenciais e trabalho separados; o mesmo usuário pode se conectar em computadores diferentes simultaneamente. Não clone estado já registrado em imagens de máquinas.

O arquivo de implantação contém um segredo de registro. Restrinja a leitura às contas dos computadores alvo e aos administradores, com escrita somente administrativa. Não o coloque em compartilhamento legível por todos. Revogação administrativa permanece válida até liberação explícita do vínculo correto no GLPI.

## Diagnóstico e aceitação

Confira separadamente Bootstrap, payload, broker, versão do Widget carregado, registro da máquina e conexão de usuários novos. Um serviço em execução ou uma conta com credencial antiga funcionando não comprova a conexão automática de outro usuário. O coletor administrativo exporta campos permitidos e evidência limitada; não distribua configuração, tokens ou estado privado bruto.

O desenho do Widget permanece o de 0.9.4. O círculo deve aparecer na sessão antes de clicar na bandeja ou receber mensagem, inclusive com zero não lidas. As 268 verificações anteriores do Diagnostic2 validaram um lançador isolado; não estabeleceram que a atualização estava instalada. A instalação afetada ainda carregava 0.9.3. A causa da interrupção original continua desconhecida.

Antes de ampliar o lote, valide recuperação real, reinício/logon, Windows 10/11, GPO, múltiplos usuários/computadores, escalas e monitores do ambiente. Confira mensagens/anexos, rascunhos, filas, leitura e navegação pela notificação. O defeito separado de serialização do checkpoint agregado de notificações continua aberto. Resultados portáteis não substituem essa aceitação nem comprovam liberação pelo Kaspersky.

O utilitário `bin/audit-private-attachments.php` continua somente leitura e deve ser usado no contexto administrativo do GLPI antes de reconciliação manual de associações antigas. O ZIP do plugin contém execução e documentação operacional; fontes Windows, testes e relatórios históricos ficam no pacote de fontes.
