# GLPI Chat — 1.9.5-desktop18

Chat contextual dos chamados do GLPI, com cliente Windows 0.9.5 e conexão automática gerenciada pela empresa.

Esta atualização corrige a recuperação do Bootstrap antigo e a conclusão das leituras assíncronas de saúde, impede nova ativação durante manutenção pendente e preserva evidências separadas de falha e rollback. A página Windows oferece acesso mais claro aos detalhes por computador e explicações para os novos códigos. Permissões, matrícula e esquema 9 são preservados.

O desenho do lançador conserva a correção de 0.9.4. As 268 verificações nativas anteriores pertencem ao teste isolado do candidato; não comprovam a instalação nem a recuperação de 0.9.5. Recuperação instalada, demais telas/escalas, GPO e política do Kaspersky ainda exigem qualificação. O cliente continua sem assinatura Authenticode. Windows 1.0.0 permanece reservado para a promoção assinada posterior. A falha separada de serialização do checkpoint agregado de notificações continua pendente.

Leia [a instalação](docs/INSTALLATION_PT-BR.md) e [as notas de desktop18](docs/releases/1.9.5-desktop18.md). Use o ZIP do plugin no GLPI e o ZIP Windows de release no gerenciamento de versões. A máquina com recuperação antiga pendente deve usar primeiro o reparo do pacote administrativo completo. Preserve estado, credenciais e pacotes anteriores; atualize sem desinstalar.
