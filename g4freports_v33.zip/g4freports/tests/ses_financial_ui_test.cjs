const assert = require('assert');
const fs = require('fs');
const vm = require('vm');
const path = require('path');
class Element {
  constructor(tag='div'){this.tagName=tag;this.children=[];this.events={};this.value='';this.disabled=false;this.textContent='';}
  appendChild(child){this.children.push(child);child.parent=this;return child}
  removeChild(child){this.children.splice(this.children.indexOf(child),1)}
  get firstChild(){return this.children[0]||null}
  setAttribute(k,v){this[k]=v}
  addEventListener(name,fn){this.events[name]=fn}
  querySelectorAll(){return all.filter(x=>['input','textarea','button'].includes(x.tagName))}
  reportValidity(){return true}
}
const all=[],els={};
const ids=['ses-financial-state','ses-financial-fronts','ses-financial-fronts-empty','ses-financial-month','ses-financial-deductions','ses-financial-adjustments','ses-financial-adjustments-empty','ses-save-financial','ses-financial-preview','g4fr-ses-financial-form','ses-add-front','ses-add-adjustment'];
ids.forEach(id=>{els[id]=new Element();els[id].id=id;all.push(els[id])});
let month='2026-06',busy=false,dirty=false,saved=0,captured,status,failNext=false;
const config={can_configure:true,financial_config:{contract_fronts:[],months:{}},financial_revision:'r1',csrf_token:'csrf1',nonce:'nonce',financial_url:'/save'};
const context={window:{crypto:require('crypto').webcrypto,confirm:()=>true},document:{getElementById:id=>els[id],createElement:tag=>{const e=new Element(tag);all.push(e);return e}},Intl,AbortController,URLSearchParams,setTimeout,clearTimeout,fetch:async(url,req)=>{captured=Object.fromEntries(req.body);if(failNext){failNext=false;return {ok:false,status:409,text:async()=>JSON.stringify({ok:false,error:'Conflito de versão',csrf_token:'csrf3'})}}return {ok:true,status:200,text:async()=>JSON.stringify({ok:true,config:JSON.parse(captured.config),revision:'r2',csrf_token:'csrf2'})}}};
vm.createContext(context);vm.runInContext(fs.readFileSync(path.join(__dirname, '../assets/js/ses_financial.js'),'utf8'),context);
const editor=context.window.G4FSesFinancial.create({config,month:()=>month,isBusy:()=>busy,setBusy:v=>{busy=v;editor.setBusy(v)},onDirty:v=>dirty=v,onSaved:()=>saved++,status:message=>status=message});
function change(element,value){element.value=value;element.events.input()}
function deduction(index){const row=els['ses-financial-deductions'].children[index-1];return {rate:row.children[1].firstChild,reason:row.children[2].firstChild}}
(async()=>{
  assert.equal(els['ses-financial-deductions'].children.length,12);
  let ins3=deduction(3);change(ins3.rate,'0');change(ins3.reason,'Ajuste aprovado pelo cliente');
  assert(dirty);assert(ins3.reason.required);
  els['ses-add-adjustment'].events.click();let adj=els['ses-financial-adjustments'].children[0];change(adj.children[0].firstChild,'Crédito do período anterior');change(adj.children[1].firstChild,'125,50');
  month='2026-07';editor.renderMonth();assert.equal(deduction(3).rate.value,'');
  change(deduction(5).rate,'1');change(deduction(5).reason,'Ajuste aprovado em julho');
  month='2026-06';editor.renderMonth();assert.equal(deduction(3).rate.value,'0');assert.equal(els['ses-financial-adjustments'].children[0].children[1].firstChild.value,'125,50');
  await els['g4fr-ses-financial-form'].events.submit({preventDefault(){},currentTarget:els['g4fr-ses-financial-form']});
  let sent=JSON.parse(captured.config);assert.equal(sent.months['2026-06'].deduction_overrides.INS3.rate,0);assert.equal(sent.months['2026-07'].deduction_overrides.INS5.rate,1);assert.equal(sent.months['2026-06'].adjustments[0].amount,'125,50');assert(!dirty);assert.equal(saved,1);assert.equal(config.csrf_token,'csrf2');assert.equal(captured.revision,'r1');
  change(deduction(3).rate,'');await els['g4fr-ses-financial-form'].events.submit({preventDefault(){},currentTarget:els['g4fr-ses-financial-form']});sent=JSON.parse(captured.config);assert(!('INS3' in sent.months['2026-06'].deduction_overrides));assert.equal(sent.months['2026-07'].deduction_overrides.INS5.rate,1);
  month='2026-08';editor.renderMonth();change(deduction(1).rate,'0');month='2026-06';editor.renderMonth();const prior=captured.config;await els['g4fr-ses-financial-form'].events.submit({preventDefault(){},currentTarget:els['g4fr-ses-financial-form']});assert.equal(captured.config,prior);assert(status.includes('2026-08'));assert(dirty);
  month='2026-08';editor.renderMonth();change(deduction(1).reason,'Ajuste autorizado');failNext=true;await els['g4fr-ses-financial-form'].events.submit({preventDefault(){},currentTarget:els['g4fr-ses-financial-form']});assert(dirty);assert.equal(deduction(1).rate.value,'0');assert.equal(config.csrf_token,'csrf3');assert.equal(status,'Conflito de versão');
  editor.renderPreview({complete:false,gross_value:'100.00',deduction_total:'0.00',adjustment_total:'0.00',net_value:'100.00'});assert(els['ses-financial-preview'].children[0].textContent.includes('parciais'));
  process.stdout.write('Financial UI smoke: monthly preservation, zero override, reset, adjustment persistence, hidden-month validation and confirmed-save dirty state passed.\n');
})().catch(error=>{process.stderr.write(error.stack+'\n');process.exit(1)});
