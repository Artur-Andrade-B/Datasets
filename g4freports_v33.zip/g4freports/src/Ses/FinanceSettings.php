<?php

namespace GlpiPlugin\G4freports\Ses;

/** Durable contractual baseline and explicitly entered monthly financial decisions. */
final class FinanceSettings
{
    public const CONFIG_KEY = 'ses_financial_json';

    public static function fromSettings(array $settings): array
    {
        return self::normalize($settings[self::CONFIG_KEY] ?? '{}');
    }

    public static function normalize($raw): array
    {
        if (is_string($raw)) {
            if (strlen($raw) > 60000 || substr(ltrim($raw), 0, 1) !== '{') {
                throw new \InvalidArgumentException('A configuração financeira deve ser um objeto JSON de até 60.000 bytes.');
            }
            $raw = json_decode($raw, true);
            if (json_last_error() !== JSON_ERROR_NONE) throw new \InvalidArgumentException('Configuração financeira inválida.');
        }
        if (!is_array($raw)) throw new \InvalidArgumentException('Configuração financeira inválida.');
        $fronts = $raw['contract_fronts'] ?? [];
        $months = $raw['months'] ?? [];
        if (!is_array($fronts) || !self::isList($fronts) || count($fronts) > 50 || !is_array($months) || count($months) > 240) {
            throw new \InvalidArgumentException('Informe até 50 frentes e 240 competências na configuração financeira.');
        }
        $result = ['contract_fronts' => [], 'months' => []];
        $ids = $profiles = [];
        foreach ($fronts as $row) {
            if (!is_array($row)) throw new \InvalidArgumentException('Frente contratual inválida.');
            $id = self::text($row['id'] ?? '', 64, 'Identificador da frente');
            if (!preg_match('/\A[A-Za-z0-9_-]{1,64}\z/D', $id) || isset($ids[$id])) throw new \InvalidArgumentException('Identificador da frente inválido ou duplicado.');
            $ids[$id] = true;
            $quantity = $row['contract_quantity'] ?? 0;
            if (!self::integer($quantity) || (int)$quantity > 10000) throw new \InvalidArgumentException('Quantidade contratada inválida.');
            $mapped = $row['profiles'] ?? [];
            if (!is_array($mapped) || !self::isList($mapped) || count($mapped) > 100) throw new \InvalidArgumentException('Perfis da frente inválidos.');
            $list = [];
            foreach ($mapped as $profile) {
                $profile = self::text($profile, 300, 'Perfil profissional');
                $key = self::profileKey($profile);
                if (isset($profiles[$key])) throw new \InvalidArgumentException('O perfil ' . $profile . ' está associado a mais de uma frente.');
                $profiles[$key] = true;
                $list[] = $profile;
            }
            $result['contract_fronts'][] = ['id' => $id, 'label' => self::text($row['label'] ?? '', 240, 'Frente de serviço'),
                'profiles' => $list, 'contract_quantity' => (int)$quantity,
                'monthly_rate' => self::money($row['monthly_rate'] ?? '0', false)];
        }
        foreach ($months as $month => $row) {
            if (!is_string($month) || !preg_match('/\A(20\d{2}|2100)-(0[1-9]|1[0-2])\z/D', $month) || !is_array($row)) {
                throw new \InvalidArgumentException('Competência financeira inválida.');
            }
            $overrides = $row['deduction_overrides'] ?? [];
            $adjustments = $row['adjustments'] ?? [];
            if (!is_array($overrides) || !is_array($adjustments) || !self::isList($adjustments) || count($adjustments) > 100) {
                throw new \InvalidArgumentException('Ajustes financeiros inválidos na competência ' . $month . '.');
            }
            $normalized = ['deduction_overrides' => [], 'adjustments' => []];
            foreach ($overrides as $id => $override) {
                if (!preg_match('/\AINS([1-9]|1[0-2])\z/D', (string)$id) || !is_array($override)) throw new \InvalidArgumentException('Indicador financeiro inválido.');
                $rate = $override['rate'] ?? null;
                if ($rate === '' || $rate === null) continue;
                if (!is_scalar($rate) || is_bool($rate) || !preg_match('/\A\d+(?:[.,]\d{1,2})?\z/D', (string)$rate)) {
                    throw new \InvalidArgumentException($id . ': informe uma glosa de 0 a 4%.');
                }
                $rate = (float)str_replace(',', '.', (string)$rate);
                if ($rate > 4) throw new \InvalidArgumentException($id . ': informe uma glosa de 0 a 4%.');
                $normalized['deduction_overrides'][$id] = ['rate' => $rate,
                    'justification' => self::text($override['justification'] ?? '', 2000, $id . ': justificativa do ajuste financeiro aprovado')];
            }
            ksort($normalized['deduction_overrides'], SORT_NATURAL);
            foreach ($adjustments as $adjustment) {
                if (!is_array($adjustment)) throw new \InvalidArgumentException('Ajuste financeiro inválido.');
                $normalized['adjustments'][] = ['description' => self::text($adjustment['description'] ?? '', 1000, 'Descrição do ajuste'),
                    'amount' => self::money($adjustment['amount'] ?? '', true)];
            }
            if ($normalized['deduction_overrides'] || $normalized['adjustments']) $result['months'][$month] = $normalized;
        }
        ksort($result['months']);
        if (strlen(self::json($result)) > 60000) throw new \InvalidArgumentException('A configuração financeira excede 60.000 bytes.');
        return $result;
    }

    public static function json(array $config): string
    {
        // Empty month/override collections are objects, also after a browser round trip.
        $config['months'] = (object)($config['months'] ?? []);
        return json_encode($config, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    }

    public static function revision(array $config): string { return hash('sha256', self::json($config)); }

    public static function profileKey(string $profile): string
    {
        return mb_strtolower(trim(preg_replace('/\s+/u', ' ', $profile)), 'UTF-8');
    }

    public static function cents($value): int
    {
        return (int)str_replace('.', '', self::money($value, true));
    }

    public static function amount(int $cents): string { return number_format($cents / 100, 2, '.', ''); }

    public static function money($value, bool $signed): string
    {
        if (!is_scalar($value) || is_bool($value)) throw new \InvalidArgumentException('Valor financeiro inválido.');
        $value = trim((string)$value);
        $value = preg_replace('/\AR\$\s*/u', '', $value);
        // Accept the same Brazilian formatting as the personnel register.
        if (strpos($value, ',') !== false) {
            if (!preg_match('/\A-?(?:\d+|\d{1,3}(?:\.\d{3})+),\d{1,2}\z/D', $value)) {
                throw new \InvalidArgumentException('Formato monetário inválido.');
            }
            $value = str_replace(['.', ','], ['', '.'], $value);
        }
        $pattern = $signed ? '/\A-?\d{1,9}(?:\.\d{1,2})?\z/D' : '/\A\d{1,9}(?:\.\d{1,2})?\z/D';
        if (!preg_match($pattern, $value)) throw new \InvalidArgumentException('Informe um valor financeiro com até duas casas decimais.');
        return number_format((float)$value, 2, '.', '');
    }

    private static function integer($value): bool
    {
        return (is_int($value) && $value >= 0) || (is_string($value) && preg_match('/\A\d+\z/D', $value));
    }

    private static function isList(array $value): bool
    {
        return !$value || array_keys($value) === range(0, count($value) - 1);
    }

    private static function text($value, int $limit, string $label): string
    {
        if (!is_string($value) || mb_strlen(trim($value), 'UTF-8') > $limit || trim($value) === '') {
            throw new \InvalidArgumentException($label . ': preenchimento obrigatório, até ' . $limit . ' caracteres.');
        }
        return trim(preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $value));
    }
}
