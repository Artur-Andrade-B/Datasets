(function (root) {
  'use strict';
  // Month-specific edits stay in this backing object when the selected month changes.
  // Rendering and filtering never decide which records are sent to the server.
  function create(options) {
    var config = options.config, canEdit = !!config.can_configure;
    var data = copy(config.financial_config || {}), dirty = false;
    var money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
    data.contract_fronts = Array.isArray(data.contract_fronts) ? data.contract_fronts : [];
    data.months = object(data.months);
    function el(id) { return document.getElementById(id); }
    function node(tag, className, text) { var item = document.createElement(tag); if (className) item.className = className; if (text !== undefined) item.textContent = String(text); return item; }
    function clear(item) { while (item.firstChild) item.removeChild(item.firstChild); }
    function copy(value) { return JSON.parse(JSON.stringify(value)); }
    function object(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : {}; }
    function validMonth(value) { return /^(20\d{2}|2100)-(0[1-9]|1[0-2])$/.test(value); }
    function currentMonth() { return options.month(); }
    function monthData(month) {
      if (!data.months[month]) data.months[month] = { deduction_overrides: {}, adjustments: [] };
      var result = data.months[month];
      result.deduction_overrides = object(result.deduction_overrides);
      result.adjustments = Array.isArray(result.adjustments) ? result.adjustments : [];
      return result;
    }
    function markDirty() {
      dirty = true;
      if (el('ses-financial-state')) el('ses-financial-state').textContent = 'Há alterações não salvas. A troca de mês preserva os ajustes em edição. Salve antes de gerar o relatório.';
      options.onDirty(true);
    }
    function makeField(row, key, label, type, changed) {
      var td = node('td');
      if (!canEdit) { td.textContent = Array.isArray(row[key]) ? row[key].join('; ') : String(row[key] === undefined ? '' : row[key]); return td; }
      var input = node(type === 'textarea' ? 'textarea' : 'input', 'form-control');
      if (type !== 'textarea') input.type = type || 'text'; else input.rows = 2;
      input.value = Array.isArray(row[key]) ? row[key].join('; ') : (row[key] === null || row[key] === undefined ? '' : row[key]);
      input.setAttribute('aria-label', label);
      input.addEventListener('input', function () { changed(input.value, input); markDirty(); });
      td.appendChild(input); return td;
    }
    function removeCell(action, label) {
      var td = node('td'), button = node('button', 'btn btn-outline-danger btn-sm', 'Remover'); button.type = 'button';
      button.setAttribute('aria-label', label); button.addEventListener('click', action); td.appendChild(button); return td;
    }
    function renderFronts() {
      var body = el('ses-financial-fronts'); clear(body);
      data.contract_fronts.forEach(function (front) {
        var tr = node('tr');
        var label = makeField(front, 'label', 'Frente de serviço', 'text', function (value) { front.label = value; });
        if (canEdit) { label.firstChild.maxLength = 180; label.firstChild.required = true; }
        tr.appendChild(label);
        tr.appendChild(makeField(front, 'profiles', 'Perfis profissionais associados à frente', 'textarea', function (value) { front.profiles = value.split(';').map(function (part) { return part.trim(); }).filter(Boolean); }));
        var quantity = makeField(front, 'contract_quantity', 'Quantidade contratual', 'number', function (value) { front.contract_quantity = value; });
        if (canEdit) { quantity.firstChild.min = '0'; quantity.firstChild.max = '10000'; quantity.firstChild.step = '1'; quantity.firstChild.required = true; }
        tr.appendChild(quantity);
        var rate = makeField(front, 'monthly_rate', 'Valor mensal unitário da frente', 'text', function (value) { front.monthly_rate = value; });
        if (canEdit) { rate.firstChild.inputMode = 'decimal'; rate.firstChild.required = true; rate.firstChild.placeholder = '0,00'; }
        tr.appendChild(rate);
        if (canEdit) tr.appendChild(removeCell(function () {
          if (!window.confirm('Remover a frente “' + (front.label || 'Sem nome') + '”? A alteração será confirmada ao salvar.')) return;
          data.contract_fronts = data.contract_fronts.filter(function (item) { return item !== front; }); markDirty(); renderFronts();
        }, 'Remover frente ' + (front.label || 'Sem nome')));
        body.appendChild(tr);
      });
      el('ses-financial-fronts-empty').hidden = data.contract_fronts.length > 0;
      setBusy(options.isBusy());
    }
    function renderMonth() {
      var month = currentMonth(), valid = validMonth(month);
      el('ses-financial-month').textContent = valid ? 'Ajustes financeiros de ' + month.slice(5) + '/' + month.slice(0, 4) + '. Os demais meses são preservados.' : 'Selecione um mês válido para consultar ou editar seus ajustes.';
      var deductions = el('ses-financial-deductions'), adjustments = el('ses-financial-adjustments'); clear(deductions); clear(adjustments);
      if (!valid) { el('ses-financial-adjustments-empty').hidden = false; setBusy(options.isBusy()); return; }
      var entry = monthData(month);
      for (var index = 1; index <= 12; index++) {
        (function (id) {
          var tr = node('tr'), override = entry.deduction_overrides[id] || { rate: '', justification: '' };
          tr.appendChild(node('td', '', id));
          var rate = makeField(override, 'rate', id + ' · taxa aplicada em ' + month, 'number', function (value) { override.rate = value; entry.deduction_overrides[id] = override; updateJustification(); });
          var justification = makeField(override, 'justification', id + ' · justificativa do ajuste em ' + month, 'textarea', function (value) { override.justification = value; entry.deduction_overrides[id] = override; });
          function updateJustification() { if (canEdit) justification.firstChild.required = override.rate !== '' && override.rate !== null && override.rate !== undefined; }
          if (canEdit) {
            rate.firstChild.min = '0'; rate.firstChild.max = '4'; rate.firstChild.step = '0.01'; rate.firstChild.placeholder = 'Automática';
            justification.firstChild.maxLength = 2000; justification.firstChild.placeholder = 'Preencha somente para um ajuste aprovado'; updateJustification();
          } else if (override.rate === '' || override.rate === null || override.rate === undefined) rate.textContent = 'Automática';
          tr.appendChild(rate); tr.appendChild(justification); deductions.appendChild(tr);
        })('INS' + index);
      }
      entry.adjustments.forEach(function (adjustment) {
        var tr = node('tr');
        var description = makeField(adjustment, 'description', 'Descrição do ajuste em ' + month, 'textarea', function (value) { adjustment.description = value; });
        var amount = makeField(adjustment, 'amount', 'Valor do ajuste em ' + month, 'text', function (value) { adjustment.amount = value; });
        if (canEdit) { description.firstChild.required = true; description.firstChild.maxLength = 1000; amount.firstChild.required = true; amount.firstChild.inputMode = 'decimal'; amount.firstChild.placeholder = 'Ex.: -150,00 ou 150,00'; }
        tr.appendChild(description); tr.appendChild(amount);
        if (canEdit) tr.appendChild(removeCell(function () { entry.adjustments = entry.adjustments.filter(function (item) { return item !== adjustment; }); markDirty(); renderMonth(); }, 'Remover ajuste ' + (adjustment.description || 'sem descrição')));
        adjustments.appendChild(tr);
      });
      el('ses-financial-adjustments-empty').hidden = entry.adjustments.length > 0;
      setBusy(options.isBusy());
    }
    function preparedData() {
      var result = copy(data), cleaned = {};
      result.contract_fronts.forEach(function (front) {
        if (!String(front.label || '').trim()) throw new Error('Informe o nome de cada frente de serviço.');
        if (!/^\d+$/.test(String(front.contract_quantity))) throw new Error('Informe uma quantidade contratual inteira e não negativa para ' + front.label + '.');
        front.contract_quantity = Number(front.contract_quantity);
      });
      Object.keys(result.months).forEach(function (month) {
        var entry = result.months[month], overrides = {};
        Object.keys(entry.deduction_overrides || {}).forEach(function (id) {
          var override = entry.deduction_overrides[id];
          if (override.rate === '' || override.rate === null || override.rate === undefined) return;
          var rate = Number(override.rate);
          if (!Number.isFinite(rate) || rate < 0 || rate > 4) throw new Error('A taxa de ' + id + ' em ' + month + ' deve estar entre 0% e 4%.');
          if (!String(override.justification || '').trim()) throw new Error('Informe a justificativa do ajuste aprovado de ' + id + ' em ' + month + '.');
          overrides[id] = { rate: rate, justification: String(override.justification).trim() };
        });
        (entry.adjustments || []).forEach(function (adjustment) {
          if (!String(adjustment.description || '').trim() || !String(adjustment.amount === undefined ? '' : adjustment.amount).trim()) throw new Error('Preencha a descrição e o valor de todos os ajustes de ' + month + ', ou remova a linha vazia.');
        });
        if (Object.keys(overrides).length || (entry.adjustments || []).length) cleaned[month] = { deduction_overrides: overrides, adjustments: entry.adjustments || [] };
      });
      result.months = cleaned;
      return result;
    }
    async function save(event) {
      event.preventDefault();
      if (options.isBusy() || !event.currentTarget.reportValidity()) return;
      var payload;
      try { payload = preparedData(); } catch (error) { options.status(error.message, 'error'); return; }
      var controller = new AbortController(), timer = setTimeout(function () { controller.abort(); }, 30000);
      var body = new URLSearchParams(); body.set('action', 'save'); body.set('config', JSON.stringify(payload)); body.set('revision', config.financial_revision || ''); body.set('_ses_nonce', config.nonce); body.set('_glpi_csrf_token', config.csrf_token || '');
      options.setBusy(true); options.status('Salvando a composição contratual e os ajustes de todos os meses…', '', true);
      try {
        var response = await fetch(config.financial_url, { method: 'POST', credentials: 'same-origin', cache: 'no-store', body: body, headers: { Accept: 'application/json' }, signal: controller.signal });
        var text = await response.text(), result;
        try { result = JSON.parse(text); } catch (error) { throw new Error('O GLPI não confirmou o salvamento (HTTP ' + response.status + '). Seus ajustes continuam nesta tela.'); }
        if (result.csrf_token) config.csrf_token = result.csrf_token;
        if (!response.ok || !result.ok) throw new Error(result.error || 'Não foi possível salvar os ajustes.');
        if (!result.config || !result.revision) throw new Error('A confirmação está incompleta. Confira a configuração salva antes de tentar novamente.');
        data = copy(result.config); data.contract_fronts = data.contract_fronts || []; data.months = object(data.months);
        config.financial_config = copy(data); config.financial_revision = result.revision; dirty = false;
        options.onDirty(false); options.onSaved(); renderFronts(); renderMonth();
        el('ses-financial-state').textContent = 'Composição e ajustes salvos. Gere novamente para aplicá-los aos relatórios.';
        options.status('Composição contratual e ajustes financeiros salvos e conferidos.', 'success');
      } catch (error) {
        options.status(error.name === 'AbortError' ? 'O servidor não confirmou o salvamento em 30 segundos. Seus ajustes continuam nesta tela; confira a configuração salva antes de tentar novamente.' : error.message, 'error');
      } finally { clearTimeout(timer); options.setBusy(false); }
    }
    function setBusy(busy) {
      var form = el('g4fr-ses-financial-form'); if (!form) return;
      Array.prototype.forEach.call(form.querySelectorAll('input:not([type="hidden"]),textarea,button'), function (input) { input.disabled = busy || (!validMonth(currentMonth()) && input.id === 'ses-add-adjustment'); });
      el('ses-save-financial').textContent = busy ? 'Aguarde…' : 'Salvar composição e ajustes';
    }
    function renderPreview(financial) {
      var target = el('ses-financial-preview'); if (!target) return; clear(target);
      if (!financial) return;
      target.appendChild(node('h3', 'g4fr-ses-financial-preview-title', financial.complete === false ? 'Resumo financeiro · valores parciais' : 'Resumo financeiro'));
      if (financial.complete === false) target.appendChild(node('p', 'g4fr-ses-notice', 'O resumo financeiro está incompleto. Os valores abaixo são parciais; confira as observações antes de utilizar o total para faturamento.'));
      var totals = node('div', 'g4fr-ses-totals');
      [['gross_value', 'Faturamento bruto'], ['deduction_total', 'Descontos dos indicadores'], ['adjustment_total', 'Outros ajustes'], ['net_value', financial.complete === false ? 'Saldo parcial' : 'Valor líquido']].forEach(function (item) {
        var tile = node('div', 'g4fr-ses-total'), value = financial[item[0]];
        tile.appendChild(node('strong', '', value === null || value === undefined ? '—' : money.format(Number(value)))); tile.appendChild(node('span', '', item[1])); totals.appendChild(tile);
      });
      target.appendChild(totals);
      if (financial.applied_rate_total !== undefined) target.appendChild(node('p', 'g4fr-ses-help', 'Desconto apurado: ' + financial.calculated_rate_total + '% · Desconto aplicado: ' + financial.applied_rate_total + '%. Ajustes financeiros não alteram os resultados dos indicadores.'));
      (financial.notes || []).forEach(function (note) { target.appendChild(node('p', 'g4fr-ses-help', note)); });
    }
    if (canEdit) {
      el('ses-add-front').addEventListener('click', function () {
        var bytes = new Uint8Array(12); window.crypto.getRandomValues(bytes);
        data.contract_fronts.push({ id: Array.from(bytes, function (byte) { return byte.toString(16).padStart(2, '0'); }).join(''), label: '', profiles: [], contract_quantity: 0, monthly_rate: '0.00' }); markDirty(); renderFronts();
      });
      el('ses-add-adjustment').addEventListener('click', function () { var month = currentMonth(); if (!validMonth(month)) return; monthData(month).adjustments.push({ description: '', amount: '' }); markDirty(); renderMonth(); });
      el('g4fr-ses-financial-form').addEventListener('submit', save);
    }
    renderFronts(); renderMonth();
    return { renderMonth: renderMonth, renderPreview: renderPreview, setBusy: setBusy, isDirty: function () { return dirty; } };
  }
  root.G4FSesFinancial = { create: create };
})(window);
