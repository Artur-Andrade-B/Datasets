# Changes

## 0.7.0-rc2

- Restore the original shared visual theme and the role-aware dashboard as the main entry. Technician queues include approval, issue, return/accessory delays, inspection, signatures and integration recovery; requester home contains category discovery and personal actions.
- Replace search-first intake with category/resource cards, a persistent multi-resource selection, duration presets, contextual room filters, usage details and a final review. Selections survive category/page changes; calendar/resource shortcuts and repeat requests enter the same flow. JavaScript-disabled controls remain functional.
- Bind final submission to the exact displayed review and retain a submitted draft receipt to recover retries without another booking or ticket.
- Redistribute resource configuration into type choice and four sections, hiding irrelevant room/equipment fields. Add structured accessory rows, draft saving, input preservation and readable durations. Make sectors list-first.
- Add explicit incorporation of existing GLPI reservable items as drafts with preserved native identity and requester restrictions. Refuse current/future legacy reservations and roll back failed links.
- Rebuild calendar month/week/day navigation, filters, selected-day details and booking shortcuts. Include authorized legacy occupancy and anonymous busy periods, without truncating the month at 100 bookings. Crowded days offer explicit detail links.
- Make request lists resource-oriented and searchable by resource, location, borrower, purpose and ticket. Match dashboard queue counts to their authorized list destinations.
- Show document preparation actions according to the current workflow stage, separate current documents from history, and preserve the original PDF/acceptance controls.
- Fix GLPI 11 redirect exceptions being shown as errors after successful resource, sector and acceptance actions. Fix multiple-group dropdown initialization and empty placeholder handling so saved restrictions survive editing.
- Use the shared URL builder for document/verification links under GLPI's scoped route loader; return from a document to its existing booking detail instead of starting another draft.
- Add task-based browser validation, new standalone tests and real GLPI enrollment scenarios. No production deployment was performed.

## 0.7.0-rc1

- Add plugin-owned resource/sector registries and separate custody, assignment, approval and organizational responsibilities.
- Add ticket-backed reservation aggregates, native group validation, service catalog offerings, scoped calendar, inventory linking and explicit equipment export.
- Add transactional allocation, optimistic revision checks, idempotent commands, native mutation guards and durable post-commit ticket integration.
- Add issue, receipt, counted accessory reconciliation, inspection, quarantine/maintenance, reinspection and documented completion.
- Add internal electronic acceptance, immutable version snapshots, original/final PDF hashes, protected evidence, integrity verification and native final-document attachments.
- Preserve legacy data and existing profile grants/denials on upgrade. Replace profile-name-based automatic grants with explicit configuration.
- Harden legacy item/entity scope, calendar privacy, independent cancellation/deletion permissions, target-user selectors and native write failure handling. Remove direct native-table write fallbacks.
- Register unsigned-hold expiry and integration retry automatic actions.
- Add standalone tests, guarded real-GLPI integration tests and release/setup documentation.
- Raise supported minimum to GLPI 11.0.7 for the verified integration surface. New workflow text is primarily Portuguese.

This candidate does not implement every longer-term item in the preceding project assessment. The README lists explicit release boundaries. No production deployment was performed.
