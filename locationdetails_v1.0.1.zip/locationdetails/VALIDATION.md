# Validação da versão 1.0.1

Ambiente descartável: distribuição oficial **GLPI 11.0.7**, PHP **8.3.6** e
MariaDB **10.11**, com dados sintéticos. Nenhuma chamada foi feita ao GLPI do usuário
ou à integração externa. Credenciais das capturas não foram utilizadas.

| Verificação | Resultado |
| --- | --- |
| Sintaxe dos arquivos PHP | Aprovada |
| Blocos e normalização de configuração | 21 verificações aprovadas |
| Middleware com classes HTTP reais do GLPI e serviços de dados isolados | 85 verificações aprovadas |
| Controles de diagnóstico e preservação das configurações | 33 verificações aprovadas |
| Armazenamento de diagnóstico, limites, privacidade e falhas | 40 verificações aprovadas |
| Integração de criação/configuração com núcleo e banco reais | 45 verificações aprovadas |
| Fluxo HTTP nativo, OAuth, configuração e diagnóstico | 46 verificações aprovadas |
| Atualização e ativação pela CLI nativa do GLPI | Aprovadas |
| Revisão independente das mudanças | Falhas de isolamento de I/O identificadas, corrigidas e cobertas por testes |

## Fluxo HTTP e diagnóstico

Um servidor PHP local executou o roteador, o login web e a autenticação OAuth reais
do GLPI. Os clientes e credenciais temporários pertencem somente ao banco descartável.

- Consulta de coleção filtrada por ID com paginação/ordenação e consulta de detalhe.
- Modo API e modo Descrição e API; criação de chamado pela classe nativa Ticket.
- Gravação do modo Descrição e API pelo formulário HTTP nativo com duas categorias
  e todos os 15 campos disponíveis além do ID.
- Ativação de captura pelo POST nativo, preservando as configurações de enriquecimento.
- Relatório na aba AJAX nativa, com versões e etapas efetivamente executadas.
- Registro da inicialização, middleware, metadados, localização, visibilidade, campos
  e alteração da resposta; registro do hook e do resultado da criação.
- Igualdade do JSON completo retornado antes/depois de habilitar a captura.
- Exclusão de categoria pelo formulário produz resposta original e motivo explícito
  `category_not_selected`; gravação comum mantém o prazo de captura.
- Encerramento impede novos eventos; limpeza remove o histórico do diagnóstico.
- POST sem CSRF é rejeitado tanto na configuração comum quanto na ativação de captura.
- Descrições, valores de endereço/sala, credenciais e tokens ausentes do relatório.
- O teste de atualização reproduziu reutilização do template compilado anterior;
  o novo nome de template resolveu a apresentação sem limpeza global de cache.

## Armazenamento e falhas

`diagnostics_test.php` usa o gravador real do plugin e diretórios temporários,
com serviços de configuração substituídos explicitamente para isolamento.

- Captura desativada ou expirada não grava eventos.
- IDs de requisição, campos permitidos e versões presentes.
- Limites por requisição e por arquivo; retenção começa em registros JSON completos.
- Bloqueio concorrente não aguarda e não prejudica a operação chamadora.
- Exceções registram classe, código, indicação segura, arquivo/linha e pilha sem argumentos.
- Mensagem SQL, corpo do chamado e valores secretos não são gravados.
- Diretório indisponível é informado corretamente; limpeza não anuncia sucesso indevido.
- Um gravador artificial em subprocesso emite avisos de armazenamento cheio e
  falhas de truncamento: o diagnóstico retorna sem produzir saída ou erro secundário.

## Regressão do enriquecimento

O teste com banco real mantém a cobertura de todos os quatro modos, categorias e
subcategorias, campos vazios/zero, escape de HTML, localização ausente, entidade
recursiva, bloqueio entre entidades não relacionadas e atualização do bloco na API.
As leituras da API preservam o conteúdo e a data de alteração no banco. Instalação,
atualização e desinstalação mantêm os contratos documentados de configuração e históricos.

## Execução dos testes incluídos

```bash
php tests/block_test.php
php tests/diagnostic_config_test.php
php tests/diagnostics_test.php
php tests/api_middleware_test.php /caminho/para/glpi
```

`core_integration_test.php` cria e altera registros sintéticos e reinstala a
configuração do plugin. Exige CLI, autorização explícita e banco chamado exatamente
`glpi_location_test`; destina-se exclusivamente a uma instalação descartável:

```bash
GLPI_LOCATIONDETAILS_TEST_ROOT=/caminho/para/glpi-descartavel \
GLPI_LOCATIONDETAILS_ALLOW_DESTRUCTIVE_TESTS=1 \
php tests/core_integration_test.php
```

## Limites

A validação local não identifica a causa da ausência de enriquecimento em outra
instalação. O relatório capturado nessa instalação é a evidência necessária para
localizar a etapa que falha. Esta versão adiciona diagnóstico e mantém os critérios
de enriquecimento existentes.

Os testes não medem desempenho na base de produção nem executam o formulário
específico ou o software da empresa integradora. A compatibilidade declarada continua
GLPI 11.0.7–11.x e PHP 8.2 ou superior. A captura exige permissão de gravação no
diretório de logs do GLPI; a aba informa quando o armazenamento está indisponível.
