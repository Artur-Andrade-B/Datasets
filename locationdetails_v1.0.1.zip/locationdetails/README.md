# Detalhes da localização — 1.0.1

Plugin independente para **GLPI 11.0.7 a 11.x**, com PHP 8.2 ou superior.
Inclui atributos da localização na descrição de novos chamados, na descrição
devolvida pela API v2, ou em ambos. A seleção de localização do formulário continua
a funcionar normalmente.

## Instalação

1. Extraia o ZIP. Ele contém uma única pasta `locationdetails/`.
2. Coloque essa pasta em `plugins/locationdetails/` na instalação GLPI de homologação.
3. Em **Configurar > Plugins**, instale e habilite **Detalhes da localização**.
4. Abra a configuração do plugin ou **Configurar > Geral > Detalhes da localização**.
5. Selecione o modo, as categorias de chamados e os campos desejados. Salve.

Não é necessário executar Composer, criar credenciais de API ou configurar uma
conexão de banco adicional. O plugin usa o GLPI e suas dependências já instaladas.
Os plugins GLPIChat e Relatórios G4F não são dependências.

A instalação começa em **Desativado**, sem categorias selecionadas. Nenhuma categoria
selecionada significa nenhum chamado abrangido. A configuração é global; o filtro
usa os IDs das categorias reais dos chamados, não as categorias do catálogo de serviços.
A opção de subcategorias inclui todos os descendentes das categorias selecionadas.

## Diagnóstico de ausência de enriquecimento

A versão 1.0.1 acrescenta diagnóstico temporário. Os critérios de enriquecimento
permanecem os mesmos; esta atualização permite identificar a etapa que impede a
inclusão dos dados em uma instalação específica.

1. Atualize o plugin normalmente, preservando a pasta `locationdetails` e as
   configurações existentes. Reative-o se o GLPI solicitar após a atualização.
2. Abra **Configurar > Geral > Detalhes da localização** e localize **Diagnóstico**.
3. Clique em **Ativar por 30 minutos**. Esse botão não modifica o modo, as categorias
   ou os campos de enriquecimento já salvos.
4. Repita exatamente o GET que a integração já utiliza, de preferência filtrado
   por um único chamado. Também é possível criar um chamado para analisar o hook
   de criação durante a captura.
5. Volte à configuração e clique em **Atualizar relatório**. Copie todo o campo
   **Relatório para copiar** para análise. Ele inclui as versões reais do GLPI,
   PHP e plugin, as configurações lidas e os eventos recentes.
6. Clique em **Encerrar captura** quando terminar; os registros permanecem disponíveis.
   **Apagar registros** limpa somente o diagnóstico. A captura expira em 30 minutos
   mesmo que não seja encerrada manualmente.

Não é necessário obter credenciais de banco, executar SQL ou modificar a integração.
O diagnóstico usa a conexão do GLPI e não adiciona campos ou cabeçalhos à API.
As datas incluem o fuso e o campo `request` agrupa eventos da mesma execução.

| Evento ou motivo | Interpretação |
| --- | --- |
| `plugin.initialized` | O plugin registrou seus hooks nessa requisição GET da API v2. |
| `api.middleware_entered` | A resposta passou pelo middleware do plugin. |
| `api.engine_entered` | O processamento dos chamados foi iniciado. |
| `ticket.hook_entered` | O hook de criação recebeu o chamado, antes de gravá-lo. |
| `category_not_selected` | A categoria efetivamente lida não pertence à seleção. |
| `no_ticket_location` / `location_not_found` | O chamado não tem ID de localização ou o registro não foi encontrado. |
| `location_entity_not_accessible` | A localização não está disponível para a entidade do chamado. |
| `selected_fields_empty` | Nenhum dos campos selecionados tem valor na localização. |
| `api_response_assigned` | A resposta foi atualizada com o conteúdo enriquecido. |
| `operation.failed` | Houve uma exceção; consulte etapa, classe, código, arquivo e linha. |
| `request.finished` | Informa se o middleware e o processamento da API foram alcançados. |

Uma captura sem novos eventos não comprova sucesso: confira o horário, o estado do
armazenamento exibido e se a requisição chegou à mesma instalação. O relatório
mostra até 200 eventos recentes; para facilitar a análise, prefira uma consulta
filtrada e recarregue o relatório logo depois.

O arquivo dedicado `locationdetails-diagnostic.jsonl` fica no diretório de logs
configurado pelo GLPI (normalmente `files/_log/`). Ele funciona mesmo se o log geral
em arquivos estiver desativado, desde que o processo PHP possa gravar nesse diretório.
A captura é limitada a 256 KiB e 200 eventos por requisição, mais um aviso de limite;
registros antigos são descartados quando necessário. Os bloqueios de arquivo não
aguardam: em caso de concorrência, um evento pode ser descartado.

São registrados IDs, nomes dos campos e etapas. Descrições de chamados, valores de
localização, senhas, tokens, SQL e argumentos de funções não são registrados.
As exceções mostram informações de localização no código e uma indicação segura
do tipo de falha; mensagens completas potencialmente sensíveis são omitidas.
A leitura do relatório exige o direito nativo de leitura da configuração; as ações
exigem alteração da configuração e o token CSRF nativo.

## Modos

| Modo | Descrição salva no GLPI | Resposta da API v2 |
| --- | --- | --- |
| Desativado | Fluxo normal | Fluxo normal |
| Somente descrição | Acrescenta o bloco na criação de chamados abrangidos | Retorna o conteúdo salvo normalmente |
| Somente API | Fluxo normal | Acrescenta ou atualiza o bloco apenas na resposta |
| Descrição e API | Acrescenta o bloco na criação | Atualiza o bloco com os dados atuais, sem duplicá-lo |

**Somente API** é o modo indicado para manter a descrição visual do chamado compacta.
O campo enriquecido é o `content` existente. A integração continua usando o mesmo
endpoint, autenticação e estrutura JSON.

O bloco se chama **Detalhes da localização**. Campos em branco são omitidos; valores
zero são mantidos. Endereço, CEP, cidade, estado, país, prédio, sala, latitude,
longitude e outros atributos podem ser escolhidos individualmente.

Os dados vêm da localização nativa do chamado (`locations_id`). O plugin não procura
registros pelo nome escrito na descrição, nem substitui a localização pela do
solicitante ou de um equipamento. Não completa campos vazios usando locais superiores.
Respeita o compartilhamento de localizações entre entidades previsto pelo GLPI.

## Chamados existentes e mudanças de modo

- A descrição salva recebe um retrato dos dados na criação, depois das regras do GLPI.
- Não há atualização em massa de chamados anteriores nem sincronização automática
  quando uma localização ou categoria é alterada posteriormente.
- O modo API funciona também em chamados existentes com categoria abrangida e
  localização nativa válida, sem gravá-los novamente.
- Na API, um bloco reconhecido é atualizado na própria posição; notas fora desse
  bloco são preservadas. Havendo blocos reconhecidos repetidos, somente um permanece.
- Se não for possível resolver uma localização válida, ou nenhum campo escolhido
  estiver preenchido, o conteúdo original é mantido. Se já houver um bloco salvo,
  ele permanece como retrato histórico nesse caso.
- Mudar para Somente API, desativar ou desinstalar **não apaga blocos já salvos**.
  A remoção de texto histórico deve ser uma operação deliberada, separada.
- O bloco usa uma classe HTML preservada pelo sanitizador do GLPI. A edição manual
  que remove a classe de identificação impede reconhecer esse bloco posteriormente.

O modo API não escreve no banco. Entretanto, se a integração ler o `content`
enriquecido e depois enviá-lo integralmente de volta em uma atualização, o próprio
GLPI poderá salvar esse texto recebido. Atualizações da integração devem enviar
somente os campos que ela pretende alterar.

## API atendida

Respostas JSON bem-sucedidas de:

```text
GET /api.php/Assistance/Ticket
GET /api.php/Assistance/Ticket/{id}
```

Também funciona com as versões explícitas desses caminhos aceitas pelo roteador
do GLPI. Exemplo do tipo de consulta usado pela integração:

```text
GET /api.php/Assistance/Ticket?filter=id==236300&start=0&limit=20&sort=date_creation:desc
Accept: application/json
Authorization: Bearer <token existente da integração>
```

A consulta de coleção retorna uma lista, mesmo filtrada por um único ID. Todos os
chamados abrangidos da página são processados. O plugin preserva quantidade, ordem,
status HTTP, paginação e propriedades que não sejam `content`. Se a projeção omitir
`id` ou `content`, ela é mantida como solicitada.

Subrecursos de chamados, alterações, problemas, GraphQL, exportações CSV/XML e o
endpoint de tokens não são enriquecidos. Na API legada `/apirest.php`, apenas os
detalhes que já estiverem salvos na descrição aparecem normalmente.

## Operação e manutenção

- Configuração usa os direitos nativos de leitura/alteração de Configurar > Geral.
- O processamento lê os dados locais do GLPI. Não faz chamadas HTTP para o próprio
  servidor, não adiciona consultas periódicas e não carrega scripts em páginas gerais.
- Listas da API usam consultas em lote para metadados e localizações, evitando uma
  consulta repetida por chamado que usa a mesma localização.
- Instalação e atualização preservam escolhas anteriores. A desinstalação remove
  somente a configuração própria; nenhum chamado ou localização é excluído.
- Falhas de enriquecimento preservam a operação original e registram a classe do
  erro em `files/_log/locationdetails.log` quando o log geral em arquivos está habilitado.
  A captura temporária detalhada utiliza o arquivo dedicado descrito acima.
- Não altere o nome da pasta `locationdetails`.

## Validação em homologação

1. Instale e confirme que o modo Desativado mantém os comportamentos existentes.
2. Escolha uma categoria e uma localização com endereço e coordenadas preenchidos.
3. Em Somente API, repita a consulta da integração: o `content` retornado deve conter
   um bloco; a descrição visual e a data de alteração do chamado devem permanecer iguais.
4. Em Somente descrição, abra um chamado novo pelo formulário existente e confira
   o bloco. Abra outro em categoria excluída e confira que seu conteúdo está normal.
5. Em Descrição e API, consulte o chamado: o bloco deve aparecer uma única vez.
6. Confira subcategorias, campos vazios, caracteres acentuados e a leitura de uma
   página com vários chamados. Depois, selecione o modo desejado.

## Testes incluídos

```bash
php tests/block_test.php
php tests/diagnostic_config_test.php
php tests/diagnostics_test.php
php tests/api_middleware_test.php /caminho/para/glpi
```

Os testes de bloco verificam escape, zeros e substituição. Os testes de diagnóstico
verificam controles de configuração e armazenamento temporário com dados sintéticos.
O teste de middleware usa classes reais do GLPI com serviços de dados isolados.
Todos são restritos à linha de comando.
Veja `VALIDATION.md` para as verificações executadas nesta versão e seus limites.

## Atualização

Substitua a pasta do plugin pelo pacote completo e execute a atualização normal
pelo GLPI. Não use desinstalação como procedimento de atualização, pois isso remove
a configuração do plugin. Configurações e blocos existentes são preservados por
uma atualização normal.
