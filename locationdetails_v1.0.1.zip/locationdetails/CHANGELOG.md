# Histórico

## 1.0.1

- Captura de diagnóstico opcional por 30 minutos e relatório na configuração nativa.
- Versões em execução, configuração efetiva, etapas, IDs e motivos de interrupção.
- Identificador por requisição e rastreamento dos hooks da API v2 e criação.
- Arquivo dedicado limitado, com bloqueios não bloqueantes e tratamento de falhas de I/O.
- Controles de ativação, encerramento e limpeza protegidos pelos direitos/CSRF nativos.
- Template de configuração com novo nome para evitar reutilizar o layout compilado da versão anterior.
- Atualização preserva os modos, categorias e campos já configurados.
- Critérios de enriquecimento e estrutura das respostas mantidos.

## 1.0.0

- Configuração nativa com modos Desativado, Somente descrição, Somente API e Ambos.
- Seleção de categorias, subcategorias e atributos da localização.
- Enriquecimento durante criação, após regras e antes da inserção do chamado.
- Enriquecimento virtual do `content` nos GETs de coleção e detalhe da API v2.
- Formatação compartilhada, escape de valores e substituição de blocos identificados.
- Consultas em lote, respeito à entidade da localização e preservação do fluxo em falhas.
