<?php
declare(strict_types=1);

namespace GlpiPlugin\Locationdetails;

final class Settings
{
    public const CONTEXT = 'plugin:locationdetails';

    public static function modeLabels(): array
    {
        return ['off' => 'Desativado', 'description' => 'Somente descrição',
            'api' => 'Somente API', 'both' => 'Descrição e API'];
    }

    public static function fieldLabels(): array
    {
        return [
            'id' => 'ID da localização', 'name' => 'Nome', 'completename' => 'Caminho completo',
            'code' => 'Código', 'alias' => 'Apelido', 'address' => 'Endereço',
            'postcode' => 'CEP', 'town' => 'Cidade', 'state' => 'Estado', 'country' => 'País',
            'building' => 'Prédio', 'room' => 'Sala', 'latitude' => 'Latitude',
            'longitude' => 'Longitude', 'altitude' => 'Altitude', 'comment' => 'Comentários',
        ];
    }

    public static function defaults(): array
    {
        return [
            'mode' => 'off', 'category_ids' => [], 'include_children' => false,
            'fields' => ['name', 'address', 'postcode', 'town', 'state', 'country',
                'building', 'room', 'latitude', 'longitude'],
            'diagnostic_until' => 0,
        ];
    }

    public static function normalize(array $values): array
    {
        $values = array_replace(self::defaults(), $values);
        $mode = is_string($values['mode']) ? $values['mode'] : 'off';
        $ids = [];
        foreach (self::listValue($values['category_ids']) as $id) {
            if ((is_int($id) || is_string($id)) && ctype_digit((string) $id) && (int) $id > 0) {
                $ids[(int) $id] = (int) $id;
            }
        }
        sort($ids, SORT_NUMERIC);
        $selected = array_filter(self::listValue($values['fields']), 'is_string');
        // The catalogue order is stable even if submitted checkbox order differs.
        $fields = array_values(array_intersect(array_keys(self::fieldLabels()), $selected));
        $until = $values['diagnostic_until'];
        $until = is_int($until) || is_string($until)
            ? filter_var($until, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]])
            : false;
        return [
            'mode' => isset(self::modeLabels()[$mode]) ? $mode : 'off',
            'category_ids' => array_values($ids),
            'include_children' => in_array($values['include_children'], [true, 1, '1'], true),
            'fields' => $fields,
            'diagnostic_until' => $until === false ? 0 : $until,
        ];
    }

    private static function listValue(mixed $value): array
    {
        if (is_string($value)) {
            $value = json_decode($value, true);
        }
        return is_array($value) ? array_values($value) : [];
    }

    public static function get(): array
    {
        // Read once per operation; no persistent cache requiring invalidation.
        return self::normalize(\Config::getConfigurationValues(self::CONTEXT));
    }

    public static function toStorage(array $values): array
    {
        $cfg = self::normalize($values);
        return [
            'mode' => $cfg['mode'],
            'category_ids' => json_encode($cfg['category_ids'], JSON_THROW_ON_ERROR),
            'include_children' => $cfg['include_children'] ? '1' : '0',
            'fields' => json_encode($cfg['fields'], JSON_THROW_ON_ERROR),
            'diagnostic_until' => (string) $cfg['diagnostic_until'],
        ];
    }

    public static function save(array $values): void
    {
        \Config::setConfigurationValues(self::CONTEXT, self::toStorage($values));
    }
}
