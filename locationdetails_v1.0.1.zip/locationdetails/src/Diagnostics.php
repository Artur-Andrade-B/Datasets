<?php
declare(strict_types=1);

namespace GlpiPlugin\Locationdetails;

/** Optional bounded tracing; never changes an API response or ticket input. */
final class Diagnostics
{
    public const MAX_BYTES = 262144;
    public const MAX_EVENTS = 200;
    private static bool $started = false;
    private static bool $active = false;
    private static int $until = 0;
    private static int $events = 0;
    private static string $requestId = '';
    private static bool $middlewareEntered = false;
    private static bool $engineEntered = false;

    /** Record initialization before the API router snapshots the plugin hooks. */
    public static function onPluginInit(): void
    {
        $path = @parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET' || !is_string($path)
            || !preg_match('~(?:^|/)api\.php(?:/|$)~', $path)) {
            return; // No configuration query on unrelated pages.
        }
        self::start('api_request');
        self::event('plugin.initialized', ['stage' => 'hooks_registered']);
    }

    public static function start(string $context, ?array $config = null): void
    {
        if (self::$started) {
            return;
        }
        self::$started = true;
        try {
            $config ??= Settings::get();
            self::$until = (int) ($config['diagnostic_until'] ?? 0);
            if (self::$until <= time()) {
                return;
            }
            self::$requestId = bin2hex(random_bytes(8));
            self::$active = true;
            self::event('capture.started', [
                'stage' => $context, 'mode' => $config['mode'] ?? 'off',
                'category_ids' => $config['category_ids'] ?? [], 'fields' => $config['fields'] ?? [],
                'include_children' => $config['include_children'] ?? false,
                'glpi_version' => defined('GLPI_VERSION') ? GLPI_VERSION : 'unknown',
                'php_version' => PHP_VERSION,
                'plugin_version' => defined('PLUGIN_LOCATIONDETAILS_VERSION') ? PLUGIN_LOCATIONDETAILS_VERSION : 'unknown',
                'sapi' => PHP_SAPI,
            ]);
            register_shutdown_function(static function (): void {
                self::event('request.finished', [
                    'status' => http_response_code() ?: 0,
                    'middleware_entered' => self::$middlewareEntered,
                    'api_engine_entered' => self::$engineEntered,
                ]);
            });
        } catch (\Throwable) {
            self::$active = false;
        }
    }

    public static function event(string $event, array $data = []): void
    {
        if (!self::$active || self::$until <= time()) {
            return;
        }
        try {
            self::$middlewareEntered = self::$middlewareEntered || $event === 'api.middleware_entered';
            self::$engineEntered = self::$engineEntered || $event === 'api.engine_entered';
            if (++self::$events > self::MAX_EVENTS + 1) {
                return;
            }
            if (self::$events === self::MAX_EVENTS + 1) {
                $event = 'capture.truncated';
                $data = ['reason' => 'per_request_event_limit'];
            }
            self::append(json_encode([
                'time' => date('c'), 'request' => self::$requestId,
                'event' => self::identifier($event), 'data' => self::safeData($data),
            ], JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES) . "\n");
        } catch (\Throwable) {
            // Encoding and file failures leave the original GLPI operation intact.
        }
    }

    public static function failure(string $context, \Throwable $error): void
    {
        try {
            $frames = [];
            foreach (array_slice($error->getTrace(), 0, 6) as $frame) {
                $frames[] = self::safeFile((string) ($frame['file'] ?? '')) . ':' . (int) ($frame['line'] ?? 0)
                    . ' ' . self::identifier((string) ($frame['class'] ?? '') . (string) ($frame['type'] ?? '') . (string) ($frame['function'] ?? ''));
            }
            self::event('operation.failed', [
                'stage' => $context, 'error_class' => get_class($error),
                'error_code' => (int) $error->getCode(), 'error_hint' => self::errorHint($error),
                'file' => self::safeFile($error->getFile()), 'line' => $error->getLine(), 'frames' => $frames,
            ]);
            // Keep legacy lightweight logging when capture is disabled. Active capture
            // above is independent of GLPI's use_log_in_files setting.
            \Toolbox::logInFile('locationdetails', sprintf(
                "[%s] %s failed (%s). Original GLPI operation preserved.\n",
                date('c'), self::identifier($context), get_class($error)
            ));
        } catch (\Throwable) {
            // The reporter must not become a second application error.
        }
    }

    /** Only called from the native Config tab after config READ authorization. */
    public static function adminReport(): array
    {
        $cfg = Settings::get();
        $until = (int) ($cfg['diagnostic_until'] ?? 0);
        $enabled = $until > time();
        $versions = [
            'glpi_version' => defined('GLPI_VERSION') ? GLPI_VERSION : 'unknown',
            'php_version' => PHP_VERSION,
            'plugin_version' => defined('PLUGIN_LOCATIONDETAILS_VERSION') ? PLUGIN_LOCATIONDETAILS_VERSION : 'unknown',
        ];
        [$records, $storage] = self::readRecent();
        return $versions + [
            'enabled' => $enabled, 'expires_at' => $until > 0 ? date('c', $until) : '',
            'storage_status' => $storage,
            'text' => implode("\n", [
                'Location Details - relatório de diagnóstico', 'Gerado em: ' . date('c'),
                'Plugin: ' . $versions['plugin_version'],
                'GLPI (código em execução): ' . $versions['glpi_version'],
                'PHP: ' . PHP_VERSION . ' (' . PHP_SAPI . ')',
                'Captura: ' . ($enabled ? 'ativa até ' . date('c', $until) : 'desativada ou expirada'),
                'Armazenamento: ' . $storage,
                'Configuração atual: ' . json_encode($cfg, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                '', 'Eventos recentes (cada request identifica uma execução; datas incluem o fuso):',
                $records === '' ? 'Nenhum evento disponível. Ative a captura, repita o GET da API e recarregue esta aba.' : $records,
            ]),
        ];
    }

    /** Only called from native Config POST after config UPDATE and CSRF checks. */
    public static function clear(): bool
    {
        $handle = null;
        try {
            $path = self::path();
            if ($path === null) { return false; }
            if (!@file_exists($path)) { return @is_dir(dirname($path)); }
            $handle = @fopen($path, 'c+b');
            return $handle !== false && @flock($handle, LOCK_EX | LOCK_NB) && @ftruncate($handle, 0);
        } catch (\Throwable) {
            return false;
        } finally {
            if (is_resource($handle)) { @fclose($handle); }
        }
    }

    private static function path(): ?string
    {
        return defined('GLPI_LOG_DIR') ? GLPI_LOG_DIR . '/locationdetails-diagnostic.jsonl' : null;
    }

    private static function append(string $line): void
    {
        $path = self::path();
        if ($path === null || strlen($line) > 16384) { return; }
        $handle = @fopen($path, 'c+b');
        if ($handle === false) { return; }
        try {
            if (!@flock($handle, LOCK_EX | LOCK_NB)) { return; }
            $stat = @fstat($handle);
            if ($stat === false) { return; }
            $size = (int) $stat['size'];
            if ($size + strlen($line) > self::MAX_BYTES) {
                // Keep newest half starting at a whole record, under the same lock.
                if (@fseek($handle, max(0, $size - intdiv(self::MAX_BYTES, 2))) !== 0) { return; }
                $tail = @stream_get_contents($handle);
                if ($tail === false) { return; }
                $newline = strpos($tail, "\n");
                $tail = $newline === false ? '' : substr($tail, $newline + 1);
                if (!@rewind($handle) || !@ftruncate($handle, 0)) { return; }
                if ($tail !== '' && @fwrite($handle, $tail) !== strlen($tail)) { return; }
            }
            if (@fseek($handle, 0, SEEK_END) !== 0) { return; }
            $offset = @ftell($handle);
            if (@fwrite($handle, $line) !== strlen($line) && $offset !== false) {
                @ftruncate($handle, $offset); // Discard a partial record if storage is full.
            }
        } finally {
            @fclose($handle);
        }
    }

    private static function readRecent(): array
    {
        $handle = null;
        try {
            $path = self::path();
            if ($path === null) { return ['', 'Diretório de logs do GLPI indisponível.']; }
            if (!@file_exists($path)) {
                return ['', @is_dir(dirname($path)) && @is_writable(dirname($path))
                    ? 'Pronto para capturar; ainda não há arquivo de diagnóstico.'
                    : 'O processo PHP não pode gravar no diretório de logs do GLPI.'];
            }
            $writable = @is_writable($path);
            $handle = @fopen($path, 'rb');
            if ($handle === false) { return ['', 'O processo PHP não pode ler o arquivo de diagnóstico.']; }
            if (!@flock($handle, LOCK_SH | LOCK_NB)) { return ['', 'Arquivo em uso; recarregue a aba para ler os eventos.']; }
            $stat = @fstat($handle);
            if ($stat === false) { return ['', 'Não foi possível consultar o arquivo de diagnóstico.']; }
            $size = (int) $stat['size'];
            $offset = max(0, $size - self::MAX_BYTES);
            if (@fseek($handle, $offset) !== 0) { return ['', 'Não foi possível ler o arquivo de diagnóstico.']; }
            if ($offset > 0) { @fgets($handle); }
            $contents = @stream_get_contents($handle);
            if ($contents === false) { return ['', 'Não foi possível ler o arquivo de diagnóstico.']; }
            $lines = explode("\n", trim($contents));
            return [implode("\n", array_slice($lines, -200)), $writable
                ? 'Disponível; arquivo limitado a 256 KiB e até 200 eventos por requisição.'
                : 'Somente leitura: o processo PHP não pode gravar novos eventos.'];
        } catch (\Throwable) {
            return ['', 'Não foi possível ler o diagnóstico; verifique as permissões do diretório de logs.'];
        } finally {
            if (is_resource($handle)) { @fclose($handle); }
        }
    }

    /** Only metadata, never arbitrary messages, headers, SQL or location values. */
    private static function safeData(array $data): array
    {
        $numeric = ['ticket_id', 'category_id', 'location_id', 'entity_id', 'location_entity_id',
            'count', 'found_count', 'eligible_count', 'changed_count', 'status', 'error_code', 'line'];
        $boolean = ['is_recursive', 'changed', 'visible', 'matched', 'collection', 'include_children',
            'middleware_entered', 'api_engine_entered'];
        $strings = ['reason', 'stage', 'operation', 'mode', 'method', 'route', 'content_type',
            'glpi_version', 'php_version', 'plugin_version', 'sapi', 'error_class', 'error_hint', 'file'];
        $safe = [];
        foreach ($data as $key => $value) {
            if (in_array($key, $numeric, true) && (is_int($value) || (is_string($value) && ctype_digit($value)))) {
                $safe[$key] = (int) $value;
            } elseif (in_array($key, $boolean, true) && (is_bool($value) || in_array($value, [0, 1, '0', '1'], true))) {
                $safe[$key] = (bool) $value;
            } elseif (in_array($key, $strings, true) && is_string($value)) {
                $safe[$key] = self::identifier($value);
            } elseif (in_array($key, ['category_ids', 'ticket_ids'], true) && is_array($value)) {
                $safe[$key] = array_values(array_map('intval', array_slice(array_filter($value,
                    static fn($id) => is_int($id) || (is_string($id) && ctype_digit($id))), 0, 80)));
            } elseif ($key === 'fields' && is_array($value)) {
                $safe[$key] = array_values(array_intersect(array_keys(Settings::fieldLabels()), $value));
            } elseif ($key === 'frames' && is_array($value)) {
                $safe[$key] = array_map(self::identifier(...), array_slice(array_filter($value, 'is_string'), 0, 6));
            }
        }
        return $safe;
    }

    private static function identifier(string $value): string
    {
        return substr((string) preg_replace('~[^A-Za-z0-9_./:{}\\\\ *()<>;=+-]~', '_', $value), 0, 220);
    }

    private static function safeFile(string $file): string
    {
        if (defined('GLPI_ROOT') && str_starts_with($file, GLPI_ROOT . '/')) {
            return self::identifier(substr($file, strlen(GLPI_ROOT) + 1));
        }
        $plugin = dirname(__DIR__) . '/';
        return self::identifier(str_starts_with($file, $plugin) ? 'locationdetails/' . substr($file, strlen($plugin)) : basename($file));
    }

    private static function errorHint(\Throwable $error): string
    {
        // Useful failure types without retaining exception messages or SQL values.
        if (preg_match('/MySQL query error:.*\((\d{3,5})\) in SQL query/s', $error->getMessage(), $match)) {
            return 'database_error_' . $match[1];
        }
        if (preg_match('/Call to undefined (?:method|function) ([A-Za-z0-9_\\\\:]+)\(/', $error->getMessage(), $match)) {
            return 'undefined_callable ' . $match[1];
        }
        return match (true) {
            $error instanceof \TypeError => 'type_mismatch',
            $error instanceof \JsonException => 'json_processing_failed',
            default => 'see_error_class_file_line_and_frames',
        };
    }
}
