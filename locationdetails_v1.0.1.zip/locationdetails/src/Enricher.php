<?php
declare(strict_types=1);

namespace GlpiPlugin\Locationdetails;

final class Enricher
{
    private array $eligibleCategories;
    private array $locations = [];

    public function __construct(private array $config)
    {
        $this->eligibleCategories = array_fill_keys($config['category_ids'], true);
        if ($config['include_children']) {
            foreach ($config['category_ids'] as $id) {
                Diagnostics::event('query_start', ['stage' => 'category_descendants', 'category_id' => (int) $id]);
                foreach (getSonsOf('glpi_itilcategories', $id) as $child) {
                    $this->eligibleCategories[(int) $child] = true;
                }
            }
        }
        Diagnostics::event('categories_resolved', ['category_ids' => array_keys($this->eligibleCategories)]);
    }

    public static function beforeAdd(\CommonDBTM $item): void
    {
        if (!$item instanceof \Ticket || !is_array($item->input)) {
            Diagnostics::event('creation_skip', ['reason' => 'invalid_ticket_input']);
            return;
        }
        try {
            $cfg = Settings::get();
            Diagnostics::start('ticket_creation', $cfg);
            Diagnostics::event('ticket.hook_entered', self::ticketMetadata($item->input));
            if (!in_array($cfg['mode'], ['description', 'both'], true)) {
                Diagnostics::event('creation_skip', ['reason' => 'description_mode_disabled', 'mode' => $cfg['mode']]);
                return;
            }
            if ($cfg['category_ids'] === [] || $cfg['fields'] === []) {
                Diagnostics::event('creation_skip', ['reason' => $cfg['category_ids'] === [] ? 'no_selected_categories' : 'no_selected_fields']);
                return;
            }
            $engine = new self($cfg);
            $input = $item->input;
            if (!$engine->eligible($input)) {
                Diagnostics::event('creation_skip', ['reason' => 'category_not_selected'] + self::ticketMetadata($input));
                return;
            }
            if (!is_string($input['content'] ?? null)) {
                Diagnostics::event('creation_skip', ['reason' => 'content_missing_or_not_string']);
                return;
            }
            $engine->loadLocations([(int) ($input['locations_id'] ?? 0)]);
            $item->input['content'] = $engine->content($input['content'], $input);
            Diagnostics::event('creation_complete', ['changed' => $item->input['content'] !== $input['content']]);
        } catch (\Throwable $error) {
            Diagnostics::failure('ticket creation', $error);
        }
    }

    /**
     * Called only with successful native API Ticket results already authorized
     * by GLPI. Never discovers additional tickets or modifies the result set.
     */
    public static function enrichApiRows(array $rows, ?array $cfg = null): array
    {
        global $DB;
        $cfg ??= Settings::get();
        Diagnostics::start('api_engine', $cfg);
        Diagnostics::event('api.engine_entered', ['count' => count($rows)]);
        if (!in_array($cfg['mode'], ['api', 'both'], true)) {
            Diagnostics::event('api_engine_skip', ['reason' => 'api_mode_disabled', 'mode' => $cfg['mode']]);
            return $rows;
        }
        if ($cfg['category_ids'] === [] || $cfg['fields'] === []) {
            Diagnostics::event('api_engine_skip', ['reason' => $cfg['category_ids'] === [] ? 'no_selected_categories' : 'no_selected_fields']);
            return $rows;
        }
        $ids = [];
        foreach ($rows as $row) {
            if (!is_array($row) || !is_string($row['content'] ?? null)) {
                Diagnostics::event('api_row_skip', ['reason' => 'content_missing_or_not_string']);
                continue;
            }
            $id = $row['id'] ?? null;
            if ((is_int($id) || is_string($id)) && ctype_digit((string) $id) && (int) $id > 0) {
                $ids[(int) $id] = (int) $id;
            } else {
                Diagnostics::event('api_row_skip', ['reason' => 'invalid_ticket_id']);
            }
        }
        if ($ids === []) {
            Diagnostics::event('api_engine_skip', ['reason' => 'no_usable_ticket_rows']);
            return $rows;
        }
        $engine = new self($cfg);
        $metadata = [];
        $foundIds = [];
        $locationIds = [];
        foreach (array_chunk(array_values($ids), 500) as $chunk) {
            Diagnostics::event('query_start', ['stage' => 'ticket_metadata', 'ticket_ids' => $chunk, 'count' => count($chunk)]);
            foreach ($DB->request([
                'SELECT' => ['id', 'entities_id', 'itilcategories_id', 'locations_id'],
                'FROM' => 'glpi_tickets', 'WHERE' => ['id' => $chunk],
            ]) as $ticket) {
                $foundIds[(int) $ticket['id']] = true;
                if ($engine->eligible($ticket)) {
                    Diagnostics::event('ticket_metadata_selected', self::ticketMetadata($ticket));
                    $metadata[(int) $ticket['id']] = $ticket;
                    $locationIds[] = (int) $ticket['locations_id'];
                } else {
                    Diagnostics::event('api_row_skip', ['reason' => 'category_not_selected'] + self::ticketMetadata($ticket));
                }
            }
        }
        Diagnostics::event('ticket_metadata_complete', ['count' => count($ids), 'found_count' => count($foundIds), 'eligible_count' => count($metadata)]);
        foreach ($ids as $id) {
            if (!isset($foundIds[$id])) {
                Diagnostics::event('api_row_skip', ['reason' => 'ticket_metadata_not_found', 'ticket_id' => $id]);
            }
        }
        $engine->loadLocations($locationIds);
        $changed = 0;
        foreach ($rows as &$row) {
            if (!is_array($row) || !is_string($row['content'] ?? null)) {
                continue;
            }
            $id = (int) ($row['id'] ?? 0);
            if (isset($metadata[$id])) {
                $original = $row['content'];
                $row['content'] = $engine->content($row['content'], $metadata[$id]);
                $changed += (int) ($row['content'] !== $original);
            }
        }
        unset($row);
        Diagnostics::event('api_engine_complete', ['count' => count($rows), 'changed_count' => $changed]);
        return $rows;
    }

    private function eligible(array $ticket): bool
    {
        return isset($this->eligibleCategories[(int) ($ticket['itilcategories_id'] ?? 0)]);
    }

    private function loadLocations(array $ids): void
    {
        global $DB;
        $ids = array_values(array_unique(array_filter($ids, static fn($id) => $id > 0)));
        foreach (array_chunk($ids, 500) as $chunk) {
            Diagnostics::event('query_start', ['stage' => 'locations', 'count' => count($chunk)]);
            foreach ($DB->request(['FROM' => 'glpi_locations', 'WHERE' => ['id' => $chunk]]) as $location) {
                $this->locations[(int) $location['id']] = $location;
            }
        }
        Diagnostics::event('locations_loaded', ['count' => count($ids), 'found_count' => count($this->locations)]);
    }

    private function content(string $original, array $ticket): string
    {
        $location = $this->locations[(int) ($ticket['locations_id'] ?? 0)] ?? null;
        if ($location === null || !array_key_exists('entities_id', $ticket)) {
            Diagnostics::event('content_skip', ['reason' => $location === null
                ? ((int) ($ticket['locations_id'] ?? 0) > 0 ? 'location_not_found' : 'no_ticket_location')
                : 'ticket_entity_missing'] + self::ticketMetadata($ticket));
            return $original;
        }
        $item = new \Location();
        $item->fields = $location;
        // Follow GLPI's recursive-entity visibility; do not import attributes
        // from an unrelated entity. No fallback to names, requester or parents.
        Diagnostics::event('visibility_check_start', self::ticketMetadata($ticket));
        $visible = $item->isAccessibleFromEntities([(int) $ticket['entities_id']]);
        Diagnostics::event('visibility_checked', ['visible' => $visible,
            'location_entity_id' => (int) ($location['entities_id'] ?? 0),
            'is_recursive' => (bool) ($location['is_recursive'] ?? false)] + self::ticketMetadata($ticket));
        if (!$visible) {
            Diagnostics::event('content_skip', ['reason' => 'location_entity_not_accessible'] + self::ticketMetadata($ticket));
            return $original;
        }
        $populated = [];
        foreach ($this->config['fields'] as $field) {
            $value = $location[$field] ?? null;
            if (is_scalar($value) && trim((string) $value) !== '') {
                $populated[] = $field;
            }
        }
        Diagnostics::event('location_fields_checked', ['fields' => $populated, 'count' => count($populated)] + self::ticketMetadata($ticket));
        $block = Block::render($location, $this->config['fields']);
        if ($block === '') {
            Diagnostics::event('content_skip', ['reason' => 'selected_fields_empty'] + self::ticketMetadata($ticket));
            return $original;
        }
        $result = Block::replace($original, $block);
        Diagnostics::event('content_complete', ['changed' => $result !== $original] + self::ticketMetadata($ticket));
        return $result;
    }

    /** Numeric identifiers only; never include descriptions or location values. */
    private static function ticketMetadata(array $ticket): array
    {
        return ['ticket_id' => (int) ($ticket['id'] ?? 0),
            'category_id' => (int) ($ticket['itilcategories_id'] ?? 0),
            'location_id' => (int) ($ticket['locations_id'] ?? 0),
            'entity_id' => (int) ($ticket['entities_id'] ?? 0)];
    }
}
