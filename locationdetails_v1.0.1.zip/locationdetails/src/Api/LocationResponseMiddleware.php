<?php

declare(strict_types=1);

namespace GlpiPlugin\Locationdetails\Api;

use Glpi\Api\HL\Middleware\AbstractMiddleware;
use Glpi\Api\HL\Middleware\MiddlewareInput;
use Glpi\Api\HL\Middleware\ResponseMiddlewareInterface;
use Glpi\Api\HL\RoutePath;
use GlpiPlugin\Locationdetails\Diagnostics;
use GlpiPlugin\Locationdetails\Enricher;
use GlpiPlugin\Locationdetails\Settings;
use GuzzleHttp\Psr7\Utils;
use stdClass;
use Throwable;

/**
 * Enrich only existing REST ticket reads after GLPI has applied its permissions.
 * GLPI normalizes api.php and the optional API version before middleware runs.
 */
final class LocationResponseMiddleware extends AbstractMiddleware implements ResponseMiddlewareInterface
{
    private const ROUTES = [
        '/Assistance/{itemtype}',
        '/Assistance/{itemtype}/{id}',
        '/Assistance/Ticket',
        '/Assistance/Ticket/{id}',
    ];

    /**
     * The ITIL controller shares these route templates with Changes and Problems.
     * The request's resolved itemtype is checked separately in process().
     */
    public static function supportsRoute(RoutePath $route): bool
    {
        $supported = in_array($route->getRoutePath(), self::ROUTES, true);
        $matched = in_array('GET', $route->getRouteMethods(), true) && $supported;
        Diagnostics::event('api_route_evaluated', [
            'route' => $supported ? $route->getRoutePath() : 'unsupported_route',
            'matched' => $matched,
        ]);
        return $matched;
    }

    public function process(MiddlewareInput $input, callable $next): void
    {
        // Keep downstream middleware outside our catch: its errors belong to GLPI.
        try {
            Diagnostics::start('api_response');
            Diagnostics::event('api.middleware_entered');
            $this->enrichResponse($input);
        } catch (Throwable $error) {
            // No modified response is assigned until enrichment and encoding succeed.
            Diagnostics::failure('api_response', $error);
        }

        $next($input);
    }

    private function enrichResponse(MiddlewareInput $input): void
    {
        $response = $input->response;
        if ($response === null) {
            Diagnostics::event('api_response_skip', ['reason' => 'no_response']);
            return;
        }
        if ($input->request->getMethod() !== 'GET') {
            Diagnostics::event('api_response_skip', ['reason' => 'not_get']);
            return;
        }
        if (!self::supportsRoute($input->route_path)) {
            Diagnostics::event('api_response_skip', ['reason' => 'unsupported_route']);
            return;
        }
        Diagnostics::event('api_response_received', ['method' => 'GET', 'status' => $response->getStatusCode(),
            'route' => $input->route_path->getRoutePath()]);
        if ($response->getStatusCode() < 200 || $response->getStatusCode() >= 300) {
            Diagnostics::event('api_response_skip', ['reason' => 'unsuccessful_status', 'status' => $response->getStatusCode()]);
            return;
        }

        $route = $input->route_path->getRoutePath();
        if (str_contains($route, '{itemtype}')
            && $input->request->getAttribute('itemtype') !== 'Ticket'
        ) {
            Diagnostics::event('api_response_skip', ['reason' => 'itemtype_not_ticket']);
            return;
        }

        // GLPI's formatter runs after this middleware. Do not enrich CSV/XML reads.
        $accept = strtolower(trim($input->request->getHeaderLine('Accept')));
        if (in_array($accept, ['text/csv', 'application/xml'], true)) {
            Diagnostics::event('api_response_skip', ['reason' => 'non_json_requested']);
            return;
        }
        $contentType = strtolower(trim(explode(';', $response->getHeaderLine('Content-Type'), 2)[0]));
        Diagnostics::event('api_content_type_checked', ['content_type' => in_array($contentType,
            ['application/json', 'application/xml', 'text/csv', 'text/html', 'text/plain'], true) ? $contentType : 'other']);
        if ($contentType !== 'application/json') {
            Diagnostics::event('api_response_skip', ['reason' => 'response_not_json']);
            return;
        }
        if ($response->getHeaderLine('Content-Encoding') !== '') {
            Diagnostics::event('api_response_skip', ['reason' => 'encoded_response']);
            return;
        }
        $config = Settings::get();
        if (!in_array($config['mode'], ['api', 'both'], true)) {
            Diagnostics::event('api_response_skip', ['reason' => 'api_mode_disabled', 'mode' => $config['mode']]);
            return;
        }

        $stream = $response->getBody();
        // Reading a non-seekable stream would prevent returning it unchanged on failure.
        if (!$stream->isReadable() || !$stream->isSeekable()) {
            Diagnostics::event('api_response_skip', ['reason' => 'stream_not_readable_or_seekable']);
            return;
        }
        Diagnostics::event('api_processing_stage', ['stage' => 'read_response_stream']);
        $position = $stream->tell();
        try {
            $stream->rewind();
            $raw = $stream->getContents();
        } finally {
            $stream->seek($position);
        }

        // Preserve nested JSON objects (including {}) by avoiding recursive array decoding.
        Diagnostics::event('api_processing_stage', ['stage' => 'decode_json']);
        $document = json_decode($raw, false, 512, JSON_THROW_ON_ERROR);
        $collection = !str_ends_with($route, '/{id}');
        if (($collection && !is_array($document))
            || (!$collection && !$document instanceof stdClass)
        ) {
            Diagnostics::event('api_response_skip', ['reason' => 'unexpected_json_shape', 'collection' => $collection]);
            return;
        }

        $objects = $collection ? $document : [$document];
        $rows = [];
        foreach ($objects as $key => $object) {
            // A projection without content is left as requested; no fields are added.
            if ($object instanceof stdClass
                && isset($object->id, $object->content)
                && is_string($object->content)
            ) {
                $rows[$key] = (array) $object;
            }
        }
        if ($rows === []) {
            Diagnostics::event('api_response_skip', ['reason' => 'no_rows_with_id_and_content', 'count' => count($objects), 'collection' => $collection]);
            return;
        }
        Diagnostics::event('api_rows_ready', ['count' => count($rows), 'collection' => $collection]);

        $enriched = Enricher::enrichApiRows($rows, $config);
        $changed = 0;
        foreach ($rows as $key => $row) {
            if (isset($enriched[$key]['content'])
                && is_string($enriched[$key]['content'])
                && $enriched[$key]['content'] !== $row['content']
            ) {
                $objects[$key]->content = $enriched[$key]['content'];
                $changed++;
            }
        }
        if (!$changed) {
            Diagnostics::event('api_response_skip', ['reason' => 'no_content_changes', 'count' => count($rows), 'changed_count' => 0]);
            return;
        }

        Diagnostics::event('api_processing_stage', ['stage' => 'encode_json', 'changed_count' => $changed]);
        $body = json_encode($document, JSON_THROW_ON_ERROR | JSON_PRESERVE_ZERO_FRACTION);
        $updated = $response->withBody(Utils::streamFor($body));
        // Preserve all pagination and status information; refresh body-dependent headers.
        if ($response->hasHeader('Content-Length')) {
            $updated = $updated->withHeader('Content-Length', (string) strlen($body));
        }
        foreach (['ETag', 'Content-MD5', 'Digest'] as $header) {
            if ($updated->hasHeader($header)) {
                $updated = $updated->withoutHeader($header);
            }
        }
        $input->response = $updated;
        Diagnostics::event('api_response_assigned', ['changed_count' => $changed, 'content_type' => 'application/json', 'status' => $updated->getStatusCode()]);
    }
}
