<?php
declare(strict_types=1);

use Glpi\Plugin\Hooks;
use GlpiPlugin\Locationdetails\Api\LocationResponseMiddleware;
use GlpiPlugin\Locationdetails\Config;
use GlpiPlugin\Locationdetails\Diagnostics;
use GlpiPlugin\Locationdetails\Enricher;

require_once __DIR__ . '/inc/autoload.php';
define('PLUGIN_LOCATIONDETAILS_VERSION', '1.0.1');

function plugin_init_locationdetails(): void
{
    global $PLUGIN_HOOKS;
    $PLUGIN_HOOKS['csrf_compliant']['locationdetails'] = true;
    $PLUGIN_HOOKS['config_page']['locationdetails'] = 'front/config.php';
    Plugin::registerClass(Config::class, ['addtabon' => \Config::class]);
    // Keep registration independent of interactive login/browser state.
    $PLUGIN_HOOKS[Hooks::POST_PREPAREADD]['locationdetails'] = [
        Ticket::class => [Enricher::class, 'beforeAdd'],
    ];
    $PLUGIN_HOOKS[Hooks::API_MIDDLEWARE]['locationdetails'] = [[
        'middleware' => LocationResponseMiddleware::class,
        'priority' => 10,
        'condition' => [LocationResponseMiddleware::class, 'supportsRoute'],
    ]];
    Diagnostics::onPluginInit();
}

function plugin_version_locationdetails(): array
{
    return [
        'name' => 'Detalhes da localização', 'version' => PLUGIN_LOCATIONDETAILS_VERSION,
        'author' => 'G4F', 'license' => 'GPLv3+', 'homepage' => '',
        'requirements' => ['glpi' => ['min' => '11.0.7', 'max' => '11.99.99'],
            'php' => ['min' => '8.2']],
    ];
}

function plugin_locationdetails_check_prerequisites(): bool
{
    return defined('GLPI_VERSION') && version_compare(GLPI_VERSION, '11.0.7', '>=')
        && version_compare(GLPI_VERSION, '12.0.0', '<') && PHP_VERSION_ID >= 80200;
}

function plugin_locationdetails_check_config($verbose = false): bool
{
    return true;
}
