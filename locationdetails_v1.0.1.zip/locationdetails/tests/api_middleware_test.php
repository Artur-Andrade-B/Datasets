<?php

declare(strict_types=1);

namespace {
    // Run separately from the plugin test harness; these service doubles are intentional.
    if (PHP_SAPI !== 'cli') {
        http_response_code(404);
        exit;
    }
    $glpiRoot = $argv[1] ?? getenv('GLPI_TEST_ROOT') ?: '';
    if (!is_file($glpiRoot . '/vendor/autoload.php')) {
        fwrite(STDERR, "Usage: php tests/api_middleware_test.php /path/to/glpi\n");
        exit(2);
    }
    require $glpiRoot . '/vendor/autoload.php';
}

namespace GlpiPlugin\Locationdetails {
    final class Settings
    {
        public static string $mode = 'api';
        public static function get(): array
        {
            return ['mode' => self::$mode];
        }
    }

    final class Enricher
    {
        public static int $calls = 0;
        public static bool $change = true;
        public static bool $throw = false;

        public static function enrichApiRows(array $rows, ?array $config = null): array
        {
            self::$calls++;
            if (self::$throw) {
                throw new \RuntimeException('Simulated lookup failure');
            }
            foreach ($rows as &$row) {
                if (self::$change) {
                    $row['content'] .= '<p>Detalhes da localização: sala 4</p>';
                }
                // Verify that the middleware cannot accidentally propagate other edits.
                $row['name'] = 'MUST NOT ESCAPE THE ENRICHER';
                $row['unexpected_property'] = true;
            }
            unset($row);
            return $rows;
        }
    }

    final class Diagnostics
    {
        public static int $failures = 0;
        public static function start(string $context, ?array $config = null): void
        {
        }
        public static function event(string $event, array $data = []): void
        {
        }
        public static function failure(string $context, \Throwable $error): void
        {
            self::$failures++;
        }
    }
}

namespace {
    use Glpi\Api\HL\Controller\ITILController;
    use Glpi\Api\HL\Middleware\MiddlewareInput;
    use Glpi\Api\HL\RoutePath;
    use Glpi\Http\JSONResponse;
    use Glpi\Http\Request;
    use Glpi\Http\Response;
    use GlpiPlugin\Locationdetails\Api\LocationResponseMiddleware;
    use GlpiPlugin\Locationdetails\Diagnostics;
    use GlpiPlugin\Locationdetails\Enricher;
    use GlpiPlugin\Locationdetails\Settings;

    require dirname(__DIR__) . '/src/Api/LocationResponseMiddleware.php';

    $checks = 0;
    function verify(bool $condition, string $message): void
    {
        global $checks;
        $checks++;
        if (!$condition) {
            throw new RuntimeException($message);
        }
    }

    function inputFor(
        ?Response $response,
        string $route = '/Assistance/{itemtype}',
        string $type = 'Ticket',
        string $method = 'GET',
        string $accept = 'application/json'
    ): MiddlewareInput {
        $request = new Request($method, '/Assistance/' . $type . '?filter=id==236300&start=0&limit=20', ['Accept' => $accept]);
        $request->setAttribute('itemtype', $type);
        $request->setAttribute('id', '236300');
        $request = $request->withHeader('GLPI-API-Version', '2.3.0');
        return new MiddlewareInput(
            $request,
            new RoutePath(ITILController::class, 'search', $route, [$method], 0, 0),
            $response
        );
    }

    function process(MiddlewareInput $input): void
    {
        $nextCalls = 0;
        (new LocationResponseMiddleware())->process($input, static function ($received) use ($input, &$nextCalls): void {
            verify($received === $input, 'Forward the same middleware input');
            $nextCalls++;
        });
        verify($nextCalls === 1, 'Call downstream middleware exactly once');
    }

    $ticket = [
        'id' => 236300,
        'name' => 'Configuração de impressora',
        'content' => '<p>Localização: Conselho de Saúde</p>',
        'location' => (object) ['id' => 17, 'metadata' => (object) []],
        'nullable' => null,
        'empty_list' => [],
        'empty_object' => (object) [],
        'numeric' => 1.25,
    ];
    $response = new JSONResponse([$ticket, ['id' => 9], $ticket], 206, [
        'Content-Range' => 'items 0-2/50',
        'X-Total-Count' => '50',
        'X-Custom' => 'preserve',
        'Content-Length' => '1',
        'ETag' => 'old-body',
    ]);
    $input = inputFor($response);
    $response->getBody()->seek(7);
    process($input);
    $data = json_decode((string) $input->response->getBody());
    verify(is_array($data) && count($data) === 3, 'Preserve filtered collection shape and row count');
    verify(str_contains($data[0]->content, 'sala 4') && str_contains($data[2]->content, 'sala 4'), 'Enrich every full ticket including sparse eligible keys');
    verify(!property_exists($data[1], 'content'), 'Do not invent omitted content projections');
    verify($data[0]->name === $ticket['name'] && !property_exists($data[0], 'unexpected_property'), 'Only content may change');
    verify($data[0]->empty_object instanceof stdClass && $data[0]->location->metadata instanceof stdClass, 'Preserve nested empty JSON objects');
    verify($data[0]->empty_list === [] && $data[0]->nullable === null && $data[0]->numeric === 1.25, 'Preserve list, null, and numeric types');
    verify($input->response->getStatusCode() === 206, 'Preserve partial success status');
    verify($input->response->getHeaderLine('Content-Range') === 'items 0-2/50' && $input->response->getHeaderLine('X-Total-Count') === '50', 'Preserve pagination headers');
    verify($input->response->getHeaderLine('X-Custom') === 'preserve', 'Preserve unrelated headers');
    verify((int) $input->response->getHeaderLine('Content-Length') === strlen((string) $input->response->getBody()), 'Update content length after enrichment');
    verify(!$input->response->hasHeader('ETag'), 'Do not retain a validator for the previous body');
    verify($response->getBody()->tell() === 7, 'Keep original stream position');
    verify($input->response instanceof JSONResponse, 'Preserve response class for downstream GLPI middleware');

    $input = inputFor(new JSONResponse($ticket), '/Assistance/{itemtype}/{id}');
    process($input);
    $single = json_decode((string) $input->response->getBody());
    verify($single instanceof stdClass && str_contains($single->content, 'sala 4'), 'Preserve single-ticket object shape');

    foreach (['off', 'description'] as $mode) {
        Settings::$mode = $mode;
        $input = inputFor($response);
        process($input);
        verify($input->response === $response, $mode . ' mode must leave response unchanged');
    }
    Settings::$mode = 'both';
    $input = inputFor(new JSONResponse([$ticket]));
    process($input);
    verify(str_contains((string) $input->response->getBody(), 'sala 4'), 'Both mode enables API enrichment');
    Settings::$mode = 'api';

    $excluded = [
        ['/Assistance/{itemtype}', 'Problem', 'GET', 'application/json'],
        ['/Assistance/{itemtype}', 'Change', 'GET', 'application/json'],
        ['/Assistance/{itemtype}/{id}/Followup', 'Ticket', 'GET', 'application/json'],
        ['/Assistance/{itemtype}/{id}/Document', 'Ticket', 'GET', 'application/json'],
        ['/Assistance/{itemtype}', 'Ticket', 'POST', 'application/json'],
        ['/Assistance/{itemtype}/{id}', 'Ticket', 'PATCH', 'application/json'],
        ['/token', 'Ticket', 'POST', 'application/json'],
        ['/GraphQL', 'Ticket', 'GET', 'application/json'],
        ['/Assistance/{itemtype}', 'Ticket', 'GET', 'text/csv'],
        ['/Assistance/{itemtype}', 'Ticket', 'GET', 'application/xml'],
    ];
    foreach ($excluded as [$route, $type, $method, $accept]) {
        $before = Enricher::$calls;
        $input = inputFor($response, $route, $type, $method, $accept);
        process($input);
        verify($input->response === $response && Enricher::$calls === $before, 'Exclude ' . $method . ' ' . $route . ' ' . $type . ' ' . $accept);
    }
    foreach ([
        new JSONResponse([$ticket], 400),
        new JSONResponse([$ticket], 403),
        new JSONResponse([], 204),
        new JSONResponse([]),
        new Response(200, ['Content-Type' => 'text/html'], '<h1>HTML</h1>'),
        null,
    ] as $excludedResponse) {
        $input = inputFor($excludedResponse);
        process($input);
        verify($input->response === $excludedResponse, 'Do not rewrite errors, empty collections, HTML, or absent responses');
    }

    Enricher::$change = false;
    $input = inputFor($response);
    process($input);
    verify($input->response === $response, 'No eligible changes means identical response instance and bytes');
    Enricher::$change = true;
    Enricher::$throw = true;
    $input = inputFor($response);
    process($input);
    verify($input->response === $response && Diagnostics::$failures === 1, 'Lookup failure must log and retain the original response');
    Enricher::$throw = false;

    $malformed = new Response(200, ['Content-Type' => 'application/json'], '{malformed');
    $input = inputFor($malformed);
    process($input);
    verify($input->response === $malformed && Diagnostics::$failures === 2, 'Malformed JSON must log and retain the original response');

    $threwDownstream = false;
    try {
        (new LocationResponseMiddleware())->process(inputFor($response), static function (): void {
            throw new RuntimeException('Downstream failure');
        });
    } catch (RuntimeException $error) {
        $threwDownstream = $error->getMessage() === 'Downstream failure';
    }
    verify($threwDownstream && Diagnostics::$failures === 2, 'Do not swallow downstream GLPI failures');

    fwrite(STDOUT, "API middleware: {$checks} checks passed using actual GLPI classes.\n");
}
