<?php
declare(strict_types=1);

// Standalone tests for diagnostic configuration commands. Core persistence,
// sessions and report storage are explicit doubles; native CSRF is tested in GLPI.
namespace {
    const READ = 1;
    const UPDATE = 2;
    const ERROR = 3;

    function __(string $message, string $domain = ''): string { return $message; }
    function htmlescape(string $message): string { return htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); }

    class CommonGLPI {}
    class Config
    {
        public static array $values = [];
        public static function getConfigurationValues(string $context): array { return self::$values; }
        public static function setConfigurationValues(string $context, array $values): void
        {
            self::$values = array_replace(self::$values, $values);
        }
    }
    class Session
    {
        public static bool $allowed = true;
        public static array $messages = [];
        public static function checkRight(string $name, int $right): void
        {
            if (!self::$allowed || $name !== 'config' || $right !== UPDATE) {
                throw new RuntimeException('Permission denied');
            }
        }
        public static function addMessageAfterRedirect(string $message, bool $unused = false, int $type = 0): void
        {
            self::$messages[] = ['message' => $message, 'type' => $type];
        }
    }
    $DB = new class {
        public function request(array $query): array
        {
            return array_map(static fn ($id) => ['id' => $id], array_intersect([14, 15], $query['WHERE']['id']));
        }
    };
    require dirname(__DIR__) . '/src/Settings.php';
}

namespace GlpiPlugin\Locationdetails {
    final class Diagnostics
    {
        public static bool $clearResult = true;
        public static int $clearCalls = 0;
        public static function clear(): bool
        {
            self::$clearCalls++;
            return self::$clearResult;
        }
    }
}

namespace {
    require dirname(__DIR__) . '/src/Config.php';
    use GlpiPlugin\Locationdetails\Config as PluginConfig;
    use GlpiPlugin\Locationdetails\Diagnostics;
    use GlpiPlugin\Locationdetails\Settings;

    $checks = [];
    function check(bool $condition, string $name): void
    {
        global $checks;
        if (!$condition) { throw new RuntimeException($name); }
        $checks[] = $name;
    }
    function apply(array $input): array
    {
        $changes = PluginConfig::configUpdate($input);
        Config::setConfigurationValues(Settings::CONTEXT, $changes);
        return $changes;
    }

    check(Settings::defaults()['diagnostic_until'] === 0, 'capture disabled by default');
    check(Settings::normalize(['diagnostic_until' => '1800000000'])['diagnostic_until'] === 1800000000, 'stored timestamp normalizes to integer');
    foreach ([-1, '-1', 'bad', '99999999999999999999999999', [], null, true, 1.5] as $invalid) {
        check(Settings::normalize(['diagnostic_until' => $invalid])['diagnostic_until'] === 0, 'invalid timestamp disabled: ' . json_encode($invalid));
    }
    check(Settings::toStorage(['diagnostic_until' => 1800000000])['diagnostic_until'] === '1800000000', 'timestamp stored as string');

    $base = ['mode' => 'both', 'category_ids' => [14, 15], 'include_children' => false,
        'fields' => ['name', 'address', 'latitude'], 'diagnostic_until' => 0];
    Settings::save($base);
    $before = Settings::get();
    $startTime = time();
    $changes = apply(['_locationdetails_diagnostic_action' => 'start', 'mode' => 'off', 'category_ids' => []]);
    check(array_keys($changes) === ['diagnostic_until'], 'start changes only capture timestamp');
    check(Settings::get()['diagnostic_until'] >= $startTime + 1800
        && Settings::get()['diagnostic_until'] <= time() + 1800, 'start enables capture for thirty minutes');
    check(array_replace(Settings::get(), ['diagnostic_until' => 0]) === $before, 'start preserves enrichment settings despite injected fields');

    $activeUntil = Settings::get()['diagnostic_until'];
    $regular = ['mode' => 'api', 'category_ids' => ['14'], 'include_children' => '1',
        'fields' => ['name', 'room'], 'diagnostic_until' => '0', 'unexpected' => 'discard'];
    apply($regular);
    check(Settings::get()['mode'] === 'api' && Settings::get()['category_ids'] === [14], 'ordinary form still saves enrichment settings');
    check(Settings::get()['diagnostic_until'] === $activeUntil, 'ordinary form preserves active capture and ignores submitted timestamp');
    check(!isset(Config::$values['unexpected']), 'ordinary form discards unknown keys');

    $beforeStop = Settings::get();
    $changes = apply(['_locationdetails_diagnostic_action' => 'stop']);
    check($changes === ['diagnostic_until' => '0'], 'stop changes only capture timestamp');
    check(Settings::get() === array_replace($beforeStop, ['diagnostic_until' => 0]), 'stop preserves enrichment settings');
    $clearCalls = Diagnostics::$clearCalls;
    check($clearCalls === 0, 'start and stop retain diagnostic records');

    apply(['_locationdetails_diagnostic_action' => 'start']);
    $beforeClear = Settings::get();
    check(apply(['_locationdetails_diagnostic_action' => 'clear']) === [], 'clear writes no configuration keys');
    check(Diagnostics::$clearCalls === $clearCalls + 1, 'clear invokes record deletion once');
    check(Settings::get() === $beforeClear, 'clear preserves capture and enrichment settings');
    check(end(Session::$messages)['type'] !== ERROR, 'successful clear reports success');

    Diagnostics::$clearResult = false;
    apply(['_locationdetails_diagnostic_action' => 'clear']);
    check(end(Session::$messages)['type'] === ERROR, 'failed clear reports failure');
    check(Settings::get() === $beforeClear, 'failed clear preserves all settings');

    foreach (['invalid', ['start'], null] as $invalidAction) {
        check(apply(['_locationdetails_diagnostic_action' => $invalidAction]) === [], 'invalid action rejected: ' . json_encode($invalidAction));
        check(Settings::get() === $beforeClear, 'invalid action preserves configuration: ' . json_encode($invalidAction));
    }
    $beforeDeniedClear = Diagnostics::$clearCalls;
    Session::$allowed = false;
    $denied = false;
    try { apply(['_locationdetails_diagnostic_action' => 'clear']); }
    catch (RuntimeException $e) { $denied = $e->getMessage() === 'Permission denied'; }
    check($denied && Diagnostics::$clearCalls === $beforeDeniedClear, 'diagnostic commands require config UPDATE before side effects');

    echo json_encode(['passed' => count($checks), 'checks' => $checks], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), "\n";
}
