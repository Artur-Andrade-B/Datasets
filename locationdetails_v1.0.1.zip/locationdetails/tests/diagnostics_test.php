<?php
declare(strict_types=1);

use GlpiPlugin\Locationdetails\Diagnostics;
use GlpiPlugin\Locationdetails\Settings;

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

// Isolated storage tests: only native configuration/logging are doubled. No DB,
// GLPI bootstrap, installation settings or production log directory is accessed.
final class Config
{
    public static array $values = [];
    public static int $reads = 0;
    public static function getConfigurationValues(string $context): array
    {
        if ($context !== 'plugin:locationdetails') {
            throw new RuntimeException('Unexpected configuration context');
        }
        ++self::$reads;
        return self::$values;
    }
}

final class Toolbox
{
    public static array $messages = [];
    public static bool $throw = false;
    public static function logInFile(string $name, string $message): void
    {
        if (self::$throw) {
            throw new RuntimeException('Synthetic logging failure');
        }
        self::$messages[] = [$name, $message];
    }
}

// Exercise warning-based I/O failures in a fresh process because GLPI_LOG_DIR
// is immutable. The custom stream does not touch the filesystem.
if (($argv[1] ?? '') === '--full-stream') {
    final class FullDiagnosticStream
    {
        public mixed $context;
        public static int $writes = 0;
        public static int $truncates = 0;
        public function stream_open(string $path, string $mode, int $options, ?string &$openedPath): bool { return true; }
        public function stream_lock(int $operation): bool { return true; }
        public function stream_stat(): array { return ['size' => 0, 'mode' => 0100600]; }
        public function url_stat(string $path, int $flags): array { return $this->stream_stat(); }
        public function stream_seek(int $offset, int $whence): bool { return true; }
        public function stream_tell(): int { return 0; }
        public function stream_write(string $data): int
        {
            ++self::$writes;
            trigger_error('Synthetic storage full while writing', E_USER_WARNING);
            return 0;
        }
        public function stream_truncate(int $size): bool
        {
            ++self::$truncates;
            trigger_error('Synthetic truncate failure', E_USER_WARNING);
            return false;
        }
        public function stream_read(int $count): string { return ''; }
        public function stream_eof(): bool { return true; }
        public function stream_close(): void {}
    }
    stream_wrapper_register('locationdetailsfull', FullDiagnosticStream::class);
    define('GLPI_LOG_DIR', 'locationdetailsfull://logs');
    require dirname(__DIR__) . '/inc/autoload.php';
    $warnings = 0;
    set_error_handler(static function (int $severity, string $message) use (&$warnings): bool {
        ++$warnings;
        // Models GLPI's reporting behavior: suppressed warnings must never add
        // visible HTML/text to a JSON response or interfere with the operation.
        if (error_reporting() & $severity) {
            echo "UNSUPPRESSED_STORAGE_WARNING\n";
        }
        return true;
    });
    ob_start();
    $start = microtime(true);
    Diagnostics::start('synthetic_full_disk', ['diagnostic_until' => time() + 60]);
    Diagnostics::event('api.middleware_entered');
    $cleared = Diagnostics::clear();
    $output = ob_get_clean();
    $elapsed = microtime(true) - $start;
    // Prevent the registered shutdown handler from writing after restoration.
    (new ReflectionProperty(Diagnostics::class, 'active'))->setValue(null, false);
    restore_error_handler();
    if ($output !== '' || $warnings < 1 || FullDiagnosticStream::$writes < 1
        || FullDiagnosticStream::$truncates < 1 || $cleared || $elapsed >= 1.0) {
        throw new RuntimeException('Storage warning suppression, failure return or nonblocking behavior failed');
    }
    echo "Full-storage stream checks passed.\n";
    exit;
}

$testRoot = sys_get_temp_dir() . '/locationdetails-diagnostics-' . bin2hex(random_bytes(8));
if (!mkdir($testRoot, 0700) || !mkdir($testRoot . '/logs', 0700)) {
    throw new RuntimeException('Unable to create isolated test directory');
}
define('GLPI_LOG_DIR', $testRoot . '/logs');
define('GLPI_VERSION', '11.0.7-test');
define('PLUGIN_LOCATIONDETAILS_VERSION', 'diagnostics-test');
require dirname(__DIR__) . '/inc/autoload.php';

$path = GLPI_LOG_DIR . '/locationdetails-diagnostic.jsonl';
$checks = 0;

function verify(bool $ok, string $message): void
{
    global $checks;
    ++$checks;
    if (!$ok) {
        throw new RuntimeException($message);
    }
}

/** Begin another synthetic request without changing the public implementation. */
function resetRequest(): void
{
    $class = new ReflectionClass(Diagnostics::class);
    foreach ($class->getDefaultProperties() as $name => $value) {
        $class->getProperty($name)->setValue(null, $value);
    }
}

function activeConfig(): array
{
    return Settings::normalize([
        'mode' => 'both', 'category_ids' => [14, 15], 'include_children' => false,
        'fields' => ['name', 'latitude'], 'diagnostic_until' => time() + 600,
    ]);
}

function records(): array
{
    global $path;
    clearstatcache(true, $path);
    if (!is_file($path) || filesize($path) === 0) {
        return [];
    }
    return array_map(static fn(string $line): array => json_decode($line, true, 512, JSON_THROW_ON_ERROR),
        file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES));
}

function caughtError(string $message, string $secretArgument): Throwable
{
    try {
        throw new RuntimeException($message, 1054);
    } catch (Throwable $error) {
        return $error;
    }
}

$lock = null;
try {
    Diagnostics::start('api_request', Settings::defaults());
    Diagnostics::event('should.not.exist', ['ticket_id' => 1]);
    verify(!file_exists($path), 'Disabled capture must not create a diagnostic file');
    resetRequest();
    Diagnostics::start('api_request', ['diagnostic_until' => time() - 1]);
    Diagnostics::event('should.not.exist');
    verify(!file_exists($path), 'Expired capture must not create a diagnostic file');
    verify(Diagnostics::clear() && !file_exists($path), 'Clearing absent logs is successful without creating a file');

    resetRequest();
    Config::$values = activeConfig();
    $_SERVER['REQUEST_URI'] = '/front/ticket.form.php?id=1';
    $_SERVER['REQUEST_METHOD'] = 'GET';
    Diagnostics::onPluginInit();
    $_SERVER['REQUEST_URI'] = '/api.php/Assistance/Ticket';
    $_SERVER['REQUEST_METHOD'] = 'POST';
    Diagnostics::onPluginInit();
    verify(Config::$reads === 0, 'Unrelated pages and writes do not query diagnostic settings during initialization');
    $_SERVER['REQUEST_METHOD'] = 'GET';
    $_SERVER['REQUEST_URI'] = '/glpi/api.php/Assistance/Ticket?filter=id==236304&token=URL_SECRET';
    Diagnostics::onPluginInit();
    $initial = records();
    verify(Config::$reads === 1 && count($initial) === 2, 'Ticket API initialization reads settings once and records capture and registration');
    verify($initial[0]['event'] === 'capture.started' && $initial[1]['event'] === 'plugin.initialized', 'Initialization evidence records the expected stages');
    verify($initial[0]['data']['glpi_version'] === GLPI_VERSION && $initial[0]['data']['php_version'] === PHP_VERSION,
        'Capture identifies the executing GLPI and PHP versions');
    verify($initial[0]['data']['mode'] === 'both' && $initial[0]['data']['category_ids'] === [14, 15],
        'Capture records the effective mode and category selection');
    verify(preg_match('/^[a-f0-9]{16}$/', $initial[0]['request']) === 1 && $initial[0]['request'] === $initial[1]['request'],
        'Records from a request share a correlation identifier');
    Diagnostics::start('ignored_second_start', activeConfig());
    verify(count(records()) === 2, 'Repeated start does not emit a second capture record');

    $secrets = ['BODY_SECRET', 'PASSWORD_SECRET', 'TOKEN_SECRET', 'RAW_SQL_SECRET', 'LOCATION_SECRET', 'URL_SECRET'];
    Diagnostics::event('api.engine_entered', [
        'ticket_id' => '236304', 'category_id' => 14, 'location_id' => 17, 'entity_id' => 0,
        'visible' => true, 'changed' => '0', 'reason' => 'eligible',
        'content' => $secrets[0], 'password' => $secrets[1], 'authorization' => $secrets[2],
        'query' => $secrets[3], 'address' => $secrets[4], 'nested' => ['password' => $secrets[1]],
        'fields' => ['latitude', 'name', 'PASSWORD_SECRET'],
        'ticket_ids' => [17, '18', 'PASSWORD_SECRET'],
    ]);
    $metadata = records()[2]['data'];
    verify($metadata['ticket_id'] === 236304 && $metadata['entity_id'] === 0 && $metadata['changed'] === false,
        'Numeric identifiers including root entity and false values remain useful metadata');
    verify($metadata['fields'] === ['name', 'latitude'] && $metadata['ticket_ids'] === [17, 18],
        'Metadata lists reject unknown fields and nonnumeric identifiers');
    $raw = file_get_contents($path);
    verify(array_filter($secrets, static fn(string $secret): bool => str_contains($raw, $secret)) === [],
        'Capture does not retain arbitrary request bodies, credentials, SQL, URLs or location values');

    Diagnostics::failure('api_location_lookup', caughtError(
        'MySQL query error: unknown column (1054) in SQL query SELECT RAW_SQL_SECRET', 'ARGUMENT_SECRET'));
    Diagnostics::failure('api_call', new Error('Call to undefined method Sample\\Lookup::missing() PASSWORD_SECRET'));
    Diagnostics::failure('api_types', new TypeError('BODY_SECRET'));
    Diagnostics::failure('api_json', new JsonException('TOKEN_SECRET'));
    $failures = array_values(array_filter(records(), static fn(array $record): bool => $record['event'] === 'operation.failed'));
    verify(count($failures) === 4, 'Failures are recorded independently of native log file settings');
    verify(array_column(array_column($failures, 'data'), 'error_hint') === [
        'database_error_1054', 'undefined_callable Sample\\Lookup::missing', 'type_mismatch', 'json_processing_failed',
    ], 'Failure hints retain actionable error types without full exception messages');
    verify($failures[0]['data']['line'] > 0 && $failures[0]['data']['file'] === 'locationdetails/tests/diagnostics_test.php'
        && count($failures[0]['data']['frames']) > 0, 'Failures retain source file, line and stack call sites');
    $raw = file_get_contents($path) . json_encode(Toolbox::$messages);
    verify(array_filter([...$secrets, 'ARGUMENT_SECRET'], static fn(string $secret): bool => str_contains($raw, $secret)) === [],
        'Exception messages and stack arguments never enter diagnostic or fallback logs');
    verify(count(Toolbox::$messages) === 4 && Toolbox::$messages[0][0] === 'locationdetails', 'Lightweight native failure logging remains available');
    Toolbox::$throw = true;
    Diagnostics::failure('api_logging_failure', new RuntimeException('PASSWORD_SECRET'));
    verify(count(records()) === 8, 'Native logging failures do not escape the reporter or discard captured evidence');
    Toolbox::$throw = false;

    $report = Diagnostics::adminReport();
    verify($report['enabled'] && str_contains($report['text'], 'api.engine_entered')
        && str_contains($report['text'], '"category_ids":[14,15]'), 'Admin report includes effective settings and captured evidence');
    verify(!str_contains($report['text'], 'PASSWORD_SECRET'), 'Admin report excludes secret exception values');
    verify(Diagnostics::clear(), 'Admin clear succeeds for an unlocked diagnostic log');
    clearstatcache(true, $path);
    verify(filesize($path) === 0 && records() === [], 'Clear truncates all captured records');

    resetRequest();
    Diagnostics::start('bounded_request', activeConfig());
    for ($i = 0; $i < Diagnostics::MAX_EVENTS + 50; ++$i) {
        Diagnostics::event('ticket.checked', ['ticket_id' => $i]);
    }
    $limited = records();
    verify(count($limited) === Diagnostics::MAX_EVENTS + 1, 'Per-request limit stores at most MAX_EVENTS records plus one truncation notice');
    verify(end($limited)['event'] === 'capture.truncated' && end($limited)['data']['reason'] === 'per_request_event_limit',
        'Per-request event truncation is explicitly identified');

    Diagnostics::clear();
    $maximumObserved = 0;
    for ($batch = 0; $batch < 8; ++$batch) {
        resetRequest();
        Diagnostics::start('retention_test', activeConfig());
        for ($i = 0; $i < 80; ++$i) {
            Diagnostics::event('ticket.checked', ['ticket_id' => $batch * 80 + $i,
                'stage' => str_repeat('s', 210), 'reason' => str_repeat('r', 210), 'operation' => str_repeat('o', 210)]);
            clearstatcache(true, $path);
            $maximumObserved = max($maximumObserved, filesize($path));
        }
    }
    $retained = records(); // JSON_THROW_ON_ERROR verifies that retained records are whole.
    verify($maximumObserved <= Diagnostics::MAX_BYTES, 'Log remains within MAX_BYTES throughout repeated request writes');
    verify(count($retained) < 640 && end($retained)['data']['ticket_id'] === 639,
        'Bounded retention discards older data and preserves newest complete records');
    verify(!in_array(0, array_column(array_column($retained, 'data'), 'ticket_id'), true), 'Oldest ticket evidence is removed when retention rotates');
    $recent = Diagnostics::adminReport();
    verify(str_contains($recent['text'], '"ticket_id":639'), 'Admin report exposes the newest retained evidence');

    $lock = fopen($path, 'r+b');
    if ($lock === false || !flock($lock, LOCK_EX | LOCK_NB)) {
        throw new RuntimeException('Unable to obtain synthetic competing file lock');
    }
    $before = file_get_contents($path);
    $start = microtime(true);
    Diagnostics::event('locked.record');
    $clearLocked = Diagnostics::clear();
    $lockedReport = Diagnostics::adminReport();
    $elapsed = microtime(true) - $start;
    verify($elapsed < 1.0, 'Competing file lock never blocks request processing or admin report');
    verify(!$clearLocked && file_get_contents($path) === $before, 'Competing lock does not clear or append to the log');
    verify(str_contains($lockedReport['storage_status'], 'Arquivo em uso'), 'Admin report identifies temporarily locked storage');
    flock($lock, LOCK_UN);
    fclose($lock);
    $lock = null;
    Diagnostics::event('unlocked.record');
    $unlocked = records();
    verify(end($unlocked)['event'] === 'unlocked.record', 'Capture resumes after the competing writer releases its lock');

    // A regular file in place of the log directory reliably causes ENOTDIR even
    // when the tests run as root, unlike chmod-based permission simulations.
    rename(GLPI_LOG_DIR, $testRoot . '/saved-logs');
    file_put_contents(GLPI_LOG_DIR, 'synthetic unavailable directory');
    resetRequest();
    Diagnostics::start('unavailable_storage', activeConfig());
    Diagnostics::event('should.fail.open');
    Diagnostics::failure('unavailable_storage', new RuntimeException('TOKEN_SECRET'));
    verify(!Diagnostics::clear(), 'Unavailable storage causes admin clear to report failure');
    $unavailable = Diagnostics::adminReport();
    verify(str_contains($unavailable['storage_status'], 'não pode gravar'), 'Admin report explains unavailable capture storage');
    verify(file_get_contents(GLPI_LOG_DIR) === 'synthetic unavailable directory', 'Storage failure leaves unrelated files untouched and operations return normally');
    unlink(GLPI_LOG_DIR);
    rename($testRoot . '/saved-logs', GLPI_LOG_DIR);

    // Expiration after capture has already started also stops subsequent writes.
    resetRequest();
    Diagnostics::start('expires_mid_request', activeConfig());
    $before = file_get_contents($path);
    (new ReflectionProperty(Diagnostics::class, 'until'))->setValue(null, time() - 1);
    Diagnostics::event('after.expiration');
    verify(file_get_contents($path) === $before, 'Capture stops writing immediately when the configured expiry is reached');
    Config::$values['diagnostic_until'] = time() - 1;
    verify(!Diagnostics::adminReport()['enabled'], 'Admin status identifies expired capture without discarding existing evidence');
    verify(Diagnostics::clear(), 'Diagnostic history can still be cleared after capture expires');

    $command = [PHP_BINARY];
    if (php_ini_loaded_file() !== false) {
        array_push($command, '-c', php_ini_loaded_file());
    }
    array_push($command, __FILE__, '--full-stream');
    $pipes = [];
    $process = proc_open($command, [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
    if (!is_resource($process)) {
        throw new RuntimeException('Unable to start isolated warning-stream test');
    }
    fclose($pipes[0]);
    $stdout = stream_get_contents($pipes[1]);
    $stderr = stream_get_contents($pipes[2]);
    fclose($pipes[1]);
    fclose($pipes[2]);
    $exitCode = proc_close($process);
    verify($exitCode === 0 && $stdout === "Full-storage stream checks passed.\n" && $stderr === '',
        'Warning-emitting full storage fails open without response output, blocking or false clear success: ' . $stdout . $stderr);

    echo "Diagnostics storage tests passed: $checks checks.\n";
} finally {
    resetRequest(); // Also makes registered shutdown callbacks inert before cleanup.
    if (is_resource($lock)) {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
    if (is_file(GLPI_LOG_DIR)) {
        unlink(GLPI_LOG_DIR);
    }
    foreach ([GLPI_LOG_DIR, $testRoot . '/saved-logs'] as $directory) {
        if (is_dir($directory)) {
            foreach (glob($directory . '/*') ?: [] as $file) {
                unlink($file);
            }
            rmdir($directory);
        }
    }
    rmdir($testRoot);
}
