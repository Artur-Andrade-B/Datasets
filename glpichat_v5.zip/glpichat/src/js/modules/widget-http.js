/**
 * Widget HTTP Module
 * Handles shared-lane and explicitly isolated fetch requests, CSRF
 * synchronization and privacy-safe request diagnostics.
 */

let csrfToken = "";
let csrfRevision = 0;
let requestCounter = 0;

export class HttpRequestError extends Error {
  constructor(message, details = {}) {
    super(message);
    this.name = "HttpRequestError";
    this.requestId = String(details.requestId || "");
    this.status = Number(details.status || 0);
    this.kind = String(details.kind || "request_failed");
  }
}

export const setCsrfToken = (token) => {
  csrfToken = String(token || "");
  csrfRevision += 1;
};

export const getCsrfToken = () => csrfToken;

const createRequestId = () => {
  requestCounter = (requestCounter + 1) % 0x1000000;

  try {
    const bytes = new Uint8Array(8);
    globalThis.crypto.getRandomValues(bytes);
    return Array.from(bytes, (value) => value.toString(16).padStart(2, "0")).join("");
  } catch (_error) {
    const timePart = Date.now().toString(16).slice(-10).padStart(10, "0");
    const counterPart = requestCounter.toString(16).padStart(6, "0");
    return `${timePart}${counterPart}`;
  }
};

const elapsedMs = (startedAt) => Math.max(0, Math.round(performance.now() - startedAt));

const normalizeRequestId = (candidate, fallback) => {
  const value = String(candidate || "");
  return /^[a-zA-Z0-9_-]{8,64}$/.test(value) ? value : fallback;
};

let activeRequestPromise = Promise.resolve();

/**
 * Perform a JSON fetch request on the serialized shared lane by default.
 *
 * Client-only options are removed before native fetch():
 * - requestLabel: privacy-safe operation name used in Console diagnostics.
 * - onStart: observes actual dispatch after the serialized queue is released.
 * - queueSlowAfterMs/onQueueSlow: observes local queue congestion only.
 * - slowAfterMs/onSlow: observes server/network time after actual dispatch.
 * - maxQueueWaitMs: expires a request only while it is still waiting to be
 *   dispatched, so stale work cannot start after a long queue blockage.
 * - useSharedQueue: defaults to true; false selects an isolated request lane.
 * - waitForSharedQueue: for an isolated request, capture the current shared
 *   tail as a predecessor without making the isolated request the new tail.
 */
export const fetchJson = (url, options = {}) => {
  const {
    requestLabel = "request",
    onStart = null,
    queueSlowAfterMs = 0,
    onQueueSlow = null,
    slowAfterMs = 0,
    onSlow = null,
    maxQueueWaitMs = 0,
    useSharedQueue = true,
    waitForSharedQueue = false,
    ...nativeOptions
  } = options || {};

  const requestId = createRequestId();
  const queuedAt = performance.now();
  const safeLabel = String(requestLabel || "request").slice(0, 64);
  let dispatched = false;
  let settled = false;
  let queueExpired = false;
  let slowTimer = null;
  let queueSlowTimer = null;
  let queueTimer = null;

  console.info(`[GLPI Chat][${requestId}] queued`, {
    operation: safeLabel,
  });

  if (useSharedQueue !== false && Number(queueSlowAfterMs) > 0) {
    queueSlowTimer = window.setTimeout(() => {
      if (settled) {
        return;
      }

      const diagnostic = {
        requestId,
        operation: safeLabel,
        elapsedMs: elapsedMs(queuedAt),
        phase: "queued",
      };
      console.warn(`[GLPI Chat][${requestId}] queue slow`, diagnostic);
      if (typeof onQueueSlow === "function") {
        try {
          onQueueSlow(diagnostic);
        } catch (_callbackError) {
          console.error(`[GLPI Chat][${requestId}] queue callback failed`, {
            operation: safeLabel,
            kind: "callback_error",
          });
        }
      }
    }, Number(queueSlowAfterMs));
  }

  const queueExpiryPromise = useSharedQueue !== false && Number(maxQueueWaitMs) > 0
    ? new Promise((_, reject) => {
        queueTimer = window.setTimeout(() => {
          if (settled || dispatched) {
            return;
          }
          queueExpired = true;
          reject(new HttpRequestError(
            "Request expired before it reached the server.",
            { requestId, kind: "queue_expired" }
          ));
        }, Number(maxQueueWaitMs));
      })
    : null;

  const sharedTailAtAdmission = activeRequestPromise;
  const queuePredecessor = useSharedQueue === false
    ? (waitForSharedQueue === true ? sharedTailAtAdmission : Promise.resolve())
    : sharedTailAtAdmission;
  const executionPromise = queuePredecessor.then(async () => {
    if (queueExpired) {
      throw new HttpRequestError(
        "Request expired before it reached the server.",
        { requestId, kind: "queue_expired" }
      );
    }

    dispatched = true;
    if (queueSlowTimer !== null) {
      window.clearTimeout(queueSlowTimer);
      queueSlowTimer = null;
    }
    if (queueTimer !== null) {
      window.clearTimeout(queueTimer);
      queueTimer = null;
    }

    if (Number(slowAfterMs) > 0) {
      const activeStartedAt = performance.now();
      slowTimer = window.setTimeout(() => {
        if (settled) {
          return;
        }

        const diagnostic = {
          requestId,
          operation: safeLabel,
          elapsedMs: elapsedMs(activeStartedAt),
          phase: "active",
        };
        console.warn(`[GLPI Chat][${requestId}] slow`, diagnostic);
        if (typeof onSlow === "function") {
          try {
            onSlow(diagnostic);
          } catch (_callbackError) {
            console.error(`[GLPI Chat][${requestId}] slow callback failed`, {
              operation: safeLabel,
              kind: "callback_error",
            });
          }
        }
      }, Number(slowAfterMs));
    }

    const requestOptions = {
      credentials: "same-origin",
      ...nativeOptions,
    };
    const dispatchedCsrfRevision = csrfRevision;
    const dispatchedCsrfToken = csrfToken;
    const headers = new Headers(requestOptions.headers || {});
    headers.set("X-Requested-With", "XMLHttpRequest");
    headers.set("Accept", "application/json");
    headers.set("X-Glpichat-Trace-Id", requestId);
    if (dispatchedCsrfToken) {
      headers.set("X-Glpi-Csrf-Token", dispatchedCsrfToken);
    }
    requestOptions.headers = headers;

    if (requestOptions.body instanceof FormData) {
      if (requestOptions.body.has("_glpi_csrf_token") && dispatchedCsrfToken) {
        requestOptions.body.set("_glpi_csrf_token", dispatchedCsrfToken);
      }
    }

    console.info(`[GLPI Chat][${requestId}] start`, {
      operation: safeLabel,
      queueMs: elapsedMs(queuedAt),
    });
    if (typeof onStart === "function") {
      try {
        onStart({
          requestId,
          operation: safeLabel,
          queueMs: elapsedMs(queuedAt),
          phase: "active",
        });
      } catch (_callbackError) {
        console.error(`[GLPI Chat][${requestId}] start callback failed`, {
          operation: safeLabel,
          kind: "callback_error",
        });
      }
    }

    let response;
    try {
      response = await fetch(url, requestOptions);
    } catch (_error) {
      throw new HttpRequestError(
        "Network request failed.",
        { requestId, kind: "network_error" }
      );
    }

    const serverTraceId = normalizeRequestId(
      response.headers.get("X-Glpichat-Trace-Id"),
      requestId
    );
    let responseText;
    try {
      responseText = await response.text();
    } catch (_error) {
      throw new HttpRequestError(
        "Network response could not be read.",
        {
          requestId: serverTraceId,
          status: response.status,
          kind: "network_error",
        }
      );
    }
    let data = {};
    let responseIsJson = responseText === "";
    if (responseText !== "") {
      try {
        data = JSON.parse(responseText);
        responseIsJson = true;
      } catch (_error) {
        // A reverse proxy commonly returns an HTML error page for 502/503/504.
        // Preserve that HTTP failure below instead of misreporting it as a
        // successful-response JSON protocol error. The raw body is discarded.
        responseIsJson = false;
      }
    }

    if (!response.ok) {
      const responseObject = data && typeof data === "object" ? data : {};
      const failureKind = response.status === 504
        ? "gateway_timeout"
        : (response.status === 502 || response.status === 503)
          ? "gateway_unavailable"
          : "http_error";
      const errorMsg =
        responseIsJson && (typeof responseObject.message === "string" && responseObject.message !== "")
          ? responseObject.message
          : responseIsJson && (typeof responseObject.error === "string" && responseObject.error !== "")
            ? responseObject.error
            : "Request failed.";
      throw new HttpRequestError(errorMsg, {
        requestId: responseIsJson
          ? normalizeRequestId(responseObject._glpichat_trace_id, serverTraceId)
          : serverTraceId,
        status: response.status,
        kind: failureKind,
      });
    }

    if (!responseIsJson) {
      throw new HttpRequestError(
        `Unexpected response format (${response.status}).`,
        {
          requestId: serverTraceId,
          status: response.status,
          kind: "invalid_json",
        }
      );
    }

    if (
      data
      && typeof data === "object"
      && data._glpi_csrf_token
      && csrfRevision === dispatchedCsrfRevision
    ) {
      csrfToken = String(data._glpi_csrf_token);
      csrfRevision += 1;
    }

    console.info(`[GLPI Chat][${serverTraceId}] complete`, {
      operation: safeLabel,
      status: response.status,
      elapsedMs: elapsedMs(queuedAt),
    });
    return data;
  });

  if (useSharedQueue !== false) {
    activeRequestPromise = executionPromise.catch(() => {});
  }
  const callerPromise = queueExpiryPromise
    ? Promise.race([executionPromise, queueExpiryPromise])
    : executionPromise;

  return callerPromise.catch((error) => {
    const normalizedError = error instanceof HttpRequestError
      ? error
      : new HttpRequestError("Request failed.", {
          requestId,
          kind: "request_failed",
        });
    console.error(`[GLPI Chat][${normalizedError.requestId || requestId}] failed`, {
      operation: safeLabel,
      status: normalizedError.status,
      kind: normalizedError.kind,
      elapsedMs: elapsedMs(queuedAt),
    });
    throw normalizedError;
  }).finally(() => {
    settled = true;
    if (slowTimer !== null) {
      window.clearTimeout(slowTimer);
    }
    if (queueSlowTimer !== null) {
      window.clearTimeout(queueSlowTimer);
    }
    if (queueTimer !== null) {
      window.clearTimeout(queueTimer);
    }
  });
};

export const postForm = (url, formData, requestOptions = {}) => fetchJson(url, {
  method: "POST",
  body: formData,
  credentials: "same-origin",
  ...requestOptions,
});

/**
 * Send a small best-effort mutation without joining the shared widget queue.
 *
 * This path is intentionally opt-in. It is suitable for explicit presence
 * teardown where waiting behind a slow Leave must never block History, Poll,
 * Channels or native GLPI navigation. Dispatched work is never aborted and
 * callers observe its real fetch/proxy settlement.
 */
export const postFormBestEffort = (url, formData, requestOptions = {}) => {
  return fetchJson(url, {
    ...(requestOptions || {}),
    method: "POST",
    body: formData,
    credentials: "same-origin",
    keepalive: true,
    useSharedQueue: false,
    waitForSharedQueue: true,
  });
};
