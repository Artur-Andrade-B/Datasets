<?php

declare(strict_types=1);

require dirname(__DIR__, 2) . '/bootstrap/unit.php';
require_once dirname(__DIR__, 3) . '/src/diagnostics.php';

$plugin_root = dirname(__DIR__, 3);
$controller = file_get_contents($plugin_root . '/src/Controller/WidgetController.php');
$diagnostics = file_get_contents($plugin_root . '/src/diagnostics.php');
$functions = file_get_contents($plugin_root . '/src/functions.php');

if (!is_string($controller) || !is_string($diagnostics) || !is_string($functions)) {
    glpichat_unit_fail('Unable to read perf4 Leave source contracts.');
}

$leave_start = strpos($controller, 'public function leave(Request $request): Response');
if ($leave_start === false) {
    glpichat_unit_fail('Widget Leave controller is missing.');
}
$leave = substr($controller, $leave_start);

$started_at = strpos($leave, '$started_at = glpichat_diagnostic_started_at()');
$trace_id = strpos($leave, '$trace_id = glpichat_diagnostic_trace_id(');
$csrf_check = strpos($leave, 'glpichat_require_logged_csrf($input)');
$user_capture = strpos($leave, '$users_id = glpichat_current_user_id()');
$room_validation = strpos($leave, 'glpichat_widget_readable_room_or_fail(');
$csrf_capture = strpos($leave, '$csrf_token = Session::getNewCSRFToken()');
$session_release = strpos($leave, '$session_released = glpichat_release_session_lock()');
$disconnect = strpos($leave, 'glpichat_disconnect_user_participant(');

foreach ([
    $started_at,
    $trace_id,
    $csrf_check,
    $user_capture,
    $room_validation,
    $csrf_capture,
    $session_release,
    $disconnect,
] as $position) {
    if ($position === false) {
        glpichat_unit_fail('Perf4 Leave session/diagnostic boundary is incomplete.');
    }
}

if (!(
    $started_at < $csrf_check
    && $trace_id < $csrf_check
    && $csrf_check < $user_capture
    && $user_capture < $room_validation
    && $room_validation < $csrf_capture
    && $csrf_capture < $session_release
    && $session_release < $disconnect
)) {
    glpichat_unit_fail('Leave must validate session/room and capture CSRF before releasing the session ahead of disconnect work.');
}
glpichat_unit_pass('Perf4 Leave releases the PHP session before disconnect/event/notification work');

$disconnect_function_start = strpos($functions, 'function glpichat_disconnect_user_participant(');
if ($disconnect_function_start === false) {
    glpichat_unit_fail('Unable to isolate the existing participant disconnect semantics.');
}
$disconnect_function_end = strpos($functions, 'function glpichat_expire_inactive_user_participants(', $disconnect_function_start);
if ($disconnect_function_end === false) {
    glpichat_unit_fail('Unable to isolate the existing participant disconnect semantics.');
}
$disconnect_function = substr($functions, $disconnect_function_start, $disconnect_function_end - $disconnect_function_start);
foreach ([
    "'left_at' => \$now",
    "'user_left'",
    'glpichat_record_event(',
    'glpichat_raise_user_left_notification_event($tickets_id, $user_name)',
] as $presence_contract) {
    if (!str_contains($disconnect_function, $presence_contract)) {
        glpichat_unit_fail('Perf4 Leave must preserve the existing presence/event/notification semantic: ' . $presence_contract);
    }
}
glpichat_unit_pass('Perf4 preserves explicit Leave presence, event and notification semantics');

if (
    !str_contains($disconnect_function, '?callable $phase_callback = null')
    || !str_contains($disconnect_function, 'try {')
    || !str_contains($disconnect_function, '$phase_callback($phase)')
    || !str_contains($disconnect_function, '// Diagnostics must never alter disconnect semantics.')
) {
    glpichat_unit_fail('Leave internal phase callback must remain optional and unable to alter disconnect behavior.');
}

$participant_update = strpos($disconnect_function, "\$DB->update('glpi_plugin_glpichat_participants'");
$participant_phase = strpos($disconnect_function, "\$emit_phase('participant_disconnected')");
$room_lookup = strpos($disconnect_function, 'glpichat_room_by_id($rooms_id)');
$room_phase = strpos($disconnect_function, "\$emit_phase('room_ready')");
$event_started = strpos($disconnect_function, "\$emit_phase('event_started')");
$event_call = strpos($disconnect_function, 'glpichat_record_event(');
$event_complete = strpos($disconnect_function, "\$emit_phase('event_complete')");
$notification_started = strpos($disconnect_function, "\$emit_phase('notification_started')");
$notification_call = strpos($disconnect_function, 'glpichat_raise_user_left_notification_event($tickets_id, $user_name)');
$notification_complete = strpos($disconnect_function, "\$emit_phase('notification_complete')");
foreach ([
    $participant_update,
    $participant_phase,
    $room_lookup,
    $room_phase,
    $event_started,
    $event_call,
    $event_complete,
    $notification_started,
    $notification_call,
    $notification_complete,
] as $position) {
    if ($position === false) {
        glpichat_unit_fail('Perf4 Leave is missing an internal disconnect diagnostic boundary.');
    }
}
if (!(
    $participant_update < $participant_phase
    && $participant_phase < $room_lookup
    && $room_lookup < $room_phase
    && $room_phase < $event_started
    && $event_started < $event_call
    && $event_call < $event_complete
    && $event_complete < $notification_started
    && $notification_started < $notification_call
    && $notification_call < $notification_complete
)) {
    glpichat_unit_fail('Internal Leave diagnostics must bracket participant, room, event and notification work in execution order.');
}
glpichat_unit_pass('Perf4 distinguishes participant, room, event and synchronous notification boundaries');

$disconnect_started = strpos($leave, "glpichat_diagnostic_log('widget_leave', 'disconnect_started'");
$disconnect_complete = strpos($leave, "glpichat_diagnostic_log('widget_leave', 'disconnect_complete'");
$complete = strpos($leave, "glpichat_diagnostic_log('widget_leave', 'complete'");
$diagnostic_response = strpos($leave, 'return glpichat_diagnostic_response($response, $trace_id, $started_at)');
$trace_payload = strpos($leave, "'_glpichat_trace_id' => \$trace_id");
foreach ([$disconnect_started, $disconnect_complete, $complete, $diagnostic_response, $trace_payload] as $position) {
    if ($position === false) {
        glpichat_unit_fail('Perf4 Leave response/phase diagnostics are incomplete.');
    }
}
if (
    !str_contains($leave, 'static function (string $phase) use (')
    || !str_contains($leave, "glpichat_diagnostic_log('widget_leave', \$phase")
    || !($session_release < $disconnect_started && $disconnect_started < $disconnect && $disconnect < $disconnect_complete && $disconnect_complete < $complete && $complete < $diagnostic_response)
) {
    glpichat_unit_fail('Leave diagnostics must bracket the post-release disconnect boundary and time the final response.');
}
glpichat_unit_pass('Perf4 Leave diagnostics identify a blocked disconnect without exposing room/user identity');

$runtime_catch = strpos($leave, '} catch (RuntimeException $e) {');
$throwable_catch = strpos($leave, '} catch (Throwable $e) {');
if ($runtime_catch === false || $throwable_catch === false || !($runtime_catch < $throwable_catch)) {
    glpichat_unit_fail('Perf4 Leave must handle rejected and unexpected failures separately.');
}
$runtime_handler = substr($leave, $runtime_catch, $throwable_catch - $runtime_catch);
$throwable_handler = substr($leave, $throwable_catch);
foreach ([$runtime_handler, $throwable_handler] as $handler) {
    if (
        !str_contains($handler, '$released_on_error = glpichat_release_session_lock()')
        || !str_contains($handler, "glpichat_diagnostic_log('widget_leave', 'runtime_error'")
        || !str_contains($handler, "'_glpichat_trace_id' => \$trace_id")
        || !str_contains($handler, 'glpichat_diagnostic_response(')
    ) {
        glpichat_unit_fail('Every Leave error path must release the session and return correlated diagnostics.');
    }
}
glpichat_unit_pass('Perf4 Leave releases and correlates both validation and unexpected error paths');

foreach ([
    'widget_leave',
    'disconnect_started',
    'participant_disconnected',
    'room_ready',
    'event_started',
    'event_complete',
    'notification_started',
    'notification_complete',
    'disconnect_complete',
] as $allowlisted_value) {
    if (!str_contains($diagnostics, "'{$allowlisted_value}'")) {
        glpichat_unit_fail('Missing perf4 Leave diagnostics allowlist value: ' . $allowlisted_value);
    }
}

$lines = [];
glpichat_diagnostic_log(
    'widget_leave',
    'notification_started',
    'leavetrace12345',
    glpichat_diagnostic_started_at(),
    [
        'session_released' => true,
        'last_phase' => 'notification_started',
        'rooms_id' => 912345,
        'users_id' => 923456,
        'tickets_id' => 934567,
        'user_name' => 'private-leave-user',
    ],
    static function (string $line) use (&$lines): void {
        $lines[] = $line;
    }
);

glpichat_unit_assert_same(1, count($lines), 'Leave diagnostics emits one closed-schema phase record');
$record = json_decode($lines[0], true, 512, JSON_THROW_ON_ERROR);
glpichat_unit_assert_same('widget_leave', $record['operation'] ?? null, 'Leave diagnostics keeps its allowlisted operation');
glpichat_unit_assert_same('notification_started', $record['phase'] ?? null, 'Leave diagnostics keeps its internal notification boundary');
glpichat_unit_assert_same(true, $record['session_released'] ?? null, 'Leave diagnostics proves the lock was released at the boundary');
glpichat_unit_assert_same('notification_started', $record['last_phase'] ?? null, 'Leave diagnostics retains only the safe phase marker');
foreach (['912345', '923456', '934567', 'private-leave-user', 'rooms_id', 'users_id', 'tickets_id', 'user_name'] as $forbidden) {
    if (str_contains($lines[0], $forbidden)) {
        glpichat_unit_fail('Leave diagnostics leaked a forbidden identity value: ' . $forbidden);
    }
}
glpichat_unit_pass('Perf4 Leave diagnostics remains privacy-safe');

fwrite(STDOUT, "[PASS] perf4 Leave session contract tests completed\n");
