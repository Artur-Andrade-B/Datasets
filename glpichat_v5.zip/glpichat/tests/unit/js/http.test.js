import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  fetchJson,
  getCsrfToken,
  HttpRequestError,
  postForm,
  postFormBestEffort,
  setCsrfToken
} from '../../../src/js/modules/widget-http.js';

const createJsonResponse = (payload, status = 200) => new Response(
  JSON.stringify(payload),
  {
    status,
    headers: {
      'Content-Type': 'application/json',
    },
  }
);

describe('HTTP Module', () => {
  beforeEach(() => {
    setCsrfToken('');
    vi.spyOn(console, 'info').mockImplementation(() => {});
    vi.spyOn(console, 'warn').mockImplementation(() => {});
    vi.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    vi.restoreAllMocks();
    vi.unstubAllGlobals();
    vi.useRealTimers();
    setCsrfToken('');
  });

  it('keeps the active CSRF token in module state', () => {
    setCsrfToken('token-123');
    expect(getCsrfToken()).toBe('token-123');
  });

  it('serializes headers, injects the CSRF token and refreshes it from the response', async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      createJsonResponse({
        ok: true,
        _glpi_csrf_token: 'token-456',
      })
    );
    vi.stubGlobal('fetch', fetchMock);

    const formData = new FormData();
    formData.set('_glpi_csrf_token', 'stale-token');
    formData.set('message', 'hello');

    setCsrfToken('token-123');

    const result = await fetchJson('/api/messages', {
      method: 'POST',
      headers: { 'X-Custom': 'value' },
      body: formData,
    });

    expect(result).toEqual({
      ok: true,
      _glpi_csrf_token: 'token-456',
    });
    expect(getCsrfToken()).toBe('token-456');
    expect(formData.get('_glpi_csrf_token')).toBe('token-123');
    expect(fetchMock).toHaveBeenCalledTimes(1);

    const [url, requestOptions] = fetchMock.mock.calls[0];
    expect(url).toBe('/api/messages');
    expect(requestOptions.method).toBe('POST');
    expect(requestOptions.credentials).toBe('same-origin');
    expect(requestOptions.headers).toBeInstanceOf(Headers);
    expect(requestOptions.headers.get('X-Requested-With')).toBe('XMLHttpRequest');
    expect(requestOptions.headers.get('Accept')).toBe('application/json');
    expect(requestOptions.headers.get('X-Custom')).toBe('value');
    expect(requestOptions.headers.get('X-Glpi-Csrf-Token')).toBe('token-123');
    expect(requestOptions.headers.get('X-Glpichat-Trace-Id')).toMatch(/^[a-f0-9]{16}$/);

    const visibleStates = console.info.mock.calls.map(([message]) => String(message));
    expect(visibleStates.some((message) => message.endsWith(' queued'))).toBe(true);
    expect(visibleStates.some((message) => message.endsWith(' start'))).toBe(true);
    expect(visibleStates.some((message) => message.endsWith(' complete'))).toBe(true);
  });

  it('serializes requests so the second fetch waits for the first one', async () => {
    let resolveFirst;
    const fetchMock = vi.fn()
      .mockImplementationOnce(() => new Promise((resolve) => {
        resolveFirst = resolve;
      }))
      .mockResolvedValueOnce(createJsonResponse({ second: true }));
    vi.stubGlobal('fetch', fetchMock);

    const firstPromise = fetchJson('/first');
    const secondPromise = fetchJson('/second');

    await Promise.resolve();
    expect(fetchMock).toHaveBeenCalledTimes(1);

    resolveFirst(createJsonResponse({ first: true }));
    await expect(firstPromise).resolves.toEqual({ first: true });

    await Promise.resolve();
    expect(fetchMock).toHaveBeenCalledTimes(2);
    await expect(secondPromise).resolves.toEqual({ second: true });
  });

  it('throws a canonical parse error when the body is not JSON', async () => {
    const fetchMock = vi.fn().mockResolvedValue(new Response('plain text body', {
      status: 200,
      headers: {
        'Content-Type': 'text/plain',
      },
    }));
    vi.stubGlobal('fetch', fetchMock);

    await expect(fetchJson('/broken')).rejects.toThrow('Unexpected response format (200).');
  });

  it('preserves an HTML 504 as a gateway timeout instead of invalid JSON', async () => {
    const fetchMock = vi.fn().mockResolvedValue(new Response('<html>Gateway Time-out</html>', {
      status: 504,
      headers: {
        'Content-Type': 'text/html',
      },
    }));
    vi.stubGlobal('fetch', fetchMock);

    await expect(fetchJson('/channels')).rejects.toMatchObject({
      name: 'HttpRequestError',
      status: 504,
      kind: 'gateway_timeout',
    });
    expect(console.error.mock.calls.at(-1)?.[1]).toMatchObject({
      status: 504,
      kind: 'gateway_timeout',
    });
    expect(JSON.stringify(console.error.mock.calls)).not.toContain('Gateway Time-out');
  });

  it.each([
    [502, 'gateway_unavailable'],
    [503, 'gateway_unavailable'],
  ])('preserves an HTML %i as %s', async (status, kind) => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response('<html>proxy failure</html>', {
      status,
      headers: { 'Content-Type': 'text/html' },
    })));

    await expect(fetchJson('/channels')).rejects.toMatchObject({ status, kind });
  });

  it('classifies a response-body read failure as a network error', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      headers: new Headers(),
      text: vi.fn().mockRejectedValue(new Error('stream interrupted')),
    }));

    await expect(fetchJson('/channels')).rejects.toMatchObject({
      name: 'HttpRequestError',
      status: 200,
      kind: 'network_error',
    });
    expect(JSON.stringify(console.error.mock.calls)).not.toContain('stream interrupted');
  });

  it('prefers the GLPI message field for failed responses', async () => {
    const fetchMock = vi.fn().mockResolvedValue(createJsonResponse({
      message: 'Request rejected by GLPI',
      error: true,
    }, 400));
    vi.stubGlobal('fetch', fetchMock);

    await expect(fetchJson('/denied')).rejects.toThrow('Request rejected by GLPI');
  });

  it('forwards POST FormData through the same fetch pipeline', async () => {
    const fetchMock = vi.fn().mockResolvedValue(createJsonResponse({ saved: true }));
    vi.stubGlobal('fetch', fetchMock);

    const formData = new FormData();
    formData.set('message', 'hello');

    await expect(postForm('/api/messages', formData, { keepalive: true })).resolves.toEqual({ saved: true });
    expect(fetchMock).toHaveBeenCalledTimes(1);

    const [, requestOptions] = fetchMock.mock.calls[0];
    expect(requestOptions.method).toBe('POST');
    expect(requestOptions.keepalive).toBe(true);
    expect(requestOptions.body).toBe(formData);
    expect(requestOptions.credentials).toBe('same-origin');
  });

  it('emits a soft slow diagnostic without aborting an active request', async () => {
    vi.useFakeTimers();
    let resolveFetch;
    const fetchMock = vi.fn(() => new Promise((resolve) => {
      resolveFetch = resolve;
    }));
    vi.stubGlobal('fetch', fetchMock);
    const onSlow = vi.fn();
    const onStart = vi.fn();

    const requestPromise = fetchJson('/history', {
      requestLabel: 'Widget/History',
      slowAfterMs: 1000,
      onStart,
      onSlow,
    });

    await Promise.resolve();
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(onStart).toHaveBeenCalledWith(expect.objectContaining({
      operation: 'Widget/History',
      phase: 'active',
    }));
    await vi.advanceTimersByTimeAsync(1000);

    expect(onSlow).toHaveBeenCalledTimes(1);
    expect(onSlow.mock.calls[0][0]).toMatchObject({
      operation: 'Widget/History',
      phase: 'active',
    });
    expect(fetchMock.mock.calls[0][1].signal).toBeUndefined();

    resolveFetch(createJsonResponse({ messages: [], events: [] }));
    await expect(requestPromise).resolves.toEqual({ messages: [], events: [] });
  });

  it('reports local queue congestion separately from active server time', async () => {
    vi.useFakeTimers();
    let resolveFirst;
    let resolveSecond;
    const fetchMock = vi.fn()
      .mockImplementationOnce(() => new Promise((resolve) => {
        resolveFirst = resolve;
      }))
      .mockImplementationOnce(() => new Promise((resolve) => {
        resolveSecond = resolve;
      }));
    vi.stubGlobal('fetch', fetchMock);

    const firstPromise = fetchJson('/first');
    const onQueueSlow = vi.fn();
    const onSlow = vi.fn();
    const secondPromise = fetchJson('/channels', {
      queueSlowAfterMs: 100,
      onQueueSlow,
      slowAfterMs: 100,
      onSlow,
    });

    await Promise.resolve();
    await vi.advanceTimersByTimeAsync(100);
    expect(onQueueSlow).toHaveBeenCalledWith(expect.objectContaining({ phase: 'queued' }));
    expect(onSlow).not.toHaveBeenCalled();

    resolveFirst(createJsonResponse({ first: true }));
    await expect(firstPromise).resolves.toEqual({ first: true });
    await Promise.resolve();
    expect(fetchMock).toHaveBeenCalledTimes(2);

    await vi.advanceTimersByTimeAsync(100);
    expect(onSlow).toHaveBeenCalledWith(expect.objectContaining({ phase: 'active' }));

    resolveSecond(createJsonResponse({ channels: [] }));
    await expect(secondPromise).resolves.toEqual({ channels: [] });
  });

  it('does not abort ordinary dispatched work when only queue admission is bounded', async () => {
    vi.useFakeTimers();
    let resolveFetch;
    const fetchMock = vi.fn((_url, options) => new Promise((resolve) => {
      expect(options.signal).toBeUndefined();
      resolveFetch = resolve;
    }));
    vi.stubGlobal('fetch', fetchMock);

    const requestPromise = fetchJson('/channels', {
      maxQueueWaitMs: 10,
      slowAfterMs: 20,
    });
    await Promise.resolve();
    await vi.advanceTimersByTimeAsync(120000);
    expect(fetchMock).toHaveBeenCalledTimes(1);

    resolveFetch(createJsonResponse({ channels: [] }));
    await expect(requestPromise).resolves.toEqual({ channels: [] });
  });

  it('orders Leave after the captured shared tail without making later reads wait for Leave', async () => {
    let resolveFirst;
    let resolveLeave;
    const fetchMock = vi.fn((url) => {
      if (url === '/first') {
        return new Promise((resolve) => {
          resolveFirst = resolve;
        });
      }
      if (url === '/leave') {
        return new Promise((resolve) => {
          resolveLeave = resolve;
        });
      }
      return Promise.resolve(createJsonResponse({ ok: true }));
    });
    vi.stubGlobal('fetch', fetchMock);

    const firstPromise = fetchJson('/first');
    const leaveData = new FormData();
    leaveData.set('_glpi_csrf_token', 'token');
    const leavePromise = postFormBestEffort('/leave', leaveData, {
      requestLabel: 'Widget/Leave',
    });
    const laterReadPromise = fetchJson('/later-read');

    await Promise.resolve();
    await Promise.resolve();
    expect(fetchMock).toHaveBeenCalledTimes(1);

    let leaveSettled = false;
    leavePromise.finally(() => {
      leaveSettled = true;
    });
    resolveFirst(createJsonResponse({ first: true }));
    await expect(firstPromise).resolves.toEqual({ first: true });
    await Promise.resolve();
    await Promise.resolve();

    expect(fetchMock.mock.calls.map(([url]) => url)).toEqual([
      '/first',
      '/leave',
      '/later-read',
    ]);
    await expect(laterReadPromise).resolves.toEqual({ ok: true });
    expect(leaveSettled).toBe(false);

    const [, leaveOptions] = fetchMock.mock.calls.find(([url]) => url === '/leave');
    expect(leaveOptions.keepalive).toBe(true);
    expect(leaveOptions.signal).toBeUndefined();

    resolveLeave(createJsonResponse({ ok: true }));
    await expect(leavePromise).resolves.toEqual({ ok: true });
  });

  it('never aborts an isolated Leave which may still complete in PHP', async () => {
    vi.useFakeTimers();
    let resolveLeave;
    const fetchMock = vi.fn((_url, options) => new Promise((resolve) => {
      expect(options.signal).toBeUndefined();
      resolveLeave = resolve;
    }));
    vi.stubGlobal('fetch', fetchMock);

    const fd = new FormData();
    fd.set('_glpi_csrf_token', 'token');
    const leavePromise = postFormBestEffort('/leave', fd);

    await Promise.resolve();
    await vi.advanceTimersByTimeAsync(120000);
    expect(fetchMock).toHaveBeenCalledTimes(1);

    resolveLeave(createJsonResponse({ ok: true }));
    await expect(leavePromise).resolves.toEqual({ ok: true });
  });

  it('does not let a late parallel Leave response overwrite a newer CSRF token', async () => {
    let resolvePredecessor;
    let resolveMain;
    let resolveLeave;
    const fetchMock = vi.fn((url) => new Promise((resolve) => {
      if (url === '/predecessor') {
        resolvePredecessor = resolve;
      } else if (url === '/main') {
        resolveMain = resolve;
      } else {
        resolveLeave = resolve;
      }
    }));
    vi.stubGlobal('fetch', fetchMock);
    setCsrfToken('token-initial');

    const predecessorPromise = fetchJson('/predecessor');
    const leaveData = new FormData();
    leaveData.set('_glpi_csrf_token', 'token-initial');
    const leavePromise = postFormBestEffort('/leave', leaveData);
    const mainPromise = fetchJson('/main');
    await Promise.resolve();
    await Promise.resolve();

    resolvePredecessor(createJsonResponse({ ok: true }));
    await predecessorPromise;
    await Promise.resolve();
    await Promise.resolve();
    resolveMain(createJsonResponse({ ok: true, _glpi_csrf_token: 'token-main' }));
    await expect(mainPromise).resolves.toMatchObject({ ok: true });
    expect(getCsrfToken()).toBe('token-main');

    resolveLeave(createJsonResponse({ ok: true, _glpi_csrf_token: 'token-leave-late' }));
    await expect(leavePromise).resolves.toMatchObject({ ok: true });
    expect(getCsrfToken()).toBe('token-main');
  });

  it('expires stale queued reads without dispatching a second server request', async () => {
    vi.useFakeTimers();
    let resolveFirst;
    const fetchMock = vi.fn()
      .mockImplementationOnce(() => new Promise((resolve) => {
        resolveFirst = resolve;
      }))
      .mockResolvedValueOnce(createJsonResponse({ should_not_run: true }));
    vi.stubGlobal('fetch', fetchMock);

    const firstPromise = fetchJson('/first');
    const queuedPromise = fetchJson('/history', {
      requestLabel: 'Widget/History',
      maxQueueWaitMs: 500,
    });
    const queuedExpectation = expect(queuedPromise).rejects.toMatchObject({
      name: 'HttpRequestError',
      kind: 'queue_expired',
    });

    await Promise.resolve();
    expect(fetchMock).toHaveBeenCalledTimes(1);
    await vi.advanceTimersByTimeAsync(500);

    await queuedExpectation;

    resolveFirst(createJsonResponse({ first: true }));
    await expect(firstPromise).resolves.toEqual({ first: true });
    await Promise.resolve();
    await Promise.resolve();
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it('exposes status, failure kind and correlation ID on HTTP errors', async () => {
    const fetchMock = vi.fn().mockResolvedValue(new Response(
      JSON.stringify({ error: 'denied', _glpichat_trace_id: 'servertrace1234' }),
      {
        status: 403,
        headers: {
          'Content-Type': 'application/json',
          'X-Glpichat-Trace-Id': 'servertrace1234',
        },
      }
    ));
    vi.stubGlobal('fetch', fetchMock);

    try {
      await fetchJson('/denied');
      throw new Error('Expected fetchJson to reject.');
    } catch (error) {
      expect(error).toBeInstanceOf(HttpRequestError);
      expect(error).toMatchObject({
        status: 403,
        kind: 'http_error',
        requestId: 'servertrace1234',
      });
    }
  });
});
