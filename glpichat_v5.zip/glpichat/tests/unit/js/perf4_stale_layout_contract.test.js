// @vitest-environment node

import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = resolve(import.meta.dirname, "../../..");
const css = readFileSync(resolve(root, "public/css/glpichat.css"), "utf8");
const widget = readFileSync(resolve(root, "src/js/glpichat-widget.js"), "utf8");

const ruleBody = (selector) => {
  const escapedSelector = selector.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const match = css.match(new RegExp(`${escapedSelector}\\s*\\{([^}]*)\\}`));
  expect(match, `missing CSS rule for ${selector}`).not.toBeNull();
  return match[1];
};

describe("perf4 stale launcher layout contract", () => {
  it("keeps progress, warning and filters intrinsic while the ticket list owns remaining space", () => {
    const notificationView = ruleBody(".glpichat-notification-view");
    const progress = ruleBody(".glpichat-discovery-refresh-progress");
    const warning = ruleBody(".glpichat-discovery-refresh-warning");
    const filters = ruleBody(".glpichat-status-filters");
    const ticketList = ruleBody(".glpichat-ticket-filter-list");

    expect(widget).toContain('class="glpichat-discovery-refresh-progress"');
    expect(widget).toContain('class="glpichat-discovery-refresh-warning"');
    expect(widget).toContain('class="glpichat-status-filters"');
    expect(widget).toContain('class="glpichat-ticket-filter-list"');
    expect(widget).toContain("`${refreshProgress}${delayedRefresh}${statusFilters}${ticketList}`");

    expect(notificationView).toMatch(/display:\s*flex\s*;/);
    expect(notificationView).toMatch(/flex-direction:\s*column\s*;/);
    expect(notificationView).not.toMatch(/grid-template-rows\s*:/);
    expect(progress).toMatch(/flex:\s*0\s+0\s+auto\s*;/);
    expect(warning).toMatch(/flex:\s*0\s+0\s+auto\s*;/);
    expect(filters).toMatch(/flex:\s*0\s+0\s+auto\s*;/);
    expect(ticketList).toMatch(/flex:\s*1\s+1\s+0\s*;/);
    expect(ticketList).toMatch(/min-height:\s*0\s*;/);
    expect(ticketList).toMatch(/overflow-y:\s*auto\s*;/);
  });

  it("keeps a same-room reopen visibly pending without presenting an active control", () => {
    const reopeningTicket = ruleBody(".glpichat-ticket-filter-item.is-reopening");

    expect(widget).toContain('disabled aria-busy="true" title="Finalizando sessão anterior..."');
    expect(widget).toContain('box.classList.toggle("is-reopening", isReopening)');
    expect(reopeningTicket).toMatch(/cursor:\s*wait\s*;/);
  });
});
