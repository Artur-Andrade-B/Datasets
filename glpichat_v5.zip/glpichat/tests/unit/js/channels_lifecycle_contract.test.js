import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = resolve(import.meta.dirname, "../../..");
const widget = readFileSync(resolve(root, "src/js/glpichat-widget.js"), "utf8");

describe("perf3 Channels lifecycle contracts", () => {
  it("models discovery separately from a successful empty result", () => {
    expect(widget).toContain('channelsDiscoveryState: "loading"');
    expect(widget).toContain('setChannelsDiscoveryState("slow"');
    expect(widget).toContain('setChannelsDiscoveryState("retry_wait"');
    expect(widget).toContain('setChannelsDiscoveryState("failed"');
    expect(widget).toContain('setChannelsDiscoveryState("ready"');

    const renderStart = widget.indexOf("const renderLauncherNotifications");
    const falseEmptyGuard = widget.indexOf('state.channelsDiscoveryState !== "ready"', renderStart);
    const emptyCopy = widget.indexOf("Nenhum chamado em", renderStart);
    expect(falseEmptyGuard).toBeGreaterThan(renderStart);
    expect(emptyCopy).toBeGreaterThan(falseEmptyGuard);
    expect(widget).toContain("Carregando conversas...");
  });

  it("gates every recurring timer until the Channels runtime is ready", () => {
    const scheduleStart = widget.indexOf("const schedulePolling");
    const bootstrapStart = widget.indexOf("const bootstrap", scheduleStart);
    const scheduleBlock = widget.slice(scheduleStart, bootstrapStart);

    expect(scheduleBlock).toContain("!state.runtimeReady || automaticReadsBlocked()");
    expect(widget).toContain("if (state.runtimeReady && state.activeTicketId > 0)");
    expect(widget).toContain("if (state.runtimeReady) {\n        minimizeAll();");
  });

  it("uses one exact Channels flight for startup, metadata and retry", () => {
    expect(widget).toContain("const requestChannels = createExactSingleFlight(performChannelsRequest)");
    expect(widget).toContain('requestChannels("startup", "initial")');
    expect(widget).toContain('requestChannels("metadata", "periodic")');
    expect(widget).toContain('requestChannels(mode, "retry")');
    expect(widget).toContain('onStart: (diagnostic) =>');
    expect(widget).toContain('phase: "active"');

    const channelsStart = widget.indexOf("const channelsFailureDetails");
    const pollStart = widget.indexOf("const pollChannelsOnce", channelsStart);
    const channelsBlock = widget.slice(channelsStart, pollStart);
    expect(channelsBlock).not.toContain("createCoalescedSingleFlight");
  });

  it("keeps loaded tickets visible when a metadata refresh is delayed", () => {
    expect(widget).toContain("state.channelsRefreshDelayed = true");
    expect(widget).toContain("As conversas já carregadas continuam disponíveis.");
    expect(widget).toContain("Tentar atualizar");
    expect(widget).toContain("Nova tentativa em ~");
    expect(widget).toContain("Nova tentativa aguardando");
    expect(widget).toContain("Tentar novamente");
    expect(widget).not.toContain("state.tickets.clear()");
  });

  it("sequences Config only after a successful Channels result", () => {
    const bootstrapStart = widget.indexOf("const bootstrap");
    const bootstrapEnd = widget.indexOf("const bootWidget", bootstrapStart);
    const bootstrapBlock = widget.slice(bootstrapStart, bootstrapEnd);
    const completionStart = widget.indexOf("const completeRuntimeStartup");
    const completionEnd = widget.indexOf("const handleWidgetVisibilityChange", completionStart);
    const completionBlock = widget.slice(completionStart, completionEnd);

    expect(bootstrapBlock).not.toContain("Promise.all");
    expect(bootstrapBlock).not.toContain("/Widget/Config");
    expect(completionBlock).toContain("/Widget/Config");
    expect(completionBlock).toContain("configData = {}");
  });

  it("claims one page-global widget root", () => {
    expect(widget).toContain('const WIDGET_MOUNT_KEY = "__glpichatWidgetMounted"');
    expect(widget).toContain("const ownsWidgetRuntime = window[WIDGET_MOUNT_KEY] !== true");
    expect(widget).toContain('document.querySelector(".glpichat-widget")');
    expect(widget).toContain('root.dataset.glpichatRoot = "1"');
    expect(widget).toContain("if (ownsWidgetRuntime) {\n    if (document.readyState");
  });

  it("does not allow a manual post-timeout retry to bypass its cooldown", () => {
    const retryStart = widget.indexOf("const retryChannelsNow");
    const retryEnd = widget.indexOf("const syncChannelMetadata", retryStart);
    const retryBlock = widget.slice(retryStart, retryEnd);

    expect(retryBlock).toContain("Date.now() < state.channelsRetryAt");
    expect(retryBlock).toContain('status: "cooldown"');
    expect(retryBlock).toContain('status: "busy"');
  });

  it("defers retry admission behind History and mutations", () => {
    const armStart = widget.indexOf("const armChannelsRetry");
    const armEnd = widget.indexOf("const scheduleChannelsRetry", armStart);
    const armBlock = widget.slice(armStart, armEnd);

    expect(armBlock).toContain("state.pendingMutations > 0");
    expect(armBlock).toContain("automaticReadsBlocked()");
    expect(widget).toContain("if (state.pendingMutations === 0) {\n          armChannelsRetry();");
  });

  it("treats every queued Channels admission as bounded local work", () => {
    expect(widget).toContain('if (failure.kind === "queue_expired")');
    expect(widget).toContain('maxQueueWaitMs: CHANNELS_QUEUE_MAX_WAIT_MS');
    expect(widget).toContain('A solicitação não chegou ao servidor.');
    expect(widget).toContain('source === "retry" || source === "manual"');

    const channelsStart = widget.indexOf("const performChannelsRequest");
    const channelsEnd = widget.indexOf("const requestChannels", channelsStart);
    const channelsBlock = widget.slice(channelsStart, channelsEnd);
    expect(channelsBlock).not.toContain("activeTimeoutMs");
  });

  it("never enables a Channels retry while exact single-flight is active", () => {
    expect(widget).toContain("channelsRequestActive: false");
    expect(widget).toContain("state.channelsRequestActive || requestChannels.hasActive()");
    expect(widget).toContain('state.channelsRequestActive ? "active" : "idle"');
    expect(widget).toContain('disabled title="Atualização em andamento"');
  });

  it("does not turn local metadata queue congestion into a stale server warning", () => {
    const channelsStart = widget.indexOf("const performChannelsRequest");
    const channelsEnd = widget.indexOf("const requestChannels", channelsStart);
    const channelsBlock = widget.slice(channelsStart, channelsEnd);
    const queueSlowStart = channelsBlock.indexOf("onQueueSlow:");
    const activeSlowStart = channelsBlock.indexOf("onSlow:", queueSlowStart);
    const queueSlowBlock = channelsBlock.slice(queueSlowStart, activeSlowStart);
    const activeSlowEnd = channelsBlock.indexOf("\n        },\n      });", activeSlowStart);
    const activeSlowBlock = channelsBlock.slice(activeSlowStart, activeSlowEnd);
    const staleAssignments = Array.from(channelsBlock.matchAll(/channelsRefreshDelayed = true/g));
    const catchStart = channelsBlock.indexOf("} catch (error)");

    expect(queueSlowBlock).not.toContain("channelsRefreshDelayed = true");
    expect(activeSlowBlock).not.toContain("channelsRefreshDelayed = true");
    expect(queueSlowBlock).toContain('state.channelsRequestPhase = "queued"');
    expect(widget).toContain("glpichat-discovery-refresh-progress");
    expect(channelsBlock).toContain('phase: "active"');
    expect(staleAssignments).toHaveLength(1);
    expect(staleAssignments[0].index).toBeGreaterThan(catchStart);
  });

  it("keeps healthy loaded metadata fresh when a manual request expires locally", () => {
    const channelsStart = widget.indexOf("const performChannelsRequest");
    const channelsEnd = widget.indexOf("const requestChannels", channelsStart);
    const channelsBlock = widget.slice(channelsStart, channelsEnd);
    const queueExpiredStart = channelsBlock.indexOf('if (failure.kind === "queue_expired")');
    const nextFailureBranch = channelsBlock.indexOf("} else if (isStartup)", queueExpiredStart);
    const queueExpiredBlock = channelsBlock.slice(queueExpiredStart, nextFailureBranch);

    expect(queueExpiredBlock).toContain('(source === "retry" || source === "manual") && state.channelsFailure');
    expect(queueExpiredBlock).toContain('scheduleChannelsRetry("metadata", state.channelsFailure)');
    expect(queueExpiredBlock).not.toContain("state.channelsFailure || failure");
    expect(queueExpiredBlock).not.toContain("channelsRefreshDelayed = true");
  });

  it("isolates a failed History room without enabling its composer", () => {
    expect(widget).toContain("const automaticReadsBlocked = () => activeHistoryRequests > 0");
    expect(widget).not.toContain("hasBlockedOpenHistory");
    expect(widget).toContain("activeChannel.history_failed === true");
    expect(widget).toContain("Somente esta sala permanece pausada");
  });

  it("waits for the real room Leave before reopening and coalesces repeated opens", () => {
    expect(widget).toContain("postFormBestEffort");
    expect(widget).toContain("const leaveRequestsByRoom = new Map()");
    expect(widget).toContain('requestLabel: "Widget/Leave"');
    expect(widget).toContain("const openTicketRequests = new Map()");
    expect(widget).toContain("await pendingLeave");
    expect(widget).toContain("state.reopeningTicketIds.add(ticketId)");
    expect(widget).toContain("Finalizando sessão anterior...");
    expect(widget).toContain("for (const ticketId of state.reopeningTicketIds)");
    expect(widget).toContain("tab.disabled = isReopening");
    expect(widget).toContain("const existingRequest = openTicketRequests.get(normalizedTicketId)");
    expect(widget).toContain("const releaseOpenTicketRequest = (ticketId, openRequest)");
    expect(widget).not.toContain("activeTimeoutMs");

    const openStart = widget.indexOf("const openTicketOnce");
    const openEnd = widget.indexOf("const openTicket =", openStart);
    const openBlock = widget.slice(openStart, openEnd);
    expect(openBlock.indexOf("await pendingLeave")).toBeLessThan(openBlock.indexOf("state.openTicketIds.push(ticketId)"));
    expect(openBlock.indexOf("releaseOpenTicketRequest(ticketId, openRequest)")).toBeGreaterThan(openBlock.indexOf("await pendingLeave"));
    expect(openBlock.indexOf("releaseOpenTicketRequest(ticketId, openRequest)")).toBeLessThan(openBlock.indexOf("state.openTicketIds.push(ticketId)"));
    expect(openBlock.match(/state\.manualTicketIds\.add\(ticketId\)/g)).toHaveLength(1);

    const openGateStart = widget.indexOf("const openTicket =", openEnd);
    const openGateEnd = widget.indexOf("const notifyLeaveRoom", openGateStart);
    const openGateBlock = widget.slice(openGateStart, openGateEnd);
    expect(openGateBlock.indexOf("openTicketRequests.set(normalizedTicketId, openRequest)")).toBeLessThan(openGateBlock.indexOf("openTicketOnce(normalizedTicketId, openRequest)"));
    expect(openGateBlock).toContain("if (releaseOpenTicketRequest(normalizedTicketId, openRequest))");

    const renderMessagesStart = widget.indexOf("const renderTicketMessages");
    const renderMessagesEnd = widget.indexOf("const renderTypingIndicator", renderMessagesStart);
    const renderMessagesBlock = widget.slice(renderMessagesStart, renderMessagesEnd);
    expect(renderMessagesBlock).toContain("const canMarkRead = state.openTicketIds.includes(ticketId)");
    expect(renderMessagesBlock).toContain("!state.closedTicketIds.has(ticketId)");
    expect(renderMessagesBlock).toContain('!box.classList.contains("is-closing")');
    expect(renderMessagesBlock).toContain("wasNearBottom && canMarkRead");

    const pollStart = widget.indexOf("const pollChannelsOnce");
    const pollEnd = widget.indexOf("const pollChannels =", pollStart);
    const pollBlock = widget.slice(pollStart, pollEnd);
    const reloadStart = pollBlock.indexOf("for (const channel of channelsNeedingReload)");
    const reloadBlock = pollBlock.slice(reloadStart);
    expect(reloadBlock).toContain("!state.openTicketIds.includes(reloadTicketId)");
    expect(reloadBlock).toContain("state.closedTicketIds.has(reloadTicketId)");
    expect(reloadBlock).toContain("state.reopeningTicketIds.has(reloadTicketId)");
    expect(reloadBlock.indexOf("state.reopeningTicketIds.has(reloadTicketId)")).toBeLessThan(reloadBlock.indexOf("await loadChannelHistory(channel)"));

    const historyStart = widget.indexOf("const loadChannelHistoryOnce");
    const channelsStart = widget.indexOf("const channelsFailureDetails", historyStart);
    const historyBlock = widget.slice(historyStart, channelsStart);
    expect(historyBlock).not.toContain("activeTimeoutMs");
  });

  it("opts into detailed Channels phases only outside periodic metadata", () => {
    expect(widget).toContain('source === "periodic"\n          ? {}\n          : { "X-Glpichat-Diagnostic-Level": "phases" }');
  });

  it("gates invite reads and timers until Config sequencing completes", () => {
    const mountStart = widget.indexOf("const mountInviteManagement");
    const mountEnd = widget.indexOf("const markRead", mountStart);
    const mountBlock = widget.slice(mountStart, mountEnd);

    expect(widget).toContain("if (!state.runtimeReady || !targetContainer)");
    expect(mountBlock).toContain("await runtimeReadyPromise");
    expect(mountBlock).toContain("!state.runtimeReady || document.hidden");
  });

  it("shows explicit History loading text from the first skeleton render", () => {
    expect(widget).toContain("Carregando histórico...");
  });
});
