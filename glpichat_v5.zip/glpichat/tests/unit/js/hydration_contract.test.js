import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = resolve(import.meta.dirname, "../../..");
const readText = (relativePath) => readFileSync(resolve(root, relativePath), "utf8");

describe("hydration safety contracts", () => {
  it("never aborts active History, Channels or isolated Leave", () => {
    const http = readText("src/js/modules/widget-http.js");
    const widget = readText("src/js/glpichat-widget.js");
    const historyStart = widget.indexOf("const loadChannelHistoryOnce");
    const historyEnd = widget.indexOf("const channelsFailureDetails", historyStart);
    const historyBlock = widget.slice(historyStart, historyEnd);
    const channelsStart = widget.indexOf("const performChannelsRequest", historyEnd);
    const channelsEnd = widget.indexOf("const requestChannels", channelsStart);
    const channelsBlock = widget.slice(channelsStart, channelsEnd);
    const leaveStart = widget.indexOf("const notifyLeaveRoom");
    const leaveEnd = widget.indexOf("const minimizeTicket", leaveStart);
    const leaveBlock = widget.slice(leaveStart, leaveEnd);

    expect(http).not.toContain("AbortController");
    expect(historyBlock).toContain("/Widget/History");
    expect(historyBlock).not.toContain("/Widget/Poll");
    expect(historyBlock).not.toContain("activeTimeoutMs");
    expect(channelsBlock).not.toContain("activeTimeoutMs");
    expect(leaveBlock).not.toContain("activeTimeoutMs");
    expect(widget).toContain("await pendingLeave");
    expect(widget).toContain("state.reopeningTicketIds.add(ticketId)");
    expect(widget).toContain("Finalizando sessão anterior...");
    expect(widget).toContain("releaseOpenTicketRequest(ticketId, openRequest)");
    expect(widget).toContain("wasNearBottom && canMarkRead");
    expect(widget).toContain("state.reopeningTicketIds.has(reloadTicketId)");
    expect(http).toContain("useSharedQueue: false");
    expect(http).toContain("waitForSharedQueue: true");
    expect(historyBlock).toContain("history_failed = true");
  });

  it("never converts an empty incremental Poll payload into Channels discovery", () => {
    const widget = readText("src/js/glpichat-widget.js");
    expect(widget).toMatch(/if \(payload\.length === 0\) \{\s*return;\s*\}/);
  });

  it("preserves canonical channel identity during metadata refresh", () => {
    const widget = readText("src/js/glpichat-widget.js");
    const setChannelStart = widget.indexOf("const setChannel");
    const setChannelEnd = widget.indexOf("const automaticReadsBlocked", setChannelStart);
    const setChannelBlock = widget.slice(setChannelStart, setChannelEnd);

    expect(setChannelBlock).toContain("mergeChannelMetadata(existing, payload)");
    expect(setChannelBlock).not.toContain("...prev");
    expect(setChannelBlock).not.toContain("history_loading: false");
  });

  it("pauses recurring browser work only while History remains active", () => {
    const widget = readText("src/js/glpichat-widget.js");
    expect(widget).toContain("const automaticReadsBlocked = () => activeHistoryRequests > 0");
    expect(widget).not.toContain("hasBlockedOpenHistory");
    expect(widget).toMatch(/if \(automaticReadsBlocked\(\)\) \{\s*return;\s*\}/);
    expect(widget).toContain("Somente esta sala permanece pausada");
    expect(widget).toContain("document.hidden || !isVisible || automaticReadsBlocked()");
    expect(widget).toContain("channel.messages_loaded !== true");
    expect(widget).toContain("if (!hydrationResult?.ok)");
  });

  it("rejects incomplete History payloads instead of displaying a false empty chat", () => {
    const widget = readText("src/js/glpichat-widget.js");

    expect(widget).toContain("!Array.isArray(data.messages) || !Array.isArray(data.events)");
    expect(widget).toContain('kind: "invalid_payload"');
  });

  it("does not commit an old-room response into refreshed channel metadata", () => {
    const widget = readText("src/js/glpichat-widget.js");

    expect(widget).toContain("const requestedRoomsId = Number(channel.rooms_id || 0)");
    expect(widget).toContain("Number(channel.rooms_id || 0) !== requestedRoomsId");
    expect(widget).toContain('kind: "room_changed"');
    expect(widget).toContain('{ kind: "missing_room" }');
  });

  it("restarts scheduling when minimize-all removes the blocked open room", () => {
    const widget = readText("src/js/glpichat-widget.js");
    const start = widget.indexOf("const minimizeAll");
    const end = widget.indexOf("const restoreMinimizedSnapshot", start);
    const block = widget.slice(start, end);

    expect(block).toContain("state.openTicketIds = []");
    expect(block).toContain("schedulePolling()");
  });

  it("keeps an inactive-room failure visible and requires explicit retry", () => {
    const widget = readText("src/js/glpichat-widget.js");

    expect(widget).toContain('btn.classList.add("has-history-error")');
    expect(widget).toContain('failureMarker.textContent = "!"');
    expect(widget).toContain("if (activeChannel?.history_failed === true)");
    expect(widget).toContain("const isActiveRoom = ticket?.activeTab === channel.room_type");
  });

  it("blocks all mutations during active History, then localizes a settled failure", () => {
    const widget = readText("src/js/glpichat-widget.js");
    const composerStart = widget.indexOf("const applyComposerState");
    const composerEnd = widget.indexOf("const refreshOpenComposerStates", composerStart);
    const composerBlock = widget.slice(composerStart, composerEnd);

    expect(composerBlock).toContain("const hydrationBlocked = automaticReadsBlocked()");
    expect(composerBlock).toContain("activeChannel.history_loading === true");
    expect(composerBlock).toContain("activeChannel.history_failed === true");
    expect(widget).toContain("|| automaticReadsBlocked()");
    expect(widget).toContain("const automaticReadsBlocked = () => activeHistoryRequests > 0");
    expect(widget).not.toContain("hasBlockedOpenHistory");
    expect(widget).toContain("const refreshOpenComposerStates = () =>");
  });

  it("keeps automatic reads paused while active History remains in flight after minimize", () => {
    const widget = readText("src/js/glpichat-widget.js");

    expect(widget).toContain("let activeHistoryRequests = 0");
    expect(widget).toContain("const automaticReadsBlocked = () => activeHistoryRequests > 0");
    expect(widget).toContain("activeHistoryRequests = Math.max(0, activeHistoryRequests - 1)");
  });
});
