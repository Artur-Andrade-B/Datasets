# Testes Automatizados do Plugin

Este diretório contém a suíte de testes do plugin organizada por camada de confiança.

## Estrutura Atual

```text
tests/
├── bootstrap/
│   └── unit.php                       # Bootstrap mínimo para testes PHP puros
├── unit/
│   ├── js/                            # Suítes Vitest e contratos de release
│   │   ├── channels_lifecycle_contract.test.js # Bootstrap/retry/estado visual perf3
│   │   ├── perf4_stale_layout_contract.test.js # Layout estável com aviso atrasado
│   │   ├── hydration_contract.test.js # Bloqueios/falhas da hidratação perf2
│   │   ├── release_bundle.test.js     # Bundle publicado reproduzível
│   │   ├── release_metadata.test.js   # Metadados 1.0.5-perf4
│   │   └── ...                        # Estado, DOM, HTTP, scheduler, format/sanitize
│   └── php/                           # Contratos e testes unitários PHP
│       ├── diagnostics_privacy_test.php
│       ├── perf2_hydration_contract_test.php
│       ├── perf3_channels_contract_test.php
│       ├── perf3_lifecycle_contract_test.php
│       ├── perf4_leave_session_contract_test.php
│       └── ...                        # Acesso, guest, invites, eventos e readstate
├── smoke/
│   ├── http/                          # 2 testes de rotas/segurança HTTP
│   └── php/                           # 13 testes no runtime GLPI/banco real
├── lifecycle/
│   └── install_uninstall_test.php     # Instalação/update/uninstall no laboratório
├── e2e/
│   ├── python/                        # 3 fluxos browser/E2E
│   └── setup/                         # Preparação e teardown do ambiente
├── fixtures/
│   ├── blocked_upload.html
│   └── blocked_upload.php
├── helpers/
│   └── patch_animations.py
├── performance/
│   ├── README.md
│   ├── k6/                            # 9 cenários de carga/soak
│   └── run_k6.sh
├── run_full_suite.sh
├── run_unit_php.sh
└── validate_tests.sh
```

## Pré-requisitos de Ambiente

Para rodar as camadas de integração (smoke-php, smoke-http, e2e, lifecycle) você precisa de uma instância do GLPI rodando com o plugin instalado e dois usuários configurados:

| Usuário | Senha | Perfil | Criado por |
|---------|-------|--------|------------|
| `glpi` | `glpi` | Super-Admin | GLPI (padrão de instalação) |
| `self` | `self` | Self-Service | **Você precisa criar manualmente** |

### Criando o usuário `self`

O GLPI não cria o usuário `self` automaticamente. Você precisa criá-lo antes de rodar a esteira:

**Via interface:**
1. Acesse **Administração > Usuários > Adicionar**
2. Login: `self`, Senha: `self`, Perfil padrão: `Self-Service`
3. Salve

**Via PHP CLI no container:**
```bash
docker exec glpi php - <<'PHP'
<?php
$loader = require '/var/www/glpi/vendor/autoload.php';
$kernel = new \Glpi\Kernel\Kernel();
$kernel->boot();

$profile_row = $GLOBALS['DB']->request([
    'SELECT' => ['id'], 'FROM' => 'glpi_profiles',
    'WHERE' => ['name' => 'Self-Service'], 'LIMIT' => 1,
])->current();
$profiles_id = is_array($profile_row) ? (int)$profile_row['id'] : 6;

$user = new User();
$id = (int) $user->add([
    'name' => 'self', 'password' => 'self', 'password2' => 'self',
    'is_active' => 1, 'profiles_id' => $profiles_id, '_profiles_id' => $profiles_id,
]);
echo $id > 0 ? "[PASS] self criado (id=$id)\n" : "[FAIL] nao foi possivel criar\n";
PHP
```

O usuário `self` representa o solicitante (requester) nos testes de integração e E2E. Sem ele, o `prepare_env.php` falhará ao tentar vincular um solicitante ao ticket dedicado da esteira.

---



1. **Unitário**
   - Cobre regras puras e determinísticas.
   - Não depende de banco, sessão ou kernel do GLPI.
   - Exemplos atuais: `tests/unit/php/domain_test.php`, `tests/unit/php/access_test.php`, `tests/unit/php/message_flow_test.php`, `tests/unit/php/guest_flow_test.php`, `tests/unit/php/guest_accept_test.php`, `tests/unit/php/invite_flow_test.php` e `tests/unit/php/invite_manage_flow_test.php`.
2. **Integração / Smoke PHP**
   - Valida comportamento real do plugin no runtime do GLPI.
   - Usa banco, sessão, hooks, controllers e filesystem reais.
3. **Browser / E2E**
   - Valida fluxos visíveis no frontend e no guest flow.

## Execução

### Roteador principal

Executa todas as suítes por padrão ou uma camada específica por parâmetro:

```bash
./tests/run_unit_php.sh
./tests/run_unit_php.sh unit
./tests/run_unit_php.sh unit-php
./tests/run_unit_php.sh unit-js
./tests/run_unit_php.sh smoke
./tests/run_unit_php.sh smoke-php
./tests/run_unit_php.sh smoke-http http://localhost:8080 2 public
./tests/run_unit_php.sh e2e http://localhost:8080
```

### Unitário PHP

Executa apenas os testes unitários PHP no container `glpi`:

```bash
./tests/run_unit_php.sh unit-php
```

### Smoke PHP existente

Exemplos de execução direta no container:

```bash
./tests/run_unit_php.sh smoke-php
```

### Smoke HTTP autenticado

```bash
./tests/run_unit_php.sh smoke-http http://localhost:8080 2 public
```

### E2E Browser

```bash
./tests/run_unit_php.sh e2e http://localhost:8080
```

### Carga / Performance

```bash
./tests/performance/run_k6.sh http://localhost:8080
```

## Diretrizes

1. **Refatoração guiada por testes**: cada extração nova deve ganhar primeiro um teste unitário ou de integração compatível com o tipo de risco.
2. **Teardown obrigatório**: qualquer teste que escreva em banco ou disco deve limpar seus artefatos.
3. **Sem downgrade artificial**: regras puras vão para a camada unitária; integrações reais continuam protegidas por smoke/integration.
4. **Comportamento externo preservado**: testes devem validar o contrato real do plugin, não o detalhe interno da implementação.
5. **Helpers não são suíte**: scripts em `tests/helpers/` apoiam manutenção local, mas não fazem parte da taxonomia de unit/smoke/e2e.
