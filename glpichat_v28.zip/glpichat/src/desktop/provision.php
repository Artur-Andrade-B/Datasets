<?php

declare(strict_types=1);

require_once __DIR__ . '/enrollment.php';
require_once __DIR__ . '/identity.php';

/** Administrator-only helpers. Never included by the desktop HTTP controller. */
function glpichat_desktop_provision_csv(string $path): array
{
    $stream = fopen($path, 'rb');
    if ($stream === false) { throw new RuntimeException('Cannot open the assignment CSV.'); }
    try {
        $headers = fgetcsv($stream, 16384, ',', '"', '');
        if (!is_array($headers)) { throw new RuntimeException('The assignment CSV is empty.'); }
        $headers = array_map(static fn($v): string => strtolower(trim((string) $v)), $headers);
        $headers[0] = ltrim($headers[0], "\xEF\xBB\xBF");
        if (count(array_unique($headers)) !== count($headers)) { throw new RuntimeException('Duplicate CSV columns.'); }
        foreach (['login', 'object_guid', 'windows_sid', 'computer_name'] as $required) {
            if (!in_array($required, $headers, true)) { throw new RuntimeException('Missing CSV column: ' . $required); }
        }
        $rows = [];
        while (($values = fgetcsv($stream, 16384, ',', '"', '')) !== false) {
            if ($values === [null]) { continue; }
            if (count($rows) >= 10000 || count($values) !== count($headers)) {
                throw new RuntimeException('Invalid CSV row or more than 10000 assignments.');
            }
            $rows[] = array_combine($headers, array_map(static fn($v): string => trim((string) $v), $values));
        }
        if (!$rows) { throw new RuntimeException('No assignments in the CSV.'); }
        return $rows;
    } finally { fclose($stream); }
}

function glpichat_desktop_provision_guid(string $value): string
{
    if (strlen($value) === 16) {
        // Use GLPI's conversion, which handles the mixed-endian AD GUID layout.
        $value = AuthLDAP::guidToString($value);
    }
    $value = strtolower(trim($value, "{} \r\n\t"));
    if (preg_match('/\A[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}\z/D', $value) !== 1) {
        throw new RuntimeException('An AD objectGUID is missing or invalid.');
    }
    return $value;
}

/** Resolve the existing directory-backed user; never create/rewrite a GLPI user. */
function glpichat_desktop_provision_user(array $row, array $source): array
{
    $login = $row['login'] ?? '';
    if (!is_string($login) || $login === '' || strlen($login) > 200 || preg_match('/[\x00-\x1f]/', $login)) {
        throw new RuntimeException('Missing or invalid login in assignment.');
    }
    $users = glpichat_desktop_db_rows('SELECT ' . glpichat_desktop_native_columns(true) . ' FROM glpi_users WHERE auths_id=' . (int) $source['id']
        . ' AND name=' . glpichat_desktop_quote($login) . ' AND is_deleted=0 LIMIT 2');
    if (count($users) !== 1) { throw new RuntimeException('Login must resolve to exactly one existing GLPI user in the selected directory.'); }
    $user = $users[0];
    $attribute = strtolower(trim((string) ($source['sync_field'] ?? '')));
    if ($attribute === 'objectguid') {
        if (!hash_equals(glpichat_desktop_provision_guid((string) $user['sync_field']),
            glpichat_desktop_provision_guid((string) ($row['object_guid'] ?? '')))) {
            throw new RuntimeException('AD objectGUID does not match the replicated GLPI account. Refresh the assignment export or GLPI synchronization.');
        }
    } else {
        $expected = (string) ($row['sync_value'] ?? '');
        if ($attribute === '' || $expected === '' || !hash_equals((string) ($user['sync_field'] ?? ''), $expected)) {
            throw new RuntimeException('The CSV sync_value must match the configured GLPI directory synchronization attribute: ' . $attribute);
        }
    }
    return $user;
}

function glpichat_desktop_provision_number(mixed $value, string $name, bool $allowZero): ?int
{
    if ($value === null || $value === '') { return null; }
    if ((!is_int($value) && !is_string($value)) || preg_match('/\A(?:0|[1-9][0-9]{0,9})\z/D', (string) $value) !== 1
        || (int) $value > 2147483647 || (!$allowZero && (int) $value === 0)) {
        throw new RuntimeException('Invalid ' . $name . '.');
    }
    return (int) $value;
}

function glpichat_desktop_provision_assignments(array $rows, array $source, ?int $profile, ?int $entity): array
{
    $source = glpichat_desktop_auth_one('SELECT ' . glpichat_desktop_native_columns(false) . ' FROM glpi_authldaps WHERE id=' . (int) $source['id'] . ' LIMIT 1');
    if (!$source) { throw new RuntimeException('Directory source is unavailable.'); }
    $assignments = [];
    $seen = [];
    foreach ($rows as $offset => $row) {
        try {
            [$sid, $computer] = glpichat_desktop_delivery_identity(
                strtoupper((string) ($row['windows_sid'] ?? '')), (string) ($row['computer_name'] ?? ''));
            $key = $sid . '/' . $computer;
            if (isset($seen[$key])) { throw new RuntimeException('Duplicate user/computer assignment.'); }
            $seen[$key] = true;
            $user = glpichat_desktop_provision_user($row, $source);
            $facts = glpichat_desktop_provision_context($user,
                glpichat_desktop_provision_number($row['profiles_id'] ?? null, 'profiles_id', false) ?? $profile,
                glpichat_desktop_provision_number($row['entities_id'] ?? null, 'entities_id', true) ?? $entity);
            $assignments[] = ['users_id' => (int) $user['id'], 'profiles_id' => $facts['profile_id'],
                'entities_id' => $facts['entity_id'], 'windows_sid' => $sid, 'computer_name' => $computer,
                // Retain the exact row incarnation whose AD anchor was checked.
                // grant_issue compares these facts again under write locks.
                'expected_identity' => glpichat_desktop_account_identity($user, $source)];
        } catch (Throwable $e) {
            throw new RuntimeException('Assignment row ' . ($offset + 2) . ': ' . $e->getMessage(), 0, $e);
        }
    }
    return $assignments;
}

/** All files are private until an administrator publishes them with the supplied ACL tool. */
function glpichat_desktop_provision_export(array $assignments, string $directory, string $baseUrl, int $ttlSeconds): array
{
    if (file_exists($directory) || is_link($directory)) { throw new RuntimeException('Output directory must be new; existing grants are never overwritten.'); }
    $parent = realpath(dirname($directory));
    if ($parent === false || !is_dir($parent)) { throw new RuntimeException('Output parent directory does not exist.'); }
    $root = realpath(GLPI_ROOT);
    if ($root !== false && ($parent === $root || str_starts_with($parent . '/', $root . '/'))) {
        throw new RuntimeException('Export enrollment grants outside the GLPI web directory.');
    }
    $oldMask = umask(0077);
    try {
        if (!mkdir($directory, 0700)) { throw new RuntimeException('Cannot create private output directory.'); }
        $summary = [];
        foreach ($assignments as $assignment) {
            $userDirectory = $directory . '/' . $assignment['windows_sid'];
            if (!is_dir($userDirectory) && !mkdir($userDirectory, 0700)) { throw new RuntimeException('Cannot create private user directory.'); }
            $path = $userDirectory . '/' . $assignment['computer_name'] . '.json';
            try {
                $record = glpichat_desktop_transaction(static function () use ($assignment, $ttlSeconds, $path, $baseUrl): array {
                    $issued = glpichat_desktop_grant_issue($assignment, $ttlSeconds);
                    $grant = ['schema' => 1, 'grant_id' => $issued['grant_id'], 'secret' => $issued['grant_secret'],
                        'windows_sid' => $issued['windows_sid'], 'computer_name' => $issued['computer_name'],
                        'base_url' => $baseUrl, 'user_id' => $issued['user']['id'], 'subject_id' => $issued['user']['subject_id'],
                        'expires_at' => $issued['expires_at']];
                    $json = json_encode($grant, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . "\n";
                    $file = fopen($path, 'xb');
                    if ($file === false) { throw new RuntimeException('Cannot exclusively create enrollment file.'); }
                    try {
                        if (fwrite($file, $json) !== strlen($json) || !fflush($file)) { throw new RuntimeException('Cannot write the complete enrollment file.'); }
                        if (function_exists('fsync') && !fsync($file)) { throw new RuntimeException('Cannot flush the enrollment file.'); }
                    } finally { fclose($file); }
                    return ['grant_id' => $grant['grant_id'], 'users_id' => $grant['user_id'],
                        'profiles_id' => $assignment['profiles_id'], 'entities_id' => $assignment['entities_id'],
                        'windows_sid' => $grant['windows_sid'], 'computer_name' => $grant['computer_name'], 'expires_at' => $grant['expires_at']];
                });
                $summary[] = $record;
            } catch (Throwable $e) {
                if (is_file($path)) { unlink($path); }
                throw new RuntimeException('Export stopped. Earlier completed files remain usable; this row was not exported. ' . $e->getMessage(), 0, $e);
            }
        }
        return $summary;
    } finally { umask($oldMask); }
}
