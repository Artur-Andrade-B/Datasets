# GLPIChat 1.9.1-desktop14 / Windows 0.9.1

Esta é a versão de correções e homologação, ainda sem assinatura Authenticode. A versão 1.0.0 será a promoção assinada após a validação no ambiente Windows/AD/GLPI.

## Atualização do plugin

1. Faça backup do banco e da pasta atual do plugin.
2. Substitua a pasta `glpichat` pelos arquivos deste pacote e execute a atualização normal do plugin no GLPI. Não desinstale o plugin: a desinstalação remove dados.
3. Não mantenha cópias antigas renomeadas dentro da pasta de plugins. Guarde o backup fora desse diretório.
4. Confirme a versão 1.9.1, build desktop14 e esquema Desktop 9. A atualização de desktop13 mantém o esquema 9 existente. Uma instalação anterior ao esquema 9 ainda executa a migração de identificação da máquina emissora; somente vínculos comprováveis são preenchidos.
5. Atualize o Windows usando o pacote administrativo/GPO 0.9.1 para instalações antigas que ainda dependem de arquivos de autorização por usuário. Importar apenas o ZIP de atualização não substitui a configuração administrativa da implantação.

Depois de atualizar, abra a aba Desktop da configuração: **Estrutura desktop → Atualização registrada**. Abra **Gerenciar versões e computadores Windows** com uma conta administrativa autorizada e confirme a presença das listas e controles. desktop14 corrige a rejeição indevida do esquema 9 nessas páginas. Não reduza o marcador do esquema nem reinstale o plugin para recuperar os controles.

Use o ZIP do plugin somente no GLPI. O ZIP administrativo Windows contém `desktop/tools`, `desktop/dist/0.9.1` e as instruções de implantação. Para atualizar uma frota já gerenciada pelo GLPI, importe o ZIP Windows específico de release, contendo apenas Agent, Widget e `release.json`. Os executáveis corrigidos têm versão 0.9.1; não substitua os bytes de um release 0.9.0 já importado mantendo a mesma versão.

O [roteiro de desktop14](releases/1.9.1-desktop14.md) descreve as correções e os casos de aceitação desta versão.

## Conexão automática

Configure centralmente o diretório LDAP, a importação/sincronização de usuários, o perfil/entidade e os direitos de chat. O usuário não precisa acessar o GLPI anteriormente, fornecer senha/token, parear a conta ou executar comandos. O usuário precisa existir no GLPI por sincronização central.

O computador é registrado uma vez. O serviço local verifica o usuário real da sessão Windows e solicita sua autorização automaticamente. Usuários diferentes no mesmo computador mantêm dados separados. O mesmo usuário pode manter conexões em computadores diferentes; cada instalação possui identidade e autorização próprias. Não clone estado já registrado em imagens de máquinas.

A revogação administrativa permanece válida. Corrigir ou renovar uma conexão não libera silenciosamente um acesso revogado. O painel de administração permite liberar o vínculo correto quando apropriado.

## Mensagens não lidas

A caixa Não lidas consulta mensagens autorizadas independentemente do status do chamado e da página de chamados recentes. A leitura é compartilhada entre clientes do mesmo usuário; notificações não equivalem a leitura. Abrir a última mensagem não deve marcar como lidas as mensagens antigas que não foram vistas.

Na validação de 0.9.1, confira chamados fora da primeira página e mais de 50 mensagens, clique em uma notificação durante a reconexão automática e reinicie o aplicativo após uma notificação. O contador deve refletir o chamado inteiro, a navegação deve preservar a solicitação do usuário e mensagens não vistas devem continuar não lidas.

## Operação e diagnóstico

Confirme saúde do serviço local, registro da máquina e conexão real de dois usuários de domínio novos. Um usuário com credenciais antigas funcionando não comprova que novos usuários conseguem se conectar. Use os diagnósticos do pacote administrativo, sem exportar tokens ou segredos.

As rotinas de limpeza preservam evidências de anexos históricos. O utilitário `bin/audit-private-attachments.php` é somente leitura e deve ser executado no contexto administrativo do GLPI antes de qualquer reconciliação manual de associações antigas.

O pacote de instalação contém apenas arquivos de execução e documentação operacional. Testes, fontes completas do Windows, ferramentas de compilação e relatórios históricos estão no pacote completo de código-fonte; não são necessários no diretório web.
