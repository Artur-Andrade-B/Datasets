# GLPI Chat — 1.9.2-desktop15

Chat contextual vinculado aos chamados do GLPI, com cliente Windows 0.9.2 e conexão automática gerenciada pela empresa.

- GLPI 11.0.7 ou superior compatível; PHP 8.2 ou superior.
- Plugin e cliente Windows possuem versões independentes.
- Instalação e configuração são administrativas; o usuário final não precisa de token ou pareamento.
- Usuários diferentes no mesmo computador têm estado separado; um usuário pode utilizar computadores diferentes simultaneamente.
- O pacote Windows 0.9.2 é destinado à homologação funcional antes da promoção assinada 1.0.0.

Leia [Instalação e operação](docs/INSTALLATION_PT-BR.md). Não desinstale o plugin para atualizar. Preserve os dados, as chaves de atualização e a identidade das máquinas.

desktop15 corrige 11 problemas confirmados de navegação, desenho do lançador, prévias, recuperação de envio, transporte web e implantação/recuperação de sessões Windows. O esquema permanece 9 e a visibilidade de anexos nativos do chamado não muda. Atualize o plugin antes do cliente Windows 0.9.2; a aceitação nativa de desenho e DPI continua necessária.

Este ZIP contém somente os arquivos de execução do plugin e documentação operacional. O pacote completo inclui fontes, testes e ferramentas de desenvolvimento. Os scripts administrativos em `bin/` exigem o contexto e permissões adequados do GLPI.

Licença GPL-3.0-or-later; consulte LICENSE. A interface e os controles de acesso existentes foram preservados.
