<?php

declare(strict_types=1);

// GLPI 11 routes this legacy front script through its authenticated, CSRF-aware
// entry point. Unlike /Desktop/V1, this path MUST NOT be registered stateless.
if (!defined('GLPI_ROOT')) {
    define('GLPI_ROOT', dirname(__DIR__, 3));
}
include GLPI_ROOT . '/inc/includes.php';
require_once dirname(__DIR__) . '/src/desktop/common.php';
require_once dirname(__DIR__) . '/src/desktop/auth.php';

Session::checkLoginUser();
$userId = (int) Session::getLoginUserID();
if ($userId < 1) {
    throw new RuntimeException('Authentication required.');
}

header('Cache-Control: no-store, private');
header('Referrer-Policy: no-referrer');
header('X-Frame-Options: DENY');
header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");
header('X-Content-Type-Options: nosniff');

glpichat_desktop_reset_request_context();
$fieldString = static fn(array $input, string $key): string => isset($input[$key]) && is_string($input[$key]) ? $input[$key] : '';
$pairingId = $fieldString($_GET, 'pairing');
$notice = '';
$error = '';
$pair = [];
$devices = [];
$loginName = (string) ($_SESSION['glpiname'] ?? '');
$profileId = (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0);
$entityId = (int) ($_SESSION['glpiactive_entity'] ?? -1);
$enabled = glpichat_desktop_enabled();

try {
    glpichat_desktop_require_schema();
    $currentUser = glpichat_desktop_auth_one('SELECT name FROM glpi_users WHERE id=' . $userId . ' LIMIT 1');
    $loginName = (string) ($currentUser['name'] ?? $loginName);
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        // GLPI validates the standard session CSRF token before this script.
        $action = $fieldString($_POST, 'desktop_action');
        if ($action === 'approve') {
            $postedPair = $fieldString($_POST, 'pairing_id');
            if (!hash_equals($pairingId, $postedPair)) {
                glpichat_desktop_fail('pairing_unavailable', 'Solicitação indisponível.', 404);
            }
            glpichat_desktop_pair_approve($postedPair, $userId, $profileId, $entityId);
            $notice = 'Conexão confirmada. Volte ao aplicativo no seu computador.';
        } elseif ($action === 'revoke') {
            $postedDevice = $fieldString($_POST, 'device_id');
            glpichat_desktop_revoke_user_device(ctype_digit($postedDevice) ? (int) $postedDevice : 0, $userId);
            $notice = 'A conexão foi revogada.';
        } else {
            glpichat_desktop_fail('invalid_action', 'Ação inválida.', 400);
        }
    }
    if ($pairingId !== '') {
        if (!glpichat_desktop_auth_hex($pairingId, 32)) {
            glpichat_desktop_fail('pairing_unavailable', 'Solicitação indisponível.', 404);
        }
        $pair = glpichat_desktop_auth_one('SELECT pairing_id,user_code,device_name,windows_login,status,pairing_expires_at,users_id'
            . ' FROM ' . GLPICHAT_DESKTOP_DEVICES_TABLE . ' WHERE pairing_id='
            . glpichat_desktop_quote($pairingId) . ' LIMIT 1');
        if (!$pair || !in_array($pair['status'], ['pending', 'approved', 'completed'], true)
            || $pair['pairing_expires_at'] <= glpichat_desktop_now()
            || ((int) $pair['users_id'] > 0 && (int) $pair['users_id'] !== $userId)) {
            $pair = [];
            glpichat_desktop_fail('pairing_unavailable', 'Solicitação indisponível ou expirada. Inicie uma nova conexão no aplicativo.', 404);
        }
    }
    $devices = glpichat_desktop_db_rows('SELECT id,device_name,windows_login,status,approved_at,token_expires_at,profiles_id,entities_id'
        . ' FROM ' . GLPICHAT_DESKTOP_DEVICES_TABLE . ' WHERE users_id=' . $userId
        // Keep completed records visible even when access expired: managed
        // refresh credentials can still renew and must remain revocable.
        . " AND (status='completed' OR (status='approved' AND pairing_expires_at>" . glpichat_desktop_quote(glpichat_desktop_now())
        . ')) ORDER BY id DESC LIMIT 100');
} catch (Throwable $e) {
    if ($e instanceof GlpichatDesktopException) {
        $safeMessages = [
            'invalid_request' => 'Solicitação inválida. Inicie novamente a conexão no aplicativo.',
            'schema_unavailable' => 'O administrador precisa concluir a atualização do plugin.',
            'pairing_unavailable' => 'Esta solicitação não está disponível. Inicie uma nova conexão no aplicativo.',
            'pairing_expired' => 'Esta solicitação expirou. Inicie uma nova conexão no aplicativo.',
            'credential_invalid' => 'Confira se sua conta está ativa, vinculada ao diretório e possui acesso público aos chamados no perfil e na entidade selecionados.',
        ];
        $error = $safeMessages[$e->errorCode] ?? $e->getMessage();
    } else {
        $reference = glpichat_desktop_log_failure('browser_approval', $e);
        $error = 'Não foi possível concluir esta operação. Referência para o administrador: ' . $reference . '.';
    }
    if (!$enabled) {
        $error = 'O acesso pelo aplicativo está desativado pelo administrador.';
    }
}

$escape = static fn(mixed $value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$path = rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/') . '/plugins/glpichat/front/desktop.php';
$actionUrl = $path . ($pairingId !== '' && glpichat_desktop_auth_hex($pairingId, 32) ? '?pairing=' . $pairingId : '');
$standardToken = Session::getNewCSRFToken();
$hidden = '<input type="hidden" name="_glpi_csrf_token" value="' . $escape($standardToken) . '">';

echo '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
    . '<title>GLPI Chat · Conexões do aplicativo</title><style>'
    . 'body{font:16px/1.5 system-ui,sans-serif;background:#f1f4f8;color:#24334d;margin:0;padding:32px}'
    . 'main{max-width:760px;margin:auto;background:white;border-radius:12px;padding:28px;box-shadow:0 8px 30px #24334d18}'
    . 'h1{font-size:26px;margin-top:0}h2{font-size:20px}button{background:#2f3f64;color:white;border:0;border-radius:6px;padding:10px 16px;cursor:pointer}'
    . 'button:disabled{opacity:.55;cursor:default}.code{font-size:32px;font-weight:bold;letter-spacing:3px}.notice{background:#e5f5eb;padding:12px}.error{background:#fff0e7;padding:12px}'
    . 'article{padding:16px 0;border-top:1px solid #e3e8ef}dl{display:grid;grid-template-columns:130px 1fr}dt{font-weight:600}dd{margin:0;overflow-wrap:anywhere}'
    . 'small{color:#52647d}a{color:#244e88}</style></head><body><main><h1>GLPI Chat</h1>'
    . '<p>Conta conectada: <strong>' . $escape($loginName) . '</strong></p>';
if ($notice !== '') {
    echo '<p class="notice">' . $escape($notice) . '</p>';
}
if ($error !== '') {
    echo '<p class="error">' . $escape($error) . '</p>';
}
if ($pair) {
    echo '<h2>Conectar este computador</h2><p>Confirme somente se você iniciou esta conexão no seu próprio aplicativo '
        . 'e o código abaixo é igual ao exibido nele.</p><p class="code">' . $escape($pair['user_code']) . '</p>'
        . '<dl><dt>Computador</dt><dd>' . $escape($pair['device_name']) . '</dd><dt>Conta Windows</dt><dd>' . $escape($pair['windows_login'])
        . '</dd><dt>Perfil / entidade</dt><dd>' . $escape($profileId . ' / ' . $entityId) . '</dd></dl>';
    if ($pair['status'] === 'pending' && $enabled) {
        echo '<form action="' . $escape($actionUrl) . '" method="post">' . $hidden
            . '<input type="hidden" name="pairing_id" value="' . $escape($pairingId) . '">'
            . '<input type="hidden" name="desktop_action" value="approve"><button type="submit">Confirmar conexão deste computador</button></form>';
    } else {
        echo '<p>Esta solicitação já foi confirmada. Volte ao aplicativo.</p>';
    }
}
echo '<h2>Minhas conexões</h2><p>Revogue o acesso de computadores que você não usa mais. Cada conexão usa o perfil e a entidade confirmados. Conexões gerenciadas podem renovar o token automaticamente; revogá-las também impede a renovação.</p>';
if (!$devices) {
    echo '<p>Nenhuma conexão registrada nesta conta.</p>';
}
foreach ($devices as $device) {
    echo '<article><strong>' . $escape($device['device_name']) . '</strong><br><small>'
        . $escape('Perfil ' . $device['profiles_id'] . ' · Entidade ' . $device['entities_id'] . ' · Token válido até ' . ($device['token_expires_at'] ?: 'aguardando aplicativo'))
        . '</small><form action="' . $escape($actionUrl) . '" method="post">' . $hidden
        . '<input type="hidden" name="desktop_action" value="revoke"><input type="hidden" name="device_id" value="' . (int) $device['id']
        . '"><button type="submit">Revogar conexão</button></form></article>';
}
echo '<p><a href="' . $escape(rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/') . '/front/central.php') . '">Voltar ao GLPI</a></p></main></body></html>';
