<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpichat;

use CronTask;

require_once __DIR__ . '/notification_queue.php';

final class NotificationQueueCron
{
    public static function cronInfo(string $name): array
    {
        return $name === 'DeliverChatNotifications'
            ? ['description' => __('Prepare queued GLPI Chat notifications without delaying chat messages.')]
            : [];
    }

    public static function cronDeliverChatNotifications(CronTask $task): int
    {
        $result = \glpichat_process_notification_jobs();
        $count = array_sum($result);
        $task->addVolume($count);
        $task->log(sprintf('Chat notifications: %d prepared, %d source no longer eligible, %d deferred after failure.',
            $result['delivered'], $result['suppressed'], $result['failed']));
        return $count > 0 ? 1 : 0;
    }
}
