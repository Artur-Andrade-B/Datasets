<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpichat\Controller;

use Glpi\Controller\AbstractController;
use Glpi\Http\Firewall;
use Glpi\Security\Attribute\SecurityStrategy;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

use function glpichat_browser_send;
use function glpichat_release_session_lock;
use function glpichat_require_logged_csrf;

require_once dirname(__DIR__) . '/functions.php';
require_once dirname(__DIR__) . '/flows/message_flow.php';

final class SendController extends AbstractController
{
    #[Route('/Send', name: 'glpichat_send', methods: ['POST'])]
    #[SecurityStrategy(Firewall::STRATEGY_AUTHENTICATED)]
    public function __invoke(Request $request): Response
    {
        $started = microtime(true);
        try {
            $input = $request->request->all();
            glpichat_require_logged_csrf($input);

            $tickets_id = $request->request->getInt('tickets_id');
            $room_type = $request->request->getString('room_type');
            $content = $request->request->getString('content');

            if ($tickets_id <= 0 || !in_array($room_type, ['public', 'internal'], true)) {
                \glpichat_desktop_fail('invalid_request', 'Parâmetros inválidos.', 400);
            }

            // Core's AJAX CSRF listener validates preserved tokens. Persist a
            // replacement before releasing the session write lock, so polls
            // from this user can progress while this transaction runs.
            $csrf = \Session::getNewCSRFToken();
            glpichat_release_session_lock();
            $result = glpichat_browser_send($tickets_id, $room_type, $content,
                $request->request->getString('client_message_id'));
            $elapsed = (int) round((microtime(true) - $started) * 1000);
            if ($elapsed >= 2000) {
                error_log('glpichat send: committed elapsed_ms=' . $elapsed);
            }
            return new JsonResponse($result + ['_glpi_csrf_token' => $csrf]);

        } catch (\GlpichatDesktopException $e) {
            return new JsonResponse(['error' => $e->getMessage(), 'code' => $e->errorCode], $e->httpStatus);
        } catch (\Throwable $e) {
            $reference = \glpichat_desktop_log_failure('browser_send', $e);
            return new JsonResponse(['error' => 'Não foi possível confirmar o envio. Referência: ' . $reference], 500);
        }
    }
}
