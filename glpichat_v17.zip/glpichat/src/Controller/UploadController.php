<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpichat\Controller;

use Glpi\Controller\AbstractController;
use Glpi\Http\Firewall;
use Glpi\Security\Attribute\SecurityStrategy;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

use function glpichat_browser_upload;
use function glpichat_release_session_lock;
use function glpichat_require_logged_csrf;

require_once dirname(__DIR__) . '/functions.php';
require_once dirname(__DIR__) . '/flows/message_flow.php';

final class UploadController extends AbstractController
{
    #[Route('/Upload', name: 'glpichat_upload', methods: ['POST'])]
    #[SecurityStrategy(Firewall::STRATEGY_AUTHENTICATED)]
    public function __invoke(Request $request): Response
    {
        try {
            $input = $request->request->all();
            glpichat_require_logged_csrf($input);

            $tickets_id = $request->request->getInt('tickets_id');
            $room_type = $request->request->getString('room_type');
            $file = $request->files->get('file');

            $csrf = \Session::getNewCSRFToken();
            glpichat_release_session_lock();
            $result = glpichat_browser_upload($tickets_id, $room_type, $file);
            return new JsonResponse($result + ['_glpi_csrf_token' => $csrf]);
        } catch (\GlpichatDesktopException $e) {
            return new JsonResponse(['error' => $e->getMessage(), 'code' => $e->errorCode], $e->httpStatus);
        } catch (\Symfony\Component\HttpFoundation\Exception\RequestExceptionInterface $e) {
            return new JsonResponse(['error' => 'Parâmetros de upload inválidos.', 'code' => 'invalid_request'], 400);
        } catch (\Throwable $e) {
            $reference = \glpichat_desktop_log_failure('browser_upload', $e);
            return new JsonResponse(['error' => 'Não foi possível confirmar o envio do anexo. Atualize a conversa antes de tentar novamente. Referência: ' . $reference], 500);
        }
    }
}
