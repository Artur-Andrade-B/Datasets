<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpichat;

/**
 * Native document relation writer scoped to one followup.
 *
 * GLPI 11.0.7 Document_Item::post_addItem applies Ticket::getMergedTickets()
 * to every items_id, including ITILFollowup IDs. That can copy an attachment
 * to unrelated followups whose IDs happen to match merged tickets. Keep the
 * native validation, database writer, relation history and item hooks, while
 * omitting the Ticket-only merge propagation for this exact relation type.
 */
final class FollowupDocumentItem extends \Document_Item
{
    public static function getTable($classname = null)
    {
        return \Document_Item::getTable();
    }

    public static function getType()
    {
        return \Document_Item::class;
    }

    public function prepareInputForAdd($input)
    {
        if (($input['itemtype'] ?? '') !== \ITILFollowup::class) {
            throw new \InvalidArgumentException('This document writer requires a followup.');
        }
        return parent::prepareInputForAdd($input);
    }

    public function post_addItem()
    {
        \CommonDBRelation::post_addItem();
    }
}
