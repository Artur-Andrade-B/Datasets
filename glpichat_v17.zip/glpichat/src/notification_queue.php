<?php

declare(strict_types=1);

/**
 * Durable event intent, inserted in the same transaction as the chat message.
 * Only source identifiers are kept: content and recipients are read again by
 * GLPI's existing automatic-action runner, never rendered in the send request.
 */
function glpichat_queue_notification_job(string $source_type, int $source_id, int $tickets_id, string $event, string $room_type, int $users_id): void
{
    global $DB;
    if (!in_array($source_type, ['message', 'followup', 'participant'], true) || $source_id <= 0 || $tickets_id <= 0
        || !in_array($room_type, ['public', 'internal'], true)
        || !in_array($event, ['add_followup', 'glpichat_public_message', 'glpichat_internal_message', 'glpichat_guest_message', 'glpichat_user_joined'], true)
    ) {
        throw new InvalidArgumentException('Invalid chat notification source.');
    }
    $existing = $DB->request([
        'SELECT' => ['id'], 'FROM' => 'glpi_plugin_glpichat_notificationjobs',
        'WHERE' => ['source_type' => $source_type, 'source_id' => $source_id, 'event' => $event], 'LIMIT' => 1,
    ])->current();
    if (is_array($existing)) {
        return;
    }
    $now = date('Y-m-d H:i:s');
    if (!$DB->insert('glpi_plugin_glpichat_notificationjobs', [
        'source_type' => $source_type, 'source_id' => $source_id, 'tickets_id' => $tickets_id,
        'event' => $event, 'room_type' => $room_type, 'users_id' => max(0, $users_id),
        'status' => 'pending', 'attempts' => 0, 'available_at' => $now,
        'created_at' => $now, 'completed_at' => null, 'last_error' => '',
    ])) {
        throw new RuntimeException('Unable to queue chat notification.');
    }
}

function glpichat_queue_user_joined_notification(int $tickets_id, string $room_type, int $users_id, int $participants_id): void
{
    glpichat_queue_notification_job('participant', $participants_id, $tickets_id,
        'glpichat_user_joined', $room_type, $users_id);
}

function glpichat_queue_native_followup_notification(ITILFollowup $followup): void
{
    if (($followup->fields['itemtype'] ?? '') !== 'Ticket') {
        return;
    }
    glpichat_queue_notification_job('followup', (int) $followup->getID(), (int) $followup->fields['items_id'],
        'add_followup', (int) ($followup->fields['is_private'] ?? 0) === 1 ? 'internal' : 'public',
        (int) ($followup->fields['users_id'] ?? 0));
}

function glpichat_queue_message_notifications(int $tickets_id, string $room_type, string $actor_type, int $users_id, string $content, int $messages_id, int $itilfollowups_id, bool $native = false): void
{
    // Content deliberately never becomes a second, potentially stale copy.
    glpichat_queue_notification_job('message', $messages_id, $tickets_id,
        glpichat_message_notification_event_name($room_type, $actor_type), $room_type, $users_id);
    if ($native && $itilfollowups_id > 0) {
        glpichat_queue_notification_job('followup', $itilfollowups_id, $tickets_id,
            'add_followup', $room_type, $users_id);
    }
}

/** Fixed identifier allowlist; source rows, never the ticket, are locked. */
function glpichat_notification_source_row(string $table, int $id): ?array
{
    global $DB;
    if (!in_array($table, ['glpi_plugin_glpichat_messages', 'glpi_itilfollowups', 'glpi_plugin_glpichat_participants'], true)) {
        throw new InvalidArgumentException('Invalid notification source table.');
    }
    $result = $DB->doQuery('SELECT * FROM `' . $table . '` WHERE id = ' . $id . ' FOR UPDATE');
    $row = $DB->fetchAssoc($result);
    return is_array($row) ? $row : null;
}

/**
 * Current source validation is independent of the worker's cron identity.
 * GLPI resolves current recipients/active accounts/entities at raiseEvent;
 * the existing internal-recipient hook rechecks current private-channel rights.
 */
function glpichat_notification_source_matches(array $job, ?array $message, ?array $followup, ?array $room): bool
{
    $ticket_id = (int) $job['tickets_id'];
    $private = $job['room_type'] === 'internal' ? 1 : 0;
    if ($job['source_type'] === 'message') {
        if ($message === null || $room === null
            || (int) $message['tickets_id'] !== $ticket_id || (int) $room['tickets_id'] !== $ticket_id
            || (int) $message['rooms_id'] !== (int) $room['id'] || $room['room_type'] !== $job['room_type']
            || (int) ($message['users_id'] ?? 0) !== (int) $job['users_id']
            || glpichat_message_notification_event_name((string) $room['room_type'], (string) $message['participant_type']) !== $job['event']
        ) {
            return false;
        }
        if ((int) ($message['itilfollowups_id'] ?? 0) === 0) {
            return true;
        }
    }
    return $followup !== null && ($followup['itemtype'] ?? '') === 'Ticket'
        && (int) $followup['items_id'] === $ticket_id && (int) $followup['is_private'] === $private
        && (($job['source_type'] === 'message' && ($message['participant_type'] ?? '') !== 'user')
            || (int) ($followup['users_id'] ?? 0) === (int) $job['users_id']);
}

/** Return false when the source was deleted/moved/made private before delivery. */
function glpichat_deliver_notification_job(array $job): bool
{
    global $DB;
    $ticket = new Ticket();
    if (!$ticket->getFromDB((int) $job['tickets_id']) || (int) ($ticket->fields['is_deleted'] ?? 0) !== 0) {
        return false;
    }
    $message = null;
    $followup = null;
    $room = null;
    $participant = null;
    if ($job['source_type'] === 'message') {
        $message = glpichat_notification_source_row('glpi_plugin_glpichat_messages', (int) $job['source_id']);
        if ($message !== null) {
            $room = $DB->request(['FROM' => 'glpi_plugin_glpichat_rooms', 'WHERE' => ['id' => (int) $message['rooms_id']], 'LIMIT' => 1])->current();
            $room = is_array($room) ? $room : null;
            if ((int) $message['itilfollowups_id'] > 0) {
                $followup = glpichat_notification_source_row('glpi_itilfollowups', (int) $message['itilfollowups_id']);
            }
        }
    } elseif ($job['source_type'] === 'followup' && $job['event'] === 'add_followup') {
        $followup = glpichat_notification_source_row('glpi_itilfollowups', (int) $job['source_id']);
    } elseif ($job['source_type'] === 'participant' && $job['event'] === 'glpichat_user_joined') {
        $participant = glpichat_notification_source_row('glpi_plugin_glpichat_participants', (int) $job['source_id']);
        if ($participant === null || $participant['left_at'] !== null
            || $participant['participant_type'] !== 'user' || (int) $participant['users_id'] !== (int) $job['users_id']
        ) {
            return false;
        }
        $room = $DB->request(['FROM' => 'glpi_plugin_glpichat_rooms', 'WHERE' => ['id' => (int) $participant['rooms_id']], 'LIMIT' => 1])->current();
        if (!is_array($room) || (int) $room['tickets_id'] !== (int) $job['tickets_id'] || $room['room_type'] !== $job['room_type']
            || !glpichat_can_user_read_notification_room((int) $job['users_id'], (int) $job['tickets_id'], (string) $job['room_type'])
        ) {
            return false;
        }
    } else {
        return false;
    }
    if ($participant === null && !glpichat_notification_source_matches($job, $message, $followup, $room)) {
        return false;
    }
    $trigger = null;
    if ($job['source_type'] === 'followup') {
        $trigger = new ITILFollowup();
        if (!$trigger->getFromDB((int) $job['source_id'])) {
            return false;
        }
        $options = ['followup_id' => (int) $followup['id'], 'is_private' => (int) $followup['is_private']];
    } elseif ($participant !== null) {
        $options = ['glpichat_user_name' => (string) (getUserName((int) $job['users_id']) ?: ('Usuário #' . $job['users_id']))];
    } else {
        // A followup can be edited while an automatic action is pending. Never
        // resurrect removed text from its older chat mirror in a notification.
        if ($followup !== null && (int) ($message['documents_id'] ?? 0) === 0) {
            $message['content'] = (string) $followup['content'];
        }
        $options = [
            'glpichat_room_type' => $job['room_type'],
            'glpichat_actor_type' => $message['participant_type'],
            'glpichat_users_id' => (int) $message['users_id'],
            'glpichat_content' => (string) $message['content'],
            'glpichat_message_row' => $message,
        ];
    }
    // This is GLPI's documented cron emitter path: preserve the original
    // sender's "notify myself" preference instead of notifying every sender.
    $session_before = $_SESSION ?? [];
    try {
        if ((int) $job['users_id'] > 0) {
            $_SESSION['mailcollector_user'] = (int) $job['users_id'];
        } else {
            unset($_SESSION['mailcollector_user']);
        }
        if (!NotificationEvent::raiseEvent((string) $job['event'], $ticket, $options, $trigger)) {
            throw new RuntimeException('Notification event could not be rendered.');
        }
    } finally {
        $_SESSION = $session_before;
    }
    return true;
}

/**
 * Each job and core mail/AJAX queue writes commit together. A worker crash or
 * rollback leaves the job pending without duplicate native queue entries.
 * Custom third-party modes with external side effects retain their own retry
 * semantics; a database transaction cannot provide exactly-once remote sends.
 */
function glpichat_process_notification_jobs(int $limit = 20, ?callable $deliver = null): array
{
    global $DB;
    $deliver ??= 'glpichat_deliver_notification_job';
    $now = date('Y-m-d H:i:s');
    $rows = $DB->request([
        'SELECT' => ['id'], 'FROM' => 'glpi_plugin_glpichat_notificationjobs',
        'WHERE' => ['status' => 'pending', 'available_at' => ['<=', $now]],
        'ORDER' => ['id ASC'], 'LIMIT' => max(1, min(100, $limit)),
    ]);
    $ids = [];
    foreach ($rows as $row) { $ids[] = (int) $row['id']; }
    $result = ['delivered' => 0, 'suppressed' => 0, 'failed' => 0];
    foreach ($ids as $id) {
        $job = null;
        $DB->beginTransaction();
        try {
            $query = $DB->doQuery('SELECT * FROM `glpi_plugin_glpichat_notificationjobs` WHERE id = ' . $id . ' FOR UPDATE');
            $job = $DB->fetchAssoc($query);
            if (!is_array($job) || $job['status'] !== 'pending' || $job['available_at'] > $now) {
                $DB->commit();
                continue;
            }
            $delivered = $deliver($job);
            if (!$DB->update('glpi_plugin_glpichat_notificationjobs', [
                'status' => $delivered ? 'done' : 'suppressed', 'completed_at' => date('Y-m-d H:i:s'), 'last_error' => '',
            ], ['id' => $id])) {
                throw new RuntimeException('Unable to complete notification job.');
            }
            $DB->commit();
            ++$result[$delivered ? 'delivered' : 'suppressed'];
        } catch (Throwable $e) {
            $DB->rollBack();
            ++$result['failed'];
            $attempts = min(100000, (int) ($job['attempts'] ?? 0) + 1);
            $delay = min(3600, 60 * (2 ** min(6, $attempts - 1)));
            $DB->update('glpi_plugin_glpichat_notificationjobs', [
                'attempts' => $attempts, 'available_at' => date('Y-m-d H:i:s', time() + $delay),
                'last_error' => substr(get_class($e), 0, 80),
            ], ['id' => $id, 'status' => 'pending']);
            error_log('GLPIChat notification job ' . $id . ' failed: ' . get_class($e));
        }
    }
    return $result;
}
