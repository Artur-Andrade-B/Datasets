# Desktop attachments (1.5.0 / Windows 0.5.0)

The desktop uses the current bearer identity and the same direct-requester,
public-conversation boundaries as desktop messages. No browser login, download
URL, file path, entity ID or uploader ID is accepted from the client.

| Operation | Request | Result |
| --- | --- | --- |
| `GET Desktop/V1/AttachmentPolicy` | Bearer | `{max_bytes, extensions}` from GLPI document types/size and PHP upload/post limits |
| `POST Desktop/V1/Conversations/{ticket}/Attachments` | Bearer; multipart `client_message_id` UUIDv4 and one `file` | Same send envelope; `message.attachments` contains `{id,name,size,mime}` |
| `GET Desktop/V1/Conversations/{ticket}/Messages/{message}/Attachments/{document}` | Bearer | Exact managed file bytes, forced download, private/no-store and nosniff |
| Existing `Messages` history | Bearer | Additive `attachments` array on every message; empty for text or unavailable files |

The original filename must be valid UTF-8, at most 200 bytes, without path,
control or bidirectional override characters. Native GLPI document-type rules
remain authoritative; `extensions` is advisory because GLPI can also configure
filename regex rules. The Windows client has its own explicit 32 MiB maximum
for protected local staging, applied together with the server-reported limit.

The immutable queued file uses the same UUID on every retry. The existing
`desktopsends` receipt stores a domain-separated HMAC of ticket, exact filename,
actual byte size and SHA-256. The transaction revalidates the actor/requester,
locks the ticket, and commits the native followup, native followup/document association,
chat mirror, receipt and deferred notification intent together. Retrying a
confirmed UUID returns that same file only while its current public followup and
attachment are still available; changed bytes/name/UUID reuse conflicts. A
closed ticket can acknowledge an existing receipt but cannot create a new file.

History and downloads query current native document associations and current
public followup visibility. New uploads link only to the native followup, so changing that followup to private also changes native GLPI download access. The scoped native relation writer preserves validation/history while excluding GLPI 11.0.7’s incorrect ticket-merge propagation for numeric followup IDs. Older public chat attachments linked directly to
Ticket are supported only through their exact public chat mirror; a bare Ticket
document association does not expose private chat files. Removed associations,
private followups, deleted/blacklisted documents, another entity and missing
managed files are not downloadable. Paths are resolved only from server-owned
GLPI documents and checked to stay inside managed document storage.

Native storage receives explicit author/entity values. Ambient browser identity
is removed while storing and restored afterward, rather than impersonating the
bearer user in GLPI Session. Temporary upload files and hook suppression are
cleaned/restored on both success and failure. Native content-addressed files can
be shared across documents, so failed transactions never unlink a final shared
file. The database transaction is atomic, but physical storage is not: a rare
post-storage failure can leave unreferenced bytes requiring administrative
storage reconciliation. GLPI’s row-based orphan cleanup cannot guarantee cleanup
when the document row itself was rolled back.

The desktop download action asks where to save, validates the response size and
saves atomically. It does not open executable content or navigate to arbitrary
file URLs. Attachments remain separate from the text outbox so an older desktop
binary cannot send an attachment queue entry as plain text after rollback.
