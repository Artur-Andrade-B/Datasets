import { describe, expect, it } from "vitest";
import {
  applyDeliveryFailure,
  createClientMessageId,
  createOptimisticMessage,
  deliveryLabel,
  lastConfirmedMessageId,
  mergeConfirmedMessages,
  reconcileConfirmedMessage,
} from "../../../src/js/modules/message-delivery.js";

const receipt = (pending, id = 12, changes = {}) => ({
  id, actor_type: "user", users_id: pending.users_id,
  client_message_id: pending.client_message_id, content: pending.content,
  date_creation: "2026-10-02 12:00:00", ...changes,
});

describe("browser message delivery", () => {
  it("creates distinct UUIDv4 correlation IDs, including messages created in one millisecond", () => {
    const ids = Array.from({ length: 100 }, createClientMessageId);
    expect(new Set(ids).size).toBe(100);
    expect(ids.every((id) => /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(id))).toBe(true);
    expect(createOptimisticMessage("one", 7).id).not.toBe(createOptimisticMessage("two", 7).id);
  });

  it("confirms through Poll before a failed POST response without restoring or duplicating text", () => {
    const pending = createOptimisticMessage("hello", 7, createClientMessageId());
    const channel = { messages: [pending], last_message_id: 10 };
    mergeConfirmedMessages(channel, [receipt(pending)]);
    expect(applyDeliveryFailure(pending, { status: 504, kind: "gateway_timeout" })).toBe("confirmed");
    expect(channel.messages).toHaveLength(1);
    expect(channel.messages[0].id).toBe(12);
    expect(pending.confirmed_message_id).toBe(12);
  });

  it("keeps a transport-ambiguous message visible until its exact receipt arrives", () => {
    const pending = createOptimisticMessage("hello", 7, createClientMessageId());
    const channel = { messages: [pending], last_message_id: 10 };
    expect(applyDeliveryFailure(pending, { status: 502 })).toBe("unconfirmed");
    expect(deliveryLabel(pending)).toContain("Confirmação pendente");
    mergeConfirmedMessages(channel, [{ id: 11, users_id: 8, content: "different", actor_type: "user" }]);
    expect(channel.messages).toContain(pending);
    mergeConfirmedMessages(channel, [receipt(pending)]);
    expect(channel.messages.map((message) => message.id)).toEqual([11, 12]);
  });

  it("never treats identical text as delivery proof for another operation or user", () => {
    const first = createOptimisticMessage("hello", 7, createClientMessageId());
    const second = createOptimisticMessage("hello", 7, createClientMessageId());
    const channel = { messages: [first, second] };
    mergeConfirmedMessages(channel, [receipt(first, 12, { users_id: 8 })]);
    expect(channel.messages).toContain(first);
    expect(channel.messages).toContain(second);
    mergeConfirmedMessages(channel, [receipt(first, 13)]);
    expect(first.confirmed_message_id).toBe(13);
    expect(second.confirmed_message_id).toBe(0);
    expect(channel.messages).toContain(second);
  });

  it("does not discard an unconfirmed message just because time passed or another message arrived", () => {
    const pending = createOptimisticMessage("old pending", 7, createClientMessageId());
    pending.id = -1;
    const channel = { messages: [pending] };
    mergeConfirmedMessages(channel, [{ id: 20, actor_type: "user", users_id: 7, content: "old pending" }]);
    expect(channel.messages).toContain(pending);
    expect(pending.confirmed_message_id).toBe(0);
  });

  it("deduplicates the acknowledgement after Poll and keeps unrelated pending text", () => {
    const pending = createOptimisticMessage("hello", 7, createClientMessageId());
    const other = createOptimisticMessage("hello", 7, createClientMessageId());
    const channel = { messages: [pending, other], last_message_id: 10 };
    mergeConfirmedMessages(channel, [receipt(pending)]);
    expect(reconcileConfirmedMessage(channel, pending, receipt(pending))).toBe(true);
    expect(channel.messages.filter((message) => message.id === 12)).toHaveLength(1);
    expect(channel.messages).toContain(other);
    expect(channel.last_message_id).toBe(10);
  });

  it("rejects a mismatched acknowledgement and lets a later Poll supply the exact receipt", () => {
    const pending = createOptimisticMessage("hello", 7, createClientMessageId());
    const channel = { messages: [pending] };
    expect(reconcileConfirmedMessage(channel, pending, receipt(pending, 12, { client_message_id: createClientMessageId() }))).toBe(false);
    expect(channel.messages).toContain(pending);
    expect(pending.confirmed_message_id).toBe(0);
  });

  it("keeps text confirmed when a separate upload fails", () => {
    const text = createOptimisticMessage("text", 7, createClientMessageId());
    const file = createOptimisticMessage("Arquivo: file.pdf", 7);
    const channel = { messages: [text, file] };
    reconcileConfirmedMessage(channel, text, receipt(text));
    expect(applyDeliveryFailure(file, { status: 413 })).toBe("failed");
    expect(text.confirmed_message_id).toBe(12);
    expect(channel.messages).toContain(file);
    expect(channel.messages.some((message) => message.id === 12)).toBe(true);
  });

  it.each([0, 408, 500, 502, 503, 504])("does not report HTTP %i as proof that a write failed", (status) => {
    expect(applyDeliveryFailure(createOptimisticMessage("hello", 7), { status })).toBe("unconfirmed");
  });

  it.each([400, 401, 403, 409, 413, 422, 429])("distinguishes a definite HTTP %i rejection", (status) => {
    expect(applyDeliveryFailure(createOptimisticMessage("hello", 7), { status })).toBe("failed");
  });

  it("preserves the consumed Poll cursor despite later optimistic or POST-confirmed messages", () => {
    const pending = createOptimisticMessage("hello", 7, createClientMessageId());
    expect(lastConfirmedMessageId({ last_message_id: 10, messages: [{ id: 20 }, pending] })).toBe(10);
    expect(lastConfirmedMessageId({ messages: [{ id: 20 }, pending] })).toBe(20);
    expect(lastConfirmedMessageId({ last_message_id: 0, messages: [pending] })).toBe(0);
  });

  it("exposes a conflicting receipt without offering a blind retry", () => {
    const pending = createOptimisticMessage("recoverable text", 7, createClientMessageId());
    applyDeliveryFailure(pending, { status: 409, message: "Identificador em conflito." });
    expect(pending.delivery_retryable).toBe(false);
    expect(deliveryLabel(pending)).toContain("Identificador em conflito.");
    expect(pending.content).toBe("recoverable text");
  });
});
