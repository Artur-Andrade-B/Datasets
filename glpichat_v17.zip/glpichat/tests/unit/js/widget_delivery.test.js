import { afterEach, expect, it, vi } from "vitest";

afterEach(() => {
  vi.clearAllTimers();
  vi.useRealTimers();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  document.body.innerHTML = "";
  delete window.__glpichatWidgetMounted;
});

it("keeps the real composer/history stable when Poll confirms a send before its HTTP response fails", async () => {
  vi.useFakeTimers();
  vi.resetModules();
  vi.spyOn(console, "info").mockImplementation(() => {});
  vi.spyOn(console, "warn").mockImplementation(() => {});
  vi.spyOn(console, "error").mockImplementation(() => {});
  const alert = vi.fn();
  vi.stubGlobal("alert", alert);
  localStorage.setItem("glpichat_widget_ui", JSON.stringify({ openTicketIds: [42], manualTicketIds: [42] }));
  let rejectSend;
  let sentId = "";
  let committed = null;
  let sendCount = 0;
  const json = (data) => new Response(JSON.stringify(data), { headers: { "Content-Type": "application/json" } });
  const fetchMock = vi.fn((url, options) => {
    if (url.includes("/Widget/Channels")) return Promise.resolve(json({ current_user_id: 7, channels: [{ tickets_id: 42, rooms_id: 3, room_type: "public", ticket_status: 1 }] }));
    if (url.endsWith("/Widget/Config")) return Promise.resolve(json({ poll_focused_ms: 100 }));
    if (url.includes("/Widget/History")) return Promise.resolve(json({ messages: [], events: [] }));
    if (url.endsWith("/Send")) {
      sendCount += 1;
      sentId = options.body.get("client_message_id");
      if (sendCount === 3) {
        committed = { id: 13, actor_type: "user", users_id: 7, sender_name: "User", content: "Retry hello", client_message_id: sentId, date_creation: "2026-10-02 12:00:01" };
        return Promise.resolve(json({ message: committed, client_message_id: sentId }));
      }
      return new Promise((_, reject) => { rejectSend = reject; });
    }
    if (url.endsWith("/Widget/Poll")) return Promise.resolve(json({ channels: { "42:public": { last_message_id: committed?.id || 0, messages: committed ? [committed] : [], events: [] } } }));
    return Promise.resolve(json({}));
  });
  vi.stubGlobal("fetch", fetchMock);
  await import("../../../src/js/glpichat-widget.js");
  document.dispatchEvent(new Event("DOMContentLoaded"));
  await vi.advanceTimersByTimeAsync(100);

  const composer = document.querySelector("#glpichat-box-42 textarea");
  expect(composer).not.toBeNull();
  expect(composer.disabled).toBe(false);
  composer.value = "Committed hello";
  composer.closest("form").dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
  await vi.advanceTimersByTimeAsync(1);
  expect(sentId).toMatch(/^[a-f0-9-]{36}$/);
  expect(document.querySelectorAll("#glpichat-box-42 .is-optimistic")).toHaveLength(1);
  expect(composer.value).toBe("");
  // The HTTP write is still in flight. Incremental reads can already see it.
  committed = { id: 12, actor_type: "user", users_id: 7, sender_name: "User", content: "Committed hello", client_message_id: sentId, date_creation: "2026-10-02 12:00:00" };
  await vi.advanceTimersByTimeAsync(110);
  expect(document.querySelectorAll("#glpichat-box-42 .is-optimistic")).toHaveLength(0);
  expect(document.querySelectorAll("#glpichat-box-42 .glpichat-message-body")).toHaveLength(1);
  expect(composer.disabled).toBe(false);

  rejectSend(new Error("proxy response lost after commit"));
  await vi.advanceTimersByTimeAsync(1);
  expect(alert).not.toHaveBeenCalled();
  expect(composer.value).toBe("");
  expect(document.querySelectorAll("#glpichat-box-42 .glpichat-message-body")).toHaveLength(1);
  expect(document.querySelector("#glpichat-box-42 [data-action='retry-message']")).toBeNull();
  expect(fetchMock.mock.calls.filter(([url]) => url.endsWith("/Send"))).toHaveLength(1);
  expect(fetchMock.mock.calls.filter(([url]) => url.includes("/Widget/History"))).toHaveLength(1);

  // An unknown outcome stays visible. A user retry reuses the same receipt,
  // ticket and room; it does not generate a second logical send.
  composer.value = "Retry hello";
  composer.closest("form").dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
  await vi.advanceTimersByTimeAsync(1);
  const retryId = sentId;
  rejectSend(new Error("network lost before acknowledgement"));
  await vi.advanceTimersByTimeAsync(1);
  expect(document.querySelector("#glpichat-box-42 .is-optimistic").textContent).toContain("Confirmação pendente");
  expect(sendCount).toBe(2);
  document.querySelector("#glpichat-box-42 [data-action='retry-message']").click();
  await vi.advanceTimersByTimeAsync(1);
  expect(sentId).toBe(retryId);
  expect(sendCount).toBe(3);
  const retryForm = fetchMock.mock.calls.filter(([url]) => url.endsWith("/Send"))[2][1].body;
  expect(retryForm.get("tickets_id")).toBe("42");
  expect(retryForm.get("room_type")).toBe("public");
  expect(retryForm.get("content")).toBe("Retry hello");
  expect(document.querySelectorAll("#glpichat-box-42 .is-optimistic")).toHaveLength(0);
  expect(document.querySelectorAll("#glpichat-box-42 .glpichat-message-body")).toHaveLength(2);
  expect(alert).not.toHaveBeenCalled();
});
