import { afterEach, beforeEach, expect, it, vi } from "vitest";

let registered = [];
beforeEach(() => {
  vi.useFakeTimers();
  vi.resetModules();
  for (const target of [window, document]) {
    const add = target.addEventListener.bind(target);
    vi.spyOn(target, "addEventListener").mockImplementation((type, handler, options) => {
      registered.push([target, type, handler, options]);
      add(type, handler, options);
    });
  }
  vi.spyOn(console, "info").mockImplementation(() => {});
  vi.spyOn(console, "warn").mockImplementation(() => {});
  vi.spyOn(console, "error").mockImplementation(() => {});
  localStorage.setItem("glpichat_widget_ui", JSON.stringify({ openTicketIds: [42], manualTicketIds: [42] }));
});
afterEach(() => {
  for (const [target, type, handler, options] of registered) target.removeEventListener(type, handler, options);
  registered = [];
  vi.clearAllTimers();
  vi.useRealTimers();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  document.body.innerHTML = "";
  delete window.__glpichatWidgetMounted;
  delete window.CFG_GLPI;
});
const message = (id, extra = {}) => ({ id, actor_type: "user", users_id: 8, sender_name: "Support", content: `Message ${id}`, date_creation: "2026-10-02 12:00:00", ...extra });
const json = (data) => new Response(JSON.stringify(data), { headers: { "Content-Type": "application/json" } });
const boot = async (fetchMock) => {
  vi.stubGlobal("fetch", fetchMock);
  await import("../../../src/js/glpichat-widget.js");
  document.dispatchEvent(new Event("DOMContentLoaded"));
  await vi.advanceTimersByTimeAsync(1);
};

it("consumes every bounded Poll page without jumping to the room head", async () => {
  const cursors = [];
  const fetchMock = vi.fn((url, options) => {
    if (url.includes("/Widget/Channels")) return Promise.resolve(json({ current_user_id: 7, channels: [{ tickets_id: 42, rooms_id: 3, room_type: "public", ticket_status: 1 }] }));
    if (url.endsWith("/Widget/Config")) return Promise.resolve(json({ poll_focused_ms: 100 }));
    if (url.includes("/Widget/History")) return Promise.resolve(json({ messages: [message(1)], events: [] }));
    if (url.endsWith("/Widget/Poll")) {
      const after = Number(options.body.get("channels[0][after_id]"));
      cursors.push(after);
      const page = Array.from({ length: 111 }, (_, i) => message(i + 1)).filter((m) => m.id > after).slice(0, 50);
      return Promise.resolve(json({ channels: { "42:public": { last_message_id: 111, messages: page, events: [] } } }));
    }
    return Promise.resolve(json({}));
  });
  await boot(fetchMock);
  await vi.advanceTimersByTimeAsync(310);
  expect(cursors.slice(0, 3)).toEqual([1, 51, 101]);
  expect(document.querySelectorAll("#glpichat-box-42 .glpichat-message-body")).toHaveLength(111);
  expect(document.querySelector("#glpichat-box-42").textContent).toContain("Message 111");
});

it("uses native ticket context for download links and image previews under a GLPI subdirectory", async () => {
  window.CFG_GLPI = { root_doc: "/helpdesk" };
  const fetchMock = vi.fn((url) => {
    if (url.includes("/Widget/Channels")) return Promise.resolve(json({ current_user_id: 7, channels: [{ tickets_id: 42, rooms_id: 3, room_type: "public", ticket_status: 1 }] }));
    if (url.endsWith("/Widget/Config")) return Promise.resolve(json({}));
    if (url.includes("/Widget/History")) return Promise.resolve(json({ messages: [
      message(1, { documents_id: 91, content: "Attachment added from GLPI Chat Desktop: proof.pdf" }),
      message(2, { documents_id: 92, content: "Attachment added from GLPI Chat: preview.png" }),
    ], events: [] }));
    return Promise.resolve(json({}));
  });
  await boot(fetchMock);
  const link = document.querySelector(".glpichat-attachment-link");
  expect(link.getAttribute("href")).toBe("/helpdesk/front/document.send.php?docid=91&itemtype=Ticket&items_id=42");
  expect(link.getAttribute("download")).toBe("proof.pdf");
  expect(document.querySelector(".glpichat-zoomable-img").getAttribute("src")).toBe("/helpdesk/front/document.send.php?docid=92&itemtype=Ticket&items_id=42");
});

it("keeps hidden or unfocused chat unread and acknowledges unchanged history when actually viewed", async () => {
  let visible = false;
  let focused = false;
  vi.spyOn(document, "visibilityState", "get").mockImplementation(() => visible ? "visible" : "hidden");
  vi.spyOn(document, "hasFocus").mockImplementation(() => focused);
  const fetchMock = vi.fn((url, options) => {
    if (url.includes("/Widget/Channels")) return Promise.resolve(json({ current_user_id: 7, channels: [{ tickets_id: 42, rooms_id: 3, room_type: "public", ticket_status: 1, unread_count: 1 }] }));
    if (url.endsWith("/Widget/Config")) return Promise.resolve(json({}));
    if (url.includes("/Widget/History")) return Promise.resolve(json({ messages: [message(9)], events: [] }));
    if (url.endsWith("/Widget/MarkRead")) return Promise.resolve(json({ last_read_message_id: Number(options.body.get("last_read_message_id")), unread_count: 0 }));
    return Promise.resolve(json({}));
  });
  await boot(fetchMock);
  const marks = () => fetchMock.mock.calls.filter(([url]) => url.endsWith("/Widget/MarkRead"));
  expect(marks()).toHaveLength(0);
  visible = true;
  document.dispatchEvent(new Event("visibilitychange"));
  await vi.advanceTimersByTimeAsync(1);
  expect(marks()).toHaveLength(0);
  focused = true;
  window.dispatchEvent(new Event("focus"));
  await vi.advanceTimersByTimeAsync(1);
  expect(marks()).toHaveLength(1);
  expect(marks()[0][1].body.get("last_read_message_id")).toBe("9");
  window.dispatchEvent(new Event("focus"));
  await vi.advanceTimersByTimeAsync(1);
  expect(marks()).toHaveLength(1);
});
