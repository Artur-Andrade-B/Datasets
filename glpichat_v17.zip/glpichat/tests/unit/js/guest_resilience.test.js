import { afterEach, beforeEach, expect, it, vi } from "vitest";
let listeners = [];
beforeEach(() => {
  vi.useFakeTimers();
  vi.resetModules();
  for (const target of [window, document]) {
    const add = target.addEventListener.bind(target);
    vi.spyOn(target, "addEventListener").mockImplementation((type, handler, options) => {
      listeners.push([target, type, handler, options]);
      add(type, handler, options);
    });
  }
  vi.spyOn(console, "error").mockImplementation(() => {});
  vi.spyOn(document, "visibilityState", "get").mockReturnValue("visible");
  window.__glpichatConfig = { guest_poll_ms: 100 };
  document.body.innerHTML = `<main class="glpichat" data-guest="1"><div class="glpichat-chatbox-panel"><div class="glpichat-window-head"></div><div data-role="messages"></div><div data-role="typing-indicator"></div><form data-role="guest-send-form"><input class="glpichat-file-input" name="file" type="file"><label class="glpichat-attach"></label><textarea name="content"></textarea><button type="submit">Send</button></form></div></main>`;
});
afterEach(() => {
  for (const [target, type, handler, options] of listeners) target.removeEventListener(type, handler, options);
  listeners = [];
  vi.clearAllTimers();
  vi.useRealTimers();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  document.body.innerHTML = "";
  delete window.__glpichatConfig;
});
const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json" } });
const syncData = (messages = []) => ({ messages, events: [], ticket_status: 1, session_remaining_seconds: 600 });
const msg = (id, content) => ({ id, actor_type: "user", content, sender_name: "Support", date_creation: "2026-10-02 12:00:00" });
const boot = async (fetchMock) => {
  vi.stubGlobal("fetch", fetchMock);
  await import("../../../src/js/glpichat-guest.js");
  document.dispatchEvent(new Event("DOMContentLoaded"));
  await vi.advanceTimersByTimeAsync(1);
};
it("recovers a guest session after transient network/proxy failures without declaring it expired", async () => {
  let calls = 0;
  const fetchMock = vi.fn(() => {
    calls += 1;
    if (calls === 2) return Promise.resolve(new Response("<html>proxy unavailable</html>", { status: 503 }));
    if (calls === 3) return Promise.reject(new TypeError("network unavailable"));
    return Promise.resolve(json(syncData(calls >= 4 ? [msg(1, "Recovered")] : [])));
  });
  await boot(fetchMock);
  await vi.advanceTimersByTimeAsync(210);
  expect(document.querySelector(".glpichat-countdown").textContent).not.toContain("Sessão expirada");
  expect(document.querySelector("textarea").disabled).toBe(false);
  expect(document.querySelector("[role='status']").hidden).toBe(false);
  await vi.advanceTimersByTimeAsync(100);
  expect(document.querySelector("[role='status']").hidden).toBe(true);
  expect(document.querySelectorAll(".glpichat-message")).toHaveLength(1);
  expect(document.body.textContent).toContain("Recovered");
});
it("still disables the composer when the server rejects the guest session", async () => {
  const fetchMock = vi.fn().mockResolvedValueOnce(json(syncData())).mockResolvedValue(json({ error: "Sessão de acesso inválida ou expirada." }, 400));
  await boot(fetchMock);
  await vi.advanceTimersByTimeAsync(110);
  expect(document.querySelector(".glpichat-countdown").textContent).toBe("Sessão expirada");
  expect(document.querySelector("textarea").disabled).toBe(true);
  const requests = fetchMock.mock.calls.length;
  await vi.advanceTimersByTimeAsync(500);
  expect(fetchMock).toHaveBeenCalledTimes(requests);
});
it("keeps a pending send when unrelated messages arrive and removes it only on its returned message ID", async () => {
  let syncCalls = 0;
  let resolveSync;
  let resolveSend;
  let committed = false;
  const fetchMock = vi.fn((url) => {
    if (url.includes("/Guest/Sync?")) {
      syncCalls += 1;
      if (syncCalls === 2) return new Promise((resolve) => { resolveSync = resolve; });
      return Promise.resolve(json(syncData(committed ? [msg(3, "My outgoing message")] : [])));
    }
    if (url.endsWith("/Guest/Send")) return new Promise((resolve) => { resolveSend = resolve; });
    return Promise.resolve(json({}));
  });
  await boot(fetchMock);
  await vi.advanceTimersByTimeAsync(100);
  const textarea = document.querySelector("textarea");
  textarea.value = "My outgoing message";
  textarea.closest("form").dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }));
  await vi.advanceTimersByTimeAsync(1);
  expect(document.querySelectorAll(".is-optimistic")).toHaveLength(1);
  resolveSync(json(syncData([msg(2, "Unrelated incoming message")])));
  await vi.advanceTimersByTimeAsync(1);
  expect(document.querySelectorAll(".is-optimistic")).toHaveLength(1);
  expect(document.body.textContent).toContain("Unrelated incoming message");
  committed = true;
  resolveSend(json({ message_id: 3 }));
  await vi.advanceTimersByTimeAsync(1);
  expect(document.querySelectorAll(".is-optimistic")).toHaveLength(0);
  expect(document.querySelectorAll(".glpichat-message")).toHaveLength(2);
  await vi.advanceTimersByTimeAsync(200);
  expect(document.querySelectorAll(".glpichat-message")).toHaveLength(2);
});
it("does not restore or resend committed guest text when its separate attachment is rejected", async () => {
  const NativeFormData = globalThis.FormData;
  class AttachmentFormData extends NativeFormData {
    constructor(form) {
      super(form);
      if (form) this.set("file", new File(["file payload"], "proof.pdf", { type: "application/pdf" }));
    }
  }
  vi.stubGlobal("FormData", AttachmentFormData);
  let textCommitted = false;
  const fetchMock = vi.fn((url, options) => {
    if (url.includes("/Guest/Sync?")) return Promise.resolve(json(syncData(textCommitted ? [msg(3, "Committed guest text")] : [])));
    if (url.endsWith("/Guest/Send")) {
      expect(options.body.get("file")).toBeNull();
      textCommitted = true;
      return Promise.resolve(json({ message_id: 3 }));
    }
    if (url.endsWith("/Guest/Upload")) return Promise.resolve(json({ error: "File exceeds configured size." }, 413));
    return Promise.resolve(json({}));
  });
  await boot(fetchMock);
  const textarea = document.querySelector("textarea");
  textarea.value = "Committed guest text";
  textarea.closest("form").dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }));
  await vi.advanceTimersByTimeAsync(1);
  expect(textarea.value).toBe("");
  expect(document.querySelectorAll(".is-optimistic")).toHaveLength(1);
  expect(document.querySelector(".is-optimistic").textContent).toContain("Arquivo: proof.pdf");
  expect(document.querySelector(".is-optimistic").textContent).toContain("Envio recusado");
  expect(document.querySelectorAll(".glpichat-message:not(.is-optimistic)")).toHaveLength(1);
  await vi.advanceTimersByTimeAsync(5100);
  expect(fetchMock.mock.calls.filter(([url]) => url.endsWith("/Guest/Send"))).toHaveLength(1);
  expect(document.querySelectorAll(".is-optimistic")).toHaveLength(1);
});
