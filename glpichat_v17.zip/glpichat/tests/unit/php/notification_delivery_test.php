<?php

declare(strict_types=1);
require_once dirname(__DIR__, 3) . '/src/domain/domain.php';
require_once dirname(__DIR__, 3) . '/src/notification_queue.php';
require_once dirname(__DIR__, 3) . '/src/HookHandler.php';

$count = 0;
function delivery_assert(bool $ok, string $text): void { ++$GLOBALS['count']; if (!$ok) { throw new RuntimeException($text); } }
class CommonDBTM { public array $fields = []; public array $input = []; public function getID(): int { return (int) ($this->fields['id'] ?? 0); } }
class Ticket extends CommonDBTM {
    public function getFromDB(int $id): bool { $this->fields = $GLOBALS['ticket']; return $id === 10; }
}
class ITILFollowup extends CommonDBTM {
    public function getFromDB(int $id): bool { $this->fields = $GLOBALS['followup']; return $id === 33; }
}
class NotificationTarget {}
class NotificationTargetTicket extends NotificationTarget { public mixed $obj; public string $raiseevent; public array $options; public array $data = []; }
class NotificationEvent {
    public static array $calls = [];
    public static bool $fail = false;
    public static function raiseEvent(string $event, Ticket $ticket, array $options, mixed $trigger): bool {
        self::$calls[] = compact('event', 'options', 'trigger') + ['emitter' => $_SESSION['mailcollector_user'] ?? null];
        if (self::$fail) { throw new RuntimeException('test'); }
        return true;
    }
}
class DeliveryRows extends ArrayIterator { public function current(): mixed { return parent::valid() ? parent::current() : false; } }
class DeliveryDB {
    public array $jobs = [];
    public array $locks = [];
    public function doQuery(string $sql): mixed {
        preg_match('/FROM `([^`]+)` WHERE id = (\d+) FOR UPDATE/', $sql, $match);
        $this->locks[] = $match[1];
        return match ($match[1]) {
            'glpi_plugin_glpichat_messages' => $GLOBALS['message'],
            'glpi_itilfollowups' => $GLOBALS['followup'],
            'glpi_plugin_glpichat_participants' => $GLOBALS['participant'],
        };
    }
    public function fetchAssoc(mixed $r): mixed { return $r; }
    public function request(array $q): DeliveryRows { return new DeliveryRows($q['FROM'] === 'glpi_plugin_glpichat_rooms' ? [$GLOBALS['room']] : []); }
    public function insert(string $table, array $row): bool { $this->jobs[] = $row; return true; }
}
function getUserName(int $id): string { return 'User ' . $id; }
function glpichat_room_id(int $ticket, string $room): int { return 3; }
function glpichat_latest_message_for_room(int $room): array { throw new RuntimeException('Wrong latest-message fallback'); }
function glpichat_notification_message_summary_from_row(array $row): array { return ['sender_name' => getUserName($row['users_id']), 'preview' => $row['content']]; }
function glpichat_can_user_read_notification_room(int $user, int $ticket, string $room): bool { return true; }

$DB = new DeliveryDB();
$ticket = ['id' => 10, 'is_deleted' => 0];
$message = ['id' => 22, 'tickets_id' => 10, 'rooms_id' => 3, 'itilfollowups_id' => 33, 'participant_type' => 'user', 'users_id' => 41, 'content' => 'Old edited text'];
$followup = ['id' => 33, 'itemtype' => 'Ticket', 'items_id' => 10, 'is_private' => 0, 'users_id' => 41, 'content' => 'Current exact text'];
$room = ['id' => 3, 'tickets_id' => 10, 'room_type' => 'public'];
$participant = ['id' => 70, 'rooms_id' => 3, 'users_id' => 41, 'participant_type' => 'user', 'left_at' => null];
$job = ['source_type' => 'message', 'source_id' => 22, 'tickets_id' => 10, 'room_type' => 'public', 'event' => 'glpichat_public_message', 'users_id' => 41];
$_SESSION = ['mailcollector_user' => 7, 'other' => 'retained'];
$before = $_SESSION;
delivery_assert(glpichat_deliver_notification_job($job), 'Current message renders');
$call = NotificationEvent::$calls[0];
delivery_assert($call['options']['glpichat_message_row']['id'] === 22 && $call['options']['glpichat_content'] === 'Current exact text', 'Exact current source is passed to templates, no stale mirror');
delivery_assert($call['emitter'] === 41 && $_SESSION === $before, 'Cron emitter uses original author preferences and restores all context');
delivery_assert(!in_array('glpi_tickets', $DB->locks, true), 'Delivery holds no ticket-wide lock');

$target = new NotificationTargetTicket(); $target->obj = new Ticket(); $target->obj->fields = $ticket;
$target->raiseevent = $job['event']; $target->options = $call['options'];
\GlpiPlugin\Glpichat\HookHandler::itemGetDatas($target);
delivery_assert($target->data['##glpichat.message_preview##'] === 'Current exact text', 'Actual hook uses validated exact source instead of room latest message');

NotificationEvent::$fail = true;
try { glpichat_deliver_notification_job($job); } catch (RuntimeException) {}
delivery_assert($_SESSION === $before, 'Failure restores cron emitter context');
NotificationEvent::$fail = false;
$followup['is_private'] = 1;
$calls = count(NotificationEvent::$calls);
delivery_assert(!glpichat_deliver_notification_job($job) && count(NotificationEvent::$calls) === $calls, 'Changed privacy never raises an event');
$followup['is_private'] = 0;
$native = array_replace($job, ['source_type' => 'followup', 'source_id' => 33, 'event' => 'add_followup']);
delivery_assert(glpichat_deliver_notification_job($native), 'Native followup event retained');
$call = end(NotificationEvent::$calls);
delivery_assert($call['options'] === ['followup_id' => 33, 'is_private' => 0] && $call['trigger'] instanceof ITILFollowup && $call['trigger']->getID() === 33, 'Core native trigger/options exactly preserved');

$joined = array_replace($job, ['source_type' => 'participant', 'source_id' => 70, 'event' => 'glpichat_user_joined']);
delivery_assert(glpichat_deliver_notification_job($joined), 'Active join can be notified');
$participant['left_at'] = '2026-10-02 16:00:00';
delivery_assert(!glpichat_deliver_notification_job($joined), 'Already-left join is suppressed');

// The actual hook preserves native event intent even when a merged followup
// has no plugin mirror and document suppression is active.
$GLOBALS['GLPICHAT_SUPPRESS_DOCUMENT_HOOK'] = true;
$item = new ITILFollowup(); $item->fields = $followup; $item->input = ['_disablenotif' => true, '_glpichat_deferred_native_notification' => true];
\GlpiPlugin\Glpichat\HookHandler::itemAdd($item);
delivery_assert(count($DB->jobs) === 1 && $DB->jobs[0]['source_type'] === 'followup' && $DB->jobs[0]['source_id'] === 33, 'Marked native followup hook queues independently of mirror/document behavior');
$item->input = ['_disablenotif' => true];
\GlpiPlugin\Glpichat\HookHandler::itemAdd($item);
delivery_assert(count($DB->jobs) === 1, 'Desktop native suppression without marker remains unchanged');
echo '[PASS] Notification delivery and hooks: ' . $count . " assertions.\n";
