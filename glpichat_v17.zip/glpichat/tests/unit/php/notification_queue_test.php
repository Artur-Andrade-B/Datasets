<?php

declare(strict_types=1);
require_once dirname(__DIR__, 3) . '/src/domain/domain.php';
require_once dirname(__DIR__, 3) . '/src/notification_queue.php';

$count = 0;
function queue_assert(bool $value, string $description): void {
    ++$GLOBALS['count'];
    if (!$value) { throw new RuntimeException($description); }
}
class QueueRows extends ArrayIterator {
    public function current(): mixed { return parent::valid() ? parent::current() : false; }
}
class QueueFixtureDb {
    public array $jobs = [];
    public array $nativeQueue = [];
    public array $snapshot = [];
    public bool $failComplete = false;
    public int $commits = 0;
    public int $rollbacks = 0;
    public function request(array $query): QueueRows {
        $rows = array_values(array_filter($this->jobs, function ($row) use ($query) {
            foreach ($query['WHERE'] ?? [] as $field => $value) {
                if (is_array($value)) {
                    if ($value[0] === '<=' && $row[$field] > $value[1]) { return false; }
                } elseif ($row[$field] !== $value) { return false; }
            }
            return true;
        }));
        return new QueueRows(array_slice($rows, 0, $query['LIMIT'] ?? count($rows)));
    }
    public function insert(string $table, array $row): bool {
        queue_assert($table === 'glpi_plugin_glpichat_notificationjobs', 'Only notification intent is inserted by enqueue');
        $row['id'] = count($this->jobs) + 1;
        $this->jobs[$row['id']] = $row;
        return true;
    }
    public function beginTransaction(): void { $this->snapshot = [$this->jobs, $this->nativeQueue]; }
    public function commit(): void { ++$this->commits; $this->snapshot = []; }
    public function rollBack(): void { ++$this->rollbacks; [$this->jobs, $this->nativeQueue] = $this->snapshot; $this->snapshot = []; }
    public function doQuery(string $sql): mixed {
        queue_assert(preg_match('/^SELECT \* FROM `glpi_plugin_glpichat_notificationjobs` WHERE id = (\d+) FOR UPDATE$/', $sql, $match) === 1, 'Only the exact job is locked, never the ticket');
        return $this->jobs[(int) $match[1]] ?? false;
    }
    public function fetchAssoc(mixed $result): mixed { return $result; }
    public function update(string $table, array $values, array $where): bool {
        if ($this->failComplete && isset($values['completed_at'])) { $this->failComplete = false; return false; }
        foreach ($this->jobs as $id => $row) {
            foreach ($where as $key => $value) { if ($row[$key] !== $value) { continue 2; } }
            $this->jobs[$id] = array_replace($row, $values);
        }
        return true;
    }
}

$DB = new QueueFixtureDb();
glpichat_queue_message_notifications(10, 'public', 'user', 41, 'Sensitive text must not be stored', 22, 33, true);
queue_assert(count($DB->jobs) === 2, 'Web message stores distinct plugin and native intents');
queue_assert(!str_contains(json_encode($DB->jobs), 'Sensitive'), 'Outbox stores no message text');
glpichat_queue_message_notifications(10, 'public', 'user', 41, 'retry', 22, 33, true);
queue_assert(count($DB->jobs) === 2, 'Repeated intent insertion does not duplicate either event');
glpichat_queue_message_notifications(10, 'public', 'user', 41, 'Desktop', 23, 34);
queue_assert(count($DB->jobs) === 3 && $DB->jobs[3]['source_type'] === 'message', 'Desktop keeps plugin event only, preserving native suppression');
glpichat_queue_user_joined_notification(10, 'public', 41, 70);
queue_assert(count($DB->jobs) === 4 && $DB->jobs[4]['event'] === 'glpichat_user_joined', 'First participant event is deferred');
$bad = false;
try { glpichat_queue_notification_job('ticket', 1, 10, 'arbitrary', 'public', 41); } catch (InvalidArgumentException) { $bad = true; }
queue_assert($bad, 'Queue rejects unrelated event/source types');

$job = $DB->jobs[1];
$message = ['id' => 22, 'tickets_id' => 10, 'rooms_id' => 3, 'itilfollowups_id' => 33, 'participant_type' => 'user', 'users_id' => 41];
$followup = ['id' => 33, 'itemtype' => 'Ticket', 'items_id' => 10, 'is_private' => 0, 'users_id' => 41];
$room = ['id' => 3, 'tickets_id' => 10, 'room_type' => 'public'];
queue_assert(glpichat_notification_source_matches($job, $message, $followup, $room), 'Current public source is eligible');
queue_assert(!glpichat_notification_source_matches($job, array_replace($message, ['users_id' => 99]), $followup, $room), 'Changed mirror author is suppressed');
queue_assert(!glpichat_notification_source_matches($job, $message, array_replace($followup, ['users_id' => 99]), $room), 'Changed native author is suppressed');
queue_assert(!glpichat_notification_source_matches($job, $message, null, $room), 'Deleted followup suppresses plugin notification');
queue_assert(!glpichat_notification_source_matches($job, $message, array_replace($followup, ['is_private' => 1]), $room), 'Made-private followup suppresses queued public preview');
queue_assert(!glpichat_notification_source_matches($job, $message, array_replace($followup, ['items_id' => 99]), $room), 'Moved source cannot disclose through original ticket');
queue_assert(!glpichat_notification_source_matches($job, $message, array_replace($followup, ['itemtype' => 'Problem']), $room), 'Followup type is revalidated');
queue_assert(!glpichat_notification_source_matches($job, null, $followup, $room), 'Deleted mirror is suppressed');
queue_assert(!glpichat_notification_source_matches($job, $message, $followup, array_replace($room, ['room_type' => 'internal'])), 'Changed channel is suppressed');
queue_assert(!glpichat_notification_source_matches($job, array_replace($message, ['participant_type' => 'guest']), $followup, $room), 'Original actor event type cannot change under a pending job');
queue_assert(glpichat_notification_source_matches($job, array_replace($message, ['itilfollowups_id' => 0]), null, $room), 'Message without native followup remains eligible');

// Simulate a crash after core native queue writes and before the job completes.
$DB->jobs = [1 => $job];
$DB->failComplete = true;
$deliveryCalls = 0;
$deliver = function (array $job) use (&$deliveryCalls): bool {
    global $DB;
    ++$deliveryCalls;
    $DB->nativeQueue[] = ['event' => $job['event'], 'source' => $job['source_id']];
    return true;
};
$result = glpichat_process_notification_jobs(20, $deliver);
queue_assert($result === ['delivered' => 0, 'suppressed' => 0, 'failed' => 1], 'Completion error leaves retryable job');
queue_assert($DB->nativeQueue === [] && $DB->rollbacks === 1, 'Core queue writes roll back with the job');
queue_assert($DB->jobs[1]['status'] === 'pending' && $DB->jobs[1]['attempts'] === 1, 'Failure retains intent and records attempt');
queue_assert($DB->jobs[1]['available_at'] > date('Y-m-d H:i:s'), 'Failure backs off without blocking other sends');
queue_assert(!str_contains($DB->jobs[1]['last_error'], 'Unable'), 'Diagnostics keep exception class without server/content detail');
$DB->jobs[1]['available_at'] = '2000-01-01 00:00:00';
$result = glpichat_process_notification_jobs(20, $deliver);
queue_assert($result['delivered'] === 1 && count($DB->nativeQueue) === 1 && $DB->jobs[1]['status'] === 'done', 'Retry commits exactly one native queue entry');
glpichat_process_notification_jobs(20, $deliver);
queue_assert($deliveryCalls === 2 && count($DB->nativeQueue) === 1, 'Completed job is never rendered again');
$DB->jobs[1] = $job;
$result = glpichat_process_notification_jobs(20, static fn (array $row): bool => false);
queue_assert($result['suppressed'] === 1 && $DB->jobs[1]['status'] === 'suppressed', 'No-longer-eligible source completes without delivery or retry');

echo '[PASS] Deferred notification outbox: ' . $count . " assertions.\n";
