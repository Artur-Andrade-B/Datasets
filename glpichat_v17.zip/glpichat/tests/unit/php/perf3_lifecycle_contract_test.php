<?php

declare(strict_types=1);

/**
 * Source-level safety contract for the lifecycle slice inherited through
 * foundation1. The behavior remains the perf3/perf4 contract even as release
 * identity advances.
 *
 * This test intentionally has no GLPI or Composer dependency, so it can guard
 * package composition before a candidate is copied into a GLPI instance. The
 * destructive lifecycle suite performs the complementary database assertions.
 */

$plugin_root = dirname(__DIR__, 3);
$setup = file_get_contents($plugin_root . '/setup.php');
$hook = file_get_contents($plugin_root . '/hook.php');
$config = file_get_contents($plugin_root . '/front/config.php');
$plugin_xml = file_get_contents($plugin_root . '/plugin.xml');

if (!is_string($setup) || !is_string($hook) || !is_string($config) || !is_string($plugin_xml)) {
    fwrite(STDERR, "[FAIL] Nao foi possivel carregar os arquivos do contrato de lifecycle.\n");
    exit(1);
}

$assert = static function (bool $condition, string $message): void {
    if (!$condition) {
        fwrite(STDERR, "[FAIL] {$message}\n");
        exit(1);
    }
    fwrite(STDOUT, "[PASS] {$message}\n");
};

$package = json_decode(file_get_contents($plugin_root . '/package.json'), true, 512, JSON_THROW_ON_ERROR);
$lock = json_decode(file_get_contents($plugin_root . '/package-lock.json'), true, 512, JSON_THROW_ON_ERROR);
$versionMatches = [];
$buildMatches = [];
$xmlMatches = [];
$assert(
    preg_match("/define\('PLUGIN_GLPICHAT_VERSION', '([0-9]+\.[0-9]+\.[0-9]+)'\);/", $setup, $versionMatches) === 1
        && preg_match("/define\('PLUGIN_GLPICHAT_BUILD', '([a-z0-9][a-z0-9.-]*)'\);/", $setup, $buildMatches) === 1
        && preg_match('~<num>([0-9]+\.[0-9]+\.[0-9]+)</num>~', $plugin_xml, $xmlMatches) === 1
        && $xmlMatches[1] === $versionMatches[1]
        && ($package['version'] ?? null) === $versionMatches[1]
        && ($lock['version'] ?? null) === $versionMatches[1]
        && ($lock['packages']['']['version'] ?? null) === $versionMatches[1],
    'Setup, XML, package.json e lockfile identificam a mesma versao; build possui identificador valido'
);

$init_start = strpos($setup, 'function plugin_init_glpichat(): void');
$version_start = strpos($setup, 'function plugin_version_glpichat(): array');
$assert($init_start !== false && $version_start !== false && $version_start > $init_start, 'plugin_init pode ser isolado para auditoria');
$init_body = substr($setup, $init_start, $version_start - $init_start);

$assert(
    !str_contains($init_body, 'glpichat_ensure_runtime_schema')
        && !str_contains($init_body, 'glpichat_ensure_profile_rights_model')
        && !str_contains($init_body, 'reloadCurrentProfile'),
    'plugin_init nao executa reparo de schema, direitos ou reload de perfil'
);

$assert(
    str_contains($init_body, "glpichat_config_bool('browser_surface_enabled', false)")
        && !str_contains($init_body, 'cap_browser_assets_enabled'),
    'Injecao usa o novo kill switch independente e fail-closed'
);

$assert(
    str_contains($init_body, "Hooks::ITEM_CAN")
        && str_contains($init_body, "HookHandler::class, 'canDocument'")
        && str_contains($init_body, "Hooks::ADD_RECIPIENT_TO_TARGET"),
    'Hooks obrigatorios de seguranca continuam registrados fora da injecao visual'
);

$assert(
    !str_contains($init_body, '/External/')
        && substr_count($init_body, 'registerPluginStatelessPath') === 1
        && str_contains($init_body, "#^/Guest/.*#"),
    'plugin_init preserva somente a familia Guest; Desktop e registrado no boot separado'
);

$boot_start = strpos($setup, 'function plugin_glpichat_boot(): void');
$assert($boot_start !== false && $boot_start < $init_start, 'Desktop registra prefixo stateless antes do init');
$boot_body = substr($setup, $boot_start, $init_start - $boot_start);
$assert(
    substr_count($boot_body, 'registerPluginStatelessPath') === 1
        && str_contains($boot_body, '#^/(?:Desktop|Management)/V1(?:/|$)#')
        && !str_contains($boot_body, 'schema_install')
        && !str_contains($boot_body, 'schema_health'),
    'Boot registra apenas os prefixos exatos Desktop e Management, sem DDL nem inspecao de schema'
);

$field_positions = [];
foreach (['last_activity', 'last_seen', 'is_typing_until', 'last_send_at'] as $field) {
    $position = strpos($hook, "addField('glpi_plugin_glpichat_participants', '{$field}'");
    $assert($position !== false, "Migracao contempla participants.{$field}");
    $field_positions[] = $position;
}
$index_position = strpos($hook, 'glpichat_add_indexes($schema_migration);');
$assert(
    $index_position !== false && max($field_positions) < $index_position,
    'Todos os campos de compatibilidade sao enfileirados antes dos indices'
);

$assert(
    !str_contains($hook, "addCrontask(\\GlpiPlugin\\Glpichat\\EventCleanupCron::class, 'ExpireParticipants'")
        && str_contains($hook, "'name'     => 'ExpireParticipants'"),
    'Upgrade nao registra e remove com seguranca a crontask residual de lab1'
);

$assert(
    str_contains($hook, "'browser_surface_enabled'      => \$cfg_default('browser_surface_enabled', '0')")
        && str_contains($config, "\$_POST['browser_surface_enabled'] ?? '0'")
        && str_contains($config, "\$cfg('browser_surface_enabled', '0')"),
    'Kill switch nasce desligado, pode ser salvo e e exibido na configuracao'
);

$notification_postcondition = strpos($hook, 'glpichat_install_default_notifications();');
$foundation_marker_write = strpos($hook, "'foundation_schema_version' => glpichat_foundation_version_to_store(");
$install_return = strpos($hook, 'return true;', $foundation_marker_write === false ? 0 : $foundation_marker_write);
$assert(
    $notification_postcondition !== false
        && $foundation_marker_write !== false
        && $install_return !== false
        && $notification_postcondition < $foundation_marker_write
        && $foundation_marker_write < $install_return
        && substr_count($hook, "'foundation_schema_version' => glpichat_foundation_version_to_store(") === 1,
    'Marker foundation e gravado uma vez, somente apos os postconditions do lifecycle'
);

$assert(
    str_contains($hook, "'public_authorization_shadow_enabled' => glpichat_foundation_shadow_config_value(")
        && !str_contains($config, 'public_authorization_shadow_enabled'),
    'Shadow publico nasce fail-closed e permanece oculto da configuracao web'
);

fwrite(STDOUT, "[PASS] Contrato de lifecycle/configuracao herdado concluido\n");
