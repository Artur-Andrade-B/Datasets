#!/usr/bin/env python3
"""Round-trip actual C# multipart bytes through PHP's HTTP upload parser/Symfony.

The receiver is a disposable loopback-only fixture; it validates with production
attachment request/input functions but never enrolls, writes native documents or
contacts a user's GLPI. Usage: script PHP PLUGIN_ROOT AUTOLOAD WIRE_DIR [OUTPUT]
"""
import json, os, socket, subprocess, sys, tempfile, time, urllib.request
from pathlib import Path
php, plugin, autoload, wire_dir = sys.argv[1:5]
wire = Path(wire_dir)
metadata = json.loads((wire/'multipart.json').read_text())
receiver = r'''<?php
require getenv('GLPICHAT_TEST_AUTOLOAD');
require getenv('GLPICHAT_TEST_PLUGIN') . '/src/desktop/common.php';
require getenv('GLPICHAT_TEST_PLUGIN') . '/src/desktop/attachments.php';
final class Toolbox { public static function getPhpUploadSizeLimit(): int { return 1048576; } }
final class DocumentType { public static function getUploadableFilePattern(): string { return '/\\.txt$/i'; } }
final class Document { public static function isValidDoc(string $name): string { return preg_match('/\\.txt$/i',$name) ? 'TXT' : ''; } }
final class WireRows { public int $position=0; public array $rows=[['ext'=>'txt']]; public function free(): void {} }
final class WireDB {
 public function doQuery(string $sql): WireRows { return new WireRows(); }
 public function fetchAssoc(WireRows $rows): array|false { return $rows->rows[$rows->position++]??false; }
}
$DB=new WireDB(); $CFG_GLPI=['document_max_size'=>1];
try {
 [$uuid,$file]=glpichat_desktop_attachment_request(Symfony\Component\HttpFoundation\Request::createFromGlobals());
 $input=glpichat_desktop_attachment_input($file);
 header('Content-Type: application/json'); echo json_encode(['uuid'=>$uuid]+$input, JSON_THROW_ON_ERROR);
} catch (Throwable $error) { http_response_code(400); echo get_class($error).':'.$error->getMessage(); }
'''
with tempfile.TemporaryDirectory(prefix='glpichat-multipart-wire-') as temporary:
    temp = Path(temporary)
    (temp/'index.php').write_text(receiver)
    probe = socket.socket(); probe.bind(('127.0.0.1',0)); port=probe.getsockname()[1]; probe.close()
    env=os.environ.copy(); env['GLPICHAT_TEST_PLUGIN']=str(Path(plugin).resolve()); env['GLPICHAT_TEST_AUTOLOAD']=str(Path(autoload).resolve())
    log=(temp/'server.log').open('wb')
    server=subprocess.Popen([php,'-S',f'127.0.0.1:{port}','-t',str(temp)],stdout=log,stderr=log,env=env)
    try:
        for _ in range(50):
            try:
                with socket.create_connection(('127.0.0.1',port),timeout=.2): break
            except OSError:
                if server.poll() is not None: raise RuntimeError('Disposable PHP receiver failed: '+(temp/'server.log').read_text())
                time.sleep(.05)
        request=urllib.request.Request(f'http://127.0.0.1:{port}/',data=(wire/'multipart.bin').read_bytes(),headers={'Content-Type':metadata['content_type']},method='POST')
        with urllib.request.urlopen(request,timeout=10) as response: result=json.loads(response.read())
        expected={'uuid':metadata['client_message_id'],'name':metadata['filename'],'size':metadata['payload_size'],'sha256':metadata['sha256']}
        assert result==expected, (result,expected)
        report={'passed':True,'assertions':4,'scope':'Actual production C# multipart bytes -> PHP HTTP upload parser -> Symfony UploadedFile -> production attachment validation; loopback fixture only','received':result}
        if len(sys.argv)>5: Path(sys.argv[5]).write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
        print('PASS multipart wire: UTF-8 original filename, stable UUID, actual byte count and SHA256 match through PHP HTTP upload parser.')
    finally:
        server.terminate()
        try: server.wait(timeout=5)
        except subprocess.TimeoutExpired: server.kill(); server.wait(timeout=5)
        log.close()
