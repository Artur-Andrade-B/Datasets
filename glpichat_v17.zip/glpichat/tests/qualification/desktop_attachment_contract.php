<?php

declare(strict_types=1);

/** Actual Symfony uploads/responses and production attachment service; native
 * writers/auth use explicit failure-injection fixtures. Native SQL and core
 * Document writers are qualified separately, not claimed by this harness. */
if (PHP_SAPI !== 'cli' || $argc !== 3) { exit(2); }
[$unused, $plugin, $autoload] = $argv;
require $autoload;
require $plugin . '/src/desktop/common.php';
require $plugin . '/src/desktop/conversations.php';
require $plugin . '/src/desktop/attachments.php';
final class Config { public static function getConfigurationValues(string $scope): array { return ['desktop_idempotency_key'=>str_repeat('a',64),'desktop_schema_version'=>'5']; } }
final class Toolbox { public static function getPhpUploadSizeLimit(): int { return 1048576; } }
final class DocumentType { public static function getUploadableFilePattern(): string { return '/\.(txt|pdf)$/i'; } }
final class Ticket { public static bool $merged=false; public static function getMergedTickets(int $id): array { return self::$merged ? [99] : []; } }
final class RequestType { public function find(array $where,array $order,int $limit): array { return [['id'=>1,'is_active'=>1,'is_itilfollowup'=>1]]; } }
final class AttachmentRows { public int $at=0; public function __construct(public array $rows) {} public function free(): void {} }
final class AttachmentDB {
    public array $receipts=[], $followups=[], $documents=[], $links=[], $mirrors=[], $jobs=[];
    public bool $requester=true, $private=false, $revoked=false, $failQueue=false;
    public int $status=2,$last=0;
    private array $backup=[];
    public function escape(string $s): string { return addslashes($s); }
    public function insertId(): int { return $this->last; }
    public function beginTransaction(): void { $this->backup=[$this->receipts,$this->followups,$this->documents,$this->links,$this->mirrors,$this->jobs]; }
    public function commit(): void {}
    public function rollBack(): void { [$this->receipts,$this->followups,$this->documents,$this->links,$this->mirrors,$this->jobs]=$this->backup; }
    public function insert(string $table,array $input): bool { $input['id']=++$this->last; $this->receipts[$input['id']]=$input; return true; }
    public function update(string $table,array $input,array $where): bool { $this->receipts[$where['id']]=array_replace($this->receipts[$where['id']],$input); return true; }
    public function fetchAssoc(AttachmentRows $rows): array|false { return $rows->rows[$rows->at++]??false; }
    public function doQuery(string $sql): AttachmentRows {
        if (str_contains($sql,'SELECT ext FROM')) { return new AttachmentRows([['ext'=>'txt'],['ext'=>'pdf'],['ext'=>'/^namedfile$/']]); }
        if (str_contains($sql,'FROM glpi_tickets_users')) { return new AttachmentRows($this->requester ? [['id'=>1]] : []); }
        if (str_contains($sql,'FROM glpi_tickets ')) { return new AttachmentRows([['id'=>7,'name'=>'Test','status'=>$this->status,'entities_id'=>2]]); }
        if (str_starts_with($sql,'SELECT DISTINCT f.id AS message_id')) {
            if ($this->private) { return new AttachmentRows([]); }
            $rows=[];
            foreach ($this->documents as $d) {
                foreach($this->links as $link) {
                    if ($link['documents_id']===$d['id'] && $link['itemtype']==='ITILFollowup') {
                        if (preg_match('/AND d.id = (\d+)/',$sql,$id) && (int)$id[1]!==$d['id']) { continue; }
                        if (preg_match('/f.id IN \(([^)]+)\)/',$sql,$messages) && !in_array((string)$link['items_id'],explode(',',$messages[1]),true)) { continue; }
                        $rows[]=['message_id'=>$link['items_id']]+$d;
                    }
                }
            }
            return new AttachmentRows($rows);
        }
        if (str_contains($sql,'FROM glpi_itilfollowups f')) {
            preg_match('/WHERE f.id = (\d+)/',$sql,$id);
            $r=$this->followups[(int)($id[1]??0)]??null;
            return new AttachmentRows($r!==null&&!$this->private ? [$r] : []);
        }
        if(str_contains($sql,'FROM glpi_plugin_glpichat_desktopsends')) {
            if(str_contains($sql,'COUNT(*)')) { return new AttachmentRows([['n'=>count($this->receipts)]]); }
            preg_match("/client_message_id = '([^']+)'/",$sql,$uuid);
            return new AttachmentRows(array_values(array_filter($this->receipts,fn($r)=>$r['client_message_id']===($uuid[1]??''))));
        }
        if(str_contains($sql,'FROM glpi_plugin_glpichat_messages')) { return new AttachmentRows($this->mirrors); }
        throw new RuntimeException('Unexpected fixture SQL: '.$sql);
    }
}
function glpichat_desktop_validate_actor(array $actor,bool $lock): array { if ($GLOBALS['DB']->revoked) { glpichat_desktop_fail('invalid_credential','revoked',401); } return $actor; }
final class ITILFollowup { public function add(array $input): int { global $DB; $id=100+count($DB->followups); $DB->followups[$id]=['id'=>$id]+$input; return $id; } }
final class Document {
    public static function isValidDoc(string $name): string { return preg_match('/\.(txt|pdf)$/i',$name) ? strtoupper(pathinfo($name,PATHINFO_EXTENSION)) : ''; }
    public static array $inputs=[];
    public function add(array $input): int {
        global $DB;
        self::$inputs[]=['input'=>$input,'session'=>$_SESSION,'suppressed'=>$GLOBALS['GLPICHAT_SUPPRESS_DOCUMENT_HOOK']];
        $prefix=$input['_prefix_filename'][0]; $name=substr($input['upload_file'],strlen($prefix));
        $id=200+count($DB->documents); $path=GLPI_DOC_DIR.'/'.$id.'.txt';
        rename(GLPI_UPLOAD_DIR.'/'.$input['upload_file'],$path);
        $DB->documents[$id]=['id'=>$id,'name'=>$input['name'],'filename'=>$name,'filepath'=>$id.'.txt','mime'=>'text/plain','sha1sum'=>sha1_file($path)];
        return $id;
    }
}
class Document_Item { public function add(array $input): int { $GLOBALS['DB']->links[]=$input; return count($GLOBALS['DB']->links); } }
function glpichat_add_message(int $ticket,string $room,string $type,int $user,int $participant,string $content,int $document,int $followup,bool $notify): int {
    $GLOBALS['DB']->mirrors[]=['id'=>300,'documents_id'=>$document,'itilfollowups_id'=>$followup]; return 300;
}
function glpichat_queue_message_notifications(...$args): void { if($GLOBALS['DB']->failQueue) { throw new RuntimeException('Injected queue failure'); } $GLOBALS['DB']->jobs[]=$args; }
$root=sys_get_temp_dir().'/glpichat-attachment-contract-'.bin2hex(random_bytes(8));
mkdir($root,0700); mkdir($root.'/upload',0700); mkdir($root.'/docs',0700);
define('GLPI_UPLOAD_DIR',$root.'/upload'); define('GLPI_DOC_DIR',$root.'/docs');
$checks=0;
function check(bool $yes,string $what): void { if(!$yes) { throw new RuntimeException($what); } ++$GLOBALS['checks']; }
function expected(string $code,callable $f): void { try{$f();}catch(GlpichatDesktopException $e){ check($e->errorCode===$code,'Expected '.$code.' got '.$e->errorCode); return;} throw new RuntimeException('Missing error '.$code); }
function upload(string $bytes='File bytes',string $name='arquivo.txt'): Symfony\Component\HttpFoundation\File\UploadedFile {
    $path=tempnam($GLOBALS['root'],'input'); file_put_contents($path,$bytes);
    return new Symfony\Component\HttpFoundation\File\UploadedFile($path,$name,'application/octet-stream',null,true);
}
$DB=new AttachmentDB(); $CFG_GLPI=['document_max_size'=>1];
$actor=['user_id'=>10,'entity_id'=>2,'can_read'=>true,'can_create'=>true];
$uuid='01234567-89ab-4cde-8fab-0123456789ab';
try {
    check(glpichat_desktop_attachment_policy()===['max_bytes'=>1048576,'extensions'=>['txt','pdf']], 'Native max and extension policy; native regex rules stay server-authoritative');
    expected('invalid_attachment',fn()=>glpichat_desktop_attachment_input(null));
    expected('attachment_type_not_allowed',fn()=>glpichat_desktop_attachment_input(upload('x','script.exe')));
    expected('invalid_attachment_name',fn()=>glpichat_desktop_attachment_input(upload('x',str_repeat('é',100).'.txt')));
    expected('invalid_attachment_name',fn()=>glpichat_desktop_attachment_input(upload('x',"a\u{202E}.txt")));
    expected('attachment_too_large',fn()=>glpichat_desktop_attachment_input(upload(str_repeat('x',1048577))));
    expected('invalid_message_id',fn()=>glpichat_desktop_upload_attachment($actor,7,'bad',upload()));
    $request=new Symfony\Component\HttpFoundation\Request([],['client_message_id'=>$uuid],[],[],['file'=>upload()],['CONTENT_TYPE'=>'multipart/form-data; boundary=test']);
    [$requestUuid,$requestFile]=glpichat_desktop_attachment_request($request);
    check($requestUuid===$uuid && $requestFile instanceof Symfony\Component\HttpFoundation\File\UploadedFile,'Actual Symfony multipart request resolves one stable UUID and file');
    $request->request->set('base_url','https://evil.invalid');
    expected('invalid_attachment',fn()=>glpichat_desktop_attachment_request($request));
    $_SESSION=['glpiID'=>99,'glpiinventoryuserrunning'=>98,'glpicronuserrunning'=>97,'glpi_currenttime'=>'2026-10-02 18:00:00','preserved'=>'value']; $session=$_SESSION;
    $GLOBALS['GLPICHAT_SUPPRESS_DOCUMENT_HOOK']='outer-value';
    $sent=glpichat_desktop_upload_attachment($actor,7,$uuid,upload());
    check($sent['message']['attachments']===[['id'=>200,'name'=>'arquivo.txt','size'=>10,'mime'=>'text/plain']], 'Committed response includes saved native attachment metadata');
    check(count($DB->followups)===1 && count($DB->receipts)===1 && count($DB->documents)===1 && count($DB->links)===1 && count($DB->jobs)===1,'Followup/document/scoped link/mirror/receipt/notification are committed together');
    $write=Document::$inputs[0];
    check($write['input']['users_id']===10 && $write['input']['entities_id']===2 && !isset($write['input']['itemtype']), 'Document receives explicit bearer author/entity without synchronous item event');
    check(!isset($write['session']['glpiID'],$write['session']['glpiinventoryuserrunning'],$write['session']['glpicronuserrunning']) && $write['suppressed']===true,'No ambient browser actor can override native author; document hook is suppressed');
    check($_SESSION===$session && $GLOBALS['GLPICHAT_SUPPRESS_DOCUMENT_HOOK']==='outer-value','Prior session and nested hook flag are restored exactly');
    $DB->status=6;
    $replay=glpichat_desktop_upload_attachment($actor,7,$uuid,upload());
    check($replay===$sent && count($DB->documents)===1 && count($DB->jobs)===1,'Lost-response retry on now-closed ticket acknowledges exact committed file without duplicate');
    expected('idempotency_conflict',fn()=>glpichat_desktop_upload_attachment($actor,7,$uuid,upload('changed')));
    expected('idempotency_conflict',fn()=>glpichat_desktop_upload_attachment($actor,7,$uuid,upload('File bytes','renamed.txt')));
    expected('conversation_read_only',fn()=>glpichat_desktop_upload_attachment($actor,7,'11234567-89ab-4cde-8fab-0123456789ab',upload()));
    $DB->status=2; $DB->private=true;
    expected('attachment_unavailable',fn()=>glpichat_desktop_upload_attachment($actor,7,$uuid,upload()));
    expected('attachment_unavailable',fn()=>glpichat_desktop_download_attachment($actor,7,100,200));
    $DB->private=false; $DB->requester=false;
    expected('conversation_unavailable',fn()=>glpichat_desktop_upload_attachment($actor,7,$uuid,upload()));
    expected('conversation_unavailable',fn()=>glpichat_desktop_download_attachment($actor,7,100,200));
    $DB->requester=true; $DB->revoked=true;
    expected('invalid_credential',fn()=>glpichat_desktop_upload_attachment($actor,7,$uuid,upload())); $DB->revoked=false;
    $download=glpichat_desktop_download_attachment($actor,7,100,200);
    check($download instanceof Symfony\Component\HttpFoundation\BinaryFileResponse && $download->getFile()->getContent()==='File bytes','Authenticated route serves exact managed bytes');
    check($download->headers->get('Content-Type')==='application/octet-stream' && str_contains($download->headers->get('Content-Disposition'),'attachment') && str_contains($download->headers->get('Cache-Control'),'no-store'),'Download forces save with private noncacheable nosniff headers');
    expected('attachment_unavailable',fn()=>glpichat_desktop_download_attachment($actor,7,100,999));
    check(glpichat_desktop_document_path(['filepath'=>'../upload'])===null && glpichat_desktop_document_path(['filepath'=>'/etc/passwd'])===null,'Document paths cannot escape managed storage');
    file_put_contents(GLPI_DOC_DIR.'/200.txt','tampered');
    expected('attachment_unavailable',fn()=>glpichat_desktop_upload_attachment($actor,7,$uuid,upload()));
    expected('attachment_unavailable',fn()=>glpichat_desktop_download_attachment($actor,7,100,200));
    file_put_contents(GLPI_DOC_DIR.'/200.txt','File bytes');
    $DB->failQueue=true;
    try { glpichat_desktop_upload_attachment($actor,7,'21234567-89ab-4cde-8fab-0123456789ab',upload('new-file')); throw new LogicException('Expected failure'); } catch (RuntimeException $e) { check($e->getMessage()==='Injected queue failure','Injected notification failure is observed'); }
    check(count($DB->documents)===1 && count($DB->followups)===1 && count($DB->receipts)===1 && count($DB->jobs)===1,'Notification failure rolls back every native row/receipt before success');
    check($_SESSION===$session && $GLOBALS['GLPICHAT_SUPPRESS_DOCUMENT_HOOK']==='outer-value','Exception path restores ambient session and hook suppression');
    $file=upload('private'); $input=glpichat_desktop_attachment_input($file);
    $id=glpichat_desktop_store_attachment($actor,7,101,$file,$input);
    $links=array_values(array_filter($DB->links,fn($l)=>$l['documents_id']===$id));
    check(count($links)===1 && $links[0]['itemtype']==='ITILFollowup','Every browser/desktop upload uses only followup link, no public Ticket shortcut');
    check(glob(GLPI_UPLOAD_DIR.'/*')===[],'Native upload staging is cleaned');
    echo 'PASS desktop attachment contract: '.$checks.' assertions; real Symfony multipart/binary response and production service, explicit native-writer/auth fixtures.'."\n";
} finally {
    foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST) as $entry) { $entry->isDir()?rmdir($entry->getPathname()):unlink($entry->getPathname()); }
    rmdir($root);
}
