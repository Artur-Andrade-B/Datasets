<?php
declare(strict_types=1);
// Executes production LDAP-reader logic with an explicit LDAP transport fixture.
// Run PHP -n + ctype extension, intentionally without native LDAP extension.
if (extension_loaded('ldap')) { throw new RuntimeException('Fixture must run without LDAP extension.'); }
if (PHP_SAPI !== 'cli' || $argc !== 3) { fwrite(STDERR, "Usage: php -n -d extension=ctype.so desktop_automatic_ldap_boundary.php PLUGIN_ROOT CORE_AUTHLDAP_SOURCE\n"); exit(2); }
require $argv[1] . '/src/desktop/automatic.php';
$core = file_get_contents($argv[2]);
if (hash('sha256', $core) !== 'e72b22086fe6b60ac799afef90de38fac98e241d04ca6e5da369e3f21a6b518a') { throw new RuntimeException('Expected unchanged official GLPI11.0.7 AuthLDAP.php.'); }
$methods = '';
foreach (['getFieldValue', 'guidToString', 'isValidGuid'] as $method) {
    $start = strpos($core, '    public static function ' . $method . '(');
    if ($start === false) { throw new RuntimeException('Missing core method.'); }
    $end = strpos($core, "\n    }", $start);
    if ($end === false) { throw new RuntimeException('Missing core method end.'); }
    $methods .= substr($core, $start, $end + 6 - $start) . "\n";
}
// Only connection/search IO is replaced; these three conversion methods are
// executed unchanged from the hash-pinned official core source.
eval('class CoreLdapFieldMethods {' . $methods . '}');
$checks=0;$searchArgs=[];$connectArgs=[];$unbinds=0;$errno=0;$canConnect=true;$badEntries=false;
class AuthLDAP extends CoreLdapFieldMethods {
 public static function tryToConnectToServer($source,$login,$password) { $GLOBALS['connectArgs']=func_get_args();return $GLOBALS['canConnect'] ? new stdClass() : false; }
 public static function get_entries_clean($connection,$result,?bool &$error=null) { $error=$GLOBALS['badEntries'];return $GLOBALS['entries']; }
}
if (!function_exists('ldap_search')) {
function ldap_search(...$args) { $GLOBALS['searchArgs']=$args;return new stdClass(); }
function ldap_errno($connection) { return $GLOBALS['errno']; }
function ldap_unbind($connection) { $GLOBALS['unbinds']++;return true; }
}
function check(bool $value,string $name):void { if(!$value)throw new RuntimeException($name);$GLOBALS['checks']++; }
function rejects(callable $call,string $name):void { try {$call();}catch(GlpichatDesktopException $e){check($e->errorCode==='directory_unavailable'&&!str_contains($e->getMessage(),'private'),'safe '.$name);return;} throw new RuntimeException('not rejected '.$name); }
$sid='S-1-5-21-123555548-4169228633-3417879051-282348';
$binary=hex2bin(str_replace('\\','',glpichat_desktop_automatic_sid_filter($sid)));
$guid=hex2bin('785634123412341212341234567890ab');
$source=['id'=>3,'login_field'=>'sAMAccountName','sync_field'=>'objectGUID','basedn'=>'DC=saude,DC=example','condition'=>'(!(userAccountControl:1.2.840.113556.1.4.803:=2))','rootdn_passwd'=>'private encrypted binding'];
$entry=['samaccountname'=>['count'=>1,0=>'01479491144'],'objectguid'=>['count'=>1,0=>$guid],'objectsid'=>['count'=>1,0=>$binary],'useraccountcontrol'=>['count'=>1,0=>'512']];
$entries=['count'=>1,0=>$entry];
$rows=glpichat_desktop_automatic_ldap($source,$sid);
check($rows===[['login'=>'01479491144','object_guid'=>$guid,'sync_value'=>$guid]],'binary GUID and leading zeros preserved');
check($connectArgs===[$source,'',''],'existing GLPI connection config reused without client credentials');
check($searchArgs[1]===$source['basedn']&&$searchArgs[5]===2&&$searchArgs[6]===10,'bounded search uses configured base');
check(str_contains($searchArgs[2],$source['condition'])&&str_contains($searchArgs[2],'(objectSid='.glpichat_desktop_automatic_sid_filter($sid).')'),'configured condition and exact binary SID retained');
check($unbinds===1,'connection closed after success');
$guidSource=array_replace($source,['login_field'=>'objectguid']);
$guidRows=glpichat_desktop_automatic_ldap($guidSource,$sid);
check($guidRows[0]['login']==='12345678-1234-1234-1234-1234567890ab'&&$guidRows[0]['object_guid']===$guid,'native GLPI GUID login conversion preserves separate binary anchor');
$entries=['count'=>0];check(glpichat_desktop_automatic_ldap($source,$sid)===[],'no matching identity returns none');
$entries=['count'=>1,0=>$entry];$entries[0]['useraccountcontrol'][0]='514';check(glpichat_desktop_automatic_ldap($source,$sid)===[],'disabled account skipped');
foreach(['missing','invalid','multiple'] as $type){$entries=['count'=>1,0=>$entry];if($type==='missing')unset($entries[0]['useraccountcontrol']);elseif($type==='invalid')$entries[0]['useraccountcontrol'][0]='private';else $entries[0]['useraccountcontrol']['count']=2;rejects(fn()=>glpichat_desktop_automatic_ldap($source,$sid),'UAC '.$type);}
$entries=['count'=>1,0=>$entry];$entries[0]['objectsid'][0]='wrong';rejects(fn()=>glpichat_desktop_automatic_ldap($source,$sid),'SID mismatch');
$entries=['count'=>1,0=>$entry];unset($entries[0]['objectguid']);rejects(fn()=>glpichat_desktop_automatic_ldap($source,$sid),'missing GUID');
$entries=['count'=>1,0=>$entry];$errno=4;rejects(fn()=>glpichat_desktop_automatic_ldap($source,$sid),'incomplete result');$errno=0;
$badEntries=true;rejects(fn()=>glpichat_desktop_automatic_ldap($source,$sid),'entry decoding');$badEntries=false;
$canConnect=false;rejects(fn()=>glpichat_desktop_automatic_ldap($source,$sid),'failed bind');
echo "PASS LDAP reader boundary: $checks assertions; explicit LDAP transport and connection fixtures; unchanged GLPI GUID conversion methods; no live directory.\n";
