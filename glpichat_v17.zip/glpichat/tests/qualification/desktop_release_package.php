<?php
declare(strict_types=1);
/** Import the actual delivered paired release with production ZIP/signing/storage code.
 * SQL and Config are explicit fixtures; all created private material is temporary.
 */
if (PHP_SAPI !== 'cli' || $argc !== 3) { fwrite(STDERR, "Usage: desktop_release_package.php PLUGIN_ROOT RELEASE_ZIP\n"); exit(2); }
[$unused,$plugin,$package]=$argv;
final class Config {
 public static function getConfigurationValues(string $context): array { return ['desktop_schema_version'=>'5','desktop_enabled'=>'0']; }
}
require $plugin . '/tests/fixtures/desktop_management_db.php';
require $plugin . '/src/desktop/management.php';
$temporary=sys_get_temp_dir().'/glpichat-release-qualification-'.bin2hex(random_bytes(8));mkdir($temporary,0700);
define('GLPI_PLUGIN_DOC_DIR',$temporary.'/private');
$DB=new DesktopManagementDB();$checks=0;
function release_check(bool $value,string $message):void { if(!$value)throw new RuntimeException($message);$GLOBALS['checks']++; }
function release_remove(string $path):void {
 if(is_dir($path)&&!is_link($path)){foreach(scandir($path) as $name){if($name!=='.'&&$name!=='..')release_remove($path.'/'.$name);}rmdir($path);}
 elseif(file_exists($path)||is_link($path))unlink($path);
}
try {
 $bytes=glpichat_management_release_bytes($package);
 release_check($bytes['version']==='0.5.0','Expected current release version');
 $import=glpichat_management_import($package,1);$row=$DB->tables[GLPICHAT_MANAGEMENT_RELEASES][0];
 $manifest=json_decode($row['manifest_json'],true,512,JSON_THROW_ON_ERROR);$signature=base64_decode($row['signature'],true);
 release_check($manifest['bootstrap_abi']===2&&$manifest['state_schema_min']===1&&$manifest['state_schema_max']===1,'ABI2 and retained state schema');
 release_check($manifest['sequence']>0&&$manifest['sequence']===$import['sequence'],'Imported sequence preserved');
 $keypath=glpichat_management_storage().'/instance-signing.pem';$key=openssl_pkey_get_private(file_get_contents($keypath));$details=openssl_pkey_get_details($key);$public=$details['key'];
 release_check(openssl_verify($row['manifest_json'],$signature,$public,OPENSSL_ALGO_SHA256)===1,'Production signature verifies');
 release_check(openssl_verify($row['manifest_json'].' ',$signature,$public,OPENSSL_ALGO_SHA256)!==1,'Tampering rejected');
 release_check($details['bits']>=2048&&(fileperms($keypath)&0777)===0600,'Private signing key strength and permissions');
 $files=[];
 foreach($manifest['components'] as $component){
  $path=glpichat_management_storage().'/'.$row['storage_key'].'/'.$component['filename'];$stored=file_get_contents($path);
  release_check(hash_equals($bytes['entries'][$component['filename']],$stored),'Stored bytes equal packaged binary');
  release_check(hash_equals($component['sha256'],hash('sha256',$stored))&&strlen($stored)===$component['size'],'Stored file hash and size');
  release_check((fileperms($path)&0777)===0600,'Artifact private permissions');
  $files[]=$component+['stored_equals_packaged'=>true,'private_mode'=>'0600'];
 }
 release_check(count($files)===2&&!$DB->snapshots,'Exactly two files and closed transaction');
 echo json_encode(['result'=>'PASS','assertions'=>$checks,'executed_utc'=>gmdate('c'),'php_version'=>PHP_VERSION,
  'openssl_version'=>OPENSSL_VERSION_TEXT,'zip_extension'=>phpversion('zip'),'package'=>$package,'package_sha256'=>hash_file('sha256',$package),
  'package_size'=>filesize($package),'package_entries'=>array_keys($bytes['entries']),'import'=>$import,'manifest'=>$manifest,
  'signature_valid'=>true,'tampered_manifest_rejected'=>true,'rsa_bits'=>$details['bits'],'key_mode'=>'0600','components'=>$files,
  'boundary'=>'Actual packaged ZIP, production import service, native ZipArchive/OpenSSL/filesystem; explicit SQL/Config fixtures. Temporary private key deleted. No Windows or connected database execution.'],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)."\n";
} finally { release_remove($temporary); }
