#!/usr/bin/env python3
"""Execute production activity/list/history reads on core-derived SQLite tables.

Usage: desktop_activity_sqlite.py PHP PLUGIN_ROOT GLPI_11_0_7_DDL [--output JSON]

PHP executes the real functions; a pipe adapter executes their SELECTs in SQLite
and returns actual rows. Native core and plugin column names are preserved. The
only query syntax adaptation removes MySQL's unary BINARY keyword: these fixture
columns use SQLite's default binary comparisons. OCTET_LENGTH is registered as a
UTF-8 byte-count function. This is not a MySQL planner/collation/locking test;
desktop_ticket_sql_integration.php is the optional native-engine qualification.
"""
import argparse
import hashlib
import json
import re
import sqlite3
import subprocess
import tempfile
from pathlib import Path

PINNED_DDL_SHA256 = '5be41e407778eaa321a53a9fddb67b95de611037335836e2bf4cc2bfd554644f'
HARNESS = r'''<?php
declare(strict_types=1);
require $argv[1] . '/src/desktop/conversations.php';
require $argv[1] . '/src/desktop/schema.php';
require $argv[1] . '/src/db/setup_helpers.php';
function glpichat_desktop_fail(string $code, string $message, int $status): never { throw new RuntimeException($code); }
function glpichat_desktop_db_rows(string $sql): array {
    echo json_encode(['sql' => $sql], JSON_THROW_ON_ERROR) . "\n"; flush();
    $line = fgets(STDIN);
    if ($line === false) { throw new RuntimeException('SQL bridge closed.'); }
    return json_decode($line, true, 512, JSON_THROW_ON_ERROR);
}
try {
    $input = json_decode(fgets(STDIN), true, 512, JSON_THROW_ON_ERROR);
    $actor = ['user_id' => $input['user'] ?? 10, 'entity_id' => 2, 'can_read' => true, 'can_create' => true];
    $result = match ($input['mode']) {
        'schema' => ['owned' => glpichat_schema_queries(), 'desktop' => glpichat_desktop_schema_definitions()],
        'list' => glpichat_desktop_conversations($actor, $input['before'] ?? 0, 30),
        'history' => glpichat_desktop_history($actor, $input['ticket'], $input['before'] ?? 0, 50),
    };
    echo json_encode(['result' => $result], JSON_THROW_ON_ERROR) . "\n";
} catch (Throwable $error) { echo json_encode(['error' => $error->getMessage()], JSON_THROW_ON_ERROR) . "\n"; exit(1); }
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('php')
    parser.add_argument('plugin_root', type=Path)
    parser.add_argument('core_ddl', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    ddl_bytes = args.core_ddl.read_bytes()
    if hashlib.sha256(ddl_bytes).hexdigest() != PINNED_DDL_SHA256:
        raise RuntimeError('Exact official GLPI11.0.7 glpi-empty.sql required.')
    db = sqlite3.connect(':memory:')
    db.row_factory = sqlite3.Row
    db.create_function('OCTET_LENGTH', 1, lambda value: len(value.encode('utf-8')) if value is not None else None)
    evidence, checks, definitions = [], [], {}

    def check(condition, description):
        checks.append({'description': description, 'pass': bool(condition)})
        if not condition:
            raise AssertionError(description)

    with tempfile.TemporaryDirectory(prefix='glpichat-activity-sql-') as temporary:
        harness = Path(temporary) / 'bridge.php'
        harness.write_text(HARNESS)

        def request(case):
            process = subprocess.Popen([args.php, str(harness), str(args.plugin_root.resolve())],
                                       stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            captured = []
            try:
                process.stdin.write(json.dumps(case) + '\n')
                process.stdin.flush()
                while True:
                    line = process.stdout.readline()
                    if not line:
                        raise RuntimeError('PHP bridge stopped: ' + process.stderr.read())
                    event = json.loads(line)
                    if 'error' in event:
                        raise RuntimeError(event['error'])
                    if 'result' in event:
                        process.stdin.close()
                        process.wait(timeout=10)
                        if process.returncode:
                            raise RuntimeError(process.stderr.read())
                        evidence.append({'case': case, 'queries': captured})
                        return event['result'], captured
                    original = event['sql']
                    # Only a MySQL unary comparison modifier is adapted. No table,
                    # column, filter, join, bound, order or receipt rule is changed.
                    sql = re.sub(r'\bBINARY (?=(?:gr|gm)\.|\')', '', original)
                    rows = [dict(row) for row in db.execute(sql)]
                    captured.append({'production_sql': original, 'sqlite_sql': sql, 'rows': len(rows)})
                    process.stdin.write(json.dumps(rows) + '\n')
                    process.stdin.flush()
            finally:
                if process.poll() is None:
                    process.kill()
                    process.wait()
                process.stdout.close()
                process.stderr.close()
                if not process.stdin.closed:
                    process.stdin.close()

        def create_table(table, columns):
            definitions[table] = [name for name, declaration in columns]
            sql_columns = []
            for name, declaration in columns:
                kind = 'INTEGER' if re.match(r'(?:tinyint|smallint|mediumint|int|bigint)\b', declaration, re.I) else 'TEXT'
                sql_columns.append('"' + name + '" ' + kind)
            db.execute('CREATE TABLE "' + table + '" (' + ','.join(sql_columns) + ')')

        ddl = ddl_bytes.decode()
        for table in ('glpi_tickets', 'glpi_tickets_users', 'glpi_itilfollowups', 'glpi_users'):
            match = re.search(r'CREATE TABLE `' + table + r'` \(\n(.*?)\n\) ENGINE=.*?;', ddl, re.S)
            if not match:
                raise RuntimeError('Native table definition missing: ' + table)
            create_table(table, re.findall(r'^  `([^`]+)`\s+([^\n]+)', match.group(1), re.M))
        schema, unused = request({'mode': 'schema'})
        for table in ('glpi_plugin_glpichat_rooms', 'glpi_plugin_glpichat_messages'):
            create_table(table, re.findall(r'^\s+`([^`]+)`\s+([^\n]+)', schema['owned'][table], re.M))
        for table in ('glpi_plugin_glpichat_desktopreads', 'glpi_plugin_glpichat_desktopsends'):
            create_table(table, [(name, column['type']) for name, column in schema['desktop'][table]['columns'].items()])
        db.executemany('INSERT INTO glpi_tickets (id,name,status,entities_id,is_deleted) VALUES (?,?,?,?,?)',
                       [(7, 'Own ticket', 2, 2, 0), (8, 'Other requester', 2, 2, 0), (9, 'Foreign entity', 2, 3, 0)])
        db.executemany('INSERT INTO glpi_tickets_users (id,tickets_id,users_id,type) VALUES (?,?,?,?)',
                       [(1, 7, 10, 1), (2, 8, 11, 1), (3, 9, 10, 1)])
        db.executemany('INSERT INTO glpi_users (id,name,firstname,realname) VALUES (?,?,?,?)',
                       [(10, 'same-user', 'Same', 'User'), (11, 'other-user', 'Other', 'User')])

        def followup(message, ticket, author=10, private=0, itemtype='Ticket'):
            db.execute('INSERT INTO glpi_itilfollowups (id,itemtype,items_id,date,users_id,content,is_private) VALUES (?,?,?,?,?,?,?)',
                       (message, itemtype, ticket, '2026-10-02 12:00:00', author, 'Activity ' + str(message), private))

        for message in range(1, 26):
            followup(message, 7, 11 if message in (21, 24) else 10)
        followup(26, 7, private=1)
        for message in range(27, 32):
            followup(message, 7)
        followup(32, 7, itemtype='Problem')
        followup(100, 8)
        followup(101, 9)
        db.executemany('INSERT INTO glpi_plugin_glpichat_rooms (id,tickets_id,room_type) VALUES (?,?,?)',
                       [(1, 7, 'public'), (2, 7, 'internal'), (3, 8, 'public')])
        db.executemany('INSERT INTO glpi_plugin_glpichat_messages (id,rooms_id,tickets_id,participant_type,users_id,message_type,content,documents_id,itilfollowups_id) VALUES (?,?,?,?,?,?,?,?,?)',
                       [(1, 1, 7, 'user', 10, 'message', 'Attachment', 1, 27),
                        (2, 2, 7, 'user', 10, 'message', 'Internal', 0, 28),
                        (3, 1, 7, 'guest', 10, 'message', 'Guest', 0, 29),
                        (4, 3, 8, 'user', 10, 'message', 'Wrong ticket', 0, 30),
                        (5, 999, 7, 'user', 10, 'message', 'Orphan room', 0, 31)])
        own_uuid = '01234567-89ab-4cde-8fab-0123456789ab'
        db.executemany('INSERT INTO glpi_plugin_glpichat_desktopsends (id,users_id,client_message_id,tickets_id,itilfollowups_id) VALUES (?,?,?,?,?)',
                       [(1, 10, own_uuid, 7, 25), (2, 11, 'other-actor', 7, 24),
                        (3, 10, 'wrong-ticket', 8, 23), (4, 10, 'wrong-author', 7, 21)])
        data, queries = request({'mode': 'list'})
        check(len(queries) == 3 and len(data['conversations']) == 1, 'One list/aggregate/batched-activity query preserves requester and entity scope')
        ticket = data['conversations'][0]
        activity = {row['id']: row for row in ticket['recent_activity']}
        check(list(activity) == list(range(25, 5, -1)), 'Newest20 IDs are descending and exclude private/internal/guest/attachment/mismatched/orphan sources')
        check(ticket['latest_message_id'] == 25 and ticket['activity_before'] == 6, 'Activity head and continuation cursor retain the eligible source bounds')
        check(ticket['unread_count'] == 2, 'Same-author activity does not change incoming unread semantics')
        check(activity[25]['client_message_id'] == own_uuid and activity[22]['client_message_id'] is None, 'Own receipt UUID is exposed while same-user web/native activity remains distinguishable')
        check(all(activity[message]['client_message_id'] is None for message in (24, 23, 21)), 'Receipt projection rejects other actors, wrong tickets and mismatched authors')
        history, unused = request({'mode': 'history', 'ticket': 7})
        messages = {row['id']: row for row in history['messages']}
        check(list(messages) == list(range(1, 26)) and messages[25]['client_message_id'] == own_uuid, 'History preserves visibility and includes exact same-actor receipt UUID')
        check(all(messages[message]['client_message_id'] is None for message in (24, 23, 21)), 'History continuation applies the same receipt isolation')
        history, unused = request({'mode': 'history', 'ticket': 7, 'before': ticket['activity_before']})
        check([row['id'] for row in history['messages']] == list(range(1, 6)) and not history['has_more'], 'History continues below the activity cursor without gaps or duplicates')
        for ticket_id in range(1000, 1030):
            db.execute('INSERT INTO glpi_tickets (id,name,status,entities_id,is_deleted) VALUES (?,?,?,?,?)', (ticket_id, 'Bounded', 2, 2, 0))
            db.execute('INSERT INTO glpi_tickets_users (id,tickets_id,users_id,type) VALUES (?,?,?,?)', (ticket_id, ticket_id, 10, 1))
            for offset in range(1, 27):
                followup(ticket_id * 100 + offset, ticket_id, private=int(offset == 26))
        page, queries = request({'mode': 'list'})
        check(len(queries) == 3 and len(page['conversations']) == 30, 'Thirty populated conversations still require only three database calls')
        check(queries[2]['rows'] == 630 and queries[2]['production_sql'].count(' UNION ALL ') == 29, 'Thirty separately bounded UNION branches return at most21 rows each')
        for conversation in page['conversations']:
            base = conversation['ticket_id'] * 100
            check([row['id'] for row in conversation['recent_activity']] == list(range(base + 25, base + 5, -1))
                  and conversation['activity_before'] == base + 6 and conversation['latest_message_id'] == base + 25,
                  'Ticket ' + str(conversation['ticket_id']) + ' retains its own newest20 public IDs and cursor')
        db.execute('DELETE FROM glpi_tickets_users WHERE tickets_id=7 AND users_id=10')
        data, queries = request({'mode': 'list', 'before': 1000})
        check(data['conversations'] == [] and len(queries) == 1, 'Requester removal prevents both metadata and receipt queries')

    result = {'engine': 'Python sqlite3 ' + sqlite3.sqlite_version, 'core_version': 'GLPI11.0.7',
              'core_ddl_sha256': PINNED_DDL_SHA256,
              'source_sha256': hashlib.sha256((args.plugin_root / 'src/desktop/conversations.php').read_bytes()).hexdigest(),
              'schema_columns': definitions, 'cases': evidence, 'checks': checks, 'passed': len(checks),
              'limits': ['Core/plugin column names projected to SQLite INTEGER/TEXT; native types, defaults, constraints and indexes not reproduced.',
                         'MySQL unary BINARY removed only from compiled public predicates; fixture SQLite columns use binary-default comparison.',
                         'OCTET_LENGTH supplied as UTF-8 byte-count function. No native MySQL planner, locking, write, HTTP, GLPI session or AD execution.']}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print('PASS desktop activity core-schema SQL: ' + str(len(checks)) + ' checks; SQLite comparison adapter; native MySQL execution remains separate.')


if __name__ == '__main__':
    main()
