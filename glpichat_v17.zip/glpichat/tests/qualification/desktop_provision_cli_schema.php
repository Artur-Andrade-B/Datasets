<?php

declare(strict_types=1);

/** Executes the unchanged copied CLI entrypoint in subprocesses. GLPI bootstrap,
 * Config and source query are fixtures; managed-schema validation is production.
 * Usage: php desktop_provision_cli_schema.php PLUGIN_ROOT
 */
if (PHP_SAPI !== 'cli' || $argc !== 2) { exit(2); }
$plugin = realpath($argv[1]);
$root = sys_get_temp_dir() . '/glpichat-provision-cli-' . bin2hex(random_bytes(8));
foreach (['src/Glpi/Application', 'vendor', 'plugins/glpichat/bin', 'plugins/glpichat/src/desktop'] as $path) { mkdir($root . '/' . $path, 0700, true); }
copy($plugin . '/bin/desktop-provision.php', $root . '/plugins/glpichat/bin/desktop-provision.php');
foreach (['common.php', 'auth.php', 'enrollment.php', 'provision.php'] as $name) { copy($plugin . '/src/desktop/' . $name, $root . '/plugins/glpichat/src/desktop/' . $name); }
file_put_contents($root . '/src/Glpi/Application/ResourcesChecker.php', '<?php namespace Glpi\Application; final class ResourcesChecker { public function __construct($root) {} public function checkResources(): void {} }');
file_put_contents($root . '/vendor/autoload.php', <<<'PHP'
<?php
namespace Glpi\Kernel { final class Kernel { public function __construct($env) {} public function boot(): void { $GLOBALS['DB'] = new \SourceDb(); } } }
namespace {
final class Config {
    public static function getConfigurationValues(string $scope): array {
        return ['desktop_schema_version' => trim(file_get_contents(dirname(__DIR__) . '/schema.txt')), 'desktop_idempotency_key' => str_repeat('a', 64)];
    }
}
final class SourceRows { public int $index = 0; public function free(): void {} }
final class SourceDb {
    public function doQuery(string $sql): SourceRows {
        if ($sql !== 'SELECT id,name,sync_field FROM glpi_authldaps WHERE is_active=1 ORDER BY id') { throw new \LogicException('Unexpected query.'); }
        return new SourceRows();
    }
    public function fetchAssoc(SourceRows $rows): array|false { return $rows->index++ === 0 ? ['id' => 3, 'name' => 'SAUDE', 'sync_field' => 'objectguid'] : false; }
}
}
PHP);
$checks = 0;
try {
    foreach (['2', '3', '4', '5', '1', '6'] as $schema) {
        file_put_contents($root . '/schema.txt', $schema);
        $command = [PHP_BINARY];
        if (php_ini_loaded_file()) { $command = [...$command, '-c', php_ini_loaded_file()]; }
        $command = [...$command, $root . '/plugins/glpichat/bin/desktop-provision.php', '--list-sources'];
        $process = proc_open($command, [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
        fclose($pipes[0]); $output = stream_get_contents($pipes[1]); fclose($pipes[1]);
        $error = stream_get_contents($pipes[2]); fclose($pipes[2]); $status = proc_close($process);
        if (in_array($schema, ['2', '3', '4', '5'], true)) {
            if ($status !== 0 || $error !== '' || json_decode($output, true) !== [['id' => 3, 'name' => 'SAUDE', 'sync_field' => 'objectguid']]) {
                throw new RuntimeException('Supported CLI schema failed: ' . $schema . ': ' . $output . $error);
            }
        } elseif ($status !== 1 || $output !== '' || !str_contains($error, 'Provisioning failed:')) {
            throw new RuntimeException('Unsupported CLI schema was accepted: ' . $schema);
        }
        ++$checks;
    }
    echo 'PASS desktop_provision_cli_schema: ' . $checks . " subprocess cases; actual CLI/service guard, explicit bootstrap/query fixtures.\n";
} finally {
    foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $entry) {
        $entry->isDir() ? rmdir($entry->getPathname()) : unlink($entry->getPathname());
    }
    rmdir($root);
}
