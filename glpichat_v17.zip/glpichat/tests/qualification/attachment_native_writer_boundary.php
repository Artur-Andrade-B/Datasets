<?php

declare(strict_types=1);

/**
 * Execute unchanged, hash-pinned GLPI 11.0.7 Document preparation/file movement
 * and Document_Item preparation/post-add methods with the production adapter.
 * The generic DBTM persistence, database, session and notification services are
 * explicit fixtures. Actual filesystem bytes and Symfony UploadedFile are used.
 * This does not boot GLPI or claim a complete native CommonDBTM::add integration.
 * Usage: php attachment_native_writer_boundary.php PLUGIN CORE_SRC AUTOLOAD
 */
if (PHP_SAPI !== 'cli' || $argc !== 4) { exit(2); }
[$unused, $plugin, $coreRoot, $autoload] = $argv;
require $autoload;
$pins = [
    'Document.php' => '3aa4fa107e9beac663342ace1218c350c3a02b372e9dd55579e7b8ef75214f4d',
    'Document_Item.php' => '988ebf83747fa58b40ae7674cbff1d005a3e4fe0f508c380c0b27e730dddfbf7',
    'CommonDBRelation.php' => '05653b1906dfced07cd0707939a4e0c165fba0b7ef08012a4f7f251d2f54f1b9',
    'CommonITILObject.php' => '54dd6cb83cc8f2d64fc3e54328de6a8e07924167f5bce505e2c7d62da6390755',
];
$sources = [];
foreach ($pins as $name => $sha) {
    $source = file_get_contents($coreRoot . '/' . $name);
    if (hash('sha256', $source) !== $sha) { throw new RuntimeException('Core source mismatch: ' . $name); }
    $sources[$name] = $source;
}
function core_methods(string $source, array $names): string {
    $code = '';
    foreach ($names as $name) {
        if (!preg_match('/^    (?:public|private|protected) (?:static )?function ' . preg_quote($name, '/') . '\(/m', $source, $match, PREG_OFFSET_CAPTURE)) {
            throw new RuntimeException('Core method missing: ' . $name);
        }
        $start = $match[0][1];
        $end = strpos($source, "\n    }", $start);
        if ($end === false) { throw new RuntimeException('Core method end missing.'); }
        $code .= substr($source, $start, $end + 6 - $start) . "\n";
    }
    return $code;
}
function __s(string $text): string { return $text; }
function __(string $text): string { return $text; }
function htmlescape(string $text): string { return htmlspecialchars($text); }
function countElementsInTable(string $table, array $criteria): int {
    return count(array_filter($GLOBALS['relations'], static function (array $row) use ($criteria): bool {
        foreach ($criteria as $key => $value) { if (($row[$key] ?? null) !== $value) { return false; } }
        return true;
    }));
}
define('READ', 1); define('UPDATE', 2); define('ERROR', 1);
class Session {
    public static function getLoginUserID(): int|false { return $_SESSION['glpiID'] ?? $_SESSION['glpiinventoryuserrunning'] ?? $_SESSION['glpicronuserrunning'] ?? false; }
    public static function haveRight(...$args): bool { return (bool) ($_SESSION['private_right'] ?? false); }
    public static function addMessageAfterRedirect(...$args): void { $GLOBALS['coreMessages'][] = $args; }
}
class Toolbox {
    public static function getMime(string $path): string { return 'text/plain'; }
    public static function strtoupper(string $s): string { return strtoupper($s); }
}
class Rule { public static function getUuid(): string { return 'fixture-native-tag'; } }
class NotificationEvent { public static function raiseEvent(...$args): bool { ++$GLOBALS['nativeNotifications']; return true; } }
class Event { public static function log(...$args): void {} }
class Log { public static function history(...$args): void { $GLOBALS['history'][] = $args; } }
class NativeItilSupport {
    public array $fields = ['id' => 7, 'entities_id' => 3];
    public const TIMELINE_LEFT = 1;
    public static function getTaskClass(): ?string { return null; }
    public function getType(): string { return 'Ticket'; }
    public function getID(): int { return $this->fields['id']; }
    public function getFromDB(int $id): bool { $this->fields['id'] = $id; return true; }
    public function can(int $id, int $right): bool { return $GLOBALS['ticketAllowed']; }
}
eval('class CommonITILObject extends NativeItilSupport {' . core_methods($sources['CommonITILObject.php'], ['getAssociatedDocumentsCriteria']) . '}');
class ITILFollowup {
    public static $rightname = 'followup';
    public const SEEPRIVATE = 2;
    public static function canView(): bool { return true; }
    public static function getTable(): string { return 'glpi_itilfollowups'; }
    public static function getType(): string { return 'ITILFollowup'; }
    public static function getTableField(string $field): string { return self::getTable() . '.' . $field; }
}
class ITILSolution { public static function canView(): bool { return false; } }
class Change { public const READALL = 1, READMY = 2; }
class Problem { public const READALL = 1, READMY = 2; }
class Ticket extends CommonITILObject {
    public const READALL = 1, READMY = 2, READASSIGN = 4, READGROUP = 8, OWN = 16;
    public static array $merges = [77 => [88]];
    public static function getMergedTickets(int $id): array { $GLOBALS['mergeQueries'][] = $id; return self::$merges[$id] ?? []; }
    public static function getTimelinePosition(...$args): int { return 1; }
    public function update(array $input): bool { $GLOBALS['ticketUpdates'][] = $input; return true; }
}
class NativeWriterDb {
    public function request(array $query): ArrayIterator {
        if (($query['FROM'] ?? '') === 'glpi_itilfollowups') {
            return new ArrayIterator(array_values(array_filter($GLOBALS['followupRows'], fn(array $row): bool => $this->matches($row, $query['WHERE']))));
        }
        if (($query['FROM'] ?? '') === 'glpi_documents_items') {
            return new ArrayIterator([['cpt' => count(array_filter($GLOBALS['relations'], fn(array $row): bool => $this->matches($row, $query['WHERE'])))]]);
        }
        if (($query['FROM'] ?? '') !== 'glpi_documenttypes') { throw new LogicException('Unexpected core database read.'); }
        return new ArrayIterator(($query['WHERE']['ext'][1] ?? '') === 'txt' ? [['id' => 1, 'ext' => 'txt']] : []);
    }
    private function matches(array $row, array $criteria, bool $or = false): bool {
        $checks = [];
        foreach ($criteria as $key => $value) {
            if ($key === 'OR') { $checks[] = $this->matches($row, $value, true); }
            elseif (is_int($key)) { $checks[] = $this->matches($row, $value); }
            else {
                $field = substr($key, strrpos('.' . $key, '.'));
                $checks[] = is_array($value) ? in_array($row[$field] ?? null, $value, true) : ($row[$field] ?? null) === $value;
            }
        }
        return $or ? in_array(true, $checks, true) : !in_array(false, $checks, true);
    }
}
class CommonDBTM {
    public array $input = [], $fields = [];
    public bool $dohistory = true;
    public function filterFields(array $input): array { return $input; }
    public function prepareInputForAdd($input) { return $input; }
    public static function getTable($classname = null) { return static::class === 'Document' ? 'glpi_documents' : 'glpi_documents_items'; }
    public static function getType() { return static::class; }
    public static function getTableField(string $field): string { return static::getTable() . '.' . $field; }
    public function getID(): int { return (int) ($this->fields['id'] ?? 1); }
    public function add(array $input): int|false {
        $this->input = $this->prepareInputForAdd($input);
        if ($this->input === false) { return false; }
        $this->fields = $this->input;
        $this->fields['id'] = ++$GLOBALS['nextId'];
        if ($this instanceof Document) { $GLOBALS['documents'][$this->fields['id']] = $this->fields; }
        else { $GLOBALS['relations'][] = $this->fields; }
        $this->post_addItem();
        return $this->fields['id'];
    }
}
eval('class CommonDBRelation extends CommonDBTM {
    public static $itemtype_1="Document", $items_id_1="documents_id", $itemtype_2="itemtype", $items_id_2="items_id";
    public static $logs_for_item_1=true, $logs_for_item_2=true, $log_history_1_add=1, $log_history_2_add=1;
    public $_force_log_option=0;
    public function getConnexityItem($type,$field) { return new CommonDBTM(); }
    public function getHistoryNameForItem1($item,$action) { return "document relation"; }
    public function getHistoryNameForItem2($item,$action) { return "followup relation"; }
' . core_methods($sources['CommonDBRelation.php'], ['post_addItem']) . '}');
eval('class Document extends CommonDBTM {' . core_methods($sources['Document.php'], [
    'prepareInputForAdd', 'post_addItem', 'moveUploadedDocument', 'isValidDoc', 'getUploadFileValidLocationName', 'renameForce', 'canViewFileFromItilObject',
]) . '}');
eval('class Document_Item extends CommonDBRelation {' . core_methods($sources['Document_Item.php'], [
    'prepareInputForAdd', 'alreadyExists', 'post_addItem', 'addToMergedTickets',
]) . '}');
require $plugin . '/src/desktop/attachments.php';
require $plugin . '/src/FollowupDocumentItem.php';
$DB = new NativeWriterDb();
$CFG_GLPI = ['documentcategories_id_forticket' => 1];
$root = sys_get_temp_dir() . '/glpichat-native-file-' . bin2hex(random_bytes(8));
mkdir($root, 0700); mkdir($root . '/upload', 0700); mkdir($root . '/docs', 0700);
define('GLPI_UPLOAD_DIR', $root . '/upload'); define('GLPI_DOC_DIR', $root . '/docs');
$checks = 0;
function native_check(bool $ok, string $message): void { if (!$ok) { throw new RuntimeException($message); } ++$GLOBALS['checks']; }
$fresh = static function (): void {
    $GLOBALS['documents'] = $GLOBALS['relations'] = $GLOBALS['history'] = $GLOBALS['mergeQueries'] = $GLOBALS['ticketUpdates'] = $GLOBALS['coreMessages'] = [];
    $GLOBALS['nextId'] = $GLOBALS['nativeNotifications'] = 0;
};
$upload = static function () use ($root): Symfony\Component\HttpFoundation\File\UploadedFile {
    $path = tempnam($root, 'incoming-'); file_put_contents($path, 'unchanged native file bytes');
    return new Symfony\Component\HttpFoundation\File\UploadedFile($path, 'relatório.txt', 'text/plain', null, true);
};
try {
    $fresh();
    // Demonstrate the exact upstream numeric-ID collision before asserting the fix.
    (new Document_Item())->add(['documents_id' => 10, 'itemtype' => 'ITILFollowup', 'items_id' => 77, 'users_id' => 10]);
    native_check(array_column($relations, 'items_id') === [77, 88], 'Unchanged core demonstrates erroneous merge propagation for a followup ID');
    $fresh();
    (new GlpiPlugin\Glpichat\FollowupDocumentItem())->add(['documents_id' => 10, 'itemtype' => 'ITILFollowup', 'items_id' => 77, 'users_id' => 10]);
    native_check(array_column($relations, 'items_id') === [77] && $mergeQueries === [], 'Scoped native relation writer never treats followup IDs as merged ticket IDs');
    native_check(count($history) === 2, 'Native relation history remains enabled for both objects');
    native_check(GlpiPlugin\Glpichat\FollowupDocumentItem::getTable() === 'glpi_documents_items' && GlpiPlugin\Glpichat\FollowupDocumentItem::getType() === 'Document_Item', 'Scoped writer retains native table/type identity');
    foreach ([true, false] as $browserSession) {
        $fresh();
        $_SESSION = ['glpi_currenttime' => '2026-10-02 18:00:00', 'custom' => 'preserved'];
        if ($browserSession) { $_SESSION += ['glpiID' => 999, 'glpiinventoryuserrunning' => 998, 'glpicronuserrunning' => 997]; }
        $before = $_SESSION; $GLOBALS['GLPICHAT_SUPPRESS_DOCUMENT_HOOK'] = 'nested-flag';
        $file = $upload();
        $input = ['name' => 'relatório.txt', 'size' => $file->getSize(), 'sha256' => hash_file('sha256', $file->getPathname())];
        $id = glpichat_desktop_store_attachment(['user_id' => 10, 'entity_id' => 3], 7, 77, $file, $input);
        $document = $documents[$id];
        native_check($document['users_id'] === 10 && $document['entities_id'] === 3, 'Real native preparation retains explicit actor/entity under hostile ambient session');
        native_check($document['filename'] === 'relatório.txt' && $document['name'] === 'relatório.txt', 'Native prefix removal preserves original UTF-8 filename');
        native_check(file_get_contents(GLPI_DOC_DIR . '/' . $document['filepath']) === 'unchanged native file bytes' && $document['sha1sum'] === sha1('unchanged native file bytes'), 'Real native move persists exact bytes into content-addressed GLPI storage');
        native_check(array_column($relations, 'itemtype') === ['ITILFollowup'], 'Every chat document is linked only to its native followup');
        native_check(array_column($relations, 'items_id') === [77], 'Unrelated merged followup never gains this file');
        native_check($nativeNotifications === 0, 'Native document creation renders no inline notification');
        native_check($ticketUpdates === [], 'Association creates neither extra ticket writes nor forced notifications');
        native_check($_SESSION === $before && $GLOBALS['GLPICHAT_SUPPRESS_DOCUMENT_HOOK'] === 'nested-flag', 'Ambient session and nested suppression restored');
        native_check(glob(GLPI_UPLOAD_DIR . '/*') === [], 'Native move and adapter leave staging directory empty');
    }
    $documentObject = new Document(); $documentObject->fields = $document;
    $canDownload = new ReflectionMethod(Document::class, 'canViewFileFromItilObject');
    $_SESSION = ['glpiID' => 42]; $ticketAllowed = true;
    $followupRows = [['id' => 77, 'items_id' => 7, 'itemtype' => 'Ticket', 'users_id' => 10, 'is_private' => 0]];
    native_check($canDownload->invoke($documentObject, 'Ticket', 7) === true, 'Actual native document authorization discovers a public followup-only attachment from its Ticket context');
    $followupRows[0]['is_private'] = 1;
    native_check($canDownload->invoke($documentObject, 'Ticket', 7) === false, 'Making the native followup private removes requester download access without changing the document link');
    $_SESSION['private_right'] = true;
    native_check($canDownload->invoke($documentObject, 'Ticket', 7) === true, 'Native private-followup right retains permitted download access');
    $_SESSION['private_right'] = false; $_SESSION['glpiID'] = 10;
    native_check($canDownload->invoke($documentObject, 'Ticket', 7) === true, 'Native followup author retains the access granted by GLPI');
    $ticketAllowed = false;
    native_check($canDownload->invoke($documentObject, 'Ticket', 7) === false, 'Native Ticket permission remains required even for followup author');
    $ticketAllowed = true; $_SESSION = [];
    native_check($canDownload->invoke($documentObject, 'Ticket', 7) === false, 'No browser session cannot use native browser document authorization');
    echo 'PASS attachment_native_writer_boundary: ' . $checks . " assertions; pinned native preparation/movement/relation methods, explicit DBTM/DB dependencies.\n";
} finally {
    foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $entry) {
        $entry->isDir() ? rmdir($entry->getPathname()) : unlink($entry->getPathname());
    }
    rmdir($root);
}
