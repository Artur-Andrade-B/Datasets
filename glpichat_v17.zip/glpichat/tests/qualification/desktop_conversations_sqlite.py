#!/usr/bin/env python3
"""Execute unchanged production ticket SELECTs against core-derived SQLite columns.

Usage: python3 desktop_conversations_sqlite.py PHP PLUGIN_ROOT GLPI_11_0_7_DDL
         [--baseline OLD_PLUGIN_ROOT] [--output RESULTS_JSON]

PHP calls the real functions to capture their exact SQL. The capture adapter is
not a database assertion: placeholder return rows only allow the shared lookup
to emit its second SELECT. All query/filter assertions use SQLite execution.
Only the ticket list and unlocked shared ticket/requester SELECTs are executed;
MySQL locking, collations, followup aggregation, transactions, native writers,
HTTP, authentication and AD are outside this bounded regression.
"""
import argparse
import hashlib
import json
import re
import sqlite3
import subprocess
import tempfile
from pathlib import Path

PINNED_DDL_SHA256 = '5be41e407778eaa321a53a9fddb67b95de611037335836e2bf4cc2bfd554644f'
CAPTURE = r'''<?php
declare(strict_types=1);
$input = json_decode(stream_get_contents(STDIN), true, 512, JSON_THROW_ON_ERROR);
require $argv[1] . '/src/desktop/conversations.php';
function glpichat_desktop_fail(string $code, string $message, int $status): never {
    throw new RuntimeException($code);
}
function glpichat_desktop_db_rows(string $sql): array {
    $GLOBALS['queries'][] = $sql;
    // These are capture-control placeholders, never the SQL acceptance result.
    if ($GLOBALS['mode'] === 'ticket') {
        return str_starts_with($sql, 'SELECT id, name, status, entities_id')
            ? [['id' => $GLOBALS['ticket'], 'name' => 'capture', 'status' => 1, 'entities_id' => 2]]
            : [['id' => 1]];
    }
    return [];
}
$output = [];
foreach ($input as $case) {
    $GLOBALS['queries'] = [];
    $GLOBALS['mode'] = $case['mode'];
    $GLOBALS['ticket'] = $case['ticket'] ?? 0;
    $actor = ['user_id' => $case['user'], 'entity_id' => $case['entity'], 'can_read' => true, 'can_create' => true];
    if ($case['mode'] === 'list') {
        glpichat_desktop_conversations($actor, $case['before'] ?? 0, $case['limit'] ?? 30);
    } else {
        glpichat_desktop_ticket($actor, $case['ticket'], false);
    }
    $output[] = $GLOBALS['queries'];
}
echo json_encode($output, JSON_THROW_ON_ERROR);
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('php')
    parser.add_argument('plugin_root', type=Path)
    parser.add_argument('core_ddl', type=Path)
    parser.add_argument('--baseline', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    ddl_bytes = args.core_ddl.read_bytes()
    digest = hashlib.sha256(ddl_bytes).hexdigest()
    if digest != PINNED_DDL_SHA256:
        raise RuntimeError('Expected exact official GLPI 11.0.7 glpi-empty.sql; supplied DDL hash differs.')
    ddl = ddl_bytes.decode()
    db = sqlite3.connect(':memory:')
    db.row_factory = sqlite3.Row
    definitions = {}
    for table in ('glpi_tickets', 'glpi_tickets_users'):
        match = re.search(r'CREATE TABLE `' + table + r'` \(\n(.*?)\n\) ENGINE=.*?;', ddl, re.S)
        if not match:
            raise RuntimeError('Core table definition missing: ' + table)
        # Preserve every native column name. Only MySQL declaration types and
        # engine/index/constraint syntax are projected, not query identifiers.
        columns = re.findall(r'^  `([^`]+)`\s+([^\n]+)', match.group(1), re.M)
        sql_columns = []
        for name, declaration in columns:
            data_type = 'INTEGER' if re.match(r'(?:tinyint|smallint|mediumint|int|bigint)\b', declaration) else 'TEXT'
            sql_columns.append('"' + name + '" ' + data_type)
        db.execute('CREATE TABLE "' + table + '" (' + ','.join(sql_columns) + ')')
        definitions[table] = {'native_ddl': match.group(0), 'columns': [x[0] for x in columns]}
    if 'is_template' in definitions['glpi_tickets']['columns']:
        raise RuntimeError('Regression schema unexpectedly includes nonexistent ticket is_template field.')

    # Real tickets can originate from templates. This does not make the ticket a
    # template row and must not remove it from the requester conversation list.
    ticket_rows = [(100 + status, 2, 'status ' + str(status), status, 0, 0) for status in range(1, 7)]
    ticket_rows += [(107, 2, 'template-origin ticket', 1, 0, 83),
                    (108, 2, 'deleted', 1, 1, 0), (109, 3, 'other entity', 1, 0, 0),
                    (110, 2, 'other requester', 1, 0, 0), (111, 2, 'assigned only', 1, 0, 0),
                    (112, 2, 'invalid status', 7, 0, 0), (113, 2, 'invalid status zero', 0, 0, 0)]
    db.executemany('INSERT INTO glpi_tickets (id,entities_id,name,status,is_deleted,tickettemplates_id) VALUES (?,?,?,?,?,?)', ticket_rows)
    relation_rows = [(index + 1, row[0], 8 if row[0] == 110 else 7, 2 if row[0] == 111 else 1) for index, row in enumerate(ticket_rows)]
    relation_rows.append((99, 107, 7, 1))  # A duplicate requester must not duplicate list items.
    db.executemany('INSERT INTO glpi_tickets_users (id,tickets_id,users_id,type) VALUES (?,?,?,?)', relation_rows)

    cases = [{'mode': 'list', 'user': 7, 'entity': 2},
             {'mode': 'list', 'user': 7, 'entity': 2, 'before': 105},
             {'mode': 'list', 'user': 7, 'entity': 2, 'limit': 2},
             {'mode': 'list', 'user': 8, 'entity': 2},
             {'mode': 'list', 'user': 7, 'entity': 3}]
    cases += [{'mode': 'ticket', 'user': 7, 'entity': 2, 'ticket': row[0]} for row in ticket_rows]
    cases += [{'mode': 'ticket', 'user': 7, 'entity': 2, 'ticket': 999}]

    def capture(root):
        with tempfile.TemporaryDirectory(prefix='glpichat-sql-capture-') as temporary:
            path = Path(temporary) / 'capture.php'
            path.write_text(CAPTURE)
            process = subprocess.run([args.php, str(path), str(root.resolve())], input=json.dumps(cases), text=True, capture_output=True)
            if process.returncode:
                raise RuntimeError(process.stderr)
            return json.loads(process.stdout)

    queries = capture(args.plugin_root)
    checks = []

    def check(ok, description):
        checks.append({'description': description, 'pass': bool(ok)})
        if not ok:
            raise AssertionError(description)

    expected_lists = [[107, 106, 105, 104, 103, 102, 101], [104, 103, 102, 101], [107, 106, 105], [110], [109]]
    for case, sqls, expected in zip(cases[:5], queries[:5], expected_lists):
        check(len(sqls) == 1, 'List capture has exactly one selection query: ' + str(case))
        actual = [row['id'] for row in db.execute(sqls[0])]
        check(actual == expected, 'Exact list SQL requester/entity/deleted/status/template/pagination behavior: ' + str(case))
    for case, sqls in zip(cases[5:], queries[5:]):
        check(len(sqls) == 2, 'Shared lookup emits ticket and direct requester SELECTs for ' + str(case['ticket']))
        ticket_rows_found = list(db.execute(sqls[0]))
        requester_rows_found = list(db.execute(sqls[1]))
        allowed = bool(ticket_rows_found and requester_rows_found)
        check(allowed == (101 <= case['ticket'] <= 107), 'Shared lookup authorization and status filters for ticket ' + str(case['ticket']))
    old_failures = []
    if args.baseline:
        old_queries = capture(args.baseline)
        for name, old_sql in [('list', old_queries[0][0]), ('shared_ticket', old_queries[5][0])]:
            try:
                db.execute(old_sql).fetchall()
            except sqlite3.OperationalError as error:
                old_failures.append({'query': name, 'sql': old_sql, 'error': str(error)})
                check('is_template' in str(error), 'Old ' + name + ' SQL fails specifically on missing native column')
            else:
                check(False, 'Old ' + name + ' SQL must reproduce missing-column failure')
    result = {'engine': 'Python sqlite3 ' + sqlite3.sqlite_version,
              'core_version': 'GLPI 11.0.7', 'core_ddl_sha256': digest,
              'source_sha256': hashlib.sha256((args.plugin_root / 'src/desktop/conversations.php').read_bytes()).hexdigest(),
              'schema': definitions, 'cases': cases, 'captured_production_queries': queries,
              'old_source_failures': old_failures, 'checks': checks, 'passed': len(checks),
              'limits': ['Exact production list/shared lookup SELECTs only; query text is not rewritten.',
                         'Core column declarations are projected into SQLite INTEGER/TEXT; MySQL types, indexes, defaults, constraints and collation are not tested.',
                         'No MySQL locks, followup metadata, native writes, deployed GLPI/HTTP authentication or AD are exercised.']}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print('PASS desktop conversations core-schema SQL: ' + str(len(checks)) + ' checks; unchanged SELECTs in SQLite; old-source failures=' + str(len(old_failures)))


if __name__ == '__main__':
    main()
