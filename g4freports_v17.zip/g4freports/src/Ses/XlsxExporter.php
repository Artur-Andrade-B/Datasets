<?php

namespace GlpiPlugin\G4freports\Ses;

/** Native Excel workbook, using dependency-free OOXML and one monthly snapshot. */
final class XlsxExporter
{
    private array $sheets = [];
    private array $evidence = [];
    private array $rawColumns = [];
    private array $snapshot = [];

    public function filename(array $snapshot): string
    {
        return 'Indicadores_SES_' . preg_replace('/[^0-9-]/', '', $snapshot['period']['month'] ?? '') . '.xlsx';
    }

    public function toBinary(array $snapshot): string
    {
        $this->sheets = [];
        $this->evidence = [];
        $this->rawColumns = [];
        $this->snapshot = $snapshot;
        foreach ($snapshot['metrics'] as $metric) {
            $this->evidence[$metric['id']] = [
                'num' => array_fill_keys(array_map('strval', $metric['evidence_ids'] ?? []), true),
                'den' => array_fill_keys(array_map('strval', $metric['denominator_ids'] ?? []), true),
                'available' => isset($metric['evidence_ids'], $metric['denominator_ids']),
            ];
        }
        // The raw sheets are built first to establish the evidence column map,
        // then ordered after the individual indicators in the final package.
        $tickets = $this->rawTickets();
        $calls = $this->rawCalls();
        $this->sheets[] = $this->consolidated();
        foreach ($snapshot['metrics'] as $metric) {
            $this->sheets[] = $this->metric($metric);
        }
        $this->sheets[] = $tickets;
        $this->sheets[] = $calls;
        $this->sheets[] = $this->methodology();
        return $this->package();
    }

    private function sheet(string $name, array $widths): array
    {
        return ['name' => $name, 'widths' => $widths, 'rows' => [], 'merges' => [], 'heights' => [], 'filter' => '', 'freeze' => 6, 'chart' => false];
    }

    private function put(array &$sheet, int $row, int $col, $value, int $style = 0, ?string $formula = null): void
    {
        $sheet['rows'][$row][$col] = ['value' => $value, 'style' => $style, 'formula' => $formula];
    }

    private function merged(array &$sheet, int $row, string $text, int $style, int $end = 7, int $height = 32): void
    {
        $this->put($sheet, $row, 1, $text, $style);
        $sheet['merges'][] = 'A' . $row . ':' . self::col($end) . $row;
        $sheet['heights'][$row] = $height;
    }

    private function title(array &$sheet, string $title, int $end = 7): void
    {
        $this->merged($sheet, 1, $title, 1, $end, 48);
        $this->merged($sheet, 2, 'G4F | Contrato SES/DF 053592/2025 | ' . ($this->snapshot['period']['label'] ?? $this->snapshot['period']['month']), 2, $end, 28);
        $this->merged($sheet, 3, 'Chamados por solução; ligações por entrada na fila. Extração: ' . OfficePackage::date($this->snapshot['generated_at'] ?? ''), 9, $end, 30);
    }

    private function headers(array &$sheet, int $row, array $headers): void
    {
        foreach ($headers as $i => $header) {
            $this->put($sheet, $row, $i + 1, $header, 3);
        }
        $sheet['heights'][$row] = 36;
    }

    private function consolidated(): array
    {
        $sheet = $this->sheet('Painel Consolidado', [12, 64, 14, 16, 25, 18, 18]);
        $this->title($sheet, 'Relatório mensal de indicadores SES');
        $this->merged($sheet, 5, 'Apuração operacional | INS1 a INS12', 2);
        $this->headers($sheet, 7, ['Indicador', 'Descrição', 'Meta', 'Resultado', 'Situação', 'Numerador', 'Denominador']);
        foreach ($this->snapshot['metrics'] as $i => $m) {
            $row = 8 + $i;
            $this->put($sheet, $row, 1, $m['id'], 4);
            $this->put($sheet, $row, 2, $m['label'], 0);
            $this->put($sheet, $row, 3, ($m['direction'] === 'lte' ? '≤ ' : '≥ ') . OfficePackage::percent($m['target']), 4);
            $result = $m['value'] === null ? ($m['status'] === 'not_applicable' ? 'N/A' : 'Pendente') : $m['value'] / 100;
            $this->put($sheet, $row, 4, $result, 6, "'" . $m['id'] . "'!B10");
            $this->put($sheet, $row, 5, OfficePackage::status($m), $this->statusStyle($m), "'" . $m['id'] . "'!B12");
            $this->put($sheet, $row, 6, $m['numerator'] === null ? 'Pendente' : $m['numerator'], 5, "'" . $m['id'] . "'!B8");
            $this->put($sheet, $row, 7, $m['denominator'] === null ? 'Pendente' : $m['denominator'], 5, "'" . $m['id'] . "'!B9");
            $sheet['heights'][$row] = 44;
        }
        $this->merged($sheet, 22, 'Resumo operacional do período', 2);
        $labels = ['tickets' => 'Chamados solucionados', 'requests' => 'Requisições', 'incidents' => 'Incidentes', 'missing_deadline' => 'Chamados sem prazo registrado', 'calls_received' => 'Ligações recebidas após exclusões', 'calls_answered' => 'Ligações atendidas', 'calls_abandoned' => 'Ligações abandonadas', 'calls_excluded' => 'Ligações de teste excluídas'];
        $row = 24;
        foreach ($labels as $key => $label) {
            $this->put($sheet, $row, 2, $label, 0);
            $this->put($sheet, $row++, 4, $this->snapshot['totals'][$key] ?? 0, 5);
        }
        $this->put($sheet, 32, 2, 'Duração média das conversas atendidas');
        $this->put($sheet, 32, 4, $this->duration($this->snapshot['totals']['mean_talk_seconds'] ?? null), 10);
        $this->put($sheet, 33, 2, 'Espera média antes da conexão ao agente');
        $this->put($sheet, 33, 4, $this->duration($this->snapshot['totals']['mean_wait_seconds'] ?? null), 10);
        $this->merged($sheet, 35, 'Os percentuais operacionais não geram descontos financeiros automáticos. Pendências e resultados provisórios exigem a complementação indicada na aba do INS.', 9, 7, 44);
        $sheet['chart'] = true;
        return $sheet;
    }

    private function metric(array $m): array
    {
        $sheet = $this->sheet($m['id'], [47, 23, 21, 21, 21, 21, 23]);
        $this->title($sheet, $m['id'] . ' | ' . $m['label']);
        $this->merged($sheet, 5, $m['method'], 9, 7, 65);
        $this->headers($sheet, 7, ['Medição', 'Valor']);
        $hasEvidence = $this->evidence[$m['id']]['available'] && isset($this->rawColumns[$m['id']]);
        $source = $this->rawColumns[$m['id']] ?? null;
        foreach ([8 => ['Numerador', 'numerator', 'num'], 9 => ['Denominador', 'denominator', 'den']] as $row => $spec) {
            $formula = null;
            if ($hasEvidence && $m[$spec[1]] !== null) {
                $formula = 'SUM(' . $this->range($source['sheet'], $source[$spec[2]], $source['rows']) . ')';
            }
            $this->put($sheet, $row, 1, $spec[0], 0);
            $this->put($sheet, $row, 2, $m[$spec[1]] === null ? 'Pendente' : $m[$spec[1]], 5, $formula);
        }
        $this->put($sheet, 10, 1, 'Resultado', 4);
        $result = $m['value'] === null ? ($m['status'] === 'not_applicable' ? 'N/A' : 'Pendente') : $m['value'] / 100;
        $this->put($sheet, 10, 2, $result, 6, $m['value'] !== null ? 'IF(B9=0,"N/A",B8/B9)' : null);
        $this->put($sheet, 11, 1, 'Meta ' . ($m['direction'] === 'lte' ? '≤' : '≥'), 0);
        $this->put($sheet, 11, 2, $m['target'] / 100, 6);
        $this->put($sheet, 12, 1, 'Situação', 4);
        $statusFormula = null;
        if (in_array($m['status'], ['met', 'unmet'], true)) {
            $operator = $m['direction'] === 'lte' ? '<=' : '>=';
            $statusFormula = 'IF(ISNUMBER(B10),IF(B10' . $operator . 'B11,"Meta atingida","Meta não atingida"),"Não aplicável")';
        }
        $this->put($sheet, 12, 2, OfficePackage::status($m), $this->statusStyle($m), $statusFormula);
        $sheet['merges'][] = 'B12:D12';
        $sheet['heights'][12] = 34;
        $this->merged($sheet, 15, trim((string)($m['note'] ?? '')) ?: 'Evidências vinculadas às bases de chamados e ligações desta extração.', 9, 7, 64);
        if ($m['id'] === 'INS10') {
            $this->merged($sheet, 18, 'Informações de pessoal | janela de três meses', 2);
            $this->headers($sheet, 20, ['Informação', 'Quantidade']);
            $staff = ['staff_total' => 'Profissionais na base de cálculo', 'staff_replacements' => 'Substituições', 'staff_excluded' => 'Exclusões por determinação da contratante'];
            $r = 21;
            foreach ($staff as $key => $label) {
                $this->put($sheet, $r, 1, $label);
                $this->put($sheet, $r++, 2, $this->snapshot['input'][$key] ?? 'Não informado', 5);
            }
        } elseif ($hasEvidence) {
            $this->daily($sheet, $m, $source);
        }
        return $sheet;
    }

    private function daily(array &$sheet, array $m, array $source): void
    {
        $this->merged($sheet, 18, 'Distribuição diária da população do indicador', 2);
        $this->headers($sheet, 20, ['Data de referência', 'Numerador', 'Denominador', 'Resultado diário']);
        $dateKey = $source['sheet'] === 'Base de Dados' ? 'solved_at' : 'entered_at';
        $rows = $source['sheet'] === 'Base de Dados' ? $this->snapshot['tickets'] : $this->snapshot['calls'];
        $daily = [];
        foreach ($rows as $item) {
            $key = $source['sheet'] === 'Base de Dados' ? (string)$item['id'] : (string)($item['call_key'] ?? ($item['id'] . '|' . $item['queue']));
            $day = substr((string)($item[$dateKey] ?? ''), 0, 10);
            if ($day === '') { continue; }
            if (!isset($daily[$day])) { $daily[$day] = [0, 0]; }
            $daily[$day][0] += isset($this->evidence[$m['id']]['num'][$key]) ? 1 : 0;
            $daily[$day][1] += isset($this->evidence[$m['id']]['den'][$key]) ? 1 : 0;
        }
        ksort($daily);
        $r = 21;
        $dates = $this->range($source['sheet'], $source['date'], $source['rows']);
        foreach ($daily as $day => $counts) {
            $this->put($sheet, $r, 1, $this->excelDate($day), 8);
            foreach (['num', 'den'] as $i => $part) {
                $sumRange = $this->range($source['sheet'], $source[$part], $source['rows']);
                $formula = 'SUMIFS(' . $sumRange . ',' . $dates . ',">="&A' . $r . ',' . $dates . ',"<"&A' . $r . '+1)';
                $this->put($sheet, $r, $i + 2, $counts[$i], 5, $formula);
            }
            $this->put($sheet, $r, 4, $counts[1] ? $counts[0] / $counts[1] : 'N/A', 6, 'IF(C' . $r . '=0,"N/A",B' . $r . '/C' . $r . ')');
            $r++;
        }
        $sheet['filter'] = 'A20:D' . max(20, $r - 1);
    }

    private function rawTickets(): array
    {
        $headers = ['ID', 'Título', 'Tipo', 'Status', 'Prioridade GLPI', 'Categoria ID', 'Categoria', 'Abertura', 'Solução', 'Fechamento', 'Prazo para solução', 'SLA ID', 'SLA aplicado', 'No prazo', 'Tempo útil de solução', 'Tempo corrido', 'Tempo em espera', 'Grupos técnicos', 'Técnicos', 'Localização', 'Elegível N1', 'Reaberto', 'Solução recusada', 'Artigos vinculados', 'Vínculo validado', 'Categoria da base de conhecimento', 'Satisfação'];
        $widths = [13, 65, 17, 15, 18, 14, 68, 23, 23, 23, 23, 13, 35, 17, 23, 23, 23, 55, 45, 55, 18, 16, 18, 22, 22, 23, 16];
        $ids = ['INS1', 'INS2', 'INS3', 'INS4', 'INS5', 'INS6', 'INS11', 'INS12'];
        foreach ($ids as $id) {
            $this->rawColumns[$id] = ['sheet' => 'Base de Dados', 'num' => count($headers) + 1, 'den' => count($headers) + 2, 'date' => 9, 'rows' => count($this->snapshot['tickets'])];
            $headers[] = $id . ' numerador'; $headers[] = $id . ' denominador';
            $widths[] = 18; $widths[] = 18;
        }
        $sheet = $this->sheet('Base de Dados', $widths);
        $this->title($sheet, 'Base de chamados solucionados');
        $this->merged($sheet, 5, 'Uma linha por chamado. Colunas de evidência: 1 inclui o registro na população do indicador; 0 não inclui. Prazos ausentes permanecem sem classificação.', 9, 10, 40);
        $this->headers($sheet, 6, $headers);
        $r = 7;
        foreach ($this->snapshot['tickets'] as $t) {
            $type = is_numeric($t['type'] ?? null) ? ((int)$t['type'] === 1 ? 'Incidente' : 'Requisição') : ($t['type'] ?? '');
            $status = [5 => 'Solucionado', 6 => 'Fechado'][(int)($t['status'] ?? 0)] ?? (string)($t['status'] ?? '');
            $values = [(string)$t['id'], $t['title'] ?? '', $type, $status, $t['priority'] ?? null, $t['category_id'] ?? null, $t['category'] ?? '', $this->excelDate($t['opened_at'] ?? null), $this->excelDate($t['solved_at'] ?? null), $this->excelDate($t['closed_at'] ?? null), $this->excelDate($t['deadline'] ?? null), $t['sla_id'] ?? null, $t['sla_name'] ?? '', ($t['within_sla'] ?? null) === null ? 'Sem prazo' : ($t['within_sla'] ? 'No prazo' : 'Fora do prazo'), $this->duration($t['solve_seconds'] ?? null), $this->duration($t['elapsed_seconds'] ?? null), $this->duration($t['waiting_seconds'] ?? null), $t['groups'] ?? '', $t['technicians'] ?? '', $t['location'] ?? '', !empty($t['n1_eligible']) ? 'Sim' : 'Não', !empty($t['reopened']) ? 'Sim' : 'Não', !empty($t['refused_solution']) ? 'Sim' : 'Não', implode(', ', $t['kb_ids'] ?? []), !empty($t['kb_validated']) ? 'Sim' : 'Não', $t['kb_category_id'] ?? null, $t['satisfaction'] ?? null];
            foreach ($ids as $id) {
                $values[] = isset($this->evidence[$id]['num'][(string)$t['id']]) ? 1 : 0;
                $values[] = isset($this->evidence[$id]['den'][(string)$t['id']]) ? 1 : 0;
            }
            foreach ($values as $i => $value) {
                $col = $i + 1;
                $style = $col === 1 ? 14 : (in_array($col, [8, 9, 10, 11], true) ? 7 : (in_array($col, [15, 16, 17], true) ? 10 : (is_numeric($value) && !is_string($value) ? 5 : 0)));
                $this->put($sheet, $r, $col, $value, $style);
            }
            $sheet['heights'][$r++] = 42;
        }
        $sheet['filter'] = 'A6:' . self::col(count($headers)) . max(6, $r - 1);
        return $sheet;
    }

    private function rawCalls(): array
    {
        $headers = ['ID da ligação', 'Chave ligação e fila', 'Fila', 'Entrada na fila', 'Conexão', 'Finalização', 'Abandono', 'Número de origem', 'Tipo', 'Evento de finalização', 'Agente', 'Duração da conversa', 'Espera até conexão', 'Espera no abandono', 'Satisfação'];
        $widths = [27, 48, 28, 24, 24, 24, 24, 23, 22, 28, 25, 23, 23, 23, 17];
        foreach (['INS7', 'INS8', 'INS9'] as $id) {
            $this->rawColumns[$id] = ['sheet' => 'Base de Dados Ligações', 'num' => count($headers) + 1, 'den' => count($headers) + 2, 'date' => 4, 'rows' => count($this->snapshot['calls'])];
            $headers[] = $id . ' numerador'; $headers[] = $id . ' denominador';
            $widths[] = 18; $widths[] = 18;
        }
        $sheet = $this->sheet('Base de Dados Ligações', $widths);
        $this->title($sheet, 'Base de ligações consideradas');
        $this->merged($sheet, 5, 'Tempos individuais em horas, minutos e segundos. Ligações de teste excluídas: ' . ($this->snapshot['totals']['calls_excluded'] ?? 0) . '. Identificadores e telefones são armazenados como texto.', 9, 10, 40);
        $this->headers($sheet, 6, $headers);
        $r = 7;
        foreach ($this->snapshot['calls'] as $c) {
            $key = (string)($c['call_key'] ?? ($c['id'] . '|' . $c['queue']));
            $values = [(string)$c['id'], $key, $c['queue'] ?? '', $this->excelDate($c['entered_at'] ?? null), $this->excelDate($c['connected_at'] ?? null), $this->excelDate($c['completed_at'] ?? null), $this->excelDate($c['abandoned_at'] ?? null), (string)($c['caller'] ?? ''), $c['type'] ?? '', $c['termination'] ?? '', $c['agent'] ?? '', $this->duration($c['talk_seconds'] ?? null), $this->duration($c['wait_seconds'] ?? null), $this->duration($c['abandon_wait_seconds'] ?? null), $c['satisfaction'] ?? null];
            foreach (['INS7', 'INS8', 'INS9'] as $id) {
                $values[] = isset($this->evidence[$id]['num'][$key]) ? 1 : 0;
                $values[] = isset($this->evidence[$id]['den'][$key]) ? 1 : 0;
            }
            foreach ($values as $i => $value) {
                $col = $i + 1;
                $style = in_array($col, [1, 2, 8], true) ? 14 : (in_array($col, [4, 5, 6, 7], true) ? 7 : (in_array($col, [12, 13, 14], true) ? 10 : (is_numeric($value) && !is_string($value) ? 5 : 0)));
                $this->put($sheet, $r, $col, $value, $style);
            }
            $sheet['heights'][$r++] = 30;
        }
        $sheet['filter'] = 'A6:' . self::col(count($headers)) . max(6, $r - 1);
        return $sheet;
    }

    private function methodology(): array
    {
        $sheet = $this->sheet('Metodologia', [38, 38, 23, 23, 23, 23, 23]);
        $this->title($sheet, 'Metodologia e informações da extração');
        $input = $this->snapshot['input'] ?? [];
        $details = [
            ['Versão das regras', $this->snapshot['rules_version'] ?? ''],
            ['Início inclusivo', OfficePackage::date($this->snapshot['period']['start'])],
            ['Fim exclusivo', OfficePackage::date($this->snapshot['period']['end_exclusive'])],
            ['Base de chamados', 'Data de solução; inclui chamados abertos antes da competência.'],
            ['Base de telefonia', 'Entrada na fila; eventos posteriores ao fim do mês podem concluir a ligação.'],
            ['Entidade GLPI', (string)($input['entity_id'] ?? '')],
            ['Grupos técnicos', !empty($input['group_ids']) ? implode(', ', $input['group_ids']) : 'Todos os grupos da entidade selecionada'],
            ['Fila', (string)($input['queue_filter'] ?? '')],
            ['Horário de referência', (string)($input['timezone'] ?? 'America/Sao_Paulo')],
            ['Associação INS e prioridade GLPI', json_encode($input['priority_map'] ?? [], JSON_UNESCAPED_UNICODE)],
            ['Categorias elegíveis N1', implode(', ', $input['n1_categories'] ?? [])],
            ['Grupos N1', implode(', ', $input['n1_group_ids'] ?? [])],
            ['Grupos N2', implode(', ', $input['n2_group_ids'] ?? [])],
            ['Modo INS6', (string)($input['ins6_mode'] ?? '')],
            ['Modo base de conhecimento', (string)($input['kb_mode'] ?? '')],
            ['Artigos validados informados', implode(', ', $input['validated_kb_ids'] ?? [])],
            ['Execução incompleta informada', implode(', ', $input['incomplete_ticket_ids'] ?? [])],
            ['Exclusão de testes', 'Correspondência exata do número de origem normalizado. Quantidade excluída: ' . ($this->snapshot['totals']['calls_excluded'] ?? 0) . '. A lista aplicada integra o registro da extração.'],
            ['Dados e fórmulas', 'As bases preservam uma linha por chamado ou ligação e fila. As colunas de evidência indicam numerador e denominador; as abas INS somam essas colunas e calculam a razão. O painel referencia as abas INS.'],
            ['Dados ausentes', 'Pendente indica informação necessária ausente; N/A indica população sem denominador. Zero só é apresentado quando houve medição.'],
            ['Referências', 'Edital PE 90067/2024; alinhamento operacional de 31/07/2026; configuração da extração.'],
        ];
        $r = 5;
        foreach ($details as $detail) {
            $this->put($sheet, $r, 1, $detail[0], 4);
            $this->put($sheet, $r, 2, $detail[1], 9);
            $sheet['merges'][] = 'B' . $r . ':G' . $r;
            $sheet['heights'][$r++] = 42;
        }
        foreach (['rule_notes' => 'Regras da medição', 'warnings' => 'Limitações da apuração'] as $key => $label) {
            if (empty($this->snapshot[$key])) { continue; }
            $this->merged($sheet, ++$r, $label, 2);
            foreach ($this->snapshot[$key] as $note) {
                $this->merged($sheet, ++$r, $note, 9, 7, 52);
            }
        }
        foreach (['executive_summary' => 'Análise executiva', 'actions' => 'Ações corretivas e melhorias', 'notes' => 'Observações gerenciais'] as $key => $label) {
            $text = trim((string)($this->snapshot['manual'][$key] ?? ''));
            if ($text !== '') {
                $this->merged($sheet, ++$r, $label, 2);
                foreach (preg_split('/\r\n|\r|\n/', $text) as $line) {
                    if (trim($line) !== '') { $this->merged($sheet, ++$r, $line, 9, 7, min(300, 40 + (int)(strlen($line) / 160) * 15)); }
                }
            }
        }
        return $sheet;
    }

    private function range(string $sheet, int $col, int $rows): string
    {
        return "'" . str_replace("'", "''", $sheet) . "'!$" . self::col($col) . '$7:$' . self::col($col) . '$' . max(7, 6 + $rows);
    }

    private function duration($seconds)
    {
        return $seconds === null ? null : (float)$seconds / 86400;
    }

    private function excelDate($value)
    {
        if ($value === null || $value === '') { return null; }
        try {
            // Database timestamps represent local civil time. Do not convert
            // their wall clock using the PHP server timezone when serializing.
            $date = new \DateTimeImmutable(str_replace('T', ' ', substr((string)$value, 0, 26)), new \DateTimeZone('UTC'));
            return (float)$date->format('U.u') / 86400 + 25569;
        } catch (\Exception $e) {
            return (string)$value;
        }
    }

    private function statusStyle(array $m): int
    {
        return $m['status'] === 'met' ? 11 : ($m['status'] === 'unmet' ? 12 : 13);
    }

    private static function col(int $value): string
    {
        $name = '';
        do { $value--; $name = chr(65 + $value % 26) . $name; $value = intdiv($value, 26); } while ($value > 0);
        return $name;
    }

    private function sheetXml(array $sheet): string
    {
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0" showGridLines="0"><pane ySplit="' . $sheet['freeze'] . '" topLeftCell="A' . ($sheet['freeze'] + 1) . '" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A' . ($sheet['freeze'] + 1) . '" sqref="A' . ($sheet['freeze'] + 1) . '"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="25"/><cols>';
        foreach ($sheet['widths'] as $i => $width) {
            $xml .= '<col min="' . ($i + 1) . '" max="' . ($i + 1) . '" width="' . $width . '" customWidth="1"/>';
        }
        $xml .= '</cols><sheetData>';
        ksort($sheet['rows']);
        foreach ($sheet['rows'] as $r => $cells) {
            $xml .= '<row r="' . $r . '"' . (isset($sheet['heights'][$r]) ? ' ht="' . $sheet['heights'][$r] . '" customHeight="1"' : '') . '>';
            ksort($cells);
            foreach ($cells as $c => $cell) {
                $ref = self::col($c) . $r;
                $v = $cell['value'];
                $numeric = is_int($v) || is_float($v);
                if ($cell['formula'] !== null) {
                    $xml .= '<c r="' . $ref . '" s="' . $cell['style'] . '"' . ($numeric ? '' : ' t="str"') . '><f>' . OfficePackage::xml($cell['formula']) . '</f><v>' . OfficePackage::xml($numeric ? sprintf('%.15g', $v) : $v) . '</v></c>';
                } elseif ($v === null) {
                    $xml .= '<c r="' . $ref . '" s="' . $cell['style'] . '"/>';
                } elseif ($numeric) {
                    $xml .= '<c r="' . $ref . '" s="' . $cell['style'] . '"><v>' . sprintf('%.15g', $v) . '</v></c>';
                } else {
                    // All source text uses inlineStr, including values starting
                    // with =,+,-,@. User input is never parsed as a formula.
                    $xml .= '<c r="' . $ref . '" s="' . $cell['style'] . '" t="inlineStr"><is><t xml:space="preserve">' . OfficePackage::xml($v) . '</t></is></c>';
                }
            }
            $xml .= '</row>';
        }
        $xml .= '</sheetData>';
        if ($sheet['filter'] !== '') { $xml .= '<autoFilter ref="' . $sheet['filter'] . '"/>'; }
        if ($sheet['merges']) {
            $xml .= '<mergeCells count="' . count($sheet['merges']) . '">';
            foreach ($sheet['merges'] as $range) { $xml .= '<mergeCell ref="' . $range . '"/>'; }
            $xml .= '</mergeCells>';
        }
        $xml .= '<pageMargins left="0.3" right="0.3" top="0.5" bottom="0.5" header="0.2" footer="0.2"/><pageSetup orientation="landscape" paperSize="9" fitToWidth="1" fitToHeight="0"/><headerFooter><oddFooter>&amp;LG4F | SES&amp;R&amp;P / &amp;N</oddFooter></headerFooter>';
        if ($sheet['chart']) { $xml .= '<drawing r:id="rIdChart"/>'; }
        return $xml . '</worksheet>';
    }

    private function styles(): string
    {
        $formats = [164 => '0.00%', 165 => 'dd/mm/yyyy hh:mm:ss', 166 => 'dd/mm/yyyy', 167 => '[h]:mm:ss'];
        $xml = '<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="4">';
        foreach ($formats as $id => $code) { $xml .= '<numFmt numFmtId="' . $id . '" formatCode="' . $code . '"/>'; }
        $xml .= '</numFmts><fonts count="5"><font><sz val="11"/><color rgb="FF223344"/><name val="Arial"/></font><font><b/><sz val="21"/><color rgb="FFFFFFFF"/><name val="Arial"/></font><font><b/><sz val="12"/><color rgb="FFFFFFFF"/><name val="Arial"/></font><font><b/><sz val="11"/><color rgb="FF002B49"/><name val="Arial"/></font><font><sz val="10"/><color rgb="FF536577"/><name val="Arial"/></font></fonts><fills count="8"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>';
        foreach (['002B49', '188DA1', 'EDF3F7', 'E7F2EA', 'FBE9E8', 'FFF4CF'] as $color) { $xml .= '<fill><patternFill patternType="solid"><fgColor rgb="FF' . $color . '"/><bgColor indexed="64"/></patternFill></fill>'; }
        $xml .= '</fills><borders count="2"><border/><border><bottom style="thin"><color rgb="FFD6E0E7"/></bottom></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="15">';
        // font, fill, format, border, horizontal alignment
        $styles = [[0,0,0,1,'left'],[1,2,0,0,'left'],[2,3,0,0,'left'],[2,2,0,1,'left'],[3,4,0,1,'left'],[0,0,3,1,'right'],[3,4,164,1,'right'],[0,0,165,1,'left'],[0,0,166,1,'left'],[4,0,0,0,'left'],[0,0,167,1,'right'],[3,5,0,1,'left'],[3,6,0,1,'left'],[3,7,0,1,'left'],[0,0,49,1,'left']];
        foreach ($styles as $s) { $xml .= '<xf numFmtId="' . $s[2] . '" fontId="' . $s[0] . '" fillId="' . $s[1] . '" borderId="' . $s[3] . '" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="' . $s[4] . '" vertical="center" wrapText="1"/></xf>'; }
        return $xml . '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles><dxfs count="0"/></styleSheet>';
    }

    private function package(): string
    {
        $types = '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>';
        $workbook = '<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets>';
        $rels = '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>';
        $files = [];
        foreach ($this->sheets as $i => $sheet) {
            $n = $i + 1;
            $workbook .= '<sheet name="' . OfficePackage::xml($sheet['name']) . '" sheetId="' . $n . '" r:id="rId' . $n . '"/>';
            $rels .= '<Relationship Id="rId' . $n . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $n . '.xml"/>';
            $types .= '<Override PartName="/xl/worksheets/sheet' . $n . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
            $files['xl/worksheets/sheet' . $n . '.xml'] = $this->sheetXml($sheet);
        }
        $files['xl/workbook.xml'] = $workbook . '</sheets><calcPr calcId="191029" fullCalcOnLoad="1" forceFullCalc="1"/></workbook>';
        $files['xl/_rels/workbook.xml.rels'] = $rels . '</Relationships>';
        $files['xl/styles.xml'] = $this->styles();
        $files['_rels/.rels'] = '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>';
        $this->addChart($files, $types);
        $files['[Content_Types].xml'] = $types . '</Types>';
        return OfficePackage::write($files);
    }

    private function addChart(array &$files, string &$types): void
    {
        $files['xl/worksheets/_rels/sheet1.xml.rels'] = '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdChart" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/></Relationships>';
        $files['xl/drawings/_rels/drawing1.xml.rels'] = '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart" Target="../charts/chart1.xml"/></Relationships>';
        $files['xl/drawings/drawing1.xml'] = '<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><xdr:twoCellAnchor><xdr:from><xdr:col>0</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>37</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from><xdr:to><xdr:col>7</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>59</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to><xdr:graphicFrame macro=""><xdr:nvGraphicFramePr><xdr:cNvPr id="2" name="Resultados dos indicadores"/><xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr><xdr:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/></xdr:xfrm><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart"><c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:id="rId1"/></a:graphicData></a:graphic></xdr:graphicFrame><xdr:clientData/></xdr:twoCellAnchor></xdr:wsDr>';
        $cats = ''; $values = '';
        foreach ($this->snapshot['metrics'] as $i => $m) {
            $cats .= '<c:pt idx="' . $i . '"><c:v>' . OfficePackage::xml($m['id']) . '</c:v></c:pt>';
            if ($m['value'] !== null) { $values .= '<c:pt idx="' . $i . '"><c:v>' . sprintf('%.15g', $m['value'] / 100) . '</c:v></c:pt>'; }
        }
        $files['xl/charts/chart1.xml'] = '<c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><c:lang val="pt-BR"/><c:chart><c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:r><a:t>Resultados dos indicadores</a:t></a:r></a:p></c:rich></c:tx></c:title><c:plotArea><c:layout/><c:barChart><c:barDir val="bar"/><c:grouping val="clustered"/><c:ser><c:idx val="0"/><c:order val="0"/><c:tx><c:v>Resultado</c:v></c:tx><c:spPr><a:solidFill><a:srgbClr val="188DA1"/></a:solidFill></c:spPr><c:cat><c:strRef><c:f>\'Painel Consolidado\'!$A$8:$A$19</c:f><c:strCache><c:ptCount val="12"/>' . $cats . '</c:strCache></c:strRef></c:cat><c:val><c:numRef><c:f>\'Painel Consolidado\'!$D$8:$D$19</c:f><c:numCache><c:formatCode>0.0%</c:formatCode><c:ptCount val="12"/>' . $values . '</c:numCache></c:numRef></c:val></c:ser><c:gapWidth val="50"/><c:axId val="100"/><c:axId val="200"/></c:barChart><c:catAx><c:axId val="100"/><c:scaling><c:orientation val="maxMin"/></c:scaling><c:axPos val="l"/><c:tickLblPos val="nextTo"/><c:crossAx val="200"/><c:crosses val="autoZero"/></c:catAx><c:valAx><c:axId val="200"/><c:scaling><c:orientation val="minMax"/><c:max val="1"/><c:min val="0"/></c:scaling><c:axPos val="b"/><c:majorGridlines/><c:numFmt formatCode="0%" sourceLinked="0"/><c:tickLblPos val="nextTo"/><c:crossAx val="100"/><c:crosses val="autoZero"/></c:valAx></c:plotArea><c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/></c:chart></c:chartSpace>';
        $types .= '<Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/><Override PartName="/xl/charts/chart1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawingml.chart+xml"/>';
    }
}
