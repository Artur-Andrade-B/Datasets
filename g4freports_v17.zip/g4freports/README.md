# Relatórios G4F — 1.8.0

Plugin GLPI com dois fluxos: relatórios por profissional, obtidos pela API REST, e relatório mensal SES, obtido diretamente dos bancos GLPI/MariaDB e Asterisk/MySQL. O módulo SES gera Word editável em papel timbrado G4F e Excel a partir da mesma extração.

## Atualização

O pacote contém uma única pasta `g4freports/`.

1. Guarde uma cópia da pasta atual fora dos diretórios de plugins e mantenha o backup habitual do GLPI.
2. Substitua a pasta ativa `g4freports` pela pasta do pacote, preservando proprietário e permissões do servidor web. Evite manter outra cópia com o mesmo nome em `plugins` e `marketplace`.
3. Em **Configurar → Plugins**, execute a atualização indicada pelo GLPI e habilite o plugin. **Não desinstale para atualizar:** a desinstalação remove as configurações salvas.
4. Em **Configurar → Geral → Relatórios G4F**, confirme a identificação **Versão 1.8.0**, os campos API existentes e as duas seções de banco.
5. Em **Ferramentas → Relatórios G4F**, confirme o botão **Relatório mensal SES — Word e Excel**.

A instalação/atualização acrescenta somente configurações ausentes. Perfis e senhas existentes são preservados. Não são criadas tabelas de negócio nos bancos consultados. Composer, PHPWord e bibliotecas externas de planilhas não são necessários; o autoload e o papel timbrado já acompanham o pacote.

Se a versão ou os controles exibidos não corresponderem ao pacote, abra **Diagnóstico técnico**, ao final da configuração, ou o endereço relativo `plugins/g4freports/front/diagnostics.php`. A área administrativa informa a versão carregada, os caminhos dos arquivos e os hashes em disco, permitindo verificar qual cópia está em uso antes de alterar novamente a instalação.

## Conexões de banco

As fontes SQL do módulo SES são independentes dos perfis de API e da conexão do Metabase. Configure-as em **Configurar → Geral → Relatórios G4F**:

| Seção | Fonte |
| --- | --- |
| GLPI / MariaDB — Relatório mensal SES | Banco GLPI com chamados, prazos e evidências dos indicadores |
| Callcenter / MySQL — Telefonia | Banco Asterisk com `queue_log`; banco inicial `ipbx`, porta inicial `2210` |

Para cada fonte:

1. Preencha servidor, porta, banco e usuário; selecione **Habilitar conexão: Sim**. O auxiliar DBeaver aceita `jdbc:mysql://servidor:porta/banco` ou `jdbc:mariadb://servidor:porta/banco` e preenche apenas o endereço.
2. Informe a senha ou o nome de uma variável de ambiente disponível ao PHP do GLPI.
3. Configure TLS e os limites de tempo conforme o servidor. Em modo TLS, o certificado é verificado; o arquivo CA, quando informado, deve existir no servidor GLPI.
4. Clique em **Salvar configurações**, ao final da página, e depois em **Testar conexão** na seção correspondente.

O teste utiliza os valores salvos. A senha armazenada não reaparece no formulário: deixar em branco mantém o valor; preencher substitui; a opção de remoção apaga. As senhas usam a criptografia nativa do GLPI. Uma variável de ambiente configurada tem prioridade sobre a senha armazenada.

O PHP precisa da extensão `mysqli`, e o servidor GLPI precisa alcançar as duas fontes SQL. O acesso pelo DBeaver ou Metabase não comprova essa conectividade. Use contas com privilégios de leitura: o plugin executa consultas de leitura, mas o teste não certifica que a conta esteja impedida de escrever.

Abrir a configuração ou a tela SES não consulta as fontes SQL. A conexão ocorre ao testar ou gerar o relatório. Os relatórios por profissional continuam utilizando a API.

## Relatório mensal SES

1. Abra **Ferramentas → Relatórios G4F → Relatório mensal SES — Word e Excel**.
2. Escolha o mês, a entidade, os grupos atribuídos quando necessários e o identificador da fila. A entidade é exata, sem somar subentidades; grupos em branco abrangem todos os grupos dessa entidade. O filtro de fila procura o texto informado no nome da fila.
3. Revise **Critérios dos indicadores**, especialmente o mapeamento INS1–INS4, categorias/grupos N1 e artigos validados para INS11.
4. Complete os dados manuais de INS5/INS10 e os textos gerenciais. Salve a lista de números de teste antes da geração.
5. Clique em **Gerar relatório mensal**. Revise totais, indicadores, observações e as tabelas paginadas de chamados, ligações consideradas e testes excluídos.
6. Use **Exportar Word** e **Exportar Excel**. Ambos utilizam os mesmos dados e critérios preservados no rascunho.

O recorte dos chamados usa **data de solução (`solvedate`)**, inclusive chamados criados antes do mês. O intervalo começa no primeiro dia às 00:00 e termina no início do mês seguinte, sem incluir esse instante. Ligações usam a entrada na fila (`ENTERQUEUE`); eventos posteriores ao fim do mês são consultados para determinar o desfecho. As datas são interpretadas em `America/Sao_Paulo`, sem conversão automática de campos gravados em UTC. Esses critérios constam nos arquivos.

**Atualizar textos** altera título, análise, ações e observações sem consultar novamente as fontes. Alterar período, abrangência, critérios, dados numéricos manuais ou a lista de testes exige gerar novamente. O rascunho é temporário, vinculado ao usuário e válido por até 24 horas; exporte os arquivos para manter o registro. Uma nova extração reflete o estado atual dos bancos e pode diferir de um relatório antigo.

O Word contém o relatório gerencial editável com o timbre G4F. O Excel contém **16 abas**: `Painel Consolidado`, `INS1` a `INS12`, `Base de Dados`, `Base de Dados Ligações` e `Metodologia`. As bases incluem todos os registros considerados na extração; a paginação da prévia não limita os dados exportados. Os indicadores apresentam suas evidências, critérios e situações de apuração.

## Números de teste

Na área SES, abra **Números de teste excluídos da telefonia**. Administradores podem adicionar, editar ou remover números, informar sua identificação/motivo e ativar a exclusão. Clique em **Salvar números de teste** antes de gerar.

A correspondência usa exatamente os dígitos do número de origem após remover espaços e pontuação. Não acrescenta DDI, não compara apenas o final do número e não exclui ligações curtas automaticamente. Cadastre o número como aparece na origem registrada pela fila.

As ligações correspondentes ficam fora dos totais, INS7–INS9, médias e detalhes de telefonia considerados. A prévia permite consultar os testes excluídos, e os relatórios informam sua quantidade. A lista aplicada fica preservada com o rascunho: editar o cadastro não altera uma extração já gerada.

## Critérios que exigem revisão

| Indicador | Comportamento desta versão |
| --- | --- |
| INS1–INS4 | Há dois mapeamentos explícitos: painel atual (`2, 3, 4, 5`) ou ordem do contrato (`5, 4, 3, 2`). A associação escolhida aparece no relatório. O cálculo compara a solução com o prazo armazenado no GLPI; não recalcula calendários, feriados ou pausas a partir de horas fixas. |
| Prazo ausente | O chamado permanece no detalhamento e não é aprovado automaticamente. Fica fora da fração de cumprimento; o indicador é provisório se houver prazos válidos e pendente se faltarem todos. |
| INS5 | Usa a união dos chamados com transição registrada de solucionado/fechado para estado ativo e dos IDs de execução incompleta informados manualmente, sem duplicidade. Os IDs manuais devem pertencer ao recorte. Recusa de solução é evidência distinta. |
| INS6 | A população elegível vem das categorias N1. O critério inicial é ausência de grupo N2 atribuído; também é possível exigir grupo N1. Ambos usam vínculos atuais, sem afirmar que representam todo o histórico de escalonamento. |
| INS7–INS9 | INS7 considera conversação até 600 segundos; INS8, espera até conexão de até 30 segundos; INS9, abandono sem atendimento após mais de 30 segundos. O denominador é o total recebido após excluir testes, inclusive abandonadas. TMA/TME individuais são durações; suas médias são diferentes desses percentuais. |
| INS10 | Informe total de profissionais, substituições nos três meses encerrados no mês de referência e exclusões determinadas pela contratante. Campos ausentes deixam a apuração pendente; o GLPI não fornece os dados de pessoal. |
| INS11 | O padrão exige vínculo direto do chamado a um artigo da lista previamente validada. Sem a lista ou sem acesso aos vínculos, fica pendente. A opção por categoria reproduz a aproximação do painel e é identificada como provisória. |
| INS12 | Usa pesquisas GLPI respondidas na escala 1–5, com notas 4 e 5 favoráveis. Não converte automaticamente para a escala contratual 0–10. |

Ausência de população elegível resulta em **não aplicável**, sem divisão por zero. Evidências indisponíveis são indicadas como pendentes ou provisórias. Justificativas e ações podem ser registradas nos campos narrativos; glosas e ajustes financeiros não são calculados automaticamente.

## Compatibilidade da configuração

A versão 1.8.0 usa um template de configuração com nome próprio da versão, fixado no diretório do código carregado. Isso evita reutilizar o formulário antigo em cenários de cache de templates ou resolução de outra pasta. O campo oculto `config_class` agora recebe a classe PHP diretamente, garantindo que a gravação nativa chame o tratamento das configurações.

Esses problemas foram reproduzidos/verificados localmente. A causa exata de uma instalação que ainda mostra a tela antiga depende dos arquivos efetivamente carregados; o diagnóstico foi incluído para identificá-los. Os testes locais não substituem o teste de conectividade e a conferência dos resultados no ambiente GLPI de destino.

## Relatórios por profissional — API

O fluxo anterior continua disponível pelo botão **Relatórios por profissional**, na área SES, ou pela tela principal do plugin. Configure o perfil da API, salve e use **Testar conexão padrão**. A extração mantém contextos, filtros, processamento em lotes, rascunho editável e exportação DOCX com identidade G4F.

## Contextos do relatório

O usuário pode marcar múltiplos contextos ao mesmo tempo:

- Chamados atribuídos ao agente.
- Chamados solicitados pelo agente.
- Chamados atribuídos aos grupos selecionados explicitamente.
- Tarefas de chamado feitas pelo agente.
- Acompanhamentos feitos pelo agente.
- Soluções registradas pelo agente.
- Projetos gerenciados pelo agente.
- Projetos gerenciados pelos grupos selecionados explicitamente.
- Projetos em que o agente participa.
- Tarefas de projeto do agente.
- Tarefas de projeto dos grupos selecionados explicitamente.
- Entradas narrativas manuais.

## Análises selecionáveis

As análises são calculadas a partir do rascunho já extraído, sem criar uma segunda varredura independente na API:

- Resumo por dia.
- Distribuição por status.
- Origem das atividades.
- Agente x grupos selecionados.
- Top categorias.
- Localização dos chamados.
- Tempo médio de resposta.
- Tempo de primeira resposta.
- Eventos do solicitante sem resposta técnica.
- Tabela consolidada de indicadores.

As visualizações exportadas para DOCX são tabelas/gráficos editáveis em Word, sem imagens geradas dinamicamente.

