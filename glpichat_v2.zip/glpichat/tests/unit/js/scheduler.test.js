import { describe, expect, it, vi } from "vitest";
import {
  createCoalescedSingleFlight,
  hasOpenChatTickets,
} from "../../../src/js/modules/scheduler.js";

const deferred = () => {
  let resolve;
  let reject;
  const promise = new Promise((resolvePromise, rejectPromise) => {
    resolve = resolvePromise;
    reject = rejectPromise;
  });

  return { promise, resolve, reject };
};

describe("Chat background scheduler", () => {
  it("admits Poll only when at least one ticket chat is open", () => {
    expect(hasOpenChatTickets([])).toBe(false);
    expect(hasOpenChatTickets(null)).toBe(false);
    expect(hasOpenChatTickets([42])).toBe(true);
  });

  it("coalesces concurrent calls into one active run and one successor", async () => {
    const firstRun = deferred();
    const secondRun = deferred();
    const operation = vi
      .fn()
      .mockImplementationOnce(() => firstRun.promise)
      .mockImplementationOnce(() => secondRun.promise);
    const run = createCoalescedSingleFlight(operation);

    const firstPromise = run();
    const concurrentPromise = run();
    const anotherConcurrentPromise = run();

    expect(concurrentPromise).toBe(firstPromise);
    expect(anotherConcurrentPromise).toBe(firstPromise);
    expect(operation).toHaveBeenCalledTimes(1);

    firstRun.resolve("first");
    await vi.waitFor(() => {
      expect(operation).toHaveBeenCalledTimes(2);
    });

    secondRun.resolve("second");
    await expect(firstPromise).resolves.toBe("second");
    expect(operation).toHaveBeenCalledTimes(2);
  });

  it("does not extend the same invocation when calls continue during the successor", async () => {
    const firstRun = deferred();
    const successorRun = deferred();
    const operation = vi
      .fn()
      .mockImplementationOnce(() => firstRun.promise)
      .mockImplementationOnce(() => successorRun.promise)
      .mockResolvedValueOnce("new invocation");
    const run = createCoalescedSingleFlight(operation);

    const activePromise = run();
    for (let index = 0; index < 100; index += 1) {
      expect(run()).toBe(activePromise);
    }
    expect(operation).toHaveBeenCalledTimes(1);

    firstRun.resolve("first");
    await vi.waitFor(() => {
      expect(operation).toHaveBeenCalledTimes(2);
    });

    for (let index = 0; index < 100; index += 1) {
      expect(run()).toBe(activePromise);
    }
    successorRun.resolve("successor");

    await expect(activePromise).resolves.toBe("successor");
    expect(operation).toHaveBeenCalledTimes(2);

    await expect(run()).resolves.toBe("new invocation");
    expect(operation).toHaveBeenCalledTimes(3);
  });

  it("resets after failure so the next call can retry", async () => {
    const operation = vi
      .fn()
      .mockRejectedValueOnce(new Error("temporary failure"))
      .mockResolvedValueOnce("recovered");
    const run = createCoalescedSingleFlight(operation);

    await expect(run()).rejects.toThrow("temporary failure");
    await expect(run()).resolves.toBe("recovered");
    expect(operation).toHaveBeenCalledTimes(2);
  });

  it("rejects an invalid operation at construction time", () => {
    expect(() => createCoalescedSingleFlight(null)).toThrow(TypeError);
  });
});
