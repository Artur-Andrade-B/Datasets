import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = resolve(import.meta.dirname, "../../..");
const readText = (relativePath) => readFileSync(resolve(root, relativePath), "utf8");

describe("perf1 release metadata", () => {
  it("keeps plugin, catalogue, package and manifest versions aligned", () => {
    const setup = readText("setup.php");
    const pluginXml = readText("plugin.xml");
    const packageJson = JSON.parse(readText("package.json"));
    const packageLock = JSON.parse(readText("package-lock.json"));
    const manifest = JSON.parse(readText("release-manifest.json"));

    expect(setup).toContain("define('PLUGIN_GLPICHAT_VERSION', '1.0.2');");
    expect(setup).toContain("define('PLUGIN_GLPICHAT_BUILD', 'perf1');");
    expect(pluginXml).toContain("<num>1.0.2</num>");
    expect(packageJson.version).toBe("1.0.2");
    expect(packageLock.version).toBe("1.0.2");
    expect(packageLock.packages[""].version).toBe("1.0.2");
    expect(manifest).toMatchObject({
      plugin: "glpichat",
      version: "1.0.2",
      build: "perf1",
      package_kind: "laboratory_candidate",
      browser_surface_default_enabled: false,
      external_desktop_api_included: false,
      runtime_dependencies_added: [],
    });
  });
});
