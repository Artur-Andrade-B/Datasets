/**
 * Return whether the browser currently has at least one open Chat ticket.
 *
 * Kept as a small pure helper so the idle-poll admission rule can be tested
 * without bootstrapping the complete GLPI widget DOM.
 */
export const hasOpenChatTickets = (openTicketIds) => (
  Array.isArray(openTicketIds) && openTicketIds.length > 0
);

/**
 * Run an asynchronous operation with one active execution and at most one
 * coalesced successor. Calls made while work is active share the same promise;
 * they request a single follow-up pass instead of creating an unbounded queue.
 *
 * This deliberately does not add deadlines, cancellation or request priority.
 * The caller retains the baseline error and ordering semantics.
 */
export const createCoalescedSingleFlight = (operation) => {
  if (typeof operation !== "function") {
    throw new TypeError("A single-flight operation function is required.");
  }

  let activePromise = null;
  let successorRequested = false;
  let successorCommitted = false;

  return () => {
    if (activePromise !== null) {
      // One call arriving during the first run requests one successor. Calls
      // arriving after that successor has been committed (including while it
      // is running) are represented by the same successor and cannot extend
      // this promise into an unbounded chain.
      if (!successorCommitted) {
        successorRequested = true;
      }
      return activePromise;
    }

    activePromise = (async () => {
      try {
        let result = await operation();

        if (successorRequested) {
          successorRequested = false;
          successorCommitted = true;
          result = await operation();
        }

        return result;
      } finally {
        activePromise = null;
        successorRequested = false;
        successorCommitted = false;
      }
    })();

    return activePromise;
  };
};
