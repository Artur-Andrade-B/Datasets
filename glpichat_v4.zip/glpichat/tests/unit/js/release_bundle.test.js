// @vitest-environment node

import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { build } from "esbuild";
import { describe, expect, it } from "vitest";

const root = resolve(import.meta.dirname, "../../..");

const buildOne = async (entryPoint) => {
  const result = await build({
    absWorkingDir: root,
    entryPoints: [entryPoint],
    bundle: true,
    minify: true,
    write: false,
  });

  return Buffer.from(result.outputFiles[0].contents);
};

describe("release browser artifacts", () => {
  it("ships the exact Widget bundle generated from current source", async () => {
    const [expected, shipped] = await Promise.all([
      buildOne("src/js/glpichat-widget.js"),
      readFile(resolve(root, "public/js/glpichat-widget.js")),
    ]);

    expect(shipped.equals(expected)).toBe(true);
  });

  it("keeps the Guest bundle reproducible from unchanged source", async () => {
    const [expected, shipped] = await Promise.all([
      buildOne("src/js/glpichat-guest.js"),
      readFile(resolve(root, "public/js/glpichat-guest.js")),
    ]);

    expect(shipped.equals(expected)).toBe(true);
  });
});
