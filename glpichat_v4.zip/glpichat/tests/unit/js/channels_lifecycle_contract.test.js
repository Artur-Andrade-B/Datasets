import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = resolve(import.meta.dirname, "../../..");
const widget = readFileSync(resolve(root, "src/js/glpichat-widget.js"), "utf8");

describe("perf3 Channels lifecycle contracts", () => {
  it("models discovery separately from a successful empty result", () => {
    expect(widget).toContain('channelsDiscoveryState: "loading"');
    expect(widget).toContain('setChannelsDiscoveryState("slow"');
    expect(widget).toContain('setChannelsDiscoveryState("retry_wait"');
    expect(widget).toContain('setChannelsDiscoveryState("failed"');
    expect(widget).toContain('setChannelsDiscoveryState("ready"');

    const renderStart = widget.indexOf("const renderLauncherNotifications");
    const falseEmptyGuard = widget.indexOf('state.channelsDiscoveryState !== "ready"', renderStart);
    const emptyCopy = widget.indexOf("Nenhum chamado em", renderStart);
    expect(falseEmptyGuard).toBeGreaterThan(renderStart);
    expect(emptyCopy).toBeGreaterThan(falseEmptyGuard);
    expect(widget).toContain("Carregando conversas...");
  });

  it("gates every recurring timer until the Channels runtime is ready", () => {
    const scheduleStart = widget.indexOf("const schedulePolling");
    const bootstrapStart = widget.indexOf("const bootstrap", scheduleStart);
    const scheduleBlock = widget.slice(scheduleStart, bootstrapStart);

    expect(scheduleBlock).toContain("!state.runtimeReady || automaticReadsBlocked()");
    expect(widget).toContain("if (state.runtimeReady && state.activeTicketId > 0)");
    expect(widget).toContain("if (state.runtimeReady) {\n        minimizeAll();");
  });

  it("uses one exact Channels flight for startup, metadata and retry", () => {
    expect(widget).toContain("const requestChannels = createExactSingleFlight(performChannelsRequest)");
    expect(widget).toContain('requestChannels("startup", "initial")');
    expect(widget).toContain('requestChannels("metadata", "periodic")');
    expect(widget).toContain('requestChannels(mode, "retry")');
    expect(widget).toContain('onStart: (diagnostic) =>');
    expect(widget).toContain('phase: "active"');

    const channelsStart = widget.indexOf("const channelsFailureDetails");
    const pollStart = widget.indexOf("const pollChannelsOnce", channelsStart);
    const channelsBlock = widget.slice(channelsStart, pollStart);
    expect(channelsBlock).not.toContain("createCoalescedSingleFlight");
  });

  it("keeps loaded tickets visible when a metadata refresh is delayed", () => {
    expect(widget).toContain("state.channelsRefreshDelayed = true");
    expect(widget).toContain("As conversas já carregadas continuam disponíveis.");
    expect(widget).toContain("Tentar atualizar");
    expect(widget).toContain("Nova tentativa em ~");
    expect(widget).toContain("Nova tentativa aguardando");
    expect(widget).toContain("Tentar novamente");
    expect(widget).not.toContain("state.tickets.clear()");
  });

  it("sequences Config only after a successful Channels result", () => {
    const bootstrapStart = widget.indexOf("const bootstrap");
    const bootstrapEnd = widget.indexOf("const bootWidget", bootstrapStart);
    const bootstrapBlock = widget.slice(bootstrapStart, bootstrapEnd);
    const completionStart = widget.indexOf("const completeRuntimeStartup");
    const completionEnd = widget.indexOf("const handleWidgetVisibilityChange", completionStart);
    const completionBlock = widget.slice(completionStart, completionEnd);

    expect(bootstrapBlock).not.toContain("Promise.all");
    expect(bootstrapBlock).not.toContain("/Widget/Config");
    expect(completionBlock).toContain("/Widget/Config");
    expect(completionBlock).toContain("configData = {}");
  });

  it("claims one page-global widget root", () => {
    expect(widget).toContain('const WIDGET_MOUNT_KEY = "__glpichatWidgetMounted"');
    expect(widget).toContain("const ownsWidgetRuntime = window[WIDGET_MOUNT_KEY] !== true");
    expect(widget).toContain('document.querySelector(".glpichat-widget")');
    expect(widget).toContain('root.dataset.glpichatRoot = "1"');
    expect(widget).toContain("if (ownsWidgetRuntime) {\n    if (document.readyState");
  });

  it("does not allow a manual post-timeout retry to bypass its cooldown", () => {
    const retryStart = widget.indexOf("const retryChannelsNow");
    const retryEnd = widget.indexOf("const syncChannelMetadata", retryStart);
    const retryBlock = widget.slice(retryStart, retryEnd);

    expect(retryBlock).toContain("Date.now() < state.channelsRetryAt");
    expect(retryBlock).toContain('status: "cooldown"');
    expect(retryBlock).toContain('status: "busy"');
  });

  it("defers retry admission behind History and mutations", () => {
    const armStart = widget.indexOf("const armChannelsRetry");
    const armEnd = widget.indexOf("const scheduleChannelsRetry", armStart);
    const armBlock = widget.slice(armStart, armEnd);

    expect(armBlock).toContain("state.pendingMutations > 0");
    expect(armBlock).toContain("automaticReadsBlocked()");
    expect(widget).toContain("if (state.pendingMutations === 0) {\n          armChannelsRetry();");
  });

  it("treats a periodic queue expiry as a stale tick, not a permanent block", () => {
    expect(widget).toContain('failure.kind !== "queue_expired"');
    expect(widget).toContain('maxQueueWaitMs: source === "periodic"');
  });

  it("opts into detailed Channels phases only outside periodic metadata", () => {
    expect(widget).toContain('source === "periodic"\n          ? {}\n          : { "X-Glpichat-Diagnostic-Level": "phases" }');
  });

  it("gates invite reads and timers until Config sequencing completes", () => {
    const mountStart = widget.indexOf("const mountInviteManagement");
    const mountEnd = widget.indexOf("const markRead", mountStart);
    const mountBlock = widget.slice(mountStart, mountEnd);

    expect(widget).toContain("if (!state.runtimeReady || !targetContainer)");
    expect(mountBlock).toContain("await runtimeReadyPromise");
    expect(mountBlock).toContain("!state.runtimeReady || document.hidden");
  });

  it("shows explicit History loading text from the first skeleton render", () => {
    expect(widget).toContain("Carregando histórico...");
  });
});
