import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = resolve(import.meta.dirname, "../../..");
const readText = (relativePath) => readFileSync(resolve(root, relativePath), "utf8");

describe("perf2 hydration safety contracts", () => {
  it("does not abort active requests or hide History failure behind Poll", () => {
    const http = readText("src/js/modules/widget-http.js");
    const widget = readText("src/js/glpichat-widget.js");
    const historyStart = widget.indexOf("const loadChannelHistoryOnce");
    const historyEnd = widget.indexOf("const loadOlderMessages", historyStart);
    const historyBlock = widget.slice(historyStart, historyEnd);

    expect(http).not.toContain("AbortController");
    expect(historyBlock).toContain("/Widget/History");
    expect(historyBlock).not.toContain("/Widget/Poll");
    expect(historyBlock).toContain("history_failed = true");
  });

  it("never converts an empty incremental Poll payload into Channels discovery", () => {
    const widget = readText("src/js/glpichat-widget.js");
    expect(widget).toMatch(/if \(payload\.length === 0\) \{\s*return;\s*\}/);
  });

  it("preserves canonical channel identity during metadata refresh", () => {
    const widget = readText("src/js/glpichat-widget.js");
    const setChannelStart = widget.indexOf("const setChannel");
    const setChannelEnd = widget.indexOf("const hasBlockedOpenHistory", setChannelStart);
    const setChannelBlock = widget.slice(setChannelStart, setChannelEnd);

    expect(setChannelBlock).toContain("mergeChannelMetadata(existing, payload)");
    expect(setChannelBlock).not.toContain("...prev");
    expect(setChannelBlock).not.toContain("history_loading: false");
  });

  it("pauses recurring browser work while hydration is pending or failed", () => {
    const widget = readText("src/js/glpichat-widget.js");
    expect(widget).toContain("hasBlockedOpenHistory()");
    expect(widget).toMatch(/if \(automaticReadsBlocked\(\)\) \{\s*return;\s*\}/);
    expect(widget).toContain("As atualizações automáticas desta página foram pausadas");
    expect(widget).toContain("document.hidden || !isVisible || automaticReadsBlocked()");
    expect(widget).toContain("channel.messages_loaded !== true");
    expect(widget).toContain("if (!hydrationResult?.ok)");
  });

  it("rejects incomplete History payloads instead of displaying a false empty chat", () => {
    const widget = readText("src/js/glpichat-widget.js");

    expect(widget).toContain("!Array.isArray(data.messages) || !Array.isArray(data.events)");
    expect(widget).toContain('kind: "invalid_payload"');
  });

  it("does not commit an old-room response into refreshed channel metadata", () => {
    const widget = readText("src/js/glpichat-widget.js");

    expect(widget).toContain("const requestedRoomsId = Number(channel.rooms_id || 0)");
    expect(widget).toContain("Number(channel.rooms_id || 0) !== requestedRoomsId");
    expect(widget).toContain('kind: "room_changed"');
    expect(widget).toContain('{ kind: "missing_room" }');
  });

  it("restarts scheduling when minimize-all removes the blocked open room", () => {
    const widget = readText("src/js/glpichat-widget.js");
    const start = widget.indexOf("const minimizeAll");
    const end = widget.indexOf("const restoreMinimizedSnapshot", start);
    const block = widget.slice(start, end);

    expect(block).toContain("state.openTicketIds = []");
    expect(block).toContain("schedulePolling()");
  });

  it("keeps an inactive-room failure visible and requires explicit retry", () => {
    const widget = readText("src/js/glpichat-widget.js");

    expect(widget).toContain('btn.classList.add("has-history-error")');
    expect(widget).toContain('failureMarker.textContent = "!"');
    expect(widget).toContain("if (activeChannel?.history_failed === true)");
    expect(widget).toContain("const isActiveRoom = ticket?.activeTab === channel.room_type");
  });

  it("blocks every open composer while any open room is hydrating or failed", () => {
    const widget = readText("src/js/glpichat-widget.js");

    expect(widget).toContain("const hydrationBlocked = automaticReadsBlocked()");
    expect(widget).toContain("|| automaticReadsBlocked()");
    expect(widget).toContain("const refreshOpenComposerStates = () =>");
  });

  it("keeps automatic reads paused after a pending History room is minimized", () => {
    const widget = readText("src/js/glpichat-widget.js");

    expect(widget).toContain("let activeHistoryRequests = 0");
    expect(widget).toContain("activeHistoryRequests > 0 || hasBlockedOpenHistory()");
    expect(widget).toContain("activeHistoryRequests = Math.max(0, activeHistoryRequests - 1)");
  });
});
