<?php

declare(strict_types=1);

require dirname(__DIR__, 2) . '/bootstrap/unit.php';
require_once dirname(__DIR__, 3) . '/src/diagnostics.php';

$lines = [];
$started_at = glpichat_diagnostic_started_at();
glpichat_diagnostic_log(
    'widget_history',
    'runtime_error',
    'trace12345678',
    $started_at,
    [
        'messages' => 3,
        'events' => 2,
        'http_status' => 500,
        'outcome' => 'runtime_error',
        'exception_class' => RuntimeException::class,
        'exception_code' => 'HY000',
        'users_id' => 99123,
        'tickets_id' => 88123,
        'rooms_id' => 77123,
        'message_content' => 'private-message-marker',
        'email' => 'private.user@example.invalid',
        'csrf' => 'csrf-secret-marker',
        'exception_message' => 'raw-database-error-marker',
    ],
    static function (string $line) use (&$lines): void {
        $lines[] = $line;
    }
);

glpichat_unit_assert_same(1, count($lines), 'Diagnostics emits exactly one record');
$record = json_decode($lines[0], true, 512, JSON_THROW_ON_ERROR);
glpichat_unit_assert_same('widget_history', $record['operation'], 'Diagnostics keeps allowlisted operation');
glpichat_unit_assert_same('runtime_error', $record['phase'], 'Diagnostics keeps allowlisted phase');
glpichat_unit_assert_same('trace12345678', $record['trace'], 'Diagnostics keeps safe opaque trace');
glpichat_unit_assert_same(3, $record['messages'], 'Diagnostics keeps safe message count');
glpichat_unit_assert_same(2, $record['events'], 'Diagnostics keeps safe event count');
glpichat_unit_assert_same(500, $record['http_status'], 'Diagnostics keeps HTTP category');
glpichat_unit_pass('Diagnostics retains the closed safe schema');

$serialized = $lines[0];
foreach ([
    '99123',
    '88123',
    '77123',
    'private-message-marker',
    'private.user@example.invalid',
    'csrf-secret-marker',
    'raw-database-error-marker',
] as $forbidden) {
    if (str_contains($serialized, $forbidden)) {
        glpichat_unit_fail('Diagnostics leaked forbidden value: ' . $forbidden);
    }
}
glpichat_unit_pass('Diagnostics omits IDs, content, identity, secrets and raw exception text');

$invalid_trace = glpichat_diagnostic_trace_id("bad\nheader");
if (preg_match('/\A[a-f0-9]{16}\z/', $invalid_trace) !== 1) {
    glpichat_unit_fail('Invalid trace input must be replaced with an opaque hexadecimal value.');
}
glpichat_unit_pass('Diagnostics replaces unsafe trace input');

$channel_lines = [];
glpichat_diagnostic_log(
    'widget_channels',
    'authorization',
    'channeltrace1234',
    $started_at,
    [
        'candidate_rows' => 320,
        'candidates' => 240,
        'authorized_tickets' => 40,
        'denied_tickets' => 3,
        'source_limit' => 240,
        'source_truncated' => true,
        'output_truncated' => true,
        'focused_ticket' => true,
        'last_phase' => 'authorization',
        'candidate_ticket_ids' => [123456, 234567],
        'group_ids' => [987654],
    ],
    static function (string $line) use (&$channel_lines): void {
        $channel_lines[] = $line;
    }
);
$channel_record = json_decode($channel_lines[0], true, 512, JSON_THROW_ON_ERROR);
glpichat_unit_assert_same('authorization', $channel_record['phase'], 'Channels diagnostics keeps bounded authorization phase');
glpichat_unit_assert_same(240, $channel_record['candidates'], 'Channels diagnostics keeps candidate count');
glpichat_unit_assert_same(40, $channel_record['authorized_tickets'], 'Channels diagnostics keeps authorized count');
glpichat_unit_assert_same(true, $channel_record['source_truncated'], 'Channels diagnostics keeps source truncation flag');
glpichat_unit_assert_same(true, $channel_record['output_truncated'], 'Channels diagnostics keeps output truncation flag');
glpichat_unit_assert_same('authorization', $channel_record['last_phase'], 'Channels aggregate keeps only an allowlisted last phase');
foreach (['123456', '234567', '987654', 'candidate_ticket_ids', 'group_ids'] as $forbidden) {
    if (str_contains($channel_lines[0], $forbidden)) {
        glpichat_unit_fail('Channels diagnostics leaked forbidden candidate identity: ' . $forbidden);
    }
}
glpichat_unit_pass('Channels phase diagnostics exposes counts but no ticket/group identities');

$config_lines = [];
glpichat_diagnostic_log(
    'widget_config',
    'config_ready',
    'configtrace12345',
    $started_at,
    [],
    static function (string $line) use (&$config_lines): void {
        $config_lines[] = $line;
    }
);
$config_record = json_decode($config_lines[0], true, 512, JSON_THROW_ON_ERROR);
glpichat_unit_assert_same('widget_config', $config_record['operation'], 'Widget Config is an allowlisted diagnostic operation');
glpichat_unit_assert_same('config_ready', $config_record['phase'], 'Widget Config has an explicit post-release read phase');

// A failing sink represents a filesystem/logger failure and must be swallowed.
glpichat_diagnostic_log(
    'widget_history',
    'complete',
    'trace12345678',
    $started_at,
    ['outcome' => 'ok'],
    static function (string $line): void {
        throw new RuntimeException('simulated logger failure');
    }
);
glpichat_unit_pass('Diagnostics failure cannot break endpoint execution');

fwrite(STDOUT, "[PASS] Diagnostics privacy unit tests completed\n");
