<?php

declare(strict_types=1);

use Glpi\DBAL\QueryExpression;
use Glpi\DBAL\QueryFunction;

function glpichat_readstate_last_message_id(int $rooms_id, int $participants_id): int
{
    global $DB;

    $readstate = $DB->request([
        'FROM' => 'glpi_plugin_glpichat_readstates',
        'WHERE' => [
            'rooms_id' => $rooms_id,
            'participants_id' => $participants_id,
        ],
        'LIMIT' => 1,
    ])->current();

    return is_array($readstate) ? (int) $readstate['last_read_messages_id'] : 0;
}

function glpichat_participant_for_readstate(int $rooms_id, int $participants_id): array
{
    global $DB;

    $participant = $DB->request([
        'SELECT' => ['id', 'rooms_id', 'participant_type', 'users_id'],
        'FROM' => 'glpi_plugin_glpichat_participants',
        'WHERE' => [
            'id' => $participants_id,
            'rooms_id' => $rooms_id,
            'left_at' => null,
        ],
        'LIMIT' => 1,
    ])->current();

    return glpichat_assert_valid_readstate_participant(is_array($participant) ? $participant : null);
}

function glpichat_unread_count_for_participant(int $rooms_id, int $participants_id): int
{
    global $DB;

    if ($participants_id <= 0) {
        return 0;
    }

    $participant = glpichat_participant_for_readstate($rooms_id, $participants_id);
    $last_read_messages_id = glpichat_readstate_last_message_id($rooms_id, $participants_id);

    $row = $DB->request([
        'COUNT' => 'cpt',
        'FROM' => 'glpi_plugin_glpichat_messages',
        'WHERE' => glpichat_unread_where_for_participant($participant, $last_read_messages_id),
    ])->current();

    return (int) ($row['cpt'] ?? 0);
}

function glpichat_assert_message_belongs_to_room(int $rooms_id, int $messages_id): void
{
    global $DB;

    if ($messages_id === 0) {
        return;
    }

    $message = $DB->request([
        'SELECT' => ['id'],
        'FROM' => 'glpi_plugin_glpichat_messages',
        'WHERE' => [
            'id' => $messages_id,
            'rooms_id' => $rooms_id,
        ],
        'LIMIT' => 1,
    ])->current();

    if (!is_array($message)) {
        throw new RuntimeException('Read marker message does not belong to this chat room.');
    }
}

function glpichat_mark_read(int $rooms_id, int $participants_id, int $last_read_messages_id): int
{
    global $DB;

    if ($participants_id <= 0) {
        throw new RuntimeException('Invalid chat participant.');
    }

    glpichat_participant_for_readstate($rooms_id, $participants_id);
    glpichat_assert_message_belongs_to_room($rooms_id, $last_read_messages_id);

    $existing = $DB->request([
        'FROM' => 'glpi_plugin_glpichat_readstates',
        'WHERE' => [
            'rooms_id' => $rooms_id,
            'participants_id' => $participants_id,
        ],
        'LIMIT' => 1,
    ])->current();

    $requested_last_read_messages_id = max(0, $last_read_messages_id);
    $date_mod = $_SESSION['glpi_currenttime'] ?? date('Y-m-d H:i:s');

    if (!is_array($existing)) {
        $payload = glpichat_readstate_insert_payload(
            $rooms_id,
            $participants_id,
            $requested_last_read_messages_id,
            $date_mod
        );
        $inserted = false;
        try {
            $inserted = (bool) $DB->insert('glpi_plugin_glpichat_readstates', $payload);
        } catch (\Throwable $insert_error) {
            // The unique (rooms_id, participants_id) row may have been created
            // after our initial SELECT. Confirm that race below before rethrowing.
        }

        if (!$inserted) {
            $existing = $DB->request([
                'SELECT' => ['id'],
                'FROM' => 'glpi_plugin_glpichat_readstates',
                'WHERE' => [
                    'rooms_id' => $rooms_id,
                    'participants_id' => $participants_id,
                ],
                'LIMIT' => 1,
            ])->current();
            if (!is_array($existing)) {
                if (isset($insert_error)) {
                    throw $insert_error;
                }
                throw new RuntimeException('Unable to create chat read state.');
            }
        }
    }

    // Perform the monotonic cursor transition inside one SQL UPDATE. PHP-side
    // max(current, requested) is insufficient once same-session tabs can overlap
    // after the session lock is released.
    $updated = $DB->update('glpi_plugin_glpichat_readstates', [
        'last_read_messages_id' => new QueryExpression(sprintf(
            'GREATEST(`last_read_messages_id`, %d)',
            $requested_last_read_messages_id
        )),
        'date_mod' => $date_mod,
    ], [
        'rooms_id' => $rooms_id,
        'participants_id' => $participants_id,
    ]);
    if (!$updated) {
        throw new RuntimeException('Unable to update chat read state.');
    }

    $persisted = $DB->request([
        'SELECT' => ['last_read_messages_id'],
        'FROM' => 'glpi_plugin_glpichat_readstates',
        'WHERE' => [
            'rooms_id' => $rooms_id,
            'participants_id' => $participants_id,
        ],
        'LIMIT' => 1,
    ])->current();
    if (!is_array($persisted)) {
        throw new RuntimeException('Unable to read persisted chat state.');
    }

    return (int) ($persisted['last_read_messages_id'] ?? 0);
}

function glpichat_unread_count(int $rooms_id, int $participants_id): int
{
    return glpichat_unread_count_for_participant($rooms_id, $participants_id);
}

/**
 * Discover the bounded set of channels visible to one authenticated user.
 *
 * Generic discovery deliberately considers only active ticket statuses. A
 * focused ticket is evaluated independently so a ticket page can still open
 * the chat for a solved/closed ticket. Candidate and output bounds are applied
 * before any room/message/participant/read-state enrichment.
 *
 * @param array{
 *     can_read_public_room?:bool,
 *     can_read_internal_room?:bool,
 *     groups_ids?:list<int>
 * } $access_snapshot
 * @param null|callable(string, array<string, int|bool>):void $phase_logger
 * @return list<array<string, int|string>>
 */
function glpichat_list_user_channels(
    int $users_id,
    int $focus_tickets_id,
    array $access_snapshot = [],
    ?callable $phase_logger = null
): array {
    global $DB;

    $channel_limit = 80;
    $source_limit = 240;
    $active_statuses = [1, 2, 3, 4];
    $actor_types = [
        CommonITILActor::REQUESTER,
        CommonITILActor::ASSIGN,
        CommonITILActor::OBSERVER,
    ];

    $log_phase = static function (string $phase, array $metrics = []) use ($phase_logger): void {
        if ($phase_logger === null) {
            return;
        }

        try {
            $phase_logger($phase, $metrics);
        } catch (\Throwable $e) {
            // Diagnostic callbacks are observational and cannot break discovery.
        }
    };
    $log_empty_enrichment = static function () use ($log_phase): void {
        $log_phase('rooms', ['rooms' => 0, 'rooms_created' => 0]);
        $log_phase('message_heads', ['message_heads' => 0]);
        $log_phase('participants', ['participants' => 0]);
        $log_phase('readstates', ['readstates' => 0]);
        $log_phase('unread', ['unread_queries' => 0, 'channels' => 0]);
    };

    // These values are normally captured by WidgetController before the PHP
    // session is released. The fallback preserves direct helper/test callers.
    $can_read_public_room = array_key_exists('can_read_public_room', $access_snapshot)
        ? (bool) $access_snapshot['can_read_public_room']
        : (bool) Session::haveRight('plugin_glpichat_public', READ);
    $can_read_internal_room = array_key_exists('can_read_internal_room', $access_snapshot)
        ? (bool) $access_snapshot['can_read_internal_room']
        : (bool) Session::haveRight('plugin_glpichat_internal', READ);
    $raw_groups_ids = $access_snapshot['groups_ids'] ?? ($_SESSION['glpigroups'] ?? []);
    $groups_ids = array_values(array_unique(array_filter(
        array_map(static fn ($id): int => (int) $id, is_array($raw_groups_ids) ? $raw_groups_ids : []),
        static fn (int $id): bool => $id > 0
    )));

    $direct_links = [];
    $direct_source_truncated = false;
    $user_links = $DB->request([
        'SELECT' => ['glpi_tickets_users.tickets_id AS tickets_id'],
        'FROM' => 'glpi_tickets_users',
        'INNER JOIN' => [
            'glpi_tickets' => [
                'ON' => [
                    'glpi_tickets_users' => 'tickets_id',
                    'glpi_tickets' => 'id',
                ],
            ],
        ],
        'WHERE' => [
            'glpi_tickets_users.users_id' => $users_id,
            'glpi_tickets_users.type' => $actor_types,
            'glpi_tickets.status' => $active_statuses,
        ],
        'GROUPBY' => 'glpi_tickets_users.tickets_id',
        'ORDER' => ['glpi_tickets_users.tickets_id DESC'],
        'LIMIT' => $source_limit + 1,
    ]);
    foreach ($user_links as $link) {
        $tickets_id = (int) ($link['tickets_id'] ?? 0);
        if ($tickets_id <= 0) {
            continue;
        }
        if (count($direct_links) >= $source_limit) {
            $direct_source_truncated = true;
            break;
        }
        $direct_links[$tickets_id] = true;
    }
    $log_phase('direct_links', [
        'direct_links' => count($direct_links),
        'source_limit' => $source_limit,
        'source_truncated' => $direct_source_truncated,
    ]);

    $group_links_by_ticket = [];
    $group_source_truncated = false;
    if (count($groups_ids) > 0) {
        $group_links = $DB->request([
            'SELECT' => ['glpi_groups_tickets.tickets_id AS tickets_id'],
            'FROM' => 'glpi_groups_tickets',
            'INNER JOIN' => [
                'glpi_tickets' => [
                    'ON' => [
                        'glpi_groups_tickets' => 'tickets_id',
                        'glpi_tickets' => 'id',
                    ],
                ],
            ],
            'WHERE' => [
                'glpi_groups_tickets.groups_id' => $groups_ids,
                'glpi_groups_tickets.type' => $actor_types,
                'glpi_tickets.status' => $active_statuses,
            ],
            'GROUPBY' => 'glpi_groups_tickets.tickets_id',
            'ORDER' => ['glpi_groups_tickets.tickets_id DESC'],
            'LIMIT' => $source_limit + 1,
        ]);
        foreach ($group_links as $link) {
            $tickets_id = (int) ($link['tickets_id'] ?? 0);
            if ($tickets_id <= 0) {
                continue;
            }
            if (count($group_links_by_ticket) >= $source_limit) {
                $group_source_truncated = true;
                break;
            }
            $group_links_by_ticket[$tickets_id] = true;
        }
    }
    $log_phase('group_links', [
        'group_links' => count($group_links_by_ticket),
        'source_limit' => $source_limit,
        'source_truncated' => $group_source_truncated,
    ]);

    $generic_candidates = $direct_links + $group_links_by_ticket;
    krsort($generic_candidates, SORT_NUMERIC);
    $merged_source_truncated = count($generic_candidates) > $source_limit;
    if ($merged_source_truncated) {
        $generic_candidates = array_slice($generic_candidates, 0, $source_limit, true);
    }
    $source_truncated = $direct_source_truncated
        || $group_source_truncated
        || $merged_source_truncated;
    $log_phase('candidates', [
        'candidate_rows' => count($direct_links) + count($group_links_by_ticket),
        'candidates' => count($generic_candidates)
            + ($focus_tickets_id > 0 && !isset($generic_candidates[$focus_tickets_id]) ? 1 : 0),
        'source_limit' => $source_limit,
        'source_truncated' => $source_truncated,
        'focused_ticket' => $focus_tickets_id > 0,
    ]);

    $allowed_room_types = [];
    if ($can_read_public_room) {
        $allowed_room_types[] = GLPICHAT_ROOM_PUBLIC;
    }
    if ($can_read_internal_room) {
        $allowed_room_types[] = GLPICHAT_ROOM_INTERNAL;
    }
    if (count($allowed_room_types) === 0) {
        $log_phase('authorization', [
            'authorized_tickets' => 0,
            'denied_tickets' => 0,
            'output_truncated' => false,
        ]);
        $log_empty_enrichment();
        return [];
    }

    $ticket_can_read_by_id = [];
    $ticket_can_read = static function (int $tickets_id) use (&$ticket_can_read_by_id): bool {
        if (!array_key_exists($tickets_id, $ticket_can_read_by_id)) {
            $ticket = glpichat_ticket_or_fail($tickets_id);
            $ticket_can_read_by_id[$tickets_id] = (bool) $ticket->can($tickets_id, READ);
        }

        return $ticket_can_read_by_id[$tickets_id];
    };

    $ticket_budget = (int) ceil($channel_limit / count($allowed_room_types));
    $authorized_ticket_ids = [];
    $denied_tickets = 0;
    if ($focus_tickets_id > 0) {
        if (glpichat_can_read_ticket_from_state(
            $ticket_can_read($focus_tickets_id),
            $can_read_public_room,
            $can_read_internal_room
        )) {
            $authorized_ticket_ids[] = $focus_tickets_id;
        } else {
            $denied_tickets++;
        }
    }

    $evaluated_generic = 0;
    foreach (array_keys($generic_candidates) as $tickets_id) {
        $tickets_id = (int) $tickets_id;
        if ($tickets_id === $focus_tickets_id) {
            continue;
        }
        if (count($authorized_ticket_ids) >= $ticket_budget) {
            break;
        }

        $evaluated_generic++;
        if (!glpichat_can_read_ticket_from_state(
            $ticket_can_read($tickets_id),
            $can_read_public_room,
            $can_read_internal_room
        )) {
            $denied_tickets++;
            continue;
        }
        $authorized_ticket_ids[] = $tickets_id;
    }

    $generic_without_focus = count($generic_candidates) - (isset($generic_candidates[$focus_tickets_id]) ? 1 : 0);
    $output_truncated = $source_truncated || $evaluated_generic < $generic_without_focus;
    $log_phase('authorization', [
        'authorized_tickets' => count($authorized_ticket_ids),
        'denied_tickets' => $denied_tickets,
        'output_truncated' => $output_truncated,
        'focused_ticket' => $focus_tickets_id > 0,
    ]);

    if (count($authorized_ticket_ids) === 0) {
        $log_empty_enrichment();
        return [];
    }

    // From this point onward every bulk query is constrained to the bounded,
    // authorized ticket set. No room metadata from other tickets is loaded.
    $ticket_status_by_id = [];
    $ticket_rows = $DB->request([
        'SELECT' => ['id', 'status'],
        'FROM' => 'glpi_tickets',
        'WHERE' => ['id' => $authorized_ticket_ids],
    ]);
    foreach ($ticket_rows as $row) {
        $ticket_status_by_id[(int) $row['id']] = (int) $row['status'];
    }

    $rooms_by_key = [];
    $room_rows = $DB->request([
        'SELECT' => ['id', 'tickets_id', 'room_type'],
        'FROM' => 'glpi_plugin_glpichat_rooms',
        'WHERE' => [
            'tickets_id' => $authorized_ticket_ids,
            'room_type' => $allowed_room_types,
        ],
    ]);
    foreach ($room_rows as $row) {
        $key = glpichat_channel_key((int) $row['tickets_id'], (string) $row['room_type']);
        $rooms_by_key[$key] = (int) $row['id'];
    }

    $selected_channels = [];
    $rooms_created = 0;
    foreach ($authorized_ticket_ids as $tickets_id) {
        foreach ($allowed_room_types as $room_type) {
            // Keep the historical hard cap inside the room iteration itself.
            if (count($selected_channels) >= $channel_limit) {
                break 2;
            }

            $key = glpichat_channel_key($tickets_id, $room_type);
            if (!isset($rooms_by_key[$key])) {
                $rooms_by_key[$key] = glpichat_room_id($tickets_id, $room_type);
                $rooms_created++;
            }
            $selected_channels[] = [
                'tickets_id' => $tickets_id,
                'room_type' => $room_type,
                'rooms_id' => $rooms_by_key[$key],
            ];
        }
    }
    $all_rooms_ids = array_values(array_unique(array_map(
        static fn (array $channel): int => (int) $channel['rooms_id'],
        $selected_channels
    )));
    $log_phase('rooms', [
        'rooms' => count($all_rooms_ids),
        'rooms_created' => $rooms_created,
        'output_truncated' => $output_truncated,
    ]);

    $last_message_by_room = [];
    $message_head_rows = 0;
    if (count($all_rooms_ids) > 0) {
        $msg_agg = $DB->request([
            'SELECT' => [
                'rooms_id',
                QueryFunction::max('id', 'last_id'),
            ],
            'FROM' => 'glpi_plugin_glpichat_messages',
            'WHERE' => ['rooms_id' => $all_rooms_ids],
            'GROUPBY' => 'rooms_id',
        ]);
        foreach ($msg_agg as $row) {
            $last_message_by_room[(int) $row['rooms_id']] = (int) $row['last_id'];
            $message_head_rows++;
        }
    }
    $log_phase('message_heads', ['message_heads' => $message_head_rows]);

    // Keep both the latest participant and the deterministic earliest active
    // participant. This preserves unread badges across expiration while making
    // concurrent duplicate joins converge on the same active row.
    $latest_participant_by_room = [];
    $active_participant_by_room = [];
    $participant_rows = 0;
    if (count($all_rooms_ids) > 0) {
        $p_rows = $DB->request([
            'SELECT' => ['id', 'rooms_id', 'participant_type', 'users_id', 'left_at'],
            'FROM' => 'glpi_plugin_glpichat_participants',
            'WHERE' => [
                'rooms_id' => $all_rooms_ids,
                'users_id' => $users_id,
                'participant_type' => GLPICHAT_ACTOR_USER,
            ],
        ]);
        foreach ($p_rows as $row) {
            $participant_rows++;
            $rid = (int) $row['rooms_id'];
            if (
                !isset($latest_participant_by_room[$rid])
                || (int) $row['id'] > (int) $latest_participant_by_room[$rid]['id']
            ) {
                $latest_participant_by_room[$rid] = $row;
            }
            if (
                $row['left_at'] === null
                && (
                    !isset($active_participant_by_room[$rid])
                    || (int) $row['id'] < (int) $active_participant_by_room[$rid]['id']
                )
            ) {
                $active_participant_by_room[$rid] = $row;
            }
        }
    }
    $log_phase('participants', ['participants' => $participant_rows]);

    $readstate_by_participant = [];
    $all_relevant_participant_ids = array_values(array_unique(array_merge(
        array_map(static fn (array $p): int => (int) $p['id'], $latest_participant_by_room),
        array_map(static fn (array $p): int => (int) $p['id'], $active_participant_by_room)
    )));
    $readstate_rows = 0;
    if (count($all_relevant_participant_ids) > 0) {
        $rs_rows = $DB->request([
            'SELECT' => ['participants_id', 'last_read_messages_id'],
            'FROM' => 'glpi_plugin_glpichat_readstates',
            'WHERE' => ['participants_id' => $all_relevant_participant_ids],
        ]);
        foreach ($rs_rows as $row) {
            $readstate_by_participant[(int) $row['participants_id']] = (int) $row['last_read_messages_id'];
            $readstate_rows++;
        }
    }
    $log_phase('readstates', ['readstates' => $readstate_rows]);

    $result = [];
    $unread_queries = 0;
    foreach ($selected_channels as $channel) {
        // Defensive enforcement in the final room/output loop as well.
        if (count($result) >= $channel_limit) {
            break;
        }

        $tickets_id = (int) $channel['tickets_id'];
        $room_type = (string) $channel['room_type'];
        $rooms_id = (int) $channel['rooms_id'];
        $active_participant = $active_participant_by_room[$rooms_id] ?? null;
        $participants_id = $active_participant !== null ? (int) $active_participant['id'] : 0;
        $latest_participant = $latest_participant_by_room[$rooms_id] ?? null;
        $unread_participant = $active_participant ?? $latest_participant;
        $unread_count = 0;
        if ($unread_participant !== null) {
            $unread_pid = (int) $unread_participant['id'];
            $last_read = $readstate_by_participant[$unread_pid] ?? 0;
            $count_row = $DB->request([
                'COUNT' => 'cpt',
                'FROM' => 'glpi_plugin_glpichat_messages',
                'WHERE' => glpichat_unread_where_for_participant($unread_participant, $last_read),
            ])->current();
            $unread_count = (int) ($count_row['cpt'] ?? 0);
            $unread_queries++;
        }

        $result[] = glpichat_channel_output_row(
            $rooms_id,
            $tickets_id,
            $room_type,
            $participants_id,
            $unread_count,
            $last_message_by_room[$rooms_id] ?? 0,
            $ticket_status_by_id[$tickets_id] ?? 0
        );
    }
    $log_phase('unread', [
        'unread_queries' => $unread_queries,
        'channels' => count($result),
    ]);

    return $result;
}
