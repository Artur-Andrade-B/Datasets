# Histórico e Auditoria — Documentação Técnica

> **Audiência:** Administrador técnico
> **Relacionado:** [Seção no README principal](../../README.md#-histórico-e-auditoria-do-chat)

## O que faz

Registra e exibe dois tipos de histórico distintos: uma linha do tempo unificada no widget e um log de auditoria em aba dedicada. Ambos obedecem retenção configurável: por padrão, eventos duram 30 dias, mensagens 365 dias e auditlogs 180 dias.

## Fluxo completo

### Timeline (linha do tempo no widget)

A timeline é o feed principal de mensagens do chat. Ela exibe em ordem cronológica:

- Mensagens enviadas por técnicos e convidados
- Eventos de sistema: mudanças de status, prioridade, urgência, impacto, atribuições, acompanhamentos adicionados fora do chat, entrada e saída de participantes

Ao abrir um chatbox, o widget solicita até 50 mensagens e, separadamente, o recorte retido mais recente de eventos. Conforme o usuário rola para cima, carrega lotes de até 50 **mensagens** usando `before_id` com o ID da mensagem mais antiga já exibida; essa paginação não busca eventos antigos.

As CronTasks removem registros além das retenções configuradas. Os padrões são 30 dias para eventos e 365 dias para mensagens; a limpeza de mensagens registra um evento `messages_purged` antes da exclusão.

### Aba de Auditoria (log com retenção)

A aba **"Auditoria do Chat"** aparece no chamado para usuários com permissão `plugin_glpichat_view_audit` (Read). Ela exibe os eventos ainda presentes em `glpi_plugin_glpichat_auditlogs`; a CronTask `CleanAuditlogs` usa retenção configurável, padrão 180 dias.

## Permissões — detalhamento

### `plugin_glpichat_view_audit`

| Coluna | O que libera | Contexto |
|--------|--------------|---------|
| Read | Exibe a aba "Auditoria do Chat" no chamado com o log completo de eventos | Única coluna com efeito neste direito |

**Justificativa por perfil:**
- **Solicitante (Self-Service)**: Sem acesso — a auditoria é uma ferramenta de supervisão, não de operação.
- **Técnico (Technician)**: Sem acesso por padrão — o técnico não precisa auditar acessos externos no dia a dia.
- **Líder Técnico (Supervisor)**: Read ativo — precisa monitorar acessos de convidados e auditar incidentes de conformidade.
- **Administrador**: Read ativo — acesso completo para administração e diagnóstico.

## Tabelas de referência

### Colunas da aba de Auditoria

| Coluna | Descrição |
|--------|-----------|
| Data/Hora | Momento exato do evento |
| Ação | O que foi feito (ex: "Mensagem Enviada", "Convite Criado") |
| Ator | Quem fez (técnico, convidado, sistema) |
| Detalhes | Informações complementares do evento |

### Ações registradas na auditoria

| Ação registrada | Quando acontece | Detalhes incluídos |
|-----------------|-----------------|-------------------|
| Mensagem Enviada | Técnico ou convidado envia mensagem | Sala (público/interno) e conteúdo |
| Convite Criado | Técnico gera novo link de convite | Nome do convidado |
| Convite Cancelado | Técnico revoga link antes do uso | ID do convite |
| Convite Reemitido | Técnico gera novo link para substituir existente | Nova data de expiração |
| Convidado Entrou | Convidado aceita o link e acessa o chat | Nome do convidado |
| Convidado Saiu | Convidado fecha a aba ou é desconectado | Nome do convidado |
| Sessão Expirada | Sessão do convidado expira por inatividade | Nome do convidado |

## Comportamentos não óbvios

### Timeline e auditoria têm retenções diferentes

Por padrão, `glpi_plugin_glpichat_events` conserva 30 dias e `glpi_plugin_glpichat_auditlogs` conserva 180 dias. Assim, um evento pode deixar a timeline antes de sair da auditoria, mas nenhum dos dois registros é permanente por contrato. Administradores podem alterar essas retenções na configuração.

### A timeline mostra eventos de fora do chat

Mudanças de status, prioridade e atribuições feitas diretamente no formulário do chamado (fora do widget de chat) também aparecem na timeline do chat. Isso dá ao convidado externo visibilidade sobre o andamento do chamado sem que o técnico precise comunicar manualmente.

### A paginação por scroll carrega apenas mensagens antigas

A paginação infinita usa `before_id` e carrega somente mensagens antigas. Eventos entram no carregamento inicial ou chegam pelo Poll; o scroll não recupera eventos mais antigos que o recorte inicial.

## Limitações conhecidas

- O log de auditoria não tem paginação na aba — exibe de uma vez os registros ainda retidos para o chamado. Em históricos extensos, a aba pode demorar para carregar.
- Não é possível exportar o log de auditoria diretamente pela interface — é necessário consultar a tabela `glpi_plugin_glpichat_auditlogs` no banco de dados.
- Com as retenções padrão, eventos acima de 30 dias deixam a timeline e auditlogs acima de 180 dias deixam a aba; retenções maiores exigem configuração e capacidade correspondentes.

<br>

<p align="center">
  <sub>━━━━━━━━━━━━━━━━━━━━━━━</sub><br>
  <sub>Curtiu o plugin? Deixe uma ⭐ no repositório para ajudar outros administradores a encontrá-lo.</sub><br>
  <sub>Desenvolvido e mantido com apoio de <a href="https://www.forq.com.br/">Forq</a></sub>
</p>
