# Fluxo — Polling e Sincronização

> **Audiência:** Desenvolvedor
> **Relacionado:** [Índice de Documentação Técnica](../../README.md)

## O que é

Mecanismo de sincronização assíncrona incremental por polling periódico adaptativo, sem WebSockets, que consulta o backend em intervalos dinâmicos conforme o foco e o estado da aba do navegador.

## Atores envolvidos

- **Browser (usuário autenticado)** — executa `glpichat-widget.js`, controla timers de polling e estado local
- **Browser (convidado externo)** — executa `glpichat-guest.js`, fluxo simplificado sem múltiplos canais
- **Backend PHP** — controllers `Widget/Poll`, `Widget/Channels`, `Guest/Sync`, `Widget/Leave`, `Guest/Leave`
- **Banco de dados** — tabelas `rooms`, `messages`, `events`, `participants`, `readstates`

## Visão geral

```mermaid
flowchart TD
    A[Aba visível?] -->|Não| B[Intervalo Fundo\n18000ms]
    A -->|Sim| C[Chats abertos?]
    C -->|Não| D[Sem Poll de mensagens]
    C -->|Sim| E[Intervalo Focado\n2500ms]
    B --> G{History ativa\nou falha aberta?}
    E --> G
    G -->|Sim| H[Pausar Poll e Metadata]
    G -->|Não| I[POST /Widget/Poll]
```

O diagrama mostra como o intervalo é determinado pelo estado da aba e dos chats abertos. Sem chat aberto, Poll não envia POST e não chama Channels; o timer separado de metadados continua a cada 15 segundos. Enquanto qualquer History permanece ativa — inclusive se a sala foi minimizada/fechada — ou uma sala aberta mantém falha visível, Poll, Channels automático e refresh periódico de invites ficam pausados.

## Passo a passo

### A. Sincronização de metadados (`syncChannelMetadata`)

**Frequência:** a cada 15 segundos enquanto a aba estiver visível (`META_SYNC_MS = 15000ms`).

1. JS chama `GET /plugins/glpichat/Widget/Channels` (opcionalmente com `tickets_id` do chamado em foco na página).
2. Backend autentica, captura o CSRF e libera o lock da sessão PHP antes da descoberta histórica de canais.
3. Backend retorna a lista vinculada ao usuário: IDs de sala, tipo, status no GLPI, contadores de não lidas e `currentUserId`.
4. JS atualiza o launcher sem trocar o objeto canônico da sala nem apagar estados de History em andamento/falha.

### B. Polling de mensagens e eventos (`pollChannels`)

**Frequência:** dinâmica — 2500ms, 9000ms ou 18000ms.

1. JS mapeia as salas dos chatboxes abertos no dock.
2. Se a lista estiver vazia, cancela o POST e aguarda o próximo ciclo de metadados.
3. Para cada canal aberto, coleta: `tickets_id`, `room_type`, `after_id` (último `messages.id` carregado), `after_event_id` (último `events.id` carregado).
4. Envia `POST /plugins/glpichat/Widget/Poll` com CSRF token e lista de canais.
5. Backend normaliza e limita a entrada, conclui a autorização de cada sala e renova o CSRF enquanto a sessão está aberta.
6. Backend libera o lock da sessão PHP.
7. Para cada descritor já autorizado, resolve sala/participante e executa a hidratação incremental de mensagens, eventos, typing, cursores e unread.
8. JS aplica o delta e armazena o CSRF renovado.

Se Poll detectar um cursor incompatível sem mensagens incrementais, invalida no máximo uma sala ativa por ciclo e usa History para reconciliá-la. Salas inativas ficam marcadas para hidratação quando forem selecionadas. Uma primeira falha interrompe a cascata; não são iniciadas várias Histories automáticas em sequência.

### C. Hidratação e diagnóstico (`/Widget/History`)

1. O cliente admite uma única History por chave `ticket:room_type`.
2. O backend autentica e autoriza a sala, então libera imediatamente o lock de sessão PHP.
3. Após a liberação, preserva o participante/evento de presença e atualiza a atividade; a notificação GLPI de entrada é suprimida nesse caminho interativo. A criação concorrente converge para a primeira linha ativa e aposenta uma duplicata posterior antes de registrar outro evento.
4. Só então consulta mensagens e eventos.
5. Cada fase concluída (`session_released`, `participant_ready`, `messages_ready`, `events_ready`, `complete`) é correlacionada em `files/_log/glpichat.log`; o browser mostra a mesma referência no Console/UI.
6. A resposta só é aceita se `messages` e `events` forem arrays e se `rooms_id` ainda corresponder à sala solicitada.

### D. Fluxo do convidado (`/Guest/Sync`)

O convidado não tem múltiplos canais — usa `GET /plugins/glpichat/Guest/Sync?last_message_id=N&last_event_id=M`.

1. Servidor valida o cookie `glpichat_guest_session` e localiza a sala correspondente.
2. Atualiza `last_activity` e `last_seen` no participante.
3. Retorna delta de mensagens e eventos da sala pública.

### E. Saída de sala

- **Usuário autenticado:** `POST /Widget/Leave` com `rooms_id`. Remove o participante ativo e encerra o polling para aquele canal.
- **Convidado:** `POST /Guest/Leave` via `beforeunload`. Remove a sessão e redireciona para página de encerramento.

## Estado e timing

| Constante | Valor | Ativada quando |
|-----------|-------|----------------|
| `POLL_FOCUSED_MS` | 2500ms | Aba visível e pelo menos um chatbox aberto |
| `POLL_IDLE_MS` | 9000ms | Aba visível, mas todos os chatboxes minimizados |
| `POLL_BG_MS` | 18000ms | Aba em segundo plano (Page Visibility API) |
| `META_SYNC_MS` | 15000ms | Aba visível (independente de chats abertos) |

A Page Visibility API (`document.visibilitychange`) controla a transição entre `POLL_FOCUSED_MS`/`POLL_IDLE_MS` e `POLL_BG_MS`. Ao retornar ao foco, o polling se reajusta automaticamente ao intervalo correto.

O CSRF token é renovado a cada resposta de polling — sem necessidade de refresh de página em sessões longas.

## Riscos e pontos de atenção

**Limite configurável e absoluto:** Poll processa `poll_max_channels` (padrão 20) e aplica teto absoluto de 50 entradas brutas antes de qualquer autorização/query por canal.

**Duas abas abertas:** Ambas podem fazer Poll/MarkRead de forma concorrente. Perf2 usa atualização SQL monotônica (`GREATEST`) e converge a criação simultânea do primeiro readstate, impedindo que o cursor persistido volte para trás; a UI de uma aba ainda pode ficar momentaneamente defasada até a próxima resposta/sincronização.

**Servidor mais lento que o intervalo:** Poll e Channels são coalescidos; o pipeline HTTP do widget é serial. Uma History lenta pausa novos ciclos automáticos, evitando backlog crescente. Channels libera a sessão antes da descoberta e Poll antes da hidratação, portanto esses reads automáticos não devem bloquear páginas GLPI posteriores do mesmo usuário. Isso não cancela SQL/PHP já em execução nem impede esgotamento do pool se várias sessões independentes ficarem presas.

**CSRF expirado em sessões muito longas:** Embora o CSRF seja renovado a cada resposta, se o usuário deixar o GLPI aberto sem nenhuma requisição, o token pode expirar. Poll registra a falha no Console e mantém o agendamento normal; não existe reinicialização específica de bootstrap para HTTP 403 neste candidato.

**Convidado sem detecção de inatividade no cliente:** O `glpichat-guest.js` não implementa detecção de inatividade local — a expiração de sessão do convidado é detectada apenas pelo backend (via `last_activity`) e comunicada como evento `invite_revoked` no próximo `GET /Guest/Sync`.

<br>

<p align="center">
  <sub>━━━━━━━━━━━━━━━━━━━━━━━</sub><br>
  <sub>Curtiu o plugin? Deixe uma ⭐ no repositório para ajudar outros administradores a encontrá-lo.</sub><br>
  <sub>Desenvolvido e mantido com apoio de <a href="https://www.forq.com.br/">Forq</a></sub>
</p>
