/* Fleet selection is small browser state; the server always resolves the final
 * filters/IDs, checks rights, and snapshots target identities. No credentials. */
(() => {
  'use strict';
  const form = document.getElementById('desktop-assignment');
  if (!form) return;
  const key = `glpichat-fleet:${location.pathname}:${form.dataset.owner}:${form.dataset.filterKey}`;
  const rows = [...form.querySelectorAll('.fleet-machine')];
  const modes = [...form.querySelectorAll('input[name="selection"]')];
  let state = { mode: 'selected', selected: [], excluded: [] };
  try {
    if (form.dataset.committed === '1') sessionStorage.removeItem(key);
    const saved = JSON.parse(sessionStorage.getItem(key) || 'null');
    const valid = (ids) => Array.isArray(ids) && ids.length <= 10000 && ids.every((id) => /^[1-9]\d{0,9}$/.test(String(id)));
    if (saved && ['selected', 'all'].includes(saved.mode) && valid(saved.selected) && valid(saved.excluded)) {
      state = { mode: saved.mode, selected: [...new Set(saved.selected.map(String))], excluded: [...new Set(saved.excluded.map(String))] };
    }
  } catch (_) { /* Storage unavailable: selection still works on this page. */ }
  const total = Number(form.dataset.total) || 0;
  function render() {
    modes.forEach((radio) => { radio.checked = radio.value === state.mode; });
    rows.forEach((row) => { row.checked = state.mode === 'all' ? !state.excluded.includes(row.value) : state.selected.includes(row.value); });
    form.elements.selected_ids.value = JSON.stringify(state.selected);
    form.elements.excluded_ids.value = JSON.stringify(state.mode === 'all' ? state.excluded : []);
    const count = state.mode === 'all' ? Math.max(0, total - state.excluded.length) : state.selected.length;
    document.getElementById('fleet-selection-count').textContent = state.mode === 'all'
      ? `Prévia: ${count} computadores selecionados em todos os resultados (${state.excluded.length} excluídos). Desmarque uma linha para excluí-la. Os alvos serão revalidados ao solicitar.`
      : `Prévia: ${count} computadores selecionados entre páginas. Os alvos serão revalidados ao solicitar.`;
    try { sessionStorage.setItem(key, JSON.stringify(state)); } catch (_) { }
  }
  modes.forEach((radio) => radio.addEventListener('change', () => { state.mode = radio.value; render(); }));
  rows.forEach((row) => row.addEventListener('change', () => {
    const field = state.mode === 'all' ? 'excluded' : 'selected';
    const include = state.mode === 'all' ? !row.checked : row.checked;
    state[field] = state[field].filter((id) => id !== row.value);
    if (include) state[field].push(row.value);
    render();
  }));
  document.getElementById('fleet-select-page').addEventListener('click', () => {
    if (state.mode === 'all') state.excluded = state.excluded.filter((id) => !rows.some((row) => row.value === id));
    else state.selected = [...new Set([...state.selected, ...rows.map((row) => row.value)])];
    render();
  });
  document.getElementById('fleet-clear-selection').addEventListener('click', () => { state = { mode: 'selected', selected: [], excluded: [] }; render(); });
  form.addEventListener('submit', (event) => {
    if (state.mode === 'selected' && state.selected.length === 0) {
      event.preventDefault(); document.getElementById('fleet-selection-count').textContent = 'Selecione computadores antes de solicitar a operação.';
      return;
    }
    render();
  });
  render();
})();
