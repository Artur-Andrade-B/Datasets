<?php

declare(strict_types=1);

require_once __DIR__ . '/flows/guest_flow.php';
require_once __DIR__ . '/desktop/common.php';
require_once __DIR__ . '/desktop/conversations.php';
require_once __DIR__ . '/desktop/attachments.php';

/** All guest mutations lock ticket, then invitation/participant, then receipt. */
function glpichat_guest_transaction(callable $operation): mixed
{
    return glpichat_desktop_transaction($operation);
}

function glpichat_guest_row(string $sql): array
{
    return glpichat_desktop_db_rows($sql)[0] ?? [];
}

function glpichat_guest_lock_ticket(int $ticketId): array
{
    $ticket = glpichat_guest_row('SELECT * FROM glpi_tickets WHERE id=' . $ticketId . ' AND is_deleted=0 FOR UPDATE');
    if (!$ticket) { throw new GlpichatGuestException('conversation_unavailable', 'Conversa indisponível.', 403); }
    return $ticket;
}

function glpichat_guest_native_followup(int $ticketId, int $userId, string $content): int
{
    $followup = new ITILFollowup();
    $now = date('Y-m-d H:i:s');
    $id = (int) $followup->add([
        'itemtype' => 'Ticket', 'items_id' => $ticketId, 'users_id' => $userId,
        'content' => str_replace("\n", '<br>', htmlspecialchars($content, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')),
        'is_private' => 0, 'requesttypes_id' => glpichat_desktop_requesttype_id(),
        'date' => $now, 'date_creation' => $now, 'date_mod' => $now,
        '_disablenotif' => true, '_no_reopen' => true,
    ]);
    if ($id <= 0) { throw new RuntimeException('Guest native followup failed.'); }
    return $id;
}

/** A recovery cookie is delivered BEFORE consuming the invitation. It is never in the link. */
function glpichat_guest_accept_atomic(string $token, string $claim): array
{
    if (!preg_match('/\A[a-f0-9]{64}\z/D', $token) || !preg_match('/\A[a-f0-9]{64}\z/D', $claim)) {
        throw new GlpichatGuestException('invite_unavailable', 'Convite inválido ou indisponível.', 403);
    }
    $hash = glpichat_guest_invite_token_hash($token);
    $initial = glpichat_guest_row('SELECT id,tickets_id FROM glpi_plugin_glpichat_invites WHERE token_hash=' . glpichat_desktop_quote($hash) . ' LIMIT 1');
    if (!$initial) { throw new GlpichatGuestException('invite_unavailable', 'Convite inválido ou indisponível.', 403); }
    // A lost final response can only be recovered by the browser holding both secrets.
    $sessionToken = hash_hmac('sha256', "glpichat-guest-accept-v2\0" . $token, hex2bin($claim));
    return glpichat_guest_transaction(static function () use ($initial, $hash, $sessionToken): array {
        global $DB;
        $ticket = glpichat_guest_lock_ticket((int) $initial['tickets_id']);
        $invite = glpichat_guest_row('SELECT * FROM glpi_plugin_glpichat_invites WHERE id=' . (int) $initial['id'] . ' FOR UPDATE');
        if (!$invite || !hash_equals((string) $invite['token_hash'], $hash) || !empty($invite['revoked_at'])) {
            throw new GlpichatGuestException('invite_unavailable', 'Convite inválido, utilizado ou revogado.', 403);
        }
        $sessionHash = glpichat_guest_session_hash($sessionToken);
        if (!empty($invite['accepted_at'])) {
            $participant = glpichat_guest_row('SELECT * FROM glpi_plugin_glpichat_participants WHERE id=' . (int) $invite['participants_id'] . ' FOR UPDATE');
            if (!$participant || $participant['participant_type'] !== 'guest' || (int) $participant['rooms_id'] !== (int) $invite['rooms_id'] || !empty($participant['left_at']) || !hash_equals((string) $participant['session_token_hash'], $sessionHash)
                || strtotime((string) ($participant['last_activity'] ?? $participant['joined_at'])) + glpichat_guest_session_ttl_config_seconds() < time()) {
                throw new GlpichatGuestException('invite_unavailable', 'Este convite já foi utilizado ou a sessão terminou.', 403);
            }
        } else {
            if ((string) $invite['expires_at'] <= date('Y-m-d H:i:s')) {
                throw new GlpichatGuestException('invite_expired', 'Este convite expirou.', 410);
            }
            $room = glpichat_room_by_id((int) $invite['rooms_id']);
            if ($room['room_type'] !== 'public' || (int) $room['tickets_id'] !== (int) $ticket['id']) {
                throw new GlpichatGuestException('invite_unavailable', 'Conversa indisponível.', 403);
            }
            $id = glpichat_create_guest_participant((int) $invite['rooms_id'], (string) $invite['guest_name'], (string) $invite['guest_email'], $sessionHash);
            if ($id <= 0 || !glpichat_mark_invite_accepted((int) $invite['id'], $id)) { throw new RuntimeException('Guest acceptance failed.'); }
            $participant = ['id' => $id, 'rooms_id' => $invite['rooms_id'], 'guest_name' => $invite['guest_name']];
            glpichat_record_event((int) $invite['rooms_id'], (int) $ticket['id'], 'guest_joined', 'guest', 0, $id,
                ['invite_id' => (int) $invite['id'], 'guest_name' => (string) $invite['guest_name']]);
            $followupId = glpichat_guest_native_followup((int) $ticket['id'], glpichat_external_followup_user_id(),
                glpichat_guest_join_followup_content((string) $invite['guest_name']));
            glpichat_queue_notification_job('followup', $followupId, (int) $ticket['id'], 'add_followup', 'public', glpichat_external_followup_user_id());
            glpichat_queue_notification_job('participant', $id, (int) $ticket['id'], 'glpichat_guest_joined', 'public', 0);
        }
        return ['session_token' => $sessionToken, 'participants_id' => (int) $participant['id'],
            'rooms_id' => (int) $participant['rooms_id'], 'tickets_id' => (int) $ticket['id'], 'guest_name' => (string) $participant['guest_name']];
    });
}

function glpichat_guest_end_atomic(int $participantId, string $now, bool $timeout = false): bool
{
    $initial = glpichat_guest_row('SELECT p.*,r.tickets_id FROM glpi_plugin_glpichat_participants p JOIN glpi_plugin_glpichat_rooms r ON r.id=p.rooms_id WHERE p.id=' . $participantId . " AND p.participant_type='guest' LIMIT 1");
    if (!$initial) { return true; }
    return glpichat_guest_transaction(static function () use ($initial, $participantId, $now, $timeout): bool {
        global $DB;
        glpichat_guest_lock_ticket((int) $initial['tickets_id']);
        $participant = glpichat_guest_row('SELECT * FROM glpi_plugin_glpichat_participants WHERE id=' . $participantId . ' FOR UPDATE');
        if (!$participant || !empty($participant['left_at'])) { return true; }
        if ($timeout && strtotime((string) ($participant['last_activity'] ?? $participant['joined_at'])) + glpichat_guest_session_ttl_config_seconds() >= time()) { return false; }
        if (!$DB->update('glpi_plugin_glpichat_participants', ['left_at' => $now, 'session_token_hash' => null, 'is_typing_until' => null], ['id' => $participantId, 'left_at' => null]) || $DB->affectedRows() !== 1) {
            throw new RuntimeException('Guest disconnection failed.');
        }
        $event = $timeout ? 'guest_left_timeout' : 'guest_left';
        $ticketId = (int) $initial['tickets_id'];
        glpichat_record_event((int) $participant['rooms_id'], $ticketId, $event, 'guest', 0, $participantId, ['guest_name' => (string) $participant['guest_name']]);
        $userId = glpichat_external_followup_user_id();
        $content = $timeout ? glpichat_guest_left_timeout_followup_content((string) $participant['guest_name']) : glpichat_guest_left_followup_content((string) $participant['guest_name']);
        $followup = glpichat_guest_native_followup($ticketId, $userId, $content);
        glpichat_queue_notification_job('followup', $followup, $ticketId, 'add_followup', 'public', $userId);
        glpichat_queue_notification_job('participant', $participantId, $ticketId, 'glpichat_' . $event, 'public', 0);
        return true;
    });
}

/** HTTP protocol v2 must carry the subject rendered in the originating tab. */
function glpichat_guest_require_context(array $input): void
{
    if (!array_key_exists('expected_participant_id', $input) || !array_key_exists('expected_rooms_id', $input)) {
        throw new GlpichatGuestException('guest_context_changed', 'Atualize esta página para continuar nesta conversa.', 409, 0, ['reload_required' => true]);
    }
}

/** New clients bind every operation to the subject rendered in that tab.
 * HTTP controllers require both fields. Direct service callers may omit them.
 */
function glpichat_guest_assert_context(array $participant, array $input): void
{
    foreach (['expected_participant_id' => 'id', 'expected_rooms_id' => 'rooms_id'] as $field => $column) {
        if (!array_key_exists($field, $input)) { continue; }
        $value = $input[$field];
        if ((!is_int($value) && !is_string($value)) || !ctype_digit((string) $value) || (int) $value <= 0) {
            throw new GlpichatGuestException('invalid_context', 'Contexto de conversa inválido.', 400);
        }
        if ((int) $value !== (int) $participant[$column]) {
            throw new GlpichatGuestException('guest_context_changed', 'Outro convite foi aberto neste navegador. Reabra a conversa correta antes de continuar.', 409);
        }
    }
}

/** A caller-provided timeline cursor cannot move before guest admission. */
function glpichat_guest_event_cursor(string $joinedAt, string $cursor): string
{
    $floor = glpichat_event_cursor($joinedAt, '', 0);
    $parts = glpichat_event_cursor_parts($cursor);
    if ($parts['date'] === '' || strcmp($cursor, $floor) < 0) { return $floor; }
    if (!preg_match('/\A[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}\|[EFL]\|[0-9]{12}\z/D', $cursor)) {
        throw new GlpichatGuestException('invalid_cursor', 'Marcador de eventos inválido.', 400);
    }
    return $cursor;
}

/** UUIDs identify pieces; a bounded submission groups text and files for throttle admission. */
function glpichat_guest_delivery_ids(array $input): array
{
    $uuid = $input['client_message_id'] ?? '';
    if ($uuid === '') { // Legacy callers have no automatic retry guarantee.
        $bytes = random_bytes(16); $bytes[6] = chr((ord($bytes[6]) & 15) | 64); $bytes[8] = chr((ord($bytes[8]) & 63) | 128);
        $hex = bin2hex($bytes); $uuid = substr($hex,0,8) . '-' . substr($hex,8,4) . '-' . substr($hex,12,4) . '-' . substr($hex,16,4) . '-' . substr($hex,20);
    }
    $group = $input['submission_id'] ?? $uuid;
    $count = $input['submission_count'] ?? 1;
    foreach ([$uuid, $group] as $id) {
        if (!is_string($id) || !preg_match('/\A[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\z/D', $id)) {
            throw new GlpichatGuestException('invalid_message_id', 'Identificador de envio inválido.', 400);
        }
    }
    if ((!is_int($count) && !is_string($count)) || !preg_match('/\A(?:[1-9]|10|11)\z/D', (string) $count)) {
        throw new GlpichatGuestException('invalid_submission', 'Envie até dez arquivos por vez.', 400);
    }
    return [$uuid, $group, (int) $count];
}

function glpichat_guest_decorate_messages(array $messages, array $participant): array
{
    if (!$messages) { return []; }
    $ids = implode(',', array_map(static fn(array $m): int => (int) $m['id'], $messages));
    $receipts = glpichat_desktop_db_rows('SELECT messages_id,client_message_id FROM glpi_plugin_glpichat_guestsends WHERE participants_id=' . (int) $participant['id'] . ' AND messages_id IN (' . $ids . ')');
    $byId = array_column($receipts, 'client_message_id', 'messages_id');
    global $CFG_GLPI;
    $root = rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/');
    foreach ($messages as &$message) {
        unset($message['client_message_id']);
        if ($message['actor_type'] === 'guest' && (int) $message['participants_id'] === (int) $participant['id'] && isset($byId[$message['id']])) {
            $message['client_message_id'] = $byId[$message['id']];
        }
        if ((int) $message['documents_id'] > 0) {
            $message['attachment_url'] = $root . '/plugins/glpichat/Guest/Attachment/' . (int) $message['id'] . '/' . (int) $message['documents_id']
                . '?expected_participant_id=' . (int) $participant['id'] . '&expected_rooms_id=' . (int) $participant['rooms_id'];
        }
    }
    unset($message);
    return $messages;
}

function glpichat_guest_deliver(string $sessionToken, array $input, mixed $file = null): array
{
    [$uuid, $group, $count] = glpichat_guest_delivery_ids($input);
    $initial = glpichat_guest_participant($sessionToken);
    glpichat_guest_assert_context($initial, $input);
    $room = glpichat_room_by_id((int) $initial['rooms_id']);
    if ($room['room_type'] !== 'public') { throw new GlpichatGuestException('conversation_unavailable', 'Conversa indisponível.', 403); }
    $attachment = $file !== null ? glpichat_desktop_attachment_input($file) : null;
    if ($attachment === null && !is_string($input['content'] ?? null)) { throw new GlpichatGuestException('invalid_content', 'Conteúdo da mensagem inválido.', 400); }
    $content = $attachment !== null ? glpichat_guest_attachment_message_content($attachment['name']) : glpichat_desktop_normalize_message((string) ($input['content'] ?? ''));
    $payload = hash('sha256', json_encode([$attachment !== null ? 'file' : 'text', $content, $attachment], JSON_THROW_ON_ERROR));
    return glpichat_guest_transaction(static function () use ($sessionToken, $initial, $room, $uuid, $group, $count, $attachment, $file, $content, $payload): array {
        global $DB;
        $ticket = glpichat_guest_lock_ticket((int) $room['tickets_id']);
        $participant = glpichat_guest_row('SELECT * FROM glpi_plugin_glpichat_participants WHERE id=' . (int) $initial['id'] . ' FOR UPDATE');
        if (!$participant || !empty($participant['left_at']) || !hash_equals((string) $participant['session_token_hash'], glpichat_guest_session_hash($sessionToken))
            || strtotime((string) ($participant['last_activity'] ?? $participant['joined_at'])) + glpichat_guest_session_ttl_config_seconds() < time()) {
            throw new GlpichatGuestException('session_expired', 'Sessão expirada ou revogada.', 401);
        }
        $pid = (int) $participant['id']; $ticketId = (int) $ticket['id'];
        $receipt = glpichat_guest_row('SELECT * FROM glpi_plugin_glpichat_guestsends WHERE participants_id=' . $pid . ' AND client_message_id=' . glpichat_desktop_quote($uuid) . ' FOR UPDATE');
        if ($receipt) {
            if (!hash_equals((string) $receipt['payload_hash'], $payload) || $receipt['submission_id'] !== $group || (int) $receipt['submission_count'] !== $count || (int) $receipt['tickets_id'] !== $ticketId) {
                throw new GlpichatGuestException('idempotency_conflict', 'Este identificador já pertence a outro envio.', 409);
            }
            try { $message = glpichat_message_by_id((int) $receipt['messages_id']); }
            catch (RuntimeException $error) { throw new GlpichatGuestException('message_unavailable', 'O envio foi confirmado, mas a mensagem não está mais disponível.', 409, 0, ['committed' => true, 'message_id' => (int) $receipt['messages_id'], 'client_message_id' => $uuid]); }
            if ($message['actor_type'] !== 'guest' || (int) $message['participants_id'] !== $pid) { throw new RuntimeException('Guest receipt source mismatch.'); }
        } else {
            if (!in_array((int) $ticket['status'], [1,2,3,4], true) || Ticket::getMergedTickets($ticketId) !== []) {
                throw new GlpichatGuestException('conversation_read_only', 'Esta conversa está disponível somente para leitura.', 403);
            }
            $groupRows = glpichat_desktop_db_rows('SELECT submission_count,created_at FROM glpi_plugin_glpichat_guestsends WHERE participants_id=' . $pid . ' AND submission_id=' . glpichat_desktop_quote($group));
            if ($groupRows) {
                if (count($groupRows) >= $count || (int) $groupRows[0]['submission_count'] !== $count) {
                    throw new GlpichatGuestException('submission_full', 'Este conjunto de envio já foi concluído.', 409);
                }
                if (min(array_column($groupRows, 'created_at')) < date('Y-m-d H:i:s', time() - 600)) {
                    throw new GlpichatGuestException('submission_expired', 'Prepare um novo envio para os itens ainda não enviados.', 409);
                }
            } else {
                $wait = glpichat_config_int('guest_send_throttle_s', 2) - (time() - strtotime((string) ($participant['last_send_at'] ?? '1970-01-01')));
                if ($wait > 0) { throw new GlpichatGuestException('send_throttled', 'Aguarde antes de enviar novamente.', 429, $wait); }
            }
            if (!$DB->insert('glpi_plugin_glpichat_guestsends', ['participants_id' => $pid, 'client_message_id' => $uuid,
                'submission_id' => $group, 'submission_count' => $count, 'payload_hash' => $payload, 'tickets_id' => $ticketId,
                'messages_id' => null, 'itilfollowups_id' => null, 'documents_id' => 0, 'created_at' => date('Y-m-d H:i:s')])) { throw new RuntimeException('Guest receipt creation failed.'); }
            $receiptId = (int) $DB->insertId();
            $userId = glpichat_external_followup_user_id();
            $followupId = glpichat_guest_native_followup($ticketId, $userId, $content);
            $documentId = $attachment !== null ? glpichat_desktop_store_attachment(['user_id' => $userId, 'entity_id' => (int) $ticket['entities_id']], $ticketId, $followupId, $file, $attachment) : 0;
            $messageId = glpichat_add_message($ticketId, 'public', 'guest', 0, $pid, $content, $documentId, $followupId, false);
            if ($messageId <= 0 || !$DB->update('glpi_plugin_glpichat_guestsends', ['messages_id' => $messageId, 'itilfollowups_id' => $followupId, 'documents_id' => $documentId], ['id' => $receiptId])) { throw new RuntimeException('Guest receipt completion failed.'); }
            glpichat_update_participant_last_send($pid);
            glpichat_queue_message_notifications($ticketId, 'public', 'guest', 0, $content, $messageId, $followupId, true);
            $message = glpichat_message_by_id($messageId);
        }
        $message = glpichat_guest_decorate_messages([$message], $participant)[0];
        return ['message_id' => (int) $message['id'], 'documents_id' => (int) $message['documents_id'], 'client_message_id' => $uuid, 'message' => $message];
    });
}

/** Guest capability is scoped to one public room and its post-join history. */
function glpichat_guest_download(string $sessionToken, int $messageId, int $documentId, array $context = []): \Symfony\Component\HttpFoundation\BinaryFileResponse
{
    $participant = glpichat_guest_participant($sessionToken);
    glpichat_guest_assert_context($participant, $context);
    $row = glpichat_guest_row('SELECT m.*,r.room_type,t.entities_id FROM glpi_plugin_glpichat_messages m '
        . 'JOIN glpi_plugin_glpichat_rooms r ON r.id=m.rooms_id AND r.tickets_id=m.tickets_id '
        . 'JOIN glpi_tickets t ON t.id=m.tickets_id AND t.is_deleted=0 '
        . 'WHERE m.id=' . $messageId . ' AND m.documents_id=' . $documentId . ' AND m.rooms_id=' . (int) $participant['rooms_id']
        . " AND r.room_type='public' AND m.date_creation >= " . glpichat_desktop_quote((string) $participant['joined_at']) . ' LIMIT 1');
    if (!$row) { throw new GlpichatGuestException('attachment_unavailable', 'Anexo indisponível nesta conversa.', 404); }
    // Includes current source privacy, deletion, and current native relationship.
    $refreshed = glpichat_refresh_messages((int) $participant['rooms_id'], [$messageId], (string) $participant['joined_at']);
    if (!$refreshed['refreshed_messages'] || (int) $refreshed['refreshed_messages'][0]['documents_id'] !== $documentId) {
        throw new GlpichatGuestException('attachment_unavailable', 'Anexo indisponível nesta conversa.', 404);
    }
    $document = glpichat_guest_row('SELECT * FROM glpi_documents WHERE id=' . $documentId . ' AND entities_id=' . (int) $row['entities_id'] . ' AND is_deleted=0 AND is_blacklisted=0');
    $path = $document ? glpichat_desktop_document_path($document) : null;
    if ($path === null || ((string) $document['sha1sum'] !== '' && !hash_equals((string) $document['sha1sum'], (string) sha1_file($path)))) {
        throw new GlpichatGuestException('attachment_unavailable', 'Anexo indisponível. Solicite uma nova cópia.', 404);
    }
    $meta = glpichat_desktop_attachment_output($document);
    if ($meta === null) { throw new GlpichatGuestException('attachment_unavailable', 'Anexo indisponível.', 404); }
    $response = new \Symfony\Component\HttpFoundation\BinaryFileResponse($path);
    $response->headers->set('Content-Type', 'application/octet-stream');
    $response->setContentDisposition(\Symfony\Component\HttpFoundation\ResponseHeaderBag::DISPOSITION_ATTACHMENT, $meta['name'], 'anexo-' . $documentId);
    $response->headers->set('Cache-Control', 'no-store, private');
    $response->headers->set('X-Content-Type-Options', 'nosniff');
    $response->headers->set('Content-Security-Policy', "default-src 'none'; sandbox");
    return $response;
}

function glpichat_guest_failure_response(Throwable $error, string $stage): \Symfony\Component\HttpFoundation\JsonResponse
{
    if ($error instanceof GlpichatGuestException || $error instanceof GlpichatDesktopException) {
        $status = $error->httpStatus;
        $body = ['error' => $error->getMessage(), 'code' => $error->errorCode] + ($error instanceof GlpichatGuestException ? $error->details : []);
        if ($error instanceof GlpichatGuestException && $error->retryAfter > 0) { $body['retry_after'] = $error->retryAfter; }
    } elseif ($error instanceof \Symfony\Component\HttpFoundation\Exception\RequestExceptionInterface) {
        $status = 400; $body = ['error' => 'Parâmetros inválidos.', 'code' => 'invalid_request'];
    } else {
        $status = 503; $ref = glpichat_desktop_log_failure($stage, $error);
        $body = ['error' => 'Serviço temporariamente indisponível. Referência: ' . $ref . '.', 'code' => 'temporarily_unavailable', 'reference' => $ref];
    }
    $response = new \Symfony\Component\HttpFoundation\JsonResponse($body, $status);
    $response->headers->set('Cache-Control', 'no-store');
    if (isset($body['retry_after'])) { $response->headers->set('Retry-After', (string) $body['retry_after']); }
    return $response;
}
