<?php

declare(strict_types=1);

use Glpi\DBAL\QueryExpression;

require_once dirname(__DIR__) . '/flows/guest_flow.php';

function glpichat_accept_invite_lookup(string $token_hash): array
{
    global $DB;

    $invite = $DB->request([
        'FROM' => 'glpi_plugin_glpichat_invites',
        'WHERE' => [
            'token_hash' => $token_hash,
            'accepted_at' => null,
            'revoked_at' => null,
            ['expires_at' => ['>', new QueryExpression('NOW()')]],
        ],
        'LIMIT' => 1,
    ])->current();

    return is_array($invite) ? $invite : [];
}

function glpichat_create_guest_participant(int $rooms_id, string $guest_name, string $guest_email, string $session_hash): int
{
    global $DB;

    $now = date('Y-m-d H:i:s');
    if (!$DB->insert('glpi_plugin_glpichat_participants', [
        'rooms_id' => $rooms_id,
        'users_id' => 0,
        'guest_name' => $guest_name,
        'guest_email' => $guest_email,
        'participant_type' => GLPICHAT_ACTOR_GUEST,
        'session_token_hash' => $session_hash,
        'joined_at' => $now,
        'last_activity' => $now,
    ])) { throw new RuntimeException('Guest participant creation failed.'); }

    return (int) $DB->insertId();
}

function glpichat_guest_session_ttl_config_seconds(): int
{
    global $DB;

    $ttl = 3600;
    if (isset($DB) && $DB !== null) {
        $ttl = (int) Config::getConfigurationValue('plugin:glpichat', 'guest_session_ttl');
    }

    if ($ttl <= 0) {
        $ttl = 3600;
    }

    return $ttl;
}

function glpichat_mark_invite_accepted(int $invite_id, int $participants_id): bool
{
    global $DB;

    $updated = $DB->update('glpi_plugin_glpichat_invites', [
        'accepted_at' => date('Y-m-d H:i:s'),
        'participants_id' => $participants_id,
    ], [
        'id' => $invite_id,
        'accepted_at' => null,
        'revoked_at' => null,
        ['expires_at' => ['>', new QueryExpression('NOW()')]],
    ]);

    return $updated && $DB->affectedRows() === 1;
}

function glpichat_guest_participant(string $session_token): array
{
    global $DB;

    $participant = $DB->request([
        'FROM' => 'glpi_plugin_glpichat_participants',
        'WHERE' => [
            'session_token_hash' => glpichat_guest_session_hash($session_token),
            'participant_type' => GLPICHAT_ACTOR_GUEST,
            'left_at' => null,
            new QueryExpression('NOT EXISTS (SELECT 1 FROM glpi_plugin_glpichat_invites gi WHERE gi.participants_id = glpi_plugin_glpichat_participants.id AND gi.revoked_at IS NOT NULL)'),
        ],
        'LIMIT' => 1,
    ])->current();

    if (!is_array($participant)) {
        throw new GlpichatGuestException('session_expired', 'Essa sessão de convidado não é mais válida. Por favor, entre em contato com a pessoa que te enviou o invite.', 401);
    }

    $ttl = glpichat_guest_session_ttl_config_seconds();

    $last_time = $participant['last_activity'] ?? $participant['joined_at'] ?? date('Y-m-d H:i:s');
    $elapsed = time() - strtotime($last_time);

    if ($elapsed > $ttl) {
        require_once dirname(__DIR__) . '/guest_delivery.php';
        if (!glpichat_guest_end_atomic((int) $participant['id'], date('Y-m-d H:i:s'), true)) {
            // Another valid request renewed activity before the timeout lock.
            return glpichat_guest_participant($session_token);
        }
        throw new GlpichatGuestException('session_expired', 'Essa sessão de convidado não é mais válida. Por favor, entre em contato com a pessoa que te enviou o invite.', 401);
    }

    return $participant;
}

function glpichat_disconnect_participant(int $participants_id, string $now): void
{
    require_once dirname(__DIR__) . '/guest_delivery.php';
    glpichat_guest_end_atomic($participants_id, $now);
}

function glpichat_assert_guest_not_throttled(int $participants_id, int $min_interval_seconds = 2): void
{
    global $DB;

    $min_interval_seconds = glpichat_config_int('guest_send_throttle_s', $min_interval_seconds);

    $row = $DB->request([
        'SELECT' => ['last_send_at'],
        'FROM'   => 'glpi_plugin_glpichat_participants',
        'WHERE'  => ['id' => $participants_id],
        'LIMIT'  => 1,
    ])->current();

    if (!is_array($row) || $row['last_send_at'] === null) {
        return;
    }

    $elapsed = time() - strtotime((string) $row['last_send_at']);
    if ($elapsed < $min_interval_seconds) {
        throw new GlpichatGuestException('send_throttled', 'Muitas requisições. Tente novamente em instantes.', 429, $min_interval_seconds - $elapsed);
    }
}

function glpichat_update_participant_activity(int $participants_id, bool $is_typing): void
{
    global $DB;

    $now = date('Y-m-d H:i:s');
    $is_typing_until = $is_typing ? date('Y-m-d H:i:s', time() + 4) : null;

    $update_data = [
        'last_activity'   => $now,
        'last_seen'       => $now,
        'is_typing_until' => $is_typing_until,
    ];

    if (!$DB->update('glpi_plugin_glpichat_participants', $update_data, ['id' => $participants_id, 'left_at' => null])) { throw new RuntimeException('Guest activity update failed.'); }
}

function glpichat_get_typing_participants(int $rooms_id, int $exclude_participant_id): array
{
    global $DB;

    $now = date('Y-m-d H:i:s');
    $iterator = $DB->request([
        'SELECT' => ['users_id', 'guest_name', 'participant_type'],
        'FROM'   => 'glpi_plugin_glpichat_participants',
        'WHERE'  => [
            'rooms_id' => $rooms_id,
            'left_at'  => null,
            ['id' => ['!=', $exclude_participant_id]],
            ['is_typing_until' => ['>', $now]],
        ],
    ]);

    $names = [];
    foreach ($iterator as $row) {
        if ($row['participant_type'] === GLPICHAT_ACTOR_GUEST) {
            $names[] = $row['guest_name'] ?: 'Convidado';
        } else {
            $users_id = (int) $row['users_id'];
            $names[] = getUserName($users_id) ?: ('Usuário #' . $users_id);
        }
    }

    return $names;
}

function glpichat_update_participant_last_send(int $participants_id): void
{
    global $DB;
    if (!$DB->update('glpi_plugin_glpichat_participants', ['last_send_at' => date('Y-m-d H:i:s')], ['id' => $participants_id, 'left_at' => null])) { throw new RuntimeException('Guest send time update failed.'); }
}

function glpichat_log_auth_failure(string $action, string $detail, string $ip): void
{
    global $DB;
    if (!isset($DB) || !$DB->tableExists('glpi_plugin_glpichat_auditlogs')) {
        return;
    }
    $DB->insert('glpi_plugin_glpichat_auditlogs', [
        'rooms_id'        => 0,
        'tickets_id'      => 0,
        'action'          => mb_substr($action, 0, 60),
        'actor_type'      => 'unknown',
        'users_id'        => 0,
        'participants_id' => 0,
        'payload_json'    => json_encode(['detail' => $detail, 'ip_hash' => hash('sha256', $ip)]),
        'date_creation'   => date('Y-m-d H:i:s'),
    ]);
}

function glpichat_assert_accept_not_rate_limited(string $ip): void
{
    global $DB;
    if ($ip === '') {
        return;
    }
    $since    = date('Y-m-d H:i:s', time() - glpichat_config_int('accept_rate_limit_window_s', 60));
    $ip_hash  = hash('sha256', $ip);
    $count    = 0;
    if (isset($DB) && $DB->tableExists('glpi_plugin_glpichat_auditlogs')) {
        $row = $DB->request([
            'COUNT' => 'cpt',
            'FROM'  => 'glpi_plugin_glpichat_auditlogs',
            'WHERE' => [
                'action'         => 'guest_accept_failed',
                ['date_creation' => ['>', $since]],
                ['payload_json'  => ['LIKE', '%' . $ip_hash . '%']],
            ],
        ])->current();
        $count = (int) ($row['cpt'] ?? 0);
    }
    if ($count >= glpichat_config_int('accept_rate_limit_max_attempts', 10)) {
        throw new GlpichatGuestException('accept_throttled', 'Muitas tentativas. Tente novamente mais tarde.', 429, glpichat_config_int('accept_rate_limit_window_s', 60));
    }
}

/** Bounded maintenance; active guest capabilities keep all delivery receipts. */
function glpichat_cleanup_guest_receipts(int $limit = 1000): int
{
    global $DB;
    if ((int) Config::getConfigurationValue('plugin:glpichat', 'desktop_schema_version') < 6) { return 0; }
    $days = max(30, (int) ceil(glpichat_guest_session_ttl_config_seconds() / 86400) + 1);
    $cutoff = date('Y-m-d H:i:s', time() - $days * 86400);
    require_once dirname(__DIR__) . '/desktop/common.php';
    $threshold = glpichat_desktop_quote($cutoff);
    $inactive = "NOT EXISTS (SELECT 1 FROM glpi_plugin_glpichat_participants p WHERE p.id=s.participants_id "
        . "AND ((p.left_at IS NULL AND COALESCE(p.last_activity,p.joined_at) >= $threshold) OR p.left_at >= $threshold))";
    $ids = array_column(glpichat_desktop_db_rows('SELECT s.id FROM glpi_plugin_glpichat_guestsends s WHERE s.created_at < '
        . $threshold . ' AND ' . $inactive . ' ORDER BY s.id LIMIT ' . max(1, min(1000, $limit))), 'id');
    if (!$ids) { return 0; }
    // Recheck state on deletion; a stale selection is not authority to purge.
    $DB->doQuery('DELETE s FROM glpi_plugin_glpichat_guestsends s WHERE s.id IN (' . implode(',', array_map('intval', $ids))
        . ') AND s.created_at < ' . $threshold . ' AND ' . $inactive);
    return (int) $DB->affectedRows();
}
