import {
  pluginBase,
  TERMINAL_TICKET_STATUSES
} from './modules/constants.js';

import {
  fetchJson,
  HttpRequestError,
  postForm
} from './modules/widget-http.js';

import {
  submitForm
} from './modules/dom.js';

import { sanitize } from './modules/sanitize.js';
import { createCoalescedSingleFlight } from './modules/scheduler.js';

import {
  isVisibleSystemEvent,
  formatSystemEventMessage,
  formatTypingMessage
} from './modules/format.js';

import {
  normalizeEventCursor,
  isNodeNearBottom,
  hasSelectionInsideNode,
} from './modules/shared.js';

import { ComposerDrafts, filesFromTransfer, renderDraftPanel } from "./modules/composer-drafts.js";
import { createClientMessageId } from "./modules/message-delivery.js";

"use strict";

const AUTO_SCROLL_THRESHOLD_PX = 160;

const pickLatestEventCursor = (currentValue, nextValue) => {
  const currentCursor = normalizeEventCursor(currentValue);
  const nextCursor = normalizeEventCursor(nextValue);
  if (currentCursor === "") {
    return nextCursor;
  }
  if (nextCursor === "") {
    return currentCursor;
  }
  return currentCursor.localeCompare(nextCursor) >= 0 ? currentCursor : nextCursor;
};

const statusKeyFromCode = (status) => {
  const code = Number(status || 0);
  if (code === 1) {
    return "new";
  }
  if (code === 2 || code === 3) {
    return "processing";
  }
  if (code === 4) {
    return "pending";
  }
  return "other";
};

const statusLabel = (statusKey) => {
  if (statusKey === "new") {
    return "Novo";
  }
  if (statusKey === "processing") {
    return "Processando";
  }
  if (statusKey === "pending") {
    return "Pendente";
  }
  return "Outros";
};

const ticketStatusLabel = (statusCode) => {
  const code = Number(statusCode || 0);
  if (code === 5) {
    return "Solucionado";
  }
  if (code === 6) {
    return "Fechado";
  }
  return statusLabel(statusKeyFromCode(code));
};

const applyGuestComposerState = (guestRoot, ticketStatus, isSessionExpired = false) => {
  if (!(guestRoot instanceof HTMLElement)) {
    return;
  }

  const archived = isSessionExpired || TERMINAL_TICKET_STATUSES.has(Number(ticketStatus || 0));
  const form = guestRoot.querySelector("[data-role='guest-send-form']");
  if (!(form instanceof HTMLElement)) {
    return;
  }

  const messagesEl = guestRoot.querySelector("[data-role='messages']");

  let message = `Este chamado está ${ticketStatusLabel(ticketStatus).toLowerCase()}. O chat foi arquivado.`;
  if (isSessionExpired) {
    message = "Sessão expirada ou revogada. O chat foi encerrado.";
  }

  let archivedNotice = guestRoot.querySelector("[data-role='guest-archived-notice']");
  if (archived) {
    if (!(archivedNotice instanceof HTMLElement)) {
      archivedNotice = document.createElement("div");
      archivedNotice.className = "glpichat-empty glpichat-archived-notice";
      archivedNotice.setAttribute("data-role", "guest-archived-notice");
      if (messagesEl instanceof HTMLElement) {
        messagesEl.appendChild(archivedNotice);
      }
    }
    archivedNotice.textContent = message;
    archivedNotice.hidden = false;
    if (messagesEl instanceof HTMLElement) {
      messagesEl.style.alignContent = 'center';
      messagesEl.style.justifyItems = 'center';
      messagesEl.style.textAlign = 'center';
    }
  } else if (archivedNotice instanceof HTMLElement) {
    archivedNotice.hidden = true;
    if (messagesEl instanceof HTMLElement) {
      messagesEl.style.alignContent = '';
      messagesEl.style.justifyItems = '';
      messagesEl.style.textAlign = '';
    }
  }

  // Keep selected files and text visible when the ticket/session becomes read-only.
  form.style.display = '';

  const textarea = form.querySelector("textarea");
  const fileInput = form.querySelector("input[type='file']");
  const submitButton = form.querySelector("button[type='submit']");
  const attachButton = form.querySelector(".glpichat-attach");

  if (textarea instanceof HTMLTextAreaElement) {
    textarea.disabled = archived;
    textarea.readOnly = archived;
    textarea.placeholder = archived ? message : "Escreva uma mensagem...";
  }
  if (fileInput instanceof HTMLInputElement) {
    fileInput.disabled = archived;
  }
  if (submitButton instanceof HTMLButtonElement) {
    submitButton.disabled = archived;
  }
  if (attachButton instanceof HTMLElement) {
    attachButton.style.pointerEvents = archived ? "none" : "";
    attachButton.style.opacity = archived ? "0.5" : "";
  }
};

const bootstrapGuest = async (guestRoot) => {
  let lastMessageId = 0;
  let lastEventId = "";
  let initialSyncDone = false;
  let isExpired = false;
  let guestIsTyping = false;
  let guestTypingTimeout = null;
  let leaveNotificationSent = false;
  let countdownIntervalId = null;
  let syncIntervalId = null;
  const expectedParticipantId = String(window.__glpichatConfig?.current_participant_id || 0);
  const expectedRoomId = String(guestRoot.dataset.roomId || 0);
  const messages = guestRoot.querySelector("[data-role='messages']");
  const form = guestRoot.querySelector("[data-role='guest-send-form']");
  const deliveredIds = new Set();
  let refreshOffset = 0;
  const pendingConfirmations = new Map();
  const outgoing = new Map();
  let continueOutgoing = () => Promise.resolve();
  const drafts = new ComposerDrafts(`glpichat-reselection:${pluginBase}:guest`);
  const draftKey = `${window.__glpichatConfig?.current_participant_id || 0}:${guestRoot.dataset.ticketId || 0}:public`;
  let currentTicketStatus = 0;
  const renderDraft = () => renderDraftPanel(form, drafts.get(draftKey),
    `Chamado #${guestRoot.dataset.ticketId || ""} · Solicitante`,
    (id) => { drafts.remove(draftKey, id); renderDraft(); },
    () => { drafts.get(draftKey).error = ""; renderDraft(); });
  const captureDraft = () => drafts.setText(draftKey, form.querySelector("textarea").value);
  const connectionStatus = document.createElement("div");
  connectionStatus.className = "glpichat-empty";
  connectionStatus.setAttribute("role", "status");
  connectionStatus.hidden = true;
  messages.after(connectionStatus);

  const head = guestRoot.querySelector(".glpichat-window-head");
  let countdownEl = null;
  if (head) {
    countdownEl = document.createElement("span");
    countdownEl.className = "glpichat-countdown";
    head.appendChild(countdownEl);
  }
  let secondsRemaining = 0;

  const updateCountdownDisplay = () => {
    if (!countdownEl) return;
    if (secondsRemaining <= 0) {
      isExpired = true;
      countdownEl.textContent = "Sessão expirada";
      countdownEl.classList.add("is-expired");
      applyGuestComposerState(guestRoot, 0, true);
      return;
    }
    const mins = Math.floor(secondsRemaining / 60);
    const secs = secondsRemaining % 60;
    countdownEl.textContent = `Expira em ${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
  };

  const stopTimers = () => {
    window.clearInterval(countdownIntervalId);
    window.clearInterval(syncIntervalId);
    countdownIntervalId = syncIntervalId = null;
    if (guestTypingTimeout) { clearTimeout(guestTypingTimeout); guestTypingTimeout = null; }
    guestIsTyping = false;
  };
  const endAccessLocally = (reason = "Sessão expirada", contextChanged = false) => {
    isExpired = true;
    secondsRemaining = 0;
    stopTimers();
    if (guestTypingTimeout) { clearTimeout(guestTypingTimeout); guestTypingTimeout = null; }
    if (contextChanged) messages.replaceChildren();
    else messages.querySelectorAll("[data-message-id]").forEach((node) => node.remove());
    deliveredIds.clear();
    updateCountdownDisplay();
    if (countdownEl) countdownEl.textContent = contextChanged ? "Acesso alterado" : reason;
    applyGuestComposerState(guestRoot, 0, true);
    const notice = guestRoot.querySelector("[data-role='guest-archived-notice']");
    if (notice) notice.textContent = reason;
    connectionStatus.textContent = reason;
    connectionStatus.hidden = false;
    const endButton = guestRoot.querySelector("[data-role='guest-end-access']");
    if (endButton) endButton.disabled = true;
  };
  const changedAccessMessage = "Outro convite foi aberto neste navegador. Esta conversa foi pausada; seu rascunho pertence ao acesso anterior e não será enviado ao novo convite.";

  const addMessage = (message, skipAnimation = false) => {
    const own = message.actor_type === "guest" && Number(message.participants_id || 0) === Number(window.__glpichatConfig?.current_participant_id || 0);
    const item = document.createElement("div");
    const isNew = !skipAnimation && !message.is_optimistic;
    item.className = `glpichat-message ${own ? "is-own" : "is-other"}${isNew ? " is-new" : ""}${message.is_optimistic ? " is-optimistic" : ""}`;
    
    let bodyHtml = "";
    if (Number(message.documents_id || 0) > 0) {
      const contentStr = String(message.content || "");
      const filename = contentStr.includes(":") 
        ? contentStr.split(":").slice(1).join(":").trim() 
        : contentStr;
      
      const attachmentUrl = String(message.attachment_url || "");
      const allowedPrefix = `${pluginBase}/Guest/Attachment/`;
      bodyHtml = attachmentUrl.startsWith(allowedPrefix)
        ? `<a class="glpichat-attachment-link" href="${sanitize(attachmentUrl)}" download="${sanitize(filename)}">${sanitize(filename)}</a>`
        : `<span>${sanitize(filename)} · Download indisponível nesta sessão</span>`;
    } else {
      bodyHtml = sanitize(message.content);
    }

    item.innerHTML = `
      <div class="glpichat-message-head">${sanitize(message.sender_name || (own ? "Você" : "Suporte"))}</div>
      <div class="glpichat-message-body">${bodyHtml}</div>
      <div class="glpichat-message-time">${sanitize(message.date_creation || "")}</div>
    `;
    if (Number(message.id) > 0) item.dataset.messageId = String(message.id);
    messages.appendChild(item);
    return item;
  };

  const addEvent = (event, skipAnimation = false) => {
    if (!isVisibleSystemEvent(event)) {
      return;
    }

    // Supported event types include: guest_joined, guest_left, guest_left_timeout,
    // user_joined, user_left, ticket_status_changed, ticket_priority_changed,
    // ticket_urgency_changed, ticket_impact_changed, ticket_type_changed,
    // ticket_category_changed, ticket_assigned_users_changed,
    // ticket_assigned_groups_changed, ticket_followup_added,
    // messages_purged (payload: { purged_before: "YYYY-MM-DD" })
    // Formatting is delegated to formatSystemEventMessage in modules/format.js
    const item = document.createElement("div");
    item.className = `glpichat-message is-system${skipAnimation ? "" : " is-new"}`;
    item.innerHTML = `
      <div class="glpichat-message-head">Sistema</div>
      <div class="glpichat-message-body">${sanitize(formatSystemEventMessage(event))}</div>
      <div class="glpichat-message-time">${sanitize(event.date_creation || "")}</div>
    `;
    messages.appendChild(item);
  };

  const notifyGuestLeave = async () => {
    if (leaveNotificationSent || isExpired) return;
    captureDraft();
    if ((drafts.hasAny() || outgoing.size) && !window.confirm("Há rascunhos ou envios pendentes. Encerrar este acesso? Os itens locais não serão enviados a outro convite.")) return;
    leaveNotificationSent = true;
    const endButton = guestRoot.querySelector("[data-role='guest-end-access']");
    if (endButton) endButton.disabled = true;
    const leaveForm = new FormData();
    leaveForm.set("expected_participant_id", expectedParticipantId);
    leaveForm.set("expected_rooms_id", expectedRoomId);
    try {
      await postForm(`${pluginBase}/Guest/Leave`, leaveForm, { useSharedQueue: false });
      endAccessLocally("Acesso encerrado.");
    } catch (error) {
      leaveNotificationSent = false;
      if (error.code === "guest_context_changed") endAccessLocally(changedAccessMessage, true);
      else {
        connectionStatus.textContent = `Não foi possível confirmar o encerramento: ${error.message}. Tente novamente.`;
        connectionStatus.hidden = false;
        if (endButton) endButton.disabled = false;
      }
    }
  };

  const syncGuest = createCoalescedSingleFlight(async () => {
    if (isExpired) return;
    try {
      const shouldAutoScroll = !hasSelectionInsideNode(messages)
        && (isNodeNearBottom(messages, window.__glpichatConfig?.auto_scroll_threshold_px ?? AUTO_SCROLL_THRESHOLD_PX) || !initialSyncDone);
      const params = new URLSearchParams({
        last_message_id: String(lastMessageId),
        last_event_id: String(lastEventId),
        is_typing: guestIsTyping ? "1" : "0",
        expected_participant_id: expectedParticipantId,
        expected_rooms_id: expectedRoomId,
      });
      const retainedIds = Array.from(deliveredIds);
      refreshOffset %= Math.max(1, retainedIds.length);
      const visibleIds = retainedIds.slice(refreshOffset, refreshOffset + 200);
      refreshOffset += visibleIds.length;
      visibleIds.forEach((id) => params.append("visible_message_ids[]", String(id)));
      const data = await fetchJson(`${pluginBase}/Guest/Sync?${params.toString()}`, { useSharedQueue: false });
      if (isExpired) return;
      if (!Array.isArray(data.messages) || !Array.isArray(data.events)) {
        throw new HttpRequestError("Resposta de histórico incompleta.", { kind: "invalid_payload" });
      }
      connectionStatus.hidden = true;
      currentTicketStatus = Number(data.ticket_status || 0);
      applyGuestComposerState(guestRoot, currentTicketStatus);

      if (typeof data.session_remaining_seconds === "number") {
        const diff = Math.abs(data.session_remaining_seconds - secondsRemaining);
        if (!initialSyncDone || data.session_remaining_seconds > secondsRemaining || diff > 10 || data.session_remaining_seconds <= 0) {
          secondsRemaining = data.session_remaining_seconds;
          updateCountdownDisplay();
        }
      }

      const typingIndicator = guestRoot.querySelector("[data-role='typing-indicator']");
      if (typingIndicator) {
        if (Array.isArray(data.typing_names) && data.typing_names.length > 0) {
          typingIndicator.textContent = formatTypingMessage(data.typing_names);
          typingIndicator.hidden = false;
        } else {
          typingIndicator.hidden = true;
        }
      }
      
      for (const id of data.removed_message_ids || []) {
        messages.querySelector(`[data-message-id="${Number(id)}"]`)?.remove();
        deliveredIds.delete(Number(id));
      }
      for (const message of data.refreshed_messages || []) {
        const existing = messages.querySelector(`[data-message-id="${Number(message.id)}"]`);
        if (existing) {
          const updated = addMessage(message, true);
          existing.replaceWith(updated);
        }
      }
      let receiptConfirmed = false;
      for (const message of data.messages || []) {
        const id = Number(message.id || 0);
        if (!Number.isSafeInteger(id) || id <= 0) continue;
        const receipt = message.actor_type === "guest"
          && Number(message.participants_id) === Number(window.__glpichatConfig?.current_participant_id)
          ? outgoing.get(String(message.client_message_id || "")) : null;
        if (receipt) {
          receipt.confirmed = id;
          receipt.node.remove();
          outgoing.delete(receipt.id);
          receiptConfirmed = true;
        }
        if (pendingConfirmations.has(id)) {
          pendingConfirmations.get(id).remove();
          pendingConfirmations.delete(id);
        }
        if (deliveredIds.has(id)) continue;
        deliveredIds.add(id);
        addMessage(message, !initialSyncDone);
        lastMessageId = Math.max(lastMessageId, id);
      }
      if (receiptConfirmed) continueOutgoing().catch(console.error);
      for (const event of data.events || []) {
        addEvent(event, !initialSyncDone);
        lastEventId = pickLatestEventCursor(lastEventId, event.id);
      }
      if (shouldAutoScroll) {
        messages.scrollTop = messages.scrollHeight;
      }
      lastMessageId = Math.max(lastMessageId, Number(data.next_message_id || 0));
      initialSyncDone = true;
    } catch (err) {
      // A proxy/network failure is not proof that the invitation expired.
      // Keep the existing countdown and bounded polling alive until the
      // server rejects the guest session or its actual lifetime ends.
      if (err.code === "guest_context_changed") {
        endAccessLocally(changedAccessMessage, true);
      } else if (err.kind === "http_error" && ([401, 410].includes(Number(err.status))
        || ["session_invalid", "session_expired", "guest_session_invalid", "guest_session_expired", "guest_session_revoked"].includes(err.code))) {
        endAccessLocally();
      } else {
        connectionStatus.textContent = "Conexão interrompida. Tentando atualizar as mensagens novamente...";
        connectionStatus.hidden = false;
      }
      throw err;
    }
  });

  if (form) {
    const textarea = form.querySelector("textarea");
    const fileInput = form.querySelector("input[type='file']");
    const panel = guestRoot.querySelector(".glpichat-chatbox-panel");
    // Validate the composed draft, not HTML's text-only required constraint.
    textarea.required = false;
    fileInput.multiple = true;
    const selectFiles = (files) => {
      captureDraft();
      drafts.add(draftKey, files);
      fileInput.value = "";
      renderDraft();
    };
    renderDraft();
    textarea.addEventListener("paste", (event) => {
      const files = filesFromTransfer(event.clipboardData);
      if (files.length) { selectFiles(files); event.preventDefault(); }
    });
    fileInput.addEventListener("change", () => selectFiles(fileInput.files));
    textarea.addEventListener("keydown", (event) => {
      if (event.key === "Enter" && !event.shiftKey && !event.isComposing) { event.preventDefault(); submitForm(form); }
    });
    textarea.addEventListener("input", () => {
      captureDraft();
      if (!guestIsTyping) { guestIsTyping = true; syncGuest().catch(console.error); }
      if (guestTypingTimeout) clearTimeout(guestTypingTimeout);
      guestTypingTimeout = setTimeout(() => { guestIsTyping = false; syncGuest().catch(console.error); }, window.__glpichatConfig?.typing_indicator_timeout_ms ?? 3000);
    });
    panel.addEventListener("dragover", (event) => { event.preventDefault(); panel.classList.add("drag-over"); });
    panel.addEventListener("dragleave", (event) => { if (!event.relatedTarget || !panel.contains(event.relatedTarget)) panel.classList.remove("drag-over"); });
    panel.addEventListener("drop", (event) => {
      event.preventDefault(); panel.classList.remove("drag-over"); selectFiles(filesFromTransfer(event.dataTransfer));
    });
    const setOutgoingStatus = (entry, label, retryable = true) => {
      const status = entry.node.querySelector(".glpichat-message-time");
      status.textContent = label;
      entry.node.querySelectorAll("button").forEach((button) => button.remove());
      if (entry.active) return;
      if (retryable) {
        const retry = document.createElement("button"); retry.type = "button";
        retry.textContent = "Verificar / tentar novamente";
        retry.dataset.action = "retry-guest-message";
        retry.addEventListener("click", () => pumpOutgoing().catch(console.error));
        entry.node.append(retry);
      }
      if (!entry.unknown) {
        const restore = document.createElement("button"); restore.type = "button";
        restore.textContent = "Restaurar ao rascunho";
        restore.dataset.action = "restore-guest-message";
        restore.addEventListener("click", () => {
          captureDraft();
          const draft = drafts.get(draftKey);
          const file = entry.form.get("file");
          if (file instanceof File && draft.files.length >= 10) {
            draft.error = "Remova um anexo do rascunho antes de restaurar este envio.";
            renderDraft(); return;
          }
          if (file instanceof File) drafts.add(draftKey, [file]);
          else draft.text = [String(entry.form.get("content") || ""), draft.text].filter(Boolean).join("\n");
          textarea.value = draft.text;
          outgoing.delete(entry.id); entry.node.remove(); renderDraft(); pumpOutgoing().catch(console.error);
        });
        entry.node.append(restore);
      }
      const discard = document.createElement("button"); discard.type = "button";
      discard.textContent = "Remover envio local";
      discard.addEventListener("click", () => {
        if (entry.unknown && !window.confirm("O chamado pode já ter recebido este envio. Remover este item local não exclui conteúdo do GLPI. Continuar?")) return;
        outgoing.delete(entry.id); entry.node.remove(); pumpOutgoing().catch(console.error);
      });
      entry.node.append(discard);
    };
    const pumpOutgoing = createCoalescedSingleFlight(async () => {
      while (outgoing.size && !isExpired) {
        const entry = outgoing.values().next().value;
        if (entry.blocked) return;
        entry.active = true;
        setOutgoingStatus(entry, "Enviando...");
        try {
          const result = await postForm(`${pluginBase}${entry.endpoint}`, entry.form, { useSharedQueue: false });
          const id = Number(result.message_id || 0);
          if (id <= 0 || (result.client_message_id && result.client_message_id !== entry.id)) throw new Error("Resposta sem confirmação do envio.");
          entry.confirmed = id;
          outgoing.delete(entry.id);
          if (deliveredIds.has(id)) entry.node.remove();
          else {
            pendingConfirmations.set(id, entry.node);
            entry.node.querySelector(".glpichat-message-time").textContent = "Enviado. Atualizando o histórico...";
          }
        } catch (error) {
          entry.active = false;
          if (entry.confirmed) { entry.node.remove(); outgoing.delete(entry.id); continue; }
          if (error.code === "message_unavailable") {
            outgoing.delete(entry.id);
            entry.node.classList.remove("is-optimistic");
            entry.node.querySelector(".glpichat-message-body").textContent = "Mensagem ou anexo indisponível.";
            entry.node.querySelector(".glpichat-message-time").textContent = "Enviado anteriormente.";
            entry.node.querySelectorAll("button").forEach((button) => button.remove());
            continue;
          }
          if (error.code === "guest_context_changed") {
            entry.blocked = true;
            endAccessLocally(changedAccessMessage, true);
            return;
          }
          const rejected = Number(error.status) >= 400 && Number(error.status) < 500 && Number(error.status) !== 408;
          entry.unknown = entry.hadUnknown === true || !rejected;
          if (entry.unknown) entry.hadUnknown = true;
          entry.blocked = [401, 409, 410].includes(Number(error.status));
          setOutgoingStatus(entry, !entry.unknown ? `Envio recusado: ${error.message}` : `Confirmação pendente. ${error.message || "Confira a conexão e verifique a entrega."}`, !entry.blocked);
          return;
        } finally { entry.active = false; }
        syncGuest().catch(console.error);
      }
    });
    continueOutgoing = pumpOutgoing;
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      captureDraft();
      const draft = drafts.get(draftKey);
      if (isExpired || TERMINAL_TICKET_STATUSES.has(currentTicketStatus)) {
        draft.error = "Esta sessão ou chamado não permite novos envios. O rascunho foi preservado.";
        renderDraft(); return;
      }
      guestIsTyping = false;
      if (guestTypingTimeout) { clearTimeout(guestTypingTimeout); guestTypingTimeout = null; }
      const content = draft.text.trim();
      const files = draft.files.slice();
      if (!content && !files.length) return;
      const submissionId = createClientMessageId();
      const count = files.length + (content ? 1 : 0);
      const enqueue = (text, file = null) => {
        const id = createClientMessageId();
        const operationForm = new FormData();
        operationForm.set("client_message_id", id);
        operationForm.set("submission_id", submissionId);
        operationForm.set("submission_count", String(count));
        operationForm.set("expected_participant_id", expectedParticipantId);
        operationForm.set("expected_rooms_id", expectedRoomId);
        if (file) operationForm.set("file", file, file.name);
        else operationForm.set("content", text);
        const node = document.createElement("div");
        node.className = "glpichat-message is-own is-optimistic";
        node.innerHTML = `<div class="glpichat-message-head">Você</div><div class="glpichat-message-body">${sanitize(text)}</div><div class="glpichat-message-time">Na fila desta conversa.</div>`;
        messages.append(node);
        outgoing.set(id, { id, form: operationForm, node, endpoint: file ? "/Guest/Upload" : "/Guest/Send", active: false, confirmed: 0, unknown: false, blocked: false });
      };
      if (content) enqueue(content);
      for (const item of files) enqueue(`Arquivo: ${item.file.name}`, item.file);
      drafts.clear(draftKey); textarea.value = ""; fileInput.value = ""; renderDraft();
      messages.scrollTop = messages.scrollHeight;
      await pumpOutgoing();
      syncGuest().catch(console.error);
    });
    window.addEventListener("beforeunload", (event) => {
      captureDraft();
      if (drafts.hasAny() || outgoing.size) { event.preventDefault(); event.returnValue = ""; }
    });
  }

  const startTimers = () => {
    stopTimers();
    if (isExpired) return;
    countdownIntervalId = window.setInterval(() => {
      if (secondsRemaining > 0 && !isExpired) { secondsRemaining--; updateCountdownDisplay(); }
    }, 1000);
    syncIntervalId = window.setInterval(() => {
      if (document.visibilityState === "visible" && !isExpired) syncGuest().catch(console.error);
    }, window.__glpichatConfig?.guest_poll_ms ?? 5000);
  };
  guestRoot.querySelector("[data-role='guest-end-access']")?.addEventListener("click", () => notifyGuestLeave().catch(console.error));
  window.addEventListener("pagehide", stopTimers, { capture: true });
  window.addEventListener("pageshow", (event) => {
    if (event.persisted && !isExpired) { startTimers(); syncGuest().catch(console.error); }
  });
  startTimers();
  try {
    await syncGuest();
  } catch (error) { console.error("Initial guest sync failed:", error); }

};

const bootGuest = () => {
  const guestRoot = document.querySelector(".glpichat[data-guest='1']");
  if (guestRoot) {
    bootstrapGuest(guestRoot).catch(console.error);
  }
};

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", bootGuest, { once: true });
} else {
  bootGuest();
}
