/** Browser delivery state is confirmed by a server message, never by matching text. */
let optimisticSequence = 0;

export const createClientMessageId = () => {
  const bytes = new Uint8Array(16);
  if (globalThis.crypto?.getRandomValues) {
    globalThis.crypto.getRandomValues(bytes);
  } else {
    // Correlation identifier, not an authentication secret. Keep HTTP labs usable.
    for (let i = 0; i < bytes.length; i += 1) bytes[i] = Math.floor(Math.random() * 256);
  }
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
};

export const createOptimisticMessage = (content, userId, clientMessageId = "") => ({
  id: -(Date.now() * 1000 + (++optimisticSequence % 1000)),
  actor_type: "user",
  users_id: userId,
  sender_name: "Você",
  content,
  date_creation: new Date().toISOString().replace("T", " ").slice(0, 19),
  client_message_id: clientMessageId,
  is_optimistic: true,
  delivery_state: "sending",
  confirmed_message_id: 0,
});

export const lastConfirmedMessageId = (channel) => {
  const cursor = Number(channel?.last_message_id);
  if (Number.isFinite(cursor) && cursor >= 0) return cursor;
  return Math.max(0, ...(channel?.messages || []).filter((message) => !message.is_optimistic)
    .map((message) => Math.max(0, Number(message.id || 0))));
};

const sameReceipt = (optimistic, confirmed) => optimistic.is_optimistic === true
  && Number(confirmed.id || 0) > 0
  && confirmed.actor_type === "user"
  && Number(optimistic.users_id || 0) === Number(confirmed.users_id || 0)
  && String(optimistic.client_message_id || "") !== ""
  && optimistic.client_message_id === confirmed.client_message_id;

export const mergeConfirmedMessages = (channel, incomingMessages) => {
  if (!channel || !Array.isArray(incomingMessages)) return;
  const incoming = incomingMessages.filter((message) => Number(message.id || 0) > 0);
  const merged = (channel.messages || []).filter((message) => {
    const receipt = incoming.find((confirmed) => sameReceipt(message, confirmed));
    if (!receipt) return true;
    // The in-flight POST retains this reference and must ignore a later proxy error.
    message.confirmed_message_id = Number(receipt.id);
    return false;
  });
  const seen = new Set(merged.map((message) => Number(message.id || 0)));
  for (const message of incoming) {
    if (seen.has(Number(message.id))) continue;
    seen.add(Number(message.id));
    merged.push(message);
  }
  merged.sort((a, b) => {
    if (Boolean(a.is_optimistic) !== Boolean(b.is_optimistic)) return a.is_optimistic ? 1 : -1;
    return a.is_optimistic ? Number(b.id) - Number(a.id) : Number(a.id) - Number(b.id);
  });
  channel.messages = merged;
};

export const reconcileConfirmedMessage = (channel, optimistic, confirmed) => {
  if (!channel || !confirmed || Number(confirmed.id || 0) <= 0) return false;
  if (optimistic?.client_message_id && !sameReceipt(optimistic, confirmed)) return false;
  if (optimistic) {
    optimistic.confirmed_message_id = Number(confirmed.id);
    channel.messages = (channel.messages || []).filter((message) => message.id !== optimistic.id);
  }
  mergeConfirmedMessages(channel, [confirmed]);
  // Do not advance the incremental Poll cursor here: older messages may still
  // be in flight. Poll must fetch the whole interval before advancing it.
  return true;
};

export const applyDeliveryFailure = (message, error) => {
  if (Number(message?.confirmed_message_id || 0) > 0) return "confirmed";
  const status = Number(error?.status || 0);
  const currentRejection = error?.kind === "queue_expired"
    || (status >= 400 && status < 500 && status !== 408);
  // A later authorization/policy rejection may happen before receipt lookup.
  // It cannot disprove persistence during an earlier lost response.
  const definiteRejection = currentRejection && message.delivery_had_unknown !== true;
  if (!definiteRejection) message.delivery_had_unknown = true;
  message.delivery_state = definiteRejection ? "failed" : "unconfirmed";
  message.delivery_retryable = status !== 409;
  message.delivery_error = definiteRejection
    ? String(error?.message || (status > 0 ? `HTTP ${status}` : "Solicitação recusada")).slice(0, 300)
    : String(error?.message || "").slice(0, 300);
  return message.delivery_state;
};

export const deliveryLabel = (message) => {
  if (!message.is_optimistic) return String(message.date_creation || "");
  if (message.delivery_state === "queued") return "Na fila desta conversa.";
  if (message.delivery_state === "failed") return `Envio recusado: ${message.delivery_error || "tente novamente"}`;
  if (message.delivery_state === "unconfirmed") return message.client_message_id
    ? `Confirmação pendente. Use Verificar entrega.${message.delivery_error ? ` ${message.delivery_error}` : ""}`
    : "Confirmação do arquivo pendente. Confira o histórico antes de enviar novamente.";
  return "Enviando...";
};
