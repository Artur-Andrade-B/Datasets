/** In-page drafts are independent of controls, chat windows and network reads. */
export class ComposerDrafts {
  constructor(storageKey = "glpichat-composer-reselection") {
    this.entries = new Map();
    this.sequence = 0;
    this.storageKey = storageKey;
    this.reselection = {};
    try {
      const saved = JSON.parse(sessionStorage.getItem(storageKey) || "{}");
      if (saved && typeof saved === "object" && !Array.isArray(saved)) this.reselection = saved;
    } catch (_) { /* Storage restrictions must not prevent in-page drafts. */ }
  }
  rememberFiles(key, files) {
    if (files.length) this.reselection[key] = files.map((item) => String(item.file.name)).slice(0, 10);
    else delete this.reselection[key];
    try { sessionStorage.setItem(this.storageKey, JSON.stringify(this.reselection)); } catch (_) { /* In-page draft remains valid. */ }
  }
  get(key) {
    if (!this.entries.has(key)) {
      const names = Array.isArray(this.reselection[key]) ? this.reselection[key].map(String).slice(0, 10) : [];
      this.entries.set(key, { text: "", files: [], error: names.length
        ? `A página foi recarregada. Selecione novamente os anexos antes de enviar: ${names.join(", ")}.` : "" });
    }
    return this.entries.get(key);
  }
  has(key) {
    const draft = this.entries.get(key);
    return Boolean(draft && (draft.text !== "" || draft.files.length || draft.error));
  }
  hasAny() { return Array.from(this.entries.keys()).some((key) => this.has(key)); }
  setText(key, text) { this.get(key).text = String(text || ""); }
  add(key, files) {
    const draft = this.get(key);
    for (const file of Array.from(files || [])) {
      if (!(file instanceof File)) continue;
      // Repeated picker/paste events do not silently create duplicate selections.
      if (draft.files.some((item) => item.file === file)) continue;
      if (draft.files.length >= 10) {
        draft.error = "Selecione até 10 anexos por envio. Os arquivos excedentes não foram adicionados.";
        break;
      }
      draft.files.push({ id: ++this.sequence, file });
    }
    if (draft.files.length && draft.error.startsWith("A página foi recarregada.")) draft.error = "";
    this.rememberFiles(key, draft.files);
    return draft;
  }
  remove(key, id) {
    const draft = this.get(key);
    draft.files = draft.files.filter((item) => item.id !== Number(id));
    this.rememberFiles(key, draft.files);
  }
  clear(key) { this.entries.delete(key); this.rememberFiles(key, []); }
  clearAll() {
    this.entries.clear(); this.reselection = {};
    try { sessionStorage.removeItem(this.storageKey); } catch (_) { /* Optional recovery metadata. */ }
  }
}

export const filesFromTransfer = (transfer) => {
  if (!transfer) return [];
  if (transfer.files?.length) return Array.from(transfer.files).filter((file) => file instanceof File);
  return Array.from(transfer.items || []).filter((item) => item?.kind === "file")
    .map((item) => item.getAsFile()).filter((file) => file instanceof File);
};

export const fileSizeLabel = (bytes) => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1048576).toFixed(1)} MB`;
};

/** A separate bounded row keeps files/errors visible without replacing chat status. */
export const renderDraftPanel = (form, draft, destination, remove, dismiss) => {
  let panel = form.querySelector("[data-role='draft-panel']");
  if (!panel) {
    panel = document.createElement("div");
    panel.dataset.role = "draft-panel";
    panel.className = "glpichat-draft-panel";
    form.prepend(panel);
  }
  panel.replaceChildren();
  const label = document.createElement("div");
  label.className = "glpichat-draft-destination";
  label.textContent = destination;
  panel.append(label);
  if (draft.files.length) {
    const list = document.createElement("ul");
    list.className = "glpichat-draft-files";
    list.setAttribute("aria-label", "Anexos selecionados, ainda não enviados");
    for (const item of draft.files) {
      const row = document.createElement("li");
      const name = document.createElement("span");
      name.className = "glpichat-draft-filename";
      name.textContent = item.file.name;
      name.title = item.file.name;
      const size = document.createElement("small");
      size.textContent = `${fileSizeLabel(item.file.size)} · Selecionado`;
      const button = document.createElement("button");
      button.type = "button";
      button.className = "glpichat-draft-remove";
      button.textContent = "×";
      button.setAttribute("aria-label", `Remover ${item.file.name}`);
      button.addEventListener("click", () => remove(item.id));
      row.append(name, size, button);
      list.append(row);
    }
    panel.append(list);
  }
  if (draft.error) {
    const error = document.createElement("div");
    error.className = "glpichat-draft-error";
    error.setAttribute("role", "alert");
    const text = document.createElement("span");
    text.textContent = draft.error;
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = "Dispensar";
    button.addEventListener("click", dismiss);
    error.append(text, button);
    panel.append(error);
  }
};
