<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpichat\Controller;

use Glpi\Controller\AbstractController;
use Glpi\Http\Firewall;
use Glpi\Http\RedirectResponse;
use Glpi\Security\Attribute\SecurityStrategy;
use RuntimeException;
use Symfony\Component\HttpFoundation\Cookie;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

use function glpichat_assert_accept_not_rate_limited;
use function glpichat_config_int;
use function glpichat_events;
use function glpichat_guest_participant;
use function glpichat_guest_session_ttl_config_seconds;
use function glpichat_log_auth_failure;
use function glpichat_room_by_id;

use const GLPICHAT_GUEST_COOKIE;

require_once dirname(__DIR__) . '/functions.php';
require_once dirname(__DIR__) . '/flows/guest_flow.php';
require_once dirname(__DIR__) . '/guest_delivery.php';

final class GuestController extends AbstractController
{
    #[Route('/Accept/{token}', name: 'glpichat_accept', methods: ['GET'])]
    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]
    public function accept(Request $request, string $token): Response
    {
        try {
            glpichat_assert_accept_not_rate_limited($request->getClientIp() ?? '');
            if (!preg_match('/\A[a-f0-9]{64}\z/D', $token)) {
                throw new \GlpichatGuestException('invite_unavailable', 'Convite inválido ou indisponível.', 403);
            }
            $claimName = 'glpichat_guest_claim_' . substr(hash('sha256', $token), 0, 16);
            $claim = $request->cookies->get($claimName, '');
            if (!is_string($claim) || !preg_match('/\A[a-f0-9]{64}\z/D', $claim)) {
                // First deliver a browser-private recovery secret. No invitation is consumed yet.
                $response = new RedirectResponse($this->rootDoc() . '/plugins/glpichat/Accept/' . $token);
                $response->headers->setCookie($this->guestCookie($request, $claimName, bin2hex(random_bytes(32)))->withSameSite('Lax'));
                $response->headers->set('Cache-Control', 'no-store');
                $response->headers->set('Referrer-Policy', 'no-referrer');
                return $response;
            }
            $accepted = \glpichat_guest_accept_atomic($token, $claim);
            $response = new RedirectResponse($this->rootDoc() . '/plugins/glpichat/Guest');
            $response->headers->setCookie($this->guestCookie($request, GLPICHAT_GUEST_COOKIE, $accepted['session_token']));
            $response->headers->set('Cache-Control', 'no-store');
            $response->headers->set('Referrer-Policy', 'no-referrer');
            return $response;
        } catch (\Throwable $error) {
            [$status, $body] = $this->failure($error, 'accept');
            if ($status >= 400 && $status < 500 && $status !== 429) {
                glpichat_log_auth_failure('guest_accept_failed', $body['code'], $request->getClientIp() ?? '');
            }
            return new Response($this->errorHtml($body['error'], $status >= 500 ? 'Tente abrir este mesmo link novamente.' : 'Entre em contato com quem lhe enviou o convite.'), $status);
        }
    }

    #[Route('/Guest', name: 'glpichat_guest_page', methods: ['GET'])]
    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]
    public function page(Request $request): Response
    {
        $session_token = $request->cookies->get(GLPICHAT_GUEST_COOKIE, '');
        if ($session_token === '') {
            return new Response($this->errorHtml('Sessão de acesso inválida ou ausente.'), 401);
        }
        try {
            $participant = glpichat_guest_participant($session_token);
            $room = glpichat_room_by_id((int) $participant['rooms_id']);
            if ($room['room_type'] !== 'public' || !\glpichat_guest_row('SELECT id FROM glpi_tickets WHERE id=' . (int) $room['tickets_id'] . ' AND is_deleted=0')) { throw new \GlpichatGuestException('conversation_unavailable', 'Conversa indisponível.', 403); }
            $nonce = base64_encode(random_bytes(16));
            $response = new Response($this->guestHtml((int) $room['tickets_id'], (int) $participant['rooms_id'], (string) $participant['guest_name'], $nonce, (int) $participant['id']));
            $response->headers->set('Cache-Control', 'no-store');
            $response->headers->set('X-Frame-Options', 'DENY');
            $response->headers->set('Content-Security-Policy', "default-src 'self'; style-src 'self'; script-src 'self' 'nonce-{$nonce}'");
            $response->headers->set('Referrer-Policy', 'no-referrer');
            return $response;
        } catch (\Throwable $error) {
            [$status, $body] = $this->failure($error, 'page');
            return new Response($this->errorHtml($body['error']), $status);
        }
    }

    #[Route('/Guest/Sync', name: 'glpichat_guest_sync', methods: ['GET'])]
    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]
    public function sync(Request $request): Response
    {
        try {
            \glpichat_guest_require_context($request->query->all());
            $token = $request->cookies->get(GLPICHAT_GUEST_COOKIE, '');
            $participant = glpichat_guest_participant($token);
            \glpichat_guest_assert_context($participant, $request->query->all());
            $room = glpichat_room_by_id((int) $participant['rooms_id']);
            if ($room['room_type'] !== 'public') { throw new \GlpichatGuestException('conversation_unavailable', 'Conversa indisponível.', 403); }
            $ticket = \glpichat_guest_row('SELECT id,status FROM glpi_tickets WHERE id=' . (int) $room['tickets_id'] . ' AND is_deleted=0');
            if (!$ticket) { throw new \GlpichatGuestException('conversation_unavailable', 'Conversa indisponível.', 403); }
            $page = \glpichat_message_page((int) $room['id'], max(0, $request->query->getInt('last_message_id')), (string) $participant['joined_at']);
            $visibleIds = $request->query->all('visible_message_ids');
            if (count($visibleIds) > 200 || array_filter($visibleIds, static fn($id): bool => !is_scalar($id) || !ctype_digit((string) $id))) { throw new \GlpichatGuestException('invalid_message_ids', 'Janela de mensagens inválida.', 400); }
            $refreshed = \glpichat_refresh_messages((int) $room['id'], $visibleIds, (string) $participant['joined_at']);
            $cursor = $request->query->getString('last_event_id');
            $cursor = \glpichat_guest_event_cursor((string) $participant['joined_at'], $cursor);
            \glpichat_update_participant_activity((int) $participant['id'], $request->query->getBoolean('is_typing'));
            $result = ['messages' => \glpichat_guest_decorate_messages($page['messages'], $participant),
                'next_message_id' => $page['next_message_id'], 'has_more' => $page['has_more'],
                'refreshed_messages' => \glpichat_guest_decorate_messages($refreshed['refreshed_messages'], $participant),
                'removed_message_ids' => $refreshed['removed_message_ids'],
                'events' => glpichat_events((int) $room['id'], $cursor), 'ticket_status' => (int) $ticket['status'],
                'session_remaining_seconds' => glpichat_guest_session_ttl_config_seconds(),
                'typing_names' => \glpichat_get_typing_participants((int) $room['id'], (int) $participant['id'])];
            $response = new JsonResponse($result);
            $response->headers->setCookie($this->guestCookie($request, GLPICHAT_GUEST_COOKIE, $token));
            $response->headers->set('Cache-Control', 'no-store');
            return $response;
        } catch (\Throwable $error) {
            return $this->jsonFailure($error, 'sync');
        }
    }

    #[Route('/Guest/Leave', name: 'glpichat_guest_leave', methods: ['POST'])]
    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]
    public function leave(Request $request): Response
    {
        $session_token = $request->cookies->get(GLPICHAT_GUEST_COOKIE, '');
        try {
            \glpichat_guest_require_context($request->request->all());
            $participant = glpichat_guest_participant($session_token);
            \glpichat_guest_assert_context($participant, $request->request->all());
            \glpichat_disconnect_participant((int) $participant['id'], date('Y-m-d H:i:s'));
        } catch (\Throwable $error) {
            if (!$error instanceof \GlpichatGuestException || $error->httpStatus !== 401) { return $this->jsonFailure($error, 'leave'); }
        }

        $response = new Response('', 204);
        $response->headers->clearCookie(GLPICHAT_GUEST_COOKIE, $this->rootDoc() . '/plugins/glpichat');
        return $response;
    }

    #[Route('/Guest/Send', name: 'glpichat_guest_send', methods: ['POST'])]
    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]
    public function send(Request $request): Response
    {
        try {
            \glpichat_guest_require_context($request->request->all());
            return new JsonResponse(\glpichat_guest_deliver($request->cookies->get(GLPICHAT_GUEST_COOKIE, ''), $request->request->all()));
        } catch (\Throwable $error) {
            return $this->jsonFailure($error, 'send');
        }
    }

    #[Route('/Guest/Upload', name: 'glpichat_guest_upload', methods: ['POST'])]
    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]
    public function upload(Request $request): Response
    {
        try {
            $type = strtolower(trim(explode(';', (string) $request->headers->get('Content-Type', ''))[0]));
            if ($type !== 'multipart/form-data') { throw new \GlpichatGuestException('multipart_required', 'Envie o anexo como multipart/form-data.', 415); }
            if ((int) $request->headers->get('Content-Length', '0') > 0 && (int) $request->headers->get('Content-Length', '0') > \glpichat_desktop_attachment_policy()['max_bytes'] + 65536) { throw new \GlpichatGuestException('attachment_too_large', 'O arquivo excede o limite do GLPI ou do servidor.', 413); }
            \glpichat_guest_require_context($request->request->all());
            $file = $request->files->get('file');
            if ($file === null) { throw new \GlpichatGuestException('invalid_attachment', 'Selecione um arquivo para enviar.', 400); }
            return new JsonResponse(\glpichat_guest_deliver($request->cookies->get(GLPICHAT_GUEST_COOKIE, ''), $request->request->all(), $file));
        } catch (\Throwable $error) {
            return $this->jsonFailure($error, 'upload');
        }
    }

    #[Route('/Guest/Attachment/{messageId}/{documentId}', name: 'glpichat_guest_attachment', requirements: ['messageId' => '[1-9][0-9]*', 'documentId' => '[1-9][0-9]*'], methods: ['GET'])]
    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]
    public function attachment(Request $request, int $messageId, int $documentId): Response
    {
        try {
            \glpichat_guest_require_context($request->query->all());
            return \glpichat_guest_download($request->cookies->get(GLPICHAT_GUEST_COOKIE, ''), $messageId, $documentId, $request->query->all());
        } catch (\Throwable $error) { return $this->jsonFailure($error, 'download'); }
    }

    private function rootDoc(): string
    {
        return rtrim((string) ($GLOBALS['CFG_GLPI']['root_doc'] ?? ''), '/');
    }

    private function guestCookie(Request $request, string $name, string $value): Cookie
    {
        return Cookie::create($name, $value)->withHttpOnly(true)->withSameSite('Strict')
            ->withSecure($request->isSecure())->withPath($this->rootDoc() . '/plugins/glpichat')
            ->withExpires(new \DateTimeImmutable('+' . glpichat_guest_session_ttl_config_seconds() . ' seconds'));
    }

    private function failure(\Throwable $error, string $stage): array
    {
        if ($error instanceof \GlpichatGuestException || $error instanceof \GlpichatDesktopException) {
            $body = ['error' => $error->getMessage(), 'code' => $error->errorCode] + ($error instanceof \GlpichatGuestException ? $error->details : []);
            if ($error instanceof \GlpichatGuestException && $error->retryAfter > 0) { $body['retry_after'] = $error->retryAfter; }
            return [$error->httpStatus, $body];
        }
        if ($error instanceof \Symfony\Component\HttpFoundation\Exception\RequestExceptionInterface) {
            return [400, ['error' => 'Parâmetros de solicitação inválidos.', 'code' => 'invalid_request']];
        }
        $reference = \glpichat_desktop_log_failure('guest_' . $stage, $error);
        return [503, ['error' => 'Serviço temporariamente indisponível. Referência: ' . $reference . '.', 'code' => 'temporarily_unavailable', 'reference' => $reference]];
    }

    private function jsonFailure(\Throwable $error, string $stage): JsonResponse
    {
        [$status, $body] = $this->failure($error, $stage);
        $response = new JsonResponse($body, $status);
        $response->headers->set('Cache-Control', 'no-store');
        if (isset($body['retry_after'])) { $response->headers->set('Retry-After', (string) $body['retry_after']); }
        return $response;
    }

    private function guestHtml(int $tickets_id, int $rooms_id, string $guest_name, string $nonce = '', int $participantId = 0): string
    {
        global $CFG_GLPI;
        $url_path = $this->rootDoc();
        $safe_url_path = htmlescape($url_path);

        $plugin_dir = dirname(__DIR__, 2);
        $css_version = file_exists($plugin_dir . '/public/css/glpichat.css') ? filemtime($plugin_dir . '/public/css/glpichat.css') : time();
        $js_version = file_exists($plugin_dir . '/public/js/glpichat-guest.js') ? filemtime($plugin_dir . '/public/js/glpichat-guest.js') : time();

        return '<!doctype html><html><head><meta charset="utf-8"><title>GLPI Chat</title>'
            . '<link rel="stylesheet" href="' . $safe_url_path . '/plugins/glpichat/public/css/glpichat.css?v=' . $css_version . '">'
            . '<meta name="viewport" content="width=device-width, initial-scale=1.0">'
            . '</head><body class="glpichat-guest-page">'
            . '<main class="glpichat glpichat-guest" data-ticket-id="' . htmlescape((string) $tickets_id) . '" data-room-id="' . htmlescape((string) $rooms_id) . '" data-guest="1">'
            . '<div class="glpichat-chatbox-panel">'
            . '  <div class="glpichat-dropzone-overlay">'
            . '    <span class="glpichat-dropzone-icon">'
            . '      <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>'
            . '    </span>'
            . '    <span>Solte o arquivo para adicionar ao envio</span>'
            . '  </div>'
            . '  <div class="glpichat-window-head">'
            . '    <strong>Chamado #' . htmlescape((string) $tickets_id) . '</strong>'
            . '    <span class="glpichat-guest-badge">' . htmlescape($guest_name) . '</span>'
            . '    <button type="button" data-role="guest-end-access">Encerrar acesso</button>'
            . '  </div>'
            . '  <div class="glpichat-messages" data-role="messages"></div>'
            . '  <div class="glpichat-typing-indicator" data-role="typing-indicator" hidden></div>'
            . '  <form class="glpichat-send" data-role="guest-send-form">'
            . '    <input id="guest-attach" class="glpichat-file-input" type="file" name="file" multiple>'
            . '    <label for="guest-attach" class="glpichat-attach" title="Anexar arquivo">'
            . '      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>'
            . '    </label>'
            . '    <textarea name="content" placeholder="Escreva uma mensagem..."></textarea>'
            . '    <button type="submit" class="glpichat-send-btn" title="Enviar mensagem">'
            . '      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>'
            . '    </button>'
            . '  </form>'
            . '</div>'
            . '</main>'
            . '<script' . ($nonce !== '' ? ' nonce="' . htmlescape($nonce) . '"' : '') . '>window.__glpichatConfig=' . json_encode([
                'root_doc' => $url_path,
                'current_participant_id' => $participantId,
                'guest_poll_ms'                => glpichat_config_int('guest_poll_ms', 5000),
                'auto_scroll_threshold_px'     => glpichat_config_int('auto_scroll_threshold_px', 160),
                'typing_indicator_timeout_ms'  => glpichat_config_int('typing_indicator_timeout_ms', 3000),
            ]) . ';</script>'
            . '<script src="' . $safe_url_path . '/plugins/glpichat/public/js/glpichat-guest.js?v=' . $js_version . '"></script></body></html>';
    }

    private function errorHtml(string $message, string $hint = ''): string
    {
        global $CFG_GLPI;
        $url_path = $this->rootDoc();
        $safe_url_path = htmlescape($url_path);

        $plugin_dir = dirname(__DIR__, 2);
        $css_version = file_exists($plugin_dir . '/public/css/glpichat.css') ? filemtime($plugin_dir . '/public/css/glpichat.css') : time();

        $hint_html = $hint !== ''
            ? '<p class="glpichat-error-hint">' . htmlescape($hint) . '</p>'
            : '';

        return '<!doctype html><html><head><meta charset="utf-8"><title>GLPI Chat</title>'
            . '<link rel="stylesheet" href="' . $safe_url_path . '/plugins/glpichat/public/css/glpichat.css?v=' . $css_version . '">'
            . '<meta name="viewport" content="width=device-width, initial-scale=1.0">'
            . '</head><body class="glpichat-guest-page">'
            . '<main class="glpichat glpichat-guest">'
            . '<div class="glpichat-chatbox-panel">'
            . '<div class="glpichat-window-head"><strong>GLPI Chat</strong></div>'
            . '<div class="glpichat-messages glpichat-error-screen">'
            . '<div class="glpichat-empty">'
            . '<p>' . htmlescape($message) . '</p>'
            . $hint_html
            . '</div>'
            . '</div>'
            . '</div>'
            . '</main>'
            . '</body></html>';
    }
}
