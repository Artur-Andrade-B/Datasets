<?php

declare(strict_types=1);

/** Advisory runtime telemetry is separate from installed-payload validation.
 * It never completes an assignment and an old client cannot refresh an old
 * interactive snapshot merely by continuing to report its installed files. */
function glpichat_management_runtime_store(array $input, ?string $previous): ?string
{
    if (!array_key_exists('runtime_state', $input)) {
        $old = is_string($previous) ? json_decode($previous, true, 8) : null;
        if (!is_array($old)) { return null; }
        $old['reported'] = false;
        return json_encode($old, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    }
    $state = $input['runtime_state'];
    $version = $input['runtime_version'] ?? '';
    $counts = [];
    $valid = is_string($state) && in_array($state, ['current', 'stale', 'unknown', 'no_session'], true)
        && is_string($version) && ($version === '' || preg_match('/\A[0-9]{1,8}\.[0-9]{1,8}\.[0-9]{1,8}\z/D', $version) === 1);
    foreach (['runtime_sessions', 'runtime_current_sessions', 'runtime_unmanaged_sessions'] as $key) {
        $count = $input[$key] ?? null;
        if (!is_int($count) || $count < 0 || $count > 1024) { $valid = false; $count = 0; }
        $counts[$key] = $count;
    }
    $sessions = $counts['runtime_sessions'];
    if ($counts['runtime_current_sessions'] + $counts['runtime_unmanaged_sessions'] > $sessions
        || ($state === 'no_session' && ($sessions !== 0 || $version !== ''))
        || ($state === 'current' && ($sessions === 0 || $counts['runtime_current_sessions'] !== $sessions
            || $counts['runtime_unmanaged_sessions'] !== 0 || $version === '' || $version !== ($input['current_version'] ?? '')))) { $valid = false; }
    // Invalid optional telemetry must not break the authenticated management
    // command loop. Its meaning is unknown, never an invented healthy session.
    if (!$valid) { $state = 'unknown'; $version = ''; $counts = array_fill_keys(array_keys($counts), 0); }
    return json_encode(['reported' => true, 'state' => $state, 'version' => $version,
        'received_at' => glpichat_desktop_now()] + $counts, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
}

/** Bounded row-only view: no per-machine SQL, process query or remote request. */
function glpichat_management_runtime_view(array $machine, ?int $now = null): array
{
    $now ??= time();
    $snapshot = is_string($machine['runtime_json'] ?? null) ? json_decode($machine['runtime_json'], true, 8) : null;
    $view = ['state' => 'unknown', 'label' => 'Não informado por este computador', 'version' => '',
        'sessions' => 0, 'current_sessions' => 0, 'unmanaged_sessions' => 0, 'received_at' => '', 'tone' => 'secondary'];
    if (!is_array($snapshot)) { return $view; }
    $view['received_at'] = is_string($snapshot['received_at'] ?? null) ? $snapshot['received_at'] : '';
    $received = strtotime($view['received_at'] . ' UTC');
    if ($received === false || $received > $now + 5 || $received < $now - 300) {
        $view['state'] = 'expired'; $view['label'] = 'Sem confirmação recente do Widget'; return $view;
    }
    if (($snapshot['reported'] ?? false) !== true) { return $view; }
    foreach (['sessions' => 'runtime_sessions', 'current_sessions' => 'runtime_current_sessions', 'unmanaged_sessions' => 'runtime_unmanaged_sessions'] as $key => $source) {
        $view[$key] = max(0, min(1024, (int) ($snapshot[$source] ?? 0)));
    }
    $state = $snapshot['state'] ?? 'unknown';
    if ($state === 'current' && ($snapshot['version'] ?? '') !== ($machine['current_version'] ?? '')) { $state = 'stale'; }
    $labels = ['current' => 'Versão instalada em execução', 'stale' => 'Widget precisa reiniciar',
        'unknown' => 'Execução do Widget não confirmada', 'no_session' => 'Nenhuma sessão do Widget observada'];
    if (isset($labels[$state])) { $view['state'] = $state; $view['label'] = $labels[$state]; }
    $view['version'] = is_string($snapshot['version'] ?? null) ? $snapshot['version'] : '';
    $view['tone'] = $view['state'] === 'current' ? 'success' : ($view['state'] === 'stale' ? 'warning' : 'secondary');
    return $view;
}

function glpichat_management_bootstrap_pending(array $machine): bool
{
    // The 0.7 Agent carries its verified Bootstrap migration. Older installed
    // payloads do not contain this migration and must not promise auto-upgrade.
    return version_compare((string) ($machine['current_version'] ?? ''), '0.7.0', '>=')
        && version_compare((string) ($machine['bootstrap_version'] ?? ''), '0.7.0', '<');
}
