<?php

declare(strict_types=1);

/** Install/update only. Migration::addCrontask defaults to CLI regardless of GLPI_SYSTEM_CRON. */
function glpichat_desktop_register_rollout_cron(Migration $migration, string $previous_schema): void
{
    global $DB;

    $mode = defined('GLPI_SYSTEM_CRON') && GLPI_SYSTEM_CRON
        ? CronTask::MODE_EXTERNAL
        : CronTask::MODE_INTERNAL;
    $identity = [
        'itemtype' => \GlpiPlugin\Glpichat\DesktopRolloutCron::class,
        'name' => 'ProcessDesktopRollouts',
    ];
    $migration->addCrontask($identity['itemtype'], $identity['name'], 60, null, ['mode' => $mode]);

    // addCrontask deliberately does nothing for existing rows. Repair the
    // untouched, never-run desktop10 registration during its schema upgrade.
    // Preserve disabled/running tasks, modified schedules and actual CLI use.
    // This is auxiliary: authenticated machine polls can dispatch independently.
    if ($previous_schema !== '6' || $mode !== CronTask::MODE_INTERNAL) {
        return;
    }
    $updated = $DB->update('glpi_crontasks', ['mode' => CronTask::MODE_INTERNAL], $identity + [
        'mode' => CronTask::MODE_EXTERNAL,
        'state' => CronTask::STATE_WAITING,
        'frequency' => 60,
        'hourmin' => 0,
        'hourmax' => 24,
        'allowmode' => CronTask::MODE_INTERNAL | CronTask::MODE_EXTERNAL,
        'logs_lifetime' => 30,
        'param' => null,
        'comment' => '',
        'lastrun' => null,
        'lastcode' => null,
    ]);
    if ($updated === false) { throw new RuntimeException('Desktop rollout scheduler migration failed.'); }
}
