<?php

declare(strict_types=1);

use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;

/** Existing GLPI/PHP policy, reported to clients rather than copied into settings. */
function glpichat_desktop_attachment_policy(): array
{
    global $CFG_GLPI;
    $limits = array_filter([
        (int) ($CFG_GLPI['document_max_size'] ?? 0) * 1048576,
        (int) Toolbox::getPhpUploadSizeLimit(),
    ], static fn(int $size): bool => $size > 0);
    // PHP post_max_size also includes multipart framing. Reserve a small bounded
    // envelope, so the value advertised is actually usable by the desktop.
    $postLimit = function_exists('ini_parse_quantity') ? ini_parse_quantity((string) ini_get('post_max_size')) : 0;
    if ($postLimit > 0) { $limits[] = max(0, $postLimit - 65536); }
    $extensions = [];
    $complete = true;
    foreach (glpichat_desktop_db_rows('SELECT ext FROM glpi_documenttypes WHERE is_uploadable = 1 ORDER BY ext') as $row) {
        $ext = strtolower((string) $row['ext']);
        if (preg_match('/\A[a-z0-9][a-z0-9_.+-]{0,30}\z/D', $ext) === 1) { $extensions[] = $ext; }
        else { $complete = false; } // Native filename patterns cannot be translated safely into a client suffix list.
    }
    return ['max_bytes' => $limits ? min($limits) : PHP_INT_MAX, 'extensions' => array_values(array_unique($extensions)), 'extensions_complete' => $complete];
}

function glpichat_desktop_attachment_request(Request $request): array
{
    $type = strtolower(trim(explode(';', (string) $request->headers->get('Content-Type', ''))[0]));
    if ($type !== 'multipart/form-data') {
        glpichat_desktop_fail('multipart_required', 'Envie o anexo como multipart/form-data.', 415);
    }
    $policy = glpichat_desktop_attachment_policy();
    $length = (int) $request->headers->get('Content-Length', '0');
    if ($length > $policy['max_bytes'] + 65536) {
        glpichat_desktop_fail('attachment_too_large', 'O arquivo excede o limite do GLPI ou do servidor.', 413);
    }
    $fields = $request->request->all();
    $files = $request->files->all();
    if (array_keys($fields) !== ['client_message_id'] || array_keys($files) !== ['file']) {
        glpichat_desktop_fail('invalid_attachment', 'Envie um arquivo e seu identificador de mensagem.', 400);
    }
    return [glpichat_desktop_string($fields, 'client_message_id', 36), $files['file']];
}

/** Validate and hash the actual temporary upload, never a client-supplied path/hash. */
function glpichat_desktop_attachment_input(mixed $file): array
{
    if (!$file instanceof UploadedFile) {
        glpichat_desktop_fail('invalid_attachment', 'Selecione um arquivo para enviar.', 400);
    }
    if (!$file->isValid()) {
        $large = in_array($file->getError(), [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true);
        glpichat_desktop_fail($large ? 'attachment_too_large' : 'invalid_attachment',
            $large ? 'O arquivo excede o limite do servidor.' : 'O envio do arquivo não foi concluído.', $large ? 413 : 400);
    }
    $name = $file->getClientOriginalName();
    if ($name === '' || strlen($name) > 200 || preg_match('//u', $name) !== 1
        || preg_match('/[\x00-\x1F\x7F\/\\\\\x{202A}-\x{202E}\x{2066}-\x{2069}]/u', $name)
        || in_array($name, ['.', '..'], true)) {
        glpichat_desktop_fail('invalid_attachment_name', 'O nome do arquivo é inválido ou muito longo.', 400);
    }
    $pattern = DocumentType::getUploadableFilePattern();
    if ($pattern === '' || preg_match($pattern, $name) !== 1 || Document::isValidDoc($name) === '') {
        glpichat_desktop_fail('attachment_type_not_allowed', 'Este tipo de arquivo não é permitido pelo GLPI.', 415);
    }
    $size = $file->getSize();
    $limit = glpichat_desktop_attachment_policy()['max_bytes'];
    if (!is_int($size) || $size < 0 || $size > $limit) {
        glpichat_desktop_fail('attachment_too_large', 'O arquivo excede o limite do GLPI ou do servidor.', 413);
    }
    $sha = hash_file('sha256', $file->getPathname());
    if (!is_string($sha)) { throw new RuntimeException('Attachment checksum failed.'); }
    return ['name' => $name, 'size' => $size, 'sha256' => $sha];
}

function glpichat_desktop_attachment_hash(int $ticketId, array $file): string
{
    // Separate domain prevents a text message from replaying a file UUID.
    return glpichat_desktop_payload_hash($ticketId, "attachment-v1\0" . $file['name'] . "\0" . $file['size'] . "\0" . $file['sha256']);
}

/** A GLPI document can only be resolved inside GLPI's managed document storage. */
function glpichat_desktop_document_path(array $document): ?string
{
    $relative = (string) ($document['filepath'] ?? '');
    if ($relative === '' || str_contains($relative, "\0") || preg_match('~(?:^|[\\\\/])\.\.(?:[\\\\/]|$)~', $relative)
        || preg_match('~\A(?:[\\\\/]|[a-zA-Z]:)~', $relative)) { return null; }
    $root = realpath(GLPI_DOC_DIR);
    $path = realpath(GLPI_DOC_DIR . '/' . $relative);
    return is_string($root) && is_string($path) && str_starts_with($path, $root . DIRECTORY_SEPARATOR)
        && is_file($path) && is_readable($path) ? $path : null;
}

/**
 * The caller has authorized this ticket. Each document still requires a current
 * public followup and a native association. A bare Ticket document is not enough:
 * old web internal uploads also used Ticket associations.
 */
function glpichat_desktop_attachment_rows(array $actor, int $ticketId, array $messageIds, int $documentId = 0): array
{
    $ids = array_values(array_unique(array_map('intval', $messageIds)));
    if (!$ids) { return []; }
    if (count($ids) > 50 || min($ids) <= 0) { throw new InvalidArgumentException('Invalid attachment message window.'); }
    $entityId = (int) $actor['entity_id'];
    $idsSql = implode(',', $ids);
    return glpichat_desktop_db_rows('SELECT DISTINCT f.id AS message_id, d.id, d.name, d.filename, d.filepath, d.mime, d.sha1sum '
        . 'FROM glpi_itilfollowups f JOIN ('
        . "SELECT di.items_id AS message_id, di.documents_id FROM glpi_documents_items di WHERE di.itemtype = 'ITILFollowup' AND di.items_id IN ($idsSql) "
        . 'UNION SELECT am.itilfollowups_id AS message_id, am.documents_id FROM glpi_plugin_glpichat_messages am '
        . 'JOIN glpi_plugin_glpichat_rooms ar ON ar.id = am.rooms_id '
        . 'JOIN glpi_documents_items ti ON ti.documents_id = am.documents_id '
        . "AND ti.itemtype = 'Ticket' AND ti.items_id = am.tickets_id "
        . "WHERE am.itilfollowups_id IN ($idsSql) AND am.tickets_id = $ticketId AND am.documents_id > 0 "
        . "AND am.message_type = 'attachment' AND am.participant_type = 'user' "
        . "AND ar.tickets_id = am.tickets_id AND BINARY ar.room_type = BINARY 'public') links ON links.message_id = f.id "
        . 'JOIN glpi_documents d ON d.id = links.documents_id '
        . "WHERE f.items_id = $ticketId AND f.id IN ($idsSql) AND "
        . glpichat_desktop_public_followup_predicate()
        . " AND d.entities_id = $entityId AND d.is_deleted = 0 AND d.is_blacklisted = 0"
        . ($documentId > 0 ? " AND d.id = $documentId" : '')
        . ' ORDER BY f.id, d.id LIMIT 1000');
}

function glpichat_desktop_attachment_output(array $row): ?array
{
    $path = glpichat_desktop_document_path($row);
    if ($path === null) { return null; }
    $name = (string) ($row['filename'] ?: $row['name']);
    $name = basename(str_replace('\\', '/', $name));
    $name = preg_replace('/[\x00-\x1F\x7F\x{202A}-\x{202E}\x{2066}-\x{2069}]/u', '', $name) ?? '';
    if ($name === '') { $name = 'anexo-' . (int) $row['id']; }
    return ['id' => (int) $row['id'], 'name' => mb_substr($name, 0, 255, 'UTF-8'),
        'size' => (int) filesize($path), 'mime' => (string) ($row['mime'] ?: 'application/octet-stream')];
}

function glpichat_desktop_message_attachments(array $actor, int $ticketId, array $messageIds): array
{
    $byMessage = [];
    foreach (glpichat_desktop_attachment_rows($actor, $ticketId, $messageIds) as $row) {
        $attachment = glpichat_desktop_attachment_output($row);
        if ($attachment !== null) { $byMessage[(int) $row['message_id']][] = $attachment; }
    }
    return $byMessage;
}

function glpichat_desktop_download_attachment(array $actor, int $ticketId, int $messageId, int $documentId): BinaryFileResponse
{
    glpichat_desktop_ticket($actor, $ticketId);
    $rows = glpichat_desktop_attachment_rows($actor, $ticketId, [$messageId], $documentId);
    $document = $rows[0] ?? null;
    $path = $document === null ? null : glpichat_desktop_document_path($document);
    if ($path === null) { glpichat_desktop_fail('attachment_unavailable', 'O anexo não está mais disponível nesta conversa.', 404); }
    // Preserve native document.send.php integrity verification. Metadata polls
    // only stat files; this full checksum runs only for the requested download.
    $storedChecksum = (string) ($document['sha1sum'] ?? '');
    if ($storedChecksum !== '' && !hash_equals($storedChecksum, (string) sha1_file($path))) {
        glpichat_desktop_fail('attachment_unavailable', 'O anexo não está mais disponível. Solicite uma nova cópia.', 404);
    }
    $meta = glpichat_desktop_attachment_output($document);
    if ($meta === null) { glpichat_desktop_fail('attachment_unavailable', 'O anexo não está mais disponível nesta conversa.', 404); }
    $response = new BinaryFileResponse($path);
    // A native save dialog receives bytes; never execute/render attacker content.
    $response->headers->set('Content-Type', 'application/octet-stream');
    $response->setContentDisposition(ResponseHeaderBag::DISPOSITION_ATTACHMENT, $meta['name'], 'anexo-' . $documentId);
    $response->headers->set('Cache-Control', 'no-store, private');
    $response->headers->set('Pragma', 'no-cache');
    $response->headers->set('X-Content-Type-Options', 'nosniff');
    $response->headers->set('Content-Security-Policy', "default-src 'none'; sandbox");
    return $response;
}

/** Native storage and associations, with an explicit bearer actor/entity. */
function glpichat_desktop_store_attachment(array $actor, int $ticketId, int $followupId, UploadedFile $file, array $input): int
{
    global $CFG_GLPI;
    $prefix = bin2hex(random_bytes(12)) . '_';
    $stagingName = $prefix . $input['name'];
    $file->move(GLPI_UPLOAD_DIR, $stagingName);
    $stagingPath = GLPI_UPLOAD_DIR . '/' . $stagingName;
    $previousSuppress = $GLOBALS['GLPICHAT_SUPPRESS_DOCUMENT_HOOK'] ?? false;
    $sessionBefore = $_SESSION ?? [];
    try {
        // Document::prepareInputForAdd otherwise replaces explicit users_id
        // with an unrelated browser/inventory identity. Install no bearer user
        // in Session: the native writer receives explicit author/entity only.
        unset($_SESSION['glpiID'], $_SESSION['glpiinventoryuserrunning'], $_SESSION['glpicronuserrunning']);
        $GLOBALS['GLPICHAT_SUPPRESS_DOCUMENT_HOOK'] = true;
        $document = new Document();
        // Omitting itemtype avoids Document::post_addItem's synchronous event.
        // Associations below use native writers after creation, with notif off.
        $id = (int) $document->add([
            'entities_id' => (int) $actor['entity_id'], 'users_id' => (int) $actor['user_id'],
            'name' => $input['name'], 'upload_file' => $stagingName,
            '_prefix_filename' => [$prefix], '_only_if_upload_succeed' => 1,
            'documentcategories_id' => (int) ($CFG_GLPI['documentcategories_id_forticket'] ?? 0),
            '_disablenotif' => true,
        ]);
        if ($id <= 0) { throw new RuntimeException('Native attachment storage failed.'); }
        // A Ticket shortcut would remain public after this followup becomes
        // private. Native GLPI can resolve Ticket-context downloads through its
        // current public followups, so only the exact followup is associated.
        require_once dirname(__DIR__) . '/FollowupDocumentItem.php';
        $link = new \GlpiPlugin\Glpichat\FollowupDocumentItem();
        if (!$link->add(['documents_id' => $id, 'itemtype' => 'ITILFollowup', 'items_id' => $followupId,
            'entities_id' => (int) $actor['entity_id'], 'users_id' => (int) $actor['user_id'],
            '_do_notif' => false, '_disablenotif' => true])) {
            throw new RuntimeException('Native attachment association failed.');
        }
        return $id;
    } finally {
        $GLOBALS['GLPICHAT_SUPPRESS_DOCUMENT_HOOK'] = $previousSuppress;
        $_SESSION = $sessionBefore;
        if (is_file($stagingPath)) { unlink($stagingPath); }
        // Native content-addressed files may be shared with concurrent writers.
        // A later DB rollback can leave unreferenced physical bytes; never
        // delete that shared path blindly. This rare residual requires storage
        // reconciliation; GLPI's row-based orphan cron cannot guarantee cleanup.
    }
}

function glpichat_desktop_upload_attachment(array $actor, int $ticketId, string $uuid, mixed $file): array
{
    if (!in_array((string) glpichat_desktop_config('desktop_schema_version'), ['5', '6', '7', '8'], true)) {
        glpichat_desktop_fail('schema_unavailable', 'Conclua a atualização do plugin antes de enviar anexos.', 503);
    }
    $uuid = strtolower($uuid);
    if (preg_match('/\A[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\z/D', $uuid) !== 1) {
        glpichat_desktop_fail('invalid_message_id', 'Identificador de mensagem inválido.', 400);
    }
    // Authorize before hashing file bytes. Recheck actor/ticket under write locks.
    glpichat_desktop_ticket($actor, $ticketId);
    $input = glpichat_desktop_attachment_input($file);
    $hash = glpichat_desktop_attachment_hash($ticketId, $input);
    return glpichat_desktop_transaction(function () use ($actor, $ticketId, $uuid, $file, $input, $hash): array {
        global $DB;
        $actor = glpichat_desktop_validate_actor($actor, true);
        $ticket = glpichat_desktop_ticket($actor, $ticketId, true);
        $userId = (int) $actor['user_id'];
        $receipts = glpichat_desktop_db_rows('SELECT id, tickets_id, payload_hash, itilfollowups_id FROM glpi_plugin_glpichat_desktopsends '
            . "WHERE users_id = $userId AND client_message_id = " . glpichat_desktop_quote($uuid) . ' FOR UPDATE');
        $followupId = 0;
        $created = false;
        if ($receipts) {
            $receipt = $receipts[0];
            if ((int) $receipt['tickets_id'] !== $ticketId || !hash_equals((string) $receipt['payload_hash'], $hash)) {
                glpichat_desktop_fail('idempotency_conflict', 'Este identificador já pertence a outra mensagem ou arquivo.', 409);
            }
            $followupId = (int) $receipt['itilfollowups_id'];
        } else {
            if (empty($actor['can_create']) || !in_array((int) $ticket['status'], [1, 2, 3, 4], true)) {
                glpichat_desktop_fail('conversation_read_only', 'Esta conversa está disponível somente para leitura.', 403);
            }
            if (Ticket::getMergedTickets($ticketId) !== []) {
                glpichat_desktop_fail('conversation_merge_unsupported', 'Envie este anexo pela interface do GLPI.', 409);
            }
            $recent = glpichat_desktop_db_rows('SELECT COUNT(*) AS n FROM glpi_plugin_glpichat_desktopsends '
                . "WHERE users_id = $userId AND created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 1 MINUTE)");
            if ((int) ($recent[0]['n'] ?? 0) >= 30) {
                glpichat_desktop_fail('send_throttled', 'Aguarde um minuto antes de enviar novas mensagens.', 429);
            }
            if (!$DB->insert('glpi_plugin_glpichat_desktopsends', [
                'users_id' => $userId, 'client_message_id' => $uuid, 'tickets_id' => $ticketId,
                'payload_hash' => $hash, 'itilfollowups_id' => null, 'created_at' => glpichat_desktop_now(),
            ])) { throw new RuntimeException('Attachment receipt insert failed.'); }
            $receiptId = (int) $DB->insertId();
            $content = 'Attachment added from GLPI Chat: ' . $input['name'];
            $now = date('Y-m-d H:i:s');
            $followup = new ITILFollowup();
            $followupId = (int) $followup->add([
                'itemtype' => 'Ticket', 'items_id' => $ticketId, 'users_id' => $userId,
                'content' => htmlspecialchars($content, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
                'is_private' => 0, 'requesttypes_id' => glpichat_desktop_requesttype_id(),
                'date' => $now, 'date_creation' => $now, 'date_mod' => $now,
                '_disablenotif' => true, '_no_reopen' => true,
            ]);
            if ($followupId <= 0) { throw new RuntimeException('Attachment followup insert failed.'); }
            $documentId = glpichat_desktop_store_attachment($actor, $ticketId, $followupId, $file, $input);
            $messageId = glpichat_add_message($ticketId, 'public', 'user', $userId, 0, $content, $documentId, $followupId, false);
            $mirrors = glpichat_desktop_db_rows('SELECT id FROM glpi_plugin_glpichat_messages '
                . "WHERE id = $messageId AND tickets_id = $ticketId AND itilfollowups_id = $followupId AND documents_id = $documentId AND users_id = $userId");
            if ($messageId <= 0 || !$mirrors || !$DB->update('glpi_plugin_glpichat_desktopsends', ['itilfollowups_id' => $followupId], ['id' => $receiptId])) {
                throw new RuntimeException('Attachment receipt/mirror completion failed.');
            }
            glpichat_queue_message_notifications($ticketId, 'public', 'user', $userId, $content, $messageId, $followupId);
            $created = true;
        }
        $rows = glpichat_desktop_db_rows(glpichat_desktop_followup_select($userId)
            . "WHERE f.id = $followupId AND f.items_id = $ticketId AND " . glpichat_desktop_public_followup_predicate() . ' LIMIT 1 FOR UPDATE');
        $documents = glpichat_desktop_attachment_rows($actor, $ticketId, [$followupId]);
        $matching = null;
        foreach ($documents as $document) {
            $meta = glpichat_desktop_attachment_output($document);
            $path = glpichat_desktop_document_path($document);
            if ($meta !== null && $path !== null && $meta['name'] === $input['name'] && $meta['size'] === $input['size']
                && hash_equals($input['sha256'], (string) hash_file('sha256', $path))) { $matching = $meta; break; }
        }
        if (!$rows || (int) $rows[0]['users_id'] !== $userId || $matching === null) {
            if ($created) { throw new RuntimeException('Native attachment verification failed.'); }
            glpichat_desktop_fail('attachment_unavailable', 'O anexo já foi enviado e não está mais disponível. Atualize a conversa.', 409);
        }
        $rows[0]['attachments'] = [$matching];
        $rows[0]['client_message_id'] = $uuid;
        return ['message' => glpichat_desktop_message_output($actor, $rows[0]), 'client_message_id' => $uuid];
    });
}
