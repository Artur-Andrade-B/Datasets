<?php

declare(strict_types=1);
require_once __DIR__ . '/management.php';

const GLPICHAT_MANAGEMENT_ROLLOUTS = 'glpi_plugin_glpichat_desktoprollouts';
const GLPICHAT_MANAGEMENT_TARGETS = 'glpi_plugin_glpichat_desktoprollouttargets';

/** Fixed, shared filter vocabulary for the list, count and immutable target snapshot. */
function glpichat_management_filters(array $input): array
{
    $filters = [];
    foreach (['q' => 100, 'version' => 32, 'status' => 16, 'health' => 16, 'contact' => 16, 'operation_status' => 16] as $key => $limit) {
        $value = $input[$key] ?? '';
        if (!is_string($value) || strlen($value) > $limit || preg_match('/[\x00-\x1f\x7f]/', $value)) { glpichat_desktop_fail('invalid_request', 'Filtro inválido.', 400); }
        $filters[$key] = trim($value);
    }
    foreach (['status' => ['', 'active', 'revoked'], 'health' => ['', 'healthy', 'damaged', 'trial', 'unavailable'], 'contact' => ['', 'recent', 'offline', 'never'], 'operation_status' => ['', 'none', 'pending', 'started', 'completed', 'failed', 'superseded']] as $key => $allowed) {
        if (!in_array($filters[$key], $allowed, true)) { glpichat_desktop_fail('invalid_request', 'Filtro inválido.', 400); }
    }
    return $filters;
}

function glpichat_management_latest_join(): string
{
    return ' LEFT JOIN ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' a ON a.id=(SELECT MAX(la.id) FROM ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' la WHERE la.machines_id=m.id)';
}

function glpichat_management_filter_sql(array $filters, ?string $asOf = null): string
{
    $parts = ['1=1'];
    if ($filters['q'] !== '') {
        $like = '%' . str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $filters['q']) . '%';
        $parts[] = '(m.computer_name LIKE ' . glpichat_desktop_quote($like) . " ESCAPE '!' OR m.installation_id LIKE " . glpichat_desktop_quote($like) . " ESCAPE '!')";
    }
    foreach (['version' => 'current_version', 'status' => 'status', 'health' => 'health'] as $key => $column) {
        if ($filters[$key] !== '') { $parts[] = 'm.' . $column . '=' . glpichat_desktop_quote($filters[$key]); }
    }
    $asOf ??= glpichat_desktop_now();
    $cutoff = gmdate('Y-m-d H:i:s', strtotime($asOf . ' UTC') - 300);
    if ($filters['contact'] === 'never') { $parts[] = 'm.last_seen IS NULL'; }
    elseif ($filters['contact'] === 'recent') { $parts[] = 'm.last_seen>=' . glpichat_desktop_quote($cutoff); }
    elseif ($filters['contact'] === 'offline') { $parts[] = '(m.last_seen IS NULL OR m.last_seen<' . glpichat_desktop_quote($cutoff) . ')'; }
    if ($filters['operation_status'] === 'none') { $parts[] = 'a.id IS NULL'; }
    elseif ($filters['operation_status'] !== '') { $parts[] = 'a.status=' . glpichat_desktop_quote($filters['operation_status']); }
    return implode(' AND ', $parts);
}

function glpichat_management_machine_page(array $filters, int $page = 1, int $size = 50): array
{
    glpichat_management_require_schema();
    $size = in_array($size, [50, 100], true) ? $size : 50;
    $from = GLPICHAT_MANAGEMENT_MACHINES . ' m' . glpichat_management_latest_join();
    $where = glpichat_management_filter_sql($filters);
    $total = (int) (glpichat_desktop_db_rows('SELECT COUNT(*) AS total FROM ' . $from . ' WHERE ' . $where)[0]['total'] ?? 0);
    $pages = max(1, (int) ceil($total / $size)); $page = max(1, min($page, $pages));
    $columns = 'm.id,m.installation_id,m.computer_name,m.previous_computer_name,m.renamed_at,m.status,m.current_version,m.bootstrap_version,m.health,m.runtime_json,m.last_seen,m.last_result,m.last_error,'
        . 'a.id AS assignment_id,a.action AS assignment_action,a.status AS assignment_status,a.last_error AS assignment_error,a.started_at,a.completed_at,r.version AS assignment_version';
    $rows = glpichat_desktop_db_rows('SELECT ' . $columns . ' FROM ' . $from . ' LEFT JOIN ' . GLPICHAT_MANAGEMENT_RELEASES . ' r ON r.id=a.releases_id WHERE ' . $where . ' ORDER BY m.id DESC LIMIT ' . $size . ' OFFSET ' . (($page - 1) * $size));
    return ['rows' => $rows, 'total' => $total, 'page' => $page, 'pages' => $pages, 'size' => $size];
}

function glpichat_management_selection_ids(mixed $input): array
{
    if (is_string($input)) {
        if (strlen($input) > 120000) { glpichat_desktop_fail('invalid_request', 'Seleção muito grande.', 400); }
        try { $input = json_decode($input, true, 4, JSON_THROW_ON_ERROR); } catch (JsonException $error) { glpichat_desktop_fail('invalid_request', 'Seleção inválida.', 400); }
    }
    if (!is_array($input) || !array_is_list($input) || count($input) > 10000) { glpichat_desktop_fail('invalid_request', 'Seleção inválida.', 400); }
    $ids = [];
    foreach ($input as $id) {
        if ((!is_string($id) && !is_int($id)) || preg_match('/\A[1-9][0-9]{0,9}\z/D', (string) $id) !== 1 || (int) $id > 4294967295) { glpichat_desktop_fail('invalid_request', 'Computador inválido.', 400); }
        $ids[(int) $id] = true;
    }
    $result = array_keys($ids); sort($result, SORT_NUMERIC); return $result;
}

/** A single INSERT SELECT snapshots identities atomically, not all assignments.
 * Filters never remain a live rule that silently enrolls future computers. */
function glpichat_management_create_rollout(int $releaseId, string $action, array $filters, string $selection, array $ids, array $excluded, int $adminId, string $requestId, int $attempt = 0): array
{
    global $DB;
    glpichat_management_require_schema();
    $filters = glpichat_management_filters($filters);
    $ids = glpichat_management_selection_ids($ids); $excluded = glpichat_management_selection_ids($excluded);
    // Exclusions belong solely to the all-matching mode. Retained browser state
    // from that mode must never silently remove explicitly selected IDs.
    if ($selection === 'selected') { $excluded = []; }
    if (!in_array($action, ['update', 'repair'], true) || !in_array($selection, ['selected', 'all'], true) || ($selection === 'selected' && !$ids)
        || $adminId < 1 || preg_match('/\A[a-f0-9]{32}\z/D', $requestId) !== 1) { glpichat_desktop_fail('invalid_request', 'Selecione os computadores e a operação.', 400); }
    // Repeated submission with a fresh CSRF token still resolves to the same job.
    $existing = glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS, 'created_by=' . $adminId . ' AND request_id=' . glpichat_desktop_quote($requestId));
    if ($existing) { return $existing; }
    try {
        return glpichat_desktop_transaction(static function () use ($releaseId, $action, $filters, $selection, $ids, $excluded, $adminId, $requestId, $DB): array {
            if (!glpichat_management_one(GLPICHAT_MANAGEMENT_RELEASES, 'id=' . $releaseId)) { glpichat_desktop_fail('not_found', 'Versão indisponível.', 404); }
            $now = glpichat_desktop_now();
            $where = glpichat_management_filter_sql($filters, $now);
            if ($selection === 'selected') { $where .= ' AND m.id IN (' . implode(',', $ids) . ')'; }
            if ($excluded) { $where .= ' AND m.id NOT IN (' . implode(',', $excluded) . ')'; }
            // Exact target IDs live in the target table; keep the criteria
            // summary bounded even when many explicit exclusions were supplied.
            $audit = json_encode(['filters' => $filters, 'selection' => $selection, 'excluded_count' => count($excluded), 'selected_count' => count($ids), 'as_of' => $now], JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
            $rollout = glpichat_management_write(GLPICHAT_MANAGEMENT_ROLLOUTS, ['request_id' => $requestId, 'releases_id' => $releaseId, 'action' => $action,
                'filters_json' => $audit, 'target_count' => 0, 'status' => 'queued', 'created_by' => $adminId, 'created_at' => $now, 'completed_at' => null]);
            $time = glpichat_desktop_quote($now);
            if ($DB->doQuery('INSERT INTO ' . GLPICHAT_MANAGEMENT_TARGETS . ' (rollouts_id,machines_id,status,reason,available_at,created_at) SELECT '
                . $rollout . ",m.id,'queued',''," . $time . ',' . $time . ' FROM ' . GLPICHAT_MANAGEMENT_MACHINES . ' m' . glpichat_management_latest_join() . ' WHERE ' . $where . ' ORDER BY m.id') === false) { throw new RuntimeException('Rollout snapshot failed.'); }
            $count = (int) (glpichat_desktop_db_rows('SELECT COUNT(*) AS total FROM ' . GLPICHAT_MANAGEMENT_TARGETS . ' WHERE rollouts_id=' . $rollout)[0]['total'] ?? 0);
            if ($count === 0) { glpichat_desktop_fail('empty_selection', 'Nenhum computador corresponde à seleção atual.', 409); }
            glpichat_management_write(GLPICHAT_MANAGEMENT_ROLLOUTS, ['target_count' => $count], ['id' => $rollout]);
            // New explicit intent supersedes only work not dispatched to a machine.
            if ($DB->doQuery('UPDATE ' . GLPICHAT_MANAGEMENT_TARGETS . ' old INNER JOIN ' . GLPICHAT_MANAGEMENT_TARGETS . ' newer ON newer.machines_id=old.machines_id AND newer.rollouts_id=' . $rollout
                . " SET old.status='skipped',old.reason='replaced_by_newer_rollout',old.completed_at=" . $time
                . " WHERE old.rollouts_id<" . $rollout . " AND old.status IN ('queued','waiting')") === false) { throw new RuntimeException('Rollout supersession failed.'); }
            return ['id' => $rollout, 'target_count' => $count, 'status' => 'queued'];
        });
    } catch (Throwable $error) {
        // Concurrent duplicate requests race on the unique request key.
        $existing = glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS, 'created_by=' . $adminId . ' AND request_id=' . glpichat_desktop_quote($requestId));
        if ($existing) { return $existing; }
        // INSERT SELECT snapshots and concurrent dispatch can briefly contend
        // on the same machine. Retry only the database's deadlock/lock-timeout
        // classifications, after the transaction helper has rolled back.
        $transient = ($error instanceof mysqli_sql_exception && in_array($error->getCode(), [1205, 1213], true))
            || (basename($error->getFile()) === 'DBmysql.php' && preg_match('/\A(?:MySQL query error:).*\((?:1205|1213)\) in SQL query /s', $error->getMessage()));
        if ($transient && $attempt < 2) {
            usleep(random_int(10000, 50000));
            return glpichat_management_create_rollout($releaseId, $action, $filters, $selection, $ids, $excluded, $adminId, $requestId, $attempt + 1);
        }
        throw $error;
    }
}

function glpichat_management_rollout_reason(string $code): string
{
    return ['sequence_conflict' => 'Versão já atual ou sequência mais recente instalada.', 'bootstrap_upgrade_required' => 'Manutenção do bootstrap necessária.',
        'state_upgrade_required' => 'Migração de dados do cliente necessária.', 'release_quarantined' => 'Falha anterior: solicite reparo explicitamente.',
        'not_found' => 'Máquina revogada/indisponível ou versão removida.', 'operation_in_progress' => 'Aguardando a operação em andamento.',
        'replaced_by_newer_rollout' => 'Substituída por uma solicitação posterior.', 'superseded' => 'Operação substituída antes da execução.',
        'assignment_missing' => 'Registro da operação indisponível.', 'machine_revoked' => 'Gerenciamento revogado; execução não confirmada.', 'storage_retry' => 'Falha na distribuição; nova tentativa automática programada.', 'dispatch_failed' => 'A distribuição falhou após 5 tentativas. Consulte a referência e solicite novamente após corrigir a causa.'][$code] ?? $code;
}

/** Revalidate the caller while holding target -> machine locks, matching cron.
 * A credential is internal context from an already authenticated Poll. */
function glpichat_management_target_authenticate(array $target, ?array $credential): void
{
    if ($credential === null) { return; }
    if ((int) $target['machines_id'] !== $credential['machines_id']) {
        glpichat_desktop_fail('machine_invalid', 'Registro da máquina inválido.', 401);
    }
    $machine = glpichat_management_authenticate($credential['token'], $credential['installation'], true);
    if ((int) $machine['id'] !== (int) $target['machines_id']) {
        glpichat_desktop_fail('machine_invalid', 'Registro da máquina inválido.', 401);
    }
}

/** Finalize only after committing the target mutation. Snapshot membership is
 * immutable and terminal targets never become active again, so a fresh
 * nonlocking active-target check is sufficient. An UPDATE with a subquery
 * would lock other targets while holding the parent and invert dispatch order. */
function glpichat_management_complete_rollout(int $rolloutId, ?array $credential = null): void
{
    glpichat_management_transaction(static function () use ($rolloutId, $credential): void {
        if ($credential !== null) {
            $machine = glpichat_management_authenticate($credential['token'], $credential['installation'], true);
            if ((int) $machine['id'] !== $credential['machines_id']) { glpichat_desktop_fail('machine_invalid', 'Registro da máquina inválido.', 401); }
        }
        $active = glpichat_desktop_db_rows('SELECT id FROM ' . GLPICHAT_MANAGEMENT_TARGETS . ' WHERE rollouts_id=' . $rolloutId
            . " AND status IN ('queued','waiting','assigned') LIMIT 1");
        if (!$active) {
            glpichat_management_write(GLPICHAT_MANAGEMENT_ROLLOUTS, ['status' => 'completed', 'completed_at' => glpichat_desktop_now()],
                ['id' => $rolloutId, 'status' => ['queued', 'running']]);
        }
    });
}

/** Every caller uses this dispatcher. Invalid credentials never consume a
 * retry or mutate a target, including revocation racing with a valid Poll. */
function glpichat_management_dispatch_target(int $targetId, ?array $credential = null): string
{
    $rolloutId = 0;
    try {
        $outcome = glpichat_management_transaction(static function () use ($targetId, $credential, &$rolloutId): string {
            $target = glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS, 'id=' . $targetId, true);
            if (!$target) { return 'deferred'; }
            glpichat_management_target_authenticate($target, $credential);
            $rolloutId = (int) $target['rollouts_id'];
            if (!in_array($target['status'], ['queued', 'waiting'], true) || $target['available_at'] > glpichat_desktop_now()) { return 'deferred'; }
            $rollout = glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS, 'id=' . (int) $target['rollouts_id']);
            if (!$rollout) { throw new RuntimeException('Rollout unavailable.'); }
            try {
                $assignment = glpichat_management_assign_locked((int) $target['machines_id'], (int) $rollout['releases_id'], $rollout['action'], (int) $rollout['created_by']);
                glpichat_management_write(GLPICHAT_MANAGEMENT_TARGETS, ['assignments_id' => $assignment, 'status' => 'assigned', 'reason' => '',
                    'last_attempt_at' => glpichat_desktop_now(), 'last_error_ref' => ''], ['id' => $targetId]);
                glpichat_management_write(GLPICHAT_MANAGEMENT_ROLLOUTS, ['status' => 'running'], ['id' => (int) $rollout['id']]);
                return 'assigned';
            } catch (GlpichatDesktopException $error) {
                if (!in_array($error->errorCode, ['operation_in_progress', 'sequence_conflict', 'bootstrap_upgrade_required', 'state_upgrade_required', 'release_quarantined', 'not_found'], true)) { throw $error; }
                $waiting = $error->errorCode === 'operation_in_progress';
                glpichat_management_write(GLPICHAT_MANAGEMENT_TARGETS, ['status' => $waiting ? 'waiting' : 'skipped', 'reason' => $error->errorCode,
                    'last_attempt_at' => glpichat_desktop_now(), 'last_error_ref' => '',
                    'available_at' => gmdate('Y-m-d H:i:s', time() + 60), 'completed_at' => $waiting ? null : glpichat_desktop_now()], ['id' => $targetId]);
                return $waiting ? 'waiting' : 'skipped';
            }
        });
    } catch (Throwable $error) {
        if ($error instanceof GlpichatDesktopException && $error->errorCode === 'machine_invalid') { throw $error; }
        // A rollback failure poisons the connection boundary; do not begin a
        // diagnostic transaction inside that unresolved transaction either.
        if ($error instanceof GlpichatManagementTransactionStateException) { throw $error; }
        $reference = glpichat_desktop_log_failure('rollout_dispatch', $error);
        // The failed attempt rolled back. Record failure under the same lock
        // order, protecting against a concurrent success or supersession.
        $outcome = glpichat_management_transaction(static function () use ($targetId, $credential, $reference, &$rolloutId): string {
            $target = glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS, 'id=' . $targetId, true);
            if (!$target) { return 'deferred'; }
            glpichat_management_target_authenticate($target, $credential);
            $rolloutId = (int) $target['rollouts_id'];
            if (!in_array($target['status'], ['queued', 'waiting'], true) || $target['available_at'] > glpichat_desktop_now()) { return 'deferred'; }
            $attempts = min(5, max(0, (int) $target['dispatch_attempts']) + 1);
            $terminal = $attempts >= 5;
            glpichat_management_write(GLPICHAT_MANAGEMENT_TARGETS, ['dispatch_attempts' => $attempts,
                'last_attempt_at' => glpichat_desktop_now(), 'last_error_ref' => preg_replace('/[^a-f0-9]/', '', substr($reference, 0, 32)),
                'status' => $terminal ? 'failed' : $target['status'], 'reason' => $terminal ? 'dispatch_failed' : 'storage_retry',
                'available_at' => gmdate('Y-m-d H:i:s', time() + ($terminal ? 0 : [60, 120, 240, 480][$attempts - 1])),
                'completed_at' => $terminal ? glpichat_desktop_now() : null], ['id' => $targetId]);
            return $terminal ? 'failed' : 'deferred';
        });
    }
    if ($rolloutId > 0 && in_array($outcome, ['skipped', 'failed'], true)) { glpichat_management_complete_rollout($rolloutId, $credential); }
    return $outcome;
}

/** Reconcile only exact assigned targets; never alter assignment outcomes.
 * A Poll has a small machine-scoped limit; cron retains its bounded fleet pass. */
function glpichat_management_reconcile_rollout_targets(int $limit, float $deadline, ?array $credential = null): int
{
    $limit = max(1, min(1000, $limit));
    $scope = $credential === null ? '' : ' AND t.machines_id=' . (int) $credential['machines_id'];
    $finished = glpichat_desktop_db_rows('SELECT t.id FROM ' . GLPICHAT_MANAGEMENT_TARGETS . ' t LEFT JOIN ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS
        . ' a ON a.id=t.assignments_id LEFT JOIN ' . GLPICHAT_MANAGEMENT_MACHINES . " m ON m.id=t.machines_id WHERE t.status='assigned'" . $scope
        . " AND (a.id IS NULL OR a.status NOT IN ('pending','started') OR m.id IS NULL OR m.status<>'active') ORDER BY t.id LIMIT " . $limit);
    $count = 0;
    foreach ($finished as $row) {
        if (microtime(true) >= $deadline) { break; }
        $rolloutId = 0;
        $changed = glpichat_management_transaction(static function () use ($row, $credential, &$rolloutId): bool {
            $target = glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS, 'id=' . (int) $row['id'], true);
            if (!$target || $target['status'] !== 'assigned') { return false; }
            glpichat_management_target_authenticate($target, $credential);
            // Cron also takes the machine lock before reading its assignment.
            $machine = glpichat_management_one(GLPICHAT_MANAGEMENT_MACHINES, 'id=' . (int) $target['machines_id'], true);
            $assignment = glpichat_management_one(GLPICHAT_MANAGEMENT_ASSIGNMENTS, 'id=' . (int) $target['assignments_id'] . ' AND machines_id=' . (int) $target['machines_id'], true);
            $status = $assignment['status'] ?? '';
            $revoked = ($machine['status'] ?? '') !== 'active' && in_array($status, ['pending', 'started'], true);
            if (in_array($status, ['pending', 'started'], true) && !$revoked) { return false; }
            glpichat_management_write(GLPICHAT_MANAGEMENT_TARGETS, ['status' => in_array($status, ['completed', 'failed'], true) ? $status : 'skipped',
                'reason' => $revoked ? 'machine_revoked' : ($status === 'superseded' ? 'superseded' : ($status === '' ? 'assignment_missing' : '')),
                'completed_at' => glpichat_desktop_now()], ['id' => (int) $target['id']]);
            $rolloutId = (int) $target['rollouts_id'];
            return true;
        });
        if ($changed) { glpichat_management_complete_rollout($rolloutId, $credential); ++$count; }
    }
    return $count;
}

/** At most one due target, belonging to this authenticated installation only.
 * No queue work executes while the telemetry transaction holds machine locks. */
function glpichat_management_poll_rollouts(array $credential): void
{
    $deadline = microtime(true) + 2.0;
    glpichat_management_reconcile_rollout_targets(10, $deadline, $credential);
    // If a previous response failed after the target committed but before its
    // parent summary did, the next authenticated Poll still finishes that job.
    // Only this machine's terminal targets participate, with bounded output.
    $complete = glpichat_desktop_db_rows('SELECT DISTINCT t.rollouts_id FROM ' . GLPICHAT_MANAGEMENT_TARGETS . ' t INNER JOIN '
        . GLPICHAT_MANAGEMENT_ROLLOUTS . ' r ON r.id=t.rollouts_id WHERE t.machines_id=' . (int) $credential['machines_id']
        . " AND t.status IN ('completed','failed','skipped') AND r.status IN ('queued','running') AND NOT EXISTS (SELECT 1 FROM "
        . GLPICHAT_MANAGEMENT_TARGETS . " active WHERE active.rollouts_id=r.id AND active.status IN ('queued','waiting','assigned')) ORDER BY t.rollouts_id LIMIT 10");
    foreach ($complete as $row) {
        if (microtime(true) >= $deadline) { break; }
        glpichat_management_complete_rollout((int) $row['rollouts_id'], $credential);
    }
    $due = glpichat_desktop_db_rows('SELECT id FROM ' . GLPICHAT_MANAGEMENT_TARGETS . ' WHERE machines_id=' . (int) $credential['machines_id']
        . " AND status IN ('queued','waiting') AND available_at<=" . glpichat_desktop_quote(glpichat_desktop_now()) . ' ORDER BY available_at,id LIMIT 1');
    if ($due) { glpichat_management_dispatch_target((int) $due[0]['id'], $credential); }
}

/** Optional background dispatch/reconciliation. Poll does not require cron. */
function glpichat_management_process_rollouts(int $limit = 250, float $seconds = 8.0): array
{
    global $DB;
    glpichat_management_require_schema();
    $limit = max(1, min(1000, $limit)); $deadline = microtime(true) + max(0.1, min(30.0, $seconds));
    $result = ['assigned' => 0, 'waiting' => 0, 'skipped' => 0, 'reconciled' => 0, 'deferred' => 0, 'failed' => 0];
    $result['reconciled'] = glpichat_management_reconcile_rollout_targets($limit, $deadline);
    $now = glpichat_desktop_quote(glpichat_desktop_now());
    $due = glpichat_desktop_db_rows('SELECT id FROM ' . GLPICHAT_MANAGEMENT_TARGETS . " WHERE status IN ('queued','waiting') AND available_at<=" . $now . ' ORDER BY available_at,id LIMIT ' . $limit);
    foreach ($due as $row) {
        if (microtime(true) >= $deadline) { break; }
        ++$result[glpichat_management_dispatch_target((int) $row['id'])];
    }
    // Also clean up older jobs whose remaining queued targets were superseded
    // by an administrator's newer request, without touching their history.
    $complete = glpichat_desktop_db_rows('SELECT r.id FROM ' . GLPICHAT_MANAGEMENT_ROLLOUTS . " r WHERE r.status IN ('queued','running') AND NOT EXISTS (SELECT 1 FROM "
        . GLPICHAT_MANAGEMENT_TARGETS . " t WHERE t.rollouts_id=r.id AND t.status IN ('queued','waiting','assigned')) ORDER BY r.id LIMIT " . $limit);
    foreach ($complete as $row) {
        if (microtime(true) >= $deadline) { break; }
        glpichat_management_complete_rollout((int) $row['id']);
    }
    return $result;
}

function glpichat_management_rollout_page(int $page = 1): array
{
    $total = (int) (glpichat_desktop_db_rows('SELECT COUNT(*) AS total FROM ' . GLPICHAT_MANAGEMENT_ROLLOUTS)[0]['total'] ?? 0);
    $pages = max(1, (int) ceil($total / 20)); $page = max(1, min($pages, $page));
    $rows = glpichat_desktop_db_rows('SELECT o.id,o.action,o.target_count,o.status,o.created_by,o.created_at,o.completed_at,r.version FROM ' . GLPICHAT_MANAGEMENT_ROLLOUTS . ' o LEFT JOIN ' . GLPICHAT_MANAGEMENT_RELEASES . ' r ON r.id=o.releases_id ORDER BY o.id DESC LIMIT 20 OFFSET ' . (($page - 1) * 20));
    $ids = array_map(static fn (array $row): int => (int) $row['id'], $rows);
    $counts = [];
    if ($ids) {
        foreach (glpichat_desktop_db_rows('SELECT t.rollouts_id,CASE WHEN t.reason=\'dispatch_failed\' THEN \'dispatch_failed\' WHEN t.reason=\'storage_retry\' AND t.status IN (\'queued\',\'waiting\') THEN \'dispatch_retry\' WHEN t.status=\'assigned\' THEN COALESCE(a.status,\'unknown\') ELSE t.status END AS state,COUNT(*) AS total FROM '
            . GLPICHAT_MANAGEMENT_TARGETS . ' t LEFT JOIN ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' a ON a.id=t.assignments_id WHERE t.rollouts_id IN (' . implode(',', $ids) . ') GROUP BY t.rollouts_id,state') as $row) {
            $counts[(int) $row['rollouts_id']][$row['state']] = (int) $row['total'];
        }
    }
    return ['rows' => $rows, 'counts' => $counts, 'page' => $page, 'pages' => $pages, 'total' => $total];
}
