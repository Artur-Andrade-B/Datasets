<?php

declare(strict_types=1);
/** Production controller/Poll/rollout/CronTask entrypoint and GLPI DBmysql with
 * disposable MariaDB. Config is an explicit fixture; no Windows installation,
 * GLPI cron daemon, network transport or signed-client execution is simulated.
 * Usage: php desktop_rollout_poll_native_sql.php PLUGIN_ROOT GLPI_ROOT
 */
if (PHP_SAPI !== 'cli' || $argc < 3) { exit(2); }
[$unused, $plugin, $core] = $argv;
require $core . '/vendor/autoload.php';
require_once $core . '/src/DBmysql.php';
require_once $core . '/src/DBmysqlIterator.php';
require_once $core . '/src/DBConnection.php';
require $plugin . '/src/desktop/rollouts.php';
require $plugin . '/src/desktop/schema.php';
require $plugin . '/src/Controller/ManagementController.php';
require $plugin . '/src/DesktopRolloutCron.php';
final class Config {
    public static array $values = ['desktop_schema_version' => '6', 'desktop_enabled' => '1', 'desktop_idempotency_key' => ''];
    public static function getConfigurationValues(string $scope): array { return self::$values; }
    public static function getConfigurationValue(string $scope, string $key): mixed { return self::$values[$key] ?? null; }
    public static function setConfigurationValues(string $scope, array $values): void { self::$values = array_replace(self::$values, $values); }
}
final class PollNativeDB extends DBmysql {
    public array $queries = [];
    public bool $failAssignment = false;
    public bool $deadlockAssignment = false;
    public bool $failRollbackAfterDeadlock = false;
    public bool $failRollback = false;
    public int $injectedDeadlocks = 0;
    public bool $delayFirstLock = false;
    public bool $delayFirstTargetLock = false;
    public bool $failCompletion = false;
    public ?Closure $beforeTargetRead = null;
    public function __construct(mysqli $connection) { $this->dbh = $connection; $this->connected = true; }
    public function rollBack(): void {
        if ($this->failRollback) { $this->failRollback = false; throw new RuntimeException('Injected rollback failure.'); }
        parent::rollBack();
    }
    public function doQuery($query) {
        $this->queries[] = $query;
        if ($this->beforeTargetRead !== null && str_starts_with($query, 'SELECT ') && str_contains($query, 'FROM glpi_plugin_glpichat_desktoprollouttargets')) {
            $callback = $this->beforeTargetRead; $this->beforeTargetRead = null; $callback();
        }
        if ($this->deadlockAssignment && str_starts_with($query, 'INSERT INTO `glpi_plugin_glpichat_desktopassignments`')) {
            $this->deadlockAssignment = false; ++$this->injectedDeadlocks;
            $this->dbh->query('ROLLBACK'); // InnoDB deadlock victims lose the entire transaction, including savepoints.
            $this->failRollback = $this->failRollbackAfterDeadlock; $this->failRollbackAfterDeadlock = false;
            throw new mysqli_sql_exception('Injected whole-transaction deadlock victim.', 1213);
        }
        if ($this->failAssignment && str_starts_with($query, 'INSERT INTO `glpi_plugin_glpichat_desktopassignments`')) {
            $this->failAssignment = false;
            throw new RuntimeException('Injected assignment persistence failure.');
        }
        if ($this->failCompletion && str_starts_with($query, 'UPDATE `glpi_plugin_glpichat_desktoprollouts`') && str_contains($query, "'completed'")) {
            $this->failCompletion = false; throw new RuntimeException('Injected parent completion write failure.');
        }
        try { $result = $this->dbh->query($query); }
        catch (mysqli_sql_exception $error) { error_log('Native fixture SQL failure: ' . $query); throw $error; }
        // Test-only hold makes actual SQL contention observable across workers.
        if (str_ends_with($query, ' FOR UPDATE') && ($this->delayFirstLock || ($this->delayFirstTargetLock && str_contains($query, 'FROM glpi_plugin_glpichat_desktoprollouttargets')))) {
            $this->delayFirstLock = false; $this->delayFirstTargetLock = false; usleep(150000);
        }
        return $result;
    }
}
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$connection = new mysqli(getenv('GLPICHAT_TEST_DB_HOST') ?: '127.0.0.1', getenv('GLPICHAT_TEST_DB_USER') ?: 'root', getenv('GLPICHAT_TEST_DB_PASSWORD') ?: '', '', (int) getenv('GLPICHAT_TEST_DB_PORT'));
$connection->set_charset('utf8mb4');
$worker = ($argv[3] ?? '') === '--worker';
$database = $worker ? $argv[4] : 'glpichat_poll_' . bin2hex(random_bytes(6));
if (!preg_match('/\Aglpichat_poll_[a-f0-9]+\z/D', $database)) { throw new RuntimeException('Disposable database name required.'); }
if (!$worker) { $connection->query('CREATE DATABASE `' . $database . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci'); }
$connection->select_db($database); $DB = new PollNativeDB($connection); $DB->dbdefault = $database;
$checks = [];
function poll_check(bool $condition, string $description): void {
    global $checks; if (!$condition) { throw new RuntimeException($description); } $checks[] = $description;
}
function poll_token(int $id): string { return str_pad(dechex($id), 64, '0', STR_PAD_LEFT); }
function poll_installation(int $id): string { return sprintf('aaaaaaaa-aaaa-aaaa-aaaa-%012d', $id); }
function poll_machine(int $id): array {
    return ['id' => $id, 'installation_id' => poll_installation($id), 'token_hash' => glpichat_management_hash('machine', poll_token($id)),
        'registration_id' => str_repeat('a',32), 'status' => 'active', 'computer_name' => sprintf('PC-%06d', $id), 'bootstrap_version' => '0.5.0', 'current_version' => '0.5.0',
        'current_sequence' => 1, 'current_slot' => 'a', 'health' => 'healthy', 'last_result' => 'initial_install', 'last_error' => '', 'last_seen' => null, 'created_at' => glpichat_desktop_now()];
}
function poll_report(array $replace = []): array {
    return array_replace(['bootstrap_version' => '0.5.0', 'current_version' => '0.5.0', 'current_sequence' => 1, 'current_slot' => 'a', 'health' => 'healthy',
        'result' => 'initial_install', 'error_code' => '', 'assignment_id' => 0], $replace);
}
function poll_http(int $id, array $replace = [], ?string $token = null, ?string $installation = null): array {
    $request = new Symfony\Component\HttpFoundation\Request([], [], [], [], [], ['REQUEST_METHOD' => 'POST', 'CONTENT_TYPE' => 'application/json',
        'HTTP_AUTHORIZATION' => 'Bearer ' . ($token ?? poll_token($id)), 'HTTP_X_GLPICHAT_INSTALLATION' => $installation ?? poll_installation($id)], json_encode(poll_report($replace), JSON_THROW_ON_ERROR));
    $response = (new GlpiPlugin\Glpichat\Controller\ManagementController())->dispatch($request, 'Poll');
    return ['status' => $response->getStatusCode(), 'body' => json_decode($response->getContent(), true, 32, JSON_THROW_ON_ERROR)];
}
function poll_job(int $machine, int $release = 1, int $admin = 1, ?string $request = null): array {
    return glpichat_management_create_rollout($release, 'update', glpichat_management_filters([]), 'selected', [$machine], [], $admin, $request ?? bin2hex(random_bytes(16)));
}
function poll_target(int $job, int $machine): array { return glpichat_management_one(GLPICHAT_MANAGEMENT_TARGETS, 'rollouts_id=' . $job . ' AND machines_id=' . $machine); }
function poll_cron(): array {
    $task = new CronTask(); // Real GLPI class; absent task ID deliberately skips only persisted cron logging.
    $result = GlpiPlugin\Glpichat\DesktopRolloutCron::cronProcessDesktopRollouts($task);
    $volume = new ReflectionProperty(CronTask::class, 'volume');
    return ['result' => $result, 'volume' => $volume->getValue($task)];
}
function poll_ddl(string $table, array $definition): string {
    $parts = [];
    foreach ($definition['columns'] as $name => $column) { $parts[] = '`' . $name . '` ' . str_replace(' ascii_bin', ' CHARACTER SET ascii COLLATE ascii_bin', $column['type']) . ($column['nullable'] ? ' NULL DEFAULT NULL' : ' NOT NULL') . ' ' . $column['extra']; }
    foreach ($definition['indexes'] as $name => $index) { $parts[] = ($name === 'PRIMARY' ? 'PRIMARY KEY' : ($index['unique'] ? 'UNIQUE KEY ' : 'KEY ') . '`' . $name . '`') . ' (`' . implode('`,`', $index['columns']) . '`)'; }
    return 'CREATE TABLE `' . $table . '` (' . implode(',', $parts) . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
}
if ($worker) {
    Config::$values['desktop_schema_version'] = '8';
    [$mode, $id, $barrier] = [$argv[5], (int) $argv[6], $argv[7]];
    touch($barrier . '.' . getmypid() . '.ready');
    $deadline = microtime(true) + 15;
    while (!is_file($barrier . '.go')) { if (microtime(true) > $deadline) { throw new RuntimeException('Start barrier timed out.'); } usleep(1000); }
    $DB->delayFirstLock = $mode !== 'complete'; $DB->delayFirstTargetLock = $mode === 'complete';
    if ($mode === 'poll') { $answer = poll_http($id); if ($answer['status'] !== 200) { throw new RuntimeException('Parallel Poll failed: ' . json_encode($answer)); } }
    elseif ($mode === 'complete') {
        $pending = glpichat_management_pending($id);
        $answer = poll_http($id, ['assignment_id'=>(int)$pending['id'],'result'=>'committed','current_version'=>'0.6.0','current_sequence'=>10]);
        if ($answer['status'] !== 200) { throw new RuntimeException('Parallel completion failed: '.json_encode($answer)); }
    }
    elseif ($mode === 'cron') { $answer = poll_cron(); }
    elseif ($mode === 'admin') { $answer = poll_job($id, 2, 20, str_pad(dechex($id),32,'b',STR_PAD_LEFT)); }
    else { throw new RuntimeException('Unknown worker mode.'); }
    echo json_encode(['mode' => $mode, 'answer' => $answer], JSON_THROW_ON_ERROR), "\n";
    exit;
}
$started = microtime(true); $barriers = [];
try {
    // Existing desktop10 queued rows are seeded while the schema still has its
    // exact v6 target shape. Run the production additive migration before Poll.
    foreach (glpichat_desktop_schema_definitions() as $table => $definition) {
        if ($table === GLPICHAT_MANAGEMENT_TARGETS) { foreach (['dispatch_attempts', 'last_attempt_at', 'last_error_ref'] as $column) { unset($definition['columns'][$column]); } }
        $connection->query(poll_ddl($table, $definition));
    }
    $connection->query('CREATE TABLE glpi_plugin_glpichat_messages (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,itilfollowups_id INT UNSIGNED NULL) ENGINE=InnoDB');
    for ($id = 1; $id <= 40; ++$id) { $DB->insert(GLPICHAT_MANAGEMENT_MACHINES, poll_machine($id)); }
    foreach ([1 => ['0.6.0',10], 2 => ['0.7.0',20]] as $id => [$version,$sequence]) {
        $manifest = json_encode(['schema'=>1,'product'=>'glpichat-desktop','version'=>$version,'sequence'=>$sequence,'platform'=>'windows','architecture'=>'x64','bootstrap_abi'=>2,'state_schema_min'=>1,'state_schema_max'=>1,'components'=>[]]);
        $DB->insert(GLPICHAT_MANAGEMENT_RELEASES, ['id'=>$id,'version'=>$version,'sequence'=>$sequence,'manifest_json'=>$manifest,'signature'=>'server-fixture-only','storage_key'=>str_pad(dechex($id),32,'0',STR_PAD_LEFT),'created_by'=>1,'created_at'=>glpichat_desktop_now()]);
    }
    $DB->insert(GLPICHAT_MANAGEMENT_ROLLOUTS, ['id'=>1,'request_id'=>str_repeat('f',32),'releases_id'=>1,'action'=>'update','filters_json'=>'{}','target_count'=>2,'status'=>'queued','created_by'=>1,'created_at'=>glpichat_desktop_now(),'completed_at'=>null]);
    foreach ([1,2] as $id) { $DB->insert(GLPICHAT_MANAGEMENT_TARGETS, ['rollouts_id'=>1,'machines_id'=>$id,'status'=>'queued','reason'=>'','available_at'=>glpichat_desktop_now(),'created_at'=>glpichat_desktop_now()]); }
    glpichat_desktop_schema_install(); glpichat_desktop_reset_request_context();
    poll_check(Config::$values['desktop_schema_version'] === '8' && glpichat_desktop_schema_health()['healthy'], 'Existing v6 queued deployment migrates to healthy v7');
    $before = count($DB->queries); $invalid = poll_http(1, [], str_repeat('e',64));
    poll_check($invalid['status'] === 401 && poll_target(1,1)['status'] === 'queued', 'Invalid token cannot dispatch existing queued work');
    poll_check(!array_filter(array_slice($DB->queries,$before), static fn($sql) => str_contains($sql, GLPICHAT_MANAGEMENT_TARGETS) && preg_match('/(?:INSERT|UPDATE|FOR UPDATE)/', $sql)), 'Invalid Poll performs no target mutation or target lock');
    $mismatch = poll_http(1, [], poll_token(1), poll_installation(2));
    poll_check($mismatch['status'] === 401 && poll_target(1,2)['status'] === 'queued', 'Another installation header cannot dispatch work');
    $first = poll_http(1);
    poll_check($first['status'] === 200 && ($first['body']['assignment']['release_id'] ?? 0) === 1, 'Legacy 0.5 Poll dispatches and receives pre-existing queued 0.6 update without cron');
    $assignment = $first['body']['assignment']['id'];
    poll_check(poll_target(1,1)['status'] === 'assigned' && poll_target(1,2)['status'] === 'queued', 'Authenticated fallback dispatches only the polling machine');
    $again = poll_http(1);
    poll_check($again['body']['assignment']['id'] === $assignment && count(glpichat_desktop_db_rows('SELECT id FROM ' . GLPICHAT_MANAGEMENT_ASSIGNMENTS . ' WHERE machines_id=1')) === 1, 'Repeated Poll returns one existing pending assignment');
    $begin = poll_http(1, ['assignment_id'=>$assignment,'result'=>'started']);
    poll_check($begin['body']['assignment']['id'] === $assignment && glpichat_management_one(GLPICHAT_MANAGEMENT_ASSIGNMENTS,'id='.$assignment)['status'] === 'started', 'Existing Bootstrap Begin retains exact assignment and starts it');
    $next = poll_job(1,2);
    $still = poll_http(1, ['assignment_id'=>$assignment,'result'=>'started']);
    poll_check($still['body']['assignment']['id'] === $assignment && poll_target((int)$next['id'],1)['status'] === 'waiting', 'New queued intent cannot replace a started assignment');
    poll_check((int)poll_target((int)$next['id'],1)['dispatch_attempts'] === 0, 'Waiting for an active assignment does not consume dispatch-failure budget');
    $connection->query('UPDATE ' . GLPICHAT_MANAGEMENT_TARGETS . ' SET available_at=UTC_TIMESTAMP() WHERE rollouts_id=' . (int)$next['id']);
    $done = poll_http(1, ['assignment_id'=>$assignment,'result'=>'committed','current_version'=>'0.6.0','current_sequence'=>10]);
    poll_check($done['status'] === 200 && poll_target(1,1)['status'] === 'completed' && glpichat_management_one(GLPICHAT_MANAGEMENT_ASSIGNMENTS,'id='.$assignment)['status'] === 'completed', 'Poll completion reconciles prior target without cron');
    poll_check(($done['body']['assignment']['release_id'] ?? 0) === 2, 'Completion can release the next due assignment during the same Poll');
    $nextAssignment = $done['body']['assignment']['id'];
    poll_http(1, ['assignment_id'=>$assignment,'result'=>'committed','current_version'=>'0.6.0','current_sequence'=>10]);
    poll_check(glpichat_management_one(GLPICHAT_MANAGEMENT_ASSIGNMENTS,'id='.$nextAssignment)['status'] === 'pending', 'Late prior completion cannot complete the new assignment');
    $newClient = poll_http(2, ['bootstrap_version'=>'0.6.0','computer_name'=>'PC-000002']);
    poll_check($newClient['status'] === 200 && ($newClient['body']['assignment']['release_id'] ?? 0) === 1, 'Current 0.6 Poll uses identical queued-work recovery path');
    $secondAssignment = $newClient['body']['assignment']['id'];
    poll_http(2, ['bootstrap_version'=>'0.6.0','assignment_id'=>$secondAssignment,'result'=>'started']);
    $secondDone = poll_http(2, ['bootstrap_version'=>'0.6.0','assignment_id'=>$secondAssignment,'result'=>'committed','current_version'=>'0.6.0','current_sequence'=>10]);
    poll_check($secondDone['status'] === 200 && $secondDone['body']['assignment'] === null && poll_target(1,2)['status'] === 'completed' && glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS,'id=1')['status'] === 'completed', 'Final machine completion closes the original rollout with no cron execution');
    $revokedJob = poll_job(3); glpichat_management_revoke('machine',3);
    $revoked = poll_http(3);
    poll_check($revoked['status'] === 401 && poll_target((int)$revokedJob['id'],3)['status'] === 'queued', 'Revoked machine cannot dispatch queued work');
    $raceJob = poll_job(7); $revokedBetweenTransactions = false;
    $DB->beforeTargetRead = static function () use ($database, &$revokedBetweenTransactions, $connection): void {
        poll_check(!(bool)$connection->query('SELECT @@in_transaction AS active')->fetch_assoc()['active'], 'Poll commits machine telemetry before it reads rollout targets');
        $other = new mysqli(getenv('GLPICHAT_TEST_DB_HOST') ?: '127.0.0.1', getenv('GLPICHAT_TEST_DB_USER') ?: 'root', getenv('GLPICHAT_TEST_DB_PASSWORD') ?: '', $database, (int)getenv('GLPICHAT_TEST_DB_PORT'));
        $other->query("UPDATE " . GLPICHAT_MANAGEMENT_MACHINES . " SET status='revoked' WHERE id=7"); $other->close();
        $revokedBetweenTransactions = true;
    };
    $race = poll_http(7); $raceTarget = poll_target((int)$raceJob['id'],7);
    poll_check($revokedBetweenTransactions && $race['status'] === 401 && $raceTarget['status'] === 'queued' && (int)$raceTarget['dispatch_attempts'] === 0, 'Revocation after initial authentication is revalidated before dispatch without consuming failure budget');
    $DB->update(GLPICHAT_MANAGEMENT_MACHINES,['bootstrap_version'=>'0.3.0'],['id'=>8]); $upgradedBootstrap = poll_job(8);
    $currentTelemetry = poll_http(8, ['bootstrap_version'=>'0.5.0']);
    poll_check($currentTelemetry['status'] === 200 && ($currentTelemetry['body']['assignment']['release_id'] ?? 0) === 1 && poll_target((int)$upgradedBootstrap['id'],8)['status'] === 'assigned', 'Dispatch eligibility uses committed current Bootstrap telemetry');
    $four = poll_job(4); $five = poll_job(5);
    $cron = poll_cron();
    poll_check($cron['result'] === 1 && $cron['volume'] >= 2 && poll_target((int)$four['id'],4)['status'] === 'assigned' && poll_target((int)$five['id'],5)['status'] === 'assigned', 'Actual plugin CronTask entrypoint continues bounded offline-machine dispatch');
    // Pending work remains offered until explicit newer intent; Poll itself may
    // not supersede the pending assignment merely because another target exists.
    $pending = glpichat_management_pending(4); poll_http(4);
    poll_check(glpichat_management_pending(4)['id'] === $pending['id'], 'Fallback preserves an existing pending operation');
    // A transient storage failure is visible, bounded and resumable, rather than
    // returning an unbounded, unobservable queue forever.
    $broken = poll_job(6);
    $failureRefs = [];
    for ($attempt=1; $attempt<=5; ++$attempt) {
        $connection->query('UPDATE ' . GLPICHAT_MANAGEMENT_TARGETS . ' SET available_at=UTC_TIMESTAMP() WHERE rollouts_id=' . (int)$broken['id']);
        $DB->failAssignment = true; $response = poll_http(6); $target = poll_target((int)$broken['id'],6);
        poll_check($response['status'] === 200 && $response['body']['assignment'] === null && (int)$target['dispatch_attempts'] === $attempt && $target['last_attempt_at'] !== null && preg_match('/\A[a-f0-9]{12,32}\z/D',$target['last_error_ref']) === 1, 'Dispatch failure ' . $attempt . ' records durable attempt and opaque diagnostic reference');
        $failureRefs[] = $target['last_error_ref'];
        if ($attempt < 5) {
            poll_check($target['status'] === 'queued' && $target['reason'] === 'storage_retry' && strtotime($target['available_at'].' UTC') - time() >= 60*(1 << ($attempt-1))-2, 'Storage retry ' . $attempt . ' respects bounded exponential backoff');
            $response = poll_http(6); $targetAgain = poll_target((int)$broken['id'],6);
            poll_check((int)$targetAgain['dispatch_attempts'] === $attempt && $response['body']['assignment'] === null, 'Early Poll cannot bypass storage backoff ' . $attempt);
        }
    }
    poll_check($target['status'] === 'failed' && $target['reason'] === 'dispatch_failed' && $target['completed_at'] !== null, 'Fifth failed dispatch becomes an explicit terminal target failure');
    $afterLimit = poll_http(6);
    poll_check($afterLimit['body']['assignment'] === null && (int)poll_target((int)$broken['id'],6)['dispatch_attempts'] === 5, 'Terminal target is not silently retried forever');
    $deadlockJob = poll_job(9); $DB->deadlockAssignment = true;
    $deadlockResponse = poll_http(9);
    $level = new ReflectionProperty(DBmysql::class,'transaction_level');
    poll_check($deadlockResponse['status'] === 200 && ($deadlockResponse['body']['assignment']['release_id'] ?? 0) === 1 && $DB->injectedDeadlocks === 1 && $level->getValue($DB) === 0 && (int)poll_target((int)$deadlockJob['id'],9)['dispatch_attempts'] === 0, 'Whole-transaction deadlock victim retries once with clean native transaction depth and no dispatch-failure charge');
    poll_check(count(glpichat_desktop_db_rows('SELECT id FROM '.GLPICHAT_MANAGEMENT_ASSIGNMENTS.' WHERE machines_id=9')) === 1, 'Deadlock retry commits exactly one assignment');
    $rollbackJob = poll_job(10); $DB->deadlockAssignment = true; $DB->failRollbackAfterDeadlock = true;
    $rollbackResponse = poll_http(10); $rollbackTarget = poll_target((int)$rollbackJob['id'],10);
    $DB->rollBack(); // Test-only reset: the deliberately failed wrapper could not decrement its own depth.
    poll_check($rollbackResponse['status'] === 503 && $rollbackTarget['status'] === 'queued' && (int)$rollbackTarget['dispatch_attempts'] === 0 && !glpichat_management_pending(10), 'Rollback failure terminates Poll without another dispatch or failure-record transaction');
    $completionJob = glpichat_management_create_rollout(1,'update',glpichat_management_filters([]),'selected',[11,12],[],1,bin2hex(random_bytes(16)));
    foreach([11,12] as $id){$offer=poll_http($id);poll_http($id,['assignment_id'=>$offer['body']['assignment']['id'],'result'=>'started']);}
    $barrier=sys_get_temp_dir().'/'.$database.'-completion';$barriers[]=$barrier;$children=[];
    foreach([11,12] as $id){
        $pipes=[];$process=proc_open([PHP_BINARY,'-c',php_ini_loaded_file(),__FILE__,$plugin,$core,'--worker',$database,'complete',(string)$id,$barrier],[1=>['pipe','w'],2=>['pipe','w']],$pipes);
        if(!is_resource($process)){throw new RuntimeException('Completion worker failed to start.');}$children[]=[$process,$pipes];
    }
    $deadline=microtime(true)+15;
    while(count(glob($barrier.'.*.ready'))<2){if(microtime(true)>$deadline){throw new RuntimeException('Completion barrier timed out.');}usleep(1000);}
    touch($barrier.'.go');$completionFailures=[];
    foreach($children as [$process,$pipes]){$out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);if(proc_close($process)!==0){$completionFailures[]=$err.$out;}}
    if($completionFailures){throw new RuntimeException(implode("\n",$completionFailures));}
    poll_check(poll_target((int)$completionJob['id'],11)['status']==='completed' && poll_target((int)$completionJob['id'],12)['status']==='completed' && glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS,'id='.(int)$completionJob['id'])['status']==='completed','Two same-rollout completion Polls commit concurrently without parent/target lock inversion');
    $aggregateJob=poll_job(13);$offer=poll_http(13);$report=['assignment_id'=>$offer['body']['assignment']['id'],'result'=>'committed','current_version'=>'0.6.0','current_sequence'=>10];
    $DB->failCompletion=true;$failedAggregate=poll_http(13,$report);
    poll_check($failedAggregate['status']===503 && poll_target((int)$aggregateJob['id'],13)['status']==='completed' && glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS,'id='.(int)$aggregateJob['id'])['status']!=='completed','Parent-summary failure preserves committed exact assignment and target outcome');
    $recoveredAggregate=poll_http(13,$report);
    poll_check($recoveredAggregate['status']===200 && glpichat_management_one(GLPICHAT_MANAGEMENT_ROLLOUTS,'id='.(int)$aggregateJob['id'])['status']==='completed','Next Poll recovers terminal-target parent summary without cron');
    // Independent processes race the exact public Poll, administrator service
    // and production CronTask entrypoint. A barrier releases all ready workers.
    $concurrent = []; $observedLockWaits = 0;
    for ($round=0; $round<4; ++$round) {
        $machine = 20+$round; $initial=poll_job($machine);
        $barrier=sys_get_temp_dir().'/'.$database.'-barrier-'.$round; $barriers[]=$barrier; $children=[];
        foreach (['poll','poll','cron','admin'] as $mode) {
            $pipes=[]; $process=proc_open([PHP_BINARY,'-c',php_ini_loaded_file(),__FILE__,$plugin,$core,'--worker',$database,$mode,(string)$machine,$barrier],[1=>['pipe','w'],2=>['pipe','w']],$pipes);
            if (!is_resource($process)) { throw new RuntimeException('Parallel process failed to start.'); }
            $children[]=[$process,$pipes];
        }
        $deadline=microtime(true)+15;
        while (count(glob($barrier.'.*.ready'))<count($children)) { if (microtime(true)>$deadline) { throw new RuntimeException('Workers did not reach concurrency barrier.'); } usleep(1000); }
        $waitsBefore=(int)$connection->query("SHOW GLOBAL STATUS LIKE 'Innodb_row_lock_waits'")->fetch_assoc()['Value'];
        touch($barrier.'.go');
        $workerFailures=[];
        foreach ($children as [$process,$pipes]) {
            $out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);
            $exit=proc_close($process);
            if ($exit!==0) {$workerFailures[]=$err.$out;}
            else {$concurrent[]=json_decode(trim($out),true,32,JSON_THROW_ON_ERROR);}
        }
        if($workerFailures){
            $engine=$connection->query('SHOW ENGINE INNODB STATUS')->fetch_assoc()['Status'];
            $start=strpos($engine,'LATEST DETECTED DEADLOCK');
            if($start!==false){fwrite(STDERR,substr($engine,$start,14000));}
        }
        if($workerFailures){throw new RuntimeException('Parallel worker failure: '.implode("\n",$workerFailures));}
        poll_check(true, 'All four concurrent Poll/cron/admin workers complete without lock failure');
        $roundWaits=(int)$connection->query("SHOW GLOBAL STATUS LIKE 'Innodb_row_lock_waits'")->fetch_assoc()['Value']-$waitsBefore;
        $observedLockWaits += $roundWaits;
        poll_check($roundWaits>0,'Parallel round '.$round.' observes real InnoDB lock contention');
        poll_cron(); $final=poll_http($machine);
        $active=glpichat_desktop_db_rows('SELECT id,releases_id FROM '.GLPICHAT_MANAGEMENT_ASSIGNMENTS." WHERE machines_id=$machine AND status IN ('pending','started')");
        poll_check(count($active)===1 && (int)$active[0]['releases_id']===2 && ($final['body']['assignment']['id']??0)===(int)$active[0]['id'], 'Concurrent intent converges to exactly one current assignment in round '.$round);
        $duplicate=glpichat_desktop_db_rows('SELECT machines_id,releases_id,COUNT(*) AS total FROM '.GLPICHAT_MANAGEMENT_ASSIGNMENTS.' WHERE machines_id='.$machine.' GROUP BY machines_id,releases_id HAVING COUNT(*)>1');
        poll_check($duplicate===[], 'Racing Poll and cron do not duplicate per-release assignment in round '.$round);
    }
    poll_check(!$connection->query('SELECT @@in_transaction AS active')->fetch_assoc()['active'], 'All native transaction boundaries close');
    echo json_encode(['suite'=>'desktop_rollout_poll_native_sql','checks'=>count($checks),'assertions'=>$checks,'elapsed_seconds'=>round(microtime(true)-$started,3),
        'concurrent_workers'=>count($concurrent)+2,'observed_lock_waits'=>$observedLockWaits,'failure_references'=>$failureRefs,
        'boundaries'=>'Production ManagementController/Poll/services/schema/CronTask entrypoint; actual GLPI11 DBmysql builders/savepoints + CronTask object; disposable MariaDB; explicit Config and synthetic release fixtures; no installed Windows or OS cron execution'],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)."\n";
} finally {
    foreach($barriers as $barrier){foreach(glob($barrier.'.*') as $path){unlink($path);}}
    $connection->query('DROP DATABASE `'.$database.'`');
}
