<?php

declare(strict_types=1);

/**
 * Production mirror history, source filtering, read bridge and event cursor on
 * actual MariaDB, GLPI11.0.7 DDL and GLPI's unchanged DBmysqlIterator builder.
 * Only UI display/Session/catalog boundaries are fixtures. No live server used.
 * Usage: php current_source_native_sql.php GLPI_ROOT
 * DB endpoint is supplied by the disposable qualification runner environment.
 */
namespace Glpi\Search {
    final class SearchOption {
        public static function getOptionsForItemtype(string $type): array {
            return [12 => ['table' => 'glpi_tickets', 'field' => 'status']];
        }
    }
}
namespace {
    if (PHP_SAPI !== 'cli' || $argc !== 2 || !getenv('GLPICHAT_TEST_DB_HOST')) {
        throw new \RuntimeException('Disposable database and pinned GLPI root required.');
    }
    $core = $argv[1];
    $ddlPath = $core . '/install/mysql/glpi-empty.sql';
    if (hash_file('sha256', $ddlPath) !== '5be41e407778eaa321a53a9fddb67b95de611037335836e2bf4cc2bfd554644f') {
        throw new \RuntimeException('Pinned GLPI11.0.7 native DDL required.');
    }
    final class Config {
        public static function getConfigurationValue(string $scope, string $key): string { return $key === 'desktop_schema_version' ? '8' : ''; }
    }
    final class Session { public static int $user = 10; public static function getLoginUserID(): int { return self::$user; } }
    final class Ticket {
        public static function getTable(): string { return 'glpi_tickets'; }
        public static function getStatus(int $id): string { return 'Status ' . $id; }
    }
    final class RequestType { public static function getTable(): string { return 'glpi_requesttypes'; } }
    final class Dropdown { public static function getDropdownName(string $table, int $id): string { return 'Portal'; } }
    final class DbUtils {
        public function formatUserName(int $id, ?string $login, ?string $real, ?string $first, mixed ...$unused): string { return trim($first . ' ' . $real) ?: $login; }
        public function getUserName(int $id, mixed ...$unused): string { return 'User ' . $id; }
    }
    require $core . '/vendor/autoload.php';
    require_once $core . '/src/DBmysql.php';
    require_once $core . '/src/DBmysqlIterator.php';
    require dirname(__DIR__, 2) . '/src/functions.php';
    require dirname(__DIR__, 2) . '/src/desktop/schema.php';
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connect = static fn(): mysqli => new mysqli(getenv('GLPICHAT_TEST_DB_HOST'), getenv('GLPICHAT_TEST_DB_USER') ?: 'root',
        getenv('GLPICHAT_TEST_DB_PASSWORD') ?: '', '', (int) getenv('GLPICHAT_TEST_DB_PORT'));
    $connection = $connect(); $peer = $connect();
    $connection->set_charset('utf8mb4'); $peer->set_charset('utf8mb4');
    $database = 'glpichat_sources_' . bin2hex(random_bytes(6));
    $connection->query('CREATE DATABASE `' . $database . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $connection->select_db($database); $peer->select_db($database);
    final class SourceSqlDB {
        public array $queries = [];
        public function __construct(public mysqli $connection) {}
        public static function quoteName(mixed $value): string { return DBmysql::quoteName($value); }
        public static function quoteValue(mixed $value): string { return DBmysql::quoteValue($value); }
        public function escape(string $value): string { return $this->connection->real_escape_string($value); }
        public function doQuery(string $sql): mysqli_result|bool { $this->queries[] = $sql; return $this->connection->query($sql); }
        public function fetchAssoc(mysqli_result $rows): array|false|null { return $rows->fetch_assoc(); }
        public function numrows(mysqli_result $rows): int { return $rows->num_rows; }
        public function dataSeek(mysqli_result $rows, int $position): bool { return $rows->data_seek($position); }
        public function freeResult(mysqli_result $rows): void { $rows->free(); }
        public function request(array $query): DBmysqlIterator { return (new DBmysqlIterator($this))->execute($query); }
        public function insert(string $table, array $values): bool {
            $sql = 'INSERT INTO ' . DBmysql::quoteName($table) . ' (' . implode(',', array_map([DBmysql::class, 'quoteName'], array_keys($values)))
                . ') VALUES (' . implode(',', array_map([DBmysql::class, 'quoteValue'], array_values($values))) . ')';
            return $this->doQuery($sql) === true;
        }
        public function insertId(): int { return $this->connection->insert_id; }
        public function update(string $table, array $values, array $where): bool {
            $set = [];
            foreach ($values as $column => $value) { $set[] = DBmysql::quoteName($column) . '=' . DBmysql::quoteValue($value); }
            $builder = new DBmysqlIterator($this); $builder->buildQuery(['FROM' => $table, 'WHERE' => $where]);
            $clause = explode(' WHERE ', $builder->getSql(), 2)[1] ?? '';
            if ($clause === '') { throw new RuntimeException('Missing test UPDATE scope'); }
            return $this->doQuery('UPDATE ' . DBmysql::quoteName($table) . ' SET ' . implode(',', $set) . ' WHERE ' . $clause) === true;
        }
    }
    $DB = new SourceSqlDB($connection);
    $_SESSION = ['glpi_currenttime' => '2026-10-05 12:00:00'];
    $checks = 0;
    $check = static function (bool $ok, string $message) use (&$checks): void {
        if (!$ok) { throw new RuntimeException($message); } ++$checks;
    };
    try {
        $ddl = file_get_contents($ddlPath);
        foreach (['glpi_tickets','glpi_tickets_users','glpi_itilfollowups','glpi_users','glpi_documents','glpi_documents_items','glpi_logs','glpi_requesttypes'] as $table) {
            if (preg_match('/CREATE TABLE `' . $table . '` \(.*?\) ENGINE=InnoDB[^;]*;/s', $ddl, $match) !== 1) { throw new RuntimeException('Missing pinned native table'); }
            $connection->query($match[0]);
        }
        $owned = glpichat_schema_queries();
        foreach (['rooms','participants','messages','readstates','events'] as $suffix) { $connection->query($owned['glpi_plugin_glpichat_' . $suffix]); }
        foreach (['desktopreads','browsersends','desktopsends'] as $suffix) {
            $table = 'glpi_plugin_glpichat_' . $suffix; $definition = glpichat_desktop_schema_definitions()[$table]; $parts = [];
            foreach ($definition['columns'] as $name => $column) {
                $parts[] = '`' . $name . '` ' . str_replace(' ascii_bin', ' CHARACTER SET ascii COLLATE ascii_bin', $column['type'])
                    . ($column['nullable'] ? ' NULL DEFAULT NULL' : ' NOT NULL') . ' ' . $column['extra'];
            }
            foreach ($definition['indexes'] as $name => $index) {
                $parts[] = ($name === 'PRIMARY' ? 'PRIMARY KEY' : ($index['unique'] ? 'UNIQUE KEY ' : 'KEY ') . '`' . $name . '`')
                    . ' (`' . implode('`,`', $index['columns']) . '`)';
            }
            $connection->query('CREATE TABLE `' . $table . '` (' . implode(',', $parts) . ') ENGINE=InnoDB');
        }
        $connection->query("INSERT INTO glpi_users (id,name) VALUES (10,'requester'),(11,'tech')");
        $connection->query("INSERT INTO glpi_tickets (id,name,status,entities_id) VALUES (7,'Scope',2,0),(8,'Other',2,0)");
        $connection->query("INSERT INTO glpi_tickets_users (tickets_id,users_id,type) VALUES (7,10,1)");
        $connection->query("INSERT INTO glpi_plugin_glpichat_rooms (id,tickets_id,room_type) VALUES (1,7,'public'),(2,7,'internal'),(3,8,'public')");
        $connection->query("INSERT INTO glpi_plugin_glpichat_participants (id,rooms_id,participant_type,users_id,joined_at,left_at) VALUES
            (1,1,'user',10,'2026-10-01 00:00:00','2026-10-02 00:00:00'),(2,1,'user',10,'2026-10-03 00:00:00',NULL),
            (3,1,'guest',0,'2026-10-03 00:00:00',NULL),(4,2,'user',10,'2026-10-03 00:00:00',NULL)");
        $connection->query("INSERT INTO glpi_itilfollowups (id,itemtype,items_id,users_id,content,is_private,date_creation) VALUES
            (101,'Ticket',7,11,'edited &amp; current',0,'2026-10-04 10:00:00'),(102,'Ticket',7,11,'private now',1,'2026-10-04 10:00:00'),
            (104,'Ticket',8,11,'other ticket',0,'2026-10-04 10:00:00'),(105,'Ticket',7,11,'attachment',0,'2026-10-04 10:00:00')");
        foreach ([[1,1,101,0,'user'],[2,1,102,0,'user'],[3,1,103,0,'user'],[4,1,104,0,'user'],[5,1,0,0,'guest'],
            [6,1,0,0,'system'],[7,1,0,0,'user'],[8,1,105,1,'user'],[9,2,102,0,'user']] as [$id,$room,$followup,$document,$actor]) {
            $DB->insert('glpi_plugin_glpichat_messages', ['id'=>$id,'rooms_id'=>$room,'tickets_id'=>7,'participant_type'=>$actor,'users_id'=>$actor==='user'?11:0,
                'participants_id'=>0,'message_type'=>$document?'attachment':'message','content'=>'STALE','documents_id'=>$document,'itilfollowups_id'=>$followup,'date_creation'=>'2026-10-04 10:00:00']);
        }
        $connection->query("INSERT INTO glpi_documents (id,name,entities_id) VALUES (1,'note.txt',0)");
        $connection->query("INSERT INTO glpi_documents_items (documents_id,itemtype,items_id) VALUES (1,'ITILFollowup',105)");
        $page = glpichat_message_page(1,0);
        $check(array_column($page['messages'],'id') === [1,5,6,8], 'Public page must reject private/deleted/wrong-ticket/unlinked user mirrors while retaining plugin guest/system rows');
        $check($page['messages'][0]['content'] === 'edited & current' && $page['next_message_id'] === 8, 'Current native body replaces stale mirror and raw cursor consumes hidden entries');
        $check(glpichat_room_last_message_id(1) === 8 && glpichat_unread_count_for_participant(1,2) === 4, 'Head and unread use identical current-source visibility');
        $check(array_column(glpichat_messages(2,0),'id') === [9], 'Internal mirror retains native private source in its own scope');
        $connection->query('DELETE FROM glpi_documents_items');
        $check(glpichat_message_by_id(8)['documents_id'] === 0, 'Removed native document relation cannot remain actionable from stale mirror metadata');
        $connection->query('UPDATE glpi_itilfollowups SET is_private=1 WHERE id=105');
        $refresh = glpichat_refresh_messages(1,[1,2,3,4,8,9]);
        $check(array_column($refresh['refreshed_messages'],'id') === [1] && $refresh['removed_message_ids'] === [2,3,4,8,9], 'Exact-ID refresh removes revoked/missing/foreign-room rows and rehydrates visible edits');
        $guestRefresh = glpichat_refresh_messages(1,[1], '2026-10-05 00:00:00');
        $check($guestRefresh['refreshed_messages'] === [] && $guestRefresh['removed_message_ids'] === [1], 'Guest refresh cannot bypass join-date history boundary');
        $connection->query("INSERT INTO glpi_plugin_glpichat_readstates (rooms_id,participants_id,last_read_messages_id,date_mod) VALUES (1,1,6,'2026-10-04 12:00:00')");
        $check(glpichat_readstate_last_message_id(1,2) === 6 && glpichat_unread_count_for_participant(1,2) === 0, 'Recreated user presence carries prior user-room cursor without replaying old unread');
        $check(glpichat_readstate_last_message_id(1,3) === 0, 'Guest read position stays separate from user cursor');
        glpichat_mark_read(1,2,1);
        $check(glpichat_readstate_last_message_id(1,2) === 6, 'Older acknowledgement on recreated participant cannot lower stable user cursor');
        $nativeRead = $connection->query('SELECT itilfollowups_id FROM glpi_plugin_glpichat_desktopreads ORDER BY itilfollowups_id')->fetch_all(MYSQLI_ASSOC);
        $check(array_column($nativeRead,'itilfollowups_id') === ['101'], 'Web public acknowledgement bridges native IDs only; private/deleted/guest/system sources excluded');
        $desktop = glpichat_desktop_conversations(['user_id'=>10,'entity_id'=>0,'can_read'=>true,'can_create'=>true],0,30);
        $check($desktop['conversations'][0]['unread_count'] === 0 && $desktop['conversations'][0]['latest_message_id'] === 101,
            'Production desktop aggregate observes web read bridge while retaining current native public head');
        glpichat_mark_read(2,4,9);
        $check($connection->query('SELECT COUNT(*) FROM glpi_plugin_glpichat_desktopreads')->fetch_row()[0] === '1', 'Internal read never bridges into public desktop scope');
        $connection->query('DELETE FROM glpi_plugin_glpichat_readstates');
        $check(glpichat_unread_count_for_participant(1,2) === 2, 'Desktop exact native read suppresses matching public mirror without advancing over unread guest/system rows');
        $check(glpichat_unread_count_for_participant(1,3) === 3, 'Desktop read never suppresses guest unread state');
        // Fifty hidden mirrors must still expose continuation, in both directions.
        for ($id=10; $id<=65; ++$id) { $DB->insert('glpi_plugin_glpichat_messages', ['id'=>$id,'rooms_id'=>1,'tickets_id'=>7,'participant_type'=>'user','users_id'=>11,'participants_id'=>0,
            'message_type'=>'message','content'=>'private','itilfollowups_id'=>102,'date_creation'=>'2026-10-04 10:00:00']); }
        $hidden = glpichat_message_page(1,8);
        $check($hidden['messages'] === [] && $hidden['has_more'] && $hidden['next_message_id'] === 59, 'All-hidden forward page advances raw cursor and signals continuation');
        $back = glpichat_messages_before_page(1,0,50);
        $check($back['messages'] === [] && $back['has_more'] && $back['next_before'] === 16, 'All-hidden backwards page advances raw cursor and signals continuation');
        // Production three-source event pipeline: 100 same-date consumed rows
        // plus later-time rows and >100 no-op logs cannot starve the next poll.
        $connection->query("INSERT INTO glpi_requesttypes (id,name) VALUES (99,'GLPI Chat')");
        $connection->query('UPDATE glpi_itilfollowups SET requesttypes_id=99');
        for ($id=1; $id<=125; ++$id) {
            $date = $id<=120 ? '2026-10-04 11:00:00' : '2026-10-04 11:00:01';
            $DB->insert('glpi_plugin_glpichat_events',['id'=>$id,'rooms_id'=>1,'tickets_id'=>7,'event_type'=>'user_joined','actor_type'=>'user','users_id'=>11,'participants_id'=>0,'payload_json'=>'{}','date_creation'=>$date]);
            $DB->insert('glpi_itilfollowups',['id'=>200+$id,'itemtype'=>'Ticket','items_id'=>7,'users_id'=>11,'content'=>'event','is_private'=>0,'requesttypes_id'=>0,'date_creation'=>$date]);
            $DB->insert('glpi_logs',['id'=>$id,'itemtype'=>'Ticket','items_id'=>7,'id_search_option'=>12,'old_value'=>'1','new_value'=>'1','date_mod'=>$date]);
        }
        $DB->insert('glpi_logs',['id'=>126,'itemtype'=>'Ticket','items_id'=>7,'id_search_option'=>12,'old_value'=>'1','new_value'=>'2','date_mod'=>'2026-10-04 11:00:02']);
        $cursor='2026-10-04 10:59:59|L|000000000000'; $events=[];
        for ($round=0; $round<8; ++$round) {
            $chunk=glpichat_events(1,$cursor);
            if (!$chunk) { break; }
            array_push($events,...$chunk); $cursor=$chunk[count($chunk)-1]['id'];
        }
        $check(count($events) === 251 && count(array_unique(array_column($events,'id'))) === 251, 'Full SQL event cursors traverse >100 same-date rows across sources without loss or duplicates');
        $check(str_ends_with($cursor,'|L|000000000126'), 'No-op logs are removed before LIMIT so later meaningful transition remains reachable');
        // Native shared authority locks allow peer readers while still blocking
        // an administrative writer until the current operation commits.
        $connection->begin_transaction(); $peer->begin_transaction();
        $connection->query('SELECT id FROM glpi_users WHERE id=10 LOCK IN SHARE MODE');
        $start=microtime(true); $peer->query('SELECT id FROM glpi_users WHERE id=10 LOCK IN SHARE MODE');
        $check(microtime(true)-$start < 1, 'Shared authority row reads permit unrelated authenticated writes to progress');
        $peer->rollback();
        $peer->query("UPDATE glpi_users SET is_active=0 WHERE id=10", MYSQLI_ASYNC);
        $read=[$peer];$error=[$peer];$reject=[$peer];
        $check(mysqli_poll($read,$error,$reject,0,100000) === 0, 'Authority update remains blocked by held shared lock');
        $connection->commit(); $read=[$peer];$error=[$peer];$reject=[$peer];
        $check(mysqli_poll($read,$error,$reject,2) === 1 && $peer->reap_async_query() === true, 'Authority update completes after current write releases its shared lock');
        echo '[PASS] Current-source native SQL: ' . $checks . ' checks; MariaDB ' . $connection->server_info . "; pinned GLPI11.0.7 DDL + production SQL builder.\n";
    } finally {
        $connection->rollback(); $peer->close(); $connection->query('DROP DATABASE `' . $database . '`'); $connection->close();
    }
}
