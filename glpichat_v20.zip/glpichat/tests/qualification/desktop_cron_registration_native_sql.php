<?php
declare(strict_types=1);
/** Unmodified GLPI Migration/CronTask/DBmysql + native table DDL, disposable MariaDB.
 * Usage: php desktop_cron_registration_native_sql.php PLUGIN_ROOT GLPI_ROOT [system]
 */
if (PHP_SAPI !== 'cli' || $argc < 3) { exit(2); }
[$unused, $plugin, $core] = $argv;
require $core . '/vendor/autoload.php';
define('GLPI_SYSTEM_CRON', ($argv[3] ?? '') === 'system');
require $plugin . '/src/desktop/cron_registration.php';
final class RegistrationNativeDB extends DBmysql {
    public function __construct(mysqli $connection) { $this->dbh = $connection; $this->connected = true; }
    public function doQuery($query) { return $this->dbh->query($query); }
}
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$connection = new mysqli(getenv('GLPICHAT_TEST_DB_HOST') ?: '127.0.0.1', getenv('GLPICHAT_TEST_DB_USER') ?: 'root', getenv('GLPICHAT_TEST_DB_PASSWORD') ?: '', '', (int) getenv('GLPICHAT_TEST_DB_PORT'));
$database = 'glpichat_cron_' . bin2hex(random_bytes(6));
$connection->query('CREATE DATABASE `' . $database . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
$connection->select_db($database); $DB = new RegistrationNativeDB($connection); $DB->dbdefault = $database;
$checks = [];
function registration_check(bool $ok, string $description): void { global $checks; if (!$ok) { throw new RuntimeException($description); } $checks[] = $description; }
function registration_row(): array { global $connection; return $connection->query('SELECT * FROM glpi_crontasks')->fetch_assoc(); }
try {
    $ddl = file_get_contents($core . '/install/mysql/glpi-empty.sql');
    preg_match('/CREATE TABLE `glpi_crontasks` \(.*?\n\) ENGINE=.*?;/s', $ddl, $match);
    $connection->query($match[0]);
    $migration = new Migration('1.6.1');
    glpichat_desktop_register_rollout_cron($migration, '');
    $desired = GLPI_SYSTEM_CRON ? CronTask::MODE_EXTERNAL : CronTask::MODE_INTERNAL;
    registration_check((int) registration_row()['mode'] === $desired, 'Fresh task uses explicit host scheduling mode');
    $connection->query('TRUNCATE glpi_crontasks');
    $migration->addCrontask('GlpiPlugin\\Glpichat\\DesktopRolloutCron', 'ProcessDesktopRollouts', 60);
    registration_check((int) registration_row()['mode'] === CronTask::MODE_EXTERNAL, 'Reproduces desktop10 implicit CLI registration with actual native Migration');
    $original = registration_row();
    glpichat_desktop_register_rollout_cron($migration, '6');
    $fixed = registration_row();
    registration_check((int) $fixed['mode'] === $desired, 'Schema6 untouched never-run task is repaired in place');
    registration_check(array_diff_assoc($original, $fixed) === (GLPI_SYSTEM_CRON ? [] : ['mode' => '2']), 'Repair changes mode only, retaining identity/history/settings');
    glpichat_desktop_register_rollout_cron($migration, '7');
    registration_check(registration_row() === $fixed, 'Repeated schema7 lifecycle is idempotent');
    foreach ([['state'=>0], ['state'=>2], ['lastrun'=>'2026-10-01 12:00:00'], ['frequency'=>300], ['hourmin'=>3], ['allowmode'=>2], ['comment'=>'Explicit admin choice'], ['logs_lifetime'=>7], ['param'=>5], ['lastcode'=>0]] as $custom) {
        $DB->update('glpi_crontasks', array_replace(['mode'=>2,'state'=>1,'lastrun'=>null,'frequency'=>60,'hourmin'=>0,'allowmode'=>3,'comment'=>'','logs_lifetime'=>30,'param'=>null,'lastcode'=>null], $custom), ['id'=>(int)$fixed['id']]);
        $before = registration_row();
        glpichat_desktop_register_rollout_cron($migration, '6');
        registration_check(registration_row() === $before, 'Preserves administrator/runtime setting ' . key($custom));
    }
    $hook = file_get_contents($plugin . '/hook.php');
    registration_check(str_contains($hook, 'glpichat_desktop_register_rollout_cron($cron_migration'), 'Install/update hook calls the tested native registration helper');
    echo json_encode(['checks'=>count($checks),'passed'=>$checks,'system_cron'=>GLPI_SYSTEM_CRON,'native_migration_sha256'=>hash_file('sha256',$core.'/src/Migration.php'),'scope'=>'Unmodified GLPI11 Migration and DBmysql SQL, native glpi_crontasks DDL and actual MariaDB; no production host changes.'], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) . "\n";
} finally { $connection->query('DROP DATABASE `' . $database . '`'); }
