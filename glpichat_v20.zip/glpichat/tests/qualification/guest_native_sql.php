<?php

declare(strict_types=1);
/** Production guest/invite services, pinned GLPI SQL builder and nested
 * transactions, disposable MariaDB and concurrent PHP workers. ITIL writers,
 * session/config/ACL, event persistence and presentation are explicit fixtures;
 * this does not claim a full GLPI HTTP/notification/Windows environment.
 * Usage: php guest_native_sql.php PLUGIN_ROOT GLPI_ROOT [--worker DATABASE OP DATA]
 */
if (PHP_SAPI !== 'cli' || $argc < 3) { exit(2); }
[$unused, $plugin, $core] = $argv;
require $core . '/vendor/autoload.php';
foreach (['DBmysql','DBmysqlIterator','DBConnection'] as $class) { require_once $core . '/src/' . $class . '.php'; }
require $plugin . '/src/guest_delivery.php';
require $plugin . '/src/db/guest_db.php';
require $plugin . '/src/db/invite_db.php';
require $plugin . '/src/flows/invite_flow.php';
require $plugin . '/src/desktop/schema.php';
require $plugin . '/src/db/setup_helpers.php';
require $plugin . '/src/notification_queue.php';
require $plugin . '/src/message_source.php';
final class Config {
    public static array $values = ['guest_session_ttl'=>3600,'invite_ttl_seconds'=>7200,'max_invites_per_ticket'=>10,'guest_send_throttle_s'=>2];
    public static function getConfigurationValue(string $scope,string $key): mixed {return self::$values[$key]??null;}
}
final class GuestNativeDB extends DBmysql {
    public string $fault='';
    public function __construct(mysqli $connection) {$this->dbh=$connection;$this->connected=true;}
    public function doQuery($query) {
        $result=$this->dbh->query($query);
        if ($this->fault==='queue' && str_starts_with($query,'INSERT INTO `glpi_plugin_glpichat_notificationjobs`')) { throw new RuntimeException('Injected durable queue fault'); }
        return $result;
    }
}
final class Ticket {
    public array $fields=[];
    public static function getMergedTickets(int $id): array {return [];}
    public function getFromDB(int $id): bool {$this->fields=glpichat_guest_row('SELECT * FROM glpi_tickets WHERE id='.$id);return (bool)$this->fields;}
}
final class ITILFollowup {
    public array $fields=[];
    public function add(array $input): int {global $DB;foreach(array_keys($input)as$key){if(str_starts_with($key,'_')){unset($input[$key]);}}$DB->insert('glpi_itilfollowups',$input);return (int)$DB->insertId();}
    public function getFromDB(int $id): bool {$this->fields=glpichat_guest_row('SELECT * FROM glpi_itilfollowups WHERE id='.$id);return(bool)$this->fields;}
    public function getID(): int {return(int)$this->fields['id'];}
}
final class RequestType {public function find(...$args): array{return [['id'=>1,'is_active'=>1,'is_itilfollowup'=>1]];}}
final class NotificationEvent {public static array $events=[];public static function raiseEvent($event,$ticket,$options,$trigger): bool {self::$events[]=[$event,$options];return true;}}
function glpichat_config_int(string$key,int$default):int{return(int)(Config::$values[$key]??$default);}
function glpichat_external_followup_user_id():int{return 99;}
function glpichat_current_user_id():int{return 1;}
function glpichat_can_create_invites(int$id):bool{return true;}
function glpichat_can_update_invites(int$id):bool{return true;}
function glpichat_can_user_read_notification_room(...$args):bool{return true;}
function glpichat_room_by_id(int$id):array{return glpichat_guest_row('SELECT * FROM glpi_plugin_glpichat_rooms WHERE id='.$id);}
function glpichat_room_id(int$ticket,string$room):int{return(int)glpichat_guest_row('SELECT id FROM glpi_plugin_glpichat_rooms WHERE tickets_id='.$ticket.' AND room_type='.glpichat_desktop_quote($room))['id'];}
function glpichat_record_event(int$room,int$ticket,string$event,string$actor,int$user,int$participant,array$payload):void{global$DB;$DB->insert('glpi_plugin_glpichat_events',['rooms_id'=>$room,'tickets_id'=>$ticket,'event_type'=>$event,'actor_type'=>$actor,'users_id'=>$user,'participants_id'=>$participant,'payload_json'=>json_encode($payload)]);}
function glpichat_add_message(int$ticket,string$room,string$actor,int$user,int$participant,string$content,int$document,int$followup,bool$notify=true):int{global$DB;if($notify){throw new RuntimeException('Inline notifications forbidden');}$DB->insert('glpi_plugin_glpichat_messages',['rooms_id'=>glpichat_room_id($ticket,$room),'tickets_id'=>$ticket,'participant_type'=>$actor,'users_id'=>$user,'participants_id'=>$participant,'message_type'=>$document>0?'attachment':'message','content'=>$content,'documents_id'=>$document,'itilfollowups_id'=>$followup]);return(int)$DB->insertId();}
function glpichat_message_by_id(int$id):array{$rows=glpichat_current_message_rows(glpichat_desktop_db_rows('SELECT * FROM glpi_plugin_glpichat_messages WHERE id='.$id));if(!$rows){throw new RuntimeException('Unavailable');}$rows[0]['actor_type']=$rows[0]['participant_type'];return$rows[0];}
function glpichat_refresh_messages(int$room,array$ids,string$minDate=''):array{$rows=glpichat_current_message_rows(glpichat_desktop_db_rows('SELECT * FROM glpi_plugin_glpichat_messages WHERE rooms_id='.$room.' AND id IN('.implode(',',array_map('intval',$ids)).') AND date_creation>='.glpichat_desktop_quote($minDate)));return['refreshed_messages'=>$rows,'removed_message_ids'=>array_values(array_diff($ids,array_column($rows,'id')))];}
function guest_check(bool$ok,string$label):void{++$GLOBALS['checks'];if(!$ok){throw new RuntimeException($label);}}
function guest_error(callable$fn,string$code):void{try{$fn();}catch(GlpichatGuestException$e){guest_check($e->errorCode===$code,'Expected '.$code.', got '.$e->errorCode);return;}throw new RuntimeException('Expected '.$code);}
function guest_scalar(string$sql):int{return(int)array_values(glpichat_guest_row($sql))[0];}
function guest_uuid(int$n):string{return sprintf('aaaaaaaa-aaaa-4aaa-8aaa-%012d',$n);}
function guest_invite(int$n,int$ticket=1):string{$token=str_pad(dechex($n),64,'0',STR_PAD_LEFT);glpichat_insert_invite($ticket,$ticket,glpichat_guest_invite_token_hash($token),1,'Guest '.$n,'',date('Y-m-d H:i:s',time()+600));return$token;}
function guest_ddl(string$table,array$def):string{$parts=[];foreach($def['columns']as$name=>$col){$parts[]='`'.$name.'` '.str_replace(' ascii_bin',' CHARACTER SET ascii COLLATE ascii_bin',$col['type']).($col['nullable']?' NULL DEFAULT NULL':' NOT NULL').' '.$col['extra'];}foreach($def['indexes']as$name=>$idx){$parts[]=($name==='PRIMARY'?'PRIMARY KEY':($idx['unique']?'UNIQUE KEY ':'KEY ').'`'.$name.'`').' (`'.implode('`,`',$idx['columns']).'`)';}return'CREATE TABLE `'.$table.'` ('.implode(',',$parts).') ENGINE=InnoDB';}
mysqli_report(MYSQLI_REPORT_ERROR|MYSQLI_REPORT_STRICT);
$connection=new mysqli(getenv('GLPICHAT_TEST_DB_HOST')?:'127.0.0.1',getenv('GLPICHAT_TEST_DB_USER')?:'root',getenv('GLPICHAT_TEST_DB_PASSWORD')?:'','',(int)getenv('GLPICHAT_TEST_DB_PORT'));
$connection->set_charset('utf8mb4');
$worker=($argv[3]??'')==='--worker';$database=$worker?$argv[4]:'glpichat_guest_'.bin2hex(random_bytes(6));
if(!preg_match('/\Aglpichat_guest_[a-f0-9]+\z/D',$database)){throw new RuntimeException('Disposable database required');}
if(!$worker){$connection->query('CREATE DATABASE `'.$database.'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');}
$connection->select_db($database);$DB=new GuestNativeDB($connection);$DB->dbdefault=$database;
$connection->query("SET time_zone='+00:00'");
$_SESSION=[];$CFG_GLPI=['root_doc'=>'/nested/glpi'];$checks=0;
if($worker){$data=json_decode(base64_decode($argv[6]),true);try{$result=match($argv[5]){'accept'=>glpichat_guest_accept_atomic(...$data),'revoke'=>glpichat_revoke_invite_atomic(...$data),'send'=>glpichat_guest_deliver(...$data),'end'=>glpichat_guest_end_atomic(...$data)};echo json_encode(['ok'=>true,'result'=>$result]);}catch(GlpichatGuestException$e){echo json_encode(['ok'=>false,'code'=>$e->errorCode]);}exit;}
function guest_parallel(array$operations):array{global$plugin,$core,$database,$DB;$DB->beginTransaction();glpichat_guest_lock_ticket(1);$children=[];foreach($operations as[$op,$data]){$pipes=[];$process=proc_open([PHP_BINARY,'-c',php_ini_loaded_file(),__FILE__,$plugin,$core,'--worker',$database,$op,base64_encode(json_encode($data))],[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);fclose($pipes[0]);$children[]=[$process,$pipes];}usleep(100000);$DB->commit();$result=[];foreach($children as[$process,$pipes]){$out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);if(proc_close($process)!==0){throw new RuntimeException('Worker failed '.$err.' '.$out);}$result[]=json_decode($out,true,512,JSON_THROW_ON_ERROR);}return$result;}
$docRoot=sys_get_temp_dir().'/glpichat-guest-'.bin2hex(random_bytes(5));mkdir($docRoot);define('GLPI_DOC_DIR',$docRoot);
try{
 $ddlPath=$core.'/install/mysql/glpi-empty.sql';
 if(hash_file('sha256',$ddlPath)!=='5be41e407778eaa321a53a9fddb67b95de611037335836e2bf4cc2bfd554644f'){throw new RuntimeException('Pinned GLPI DDL required');}
 $ddl=file_get_contents($ddlPath);
 foreach(['glpi_tickets','glpi_itilfollowups','glpi_documents','glpi_documents_items']as$table){if(!preg_match('/CREATE TABLE `'.$table.'` \(.*?\) ENGINE=.*?;/s',$ddl,$m)){throw new RuntimeException('DDL missing '.$table);}$connection->query($m[0]);}
 foreach(glpichat_schema_queries()as$sql){$connection->query($sql);}
 foreach(glpichat_desktop_schema_definitions()as$table=>$def){if(in_array($table,['glpi_plugin_glpichat_guestsends','glpi_plugin_glpichat_notificationjobs'],true)){$connection->query(guest_ddl($table,$def));}}
 foreach([1,2]as$id){$DB->insert('glpi_tickets',['id'=>$id,'name'=>'Test','entities_id'=>1,'status'=>1]);$DB->insert('glpi_plugin_glpichat_rooms',['id'=>$id,'tickets_id'=>$id,'room_type'=>'public']);}
 $token=guest_invite(1);$claim=str_repeat('a',64);$DB->fault='queue';
 try{glpichat_guest_accept_atomic($token,$claim);throw new LogicException('Fault did not throw');}catch(RuntimeException$e){guest_check(str_contains($e->getMessage(),'Injected'),'Injected queue failure reaches caller: '.$e->getMessage());}$DB->fault='';
 guest_check(guest_scalar('SELECT COUNT(*) FROM glpi_plugin_glpichat_participants')===0&&guest_scalar('SELECT COUNT(*) FROM glpi_itilfollowups')===0&&guest_scalar('SELECT COUNT(*) FROM glpi_plugin_glpichat_events')===0,'Failed acceptance rolls back participant/native followup/events');
 guest_check(glpichat_guest_row('SELECT accepted_at FROM glpi_plugin_glpichat_invites WHERE id=1')['accepted_at']===null,'Failure leaves invitation consumable');
 $accepted=glpichat_guest_accept_atomic($token,$claim);$again=glpichat_guest_accept_atomic($token,$claim);
 guest_check($accepted===$again&&guest_scalar('SELECT COUNT(*) FROM glpi_plugin_glpichat_participants')===1,'Lost-response recovery uses same participant and token');
 guest_error(fn()=>glpichat_guest_accept_atomic($token,str_repeat('b',64)),'invite_unavailable');
 $pid=$accepted['participants_id'];$session=$accepted['session_token'];
 $id1=guest_uuid(1);$group=guest_uuid(100);$input=['content'=>'One <safe> text','client_message_id'=>$id1,'submission_id'=>$group,'submission_count'=>2];
 $first=glpichat_guest_deliver($session,$input);$replay=glpichat_guest_deliver($session,$input);
 guest_check($first['message_id']===$replay['message_id']&&guest_scalar('SELECT COUNT(*) FROM glpi_plugin_glpichat_messages')===1,'Stable UUID retry acknowledges exactly one durable message');
 guest_check($first['message']['client_message_id']===$id1,'Current guest receives receipt identity');
 guest_error(fn()=>glpichat_guest_deliver($session,array_replace($input,['content'=>'changed'])),'idempotency_conflict');
 $second=glpichat_guest_deliver($session,array_replace($input,['content'=>'piece two','client_message_id'=>guest_uuid(2)]));
 guest_check($second['message_id']!==$first['message_id'],'Second composition piece admitted without2second throttle');
 guest_error(fn()=>glpichat_guest_deliver($session,array_replace($input,['client_message_id'=>guest_uuid(3)])),'submission_full');
 guest_error(fn()=>glpichat_guest_deliver($session,['content'=>'next','client_message_id'=>guest_uuid(4)]),'send_throttled');
 $DB->update('glpi_plugin_glpichat_participants',['last_send_at'=>date('Y-m-d H:i:s',time()-5)],['id'=>$pid]);
 $dupe=['content'=>'Concurrent','client_message_id'=>guest_uuid(5)];$concurrent=guest_parallel([['send',[$session,$dupe]],['send',[$session,$dupe]]]);
 guest_check($concurrent[0]['ok']&&$concurrent[1]['ok']&&$concurrent[0]['result']['message_id']===$concurrent[1]['result']['message_id'],'Concurrent receipt retries commit one source');
 guest_check(guest_scalar('SELECT COUNT(*) FROM glpi_plugin_glpichat_guestsends')===3,'Group and concurrent attempts store exactlythree pieces');
 $other=glpichat_guest_accept_atomic(guest_invite(2,2),$claim);$otherParticipant=glpichat_guest_participant($other['session_token']);
 $beforeMessages=guest_scalar('SELECT COUNT(*) FROM glpi_plugin_glpichat_messages');
 $oldTab=['content'=>'Wrong tab draft','client_message_id'=>guest_uuid(88),'expected_participant_id'=>$pid,'expected_rooms_id'=>1];
 guest_error(fn()=>glpichat_guest_deliver($other['session_token'],$oldTab),'guest_context_changed');
 guest_error(fn()=>glpichat_guest_deliver($other['session_token'],$oldTab,new stdClass()),'guest_context_changed');
 guest_error(fn()=>glpichat_guest_download($other['session_token'],1,1,$oldTab),'guest_context_changed');
 guest_check(guest_scalar('SELECT COUNT(*) FROM glpi_plugin_glpichat_messages')===$beforeMessages,'Old tab cannot write under a replaced shared guest cookie');
 $decorated=glpichat_guest_decorate_messages([$first['message']],$otherParticipant);guest_check(!isset($decorated[0]['client_message_id']),'Other guest never receives sender receipt UUID');
 $DB->update('glpi_tickets',['status'=>6],['id'=>1]);guest_error(fn()=>glpichat_guest_deliver($session,['content'=>'closed','client_message_id'=>guest_uuid(6)]),'conversation_read_only');guest_check(glpichat_guest_deliver($session,$input)['message_id']===$first['message_id'],'Receipt replay survives ticket closure');$DB->update('glpi_tickets',['status'=>1],['id'=>1]);
 $row=glpichat_guest_row('SELECT * FROM glpi_plugin_glpichat_messages WHERE id='.$first['message_id']);$DB->update('glpi_itilfollowups',['is_private'=>1],['id'=>$row['itilfollowups_id']]);guest_error(fn()=>glpichat_guest_deliver($session,$input),'message_unavailable');$DB->update('glpi_itilfollowups',['is_private'=>0],['id'=>$row['itilfollowups_id']]);
 $token3=guest_invite(3);$invite3=guest_scalar('SELECT MAX(id) FROM glpi_plugin_glpichat_invites');$res=glpichat_reissue_invite_atomic($invite3,'https://glpi.example/nested/glpi');guest_check(abs(strtotime($res['expires_at'])-time()-7200)<5,'Reissue uses configuredTTL');guest_error(fn()=>glpichat_guest_accept_atomic($token3,$claim),'invite_unavailable');
 Config::$values['max_invites_per_ticket']=1;guest_error(fn()=>glpichat_create_invite_atomic(1,'Quota','','https://glpi.example'),'invite_limit');Config::$values['max_invites_per_ticket']=10;
 glpichat_revoke_invite_atomic($invite3);guest_error(fn()=>glpichat_reissue_invite_atomic($invite3,'https://glpi.example'),'invite_revoked');
 $raceToken=guest_invite(4);$raceId=guest_scalar('SELECT MAX(id) FROM glpi_plugin_glpichat_invites');$race=guest_parallel([['accept',[$raceToken,$claim]],['revoke',[$raceId]]]);$inv=glpichat_find_invite_by_id($raceId);guest_check($inv['revoked_at']!==null,'Concurrent revoke commits');if((int)$inv['participants_id']>0){$p=glpichat_guest_row('SELECT * FROM glpi_plugin_glpichat_participants WHERE id='.(int)$inv['participants_id']);guest_check($p['left_at']!==null&&$p['session_token_hash']===null,'Accept/revoke race leaves no active guest');}else{guest_check(!$race[0]['ok'],'Revoke-first accept rejected');}
 $before=guest_scalar("SELECT COUNT(*) FROM glpi_plugin_glpichat_events WHERE event_type='guest_left'");guest_parallel([['end',[$pid,date('Y-m-d H:i:s')]],['end',[$pid,date('Y-m-d H:i:s')]]]);guest_check(guest_scalar("SELECT COUNT(*) FROM glpi_plugin_glpichat_events WHERE event_type='guest_left'")===$before+1,'Concurrent disconnect emits exactlyone event');
 $join=glpichat_guest_row("SELECT * FROM glpi_plugin_glpichat_notificationjobs WHERE source_type='participant' AND source_id=$pid AND event='glpichat_guest_joined'");guest_check(!glpichat_deliver_notification_job($join),'Deferred stale join suppressed after disconnect');
 $left=glpichat_guest_row("SELECT * FROM glpi_plugin_glpichat_notificationjobs WHERE source_type='participant' AND source_id=$pid AND event='glpichat_guest_left'");guest_check(glpichat_deliver_notification_job($left)&&end(NotificationEvent::$events)[1]['glpichat_guest_name']==='Guest 1','Deferred left event carries current guest name');
 foreach([['submission_count'=>12],['client_message_id'=>'bad'],['submission_id'=>[]]]as$invalid){guest_error(fn()=>glpichat_guest_delivery_ids(array_replace(['client_message_id'=>guest_uuid(8)],$invalid)),isset($invalid['submission_count'])?'invalid_submission':'invalid_message_id');}
 // Authenticated download checks use real document bytes, native relation and source freshness.
 $download=glpichat_guest_accept_atomic(guest_invite(9,2),str_repeat('c',64));$dp=$download['participants_id'];file_put_contents($docRoot.'/payload.txt','safe bytes');
 $DB->insert('glpi_documents',['entities_id'=>1,'name'=>'payload','filename'=>'payload.txt','filepath'=>'payload.txt','mime'=>'text/plain','sha1sum'=>sha1('safe bytes')]);$doc=(int)$DB->insertId();$f=glpichat_guest_native_followup(2,99,'Attachment');$DB->insert('glpi_documents_items',['documents_id'=>$doc,'itemtype'=>'ITILFollowup','items_id'=>$f]);$m=glpichat_add_message(2,'public','guest',0,$dp,'Attachment',$doc,$f,false);
 $response=glpichat_guest_download($download['session_token'],$m,$doc);guest_check(str_starts_with($response->headers->get('Content-Disposition'),'attachment;'),'Guest download is authenticated attachment disposition');
 guest_error(fn()=>glpichat_guest_download($other['session_token'],$first['message_id'],$doc),'attachment_unavailable');
 $DB->update('glpi_plugin_glpichat_messages',['date_creation'=>date('Y-m-d H:i:s',time()-7200)],['id'=>$m]);guest_error(fn()=>glpichat_guest_download($download['session_token'],$m,$doc),'attachment_unavailable');$DB->update('glpi_plugin_glpichat_messages',['date_creation'=>date('Y-m-d H:i:s')],['id'=>$m]);
 $DB->update('glpi_itilfollowups',['is_private'=>1],['id'=>$f]);guest_error(fn()=>glpichat_guest_download($download['session_token'],$m,$doc),'attachment_unavailable');$DB->update('glpi_itilfollowups',['is_private'=>0],['id'=>$f]);$connection->query('DELETE FROM glpi_documents_items WHERE documents_id='.$doc);guest_error(fn()=>glpichat_guest_download($download['session_token'],$m,$doc),'attachment_unavailable');
 // Timeout rechecks fresh activity under lock and emits one lifecycle transition.
 guest_check(!glpichat_guest_end_atomic($dp,date('Y-m-d H:i:s'),true),'Fresh activity prevents stale timeout cleanup');
 $expiredId=$other['participants_id'];$DB->update('glpi_plugin_glpichat_participants',['last_activity'=>date('Y-m-d H:i:s',time()-7200)],['id'=>$expiredId]);
 guest_error(fn()=>glpichat_guest_participant($other['session_token']),'session_expired');guest_error(fn()=>glpichat_guest_participant($other['session_token']),'session_expired');
 guest_check(guest_scalar("SELECT COUNT(*) FROM glpi_plugin_glpichat_events WHERE participants_id=$expiredId AND event_type='guest_left_timeout'")===1,'Expired session creates one timeout event across retries');
 // Earlier releases could revoke an invitation before the participant was attached.
 $legacyToken=guest_invite(10,2);$legacyInvite=guest_scalar('SELECT MAX(id) FROM glpi_plugin_glpichat_invites');$legacy=glpichat_guest_accept_atomic($legacyToken,str_repeat('d',64));
 $DB->update('glpi_plugin_glpichat_invites',['revoked_at'=>date('Y-m-d H:i:s')],['id'=>$legacyInvite]);
 guest_error(fn()=>glpichat_guest_participant($legacy['session_token']),'session_expired');
 glpichat_revoke_invite_atomic($legacyInvite);guest_check(glpichat_guest_row('SELECT left_at FROM glpi_plugin_glpichat_participants WHERE id='.$legacy['participants_id'])['left_at']!==null,'Repeated revoke repairs legacy active participant');
 // Cleanup retains all active-session receipts and recently ended sessions.
 Config::$values['desktop_schema_version']='6';$old=date('Y-m-d H:i:s',time()-40*86400);
 $DB->update('glpi_plugin_glpichat_participants',['left_at'=>$old],['id'=>$pid]);
 $template=glpichat_guest_row('SELECT * FROM glpi_plugin_glpichat_guestsends LIMIT 1');unset($template['id']);
 foreach([$dp,$pid,$expiredId,999999]as$i=>$subject){$copy=$template;$copy['participants_id']=$subject;$copy['client_message_id']=guest_uuid(500+$i);$copy['created_at']=$old;$DB->insert('glpi_plugin_glpichat_guestsends',$copy);}
 guest_check(glpichat_cleanup_guest_receipts(1)===1,'Cleanup deletes at most requested old-ended batch');
 guest_check(glpichat_cleanup_guest_receipts(1000)===1,'Cleanup removes orphan subject receipts but retains active and recently ended');
 guest_check(guest_scalar("SELECT COUNT(*) FROM glpi_plugin_glpichat_guestsends WHERE client_message_id='".guest_uuid(500)."'")===1,'Active session retains old receipt');
 echo json_encode(['checks'=>$checks,'result'=>'passed','boundaries'=>'native GLPI DBmysql+MariaDB; ITIL/session/ACL/presentation fixtures'],JSON_PRETTY_PRINT)."\n";
}finally{$connection->query('DROP DATABASE `'.$database.'`');if(is_file($docRoot.'/payload.txt')){unlink($docRoot.'/payload.txt');}rmdir($docRoot);}
