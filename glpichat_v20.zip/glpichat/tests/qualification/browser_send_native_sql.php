<?php

declare(strict_types=1);

/**
 * Production browser receipt/notification services with real MariaDB transactions.
 * Usage: php browser_send_native_sql.php PLUGIN_ROOT GLPI_11_0_7_DDL TEST_SOCKET OUTPUT_JSON [USER]
 * Creates and drops only a random test database. Never supply a production server.
 * Core Ticket/Session/ACL/writer/render/event classes are explicit fixtures. Their
 * writes use real pinned core tables; no live GLPI request, mail or AD is invoked.
 */
if (PHP_SAPI !== 'cli' || $argc < 5 || $argc > 6) { fwrite(STDERR, "Invalid qualification arguments.\n"); exit(2); }
[$unused, $plugin, $ddlPath, $socket, $resultPath] = $argv;
$ddlHash = '5be41e407778eaa321a53a9fddb67b95de611037335836e2bf4cc2bfd554644f';
if (hash_file('sha256', $ddlPath) !== $ddlHash) { throw new RuntimeException('Pinned official GLPI11.0.7 DDL required.'); }
require $plugin . '/src/browser_delivery.php';
require $plugin . '/src/notification_queue.php';
require $plugin . '/src/desktop/schema.php';
require $plugin . '/src/db/setup_helpers.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$connection = new mysqli(getenv('GLPICHAT_TEST_DB_HOST') ?: 'localhost', $argv[5] ?? 'root', getenv('GLPICHAT_TEST_DB_PASSWORD') ?: '', '',
    (int) (getenv('GLPICHAT_TEST_DB_PORT') ?: 0), getenv('GLPICHAT_TEST_DB_HOST') ? null : $socket);
$connection->set_charset('utf8mb4');
$peer = new mysqli(getenv('GLPICHAT_TEST_DB_HOST') ?: 'localhost', $argv[5] ?? 'root', getenv('GLPICHAT_TEST_DB_PASSWORD') ?: '', '',
    (int) (getenv('GLPICHAT_TEST_DB_PORT') ?: 0), getenv('GLPICHAT_TEST_DB_HOST') ? null : $socket);
$peer->set_charset('utf8mb4');
$database = 'glpichat_delivery_sql_' . bin2hex(random_bytes(8));
$connection->query('CREATE DATABASE `' . $database . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
$connection->select_db($database); $peer->select_db($database);

final class NativeDeliveryDB
{
    public array $queries = [];
    public bool $active = false, $allowed = true;
    public string $fault = '';
    public function __construct(public mysqli $connection) {}
    public function escape(string $value): string { return $this->connection->real_escape_string($value); }
    public function quote(mixed $value): string {
        return $value === null ? 'NULL' : (is_int($value) ? (string) $value : "'" . $this->escape((string) $value) . "'");
    }
    private function name(string $value): string {
        if (!preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/D', $value)) { throw new RuntimeException('Invalid fixture identifier.'); }
        return '`' . $value . '`';
    }
    private function where(array $where): string {
        $parts = [];
        foreach ($where as $column => $value) {
            $operator = '=';
            if (is_array($value)) {
                [$operator, $value] = $value;
                if (!in_array($operator, ['=', '<=', '>=', '<', '>'], true)) { throw new RuntimeException('Unsupported fixture comparison.'); }
            }
            $parts[] = $this->name($column) . ($value === null ? ' IS NULL' : ' ' . $operator . ' ' . $this->quote($value));
        }
        return implode(' AND ', $parts);
    }
    public function doQuery(string $sql): mysqli_result|bool { $this->queries[] = $sql; return $this->connection->query($sql); }
    public function fetchAssoc(mysqli_result $result): array|false|null { return $result->fetch_assoc(); }
    public function insert(string $table, array $values): bool {
        if ($this->fault === 'notification_insert' && $table === 'glpi_plugin_glpichat_notificationjobs' && $values['source_type'] === 'message') { return false; }
        $columns = array_map(fn(string $name): string => $this->name($name), array_keys($values));
        return $this->doQuery('INSERT INTO ' . $this->name($table) . ' (' . implode(',', $columns) . ') VALUES ('
            . implode(',', array_map(fn(mixed $value): string => $this->quote($value), array_values($values))) . ')') === true;
    }
    public function insertId(): int { return (int) $this->connection->insert_id; }
    public function update(string $table, array $values, array $where): bool {
        if ($this->fault === 'receipt_completion' && $table === 'glpi_plugin_glpichat_browsersends') { return false; }
        $set = [];
        foreach ($values as $name => $value) { $set[] = $this->name($name) . '=' . $this->quote($value); }
        return $this->doQuery('UPDATE ' . $this->name($table) . ' SET ' . implode(',', $set) . ' WHERE ' . $this->where($where)) === true;
    }
    public function request(array $query): ArrayIterator {
        $columns = $query['SELECT'] ?? ['*'];
        $select = implode(',', array_map(fn(string $name): string => $name === '*' ? '*' : $this->name($name), $columns));
        $sql = 'SELECT ' . $select . ' FROM ' . $this->name($query['FROM']);
        if (!empty($query['WHERE'])) { $sql .= ' WHERE ' . $this->where($query['WHERE']); }
        if (!empty($query['ORDER'])) {
            $order = [];
            foreach ($query['ORDER'] as $field) {
                if (!preg_match('/^([a-z_]+) (ASC|DESC)$/D', $field, $match)) { throw new RuntimeException('Unsupported fixture order.'); }
                $order[] = $this->name($match[1]) . ' ' . $match[2];
            }
            $sql .= ' ORDER BY ' . implode(',', $order);
        }
        if (isset($query['LIMIT'])) { $sql .= ' LIMIT ' . max(1, (int) $query['LIMIT']); }
        return new ArrayIterator($this->doQuery($sql)->fetch_all(MYSQLI_ASSOC));
    }
    public function beginTransaction(): void {
        if ($this->active) { throw new RuntimeException('Unexpected nested test transaction.'); }
        $this->connection->begin_transaction(); $this->active = true;
    }
    public function commit(): void { $this->connection->commit(); $this->active = false; }
    public function rollBack(): void { $this->connection->rollback(); $this->active = false; }
}
$DB = new NativeDeliveryDB($connection);

// Explicit GLPI integration boundaries; production receipt and queue services
// above are not reimplemented. Every fixture mutation reaches the native engine.
final class Config { public static function getConfigurationValue(string $scope, string $key): string { return '5'; } }
final class Session { public static int $user = 10; public static function getLoginUserID(): int { return self::$user; } }
final class Ticket {
    public array $fields = [];
    public function getFromDB(int $id): bool { global $DB; $this->fields = $DB->request(['FROM' => 'glpi_tickets', 'WHERE' => ['id' => $id]])->current() ?? []; return $this->fields !== []; }
}
final class ITILFollowup {
    public array $fields = [];
    public function getFromDB(int $id): bool { global $DB; $this->fields = $DB->request(['FROM' => 'glpi_itilfollowups', 'WHERE' => ['id' => $id]])->current() ?? []; return $this->fields !== []; }
    public function getID(): int { return (int) ($this->fields['id'] ?? 0); }
}
final class NotificationEvent {
    public static function raiseEvent(string $event, Ticket $ticket, array $options, ?ITILFollowup $trigger): bool {
        global $DB;
        if (!$DB->active) { throw new RuntimeException('Core event fixture must run inside worker transaction.'); }
        $DB->insert('glpi_queuednotifications', ['itemtype' => 'Ticket', 'items_id' => (int) $ticket->fields['id'],
            'mode' => 'test', 'event' => $event, 'name' => 'Native SQL qualification', 'body_text' => 'Fixture event',
            'items_id_trigger' => $trigger?->getID() ?? 0]);
        if ($DB->fault === 'event_after_write') { throw new RuntimeException('Injected event rendering failure after native queue write.'); }
        return true;
    }
}
function glpichat_current_user_id(): int { return Session::$user; }
function &glpichat_ticket_or_fail_cache(): array { static $cache = []; return $cache; }
function glpichat_is_ticket_terminal_for_chat(int $id): bool { return false; }
function glpichat_can_read_room(int $ticket, string $room): bool { global $DB; return $DB->allowed; }
function glpichat_can_send(int $ticket, string $room): bool { global $DB; return $DB->allowed; }
function glpichat_can_user_read_notification_room(int $user, int $ticket, string $room): bool { global $DB; return $DB->allowed; }
function getUserName(int $user): string { return 'Test user'; }
function glpichat_room_id(int $ticket, string $room): int {
    global $DB; return (int) $DB->request(['FROM' => 'glpi_plugin_glpichat_rooms', 'WHERE' => ['tickets_id' => $ticket, 'room_type' => $room]])->current()['id'];
}
function glpichat_participant_id_for_user(int $room, int $user, bool $raise = true, bool $defer = false): int {
    global $DB;
    if (!$DB->active || !$defer) { throw new RuntimeException('Participant fixture must defer inside transaction.'); }
    $row = $DB->request(['FROM' => 'glpi_plugin_glpichat_participants', 'WHERE' => ['rooms_id' => $room, 'users_id' => $user]])->current();
    if (is_array($row)) { return (int) $row['id']; }
    $DB->insert('glpi_plugin_glpichat_participants', ['rooms_id' => $room, 'users_id' => $user, 'participant_type' => 'user']);
    $id = $DB->insertId();
    $roomRow = $DB->request(['FROM' => 'glpi_plugin_glpichat_rooms', 'WHERE' => ['id' => $room]])->current();
    glpichat_queue_user_joined_notification((int) $roomRow['tickets_id'], $roomRow['room_type'], $user, $id);
    return $id;
}
function glpichat_add_followup(int $ticket, int $user, string $content, bool $private, bool $defer = false): int {
    global $DB;
    if (!$DB->active || !$defer) { throw new RuntimeException('Native writer fixture must defer inside transaction.'); }
    $DB->insert('glpi_itilfollowups', ['itemtype' => 'Ticket', 'items_id' => $ticket, 'users_id' => $user,
        'content' => $content, 'is_private' => (int) $private, 'date' => date('Y-m-d H:i:s')]);
    $id = $DB->insertId(); $followup = new ITILFollowup(); $followup->getFromDB($id);
    glpichat_queue_native_followup_notification($followup);
    return $id;
}
function glpichat_add_message(int $ticket, string $room, string $actor, int $user, int $participant, string $content, int $document, int $followup, bool $notify = true): int {
    global $DB;
    if (!$DB->active || $notify) { throw new RuntimeException('Mirror fixture must suppress inline notification.'); }
    $DB->insert('glpi_plugin_glpichat_messages', ['rooms_id' => glpichat_room_id($ticket, $room), 'tickets_id' => $ticket,
        'participant_type' => $actor, 'users_id' => $user, 'participants_id' => $participant, 'message_type' => 'message',
        'content' => $content, 'documents_id' => $document, 'itilfollowups_id' => $followup]);
    $id = $DB->insertId();
    if ($DB->fault === 'mirror_after_write') { throw new RuntimeException('Injected mirror failure after insert.'); }
    return $id;
}
function glpichat_message_by_id(int $id): array {
    global $DB;
    if ($DB->fault === 'render') { throw new RuntimeException('Injected response rendering failure.'); }
    return $DB->request(['FROM' => 'glpi_plugin_glpichat_messages', 'WHERE' => ['id' => $id]])->current();
}
$checks = [];
function verify(bool $ok, string $description): void { global $checks; $checks[] = ['description' => $description, 'pass' => $ok]; if (!$ok) { throw new RuntimeException($description); } }
function rejection(callable $action, string $code, string $description): void {
    try { $action(); } catch (Throwable $error) { verify($code === '' || ($error instanceof GlpichatDesktopException && $error->errorCode === $code), $description); return; }
    throw new RuntimeException('Expected rejection: ' . $description);
}
function counts(): array {
    global $connection;
    $result = [];
    foreach (['glpi_itilfollowups', 'glpi_plugin_glpichat_messages', 'glpi_plugin_glpichat_participants',
        'glpi_plugin_glpichat_browsersends', 'glpi_plugin_glpichat_notificationjobs', 'glpi_queuednotifications'] as $table) {
        $result[$table] = (int) $connection->query('SELECT COUNT(*) AS n FROM `' . $table . '`')->fetch_assoc()['n'];
    }
    return $result;
}
function lock_name(string $uuid): string { return 'glpichat-send-' . substr(hash('sha256', Session::$user . ':' . $uuid), 0, 48); }
try {
    $ddl = file_get_contents($ddlPath);
    foreach (['glpi_tickets', 'glpi_itilfollowups', 'glpi_queuednotifications'] as $table) {
        if (preg_match('/CREATE TABLE `' . $table . '` \(.*?\) ENGINE=InnoDB[^;]*;/s', $ddl, $match) !== 1) { throw new RuntimeException('Native table missing.'); }
        $connection->query($match[0]);
    }
    $schema = glpichat_schema_queries();
    foreach (['glpi_plugin_glpichat_rooms', 'glpi_plugin_glpichat_messages', 'glpi_plugin_glpichat_participants'] as $table) { $connection->query($schema[$table]); }
    $desktopSchema = glpichat_desktop_schema_definitions();
    foreach (['glpi_plugin_glpichat_browsersends', 'glpi_plugin_glpichat_notificationjobs'] as $table) {
        $parts = [];
        foreach ($desktopSchema[$table]['columns'] as $name => $column) {
            $type = str_replace(' ascii_bin', ' CHARACTER SET ascii COLLATE ascii_bin', $column['type']);
            $parts[] = '`' . $name . '` ' . $type . ($column['nullable'] ? ' NULL DEFAULT NULL' : ' NOT NULL') . ' ' . $column['extra'];
        }
        foreach ($desktopSchema[$table]['indexes'] as $name => $index) {
            $prefix = $name === 'PRIMARY' ? 'PRIMARY KEY' : ($index['unique'] ? 'UNIQUE KEY ' : 'KEY ') . '`' . $name . '`';
            $parts[] = $prefix . ' (`' . implode('`,`', $index['columns']) . '`)';
        }
        $connection->query('CREATE TABLE `' . $table . '` (' . implode(',', $parts) . ') ENGINE=InnoDB');
    }
    $connection->query("INSERT INTO glpi_tickets (id,name,status,entities_id,is_deleted) VALUES (7,'Native qualification',2,2,0)");
    $connection->query("INSERT INTO glpi_plugin_glpichat_rooms (id,tickets_id,room_type) VALUES (70,7,'public'),(71,7,'internal')");
    $uuid = '01234567-89ab-4cde-8fab-0123456789ab';
    $first = glpichat_browser_send(7, 'public', 'Hello', $uuid);
    $baseline = counts();
    verify(array_values($baseline) === [1,1,1,1,3,0], 'First production send commits one followup, mirror, participant, receipt and three durable intents, without inline queue delivery');
    $replay = glpichat_browser_send(7, 'public', 'Hello', $uuid);
    verify($replay === $first && counts() === $baseline, 'Exact retry executes guarded receipt replay without duplicate rows or jobs');
    rejection(fn() => glpichat_browser_send(7, 'public', 'Changed', $uuid), 'idempotency_conflict', 'Same UUID with different content is rejected by the production receipt path');
    $DB->allowed = false;
    rejection(fn() => glpichat_browser_send(7, 'public', 'Hello', $uuid), 'authorization_denied', 'Current ACL fixture denial precedes existing receipt disclosure');
    $DB->allowed = true;
    $followupId = (int) $first['message']['itilfollowups_id'];
    $connection->query("UPDATE glpi_itilfollowups SET is_private=1 WHERE id=$followupId");
    rejection(fn() => glpichat_browser_send(7, 'public', 'Hello', $uuid), 'message_unavailable', 'Native private-source change prevents public replay');
    $connection->query("UPDATE glpi_itilfollowups SET is_private=0 WHERE id=$followupId");
    foreach (['mirror_after_write','receipt_completion','notification_insert','render'] as $index => $fault) {
        $DB->fault = $fault;
        $faultUuid = (string) ($index + 1) . substr($uuid, 1);
        rejection(fn() => glpichat_browser_send(7, 'public', 'Fault ' . $fault, $faultUuid), '', 'Injected ' . $fault . ' aborts production send');
        $DB->fault = '';
        verify(counts() === $baseline && !$DB->active, 'Real MariaDB rollback removes all source, mirror, receipt and job writes after ' . $fault);
        $lock = $peer->real_escape_string(lock_name($faultUuid));
        verify((int) $peer->query("SELECT GET_LOCK('$lock',0) AS acquired")->fetch_assoc()['acquired'] === 1, 'Failure releases the production named lock after ' . $fault);
        $peer->query("SELECT RELEASE_LOCK('$lock')");
    }
    $busyUuid = '51234567-89ab-4cde-8fab-0123456789ab';
    $lock = $peer->real_escape_string(lock_name($busyUuid));
    verify((int) $peer->query("SELECT GET_LOCK('$lock',0) AS acquired")->fetch_assoc()['acquired'] === 1, 'Independent second connection owns the exact production UUID lock');
    $started = microtime(true);
    rejection(fn() => glpichat_browser_send(7, 'public', 'Contended', $busyUuid), 'send_busy', 'Production GET_LOCK returns send_busy across two real connections');
    verify(microtime(true) - $started < 1.0 && counts() === $baseline, 'Contended send is nonblocking and creates no rows');
    $peer->query("SELECT RELEASE_LOCK('$lock')");
    $contended = glpichat_browser_send(7, 'public', 'Contended', $busyUuid);
    $after = counts();
    verify($after['glpi_plugin_glpichat_browsersends'] === 2 && $after['glpi_plugin_glpichat_messages'] === 2, 'Released lock permits exactly one later durable send');
    verify(glpichat_browser_send(7, 'public', 'Contended', $busyUuid) === $contended && counts() === $after, 'Post-contention retry reuses the committed receipt');
    $receipt = $connection->query('SELECT * FROM glpi_plugin_glpichat_browsersends ORDER BY id LIMIT 1')->fetch_assoc(); unset($receipt['id']);
    try { $DB->insert('glpi_plugin_glpichat_browsersends', $receipt); throw new RuntimeException('Expected unique-key failure.'); }
    catch (mysqli_sql_exception $error) { verify($error->getCode() === 1062, 'Actual browser receipt unique key rejects a duplicate user UUID'); }
    $job = $connection->query('SELECT * FROM glpi_plugin_glpichat_notificationjobs ORDER BY id LIMIT 1')->fetch_assoc();
    $jobCount = counts()['glpi_plugin_glpichat_notificationjobs'];
    glpichat_queue_notification_job($job['source_type'], (int) $job['source_id'], (int) $job['tickets_id'], $job['event'], $job['room_type'], (int) $job['users_id']);
    verify(counts()['glpi_plugin_glpichat_notificationjobs'] === $jobCount, 'Production durable-intent helper deduplicates an existing source event');
    $duplicateJob = $job; unset($duplicateJob['id']);
    try { $DB->insert('glpi_plugin_glpichat_notificationjobs', $duplicateJob); throw new RuntimeException('Expected unique-key failure.'); }
    catch (mysqli_sql_exception $error) { verify($error->getCode() === 1062, 'Actual source/event unique key remains the durable notification guard'); }
    $rows = $connection->query('SELECT * FROM glpi_plugin_glpichat_messages ORDER BY id')->fetch_all(MYSQLI_ASSOC);
    verify(glpichat_browser_attach_receipts($rows)[0]['client_message_id'] === $uuid, 'Actual history receipt JOIN exposes the matching current actor token');
    Session::$user = 11;
    verify(!isset(glpichat_browser_attach_receipts($rows)[0]['client_message_id']), 'Actual history receipt JOIN withholds another actor token');
    Session::$user = 10;
    $firstJob = (int) $job['id'];
    $future = $DB->quote(date('Y-m-d H:i:s', time() + 86400));
    $connection->query("UPDATE glpi_plugin_glpichat_notificationjobs SET available_at=$future WHERE id<>$firstJob");
    $DB->fault = 'event_after_write'; $_SESSION = ['test_sentinel' => 'preserved'];
    $processed = glpichat_process_notification_jobs(1);
    $DB->fault = '';
    verify($processed === ['delivered' => 0, 'suppressed' => 0, 'failed' => 1] && counts()['glpi_queuednotifications'] === 0,
        'Production worker rolls back a real core queue-table write when event rendering throws');
    $pending = $connection->query("SELECT * FROM glpi_plugin_glpichat_notificationjobs WHERE id=$firstJob")->fetch_assoc();
    verify($pending['status'] === 'pending' && (int) $pending['attempts'] === 1 && $pending['last_error'] === 'RuntimeException',
        'Failed native transaction leaves one pending durable intent with bounded retry metadata');
    verify($_SESSION === ['test_sentinel' => 'preserved'], 'Production event path restores the caller session even on failure');
    $past = $DB->quote(date('Y-m-d H:i:s', time() - 1));
    $connection->query("UPDATE glpi_plugin_glpichat_notificationjobs SET available_at=$past WHERE id=$firstJob");
    verify(glpichat_process_notification_jobs(1)['delivered'] === 1 && counts()['glpi_queuednotifications'] === 1,
        'Worker retry commits exactly one core queue row together with the completed job');
    verify(glpichat_process_notification_jobs(1) === ['delivered' => 0, 'suppressed' => 0, 'failed' => 0]
        && counts()['glpi_queuednotifications'] === 1, 'Completed intent is not rendered again on the next worker pass');
    $connection->query("UPDATE glpi_plugin_glpichat_notificationjobs SET available_at=$past WHERE status='pending'");
    verify(glpichat_process_notification_jobs(20)['delivered'] === $jobCount - 1 && counts()['glpi_queuednotifications'] === $jobCount,
        'Native and plugin source validation deliver each remaining intent exactly once in core queue tables');
    verify(glpichat_process_notification_jobs(20)['delivered'] === 0 && counts()['glpi_queuednotifications'] === $jobCount,
        'Repeated worker pass leaves committed queue rows unchanged');
    $hashes = [];
    foreach (['src/browser_delivery.php', 'src/notification_queue.php', 'src/desktop/common.php', 'src/desktop/conversations.php', 'src/desktop/schema.php',
        'src/flows/message_flow.php', 'src/domain/domain.php', 'src/db/setup_helpers.php', 'tests/qualification/browser_send_native_sql.php'] as $source) {
        $hashes[$source] = hash_file('sha256', $plugin . '/' . $source);
    }
    $result = ['engine' => $connection->server_info, 'core_version' => 'GLPI11.0.7', 'core_ddl_sha256' => $ddlHash,
        'command' => array_merge([PHP_BINARY], $argv), 'source_sha256' => $hashes, 'checks' => $checks, 'passed' => count($checks),
        'executed_sql_statements' => count($DB->queries),
        'limits' => ['Production browser receipt, replay SQL, named locks, transaction helper, notification-intent helper and default notification worker executed.',
            'Native core and plugin table DDL executed by MariaDB; GET_LOCK checked across two independent connections.',
            'GLPI Ticket/Session/ACL/native writer/mirror/render and NotificationEvent classes are explicit fixtures; their inserts target real core tables.',
            'No live GLPI request, genuine GLPI writer hooks, mail delivery, browser, Windows or AD execution.']];
    file_put_contents($resultPath, json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . "\n");
    echo 'PASS native browser delivery SQL: ' . count($checks) . ' assertions; ' . $connection->server_info . '; production receipt/queue services; explicit GLPI writer fixtures.' . "\n";
} finally {
    if ($DB->active) { $DB->rollBack(); }
    $connection->query('DROP DATABASE `' . $database . '`');
    $peer->close(); $connection->close();
}
