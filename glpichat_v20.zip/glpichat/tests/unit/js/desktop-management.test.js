import { beforeEach, expect, it, vi } from 'vitest';

beforeEach(() => { vi.resetModules(); sessionStorage.clear(); document.body.innerHTML = ''; });
async function page(ids = ['1', '2'], { owner = '7', filters = '{}', committed = '0' } = {}) {
  vi.resetModules();
  document.body.innerHTML = `<form id="desktop-assignment" data-total="6000" data-owner="${owner}" data-committed="${committed}">
    <input name="selected_ids"><input name="excluded_ids">
    <input type="radio" name="selection" value="selected" checked><input type="radio" name="selection" value="all">
    ${ids.map(id => `<input class="fleet-machine" type="checkbox" name="machine_ids[]" value="${id}">`).join('')}
    <button type="button" id="fleet-select-page"></button><button type="button" id="fleet-clear-selection"></button>
    <p id="fleet-selection-count"></p></form>`;
  document.querySelector('form').dataset.filterKey = filters;
  await import('../../../public/js/desktop-management.js');
  return document.querySelector('form');
}
const selectAll = () => document.querySelector('[value="all"]').click();
const selected = form => JSON.parse(form.elements.selected_ids.value);
const excluded = form => JSON.parse(form.elements.excluded_ids.value);
it('selects the page, persists manual selection across pages and deduplicates returning rows', async () => {
  let form = await page(); document.getElementById('fleet-select-page').click(); expect(selected(form)).toEqual(['1', '2']);
  form = await page(['2', '3']); expect(document.querySelector('[value="2"]').checked).toBe(true);
  document.getElementById('fleet-select-page').click(); expect(selected(form)).toEqual(['1', '2', '3']);
  expect(document.getElementById('fleet-selection-count').textContent).toContain('3 computadores');
});
it('all matching sends a mode and exclusions, not 6000 checkbox values', async () => {
  let form = await page(); selectAll(); document.querySelector('.fleet-machine[value="2"]').click();
  expect(excluded(form)).toEqual(['2']); expect(selected(form)).toEqual([]);
  expect(document.getElementById('fleet-selection-count').textContent).toContain('5999');
  form = await page(['2', '3']); expect(document.querySelector('[value="all"]').checked).toBe(true);
  expect(document.querySelector('.fleet-machine[value="2"]').checked).toBe(false);
  expect(document.querySelector('.fleet-machine[value="3"]').checked).toBe(true);
  document.getElementById('fleet-select-page').click(); expect(excluded(form)).toEqual([]);
});
it('separates selections by filters and administrator identity', async () => {
  await page(); selectAll(); document.querySelector('.fleet-machine').click();
  let form = await page(['1'], { owner: '8' }); expect(selected(form)).toEqual([]); expect(excluded(form)).toEqual([]);
  form = await page(['1'], { filters: '{"status":"active"}' }); expect(document.querySelector('[value="selected"]').checked).toBe(true);
});
it('clears committed or deliberately discarded selections', async () => {
  await page(); document.getElementById('fleet-select-page').click();
  let form = await page(['1'], { committed: '1' }); expect(selected(form)).toEqual([]);
  selectAll(); document.getElementById('fleet-clear-selection').click(); expect(document.querySelector('[value="selected"]').checked).toBe(true); expect(excluded(form)).toEqual([]);
});
it('blocks an empty manual submission without pretending to dispatch it', async () => {
  const form = await page(); const event = new Event('submit', { cancelable: true }); form.dispatchEvent(event);
  expect(event.defaultPrevented).toBe(true); expect(document.getElementById('fleet-selection-count').textContent).toContain('Selecione computadores');
});
it('ignores malformed stored selections without breaking the page', async () => {
  const form = await page(); const key = [...Array(sessionStorage.length)].map((_, i) => sessionStorage.key(i))[0];
  sessionStorage.setItem(key, JSON.stringify({ mode: 'all', selected: ['<script>'], excluded: [] }));
  await page(); expect(document.querySelector('[value="selected"]').checked).toBe(true);
});

it('does not carry all-mode exclusions into an explicit manual selection', async () => {
  const form = await page(); selectAll(); document.querySelector('.fleet-machine[value="2"]').click();
  expect(excluded(form)).toEqual(['2']);
  document.querySelector('[value="selected"]').click(); document.querySelector('.fleet-machine[value="2"]').click();
  expect(selected(form)).toEqual(['2']); expect(excluded(form)).toEqual([]);
});
