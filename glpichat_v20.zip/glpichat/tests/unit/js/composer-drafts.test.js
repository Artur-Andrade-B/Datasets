import { afterEach, expect, it } from "vitest";
import { ComposerDrafts, filesFromTransfer } from "../../../src/js/modules/composer-drafts.js";
afterEach(() => sessionStorage.clear());
it("requires file reselection after reload without inventing a File or leaking another account's names", () => {
  const firstPage = new ComposerDrafts("test-origin-root");
  firstPage.add("user7:42:internal", [new File(["confidential"], "private.pdf")]);
  const reloaded = new ComposerDrafts("test-origin-root");
  expect(reloaded.get("user8:42:internal").error).toBe("");
  const restored = reloaded.get("user7:42:internal");
  expect(restored.files).toHaveLength(0);
  expect(restored.error).toContain("Selecione novamente");
  expect(restored.error).toContain("private.pdf");
  expect(new ComposerDrafts("other-glpi-root").get("user7:42:internal").error).toBe("");
  reloaded.add("user7:42:internal", [new File(["new"], "private.pdf")]);
  expect(restored.files).toHaveLength(1);
  expect(restored.error).toBe("");
  reloaded.clear("user7:42:internal");
  expect(new ComposerDrafts("test-origin-root").get("user7:42:internal").error).toBe("");
});
it("keeps accepted selections when an over-limit selection reports a persistent error", () => {
  const drafts = new ComposerDrafts("limit");
  const files = Array.from({ length: 11 }, (_, i) => new File(["x"], `${i}.txt`));
  drafts.add("scope", files);
  expect(drafts.get("scope").files).toHaveLength(10);
  expect(drafts.get("scope").error).toContain("excedentes");
  drafts.remove("scope", drafts.get("scope").files[0].id);
  expect(drafts.get("scope").files).toHaveLength(9);
  expect(drafts.get("scope").error).not.toBe("");
});
it("collects every clipboard file including zero-byte files", () => {
  const one = new File([], "empty.txt"), two = new File(["x"], "second.txt");
  expect(filesFromTransfer({ items: [{ kind: "file", getAsFile: () => one }, { kind: "string" }, { kind: "file", getAsFile: () => two }] })).toEqual([one, two]);
});
