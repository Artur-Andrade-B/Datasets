import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { execFileSync } from 'node:child_process';
import { resolve } from 'node:path';

// Execute PHP's actual fallback HTML and script, without loading the main widget
// mount function. These assertions cover the independent fallback implementation.
const html = execFileSync(process.env.PHP_BINARY || 'php', [resolve(import.meta.dirname, 'helpers/ticket-tab-html.php')], { encoding: 'utf8' });
const reply = (data, status = 200) => Promise.resolve({ ok: status === 200, json: async () => data });
const invite = { id: 8, guest_name: 'Guest', status: 'active', expires_at: '2026-10-06' };
const pending = () => { let resolve; const promise = new Promise((done) => { resolve = done; }); return { promise, resolve }; };
const flush = () => vi.advanceTimersByTimeAsync(1);
const requestsTo = (fetchMock, suffix) => fetchMock.mock.calls.filter(([url]) => url.endsWith(suffix));
let root;
beforeEach(() => {
  vi.useFakeTimers();
  vi.spyOn(window, 'alert').mockImplementation(() => {});
  vi.spyOn(window, 'confirm').mockReturnValue(true);
  vi.spyOn(document, 'hidden', 'get').mockReturnValue(false);
  delete window.glpiChatMountInviteManagement;
  delete window.IntersectionObserver;
  window.CFG_GLPI = { root_doc: '/helpdesk' };
  const generated = new DOMParser().parseFromString(html, 'text/html');
  document.body.innerHTML = generated.body.innerHTML;
  root = document.querySelector('.glpichat-invite-management');
});
afterEach(() => {
  vi.clearAllTimers(); vi.useRealTimers(); vi.restoreAllMocks(); vi.unstubAllGlobals();
  document.body.innerHTML = ''; delete window.CFG_GLPI;
});
const boot = async (fetchMock) => {
  vi.stubGlobal('fetch', fetchMock);
  window.eval(document.querySelector('script').textContent);
  await flush();
};
it('suppresses repeated Enter/click submissions while keeping the typed fields until completion', async () => {
  const create = pending();
  const fetchMock = vi.fn((url) => url.endsWith('/Invite') ? create.promise : reply({ invites: [invite] }));
  await boot(fetchMock);
  const name = root.querySelector('[name=guest_name]'); name.value = 'Pending guest';
  name.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
  name.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
  root.querySelector('[data-role=submit-btn]').dispatchEvent(new Event('click'));
  expect(requestsTo(fetchMock, '/Invite')).toHaveLength(1);
  expect(name.value).toBe('Pending guest');
  expect(root.querySelector('[data-role=submit-btn]').disabled).toBe(true);
  create.resolve(await reply({ url: 'https://example.invalid/invite' })); await flush();
  expect(name.value).toBe('');
  expect(root.querySelector('[data-role=submit-btn]').disabled).toBe(false);
  expect(root.querySelector('[data-role=invite-result]').textContent).toContain('Link gerado');
});
it('keeps a failed action visible across healthy refreshes, and re-enables replacement buttons', async () => {
  const revoke = pending();
  const fetchMock = vi.fn((url) => url.endsWith('/Invite/Revoke') ? revoke.promise : reply({ invites: [invite] }));
  await boot(fetchMock);
  root.querySelector('.btn-outline-danger').click();
  root.querySelector('.btn-outline-primary').dispatchEvent(new Event('click'));
  expect(requestsTo(fetchMock, '/Invite/Revoke')).toHaveLength(1);
  expect(requestsTo(fetchMock, '/Invite/Reissue')).toHaveLength(0);
  await vi.advanceTimersByTimeAsync(100);
  expect([...root.querySelectorAll('tbody button')].every((button) => button.disabled)).toBe(true);
  revoke.resolve(await reply({ error: 'Operation denied' }, 403)); await flush();
  expect([...root.querySelectorAll('tbody button')].every((button) => !button.disabled)).toBe(true);
  await vi.advanceTimersByTimeAsync(200);
  expect(root.querySelector('[role=alert]').hidden).toBe(false);
  expect(root.querySelector('[role=alert]').textContent).toContain('Operation denied');
  fetchMock.mockImplementation((url) => url.endsWith('/Invite/Reissue') ? reply({ url: 'https://example.invalid/new' }) : reply({ invites: [invite] }));
  root.querySelector('.btn-outline-primary').click(); await flush();
  expect(root.querySelector('[role=alert]').hidden).toBe(true);
  expect([...root.querySelectorAll('tbody button')].every((button) => !button.disabled)).toBe(true);
});
it('serializes slow refreshes without losing composer input and stops after its tab is removed', async () => {
  const slow = pending(); let listCount = 0;
  const fetchMock = vi.fn(() => ++listCount === 2 ? slow.promise : reply({ invites: [invite] }));
  await boot(fetchMock);
  root.querySelector('[name=guest_name]').value = 'Keep this draft';
  await vi.advanceTimersByTimeAsync(400);
  expect(fetchMock).toHaveBeenCalledTimes(2);
  slow.resolve(await reply({ invites: [invite] })); await flush();
  expect(fetchMock).toHaveBeenCalledTimes(3);
  expect(root.querySelector('[name=guest_name]').value).toBe('Keep this draft');
  root.remove(); await vi.advanceTimersByTimeAsync(300);
  expect(fetchMock).toHaveBeenCalledTimes(3);
});
it('retains existing rows after list failure and recovers without discarding the form', async () => {
  const fetchMock = vi.fn().mockImplementation(() => reply({ invites: [invite] }));
  await boot(fetchMock);
  const form = root.querySelector('.glpichat-invite');
  fetchMock.mockRejectedValueOnce(new TypeError('Network unavailable'));
  await vi.advanceTimersByTimeAsync(100);
  expect(root.querySelector('tbody').textContent).toContain('Guest');
  expect(root.querySelector('[role=alert]').textContent).toContain('Network unavailable');
  await vi.advanceTimersByTimeAsync(100);
  expect(root.querySelector('[role=alert]').hidden).toBe(true);
  expect(root.querySelector('.glpichat-invite')).toBe(form);
});
