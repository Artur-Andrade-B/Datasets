<?php
// Minimal GLPI rendering boundary; TicketTab itself is loaded unchanged.
class CommonGLPI {}
class Ticket extends CommonGLPI { public function getID(): int { return 42; } }
class Session { public static function getNewCSRFToken(): string { return 'test-csrf'; } }
class Html {
    public static function scriptBlock(string $script): string { return '<script>' . $script . '</script>'; }
    public static function convDateTime(string $date): string { return $date; }
}
function htmlescape($text): string { return htmlspecialchars((string) $text, ENT_QUOTES); }
function glpichat_can_view_participants(int $id): bool { return true; }
function glpichat_can_create_invites(int $id): bool { return true; }
function glpichat_can_update_invites(int $id): bool { return true; }
function glpichat_can_view_audit(int $id): bool { return $GLOBALS['test_audit_allowed'] ?? true; }
function glpichat_config_int(string $name, int $fallback): int { return $name === 'invite_poll_ms' ? 100 : $fallback; }
require dirname(__DIR__, 4) . '/src/TicketTab.php';
