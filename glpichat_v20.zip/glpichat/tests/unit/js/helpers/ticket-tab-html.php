<?php
require __DIR__ . '/ticket-tab-host.php';
GlpiPlugin\Glpichat\TicketTab::displayTabContentForItem(new Ticket(), 1);
