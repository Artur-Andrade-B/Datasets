<?php
// Render the production controller HTML; only its host framework boundary is stubbed.
namespace Glpi\Controller { abstract class AbstractController {} }
namespace {
    class Config { public static function getConfigurationValue($context, $key) { return null; } }
    function htmlescape($value) { return htmlspecialchars($value, ENT_QUOTES); }
    $GLOBALS['CFG_GLPI'] = ['root_doc' => '/helpdesk'];
    require dirname(__DIR__, 4) . '/src/Controller/GuestController.php';
    $method = new ReflectionMethod(GlpiPlugin\Glpichat\Controller\GuestController::class, 'guestHtml');
    echo $method->invoke(new GlpiPlugin\Glpichat\Controller\GuestController(), 42, 3, 'Guest', '', 11);
}
