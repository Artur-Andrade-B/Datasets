import { afterEach, beforeEach, expect, it, vi } from "vitest";

let listeners = [];
beforeEach(() => {
  vi.useFakeTimers(); vi.resetModules();
  for (const target of [window, document]) {
    const add = target.addEventListener.bind(target);
    vi.spyOn(target, "addEventListener").mockImplementation((type, handler, options) => {
      listeners.push([target, type, handler, options]); add(type, handler, options);
    });
  }
  for (const method of ["info", "warn", "error", "debug"]) vi.spyOn(console, method).mockImplementation(() => {});
  vi.spyOn(document, "visibilityState", "get").mockReturnValue("visible");
  localStorage.setItem("glpichat_widget_ui", JSON.stringify({ openTicketIds: [42], manualTicketIds: [42] }));
});
afterEach(() => {
  for (const [target, type, handler, options] of listeners) target.removeEventListener(type, handler, options);
  listeners = []; vi.clearAllTimers(); vi.useRealTimers(); vi.restoreAllMocks(); vi.unstubAllGlobals();
  document.body.innerHTML = ""; localStorage.clear(); sessionStorage.clear();
  delete window.__glpichatWidgetMounted; delete window.CFG_GLPI;
});
const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json" } });
const message = (id, extra = {}) => ({ id, actor_type: "user", users_id: 7, sender_name: "User", content: `Message ${id}`, date_creation: "2026-10-05 12:00:00", ...extra });
const box = () => document.querySelector("#glpichat-box-42");
const textarea = () => box().querySelector("textarea");
const type = (text) => { textarea().value = text; textarea().dispatchEvent(new Event("input", { bubbles: true })); };
const select = (files, target = box().querySelector("input[type=file]")) => {
  Object.defineProperty(target, "files", { configurable: true, value: files });
  target.dispatchEvent(new Event("change", { bubbles: true }));
};
const switchRoom = async (index) => { box().querySelectorAll(".glpichat-tab")[index].click(); await vi.advanceTimersByTimeAsync(1); };
const writes = (fetchMock) => fetchMock.mock.calls.filter(([url]) => /\/(Send|Upload)$/.test(url));
const boot = async (handler = () => undefined, config = {}) => {
  const fetchMock = vi.fn((url, options = {}) => {
    const custom = handler(url, options); if (custom !== undefined) return custom;
    if (url.includes("/Widget/Channels")) return Promise.resolve(json({ current_user_id: 7, complete: true, channels: [
      { tickets_id: 42, rooms_id: 3, room_type: "public", ticket_status: 1, can_send: true },
      { tickets_id: 42, rooms_id: 4, room_type: "internal", ticket_status: 1, can_send: true },
    ] }));
    if (url.endsWith("/Widget/Config")) return Promise.resolve(json({ poll_focused_ms: 100, ...config }));
    if (url.includes("/Widget/History")) return Promise.resolve(json({ messages: [], events: [], next_before: 0, has_more: false }));
    if (/\/(Send|Upload)$/.test(url)) return Promise.resolve(json({ message: message(10 + writes(fetchMock).length, {
      client_message_id: options.body.get("client_message_id"), content: options.body.get("content") || `Arquivo: ${options.body.get("file").name}`,
    }) }));
    return Promise.resolve(json({}));
  });
  vi.stubGlobal("fetch", fetchMock);
  await import("../../../src/js/glpichat-widget.js");
  document.dispatchEvent(new Event("DOMContentLoaded")); await vi.advanceTimersByTimeAsync(1);
  return fetchMock;
};

it("keeps multi-file selections removable until explicit Send and preserves text", async () => {
  const fetchMock = await boot();
  type("Draft text");
  select([new File(["a"], "first.pdf"), new File(["b"], "second.pdf")]);
  expect(writes(fetchMock)).toHaveLength(0);
  expect(textarea().value).toBe("Draft text");
  expect(box().querySelectorAll(".glpichat-draft-files li")).toHaveLength(2);
  box().querySelector('[aria-label="Remover first.pdf"]').click();
  box().querySelector("form").requestSubmit(); await vi.advanceTimersByTimeAsync(1);
  expect(writes(fetchMock)).toHaveLength(2);
  expect(writes(fetchMock)[0][0]).toMatch(/\/Send$/);
  expect(writes(fetchMock)[0][1].body.get("content")).toBe("Draft text");
  expect(writes(fetchMock)[1][1].body.get("file").name).toBe("second.pdf");
  expect(box().querySelectorAll(".glpichat-draft-files li")).toHaveLength(0);
});

it("keeps private text/files separate from the public draft and remembers picker destination", async () => {
  const fetchMock = await boot();
  type("Public draft"); await switchRoom(1); type("Internal draft");
  const input = box().querySelector("input[type=file]"); input.click();
  await switchRoom(0);
  select([new File(["secret"], "internal.txt")], input);
  expect(textarea().value).toBe("Public draft");
  expect(box().querySelectorAll(".glpichat-draft-files li")).toHaveLength(0);
  box().querySelector("form").requestSubmit(); await vi.advanceTimersByTimeAsync(1);
  expect(writes(fetchMock)).toHaveLength(1);
  expect(writes(fetchMock)[0][1].body.get("room_type")).toBe("public");
  await switchRoom(1);
  expect(textarea().value).toBe("Internal draft");
  expect(box().querySelector(".glpichat-draft-files").textContent).toContain("internal.txt");
  box().querySelector("form").requestSubmit(); await vi.advanceTimersByTimeAsync(1);
  expect(writes(fetchMock).slice(1).map(([, opts]) => opts.body.get("room_type"))).toEqual(["internal", "internal"]);
});

it("retains the draft when close destroys the box and reopens it past the old eviction time", async () => {
  await boot(undefined, { poll_focused_ms: 600000, channel_sync_ms: 600000 });
  type("Keep this after closing"); select([new File(["x"], "retained.txt")]);
  box().querySelector('[data-role="close"]').click(); await vi.advanceTimersByTimeAsync(500);
  document.querySelector('[data-role="launcher-tab"]').click(); await vi.advanceTimersByTimeAsync(20);
  const row = document.querySelector('.glpichat-ticket-filter-item[data-ticket-id="42"]');
  expect(row).not.toBeNull(); row.click(); await vi.advanceTimersByTimeAsync(20);
  expect(textarea().value).toBe("Keep this after closing");
  expect(box().querySelector(".glpichat-draft-files").textContent).toContain("retained.txt");
  await vi.advanceTimersByTimeAsync(360000);
  expect(textarea().value).toBe("Keep this after closing");
  expect(box().querySelector(".glpichat-draft-files").textContent).toContain("retained.txt");
});

it("retries attachment delivery with the same receipt and preserves the next queued piece", async () => {
  let attempt = 0;
  const fetchMock = await boot((url, opts) => {
    if (!url.endsWith("/Upload")) return undefined;
    attempt += 1;
    if (attempt === 1) return Promise.reject(new TypeError("reply lost"));
    return Promise.resolve(json({ message: message(100 + attempt, { client_message_id: opts.body.get("client_message_id"), content: opts.body.get("file").name }) }));
  });
  select([new File(["a"], "first.txt"), new File(["b"], "next.txt")]);
  box().querySelector("form").requestSubmit(); await vi.advanceTimersByTimeAsync(1);
  expect(writes(fetchMock)).toHaveLength(1);
  expect(box().textContent).toContain("Confirmação pendente");
  expect(box().textContent).toContain("Na fila desta conversa");
  box().querySelector('[data-action="retry-message"]').click(); await vi.advanceTimersByTimeAsync(1);
  const uploads = writes(fetchMock);
  expect(uploads).toHaveLength(3);
  expect(uploads[0][1].body.get("client_message_id")).toBe(uploads[1][1].body.get("client_message_id"));
  expect(uploads.map(([, opts]) => opts.body.get("file").name)).toEqual(["first.txt", "first.txt", "next.txt"]);
  expect(box().querySelectorAll(".is-optimistic")).toHaveLength(0);
});

it("refreshes edited/removed rows, consumes hidden raw cursors and preserves a denied draft", async () => {
  let poll = 0; const cursors = [];
  const fetchMock = await boot((url, opts) => {
    if (url.includes("/Widget/History")) return Promise.resolve(json({ messages: [message(1), message(2)], events: [], has_more: false }));
    if (url.endsWith("/Widget/Poll")) {
      cursors.push(Number(opts.body.get("channels[0][after_id]")));
      expect(opts.body.get("channels[0][visible_message_ids][0]")).toBe("1");
      poll += 1;
      return Promise.resolve(json({ channels: { "42:public": poll === 1
        ? { availability: "available", can_send: true, messages: [], events: [], next_message_id: 52, last_message_id: 100, has_more: true, refreshed_messages: [message(1, { content: "Edited current source" })], removed_message_ids: [2] }
        : { availability: "denied", can_send: false } } }));
    }
    return undefined;
  });
  textarea().value = "Preserve private context"; select([new File(["x"], "draft.txt")]);
  await vi.advanceTimersByTimeAsync(100);
  expect(box().textContent).toContain("Edited current source");
  expect(box().textContent).not.toContain("Message 2");
  await vi.advanceTimersByTimeAsync(100);
  expect(cursors.slice(0, 2)).toEqual([2, 52]);
  expect(box().querySelectorAll(".glpichat-message-body")).toHaveLength(0);
  expect(textarea().disabled).toBe(true);
  expect(textarea().value).toBe("Preserve private context");
  expect(box().querySelector(".glpichat-draft-files").textContent).toContain("draft.txt");
  expect(writes(fetchMock)).toHaveLength(0);
});

it("offers the next older page even when the first raw page contains no visible messages", async () => {
  const before = [];
  await boot((url) => {
    if (!url.includes("/Widget/History")) return undefined;
    const cursor = new URL(url, "https://example.test").searchParams.get("before_id"); before.push(cursor);
    return Promise.resolve(json(cursor ? { messages: [message(10)], events: [], next_before: 10, has_more: false }
      : { messages: [], events: [], next_before: 51, has_more: true }));
  });
  const older = box().querySelector('[data-action="older-messages"]'); expect(older).not.toBeNull();
  older.click(); await vi.advanceTimersByTimeAsync(1);
  expect(before).toEqual([null, "51"]);
  expect(box().textContent).toContain("Message 10");
});

it("allows a healthy room to submit while another room's History is still in flight", async () => {
  let resolveInternal;
  const fetchMock = await boot((url) => {
    if (url.includes("/Widget/History?rooms_id=4")) return new Promise((resolve) => { resolveInternal = resolve; });
    return undefined;
  });
  await switchRoom(1);
  expect(textarea().disabled).toBe(true);
  await switchRoom(0);
  expect(textarea().disabled).toBe(false);
  select([new File(["healthy"], "healthy.txt")]);
  expect(box().querySelector(".glpichat-draft-files").textContent).toContain("healthy.txt");
  box().querySelector("form").requestSubmit(); await vi.advanceTimersByTimeAsync(1);
  expect(writes(fetchMock)).toHaveLength(1);
  expect(writes(fetchMock)[0][1].body.get("room_type")).toBe("public");
  resolveInternal(json({ messages: [], events: [] })); await vi.advanceTimersByTimeAsync(1);
});

it("can restore a rejected piece without restoring already committed text", async () => {
  const fetchMock = await boot((url) => url.endsWith("/Upload")
    ? Promise.resolve(json({ error: "File exceeds configured policy.", code: "attachment_too_large" }, 413)) : undefined);
  textarea().value = "Committed text";
  select([new File(["bad"], "policy.pdf")]);
  box().querySelector("form").requestSubmit(); await vi.advanceTimersByTimeAsync(1);
  expect(writes(fetchMock)).toHaveLength(2);
  box().querySelector('[data-action="restore-message"]').click(); await vi.advanceTimersByTimeAsync(1);
  expect(textarea().value).toBe("");
  expect(box().querySelector(".glpichat-draft-files").textContent).toContain("policy.pdf");
  expect(box().querySelectorAll(".is-optimistic")).toHaveLength(0);
  expect(writes(fetchMock)).toHaveLength(2);
});

it("treats a committed but unavailable receipt as delivered instead of offering a duplicate send", async () => {
  const fetchMock = await boot((url) => url.endsWith("/Upload")
    ? Promise.resolve(json({ error: "Previously committed attachment unavailable", code: "message_unavailable", committed: true }, 409)) : undefined);
  select([new File(["x"], "already-sent.txt")]); box().querySelector("form").requestSubmit();
  await vi.advanceTimersByTimeAsync(1);
  expect(box().querySelector('[data-action="retry-message"]')).toBeNull();
  expect(box().querySelector('[data-action="restore-message"]')).toBeNull();
  expect(box().textContent).toContain("Enviado anteriormente");
  expect(writes(fetchMock)).toHaveLength(1);
});

it("labels truncated discovery as partial even when its page contains no ticket", async () => {
  localStorage.clear();
  await boot((url) => url.includes("/Widget/Channels") ? Promise.resolve(json({ current_user_id: 7, channels: [], complete: false })) : undefined);
  document.querySelector('[data-role="launcher-tab"]').click(); await vi.advanceTimersByTimeAsync(1);
  expect(document.querySelector('[data-role="notifications"]').textContent).toContain("Lista parcial");
  expect(document.querySelector('[data-role="notifications"]').textContent).not.toContain("Nenhum chamado em");
});

it("continues queued successors when Poll later confirms an unknown upload outcome", async () => {
  let pendingReceipt = ""; let exposeReceipt = false; let uploads = 0;
  const fetchMock = await boot((url, options) => {
    if (url.endsWith("/Upload")) {
      uploads += 1;
      if (uploads === 1) { pendingReceipt = options.body.get("client_message_id"); return Promise.reject(new TypeError("response lost")); }
      return Promise.resolve(json({ message: message(102, { client_message_id: options.body.get("client_message_id") }) }));
    }
    if (url.endsWith("/Widget/Poll")) return Promise.resolve(json({ channels: { "42:public": {
      messages: exposeReceipt ? [message(101, { client_message_id: pendingReceipt })] : [], events: [], next_message_id: exposeReceipt ? 101 : 0,
    } } }));
    return undefined;
  });
  select([new File(["a"], "first.txt"), new File(["b"], "next.txt")]);
  box().querySelector("form").requestSubmit(); await vi.advanceTimersByTimeAsync(1);
  expect(uploads).toBe(1);
  exposeReceipt = true; await vi.advanceTimersByTimeAsync(110);
  expect(uploads).toBe(2);
  expect(writes(fetchMock).map(([, options]) => options.body.get("file").name)).toEqual(["first.txt", "next.txt"]);
  expect(box().querySelectorAll(".is-optimistic")).toHaveLength(0);
});

it("binds every browser piece to its original GLPI user and blocks account-change rejection", async () => {
  const fetchMock = await boot((url, options) => {
    if (!url.endsWith("/Send")) return undefined;
    expect(options.body.get("expected_user_id")).toBe("7");
    return Promise.resolve(json({ error: "Changed account", code: "account_context_changed" }, 409));
  });
  textarea().value = "Original user draft"; box().querySelector("form").requestSubmit();
  await vi.advanceTimersByTimeAsync(1);
  expect(writes(fetchMock)).toHaveLength(1);
  expect(textarea().disabled).toBe(true);
  expect(box().textContent).toContain("conta do GLPI foi alterada");
  expect(box().querySelector('[data-action="retry-message"]')).toBeNull();
});

it("does not restore an unknown send as new content when a later retry is denied before receipt lookup", async () => {
  let attempts = 0;
  await boot((url) => {
    if (!url.endsWith("/Send")) return undefined;
    attempts += 1;
    return attempts === 1 ? Promise.reject(new TypeError("lost after possible commit"))
      : Promise.resolve(json({ error: "Permission revoked", code: "authorization_denied" }, 403));
  });
  textarea().value = "Uncertain first write"; box().querySelector("form").requestSubmit(); await vi.advanceTimersByTimeAsync(1);
  box().querySelector('[data-action="retry-message"]').click(); await vi.advanceTimersByTimeAsync(1);
  expect(box().querySelector(".is-optimistic").textContent).toContain("Confirmação pendente");
  expect(box().querySelector('[data-action="restore-message"]')).toBeNull();
  expect(attempts).toBe(2);
});
