import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { execFileSync } from "node:child_process";
import { resolve } from "node:path";

// Native validation and root URL behavior use actual production HTML, not a
// hand-written form fixture that can silently omit required/multiple attributes.
const guestHtml = execFileSync(process.env.PHP_BINARY || "php", [resolve(import.meta.dirname, "helpers/guest-html.php")], { encoding: "utf8" });
let listeners = [];
beforeEach(() => {
  vi.useFakeTimers();
  vi.resetModules();
  for (const target of [window, document]) {
    const add = target.addEventListener.bind(target);
    vi.spyOn(target, "addEventListener").mockImplementation((type, handler, options) => {
      listeners.push([target, type, handler, options]);
      add(type, handler, options);
    });
  }
  for (const method of ["info", "warn", "error", "debug"]) vi.spyOn(console, method).mockImplementation(() => {});
  vi.spyOn(document, "visibilityState", "get").mockReturnValue("visible");
  const generated = new DOMParser().parseFromString(guestHtml, "text/html");
  document.body.innerHTML = generated.body.innerHTML;
  window.__glpichatConfig = JSON.parse(generated.querySelector("script").textContent.split("=", 2)[1].replace(/;$/, ""));
  window.__glpichatConfig.guest_poll_ms = 100;
});
afterEach(() => {
  for (const [target, type, handler, options] of listeners) target.removeEventListener(type, handler, options);
  listeners = [];
  vi.clearAllTimers();
  vi.useRealTimers();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  document.body.innerHTML = ""; sessionStorage.clear();
  delete window.__glpichatConfig;
});
const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json" } });
const syncData = (messages = []) => ({ messages, events: [], ticket_status: 1, session_remaining_seconds: 600 });
const msg = (id, content) => ({ id, actor_type: "user", content, sender_name: "Support", date_creation: "2026-10-02 12:00:00" });
const boot = async (fetchMock) => {
  vi.stubGlobal("fetch", fetchMock);
  await import("../../../src/js/glpichat-guest.js");
  document.dispatchEvent(new Event("DOMContentLoaded"));
  await vi.advanceTimersByTimeAsync(1);
};
it("recovers a guest session after transient network/proxy failures without declaring it expired", async () => {
  let calls = 0;
  const fetchMock = vi.fn(() => {
    calls += 1;
    if (calls === 2) return Promise.resolve(new Response("<html>proxy unavailable</html>", { status: 503 }));
    if (calls === 3) return Promise.reject(new TypeError("network unavailable"));
    return Promise.resolve(json(syncData(calls >= 4 ? [msg(1, "Recovered")] : [])));
  });
  await boot(fetchMock);
  await vi.advanceTimersByTimeAsync(210);
  expect(document.querySelector(".glpichat-countdown").textContent).not.toContain("Sessão expirada");
  expect(document.querySelector("textarea").disabled).toBe(false);
  expect(document.querySelector("[role='status']").hidden).toBe(false);
  await vi.advanceTimersByTimeAsync(100);
  expect(document.querySelector("[role='status']").hidden).toBe(true);
  expect(document.querySelectorAll(".glpichat-message")).toHaveLength(1);
  expect(document.body.textContent).toContain("Recovered");
});
it("still disables the composer when the server rejects the guest session", async () => {
  const fetchMock = vi.fn().mockResolvedValueOnce(json(syncData())).mockResolvedValue(json({ error: "Sessão de acesso inválida ou expirada.", code: "guest_session_invalid" }, 401));
  await boot(fetchMock);
  await vi.advanceTimersByTimeAsync(110);
  expect(document.querySelector(".glpichat-countdown").textContent).toBe("Sessão expirada");
  expect(document.querySelector("textarea").disabled).toBe(true);
  const requests = fetchMock.mock.calls.length;
  await vi.advanceTimersByTimeAsync(500);
  expect(fetchMock).toHaveBeenCalledTimes(requests);
});
it("keeps a pending send when unrelated messages arrive and removes it only on its returned message ID", async () => {
  let syncCalls = 0;
  let resolveSync;
  let resolveSend;
  let committed = false;
  const fetchMock = vi.fn((url) => {
    if (url.includes("/Guest/Sync?")) {
      syncCalls += 1;
      if (syncCalls === 2) return new Promise((resolve) => { resolveSync = resolve; });
      return Promise.resolve(json(syncData(committed ? [msg(3, "My outgoing message")] : [])));
    }
    if (url.endsWith("/Guest/Send")) return new Promise((resolve) => { resolveSend = resolve; });
    return Promise.resolve(json({}));
  });
  await boot(fetchMock);
  await vi.advanceTimersByTimeAsync(100);
  const textarea = document.querySelector("textarea");
  textarea.value = "My outgoing message";
  textarea.closest("form").dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }));
  await vi.advanceTimersByTimeAsync(1);
  expect(document.querySelectorAll(".is-optimistic")).toHaveLength(1);
  resolveSync(json(syncData([msg(2, "Unrelated incoming message")])));
  await vi.advanceTimersByTimeAsync(1);
  expect(document.querySelectorAll(".is-optimistic")).toHaveLength(1);
  expect(document.body.textContent).toContain("Unrelated incoming message");
  committed = true;
  resolveSend(json({ message_id: 3 }));
  await vi.advanceTimersByTimeAsync(1);
  expect(document.querySelectorAll(".is-optimistic")).toHaveLength(0);
  expect(document.querySelectorAll(".glpichat-message")).toHaveLength(2);
  await vi.advanceTimersByTimeAsync(200);
  expect(document.querySelectorAll(".glpichat-message")).toHaveLength(2);
});
it("does not restore or resend committed guest text when its separate attachment is rejected", async () => {
  let textCommitted = false;
  const fetchMock = vi.fn((url, options) => {
    if (url.includes("/Guest/Sync?")) return Promise.resolve(json(syncData(textCommitted ? [msg(3, "Committed guest text")] : [])));
    if (url.endsWith("/Guest/Send")) {
      expect(options.body.get("file")).toBeNull();
      textCommitted = true;
      return Promise.resolve(json({ message_id: 3 }));
    }
    if (url.endsWith("/Guest/Upload")) return Promise.resolve(json({ error: "File exceeds configured size." }, 413));
    return Promise.resolve(json({}));
  });
  await boot(fetchMock);
  const textarea = document.querySelector("textarea");
  const fileInput = document.querySelector("input[type=file]");
  Object.defineProperty(fileInput, "files", { configurable: true, value: [new File(["file payload"], "proof.pdf", { type: "application/pdf" })] });
  fileInput.dispatchEvent(new Event("change", { bubbles: true }));
  textarea.value = "Committed guest text";
  textarea.closest("form").dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }));
  await vi.advanceTimersByTimeAsync(1);
  expect(textarea.value).toBe("");
  expect(document.querySelectorAll(".is-optimistic")).toHaveLength(1);
  expect(document.querySelector(".is-optimistic").textContent).toContain("Arquivo: proof.pdf");
  expect(document.querySelector(".is-optimistic").textContent).toContain("Envio recusado");
  expect(document.querySelectorAll(".glpichat-message:not(.is-optimistic)")).toHaveLength(1);
  await vi.advanceTimersByTimeAsync(5100);
  expect(fetchMock.mock.calls.filter(([url]) => url.endsWith("/Guest/Send"))).toHaveLength(1);
  expect(document.querySelectorAll(".is-optimistic")).toHaveLength(1);
});

it("uses generated HTML for file-only multi-selection, removal and explicit grouped sends", async () => {
  const sent = [];
  const fetchMock = vi.fn((url, opts) => {
    expect(url.startsWith("/helpdesk/plugins/glpichat/")).toBe(true);
    if (url.includes("/Guest/Sync?")) return Promise.resolve(json(syncData()));
    if (url.endsWith("/Guest/Upload")) {
      sent.push(opts.body);
      return Promise.resolve(json({ message_id: 100 + sent.length, client_message_id: opts.body.get("client_message_id") }));
    }
    return Promise.resolve(json({}));
  });
  // These are server-generated attributes, inspected before frontend repair.
  expect(document.querySelector("textarea").required).toBe(false);
  expect(document.querySelector("input[type=file]").multiple).toBe(true);
  await boot(fetchMock);
  const input = document.querySelector("input[type=file]");
  Object.defineProperty(input, "files", { configurable: true, value: [new File(["a"], "a.pdf"), new File(["b"], "b.pdf"), new File([], "empty.txt")] });
  input.dispatchEvent(new Event("change", { bubbles: true }));
  expect(sent).toHaveLength(0);
  expect(document.querySelectorAll(".glpichat-draft-files li")).toHaveLength(3);
  document.querySelector('[aria-label="Remover b.pdf"]').click();
  expect(document.querySelector("form").checkValidity()).toBe(true);
  document.querySelector("form").requestSubmit();
  await vi.advanceTimersByTimeAsync(1);
  expect(sent).toHaveLength(2);
  expect(sent.map((body) => body.get("file").name)).toEqual(["a.pdf", "empty.txt"]);
  expect(sent[0].get("submission_id")).toBe(sent[1].get("submission_id"));
  expect(sent[0].get("client_message_id")).not.toBe(sent[1].get("client_message_id"));
  expect(sent.map((body) => body.get("submission_count"))).toEqual(["2", "2"]);
});

it("keeps a transient guest upload outcome visible and reuses its original receipt on verification", async () => {
  const submitted = [];
  const fetchMock = vi.fn((url, opts) => {
    if (url.includes("/Guest/Sync?")) return Promise.resolve(json(syncData()));
    if (url.endsWith("/Guest/Upload")) {
      submitted.push(opts.body);
      return submitted.length === 1
        ? Promise.resolve(json({ error: "Temporary backend issue; reference abc", code: "temporarily_unavailable" }, 503))
        : Promise.resolve(json({ message_id: 101, client_message_id: opts.body.get("client_message_id") }));
    }
    return Promise.resolve(json({}));
  });
  await boot(fetchMock);
  const input = document.querySelector("input[type=file]");
  Object.defineProperty(input, "files", { configurable: true, value: [new File(["x"], "proof.pdf")] });
  input.dispatchEvent(new Event("change"));
  document.querySelector("form").requestSubmit(); await vi.advanceTimersByTimeAsync(1);
  expect(document.querySelector(".is-optimistic").textContent).toContain("Confirmação pendente");
  expect(document.querySelector(".is-optimistic").textContent).toContain("reference abc");
  expect(document.querySelector("textarea").disabled).toBe(false);
  await vi.advanceTimersByTimeAsync(500);
  expect(submitted).toHaveLength(1);
  document.querySelector('[data-action="retry-guest-message"]').click(); await vi.advanceTimersByTimeAsync(1);
  expect(submitted).toHaveLength(2);
  expect(submitted[0].get("client_message_id")).toBe(submitted[1].get("client_message_id"));
  expect(submitted[0].get("submission_id")).toBe(submitted[1].get("submission_id"));
});

it("refreshes guest source visibility and only offers the authenticated guest document endpoint", async () => {
  let syncCalls = 0; const cursors = [];
  await boot(vi.fn((url) => {
    if (url.includes("/Guest/Sync?")) {
      const params = new URL(url, "https://example.test").searchParams;
      cursors.push(Number(params.get("last_message_id")));
      syncCalls += 1;
      const data = syncCalls === 1 ? syncData([
        msg(1, "Old visible text"),
        { ...msg(2, "Arquivo: report.pdf"), documents_id: 99, attachment_url: "/helpdesk/plugins/glpichat/Guest/Attachment/2/99" },
      ]) : { ...syncData(), next_message_id: 52, refreshed_messages: [msg(1, "Updated native text")], removed_message_ids: [2] };
      return Promise.resolve(json(data));
    }
    return Promise.resolve(json({}));
  }));
  const link = document.querySelector(".glpichat-attachment-link");
  expect(link.getAttribute("href")).toBe("/helpdesk/plugins/glpichat/Guest/Attachment/2/99");
  expect(document.body.innerHTML).not.toContain("document.send.php");
  await vi.advanceTimersByTimeAsync(210);
  expect(document.body.textContent).toContain("Updated native text");
  expect(document.body.textContent).not.toContain("Old visible text");
  expect(document.querySelector(".glpichat-attachment-link")).toBeNull();
  expect(cursors.slice(0, 3)).toEqual([0, 2, 52]);
});

it("keeps the visible draft when a live guest ticket becomes archived", async () => {
  let status = 1;
  await boot(vi.fn((url) => Promise.resolve(json({ ...syncData(), ticket_status: status }))));
  document.querySelector("textarea").value = "Not yet submitted";
  const input = document.querySelector("input[type=file]");
  Object.defineProperty(input, "files", { configurable: true, value: [new File(["x"], "draft.pdf")] });
  input.dispatchEvent(new Event("change")); status = 6;
  await vi.advanceTimersByTimeAsync(100);
  expect(document.querySelector("textarea").value).toBe("Not yet submitted");
  expect(document.querySelector("form").style.display).not.toBe("none");
  expect(document.querySelector(".glpichat-draft-files").textContent).toContain("draft.pdf");
  expect(document.querySelector("button[type=submit]").disabled).toBe(true);
});

it("keeps guest reload recoverable, stops hidden-page timers and resumes a restored page", async () => {
  const fetchMock = vi.fn((url) => Promise.resolve(json(syncData())));
  await boot(fetchMock);
  document.querySelector("textarea").value = "Retain my local draft";
  const warning = new Event("beforeunload", { cancelable: true }); window.dispatchEvent(warning);
  expect(warning.defaultPrevented).toBe(true);
  const beforeHide = fetchMock.mock.calls.length;
  window.dispatchEvent(new Event("pagehide")); await vi.advanceTimersByTimeAsync(500);
  expect(fetchMock.mock.calls.filter(([url]) => url.endsWith("/Guest/Leave"))).toHaveLength(0);
  expect(fetchMock).toHaveBeenCalledTimes(beforeHide);
  const restored = new Event("pageshow"); Object.defineProperty(restored, "persisted", { value: true });
  window.dispatchEvent(restored); await vi.advanceTimersByTimeAsync(1);
  expect(fetchMock.mock.calls.length).toBeGreaterThan(beforeHide);
  expect(document.querySelector("textarea").value).toBe("Retain my local draft");
});

it("ends guest access only through the generated explicit button and binds Leave to this tab", async () => {
  const fetchMock = vi.fn((url, opts) => {
    if (url.endsWith("/Guest/Leave")) {
      expect(opts.body.get("expected_participant_id")).toBe("11");
      expect(opts.body.get("expected_rooms_id")).toBe("3");
      return Promise.resolve(new Response(null, { status: 204 }));
    }
    return Promise.resolve(json(syncData([msg(1, "Visible while active")])));
  });
  await boot(fetchMock);
  const button = document.querySelector('[data-role="guest-end-access"]'); expect(button).not.toBeNull();
  button.click(); await vi.advanceTimersByTimeAsync(1);
  expect(fetchMock.mock.calls.filter(([url]) => url.endsWith("/Guest/Leave"))).toHaveLength(1);
  expect(document.querySelector("textarea").disabled).toBe(true);
  expect(document.querySelector(".glpichat-countdown").textContent).toBe("Acesso encerrado.");
  expect(document.body.textContent).not.toContain("Visible while active");
  const calls = fetchMock.mock.calls.length; await vi.advanceTimersByTimeAsync(500);
  expect(fetchMock).toHaveBeenCalledTimes(calls);
});

it("blocks an old guest tab after another invitation replaces its cookie without moving its draft", async () => {
  let cookieParticipant = "11"; let unauthorizedSends = 0;
  const fetchMock = vi.fn((url, opts) => {
    if (url.includes("/Guest/Sync?")) {
      const query = new URL(url, "https://example.test").searchParams;
      expect(query.get("expected_participant_id")).toBe("11"); expect(query.get("expected_rooms_id")).toBe("3");
      if (query.get("expected_participant_id") !== cookieParticipant) return Promise.resolve(json({ error: "Context changed", code: "guest_context_changed" }, 409));
      return Promise.resolve(json(syncData([msg(1, "Original ticket history")])));
    }
    if (url.endsWith("/Guest/Upload")) {
      expect(opts.body.get("expected_participant_id")).toBe("11"); expect(opts.body.get("expected_rooms_id")).toBe("3");
      if (opts.body.get("expected_participant_id") !== cookieParticipant) return Promise.resolve(json({ error: "Context changed", code: "guest_context_changed" }, 409));
      unauthorizedSends += 1;
    }
    return Promise.resolve(json({}));
  });
  await boot(fetchMock);
  const input = document.querySelector("input[type=file]");
  Object.defineProperty(input, "files", { configurable: true, value: [new File(["private"], "old-subject.txt")] });
  input.dispatchEvent(new Event("change"));
  cookieParticipant = "22";
  // The write can precede the next Sync: it must still carry its original owner.
  document.querySelector("form").requestSubmit(); await vi.advanceTimersByTimeAsync(1);
  expect(unauthorizedSends).toBe(0);
  expect(document.querySelector("textarea").disabled).toBe(true);
  expect(document.body.textContent).toContain("Outro convite foi aberto");
  expect(document.body.textContent).not.toContain("Original ticket history");
  expect(document.querySelector('[data-action="retry-guest-message"]')).toBeNull();
  const warning = new Event("beforeunload", { cancelable: true }); window.dispatchEvent(warning);
  expect(warning.defaultPrevented).toBe(true);
  const calls = fetchMock.mock.calls.length; await vi.advanceTimersByTimeAsync(500);
  expect(fetchMock).toHaveBeenCalledTimes(calls);
});

it("keeps an earlier unknown guest send uncertain when its retry is denied before receipt lookup", async () => {
  let attempts = 0;
  await boot(vi.fn((url) => {
    if (url.includes("/Guest/Sync?")) return Promise.resolve(json(syncData()));
    if (url.endsWith("/Guest/Send")) {
      attempts += 1;
      return attempts === 1 ? Promise.reject(new TypeError("lost reply"))
        : Promise.resolve(json({ error: "Conversation now read only", code: "conversation_read_only" }, 403));
    }
    return Promise.resolve(json({}));
  }));
  document.querySelector("textarea").value = "Maybe committed";
  document.querySelector("form").requestSubmit(); await vi.advanceTimersByTimeAsync(1);
  document.querySelector('[data-action="retry-guest-message"]').click(); await vi.advanceTimersByTimeAsync(1);
  expect(document.querySelector(".is-optimistic").textContent).toContain("Confirmação pendente");
  expect(document.querySelector('[data-action="restore-guest-message"]')).toBeNull();
});
