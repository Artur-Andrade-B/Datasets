<?php
declare(strict_types=1);

// Actual lifecycle helpers with only native model storage/transactions replaced.
require dirname(__DIR__, 3) . '/src/domain/domain.php';
require dirname(__DIR__, 3) . '/src/db/setup_helpers.php';

class Ticket {}
class DefaultsStore
{
    public static array $rows = [], $next = [];
    public static string $fail = '';
    public function find(array $where): array
    {
        return array_filter(self::$rows[static::class] ?? [], static function (array $row) use ($where): bool {
            foreach ($where as $key => $value) { if (($row[$key] ?? null) !== $value) { return false; } }
            return true;
        });
    }
    public function add(array $input): int
    {
        if (self::$fail === static::class) { return 0; }
        $id = self::$next[static::class] = (self::$next[static::class] ?? 0) + 1;
        self::$rows[static::class][$id] = ['id' => $id] + $input;
        return $id;
    }
    public function update(array $input): bool
    {
        self::$rows[static::class][$input['id']] = $input + self::$rows[static::class][$input['id']];
        return true;
    }
}
class NotificationTemplate extends DefaultsStore {}
class NotificationTemplateTranslation extends DefaultsStore {}
class NotificationTarget extends DefaultsStore {}
class Notification_NotificationTemplate extends DefaultsStore { const MODE_AJAX = 'ajax', MODE_MAIL = 'mailing'; }
class Notification extends DefaultsStore { const ASSIGN_TECH = 1, ASSIGN_GROUP = 2, OBSERVER = 3, OBSERVER_GROUP = 4, AUTHOR = 5, USER_TYPE = 1; }
$DB = new class {
    private array $snapshot = [];
    public function beginTransaction(): void { $this->snapshot = [DefaultsStore::$rows, DefaultsStore::$next]; }
    public function commit(): void { $this->snapshot = []; }
    public function rollBack(): void { [DefaultsStore::$rows, DefaultsStore::$next] = $this->snapshot; }
};
$checks = 0;
$check = static function (bool $ok, string $why) use (&$checks): void { if (!$ok) { throw new RuntimeException($why); } $checks++; };

DefaultsStore::$fail = NotificationTarget::class;
try { glpichat_install_default_notifications(); throw new LogicException('Expected seed failure'); }
catch (RuntimeException $error) { $check(DefaultsStore::$rows === [], 'Failed first seed rolls back templates, definitions and partial relations'); }
DefaultsStore::$fail = '';
glpichat_install_default_notifications();
$check(count(DefaultsStore::$rows[NotificationTemplate::class]) === 2, 'Two shipped templates seeded');
$check(count(DefaultsStore::$rows[Notification::class]) === 8, 'All initial event definitions seeded');
$check(count(DefaultsStore::$rows[NotificationTarget::class]) === 40, 'New definitions receive default recipients');

foreach (DefaultsStore::$rows[NotificationTemplateTranslation::class] as &$translation) {
    $translation['subject'] = 'Custom subject';
    $translation['content_text'] = 'Custom text';
    $translation['content_html'] = '<p>Custom HTML</p>';
}
unset($translation);
DefaultsStore::$rows[Notification_NotificationTemplate::class][1]['notificationtemplates_id'] = 987;
unset(DefaultsStore::$rows[Notification_NotificationTemplate::class][2]);
unset(DefaultsStore::$rows[NotificationTarget::class][1]);
DefaultsStore::$rows[Notification::class][1]['is_active'] = 0;
DefaultsStore::$rows[Notification::class][1]['is_recursive'] = 0;
$snapshot = DefaultsStore::$rows;
glpichat_install_default_notifications();
$check(DefaultsStore::$rows === $snapshot, 'Upgrade preserves exact template bodies, changed assignment, removed mode/target and disabled definition');

// An intentionally removed default translation is also not recreated.
unset(DefaultsStore::$rows[NotificationTemplateTranslation::class][1]);
$snapshot = DefaultsStore::$rows;
glpichat_install_default_notifications();
$check(DefaultsStore::$rows === $snapshot, 'Upgrade preserves removed default translation');
echo "PASS notification default upgrades: $checks assertions; production lifecycle helpers, explicit native-model fixtures.\n";
