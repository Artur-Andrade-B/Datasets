<?php

declare(strict_types=1);
require_once dirname(__DIR__, 3) . '/src/desktop/common.php';
require_once dirname(__DIR__, 3) . '/src/desktop/runtime.php';
require_once dirname(__DIR__, 3) . '/src/desktop/queue_health.php';
$count = 0;
function runtime_check(bool $value, string $message): void { ++$GLOBALS['count']; if (!$value) { throw new RuntimeException($message); } }
$now = strtotime(glpichat_desktop_now() . ' UTC');
$report = ['current_version' => '0.7.0', 'runtime_state' => 'current', 'runtime_version' => '0.7.0',
    'runtime_sessions' => 2, 'runtime_current_sessions' => 2, 'runtime_unmanaged_sessions' => 0];
$json = glpichat_management_runtime_store($report, null);
$machine = ['current_version' => '0.7.0', 'bootstrap_version' => '0.7.0', 'runtime_json' => $json];
$view = glpichat_management_runtime_view($machine, $now);
runtime_check($view['state'] === 'current' && $view['version'] === '0.7.0' && $view['sessions'] === 2, 'Fresh supervised sessions report their actual version separately');
runtime_check(glpichat_management_runtime_view($machine, $now + 301)['state'] === 'expired', 'Old telemetry does not stay green indefinitely');
runtime_check(glpichat_management_runtime_view(array_replace($machine, ['current_version' => '0.8.0']), $now)['state'] === 'stale', 'Later installed version does not silently upgrade previous runtime report');
$legacy = glpichat_management_runtime_store(['current_version' => '0.7.0'], $json);
runtime_check(glpichat_management_runtime_view(array_replace($machine, ['runtime_json' => $legacy]), $now)['state'] === 'unknown', 'Legacy heartbeat cannot claim interactive runtime current');
runtime_check(json_decode($legacy, true)['received_at'] === json_decode($json, true)['received_at'], 'Legacy heartbeat retains historical snapshot without refreshing its age');
runtime_check(glpichat_management_runtime_store([], null) === null, 'Legacy machine without runtime history remains explicitly unknown');
foreach ([['runtime_current_sessions' => 1], ['runtime_unmanaged_sessions' => 1], ['runtime_version' => '0.6.0'], ['runtime_sessions' => 100000], ['runtime_sessions' => '2'], ['runtime_state' => []]] as $bad) {
    $invalid = glpichat_management_runtime_store(array_replace($report, $bad), null);
    runtime_check(json_decode($invalid, true)['state'] === 'unknown', 'Inconsistent optional runtime telemetry becomes unknown without stopping management');
}
$none = glpichat_management_runtime_store(array_replace($report, ['runtime_state' => 'no_session', 'runtime_version' => '', 'runtime_sessions' => 0, 'runtime_current_sessions' => 0]), null);
runtime_check(glpichat_management_runtime_view(array_replace($machine, ['runtime_json' => $none]), $now)['state'] === 'no_session', 'No chat session is distinct from failed/current/unknown Widget');
$unmanaged = glpichat_management_runtime_store(array_replace($report, ['runtime_state' => 'stale', 'runtime_version' => '', 'runtime_current_sessions' => 1, 'runtime_unmanaged_sessions' => 1]), null);
runtime_check(glpichat_management_runtime_view(array_replace($machine, ['runtime_json' => $unmanaged]), $now)['unmanaged_sessions'] === 1, 'Unmanaged session remains visible separately');
runtime_check(glpichat_management_bootstrap_pending(['current_version' => '0.7.0', 'bootstrap_version' => '0.4.0']), 'Committed migration-capable payload reports pending Bootstrap');
runtime_check(!glpichat_management_bootstrap_pending(['current_version' => '0.6.0', 'bootstrap_version' => '0.4.0']), 'Old payload must not promise unavailable automatic Bootstrap migration');
runtime_check(!glpichat_management_bootstrap_pending($machine), 'Matching Bootstrap migration is complete');
runtime_check(str_contains(glpichat_management_error_label('WIDGET_UNMANAGED_RUNNING'), 'atalho instalado') && str_contains(glpichat_management_error_label('WIDGET_UNMANAGED_RUNNING'), 'WIDGET_UNMANAGED_RUNNING'), 'Unmanaged runtime failure supplies tray/installed-shortcut recovery and retains diagnostic code');
runtime_check(str_contains(glpichat_management_error_label('WIDGET_RUNTIME_UNAVAILABLE'), 'diagnóstico') && glpichat_management_error_label('UNKNOWN_CODE') === 'UNKNOWN_CODE', 'Inspection failure supplies diagnostic action without inventing instructions for unknown errors');
echo "[PASS] Runtime telemetry: $count assertions.\n";
