<?php

declare(strict_types=1);

// Production browser orchestration, multipart validation, native storage adapter,
// notification intent and transaction helper. Native object/DB writers are explicit
// fixtures; the actual GLPI Document writer has a separate core-boundary suite.
use Symfony\Component\HttpFoundation\File\UploadedFile;
if (!class_exists(UploadedFile::class)) {
    require $argv[1] ?? dirname(__DIR__, 5) . '/vendor/autoload.php';
}

final class Config {
    public static string $schema = '5';
    public static function getConfigurationValue(string $scope, string $key): string { return self::$schema; }
}
final class Ticket {
    public static bool $terminal = false, $merged = false;
    public function getFromDB(int $id): bool { return $id === 7; }
    public static function getMergedTickets(int $id): array { return self::$merged ? [8] : []; }
}
final class Session {
    public static function getLoginUserID(): int|false { return $_SESSION['glpiID'] ?? false; }
}
final class DocumentType { public static function getUploadableFilePattern(): string { return '/\.txt$/iD'; } }
final class Toolbox { public static function getPhpUploadSizeLimit(): int { return 1048576; } }
final class UploadRows extends ArrayIterator {
    public function current(): mixed { return $this->valid() ? parent::current() : false; }
    public function free(): void {}
}
final class UploadDb {
    public array $tables = ['documents' => [], 'links' => [], 'followups' => [], 'messages' => [], 'glpi_plugin_glpichat_notificationjobs' => [], 'glpi_plugin_glpichat_browsersends' => []];
    public array $calls = [];
    public string $fail = '';
    public bool $active = false, $denyInTransaction = false;
    public int $commits = 0;
    private array $before = [];
    private int $lastId = 0;
    public function escape(string $value): string { return addslashes($value); }
    public function insertId(): int { return $this->lastId; }
    public function update(string $table, array $values, array $where): bool {
        foreach ($this->tables[$table] as &$row) {
            if ($row['id'] === $where['id']) { $row = array_replace($row, $values); }
        }
        return true;
    }
    public function beginTransaction(): void { $this->before = $this->tables; $this->active = true; }
    public function commit(): void { $this->active = false; ++$this->commits; }
    public function rollBack(): void { $this->tables = $this->before; $this->active = false; }
    public function doQuery(string $sql): UploadRows {
        if (str_contains($sql, 'GET_LOCK(')) { return new UploadRows([['acquired' => 1]]); }
        if (str_contains($sql, 'RELEASE_LOCK(')) { return new UploadRows([['released' => 1]]); }
        if (str_starts_with($sql, 'SELECT * FROM glpi_plugin_glpichat_browsersends ')) {
            preg_match('/client_message_id = \'([^\']+)\'/', $sql, $match);
            return new UploadRows(array_values(array_filter($this->tables['glpi_plugin_glpichat_browsersends'],
                static fn(array $row): bool => $row['users_id'] === 10 && $row['client_message_id'] === ($match[1] ?? ''))));
        }
        if (str_starts_with($sql, 'SELECT m.id, m.content, f.content AS native_content')) {
            $message = $this->tables['messages'][1] ?? [];
            $followup = $this->tables['followups'][1] ?? [];
            return new UploadRows($message && $followup ? [['id' => 1, 'content' => $message['content'], 'native_content' => $followup['content']]] : []);
        }
        if ($sql === 'SELECT ext FROM glpi_documenttypes WHERE is_uploadable = 1 ORDER BY ext') {
            return new UploadRows([['ext' => 'txt']]);
        }
        if ($sql === 'SELECT id, entities_id FROM glpi_tickets WHERE id = 7 FOR UPDATE') {
            return new UploadRows([['id' => 7, 'entities_id' => 3]]);
        }
        throw new LogicException('Unexpected SQL: ' . $sql);
    }
    public function fetchAssoc(UploadRows $rows): mixed { $value = $rows->current(); $rows->next(); return $value; }
    public function request(array $criteria): UploadRows {
        $matches = array_filter($this->tables[$criteria['FROM']], static function (array $row) use ($criteria): bool {
            foreach ($criteria['WHERE'] as $key => $value) { if ($row[$key] !== $value) { return false; } }
            return true;
        });
        return new UploadRows(array_values($matches));
    }
    public function insert(string $table, array $input): bool {
        if (!$this->active) { throw new LogicException('Write outside transaction.'); }
        if ($this->fail === 'native_job' && ($input['source_type'] ?? '') === 'followup') { return false; }
        if ($this->fail === 'message_job' && ($input['source_type'] ?? '') === 'message') { return false; }
        $input['id'] = count($this->tables[$table]) + 1;
        $this->lastId = $input['id'];
        $this->tables[$table][$input['id']] = $input;
        return true;
    }
}
final class Document {
    public static function isValidDoc(string $name): string { return preg_match('/\.txt$/iD', $name) === 1 ? 'TXT' : ''; }
    public function add(array $input): int {
        global $DB;
        if ($DB->fail === 'document') { throw new RuntimeException('Document write failed.'); }
        $DB->calls[] = ['document', $input, Session::getLoginUserID(), $GLOBALS['GLPICHAT_SUPPRESS_DOCUMENT_HOOK']];
        if (!$DB->insert('documents', $input)) { return 0; }
        return count($DB->tables['documents']);
    }
}
class Document_Item {
    public function add(array $input): int {
        global $DB;
        if ($DB->fail === 'link') { throw new RuntimeException('Association write failed.'); }
        $DB->insert('links', $input);
        return count($DB->tables['links']);
    }
}
function &glpichat_ticket_or_fail_cache(): array { static $cache = []; return $cache; }
function glpichat_is_ticket_terminal_for_chat(int $ticket): bool { return Ticket::$terminal; }
function glpichat_can_read_room(int $ticket, string $room): bool { global $DB; return !$DB->active || !$DB->denyInTransaction; }
function glpichat_can_send(int $ticket, string $room): bool { global $DB; return !$DB->active || !$DB->denyInTransaction; }
function glpichat_current_user_id(): int { return 10; }
function glpichat_room_id(int $ticket, string $room): int { return $room === 'public' ? 11 : 12; }
function glpichat_participant_id_for_user(int $room, int $user, bool $create, bool $defer): int {
    global $DB;
    $DB->calls[] = ['participant', $defer];
    return 21;
}
function glpichat_add_followup(int $ticket, int $user, string $content, bool $private, bool $defer): int {
    global $DB;
    $DB->insert('followups', ['items_id' => $ticket, 'users_id' => $user, 'content' => $content, 'is_private' => $private]);
    if (!$defer) { throw new LogicException('Synchronous notification requested.'); }
    glpichat_queue_notification_job('followup', 1, $ticket, 'add_followup', $private ? 'internal' : 'public', $user);
    return 1;
}
function glpichat_add_message(int $ticket, string $room, string $actor, int $user, int $participant, string $content, int $document, int $followup, bool $notify): int {
    global $DB;
    if ($notify) { throw new LogicException('Synchronous notification requested.'); }
    $DB->insert('messages', ['tickets_id' => $ticket, 'room_type' => $room, 'users_id' => $user, 'content' => $content, 'documents_id' => $document, 'itilfollowups_id' => $followup]);
    return 1;
}
function glpichat_message_by_id(int $id): array {
    global $DB;
    if ($DB->fail === 'render') { throw new RuntimeException('Response rendering failed.'); }
    return $DB->tables['messages'][$id];
}

require dirname(__DIR__, 3) . '/src/browser_delivery.php';
require dirname(__DIR__, 3) . '/src/notification_queue.php';
$assertions = 0;
function upload_assert(bool $value, string $description): void {
    ++$GLOBALS['assertions'];
    if (!$value) { throw new RuntimeException($description); }
}
$directory = sys_get_temp_dir() . '/glpichat-browser-upload-' . bin2hex(random_bytes(8));
mkdir($directory, 0700);
define('GLPI_UPLOAD_DIR', $directory);
$CFG_GLPI = ['document_max_size' => 1, 'documentcategories_id_forticket' => 5];
$file = static function (string $name = 'nota.txt') use ($directory): UploadedFile {
    $path = tempnam($directory, 'incoming-');
    file_put_contents($path, 'browser upload fixture');
    return new UploadedFile($path, $name, 'text/plain', UPLOAD_ERR_OK, true);
};
$fresh = static function (): void {
    $GLOBALS['DB'] = new UploadDb();
    $_SESSION = ['glpiID' => 10, 'preserved' => 'session'];
    $GLOBALS['GLPICHAT_SUPPRESS_DOCUMENT_HOOK'] = 'outer-value';
    Config::$schema = '5'; Ticket::$terminal = false; Ticket::$merged = false;
};
try {
    foreach (['public', 'internal'] as $room) {
        $fresh(); $beforeSession = $_SESSION;
        $response = glpichat_browser_upload(7, $room, $file());
        upload_assert($DB->commits === 1 && !$DB->active && $response['documents_id'] === 1, $room . ' upload commits its complete response');
        $document = $DB->tables['documents'][1];
        upload_assert(!isset($document['itemtype']) && $document['entities_id'] === 3 && $document['users_id'] === 10, 'Native standalone document retains ticket entity and browser author');
        upload_assert($DB->tables['followups'][1]['is_private'] === ($room === 'internal'), 'Native followup carries exact room privacy');
        $types = array_column($DB->tables['links'], 'itemtype');
        upload_assert($types === ['ITILFollowup'], 'Chat upload never creates a direct Ticket document link bypassing later privacy changes');
        foreach ($DB->tables['links'] as $link) {
            upload_assert($link['_disablenotif'] === true && $link['_do_notif'] === false, 'Native association does not render a synchronous notification');
        }
        upload_assert(count($DB->tables['glpi_plugin_glpichat_notificationjobs']) === 2, 'Native followup and exact chat notification intents are committed together');
        upload_assert($DB->tables['glpi_plugin_glpichat_notificationjobs'][2]['event'] === ($room === 'internal' ? 'glpichat_internal_message' : 'glpichat_public_message'), 'Deferred plugin event retains room recipient policy');
        upload_assert($_SESSION === $beforeSession && $GLOBALS['GLPICHAT_SUPPRESS_DOCUMENT_HOOK'] === 'outer-value', 'Native storage restores ambient session and suppression state');
        upload_assert(glob($directory . '/*') === [], 'Owned temporary staging file removed after success');
    }
    $fresh();
    $token = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
    $first = glpichat_browser_upload(7, 'public', $file(), $token);
    $replayFile = $file();
    Ticket::$terminal = true;
    $replay = glpichat_browser_upload(7, 'public', $replayFile, $token);
    Ticket::$terminal = false;
    upload_assert($first === $replay && $replay['message']['client_message_id'] === $token, 'Lost response replays exact attachment receipt and UUID');
    upload_assert(count($DB->tables['documents']) === 1 && count($DB->tables['followups']) === 1
        && count($DB->tables['messages']) === 1 && count($DB->tables['glpi_plugin_glpichat_notificationjobs']) === 2,
        'Attachment retry creates no duplicate document, source, mirror or notification');
    unlink($replayFile->getPathname());
    $changed = $file('changed.txt');
    try { glpichat_browser_upload(7, 'public', $changed, $token); throw new LogicException('Expected payload conflict'); }
    catch (GlpichatDesktopException $error) { upload_assert($error->errorCode === 'idempotency_conflict', 'Same attachment UUID rejects altered filename/payload'); }
    unlink($changed->getPathname());
    $fresh();
    glpichat_browser_upload(7, 'public', $file('nota<rascunho>&.txt'));
    upload_assert($DB->tables['followups'][1]['content'] === 'Attachment added from GLPI Chat: nota&lt;rascunho&gt;&amp;.txt'
        && $DB->tables['messages'][1]['content'] === 'Attachment added from GLPI Chat: nota<rascunho>&.txt',
        'Native HTML followup escapes a legal filename while chat mirror remains plain text');
    foreach (['document', 'link', 'native_job', 'message_job', 'render'] as $failure) {
        $fresh(); $DB->fail = $failure; $input = $file();
        try { glpichat_browser_upload(7, 'internal', $input); throw new LogicException('Expected failure.'); }
        catch (RuntimeException $error) {
            upload_assert(!$error instanceof LogicException, $failure . ' reaches expected failure boundary');
        }
        upload_assert($DB->commits === 0 && !$DB->active && count(array_filter($DB->tables)) === 0, $failure . ' rolls back document, associations, mirror, followup and intents');
        upload_assert($_SESSION === ['glpiID' => 10, 'preserved' => 'session'] && $GLOBALS['GLPICHAT_SUPPRESS_DOCUMENT_HOOK'] === 'outer-value', $failure . ' restores session/hook state');
        // Before native storage begins, PHP still owns the incoming upload.
        if (is_file($input->getPathname())) { unlink($input->getPathname()); }
        upload_assert(glob($directory . '/*') === [], $failure . ' leaves no owned staging file');
    }
    $fresh(); Ticket::$merged = true; $input = $file();
    try { glpichat_browser_upload(7, 'public', $input); throw new LogicException('Expected merged-source rejection.'); }
    catch (GlpichatDesktopException $error) {
        upload_assert($error->errorCode === 'conversation_merge_unsupported' && $error->httpStatus === 409,
            'Merged source directs the upload to its actual destination ticket');
    }
    upload_assert(count(array_filter($DB->tables)) === 0 && $DB->commits === 0 && is_file($input->getPathname()),
        'Merged source check precedes every native write and file move');
    unlink($input->getPathname());
    $fresh(); $DB->denyInTransaction = true; $input = $file();
    try { glpichat_browser_upload(7, 'public', $input); throw new LogicException('Expected denial.'); }
    catch (GlpichatDesktopException $error) { upload_assert($error->errorCode === 'authorization_denied', 'Browser authorization is rechecked after ticket lock'); }
    upload_assert(count(array_filter($DB->tables)) === 0 && is_file($input->getPathname()), 'Authorization failure precedes file move and all native writes');
    unlink($input->getPathname());
    $fresh(); Config::$schema = '4'; $input = $file();
    try { glpichat_browser_upload(7, 'public', $input); throw new LogicException('Expected schema failure.'); }
    catch (GlpichatDesktopException $error) { upload_assert($error->errorCode === 'schema_unavailable', 'Incomplete migration cannot start attachment writes'); }
    unlink($input->getPathname());
    echo '[PASS] Browser upload delivery: ' . $assertions . " assertions; real storage adapter with explicit native writer/DB fixtures.\n";
} finally {
    foreach (glob($directory . '/*') ?: [] as $path) { unlink($path); }
    rmdir($directory);
}
