<?php

declare(strict_types=1);

// Failure injection of the production transaction/receipt service. Explicit SQL
// transport and native-writer fixtures, not a live GLPI/MariaDB integration.
final class Config {
    public static string $schema = '5';
    public static function getConfigurationValue(string $scope, string $key): string { return self::$schema; }
}
final class Ticket {
    public static bool $terminal = false;
    public function getFromDB(int $id): bool { return in_array($id, [7, 8], true); }
}
final class Session {
    public static int $user = 10;
    public static function getLoginUserID(): int { return self::$user; }
}
final class BrowserRows {
    public int $position = 0;
    public function __construct(public array $rows) {}
    public function free(): void {}
}
final class BrowserDB {
    public array $receipts = [], $messages = [], $followups = [], $jobs = [], $queries = [];
    public bool $active = false, $busy = false, $allowed = true, $failQueue = false, $failRender = false;
    public bool $mismatchNative = false, $failReceipt = false, $failRelease = false, $denyInTransaction = false, $canCreate = true;
    public int $lastId = 0, $commits = 0, $releases = 0, $aclChecks = 0;
    private array $backup = [];
    public function escape(string $s): string { return addslashes($s); }
    public function beginTransaction(): void {
        if ($this->active) { throw new RuntimeException('nested'); }
        $this->backup = [$this->receipts, $this->messages, $this->followups, $this->jobs];
        $this->active = true;
    }
    public function commit(): void { $this->active = false; $this->commits++; }
    public function rollBack(): void {
        [$this->receipts, $this->messages, $this->followups, $this->jobs] = $this->backup;
        $this->active = false;
    }
    public function insert(string $table, array $row): bool {
        if (!$this->active || $table !== 'glpi_plugin_glpichat_browsersends') { throw new RuntimeException('unexpected insert'); }
        foreach ($this->receipts as $existing) {
            if ($existing['users_id'] === $row['users_id'] && $existing['client_message_id'] === $row['client_message_id']) { throw new RuntimeException('duplicate unique key'); }
        }
        $row['id'] = $this->lastId = count($this->receipts) + 1;
        $this->receipts[$row['id']] = $row;
        return true;
    }
    public function insertId(): int { return $this->lastId; }
    public function update(string $table, array $set, array $where): bool {
        if ($table !== 'glpi_plugin_glpichat_browsersends' || !$this->active) { throw new RuntimeException('unexpected update'); }
        if ($this->failReceipt) { return false; }
        $this->receipts[$where['id']] = array_replace($this->receipts[$where['id']], $set);
        return true;
    }
    public function fetchAssoc(BrowserRows $rows): array|false { return $rows->rows[$rows->position++] ?? false; }
    public function doQuery(string $sql): BrowserRows {
        $this->queries[] = $sql;
        if (str_starts_with($sql, 'SELECT GET_LOCK(')) { return new BrowserRows([['acquired' => $this->busy ? 0 : 1]]); }
        if (str_starts_with($sql, 'SELECT RELEASE_LOCK(')) {
            $this->releases++;
            if ($this->failRelease) { throw new RuntimeException('release failure'); }
            return new BrowserRows([['released' => 1]]);
        }
        if (preg_match('/^SELECT id FROM glpi_tickets WHERE id = (\d+) FOR UPDATE$/', $sql, $m)) {
            return new BrowserRows(in_array((int) $m[1], [7, 8], true) ? [['id' => (int) $m[1]]] : []);
        }
        if (preg_match("/^SELECT \* FROM glpi_plugin_glpichat_browsersends WHERE users_id = (\d+) AND client_message_id = '([^']+)' FOR UPDATE$/", $sql, $m)) {
            return new BrowserRows(array_values(array_filter($this->receipts, static fn($r) => $r['users_id'] === (int) $m[1] && $r['client_message_id'] === $m[2])));
        }
        if (str_starts_with($sql, 'SELECT m.id, m.content, f.content AS native_content')) {
            // Assert native and plugin schema/ownership/room predicates rather
            // than accepting an invented room_type column on messages.
            foreach (['INNER JOIN glpi_plugin_glpichat_rooms r ON r.id = m.rooms_id', "m.participant_type = 'user'", "f.itemtype = 'Ticket'", 'FOR UPDATE'] as $guard) {
                if (!str_contains($sql, $guard)) { throw new RuntimeException('missing replay guard'); }
            }
            if (str_contains($sql, 'm.room_type')) { throw new RuntimeException('invented message field'); }
            preg_match('/m.id = (\d+) AND m.itilfollowups_id = (\d+) AND m.tickets_id = (\d+)/', $sql, $m);
            preg_match("/m.users_id = (\d+).*r.room_type = '(public|internal)'.*f.is_private = ([01])/", $sql, $a);
            $row = $this->messages[(int) $m[1]] ?? null;
            $followup = $this->followups[(int) $m[2]] ?? null;
            if (!$row || !$followup || $row['itilfollowups_id'] !== (int) $m[2] || $row['tickets_id'] !== (int) $m[3]
                || $row['users_id'] !== (int) $a[1] || $row['room_type'] !== $a[2] || $followup['is_private'] !== (int) $a[3]
                || $followup['users_id'] !== (int) $a[1] || $followup['items_id'] !== (int) $m[3]) { return new BrowserRows([]); }
            return new BrowserRows([['id' => $row['id'], 'content' => $row['content'], 'native_content' => $followup['content']]]);
        }
        if (str_starts_with($sql, 'SELECT b.messages_id,')) {
            preg_match('/b.users_id = (\d+) AND b.messages_id IN \(([^)]+)\)/', $sql, $m);
            $ids = array_map('intval', explode(',', $m[2])); $rows = [];
            foreach ($this->receipts as $r) {
                if ($r['users_id'] === (int) $m[1] && in_array($r['messages_id'], $ids, true)) {
                    $r['rooms_id'] = $r['room_type'] === 'public' ? 70 : 71; $rows[] = $r;
                }
            }
            return new BrowserRows($rows);
        }
        throw new RuntimeException('Unhandled SQL: ' . $sql);
    }
}
function glpichat_current_user_id(): int { return Session::$user; }
function &glpichat_ticket_or_fail_cache(): array { static $cache = []; return $cache; }
function glpichat_is_ticket_terminal_for_chat(int $id): bool { return Ticket::$terminal; }
function glpichat_can_read_room(int $ticket, string $room): bool { global $DB; $DB->aclChecks++; return $DB->allowed && !($DB->denyInTransaction && $DB->active); }
function glpichat_can_send(int $ticket, string $room): bool {
    global $DB; $DB->aclChecks++;
    return $DB->allowed && $DB->canCreate && !($DB->denyInTransaction && $DB->active);
}

function glpichat_room_id(int $ticket, string $room): int { return $room === 'public' ? 70 : 71; }
function glpichat_participant_id_for_user(int $room, int $user, bool $raise = true, bool $defer = false): int {
    global $DB;
    if (!$raise || !$defer || !$DB->active) { throw new RuntimeException('presence not deferred inside transaction'); }
    $DB->jobs[] = 'join'; return 30;
}
function glpichat_add_followup(int $ticket, int $user, string $content, bool $private, bool $defer = false): int {
    global $DB;
    if (!$defer || !$DB->active) { throw new RuntimeException('native event not deferred'); }
    $id = 100 + count($DB->followups);
    $DB->followups[$id] = ['id' => $id, 'items_id' => $ticket, 'users_id' => $user, 'content' => $DB->mismatchNative ? 'Changed by native writer' : $content, 'is_private' => (int) $private];
    $DB->jobs[] = 'native:' . $id; return $id;
}
function glpichat_add_message(int $ticket, string $room, string $actor, int $user, int $participant, string $content, int $document, int $followup, bool $notify = true): int {
    global $DB;
    if ($notify || !$DB->active) { throw new RuntimeException('inline plugin notification'); }
    $id = 500 + count($DB->messages);
    $DB->messages[$id] = ['id' => $id, 'tickets_id' => $ticket, 'rooms_id' => glpichat_room_id($ticket, $room), 'room_type' => $room, 'users_id' => $user, 'participant_type' => $actor, 'content' => $content, 'itilfollowups_id' => $followup];
    return $id;
}
function glpichat_queue_message_notifications(...$args): void {
    global $DB;
    if (!$DB->active) { throw new RuntimeException('job outside transaction'); }
    if ($DB->failQueue) { throw new RuntimeException('queue unavailable'); }
    $DB->jobs[] = 'plugin:' . $args[5];
}
function glpichat_message_by_id(int $id): array {
    global $DB;
    if (!$DB->active || $DB->failRender) { throw new RuntimeException('render failure'); }
    return $DB->messages[$id];
}
require_once dirname(__DIR__, 3) . '/src/browser_delivery.php';
$count = 0;
function check(bool $ok, string $label): void { global $count; if (!$ok) { throw new RuntimeException($label); } $count++; echo "[PASS] $label\n"; }
function rejects(callable $action, string $code, string $label): void {
    try { $action(); } catch (Throwable $e) {
        $matches = $code === '' ? ($e instanceof RuntimeException && !$e instanceof GlpichatDesktopException)
            : ($e instanceof GlpichatDesktopException && $e->errorCode === $code);
        if ($matches && $code === 'message_unavailable') {
            $matches = ($e->details['committed'] ?? false) === true
                && ($e->details['message_id'] ?? 0) > 0 && ($e->details['client_message_id'] ?? '') !== '';
        }
        check($matches, $label); return;
    }
    throw new RuntimeException('Expected rejection: ' . $label);
}
$DB = new BrowserDB();
$uuid = '01234567-89ab-4cde-8fab-0123456789ab';
$first = glpichat_browser_send(7, 'public', 'Hello', $uuid);
$replay = glpichat_browser_send(7, 'public', 'Hello', $uuid);
check($first === $replay && $first['message']['client_message_id'] === $uuid, 'Lost HTTP response retries confirm exactly the original message');
check(count($DB->messages) === 1 && count($DB->followups) === 1 && count($DB->receipts) === 1, 'Replay creates no duplicate native source, browser mirror or receipt');
check($DB->jobs === ['join', 'native:100', 'plugin:500'], 'Presence, native and plugin jobs are transactional and replay does not repeat them');
check($DB->commits === 2 && $DB->releases === 2 && $DB->aclChecks === 5, 'First send and replay both revalidate ACL inside the transaction and release token lock');
rejects(fn() => glpichat_browser_send(7, 'public', 'Different', $uuid), 'idempotency_conflict', 'Same UUID cannot change content');
rejects(fn() => glpichat_browser_send(8, 'public', 'Hello', $uuid), 'idempotency_conflict', 'Same UUID cannot move to another ticket');
rejects(fn() => glpichat_browser_send(7, 'internal', 'Hello', $uuid), 'idempotency_conflict', 'Same UUID cannot change public/private room');
$DB->allowed = false;
rejects(fn() => glpichat_browser_send(7, 'public', 'Hello', $uuid), 'authorization_denied', 'Current access denial precedes receipt disclosure'); $DB->allowed = true;
$DB->denyInTransaction = true;
rejects(fn() => glpichat_browser_send(7, 'public', 'Hello', $uuid), 'authorization_denied', 'Access changed before transaction is rechecked'); $DB->denyInTransaction = false;
Ticket::$terminal = true;
check(glpichat_browser_send(7, 'public', 'Hello', $uuid) === $first, 'Committed text retry remains acknowledged after ticket closes');
rejects(fn() => glpichat_browser_send(7, 'public', 'Fresh', '21234567-89ab-4cde-8fab-0123456789ab'), 'conversation_read_only', 'Terminal ticket rejects a fresh message'); Ticket::$terminal = false;
rejects(fn() => glpichat_browser_send(7, 'public', ' ', $uuid), 'invalid_content', 'Empty text is a definitive validation response');
$DB->followups[100]['is_private'] = 1;
rejects(fn() => glpichat_browser_send(7, 'public', 'Hello', $uuid), 'message_unavailable', 'Native source made private cannot be confirmed as public'); $DB->followups[100]['is_private'] = 0;
$DB->followups[100]['content'] = 'Edited';
rejects(fn() => glpichat_browser_send(7, 'public', 'Hello', $uuid), 'message_unavailable', 'Native source edit is detected even when mirror is stale'); $DB->followups[100]['content'] = '<p>Hello</p>';
check(glpichat_browser_send(7, 'public', 'Hello', $uuid) === $first, 'Native equivalent HTML formatting preserves exact message identity');
$DB->followups[100]['content'] = 'Hello';
$DB->followups[100]['users_id'] = 20;
rejects(fn() => glpichat_browser_send(7, 'public', 'Hello', $uuid), 'message_unavailable', 'Source reassigned to another author is unavailable'); $DB->followups[100]['users_id'] = 10;
$baseline = [$DB->receipts, $DB->followups, $DB->messages, $DB->jobs];
foreach (['failQueue', 'failReceipt', 'failRender', 'mismatchNative'] as $fault) {
    $DB->$fault = true;
    rejects(fn() => glpichat_browser_send(7, 'public', 'New', '11234567-89ab-4cde-8fab-0123456789ab'), '', $fault . ' fails before acknowledgment');
    check([$DB->receipts, $DB->followups, $DB->messages, $DB->jobs] === $baseline && !$DB->active, $fault . ' rolls back followup, mirror, receipt and notification jobs');
    $DB->$fault = false;
}
$DB->busy = true;
rejects(fn() => glpichat_browser_send(7, 'public', 'Hello', $uuid), 'send_busy', 'Concurrent same-token writer returns retryable busy without waiting');
check(!$DB->active && $baseline === [$DB->receipts, $DB->followups, $DB->messages, $DB->jobs], 'Busy retry mutates nothing'); $DB->busy = false;
Config::$schema = '4';
rejects(fn() => glpichat_browser_send(7, 'public', 'Hello', $uuid), 'schema_unavailable', 'Unmigrated schema rejects send before mutation'); Config::$schema = '5';
rejects(fn() => glpichat_browser_send(7, 'public', 'Hello', 'bad'), 'invalid_message_id', 'Malformed nonce is rejected');
$internal = glpichat_browser_send(7, 'internal', 'Internal', '21234567-89ab-4cde-8fab-0123456789ab');
check($DB->followups[$internal['message']['itilfollowups_id']]['is_private'] === 1, 'Internal-room send retains native private flag');
$mapped = glpichat_browser_attach_receipts(array_values($DB->messages));
check($mapped[0]['client_message_id'] === $uuid, 'Authorized current-author history row carries exact receipt UUID');
Session::$user = 20;
$mapped = glpichat_browser_attach_receipts(array_values($DB->messages));
check(!isset($mapped[0]['client_message_id']), 'Another user cannot receive someone else receipt token');
$other = glpichat_browser_send(7, 'public', 'Other user', $uuid);
check($other['message_id'] !== $first['message_id'], 'UUID uniqueness is scoped to authenticated user');
Session::$user = 10;
$legacy = glpichat_browser_send(7, 'public', 'Legacy client');
check(glpichat_browser_message_uuid($legacy['client_message_id']) === $legacy['client_message_id'], 'Legacy client without nonce remains supported with generated UUIDv4');
$DB->failRelease = true;
check(glpichat_browser_send(7, 'public', 'Hello', $uuid) === $first, 'Post-commit lock cleanup failure cannot turn confirmed message into failure');
$DB->canCreate = false;
check(glpichat_browser_send(7, 'public', 'Hello', $uuid) === $first, 'Committed text retry needs current read access even after create permission removal');
rejects(fn() => glpichat_browser_send(7, 'public', 'Fresh', '31234567-89ab-4cde-8fab-0123456789ab'), 'authorization_denied', 'Removed create permission still blocks a fresh write');
$DB->canCreate = true;
glpichat_browser_assert_expected_user(10);
rejects(fn() => glpichat_browser_assert_expected_user(11), 'account_context_changed', 'A stale-tab draft cannot send under another authenticated account');
rejects(fn() => glpichat_browser_assert_expected_user(0), 'account_context_changed', 'An explicit missing account anchor cannot authorize a captured draft');
echo "[PASS] Browser delivery failure-injection tests completed ($count assertions).\n";
