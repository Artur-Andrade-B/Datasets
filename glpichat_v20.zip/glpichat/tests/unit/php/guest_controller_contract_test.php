<?php

declare(strict_types=1);

require dirname(__DIR__, 2) . '/bootstrap/unit.php';
final class Config
{
    public static function getConfigurationValue(string $scope, string $key): mixed { return $key === 'guest_session_ttl' ? 3600 : null; }
}
final class GuestControllerReadOnlyDB
{
    public int $lookups = 0;
    public array $rows = [];
    public function request(array $query): ArrayIterator { return new ArrayIterator($this->rows); }
    public function tableExists(string $table): bool { ++$this->lookups; return false; }
}
require dirname(__DIR__, 3) . '/src/Controller/GuestController.php';
$DB = new GuestControllerReadOnlyDB();
$CFG_GLPI = ['root_doc' => '/nested/glpi', 'url_base' => 'http://obsolete.example'];
$controller = new GlpiPlugin\Glpichat\Controller\GuestController();
$token = str_repeat('a', 64);
$request = Symfony\Component\HttpFoundation\Request::create('https://glpi.example/nested/glpi/plugins/glpichat/Accept/' . $token);
$response = $controller->accept($request, $token);
glpichat_unit_assert_same(302, $response->getStatusCode(), 'Initial acceptance issues recovery redirect');
glpichat_unit_assert_same('/nested/glpi/plugins/glpichat/Accept/' . $token, $response->headers->get('Location'), 'Acceptance preserves deployed subdirectory');
$cookies = $response->headers->getCookies();
glpichat_unit_assert_same(1, count($cookies), 'Only recovery secret is issued before consumption');
glpichat_unit_assert_true(str_starts_with($cookies[0]->getName(), 'glpichat_guest_claim_'), 'Recovery cookie is invitation scoped');
glpichat_unit_assert_true($cookies[0]->isHttpOnly() && $cookies[0]->isSecure(), 'Recovery cookie protects HTTPS capability');
glpichat_unit_assert_same('/nested/glpi/plugins/glpichat', $cookies[0]->getPath(), 'Cookie honors GLPI subdirectory');
glpichat_unit_assert_true(str_contains((string) $response->headers->get('Cache-Control'), 'no-store'), 'Accept redirect is never cached');
glpichat_unit_assert_true($DB->lookups > 0, 'Initial accept only performs rate limiter table lookup');
$failure = new ReflectionMethod($controller, 'jsonFailure');
$e = new GlpichatGuestException('send_throttled', 'Wait', 429, 2);
$r = $failure->invoke($controller, $e, 'test');
glpichat_unit_assert_same(429, $r->getStatusCode(), 'Throttle keeps explicit status');
glpichat_unit_assert_same('2', $r->headers->get('Retry-After'), 'Throttle exposes bounded retry delay');
$receipt = new GlpichatGuestException('message_unavailable', 'Confirmed but unavailable', 409, 0,
    ['committed' => true, 'message_id' => 42, 'client_message_id' => 'aaaaaaaa-aaaa-4aaa-8aaa-000000000042']);
$r = $failure->invoke($controller, $receipt, 'test');
$body = json_decode($r->getContent(), true);
glpichat_unit_assert_true($body['committed'] === true && $body['message_id'] === 42, 'Committed hidden receipt cannot become a new-send retry');
$r = $failure->invoke($controller, new RuntimeException('internal secret SQL detail'), 'unit_fixture');
$body = json_decode($r->getContent(), true);
glpichat_unit_assert_same(503, $r->getStatusCode(), 'Runtime errors remain recoverable service failures');
glpichat_unit_assert_true(isset($body['reference']) && !str_contains($r->getContent(), 'secret'), 'Runtime response excludes internal exception text');
$r = $controller->page(Symfony\Component\HttpFoundation\Request::create('https://glpi.example/Guest'));
glpichat_unit_assert_same(401, $r->getStatusCode(), 'Missing guest cookie is an authentication error');
$DB->rows = [['id' => 22, 'rooms_id' => 33, 'joined_at' => date('Y-m-d H:i:s'), 'last_activity' => date('Y-m-d H:i:s')]];
$oldTab = ['expected_participant_id' => 11, 'expected_rooms_id' => 33];
$cookie = [GLPICHAT_GUEST_COOKIE => str_repeat('b', 64)];
$r = $controller->sync(Symfony\Component\HttpFoundation\Request::create('https://glpi.example/Guest/Sync', 'GET', $oldTab, $cookie));
glpichat_unit_assert_same(409, $r->getStatusCode(), 'Old tab cannot sync as replaced guest subject');
glpichat_unit_assert_same('guest_context_changed', json_decode($r->getContent(), true)['code'], 'Old tab receives explicit context mismatch');
$r = $controller->leave(Symfony\Component\HttpFoundation\Request::create('https://glpi.example/Guest/Leave', 'POST', ['expected_participant_id' => 22, 'expected_rooms_id' => 44], $cookie));
glpichat_unit_assert_same(409, $r->getStatusCode(), 'Old tab cannot end a different guest room session');
$joined = '2026-10-05 10:00:00';
glpichat_unit_assert_same(glpichat_event_cursor($joined, '', 0), glpichat_guest_event_cursor($joined, '2020-01-01 00:00:00|E|000000000001'), 'Guest event cursor cannot request pre-join events');
$next = '2026-10-05 10:01:00|E|000000000010';
glpichat_unit_assert_same($next, glpichat_guest_event_cursor($joined, $next), 'Guest event cursor preserves later progress');
foreach (['sync', 'send', 'upload', 'leave', 'attachment'] as $method) {
    $missing = Symfony\Component\HttpFoundation\Request::create('https://glpi.example/Guest', in_array($method, ['sync', 'attachment'], true) ? 'GET' : 'POST', [], $cookie);
    if ($method === 'upload') { $missing->headers->set('Content-Type', 'multipart/form-data'); }
    $r = $method === 'attachment' ? $controller->attachment($missing, 1, 1) : $controller->$method($missing);
    $body = json_decode($r->getContent(), true);
    glpichat_unit_assert_true($r->getStatusCode() === 409 && ($body['reload_required'] ?? false) === true, 'Legacy ' . $method . ' without rendered context requires reload before effects');
}
glpichat_unit_pass('Guest controller recovery, scope and error contracts:24 assertions');
