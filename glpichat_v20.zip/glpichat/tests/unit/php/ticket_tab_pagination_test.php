<?php
declare(strict_types=1);
require dirname(__DIR__) . '/js/helpers/ticket-tab-host.php';
$checks = 0;
$check = static function (bool $ok, string $message) use (&$checks): void { if (!$ok) { throw new RuntimeException($message); } $checks++; };
$DB = new class {
    public array $queries = [];
    public function request(array $query): ArrayIterator {
        $this->queries[] = $query;
        $rows = [];
        for ($id = 125 - $query['START']; $id > 0 && count($rows) < $query['LIMIT']; $id--) {
            $rows[] = ['id' => $id, 'date_creation' => '2026-10-05', 'action' => 'audit-fixture-' . $id, 'actor_type' => 'system', 'payload_json' => ''];
        }
        return new ArrayIterator($rows);
    }
};
$render = static function (int $start): string {
    $_GET = ['glpichat_audit_start' => $start]; $_POST = [];
    ob_start(); GlpiPlugin\Glpichat\TicketTab::displayTabContentForItem(new Ticket(), 2); return ob_get_clean();
};
$first = $render(0);
$check($DB->queries[0]['WHERE'] === ['tickets_id' => 42] && $DB->queries[0]['LIMIT'] === 51 && $DB->queries[0]['START'] === 0, 'Bounded ticket-scoped query with one sentinel');
$check(substr_count($first, '<tr>') === 51 && str_contains($first, 'audit-fixture-76') && !str_contains($first, 'audit-fixture-75'), 'Only the first 50 rows are rendered');
$check(str_contains($first, 'glpichat_audit_start=50') && !str_contains($first, '>Anterior'), 'First page advances without a previous link');
$second = $render(50);
$check(str_contains($second, 'audit-fixture-75') && !str_contains($second, 'audit-fixture-76'), 'Second page uses supplied offset without duplicate boundary rows');
$check(str_contains($second, 'glpichat_audit_start=0') && str_contains($second, 'glpichat_audit_start=100'), 'Both middle-page navigation actions are present');
$last = $render(100);
$check(substr_count($last, '<tr>') === 26 && !str_contains($last, '>Próxima'), 'Final partial page has no forward action');
$empty = $render(150);
$check(str_contains($empty, 'Nenhum evento') && str_contains($empty, 'glpichat_audit_start=100'), 'Out-of-range page retains a route back');
$render(-50);
$check(end($DB->queries)['START'] === 0, 'Negative offset is clamped');
$GLOBALS['test_audit_allowed'] = false; $count = count($DB->queries);
$check($render(0) === '' && count($DB->queries) === $count, 'Permission denial performs no audit query');
echo "PASS TicketTab pagination: $checks assertions; actual renderer with explicit database iterator fixture.\n";
