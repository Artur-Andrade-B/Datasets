<?php

namespace GlpiPlugin\G4freports\Ses;

/** One immutable calculation result is consumed by the screen, Word and Excel. */
class Calculator
{
    public static function build(array $input, array $data): array
    {
        if (($input['ins6_mode'] ?? '') !== 'assigned_n1') {
            throw new \InvalidArgumentException('O INS6 exige vínculo atual a grupo N1. Recarregue a página e gere novamente a extração.');
        }
        $warnings = $data['warnings'] ?? [];
        $capabilities = $data['capabilities'] ?? [];
        $selectionCatalog = $data['selection_catalog'] ?? [];
        $tickets = $data['tickets'] ?? [];
        $sourceCalls = $data['calls'] ?? [];
        $ticketIds = [];
        $priorityLabels = [2 => 'Baixa', 3 => 'Média', 4 => 'Alta', 5 => 'Muito alta'];
        $cohorts = [];
        foreach ($input['priority_map'] as $metricId => $priority) {
            $cohorts[$metricId] = ['priority' => $priority, 'all' => [], 'denominator' => [], 'numerator' => [], 'missing' => 0];
        }
        $n1Ids = array_fill_keys($input['n1_categories'], true);
        $validatedIds = array_fill_keys($input['validated_kb_ids'], true);
        $manualIncomplete = array_fill_keys($input['incomplete_ticket_ids'], true);
        $eligible = $resolvedN1 = $reopened = $kbLinked = $kbValidated = $kbProxy = $rated = $satisfied = [];
        $missing = $requests = $incidents = $unknownPriorities = $invalidRatings = 0;
        foreach ($tickets as &$ticket) {
            $id = (int)$ticket['id'];
            if (isset($ticketIds[$id])) {
                throw new \RuntimeException('A extração retornou o chamado ' . $id . ' duplicado. O relatório não foi gerado.');
            }
            $ticketIds[$id] = $id;
            if ((int)$ticket['type'] === 2) {
                $requests++;
            } elseif ((int)$ticket['type'] === 1) {
                $incidents++;
            }
            $deadline = self::date($ticket['deadline'] ?? null);
            $solved = self::date($ticket['solved_at'] ?? null);
            if ($solved === null) {
                throw new \RuntimeException('O chamado ' . $id . ' não tem data de solução válida na extração mensal.');
            }
            $ticket['within_sla'] = $deadline === null ? null : ($solved <= $deadline);
            if ($deadline === null) {
                $missing++;
            }
            $mapped = false;
            foreach ($cohorts as &$cohort) {
                if ((int)$ticket['priority'] !== $cohort['priority']) {
                    continue;
                }
                $mapped = true;
                $cohort['all'][] = $id;
                if ($deadline === null) {
                    $cohort['missing']++;
                } else {
                    $cohort['denominator'][] = $id;
                    if ($ticket['within_sla']) {
                        $cohort['numerator'][] = $id;
                    }
                }
            }
            unset($cohort);
            if (!$mapped) {
                $unknownPriorities++;
            }
            $ticket['ins5'] = !empty($ticket['reopened']) || isset($manualIncomplete[$id]);
            $ticket['incomplete_execution'] = isset($manualIncomplete[$id]);
            if ($ticket['ins5']) {
                $reopened[] = $id;
            }
            $ticket['n1_eligible'] = isset($n1Ids[(int)$ticket['category_id']]);
            $groups = array_map('intval', $ticket['group_ids'] ?? []);
            $ticket['ins6'] = $ticket['n1_eligible'] && count(array_intersect($groups, $input['n1_group_ids'])) > 0;
            if ($ticket['n1_eligible']) {
                $eligible[] = $id;
            }
            if ($ticket['ins6']) {
                $resolvedN1[] = $id;
            }
            $links = array_map('intval', $ticket['kb_ids'] ?? []);
            $ticket['kb_validated'] = false;
            if ($links) {
                $kbLinked[] = $id;
                foreach ($links as $kbId) {
                    if (isset($validatedIds[$kbId])) {
                        $ticket['kb_validated'] = true;
                        break;
                    }
                }
            }
            if ($ticket['kb_validated']) {
                $kbValidated[] = $id;
            }
            if ((int)($ticket['kb_category_id'] ?? 0) > 0) {
                $kbProxy[] = $id;
            }
            $rating = $ticket['satisfaction'] ?? null;
            $ticket['satisfaction_valid'] = false;
            if ($rating !== null && $rating !== '') {
                if (is_numeric($rating) && in_array((float)$rating, [1.0, 2.0, 3.0, 4.0, 5.0], true)) {
                    $rated[] = $id;
                    $ticket['satisfaction_valid'] = true;
                    if ((float)$rating >= 4) {
                        $satisfied[] = $id;
                    }
                } else {
                    $invalidRatings++;
                }
            }
        }
        unset($ticket);
        foreach ($input['incomplete_ticket_ids'] as $id) {
            if (!isset($ticketIds[$id])) {
                throw new \InvalidArgumentException('O chamado ' . $id . ' informado como execução incompleta não pertence ao período e filtros selecionados.');
            }
        }
        $allTickets = array_values($ticketIds);
        $metrics = [];
        foreach ($cohorts as $metricId => $cohort) {
            $note = 'Prioridade GLPI ' . $cohort['priority'] . ' (' . $priorityLabels[$cohort['priority']] . '). '
                . count($cohort['all']) . ' chamados no recorte; ' . $cohort['missing'] . ' sem prazo registrado, excluídos da fração.';
            $status = null;
            if ($cohort['missing'] > 0) {
                $status = count($cohort['denominator']) === 0 ? 'pending' : 'provisional';
            }
            $metrics[] = self::metric($metricId, 'Resolução no prazo — ' . $priorityLabels[$cohort['priority']],
                $cohort['numerator'], $cohort['denominator'], 90, 'gte',
                'Chamados solucionados até o prazo de solução registrado ÷ chamados desta prioridade com prazo registrado × 100.',
                $note, $status);
        }
        $reopeningAvailable = $capabilities['reopening'] ?? true;
        $metrics[] = self::metric('INS5', 'Chamados reabertos ou com execução incompleta', $reopeningAvailable ? $reopened : null, $allTickets, 2, 'lte',
            'União dos chamados com reabertura registrada e dos IDs de execução incompleta informados manualmente, sem duplicidade, ÷ chamados solucionados × 100.',
            count($input['incomplete_ticket_ids']) . ' IDs de execução incompleta informados. Reabertura usa transição registrada de solucionado/fechado para estado ativo; recusa de solução é evidência distinta.'
                . (!$reopeningAvailable ? ' Apuração pendente: a evidência de reabertura não está disponível, portanto a quantidade total e o percentual não podem ser determinados.' : ''),
            $reopeningAvailable ? null : 'pending');
        $ins6Method = 'Chamados solucionados de categorias elegíveis N1 com vínculo técnico atual a grupo N1 ÷ chamados solucionados de categorias elegíveis N1 × 100.';
        $metrics[] = self::metric('INS6', 'Chamados elegíveis com vínculo atual a grupo N1', $resolvedN1, $eligible, 80, 'gte', $ins6Method,
            'Elegibilidade exclusivamente pelas categorias selecionadas. Exige presença de grupo N1; chamados apenas em N2/N3 ou sem grupo não entram no numerador. Vínculos são os existentes na extração e não comprovam qual grupo realizou historicamente a solução nem o histórico de escalonamento. Critério: assigned_n1.');
        if ($eligible && !$resolvedN1) {
            $selectedGroups = [];
            foreach ($input['n1_group_ids'] as $groupId) {
                $name = $selectionCatalog['groups'][$groupId]['name'] ?? '';
                $selectedGroups[] = (string)$groupId . ($name !== '' ? ' — ' . $name : ' (nome não registrado nesta extração)');
            }
            $warnings[] = 'INS6: nenhum dos ' . count($eligible) . ' chamados elegíveis possui vínculo atual aos grupos N1 selecionados: '
                . implode('; ', $selectedGroups) . '. O resultado é 0%. Confira se esses grupos correspondem à equipe N1 no banco consultado; '
                . 'o resultado descreve os vínculos encontrados e não comprova ausência de atendimento histórico pela equipe.';
        }

        $testNumbers = [];
        foreach ($input['test_numbers'] as $test) {
            if (!empty($test['active'])) {
                $testNumbers[$test['number']] = $test['label'];
            }
        }
        $calls = $excludedCalls = $allCalls = $ins7 = $ins8 = $ins9 = [];
        $seenCalls = [];
        $answered = $abandoned = $abandonedShort = $unknown = $invalidTalk = $invalidWait = $invalidAbandon = $unfinished = 0;
        $talkSum = $talkCount = $waitSum = $waitCount = 0;
        foreach ($sourceCalls as $call) {
            $callKey = (string)$call['id'] . '|' . (string)$call['queue'];
            if (isset($seenCalls[$callKey])) {
                throw new \RuntimeException('A extração retornou uma ligação/fila duplicada. O relatório não foi gerado.');
            }
            $seenCalls[$callKey] = true;
            $call['call_key'] = $callKey;
            $digits = Settings::callerDigits($call['caller'] ?? '');
            $call['caller_normalized'] = $digits;
            if ($digits !== '' && array_key_exists($digits, $testNumbers)) {
                $call['excluded_reason'] = $testNumbers[$digits] !== '' ? $testNumbers[$digits] : 'Número de teste cadastrado';
                $call['test_number'] = $digits;
                $excludedCalls[] = $call;
                continue;
            }
            $connected = self::date($call['connected_at'] ?? null) !== null;
            $completed = self::date($call['completed_at'] ?? null) !== null;
            $hasAbandon = self::date($call['abandoned_at'] ?? null) !== null;
            $isAnswered = $connected || $completed;
            $isAbandoned = !$isAnswered && $hasAbandon;
            $talk = self::seconds($call['talk_seconds'] ?? null);
            $wait = self::seconds($call['wait_seconds'] ?? null);
            $abandonWait = self::seconds($call['abandon_wait_seconds'] ?? null);
            $call['type'] = $isAnswered ? 'Atendida' : ($isAbandoned ? 'Abandonada' : 'Sem desfecho');
            $call['ins7'] = $completed && $talk !== null && $talk <= 600;
            $call['ins8'] = $connected && $wait !== null && $wait <= 30;
            $call['ins9'] = $isAbandoned && $abandonWait !== null && $abandonWait > 30;
            $allCalls[] = $callKey;
            if ($isAnswered) {
                $answered++;
                if ($talk !== null) {
                    $talkSum += $talk;
                    $talkCount++;
                }
            }
            if ($isAbandoned) {
                $abandoned++;
                if ($abandonWait !== null && $abandonWait <= 30) {
                    $abandonedShort++;
                }
            }
            if (!$isAnswered && !$isAbandoned) {
                $unknown++;
            }
            if ($connected && !$completed) {
                $unfinished++;
            }
            if ($completed && $talk === null) {
                $invalidTalk++;
            }
            if ($connected && $wait === null) {
                $invalidWait++;
            }
            if ($isAbandoned && $abandonWait === null) {
                $invalidAbandon++;
            }
            if ($connected && $wait !== null) {
                $waitSum += $wait;
                $waitCount++;
            }
            if ($call['ins7']) {
                $ins7[] = $callKey;
            }
            if ($call['ins8']) {
                $ins8[] = $callKey;
            }
            if ($call['ins9']) {
                $ins9[] = $callKey;
            }
            $calls[] = $call;
        }
        $callNote = count($excludedCalls) . ' ligações excluídas por correspondência exata com números de teste ativos. Denominador: todas as ligações recebidas restantes, inclusive abandonadas. Não há exclusão automática por curta duração.';
        $metrics[] = self::metric('INS7', 'Atendimentos telefônicos com duração até 10 minutos', $ins7, $allCalls, 85, 'gte',
            'Ligações com evento COMPLETEAGENT/COMPLETECALLER e duração de conversação válida ≤ 600 segundos ÷ ligações recebidas × 100.',
            $callNote, ($unknown + $unfinished + $invalidTalk > 0 ? 'provisional' : null));
        $metrics[] = self::metric('INS8', 'Atendimentos telefônicos com espera até 30 segundos', $ins8, $allCalls, 85, 'gte',
            'Ligações com CONNECT e espera válida na fila até a conexão ≤ 30 segundos ÷ ligações recebidas × 100.',
            $callNote, ($unknown + $invalidWait > 0 ? 'provisional' : null));
        $metrics[] = self::metric('INS9', 'Abandono de ligação telefônica', $ins9, $allCalls, 5, 'lte',
            'Ligações sem atendimento, com abandono após mais de 30 segundos na fila ÷ ligações recebidas × 100.',
            $callNote . ' Total de abandonos: ' . $abandoned . '; acima de 30 segundos (numerador do INS9): ' . count($ins9)
                . '; até 30 segundos: ' . $abandonedShort . '; sem espera válida: ' . $invalidAbandon
                . '. O limite é estritamente maior que 30 segundos.', ($unknown + $invalidAbandon > 0 ? 'provisional' : null));

        $staffComplete = $input['staff_total'] !== null && $input['staff_replacements'] !== null && $input['staff_excluded'] !== null;
        $staffNumerator = $staffComplete ? $input['staff_replacements'] - $input['staff_excluded'] : null;
        $metrics[] = self::countMetric('INS10', 'Rotatividade da equipe', $staffNumerator, $input['staff_total'], 10, 'lte',
            '(Substituições nos últimos três meses − exclusões determinadas pela contratante) ÷ total de profissionais informado × 100.',
            'Dados manuais referentes aos três meses até o fim do mês selecionado. Reduções determinadas pela contratante devem ser informadas separadamente. Não há fonte de pessoal no GLPI.',
            $staffComplete ? null : 'pending');
        if ($input['kb_mode'] === 'category_proxy') {
            $metrics[] = self::metric('INS11', 'Vinculação à base de conhecimento', $kbProxy, $allTickets, 80, 'gte',
                'Chamados cuja categoria atual tem categoria de base de conhecimento vinculada ÷ chamados solucionados × 100.',
                'PROXY PROVISÓRIO: reproduz o campo de categoria usado no Metabase. Não comprova vínculo do chamado a artigo validado.', count($allTickets) ? 'provisional' : null);
        } else {
            $kbAvailable = ($capabilities['kb_links'] ?? true) && ($selectionCatalog['articles_available'] ?? true)
                && count($input['validated_kb_ids']) > 0;
            $metrics[] = self::metric('INS11', 'Vinculação à base de conhecimento', $kbAvailable ? $kbValidated : null, $allTickets, 80, 'gte',
                'Chamados com vínculo direto a pelo menos um artigo da lista validada ÷ chamados solucionados × 100.',
                count($kbLinked) . ' chamados com vínculo direto observado; ' . count($input['validated_kb_ids']) . ' IDs de artigos validados informados. '
                    . (!$kbAvailable ? 'Apuração pendente: são necessários acesso aos vínculos diretos e ao catálogo de artigos, além de uma lista de artigos previamente validados.' : 'Cada chamado é contado uma única vez.'),
                $kbAvailable || !count($allTickets) ? null : 'pending');
        }
        $satisfactionAvailable = $capabilities['satisfaction'] ?? true;
        $metrics[] = self::metric('INS12', 'Satisfação do usuário', $satisfactionAvailable ? $satisfied : null, $rated, 80, 'gte',
            'Pesquisas GLPI válidas com nota 4 ou 5 ÷ pesquisas GLPI respondidas com nota de 1 a 5 × 100.',
            'A escala GLPI de 1 a 5 é explicitada; não há conversão numérica automática para a escala contratual de 0 a 10. Respostas recebidas após o mês podem integrar uma nova extração. '
                . $invalidRatings . ' respostas fora da escala foram excluídas.',
            ($satisfactionAvailable ? ($invalidRatings > 0 ? (count($rated) ? 'provisional' : 'pending') : null) : 'pending'));

        if ($missing) {
            $warnings[] = $missing . ' chamados sem prazo de solução válido. Eles permanecem no detalhamento, mas não são considerados automaticamente no prazo.';
        }
        if ($unknownPriorities) {
            $warnings[] = $unknownPriorities . ' chamados têm prioridades fora do mapeamento INS1–INS4; permanecem no total e no detalhamento.';
        }
        if ($unknown) {
            $warnings[] = $unknown . ' ligações não têm atendimento nem abandono identificado; os indicadores de telefonia são provisórios.';
        }
        if ($unfinished + $invalidTalk + $invalidWait + $invalidAbandon > 0) {
            $warnings[] = 'Telefonia: ' . $unfinished . ' ligações conectadas sem evento de conclusão; ' . $invalidTalk . ' conclusões sem duração válida; '
                . $invalidWait . ' conexões sem espera válida; ' . $invalidAbandon . ' abandonos sem espera válida. Valores ausentes ou negativos não contam como atendimento no limite.';
        }
        if ($invalidRatings) {
            $warnings[] = $invalidRatings . ' avaliações fora da escala GLPI 1–5 foram excluídas do denominador do INS12.';
        }
        $mappingNotes = [];
        foreach ($input['priority_map'] as $metricId => $priority) {
            $mappingNotes[] = $metricId . ' = prioridade ' . $priority . ' (' . $priorityLabels[$priority] . ')';
        }
        $months = [1 => 'janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
        return [
            'schema_version' => 1,
            'rules_version' => Settings::RULES_VERSION,
            'generated_at' => (new \DateTimeImmutable('now', new \DateTimeZone($input['timezone'])))->format(DATE_ATOM),
            'input' => $input,
            'selection_catalog' => $selectionCatalog,
            'period' => ['month' => $input['month'], 'start' => $input['start'], 'end_exclusive' => $input['end_exclusive'],
                'label' => ucfirst($months[(int)substr($input['month'], 5, 2)]) . ' de ' . substr($input['month'], 0, 4),
                'date_basis' => 'solvedate', 'call_date_basis' => 'queue_entry'],
            'totals' => ['tickets' => count($tickets), 'requests' => $requests, 'incidents' => $incidents,
                'calls_received' => count($calls), 'calls_answered' => $answered, 'calls_abandoned' => $abandoned,
                'calls_abandoned_over_30' => count($ins9), 'calls_abandoned_up_to_30' => $abandonedShort,
                'calls_abandoned_unknown_wait' => $invalidAbandon,
                'calls_excluded' => count($excludedCalls), 'calls_unknown' => $unknown, 'missing_deadline' => $missing,
                'mean_talk_seconds' => $talkCount ? $talkSum / $talkCount : null,
                'mean_wait_seconds' => $waitCount ? $waitSum / $waitCount : null,
                'mean_talk_count' => $talkCount, 'mean_wait_count' => $waitCount],
            'metrics' => $metrics, 'tickets' => $tickets, 'calls' => $calls, 'excluded_calls' => $excludedCalls,
            'warnings' => array_values(array_unique($warnings)),
            'manual' => ['executive_summary' => $input['executive_summary'], 'actions' => $input['actions'], 'notes' => $input['notes']],
            'rule_notes' => [
                'Chamados selecionados pela data de solução (solvedate), inclusive os abertos antes do mês; início inclusivo e primeiro instante do mês seguinte exclusivo.',
                'Telefonia selecionada pela entrada na fila (ENTERQUEUE); eventos posteriores ao fim do mês são consultados para determinar o desfecho. Unidade: identificador da ligação e fila.',
                'Datas das fontes interpretadas no horário local configurado (America/Sao_Paulo), sem conversão automática de UTC.',
                'Mapeamento de prioridades aplicado: ' . implode('; ', $mappingNotes) . '. A numeração operacional do painel e a numeração de severidade do contrato podem diferir; a associação escolhida é mostrada expressamente.',
                'INS1–INS4 usam o prazo de solução armazenado no GLPI. Não recalculam o prazo a partir de um número fixo de horas nem substituem os calendários, feriados ou pausas que formaram esse prazo.',
                'INS6 exige categoria elegível e vínculo atual a grupo N1. Ausência de grupo N2 não comprova atendimento N1; a atribuição atual não identifica o grupo que historicamente realizou a solução.',
                'Números de teste: correspondência exata dos dígitos do originador após remover a formatação; sem suposição de DDI, sem correspondência por sufixo. A lista aplicada acompanha esta extração.',
                'TMA por ligação é a duração de conversação; TME por ligação é a espera na fila antes de conectar ao agente. As médias usam as durações válidas de ligações atendidas/conectadas, respectivamente, e diferem dos percentuais INS7 e INS8.',
                'Sem população elegível: não aplicável, nunca aprovação automática ou zero por divisão vazia. Evidência ausente: pendente ou provisório conforme o indicador.',
                'Esta é uma extração do estado atual das bases, com data de geração. Não reconstitui automaticamente o estado histórico de um relatório emitido anteriormente. Word e Excel usam o mesmo conjunto de dados preservado.',
                'Valores de glosa e ajustes financeiros não são calculados sem base financeira e validação específica; justificativas e ações são registradas nos campos narrativos.',
            ],
        ];
    }

    private static function metric(string $id, string $label, $numeratorIds, array $denominatorIds,
        float $target, string $direction, string $method, string $note, $status = null): array
    {
        $metric = self::countMetric($id, $label, $numeratorIds === null ? null : count($numeratorIds), count($denominatorIds),
            $target, $direction, $method, $note, $status);
        $metric['evidence_ids'] = $numeratorIds;
        $metric['denominator_ids'] = $denominatorIds;
        return $metric;
    }

    private static function countMetric(string $id, string $label, $numerator, $denominator,
        float $target, string $direction, string $method, string $note, $status = null): array
    {
        $value = $denominator !== null && $denominator > 0 && $numerator !== null ? 100 * $numerator / $denominator : null;
        if ($status === null) {
            if ($denominator === 0) {
                $status = 'not_applicable';
            } elseif ($value === null) {
                $status = 'pending';
            } else {
                $status = ($direction === 'gte' ? $value >= $target : $value <= $target) ? 'met' : 'unmet';
            }
        }
        return ['id' => $id, 'label' => $label, 'numerator' => $numerator, 'denominator' => $denominator,
            'value' => $value, 'target' => $target, 'direction' => $direction, 'status' => $status,
            'method' => $method, 'note' => $note];
    }

    private static function seconds($value)
    {
        if ((!is_int($value) && !is_float($value) && !is_string($value)) || !is_numeric($value)
            || !is_finite((float)$value) || (float)$value < 0) {
            return null;
        }
        return (float)$value;
    }

    private static function date($value)
    {
        if (!is_string($value) || $value === '' || strpos($value, '0000-00-00') === 0) {
            return null;
        }
        try {
            $parsed = new \DateTimeImmutable($value, new \DateTimeZone('America/Sao_Paulo'));
            $errors = \DateTimeImmutable::getLastErrors();
            return is_array($errors) && ($errors['warning_count'] || $errors['error_count']) ? null : $parsed;
        } catch (\Exception $e) {
            return null;
        }
    }
}
